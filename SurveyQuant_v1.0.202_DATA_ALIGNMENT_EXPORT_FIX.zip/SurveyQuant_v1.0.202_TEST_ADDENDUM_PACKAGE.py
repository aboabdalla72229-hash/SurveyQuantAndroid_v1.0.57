#!/usr/bin/env python3
"""Structural/syntax test for the injected V177 addendum."""
from __future__ import annotations
import argparse
import re
import subprocess
import tempfile
from pathlib import Path

MARKER = "<!-- SURVEYQUANT_V177_SINGLE_CANVAS_DATA_EXPORT_INTEGRATED -->"
SCRIPT_ID = 'id="sq177-single-canvas-data-export"'
MODULE_MARKER = "/* SURVEYQUANT_V177_SINGLE_CANVAS_DATA_EXPORT_ADDENDUM */"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--html", type=Path, required=True)
    ap.add_argument("--module", type=Path, required=True)
    ns = ap.parse_args()
    html = ns.html.read_text(encoding="utf-8")
    module = ns.module.read_text(encoding="utf-8")
    assert MARKER in html, "integration marker missing"
    assert html.count(MARKER) == 1, "duplicate integration marker"
    assert html.count(SCRIPT_ID) == 1, "missing or duplicate inline script"
    assert MODULE_MARKER in module, "source module marker missing"
    assert "card.id='sq177OrientationCard'" in module
    assert "card.id='sq177DataExportCard'" in module
    assert "const MOUNT_STYLE_ID=MODULE_ID+'-style'" in module, "mount sentinel must be distinct from the script element ID"
    assert "getElementById(MOUNT_STYLE_ID)" in module, "mount guard must check the style sentinel, not the inline script ID"
    assert "getElementById(MODULE_ID)" not in module, "regression: module must not treat its own script as already mounted"
    assert "root.SurveyQuantCAD177" in module
    assert "function attachCanvasGestures" in module and "pointerdown" in module and "pointermove" in module and "pointerup" in module
    assert "startPinch" in module and "applyPinch" in module
    assert "touchAction='none'" in module and "overscrollBehavior='contain'" in module
    assert "selectWindow(a,b)" in module
    assert 'id="sq177-ori-target"' in module and 'id="sq177-ori-source"' in module
    for token in ['id="sq177-ori-view-target"','id="sq177-ori-view-source"','id="sq177-ori-align-start"','function alignmentStage(stage)','[0,2,1,3]','function buildBoardDxfBytes','data-export-point="sdr"','data-export-point="bnt"','data-export-point="xlsx"','data-export-point="pdf"','data-export-point="csv"','id="sq177-data-save-board-dxf"']:
        assert token in module, f'missing V202 requirement: {token}'
    assert "function pointIdForSequence(n)" in module and "return String(v)" in module
    assert "const n=d.nextId++,id=pointIdForSequence(n)" in module
    assert "addEventListener('input',()=>drawData())" in module, "marker/text settings must redraw the canvas immediately"
    assert "sideBySideOffset" not in module, "the two boards must not be offset and displayed simultaneously"
    assert "data-export=\"dxf\"" not in module, "board DXF save must be separate from point-list exports"
    assert "kind==='dxf'" not in module
    assert "function exportBoardDxf" in module and "function exportData(kind)" in module
    assert "function bntText(points=state.data.points)" in module
    assert not re.search(r"localStorage\s*\.", module), "session persistence is not allowed"
    assert re.search(r"</script>\s*" + re.escape(MARKER), html), "addendum is not placed before the integration marker"
    match = re.search(r'<script\s+id="sq177-single-canvas-data-export">([\s\S]*?)</script>', html, re.I)
    assert match, "inline addendum script not found"
    with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8") as f:
        f.write(match.group(1))
        f.flush()
        r = subprocess.run(["node", "--check", f.name], capture_output=True, text=True)
        if r.returncode:
            raise SystemExit(r.stderr or "node --check failed")
    print("PASS V202 integration: one inline script, same-canvas reference/source view toggles, source1-reference1-source2-reference2 Alignment, numeric point IDs, separate Board DXF and point-only SDR/BNT/Excel/PDF/CSV/TXT exports, live marker styling, pinch/pan/window handlers, no localStorage, JavaScript syntax valid")

if __name__ == "__main__":
    main()
