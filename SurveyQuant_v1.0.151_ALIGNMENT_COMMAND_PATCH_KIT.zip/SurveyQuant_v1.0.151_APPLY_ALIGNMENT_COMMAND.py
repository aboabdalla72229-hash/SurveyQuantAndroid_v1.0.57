#!/usr/bin/env python3
"""Install the fresh SurveyQuant ALIGNMENT command UI/controller into V150 HTML."""
from __future__ import annotations
import argparse, hashlib, pathlib, re, sys

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-html',required=True)
    ap.add_argument('--module-js',required=True)
    ap.add_argument('--output-html',required=True)
    ap.add_argument('--report',required=True)
    args=ap.parse_args()
    src_path=pathlib.Path(args.input_html); mod_path=pathlib.Path(args.module_js); out_path=pathlib.Path(args.output_html); report_path=pathlib.Path(args.report)
    if not src_path.is_file() or not mod_path.is_file():
        raise SystemExit('ERROR: source HTML or new ALIGNMENT module missing.')
    html=src_path.read_text(encoding='utf-8')
    module=mod_path.read_text(encoding='utf-8')
    if 'id="sq-alignment-command-module"' in html:
        raise SystemExit('ERROR: ALIGNMENT module is already installed. Refusing to double-install.')
    version_token='const SQ_APP_VERSION_CODE = 150;'
    if html.count(version_token)!=1:
        raise SystemExit(f'ERROR: expected exactly one V150 app version constant; found {html.count(version_token)}')
    html=html.replace(version_token,'const SQ_APP_VERSION_CODE = 151;',1)
    # Retire the old UI constructor entirely while preserving its tested two-point/byte-transform helpers.
    legacy=re.compile(r"""function sqOriMount\(\) \{[\s\S]*?\n\}\nwindow\.sqOpenOrientationProject = function \(\) \{[\s\S]*?\n\};\nwindow\.sqCloseOrientationProject = function \(\) \{[\s\S]*?\n\};\nwindow\.__sqOrientTest = \{solve:sqOriSolve, transformBytes:sqOriTransformBytes\};\nif \(typeof document !== 'undefined'\) \{\n  if \(document\.readyState==='loading'\) document\.addEventListener\('DOMContentLoaded',sqOriMount,\{once:true\}\);\n  else sqOriMount\(\);\n\}""")
    replacement="""function sqOriMount() { /* retired V151 legacy UI; the fresh ALIGNMENT command mounts after CAD APIs are ready */ }
window.__sqOrientTest = {solve:sqOriSolve, transformBytes:sqOriTransformBytes};
if (typeof document !== 'undefined') {
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded',sqOriMount,{once:true});
  else sqOriMount();
}"""
    html,removed=legacy.subn(replacement,html,count=1)
    if removed!=1: raise SystemExit(f'ERROR: expected to retire exactly one legacy orientation UI constructor, removed={removed}')
    if '</body>' not in html:
        raise SystemExit('ERROR: closing body tag is missing from source HTML.')
    # The command is a fresh controller over the existing CAD parser and byte-preserving writer adapter.
    script='\n<script id="sq-alignment-command-module">\n'+module.rstrip()+'\n</script>\n'
    html=html.replace('</body>',script+'</body>',1)
    checks={
      'version151': html.count('const SQ_APP_VERSION_CODE = 151;')==1,
      'new_alignment_module': html.count('id="sq-alignment-command-module"')==1,
      'legacy_ui_retired': 'function sqOriMount() { /* retired V151 legacy UI' in html and 'document.body.appendChild(overlay)' not in html[html.find('function sqOriMount'):html.find('window.__sqOrientTest')],
      'new_entry_point': 'window.sqOpenAlignmentCommand=show' in html,
      'replaces_old_project_entry': 'const oldBtn=$(\'sqOrientationMenuButton\');if(oldBtn)oldBtn.remove();' in html,
      'shared_dwg_reader': 'await api.openCad(file)' in html and 'window.parseFile = parseFile;' in html,
      'entity_transformer': 'engine.transformBytes(source.bytes,t)' in html,
      'fresh_session': 'function resetSession(announce=false)' in module and 's.target=null;s.reference=null;' in module,
      'dxf_output_label': "base+'_ALIGNED.dxf'" in module,
      'no_forced_positive_coordinates': 'لا تُجبر الإحداثيات على أن تكون موجبة' in module,
    }
    failed=[k for k,v in checks.items() if not v]
    if failed: raise SystemExit('ERROR: alignment patch preflight failed: '+', '.join(failed))
    out_path.parent.mkdir(parents=True,exist_ok=True);out_path.write_text(html,encoding='utf-8')
    report='''# V151 Fresh ALIGNMENT Command Patch Report\n\n## What changed\n- Replaced the visible legacy orientation menu/card/dialog with a new `ALIGNMENT` command UI and controller.\n- Kept the shared CAD parser and byte-preserving DXF transformer as the file-format adapter; the command itself now owns a clean session, new file-loading lifecycle, two-board point picking, preview overlay, checks, and output workflow.\n- Both source and reference accept DXF or DWG. DWG is read by the shared LibreDWG path and converted to DXF in memory; exported output is a new DXF file, while the original files are left untouched.\n- Added per-board load-generation tokens, resets on open/close/file replacement, WCS snap-point input, two-point similarity Alignment, transformed-source overlay, and output entity/preview sanity checks.\n- Reduced mobile drawing viewports to 32vh (min 170/180 px; max 320 px).\n\n## Preflight\n'''+''.join(f'- {"PASS" if ok else "FAIL"}: {name}\n' for name,ok in checks.items())+f'\nHTML bytes: {len(html.encode("utf-8"))}\nSHA-256: {hashlib.sha256(html.encode("utf-8")).hexdigest()}\n\n## Limit\nA DXF/LibreDWG text conversion cannot guarantee round-trip fidelity for opaque proprietary Civil 3D/Proxy/Solid objects whose internal geometry is not exposed by the converter. The export engine must reject unsupported payloads instead of producing a deceptively successful partial drawing. Real user DWG/DXF validation is required before survey production use.\n'
    report_path.parent.mkdir(parents=True,exist_ok=True);report_path.write_text(report,encoding='utf-8')
    print('PASS V151 patcher: installed fresh ALIGNMENT command; HTML bytes',len(html.encode('utf-8')),'sha256',hashlib.sha256(html.encode('utf-8')).hexdigest())
    for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
    return 0
if __name__=='__main__':
    raise SystemExit(main())
