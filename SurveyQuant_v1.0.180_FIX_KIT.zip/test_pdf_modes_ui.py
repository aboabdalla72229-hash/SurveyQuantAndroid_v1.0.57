from pathlib import Path
import os, shutil
import base64
from playwright.sync_api import sync_playwright
import ezdxf
root=Path(__file__).resolve().parent; html_path=root/'index.html' if (root/'index.html').is_file() else root/'source/index.html'; html=html_path.read_text()
fixtures=[('mixed',root/'V180_MIXED_ARCHITECTURAL_TEST.pdf','OfficePlan_Mixed_Raster_Vector',45,3),('raster',root/'V180_RASTER_ONLY_TEST.pdf','OfficePlan_RasterOnly',40,0),('vector',root/'V180_VECTOR_ONLY_TEST.pdf','OfficePlan_VectorOnly',3,2)]
with sync_playwright() as p:
 browser_bin=os.environ.get('CHROMIUM_BIN') or shutil.which('chromium') or shutil.which('chromium-browser')
 b=p.chromium.launch(executable_path=browser_bin,headless=True,args=['--no-sandbox','--allow-file-access-from-files'])
 page=b.new_page(viewport={'width':430,'height':900});errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded',timeout=90000)
 page.evaluate("window.__nativeSaved=null;window.__nativeNotified=null;window.Android={saveFile:(filename,mime,base64)=>{window.__nativeSaved={filename,mime,base64};},notifyDownload:(filename,path,mime)=>{window.__nativeNotified={filename,path,mime};}};")
 page.wait_for_timeout(300);page.locator('#sq176-home-pdf-project').click();page.wait_for_timeout(100)
 for idx,(mode,pdf,name,minpoly,mintext) in enumerate(fixtures):
  if idx==0: page.locator('#sq162-raster-file').set_input_files(str(pdf))
  else:
   with page.expect_file_chooser() as fc: page.locator('#sq162-raster-file').click()
   fc.value.set_files(str(pdf))
  page.wait_for_timeout(200); assert page.locator('#sq162-pdf-output-name').input_value()==pdf.stem
  # Blank names must be rejected before expensive PDF processing.
  page.evaluate('window.__nativeSaved=null')
  page.locator('#sq162-pdf-output-name').fill('')
  page.locator('#sq162-trace').click();page.wait_for_timeout(250)
  assert page.evaluate('window.__nativeSaved===null')
  assert 'اكتب اسم اللوحة' in page.locator('#sq162-raster-status').inner_text()
  page.locator('#sq162-pdf-output-name').fill(name)
  page.locator('#sq162-trace').click();page.wait_for_function('window.__nativeSaved!==null',timeout=60000)
  saved=page.evaluate('window.__nativeSaved');assert saved['filename']==name+'.dxf',(mode,saved['filename'])
  assert page.evaluate('window.__nativeNotified.filename')==name+'.dxf'
  out=root/f'V180_{mode.upper()}_UI_OUTPUT.dxf';out.write_bytes(base64.b64decode(saved['base64']))
  d=ezdxf.readfile(out);m=d.modelspace();pc=len(m.query('POLYLINE'));tc=len(m.query('TEXT'));ic=len(m.query('IMAGE'))+len(m.query('IMAGEDEF'));a=d.audit()
  print(mode,'filename=',saved['filename'],'POLYLINE=',pc,'TEXT=',tc,'IMAGE=',ic,'audit=',len(a.errors),len(a.fixes),'status=',page.locator('#sq162-raster-status').inner_text().split('\n')[1])
  assert pc>=minpoly,(mode,pc);assert tc>=mintext,(mode,tc);assert ic==0,(mode,ic);assert not a.errors and not a.fixes,(mode,a.errors,a.fixes)
  rt=root/f'V180_{mode.upper()}_ROUNDTRIP.dxf';d.saveas(rt);z=ezdxf.readfile(rt).audit();assert not z.errors and not z.fixes
 print('PASS all three PDF modes; mixed page combined vector and raster, blank output name rejected, chosen output names saved, DXF audits/roundtrip clean.')
 print('non-project page errors already present in base shell:',errs[:10])
 b.close()
