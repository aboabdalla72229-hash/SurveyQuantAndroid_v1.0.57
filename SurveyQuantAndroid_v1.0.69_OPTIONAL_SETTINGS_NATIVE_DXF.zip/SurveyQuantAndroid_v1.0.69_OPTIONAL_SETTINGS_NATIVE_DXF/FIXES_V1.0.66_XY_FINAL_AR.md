# إصلاح v1.0.66 النهائي للإحداثيات X/Y

- ترتيب الملفات المساحية بدون Header أصبح: Northing, Easting, Elevation للـ SDR/PNT/TXT/CSV/DAT.
- يتم التطبيع داخليًا دائمًا إلى X = Easting وY = Northing.
- إذا وُجد Header صريح مثل X/Y أو E/N أو Easting/Northing، يتم الالتزام به ولا يتم قلب الأعمدة.
- تم إصلاح إخراج PNT/TXT/CSV من مشروع تنقيح الملفات ليحافظ على Northing, Easting, Elevation في الملف الخارجي.
- لا يوجد أي تبديل لاحق عند تحويل النقاط إلى DXF؛ X يأخذ Easting وY يأخذ Northing.
