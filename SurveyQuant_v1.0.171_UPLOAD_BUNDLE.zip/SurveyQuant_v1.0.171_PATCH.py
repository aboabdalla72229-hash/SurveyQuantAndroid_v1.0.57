#!/usr/bin/env python3
from __future__ import annotations
import argparse,base64,re
from pathlib import Path

META='<meta name="surveyquant-v171" content="sq171-home-shortcuts-pdf-image-underlay-paired-save">'
SLOT=re.compile(r'(<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">)([A-Za-z0-9+/=\r\n]+)(</script>)',re.I)

def patch_html(html:str,engine:bytes)->str:
    if 'sq170-orientation-canvas-zoom-per-board-picks-snap-wasm-binary-pdf-worker-ole-reader' not in html: raise ValueError('V170 baseline is required')
    if 'sq171-home-shortcuts-pdf-image-underlay-paired-save' in html: raise ValueError('V171 already applied')
    head=re.search(r'<head\b[^>]*>',html,re.I)
    if not head: raise ValueError('HTML head missing')
    html=html[:head.end()]+META+html[head.end():]
    data=base64.b64encode(engine).decode('ascii')
    html,n=SLOT.subn(lambda m:m.group(1)+data+m.group(3),html,count=1)
    if n!=1: raise ValueError(f'Expected exactly one CAD engine payload slot, found {n}')
    validate(html,engine)
    return html

def validate(html:str,engine:bytes)->None:
    for marker in ('sq170-orientation-canvas-zoom-per-board-picks-snap-wasm-binary-pdf-worker-ole-reader','sq171-home-shortcuts-pdf-image-underlay-paired-save','sq163-pdfjs-worker','sq162-wasm-binary','id="project1Card"','id="dropFilesCard"','onclick="openProjectPage(\'project1Card\')"','onclick="openProjectPage(\'dropFilesCard\')"'):
        if marker not in html: raise ValueError('V171 HTML missing required marker: '+marker)
    m=SLOT.search(html)
    if not m or base64.b64decode(m.group(2))!=engine: raise ValueError('Embedded CAD engine differs from tested V171 engine')
    for marker in ('SQ_V170_ORIENTATION_VIEWPORT_PER_BOARD_PICK_SNAP_AXES_EXTENTS_AND_PDF_WORKER','function makeRasterUnderlayDxf','function downloadPairedRasterFile','IMAGEDEF','sq-home-orientation-project','sq-home-pdf-project','IMAGE/IMAGEDEF القياسي بدل OLE2FRAME'):
        if marker not in engine.decode('utf-8'): raise ValueError('V171 engine missing behaviour: '+marker)
    if 'تم إخراج ملف DXF واحد فقط' in engine.decode('utf-8'): raise ValueError('Old OLE-only PDF export remains')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--html',type=Path,required=True);ap.add_argument('--engine',type=Path,required=True);ap.add_argument('--check-only',action='store_true');a=ap.parse_args()
    html=a.html.read_text(encoding='utf-8');engine=a.engine.read_bytes()
    if a.check_only: validate(html,engine);print('PASS V171 exact embedded engine and required project shortcut validation');return
    out=patch_html(html,engine);a.html.write_text(out,encoding='utf-8');print(f'PASS V171 patch applied: {a.html} ({len(out):,} HTML chars)')
if __name__=='__main__':main()
