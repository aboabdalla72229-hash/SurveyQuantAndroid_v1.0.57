          'use strict';
          const fs = require('node:fs');
          const assert = require('node:assert/strict');
          const vm = require('node:vm');
          const [htmlPath] = process.argv.slice(2);
          assert(htmlPath, 'usage: node SurveyQuant_v1.0.138_ORIENTATION_REGRESSION_TEST.js INDEX_OR_EXTRACTED_APK_HTML');
          const html = fs.readFileSync(htmlPath, 'utf8');
          const bridgeTag = html.match(/<script\s+id=["']sq-v117-universal-dwg-bridge["']\s*>([\s\S]*?)<\/script\s*>/i);
          assert(bridgeTag, 'the shared V117/V126 DWG bridge script is missing');
          const bridge = bridgeTag[1];
          assert.equal((html.match(/SQ_V138_UNIVERSAL_CAD_INPUT_GATE/g) || []).length, 1,
            'V138 shared CAD picker gate must be embedded exactly once');
          assert.match(html, /const\s+SQ_APP_VERSION_CODE\s*=\s*138\s*;/,
            'the embedded app version check must advance to 137');
          assert(bridge.includes('strongCadHint'), 'CAD context detector missing');
          assert(bridge.includes('MutationObserver'), 'dynamically-created project pickers must be monitored');
          assert(bridge.includes('window.__sqV117DwgBridgeAPI'), 'original V117 bridge API is missing');
          assert(html.includes('window.__sqOriAxisAutoTest'), 'native app DWG converter lookup must remain available outside the shared picker bridge');
          assert(bridge.includes('function universalTransformBytes') === false,
            'universalTransformBytes belongs to the app drawing engine, not the bridge itself');
          assert(html.includes('function universalTransformBytes(input,t)'), 'byte-preserving CAD transform was removed');
          assert(html.includes('dwg_write_dxf(bytes.buffer)'), 'local DWG-to-DXF writer was removed');
          assert(html.includes("function sqDwgWasmRuntimePath()"), 'absolute Android WebView WASM path helper is missing');
          assert(html.includes("new URL('./libredwg-writer/wasm/', document.baseURI)"), 'WASM URL must resolve from packaged app page');
          assert.equal((html.match(/LibreDwg\.create\(sqDwgWasmRuntimePath\(\)\)/g) || []).length, 2,
            'main board import and orientation must both use the corrected WASM path');
          assert.equal((html.match(/LibreDwg\.create\('\.\/libredwg-writer\/wasm'\)/g) || []).length, 0,
            'relative WASM path that triggers Failed to fetch must be removed');
          assert(html.includes('safeDownloadFile'), 'existing safe download path was removed');
          assert(bridge.includes("var NON_CAD_DATA_IDS = new Set(['fileToDxfInput', 'cleanFilesInput']);"),
            'dedicated point-list utilities must remain excluded');
          
          // V138 orientation restoration: make sure the real, active two-board dialog is connected.
          assert(html.includes('window.sqExtractDxfAxisEntities = sqExtractDxfAxisEntities;'),
            'raw DXF extraction function must be exposed to the axis detection module');
          assert(html.includes('id="sq110ReadAxesBtn"'), 'active two-board orientation must show Read Axes control');
          assert(html.includes("el('sq110ReadAxesBtn').addEventListener('click',readAxesForOrientation)"),
            'Read Axes must invoke the reader belonging to the visible two-board project');
          assert(html.includes('function readAxesForOrientation()'), 'active board pair must have an automatic axes reader');
          assert(html.includes("الإزاحة X '+t.tx.toPrecision(12)"), 'preview must report X/Y translation as well as angle and scale');
          assert(!html.includes('scale<1e-9||scale>1e9') && !html.includes('scale < 1e-9 || scale > 1e9'),
            'legacy arbitrary scale limits must not block valid board sizes');
          assert.equal((html.match(/height:430px;min-height:320px;max-height:520px/g) || []).length, 2,
            'both orientation board canvases must use the larger flexible viewport');
          assert(html.includes('Math.abs(Number(t.height)||2.5)*m.scale*0.8'),
            'CAD texts must scale with the actual board view and zoom');

          const orientationSolverMatch = html.match(/function solve\(src1,src2,ref1,ref2\)\{[\s\S]*?\n\}/);
          assert(orientationSolverMatch, 'two-board similarity transform solver is missing');
          const orientationSolverContext = { Math, Number, Error };
          vm.createContext(orientationSolverContext);
          vm.runInContext(orientationSolverMatch[0] + ';this.__solve=solve;', orientationSolverContext);
          const orientationSolve = orientationSolverContext.__solve;
          let orientationT = orientationSolve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
          assert(Math.abs(orientationT.scale-2)<1e-10, 'two-board solver must calculate scale factor 2');
          assert(Math.abs(orientationT.angleDeg-90)<1e-8, 'two-board solver must calculate 90 degree rotation');
          let mappedSecond = orientationT.point(10,0);
          assert(Math.hypot(mappedSecond.x-100,mappedSecond.y-220)<1e-8,
            'source point 2 must land on its corresponding reference point');
          orientationT = orientationSolve({x:0,y:0},{x:1,y:0},{x:0,y:0},{x:1e-12,y:0});
          assert(Math.abs(orientationT.scale-1e-12)<1e-24, 'tiny valid scale must remain supported');
          orientationT = orientationSolve({x:0,y:0},{x:1,y:0},{x:0,y:0},{x:1e12,y:0});
          assert.equal(orientationT.scale,1e12, 'large valid scale must remain supported');

          const orientationModuleMatch = html.match(/<script id="sq-orientation-axis-reader-module">([\s\S]*?)<\/script>/);
          assert(orientationModuleMatch, 'axis-reader module must remain bundled');
          const orientationWindow = { addEventListener() {} };
          const orientationDocument = { readyState:'loading', addEventListener() {} };
          const orientationContext = { window:orientationWindow, document:orientationDocument, Math, Number, String,
            Map, Set, Array, Object, RegExp, Error, console, TextDecoder };
          vm.createContext(orientationContext);
          vm.runInContext(orientationModuleMatch[1], orientationContext, {filename:'orientation-axis-reader.js'});
          assert(orientationWindow.__sqOriAxisAutoTest && orientationWindow.__sqOriAxisAutoTest.matchIntersections,
            'axis reader must expose its intersection matcher');
          function orientationModel(transform) {
            const point=(x,y)=>transform?transform(x,y):({x,y}); const entities=[];
            for(const x of [0,10]) entities.push({type:'LINE',layer:'GRID',a:point(x,0),b:point(x,10)});
            for(const y of [0,10]) entities.push({type:'LINE',layer:'GRID',a:point(0,y),b:point(10,y)});
            for(const [label,x] of [['AS',0],['BS',10]]) entities.push({type:'TEXT',layer:'BUBBLES',position:point(x,-0.5),text:label,height:0.5});
            for(const [label,y] of [['Z1',0],['Z2',10]]) entities.push({type:'TEXT',layer:'BUBBLES',position:point(-0.5,y),text:label,height:0.5});
            return {source:'DXF',entities};
          }
          const referenceGrid=orientationModel((x,y)=>({x:-100-2*y,y:300+2*x}));
          const sourceGrid=orientationModel();
          const axisMatches=orientationWindow.__sqOriAxisAutoTest.matchIntersections(referenceGrid,sourceGrid);
          assert(axisMatches.best && axisMatches.matches.length>=4,
            'auto axis reader must find and pair multiple labelled grid intersections');
          assert(axisMatches.matches.some(m=>m.key.includes('AS')&&m.key.includes('Z1')),
            'axis reader must recognize common axis labels AS/Z1');

          // XLINE/RAY axes must be extended using drawing bounds, not excluded or expanded by a fixed 100000 units.
          function orientationXlineModel(transform) {
            const point=(x,y)=>transform?transform(x,y):({x,y});
            const vector=(x,y)=>{if(!transform)return {x,y};const p0=transform(0,0),p1=transform(x,y);return {x:p1.x-p0.x,y:p1.y-p0.y};};
            const entities=[];
            for(const x of [0,10]) entities.push({type:'XLINE',layer:'GRID',basePoint:point(x,0),directionVector:vector(0,1)});
            for(const yy of [0,10]) entities.push({type:'XLINE',layer:'GRID',basePoint:point(0,yy),directionVector:vector(1,0)});
            for(const [label,x] of [['AS',0],['BS',10]]) entities.push({type:'TEXT',layer:'BUBBLES',position:point(x,-0.5),text:label,height:0.5});
            for(const [label,yy] of [['Z1',0],['Z2',10]]) entities.push({type:'TEXT',layer:'BUBBLES',position:point(-0.5,yy),text:label,height:0.5});
            return {source:'DXF',entities};
          }
          const xlineMatches=orientationWindow.__sqOriAxisAutoTest.matchIntersections(
            orientationXlineModel((x,y)=>({x:-100-2*y,y:300+2*x})),orientationXlineModel());
          assert(xlineMatches.best && xlineMatches.matches.length>=4,
            'XLINE axis families must also detect and match common grid intersections');
          console.log('PASS V138: automatic axis UI is connected to the original raw-DXF axis parser.');
          console.log('PASS V138: two-point solver calculates translation, rotation and valid unconstrained scale.');
          console.log('PASS V138: labelled LINE and XLINE grid intersections are detected; viewport/text scale is no longer fixed.');

          class TestBlob {
            constructor(parts = [], options = {}) {
              this.parts = parts;
              this.type = options.type || '';
              this.size = parts.reduce((n, part) => n + (part && part.byteLength != null ? part.byteLength : Buffer.byteLength(String(part))), 0);
            }
          }
          class TestFile extends TestBlob {
            constructor(parts, name, options = {}) { super(parts, options); this.name = name; this.lastModified = options.lastModified || 0; }
          }
          class TestDataTransfer {
            constructor() { this._files = []; this.items = { add: file => this._files.push(file) }; }
            get files() { return this._files.slice(); }
          }
          class TestEvent {
            constructor(type, options = {}) { this.type = type; this.bubbles = !!options.bubbles; this.defaultPrevented = false; }
            preventDefault() { this.defaultPrevented = true; }
            stopImmediatePropagation() { this.immediateStopped = true; }
          }
          function makeInput(id, accept, ariaLabel, parentText) {
            const attrs = { 'aria-label': ariaLabel || '' };
            return {
              nodeType: 1, id, tagName: 'INPUT', type: 'file', accept: accept || '', files: [], value: '',
              labels: ariaLabel ? [{ textContent: ariaLabel }] : [], projectChangeCount: 0,
              getAttribute(name) { return attrs[String(name).toLowerCase()] || null; },
              parentElement: { nodeType: 1, tagName: 'DIV', textContent: parentText || ariaLabel || '', parentElement: null }
            };
          }
          const cadIds = [
            'concreteDxfInput', 'quantBeforeFile', 'quantAfterFile', 'quantFileInput',
            'profileFileInput', 'dropSurveyFiles', 'dropCadFile', 'sqOriReferenceFile',
            'sqOriTargetFile', 'sq108File', 'sq110TargetFile', 'sq110ReferenceFile'
          ];
          const knownInputs = cadIds.map(id => makeInput(id, '*/*'));
          const genericProjection = makeInput('projectFileInputX9', '*/*',
            'اختيار لوحة المصدر لمشروع إسقاط الملفات', 'إسقاط الملفات: اختر اللوحة المصدر');
          const genericMerge = makeInput('mergeDrawingUpload', '*/*',
            'Import CAD drawing to merge', 'Merge drawings');
          const pointList = makeInput('pointListInput', '*/*,.txt,.csv,.sdr,.pnt',
            'قائمة نقاط TXT CSV SDR PNT', 'استيراد قائمة نقاط');
          const imagePdf = makeInput('referencePhotoInput', 'image/*,.pdf',
            'اختيار صورة مرجعية PDF', 'إرفاق صورة مرجعية PDF');
          const textOnlyTools = [
            makeInput('fileToDxfInput', '.sdr,.txt,.csv,.pt,.pnt,text/plain,text/csv,*/*'),
            makeInput('cleanFilesInput', '.sdr,.pnt,.txt,.csv,.dat,text/plain,text/csv,*/*')
          ];
          const allInputs = [...knownInputs, genericProjection, genericMerge, pointList, imagePdf, ...textOnlyTools];
          const listeners = Object.create(null);
          let mutationCallback = null;
          const documentMock = {
            nodeType: 9,
            documentElement: {},
            querySelectorAll(selector) { return selector === 'input[type="file"]' ? allInputs : []; },
            addEventListener(type, fn) { (listeners[type] ||= []).push(fn); }
          };
          const calls = [];
          const testBytes = new Uint8Array([0, 10, 13, 255, 7, 8]);
          const windowMock = {
            __sqOriAxisAutoTest: {
              async convertTargetToDxf(file) {
                calls.push(file.name);
                return { ok: true, bytes: testBytes.slice(), name: file.name.replace(/\.dwg$/i, '.dxf') };
              }
            }
          };
          const context = {
            window: windowMock, document: documentMock,
            MutationObserver: class { constructor(fn) { mutationCallback = fn; } observe() {} },
            File: TestFile, Blob: TestBlob, DataTransfer: TestDataTransfer, Event: TestEvent,
            DragEvent: class extends TestEvent {}, alert() {},
            console: { log() {}, warn() {}, error() {} },
            ArrayBuffer, Uint8Array, Set, Map, Array, String, Number, Object, RegExp, Error, Date, Promise, Buffer
          };
          vm.createContext(context);
          vm.runInContext(bridge, context, { filename: 'embedded-sq-universal-dwg-bridge.js' });
          
          for (const id of cadIds) {
            const control = knownInputs.find(x => x.id === id);
            assert(control.accept.toLowerCase().includes('.dwg'), `known board picker failed DWG acceptance: ${id}`);
            assert(control.accept.toLowerCase().includes('.dxf'), `known board picker failed DXF preservation: ${id}`);
          }
          assert(genericProjection.accept.toLowerCase().includes('.dwg'), 'unknown Arabic projection-board picker must accept DWG');
          assert(genericProjection.accept.toLowerCase().includes('.dxf'), 'unknown Arabic projection-board picker must continue accepting DXF');
          assert(genericMerge.accept.toLowerCase().includes('.dwg'), 'unknown English CAD merge picker must accept DWG');
          assert(!pointList.accept.toLowerCase().includes('.dwg'), 'point-list text upload must not become a CAD picker');
          assert(!imagePdf.accept.toLowerCase().includes('.dwg'), 'image/PDF picker must remain outside automatic DWG conversion');
          for (const item of textOnlyTools) assert(!item.accept.toLowerCase().includes('.dwg'), `${item.id} must stay a point-list utility`);
          assert(mutationCallback, 'MutationObserver must be installed for controls dynamically created in project screens');
          const dynamicBoard = makeInput('dynamicUploadR8', '*/*', 'Upload drawing board for orientation', 'Reference board / CAD drawing');
          mutationCallback([{ addedNodes: [dynamicBoard] }]);
          assert(dynamicBoard.accept.toLowerCase().includes('.dwg'), 'dynamically created board picker must accept DWG');
          assert(dynamicBoard.accept.toLowerCase().includes('.dxf'), 'dynamically created board picker must keep DXF');
          
          (async () => {
            const source = new TestFile([testBytes], 'Unknown-Project-Board.DwG', { type: 'application/octet-stream' });
            genericProjection.files = [source];
            genericProjection.value = 'Unknown-Project-Board.DwG';
            genericProjection.dispatchEvent = function (event) {
              event.target = this;
              for (const handler of listeners.change || []) handler(event);
              if (!event.defaultPrevented) this.projectChangeCount++;
              return true;
            };
            const original = new TestEvent('change', { bubbles: true });
            genericProjection.dispatchEvent(original);
            assert(!original.defaultPrevented && !original.immediateStopped,
              'shared picker bridge must not intercept or replace native DWG change events');
            assert.equal(genericProjection.projectChangeCount, 1,
              'the selected DWG must continue through the existing project handler exactly once');
            assert.equal(genericProjection.files.length, 1, 'the existing project handler must retain the selected source file');
            assert.equal(genericProjection.files[0], source, 'the bridge must not substitute a temporary or redrawn file');
            assert.equal(genericProjection.files[0].name, 'Unknown-Project-Board.DwG', 'the original DWG name and extension must remain intact');
            assert.equal(source.name, 'Unknown-Project-Board.DwG', 'original DWG object must remain unchanged');
            assert.equal(calls.length, 0, 'the generic picker bridge must not run orientation-only conversion');
            assert.deepEqual(Array.from(source.parts[0]), Array.from(testBytes), 'source DWG bytes must remain unchanged');
            console.log('PASS V138: all known CAD projects plus generic Arabic projection and English merge inputs accept DWG.');
            console.log('PASS V138: dynamically created board inputs are recognized; native file-change handling is preserved.');
            console.log('PASS V138: point-list TXT/CSV/SDR/PNT and image/PDF controls remain excluded; original DWG is untouched.');
          })().catch(error => { console.error(error); process.exitCode = 1; });
