from pathlib import Path
import os, shutil, base64, json
from playwright.sync_api import sync_playwright
import ezdxf, ezdxf.recover
here=Path(__file__).resolve().parent
root=here if (here/'index.html').exists() else here/'kit'
html=(root/'index.html').read_text()
fixtures=[('mixed',root/'V180_MIXED_ARCHITECTURAL_TEST.pdf','RealPDF_Mixed'),('raster',root/'V180_RASTER_ONLY_TEST.pdf','RealPDF_Raster'),('vector',root/'V180_VECTOR_ONLY_TEST.pdf','RealPDF_Vector')]
ANDROID=r"""
window.__nativeSavedFiles={};window.__nativeNotifiedFiles=[];
window.Android={saveFile:(filename,mime,base64)=>{window.__nativeSavedFiles[filename]={filename,mime,base64};return 'Downloads/SurveyQuant/'+filename;},notifyDownload:(filename,path,mime)=>window.__nativeNotifiedFiles.push({filename,path,mime})};
"""
with sync_playwright() as p:
 bin=shutil.which('chromium') or '/usr/bin/chromium'
 b=p.chromium.launch(executable_path=bin,headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':430,'height':900})
 page_errors=[];page.on('pageerror',lambda e:page_errors.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded',timeout=120000)
 page.evaluate(ANDROID);page.wait_for_timeout(500)
 page.locator('#sq176-home-pdf-project').click();page.wait_for_timeout(120)
 result=[]
 for idx,(mode,pdf,name) in enumerate(fixtures):
  inp=page.locator('#sq162-raster-file')
  if idx==0: inp.set_input_files(str(pdf))
  else:
   with page.expect_file_chooser() as fc: inp.click()
   fc.value.set_files(str(pdf))
  page.wait_for_timeout(150)
  page.locator('#sq162-pdf-output-name').fill(name)
  page.evaluate('window.__nativeSavedFiles={};window.__nativeNotifiedFiles=[];')
  page.locator('#sq162-trace').click()
  page.wait_for_function("Object.keys(window.__nativeSavedFiles).length>0",timeout=120000)
  saved=page.evaluate('window.__nativeSavedFiles')
  assert list(saved.keys())==[name+'.dxf'],(mode,list(saved))
  item=saved[name+'.dxf']
  assert item['mime']=='application/dxf'
  raw=base64.b64decode(item['base64'])
  out=root/f'V183_{mode.upper()}_V180_COMPAT.dxf';out.write_bytes(raw)
  rawtxt=raw.decode('cp1252',errors='replace')
  assert '\nIMAGE\n' not in rawtxt and '\nIMAGEDEF\n' not in rawtxt and '\nOLE2FRAME\n' not in rawtxt
  doc,rec=ezdxf.recover.readfile(out); audit=doc.audit(); m=doc.modelspace()
  assert len(m.query('POLYLINE'))+len(m.query('LWPOLYLINE'))>0
  assert not audit.errors and not audit.fixes,(mode,audit.errors,audit.fixes)
  notes=page.evaluate('window.__nativeNotifiedFiles')
  assert len(notes)==1 and notes[0]['filename']==name+'.dxf',notes
  status=page.locator('#sq162-raster-status').inner_text()
  assert 'تم حفظ ملف DXF واحد' in status,status
  result.append({'mode':mode,'file':name+'.dxf','bytes':len(raw),'modelspace_entities':len(m),'layers':len(doc.layers),'polylines':len(m.query('POLYLINE')),'lwpolylines':len(m.query('LWPOLYLINE')),'texts':len(m.query('TEXT')),'image':len(m.query('IMAGE')),'audit_errors':len(audit.errors),'audit_fixes':len(audit.fixes),'notifications':len(notes),'status':status[:240]})
 # Check settings card exclusions in actual app view.
 settings=page.evaluate("({orientation:!!document.querySelector('#sqOrientationCard .project-output-settings'),pdf:!!document.querySelector('#sqPdfDxfCard .project-output-settings')})")
 assert settings=={'orientation':False,'pdf':False},settings
 print(json.dumps({'result':'PASS V183 PDF uses one DXF only, compatible with V180, across bundled PDF fixtures','fixtures':result,'project_settings':settings,'page_errors':page_errors[:20]},ensure_ascii=False,indent=2))
 b.close()
