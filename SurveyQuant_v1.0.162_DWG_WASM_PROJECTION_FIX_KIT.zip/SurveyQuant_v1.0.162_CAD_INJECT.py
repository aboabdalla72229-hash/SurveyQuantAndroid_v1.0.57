#!/usr/bin/env python3
"""Inject the offline, free CAD alignment and raster/PDF tracing module."""
from __future__ import annotations
import argparse
import re
from pathlib import Path

MARKER = 'id="sq162-cad-engine"'


def _safe_script(source: str) -> str:
    # A literal closing script tag inside a vendor comment/string must not end
    # the HTML script element prematurely. Escaping the slash preserves JS value.
    return re.sub(r"</script", r"<\\/script", source, flags=re.IGNORECASE)


def _broaden_existing_dxf_accepts(html: str) -> str:
    pattern = re.compile(r"(\baccept\s*=\s*)(['\"])(.*?\.dxf.*?)(\2)", re.IGNORECASE | re.DOTALL)
    def update(match: re.Match[str]) -> str:
        value = match.group(3)
        if re.search(r"\.dwg", value, re.IGNORECASE):
            return match.group(0)
        return match.group(1) + match.group(2) + value + ",.dwg" + match.group(4)
    return pattern.sub(update, html)


def validate(html: str) -> None:
    required = {
        "V160 streaming DXF scanner": "function sqScanProjectionDxf(rawBytes){",
        "V161 shared DWG reader": "window.parseFile = parseFile;",
        "raw-only reference pipeline": "rawOnly:true,conversionOnly:true",
        "V162 engine marker": MARKER,
        "alignment byte transformer": "function transformDxfBytes(rawBytes, sourceA, sourceB, targetA, targetB)",
        "DXF picker extension": ".dwg,.dxf",
        "memory-only CAD state": "لا يُستخدم localStorage أو قاعدة بيانات",
        "free PDF conversion": "pdfjsLib.getDocument",
        "free image tracer": "ImageTracer.imagedataToSVG",
    }
    for label, needle in required.items():
        if needle not in html:
            raise ValueError(f"Validation failed: missing {label} marker ({needle})")
    if html.count(MARKER) != 1:
        raise ValueError("The V162 engine must be injected exactly once")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--html", required=True, type=Path)
    p.add_argument("--core", required=True, type=Path)
    p.add_argument("--imagetracer", required=True, type=Path)
    p.add_argument("--pdfjs", required=True, type=Path)
    p.add_argument("--check-only", action="store_true")
    args = p.parse_args()
    html = args.html.read_text(encoding="utf-8")
    if args.check_only:
        validate(html)
        print("PASS V162 injector check: alignment, shared DWG/DXF raw conversion, raster tracer and PDF.js are embedded exactly once")
        return
    if MARKER in html or "sq162-cad-launch" in html:
        raise SystemExit("V162 CAD tools already appear in index.html; refusing duplicate injection")
    for path in (args.core, args.imagetracer, args.pdfjs):
        if not path.is_file() or path.stat().st_size < 1000:
            raise SystemExit(f"Required offline engine is missing or unexpectedly small: {path}")
    core = args.core.read_text(encoding="utf-8")
    tracer = args.imagetracer.read_text(encoding="utf-8")
    pdfjs = args.pdfjs.read_text(encoding="utf-8")
    if "imagedataToSVG" not in tracer:
        raise SystemExit("The downloaded ImageTracer package does not expose imagedataToSVG")
    if "getDocument" not in pdfjs or "pdfjsLib" not in pdfjs:
        raise SystemExit("The downloaded PDF.js package is not the expected browser build")
    html = _broaden_existing_dxf_accepts(html)
    script_block = (
        "\n<!-- SurveyQuant v1.0.162: offline open-source CAD engines -->\n"
        "<script id=\"sq162-pdfjs\">\n" + _safe_script(pdfjs) + "\n</script>\n"
        "<script id=\"sq162-imagetracer\">\n" + _safe_script(tracer) + "\n</script>\n"
        "<script id=\"sq162-cad-engine\">\n" + _safe_script(core) + "\n</script>\n"
    )
    match = list(re.finditer(r"</body\s*>", html, re.IGNORECASE))
    if match:
        m = match[-1]
        html = html[:m.start()] + script_block + html[m.start():]
    else:
        html += script_block
    validate(html)
    args.html.write_text(html, encoding="utf-8")
    print(f"PASS V162 injection: embedded open-source offline modules into {args.html} ({len(html):,} characters)")

if __name__ == "__main__":
    main()
