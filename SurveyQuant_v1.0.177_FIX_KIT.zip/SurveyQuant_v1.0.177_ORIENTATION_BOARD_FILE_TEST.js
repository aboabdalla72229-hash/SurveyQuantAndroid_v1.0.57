'use strict';
const assert=require('node:assert/strict');
const cad=require('./SurveyQuant_v1.0.177_CAD_ENGINE.js');
const sourceA={x:383995.47801163,y:-138432.85511527};
const sourceB={x:489342.02127187,y:-112468.0996298};
const dx=sourceB.x-sourceA.x,dy=sourceB.y-sourceA.y;
const targetA={x:583995.47801163,y:-238432.85511527};
const targetB={x:targetA.x-dy,y:targetA.y+dx};
const height=1;
const makeBoard=(a,b,aci)=>cad.polylinesToDxf([{points:[{x:a.x,y:height-a.y},{x:b.x,y:height-b.y}],closed:false,aci}],1,height,1).bytes;
const sourceBytes=makeBoard(sourceA,sourceB,1),targetBytes=makeBoard(targetA,targetB,5);
const source=cad.readGeometry(sourceBytes),target=cad.readGeometry(targetBytes);
assert.equal(source.segments.length,1);assert.equal(target.segments.length,1);
const picked=[source.segments[0].a,source.segments[0].b,target.segments[0].a,target.segments[0].b];
assert.ok(Math.hypot(picked[0].x-picked[2].x,picked[0].y-picked[2].y)>1000,'first source and reference points must differ');
assert.ok(Math.hypot(picked[1].x-picked[3].x,picked[1].y-picked[3].y)>1000,'second source and reference points must differ');
const diag=cad.alignmentDiagnostics(picked);
assert.ok(Math.abs(diag.rotationDegrees-90)<1e-7,`expected +90 degrees, got ${diag.rotationDegrees}`);
assert.ok(Math.abs(diag.scale-1)<1e-10);
assert.ok(Math.hypot(diag.translationX,diag.translationY)>1000);
const out=cad.createOrientedDxfBytes(sourceBytes,picked);
const oriented=cad.readGeometry(out.bytes);
assert.equal(oriented.segments.length,1);
const expected=target.segments[0];
for(const [actual,want] of [[oriented.segments[0].a,expected.a],[oriented.segments[0].b,expected.b]]){
 assert.ok(Math.hypot(actual.x-want.x,actual.y-want.y)<1e-5,`output does not coincide with reference: ${JSON.stringify({actual,want})}`);
}
if(process.argv[2])require('node:fs').writeFileSync(process.argv[2],Buffer.from(out.bytes));
console.log(JSON.stringify({sourceFileExtents:{minX:source.minX,maxX:source.maxX,minY:source.minY,maxY:source.maxY},referenceFileExtents:{minX:target.minX,maxX:target.maxX,minY:target.minY,maxY:target.maxY},sourcePoint1:picked[0],referencePoint1:picked[2],sourcePoint2:picked[1],referencePoint2:picked[3],rotationDegrees:diag.rotationDegrees,scale:diag.scale,translation:{x:diag.translationX,y:diag.translationY},orientedOutputMatchesReference:true,result:'PASS'},null,2));
