'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');

function crc32(buf){let c=0xffffffff;for(const b of buf){c^=b;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;}
function zipStore(entries){
 const locals=[],centrals=[];let offset=0;
 const u16=n=>{const b=Buffer.alloc(2);b.writeUInt16LE(n);return b;};
 const u32=n=>{const b=Buffer.alloc(4);b.writeUInt32LE(n>>>0);return b;};
 for(const e of entries){const name=Buffer.from(e.name,'utf8'),data=Buffer.from(e.data),crc=crc32(data);
  const local=Buffer.concat([u32(0x04034b50),u16(20),u16(0x0800),u16(0),u16(0),u16(33),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),name,data]);
  const central=Buffer.concat([u32(0x02014b50),u16(20),u16(20),u16(0x0800),u16(0),u16(0),u16(33),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),name]);
  locals.push(local);centrals.push(central);offset+=local.length;
 }
 const localBytes=Buffer.concat(locals),centralBytes=Buffer.concat(centrals);
 return new Uint8Array(Buffer.concat([localBytes,centralBytes,u32(0x06054b50),u16(0),u16(0),u16(entries.length),u16(entries.length),u32(centralBytes.length),u32(localBytes.length),u16(0)]));
}
const jpegPath=path.join(__dirname,'V177_TEST_PIXEL.jpg');
assert.ok(fs.existsSync(jpegPath),'valid JPEG fixture must be present');
const jpeg=fs.readFileSync(jpegPath),drawnTexts=[];
const fakeContext={fillRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fillText(t){drawnTexts.push(String(t));}};
const fakeDocument={readyState:'loading',addEventListener(){},getElementById(){return null;},createElement(tag){if(tag!=='canvas')throw new Error('Unexpected element '+tag);return{width:0,height:0,getContext(){return fakeContext;},toDataURL(){return 'data:image/jpeg;base64,'+jpeg.toString('base64');}};}};
const window={document:fakeDocument,SurveyQuantCAD162:{zipStore},setInterval,clearInterval,addEventListener(){},atob:global.atob};
const context={window,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,Math,Number,String,Map,Set,Promise,console,atob:global.atob};
vm.createContext(context);
const modulePath=process.argv[2]||path.join(__dirname,'SurveyQuant_v1.0.177_SINGLE_CANVAS_DATA_EXPORT_MODULE.js');
vm.runInContext(fs.readFileSync(modulePath,'utf8'),context,{filename:modulePath});
const core=window.SurveyQuantV177AddendumCore;
assert.ok(core,'pure addendum helpers must be exposed for tests');
const samples=[
 {id:'P0001',easting:576761.446,northing:858279.357,elevation:12.345},
 {id:'P0002',easting:576765.125,northing:858284.875,elevation:13.25}
];
const picks=[{x:10,y:20},{x:110,y:20},{x:1000,y:2000},{x:1000,y:2200}];
const kept=core.syntheticPicks(picks),scaled=core.alignment(picks);
assert.equal(scaled.scale,2,'scale must be derived automatically as reference distance / source distance');
assert.ok(Math.abs(scaled.rotationDegrees-90)<1e-9,'source baseline must rotate to reference bearing');
assert.ok(Math.abs(scaled.apply({x:10,y:20}).x-1000)<1e-8&&Math.abs(scaled.apply({x:10,y:20}).y-2000)<1e-8,'first reference point must map exactly');
assert.ok(Math.abs(scaled.apply({x:110,y:20}).x-1000)<1e-8&&Math.abs(scaled.apply({x:110,y:20}).y-2200)<1e-8,'second reference point must map exactly after automatic scale');
assert.equal(kept[3].x,1000,'point pair must not be altered to force a unit scale');
assert.equal(kept[3].y,2200,'reference pick coordinates must be retained unchanged');
assert.ok(Math.abs(scaled.secondResidual)<1e-8,'automatic reference scale must close the second-point residual');
const side=core.sideBySideOffset({minX:0,minY:0,maxX:10,maxY:10},{minX:100,minY:0,maxX:110,maxY:10});
assert.ok(5+side.x-105>10,'unoriented board must be previewed beside the reference with a visible gap');
// Exercise the same pointer controller used by both real canvases.
class FakeCanvas {
 constructor(){this.dataset={};this.style={};this.listeners={};this.rect={left:0,top:0,width:200,height:200};this._ctx={save(){},restore(){},setLineDash(){},fillRect(){},strokeRect(){}};}
 addEventListener(name,fn){(this.listeners[name] ||= []).push(fn);}
 fire(name,event){for(const fn of this.listeners[name]||[])fn({...event,preventDefault(){}});}
 getBoundingClientRect(){return this.rect;}
 getContext(){return this._ctx;}
 setPointerCapture(){}
 releasePointerCapture(){}
}
const canvas=new FakeCanvas(),view={zoom:1,cx:100,cy:100,panX:0,panY:0};
const tapped=[],windows=[];let currentMode='pan';
function redraw(){canvas._sq177Map={baseScale:1,scale:view.zoom,fromScreen:p=>({x:view.cx+(p.x-100-view.panX)/view.zoom,y:view.cy-(p.y-100-view.panY)/view.zoom})};}
redraw();
assert.equal(core.attachCanvasGestures(canvas,{viewGetter:()=>view,draw:redraw,kind:'data',getMode:()=>currentMode,onTap:(x,y)=>tapped.push([x,y]),onWindow:(a,b)=>windows.push([a,b])}),true);
const pointer=(id,x,y)=>({pointerId:id,button:0,clientX:x,clientY:y});
canvas.fire('pointerdown',pointer(1,60,100));canvas.fire('pointerdown',pointer(2,140,100));canvas.fire('pointermove',pointer(2,180,100));
assert.ok(Math.abs(view.zoom-1.5)<1e-9,'two-finger pinch must zoom in');
assert.ok(Math.abs((view.cx+(120-100-view.panX)/view.zoom)-100)<1e-8,'pinch midpoint must remain anchored to the same world X');
canvas.fire('pointerup',pointer(1,60,100));canvas.fire('pointerup',pointer(2,180,100));
const oldPanX=view.panX,oldPanY=view.panY;
canvas.fire('pointerdown',pointer(3,40,40));canvas.fire('pointermove',pointer(3,65,72));canvas.fire('pointerup',pointer(3,65,72));
assert.ok(Math.abs(view.panX-oldPanX-25)<1e-9&&Math.abs(view.panY-oldPanY-32)<1e-9,'single-finger drag must pan the canvas');
currentMode='window';canvas.fire('pointerdown',pointer(4,30,40));canvas.fire('pointermove',pointer(4,90,110));canvas.fire('pointerup',pointer(4,90,110));
assert.equal(windows.length,1,'window mode drag must issue a selection rectangle');
assert.ok(windows[0][1].x>windows[0][0].x&&windows[0][1].y<windows[0][0].y,'window corners must be translated through the CAD coordinate map');
currentMode='select';canvas.fire('pointerdown',pointer(5,75,88));canvas.fire('pointerup',pointer(5,75,88));
assert.equal(tapped.length,1,'single-finger tap in entity-select mode must invoke hit selection');
// The orientation controller uses the same gesture engine; one-finger taps select points, drags pan.
const oriCanvas=new FakeCanvas(),oriView={zoom:1,cx:100,cy:100,panX:0,panY:0},oriTaps=[];
function redrawOri(){oriCanvas._sq177Map={baseScale:1,scale:oriView.zoom,fromScreen:p=>({x:oriView.cx+(p.x-100-oriView.panX)/oriView.zoom,y:oriView.cy-(p.y-100-oriView.panY)/oriView.zoom})};}
redrawOri();
assert.equal(core.attachCanvasGestures(oriCanvas,{viewGetter:()=>oriView,draw:redrawOri,kind:'ori',onTap:(x,y)=>oriTaps.push([x,y])}),true);
oriCanvas.fire('pointerdown',pointer(6,50,100));oriCanvas.fire('pointerdown',pointer(7,150,100));oriCanvas.fire('pointermove',pointer(7,190,100));
assert.ok(Math.abs(oriView.zoom-1.4)<1e-9,'orientation project must support two-finger pinch zoom');
oriCanvas.fire('pointerup',pointer(6,50,100));oriCanvas.fire('pointerup',pointer(7,190,100));
const oriPan=oriView.panX;oriCanvas.fire('pointerdown',pointer(8,40,50));oriCanvas.fire('pointermove',pointer(8,55,65));oriCanvas.fire('pointerup',pointer(8,55,65));
assert.ok(Math.abs(oriView.panX-oriPan-15)<1e-9,'orientation project must support one-finger canvas panning');
oriCanvas.fire('pointerdown',pointer(9,33,44));oriCanvas.fire('pointerup',pointer(9,33,44));
assert.deepEqual(oriTaps,[[33,44]],'orientation tap must invoke point-pick callback; pinch/pan must not pick accidental points');

const csv=core.csvText(samples),txt=core.txtText(samples),sdr=core.sdrText(samples);
assert.match(csv,/"ID","Easting","Northing","Elevation"/);
assert.match(csv,/576761\.446/);assert.match(csv,/858279\.357/);
assert.match(txt,/P0001\t576761\.446\t858279\.357\t12\.345/);
assert.match(sdr,/08TP,P0001,576761\.446,858279\.357,12\.345/);
const xlsx=core.makeXlsx(samples);assert.ok(xlsx instanceof Uint8Array&&xlsx.length>100,'Excel generator must return ZIP bytes');
const pdf=core.makePdf(samples);assert.ok(pdf instanceof Uint8Array&&pdf.length>100,'point-list PDF must return bytes');assert.ok(drawnTexts.includes('مكتب فني مساحة | كشف النقاط'),'Arabic report title must be drawn by the PDF canvas');
const geom={segments:[{a:{x:0,y:0},b:{x:10,y:0},color:'#f00'}],curves:[{points:[{x:0,y:2},{x:10,y:2}]}],texts:[{position:{x:5,y:5},text:'TEST'}]};
const entities=core.entityList(geom);assert.equal(entities.length,3,'line, curve and text entities must be individually selectable');
assert.equal(core.entityDistance({x:5,y:1},{kind:'segments',index:0,item:geom.segments[0]}),1,'line hit-testing distance must be accurate');
assert.equal(core.entityDistance({x:5,y:4},{kind:'texts',index:0,item:geom.texts[0]}),1,'text hit-testing distance must be accurate');
assert.equal(core.entityKey(entities[1]),'curves:0','entity identity must remain stable by type and index');
const dxf=core.annotationDxf(samples);const dxfText=new TextDecoder().decode(dxf);
assert.match(dxfText,/\$ACADVER\n1\nAC1009/);assert.match(dxfText,/SURVEY_POINTS/);assert.match(dxfText,/SURVEY_LABELS/);assert.match(dxfText,/576761\.446/);
const outDir=process.argv[3]||__dirname;fs.mkdirSync(outDir,{recursive:true});
fs.writeFileSync(path.join(outDir,'V177_TEST_POINTS.xlsx'),Buffer.from(xlsx));
fs.writeFileSync(path.join(outDir,'V177_TEST_POINTS.pdf'),Buffer.from(pdf));
fs.writeFileSync(path.join(outDir,'V177_TEST_POINTS_ANNOTATION.dxf'),Buffer.from(dxf));
console.log(JSON.stringify({
 referenceScale:{formula:'referenceLength/sourceLength',scale:scaled.scale,rotationDegrees:scaled.rotationDegrees,firstAndSecondPicksMapped:true,secondPointResidual:scaled.secondResidual},
 touchGestures:{dataPinchZoom:1.5,orientationPinchZoom:1.4,singleFingerPan:true,orientationPan:true,windowSelection:true,entityTap:true,orientationPointTap:true},
 sideBySidePreview:{gapMoreThanBoardSpan:true},
 pointExports:{csvRows:samples.length,txtRows:samples.length,sdrRows:samples.length,xlsxBytes:xlsx.length,pdfBytes:pdf.length,pdfRenderedTexts:drawnTexts.length,dxfBytes:dxf.length},
 entitySelection:{entities:entities.length,lineHitDistance:1,textHitDistance:1,stableKey:core.entityKey(entities[1])},axisOrder:'X=Easting,Y=Northing',result:'PASS'
},null,2));
