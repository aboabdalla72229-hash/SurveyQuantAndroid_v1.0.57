# SurveyQuant V1.0.148 automated test results

All results below were executed against the final HTML produced by the same staged patch sequence used by the GitHub workflow: V146 source artifact -> V147 root-cause patcher -> V148 alignment/DWG patcher.

- PASS: 10 inline JavaScript blocks parse with `node --check`.
- PASS: two-point similarity mapping has residual1/residual2 within tolerance, with no coordinate clamp or axis swap.
- PASS: DXF DIMENSION points at WCS groups 10/13/14/15 and OCS groups 11/12/16 are transformed separately.
- PASS: IMAGE and WIPEOUT WCS insertion points/axes transform; pixel sizes and clipping vertices remain local.
- PASS: orientation DWG bridge calls the packaged WASM path resolver and validates DXF output structure using a stub converter.
- PASS: orientation viewport checks for 44vh / 250-500px.
- PASS: inherited V130 DWG/orientation suite.
- PASS: 3D/OCS coordinate transforms, nested axis labels, MLEADER entity counts and vectors.
- PASS: HATCH edge-aware output, concrete boundary recovery from four LINEs and rotated/scaled INSERTs.
- PASS: 24,000 DXF entities retained after transformation.
- PASS: real DXF MULTILEADER result matches the ezdxf 1.4.4 reference transform.

Not executed: production run on the user's own DWG/reference drawing; GitHub Actions Android signing/build. The DWG regression test verifies the converter path with a controlled stub, not a proprietary/production DWG sample.
