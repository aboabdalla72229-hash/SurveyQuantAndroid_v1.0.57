#!/usr/bin/env python3
"""V136: detect CAD-board inputs across existing and dynamically-created projects.

Patches only the shared V117/V126 DWG picker gate in HTML, or the same asset in an APK.
The gate expands accepted file types and leaves selected DWG files to the app's existing
native project handler. It neither rewrites the source DWG nor redraws/replaces entities.
The orientation project's independent temporary conversion behavior remains untouched.
"""
from __future__ import annotations

import argparse
import copy
import re
import struct
import sys
import zipfile
from pathlib import Path

BRIDGE_ID = "sq-v117-universal-dwg-bridge"
MARKER = "SQ_V136_UNIVERSAL_CAD_INPUT_GATE"
TARGET_APP_VERSION_CODE = 136
TARGET_APP_VERSION_NAME = "1.0.136"
OLD_APP_VERSION_NAME = "1.0.126"

NEW_FUNCTION = r'''  function isCadInput(input) {
    /* SQ_V136_UNIVERSAL_CAD_INPUT_GATE
       Detect CAD-board inputs from file type, control identity, and nearby project labels.
       This includes file controls created after startup by separate project screens. */
    if (!input || String(input.tagName || '').toLowerCase() !== 'input' ||
        String(input.type || '').toLowerCase() !== 'file') return false;

    var id = String(input.id || '');
    var name = String(input.name || '');
    if (NON_CAD_DATA_IDS.has(id)) return false;
    if (CAD_INPUT_IDS.has(id)) return true;

    var accept = String(input.accept || '').split(',').map(function (item) {
      return item.trim().toLowerCase();
    }).filter(Boolean);
    var explicitCad = accept.some(function (item) {
      return item === '.dwg' || item === '.dxf' ||
        item === 'application/dwg' || item === 'application/x-dwg' ||
        item === 'application/dxf' || item === 'application/x-dxf' ||
        item === 'application/acad' || item === 'application/x-acad' ||
        item === 'image/vnd.dwg';
    });
    if (explicitCad) return true;

    var hints = [id, name, input.title || '', input.placeholder || ''];
    if (typeof input.getAttribute === 'function') {
      ['aria-label', 'data-project', 'data-role', 'data-import-kind', 'title', 'placeholder'].forEach(function (key) {
        var value = input.getAttribute(key);
        if (value) hints.push(value);
      });
    }
    try {
      Array.prototype.slice.call(input.labels || []).forEach(function (label) {
        if (label && label.textContent) hints.push(label.textContent);
      });
    } catch (_) {}
    try {
      var node = input.parentElement;
      for (var depth = 0; node && depth < 4; depth++, node = node.parentElement) {
        if (node.textContent) hints.push(String(node.textContent).slice(0, 320));
        if (node.tagName && String(node.tagName).toLowerCase() === 'body') break;
      }
    } catch (_) {}

    var context = hints.join(' ').toLowerCase().replace(/\s+/g, ' ');
    var mediaOrPointType = accept.some(function (item) {
      return /^(?:\.sdr|\.pnt|\.pt|\.csv|\.txt|\.dat|\.pdf|\.png|\.jpe?g|\.webp|\.bmp|\.gif|\.heic|\.tiff?|\.xlsx?|\.ods|\.json|\.kml|\.kmz|\.gpx|text\/plain|text\/csv|application\/pdf|image\/)/i.test(item);
    });
    var hasGenericType = accept.some(function (item) {
      return item === '*/*' || item === 'application/octet-stream';
    });
    var pointOrMediaHint = /(?:\b(?:point[\s_-]*list|point[\s_-]*file|survey[\s_-]*points|file[\s_-]*to[\s_-]*dxf|clean[\s_-]*files|clean[\s_-]*points|image|photo|picture|raster|pdf|spreadsheet|excel)\b)|(?:قائمة\s*نقاط|نقاط\s*(?:المساحة|الرفع|الإحداثيات)|ملف\s*نقاط|تنظيف\s*الملفات|صورة|صور|ملف\s*PDF)/i.test(context);
    if (pointOrMediaHint || (mediaOrPointType && !hasGenericType)) return false;

    var strongCadHint = /(?:\b(?:cad|dwg|dxf|drawing|board|blueprint|plan|projection|overlay|merge|orientation|section|concrete|quantity|grading|reference[\s_-]*board|target[\s_-]*board|source[\s_-]*board|import[\s_-]*drawing)\b)|(?:لوح|لوحة|رسم|اسقاط|إسقاط|توجيه|دمج|حصر|خرسانة|كميات|قطاع|القطاع|مرجع\s*اللوح|لوحة\s*المرجع|لوحة\s*الهدف|لوحة\s*المصدر)/i.test(context);
    if (strongCadHint) return true;

    /* Generic */
    return false;
  }'''


def replace_bridge_function(html: str) -> str:
    tag = re.compile(
        r'(<script\s+id=["\']' + re.escape(BRIDGE_ID) + r'["\']\s*>)([\s\S]*?)(</script\s*>)',
        re.I,
    )
    matches = list(tag.finditer(html))
    if len(matches) != 1:
        raise SystemExit(f"ERROR V136: expected one embedded {BRIDGE_ID} script; found {len(matches)}.")
    match = matches[0]
    bridge = match.group(2)
    function_re = re.compile(
        r"(?m)^  function isCadInput\(input\) \{[\s\S]*?^  \}\n[ \t]*\n?  function addAcceptedTypes",
        re.M,
    )
    found = list(function_re.finditer(bridge))
    if len(found) != 1:
        raise SystemExit(f"ERROR V136: expected one isCadInput function; found {len(found)}. Apply V126 first.")
    replacement = NEW_FUNCTION + "\n\n  function addAcceptedTypes"
    patched_bridge = function_re.sub(lambda _m: replacement, bridge, count=1)
    if patched_bridge.count(MARKER) != 1:
        raise SystemExit("ERROR V136: universal CAD input marker was not inserted exactly once.")
    if "var CAD_INPUT_IDS = new Set([" not in patched_bridge or \
       "var NON_CAD_DATA_IDS = new Set(['fileToDxfInput', 'cleanFilesInput']);" not in patched_bridge:
        raise SystemExit("ERROR V136: V126 file input allow/deny lists changed unexpectedly.")
    if "if (!isCadInput(input)) return;" not in patched_bridge:
        raise SystemExit("ERROR V136: shared accepted-types handler no longer uses isCadInput.")
    result = html[:match.start(2)] + "\n" + patched_bridge.rstrip() + "\n" + html[match.end(2):]
    if result.count(MARKER) != 1 or result.count('id="' + BRIDGE_ID + '"') != 1:
        raise SystemExit("ERROR V136: final HTML has missing or duplicate bridge code.")

    # Android file-origin WebView can fail when Emscripten fetches a relative WASM URL.
    # Resolve from document.baseURI so file:///android_asset/... reaches Emscripten's XHR branch.
    wasm_helper = r'''function sqDwgWasmRuntimePath() {
try {
  return new URL('./libredwg-writer/wasm/', document.baseURI).href.replace(/\/$/, '');
} catch (_) {
  return './libredwg-writer/wasm';
}
}'''
    if "function sqDwgWasmRuntimePath()" not in result:
        wasm_anchor = "const SQ_WRITER_WASM_URL='./libredwg-writer/wasm/libredwg-web.js';"
        if result.count(wasm_anchor) != 1:
            raise SystemExit("ERROR V136: could not locate unique local DWG WASM loader anchor.")
        result = result.replace(wasm_anchor, wasm_anchor + "\n" + wasm_helper, 1)
    relative_create = "LibreDwg.create('./libredwg-writer/wasm')"
    if result.count(relative_create) != 2:
        raise SystemExit(f"ERROR V136: expected two DWG conversion entry points using relative WASM path; found {result.count(relative_create)}.")
    result = result.replace(relative_create, "LibreDwg.create(sqDwgWasmRuntimePath())")
    if result.count("LibreDwg.create(sqDwgWasmRuntimePath())") != 2:
        raise SystemExit("ERROR V136: both DWG conversion entry points did not switch to corrected WASM path.")
    if "new URL('./libredwg-writer/wasm/', document.baseURI)" not in result:
        raise SystemExit("ERROR V136: absolute WASM runtime URL is missing.")

    # Keep app-side update checks aligned with the APK's Android package version.
    version_re = re.compile(r"(?m)(const\s+SQ_APP_VERSION_CODE\s*=\s*)(126|135|136)(\s*;)")
    version_matches = list(version_re.finditer(result))
    if len(version_matches) != 1:
        raise SystemExit(f"ERROR V136: expected one SQ_APP_VERSION_CODE value (126/135); found {len(version_matches)}.")
    version_match = version_matches[0]
    result = result[:version_match.start()] + version_match.group(1) + "136" + version_match.group(3) + result[version_match.end():]
    if "function universalTransformBytes(input,t)" not in result or "dwg_write_dxf(bytes.buffer)" not in result:
        raise SystemExit("ERROR V136: byte-preserving CAD transform or existing DWG writer is missing.")
    return result


def patch_html(path: Path) -> None:
    original = path.read_text(encoding="utf-8")
    updated = replace_bridge_function(original)
    path.write_text(updated, encoding="utf-8")
    print("PASS V136: all CAD-board pickers are detected by input type or board/project context.")
    print("PASS V136: point-list-only and photo/PDF-only controls remain excluded.")
    print("PASS V136: V117 converter and original orientation/geometry code outside the bridge are unchanged.")


def _read_len8(data: bytes, pos: int) -> tuple[int, int]:
    first = data[pos]
    if first & 0x80:
        return (((first & 0x7F) << 8) | data[pos + 1]), pos + 2
    return first, pos + 1


def _read_len16(data: bytes, pos: int) -> tuple[int, int]:
    first = struct.unpack_from("<H", data, pos)[0]
    if first & 0x8000:
        second = struct.unpack_from("<H", data, pos + 2)[0]
        return (((first & 0x7FFF) << 16) | second), pos + 4
    return first, pos + 2


def _string_pool(data: bytes, chunk_start: int, chunk_size: int, header_size: int) -> tuple[list[str], list[tuple[int, int, bool]]]:
    if header_size < 28 or chunk_start + chunk_size > len(data):
        raise ValueError("invalid Android binary XML string pool")
    string_count, _style_count, flags, strings_start, _styles_start = struct.unpack_from("<IIIII", data, chunk_start + 8)
    if string_count > 100_000:
        raise ValueError("unreasonable Android XML string count")
    offsets_start = chunk_start + header_size
    strings_base = chunk_start + strings_start
    utf8 = bool(flags & 0x100)
    strings: list[str] = []
    spans: list[tuple[int, int, bool]] = []
    for index in range(string_count):
        rel = struct.unpack_from("<I", data, offsets_start + index * 4)[0]
        p = strings_base + rel
        if utf8:
            _u16_len, p = _read_len8(data, p)
            byte_len, p = _read_len8(data, p)
            begin = p
            end = begin + byte_len
            strings.append(data[begin:end].decode("utf-8", errors="strict"))
            spans.append((begin, end, True))
        else:
            char_len, p = _read_len16(data, p)
            begin = p
            end = begin + char_len * 2
            strings.append(data[begin:end].decode("utf-16le", errors="strict"))
            spans.append((begin, end, False))
    return strings, spans


def patch_binary_manifest(manifest: bytes, version_code: int = TARGET_APP_VERSION_CODE,
                          version_name: str = TARGET_APP_VERSION_NAME) -> bytes:
    if len(manifest) < 8 or struct.unpack_from("<H", manifest, 0)[0] != 0x0003:
        raise ValueError("AndroidManifest.xml is not Android binary XML")
    result = bytearray(manifest)
    pos = struct.unpack_from("<H", result, 2)[0]
    total_size = struct.unpack_from("<I", result, 4)[0]
    if total_size > len(result) or total_size < pos:
        raise ValueError("invalid Android binary XML size")
    strings: list[str] | None = None
    spans: list[tuple[int, int, bool]] = []
    pool_info: tuple[int, int, int] | None = None
    chunks = []
    while pos < total_size:
        if pos + 8 > total_size:
            raise ValueError("truncated Android XML chunk header")
        chunk_type, header_size, chunk_size = struct.unpack_from("<HHI", result, pos)
        if chunk_size < header_size or pos + chunk_size > total_size:
            raise ValueError("invalid Android XML chunk bounds")
        chunks.append((pos, chunk_type, header_size, chunk_size))
        if chunk_type == 0x0001:
            strings, spans = _string_pool(bytes(result), pos, chunk_size, header_size)
            pool_info = (pos, chunk_size, header_size)
        pos += chunk_size
    if strings is None or pool_info is None:
        raise ValueError("Android XML string pool not found")

    # versionName string is same length (1.0.126 -> 1.0.136), so pool offsets stay valid.
    old_names = [i for i, value in enumerate(strings) if value == OLD_APP_VERSION_NAME]
    if not old_names and version_name not in strings:
        raise ValueError(f"Android manifest string pool has neither {OLD_APP_VERSION_NAME!r} nor {version_name!r}")
    for idx in old_names:
        begin, end, is_utf8 = spans[idx]
        encoded = version_name.encode("utf-8") if is_utf8 else version_name.encode("utf-16le")
        if len(encoded) != end - begin:
            raise ValueError("versionName replacement changes string-pool byte length")
        result[begin:end] = encoded
        strings[idx] = version_name

    # Locate the manifest root's android:versionCode typed value and replace its integer.
    version_fields = []
    for chunk_pos, chunk_type, header_size, chunk_size in chunks:
        if chunk_type != 0x0102 or chunk_size < 36:
            continue
        node_name_idx = struct.unpack_from("<I", result, chunk_pos + 20)[0]
        if node_name_idx >= len(strings) or strings[node_name_idx] != "manifest":
            continue
        attr_start = struct.unpack_from("<H", result, chunk_pos + 24)[0]
        attr_size = struct.unpack_from("<H", result, chunk_pos + 26)[0]
        attr_count = struct.unpack_from("<H", result, chunk_pos + 28)[0]
        if attr_size < 20 or attr_count > 1024:
            raise ValueError("invalid manifest attribute table")
        first_attr = chunk_pos + 16 + attr_start
        for n in range(attr_count):
            at = first_attr + n * attr_size
            name_idx = struct.unpack_from("<I", result, at + 4)[0]
            if name_idx >= len(strings) or strings[name_idx] != "versionCode":
                continue
            value_size = struct.unpack_from("<H", result, at + 12)[0]
            value_type = result[at + 15]
            if value_size < 8 or value_type not in (0x10, 0x11):
                raise ValueError("manifest versionCode is not a typed integer")
            version_fields.append(at + 16)
    if len(version_fields) != 1:
        raise ValueError(f"expected exactly one manifest versionCode field, found {len(version_fields)}")
    struct.pack_into("<I", result, version_fields[0], version_code)
    return bytes(result)


def patch_apk(input_apk: Path, output_apk: Path) -> None:
    if not input_apk.is_file() or input_apk.stat().st_size == 0:
        raise SystemExit("ERROR V136: input APK is missing or empty.")
    if input_apk.resolve() == output_apk.resolve():
        raise SystemExit("ERROR V136: output APK must differ from input APK.")
    output_apk.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(input_apk, "r") as zin:
        names = [info.filename for info in zin.infolist()]
        if names.count("assets/index.html") != 1:
            raise SystemExit("ERROR V136: input APK must contain exactly one assets/index.html.")
        if names.count("AndroidManifest.xml") != 1:
            raise SystemExit("ERROR V136: input APK must contain exactly one AndroidManifest.xml.")
        seen = set()
        with zipfile.ZipFile(output_apk, "w", allowZip64=True) as zout:
            for info in zin.infolist():
                name = info.filename
                if name in seen:
                    raise SystemExit("ERROR V136: duplicate APK ZIP entry: " + name)
                seen.add(name)
                upper = name.upper()
                if upper.startswith("META-INF/") and (
                    upper.endswith(".SF") or upper.endswith(".RSA") or upper.endswith(".DSA") or
                    upper.endswith(".EC") or upper.endswith("MANIFEST.MF")
                ):
                    continue
                data = zin.read(name)
                if name == "assets/index.html":
                    html = data.decode("utf-8")
                    data = replace_bridge_function(html).encode("utf-8")
                elif name == "AndroidManifest.xml":
                    data = patch_binary_manifest(data)
                clone = copy.copy(info)
                # The destination zip must not retain the old APK's data descriptors or signatures.
                zout.writestr(clone, data)
    with zipfile.ZipFile(output_apk, "r") as check:
        html = check.read("assets/index.html").decode("utf-8")
        manifest = check.read("AndroidManifest.xml")
        if html.count(MARKER) != 1:
            raise SystemExit("ERROR V136: APK output is missing the V136 HTML gate.")
        patch_binary_manifest(manifest)  # validates the resulting manifest can be safely updated again
        if "assets/libredwg-writer/wasm/libredwg-web.wasm" not in check.namelist():
            raise SystemExit("ERROR V136: APK output lost the local DWG WebAssembly engine.")
    print("PASS V136: shared DWG picker gate patched in APK assets; package version raised to 1.0.136/136.")
    print("PASS V136: source DWG is not written over; app's local DWG/DXF engine and all unrelated assets are retained.")


def _make_axml_test_fixture() -> bytes:
    """Build a small valid-enough binary XML manifest for the self-test."""
    strings = ["manifest", "versionCode", "versionName", OLD_APP_VERSION_NAME]
    enc_strings = []
    offsets = []
    for s in strings:
        raw = s.encode("utf-8")
        encoded = bytes([len(s), len(raw)]) + raw + b"\0"
        offsets.append(sum(len(item) for item in enc_strings))
        enc_strings.append(encoded)
    data_strings = b"".join(enc_strings)
    pool_header_size = 28
    offsets_bytes = b"".join(struct.pack("<I", off) for off in offsets)
    strings_start = pool_header_size + len(offsets_bytes)
    pool_size = strings_start + len(data_strings)
    pool = struct.pack("<HHI", 0x0001, pool_header_size, pool_size)
    pool += struct.pack("<IIIII", len(strings), 0, 0x100, strings_start, 0)
    pool += offsets_bytes + data_strings

    # Attributes follow the ResXMLTree_attrExt (20 bytes). Each attribute is 20 bytes.
    node_header = struct.pack("<HHIII", 0x0102, 16, 16 + 20 + 40, 1, 0xFFFFFFFF)
    attr_ext = struct.pack("<IIHHHHHH", 0xFFFFFFFF, 0, 20, 20, 2, 0, 0, 0)
    # Namespace, name index, rawValue index, typedValue.size, res0, type, data.
    attr_code = struct.pack("<IIIHBBI", 0xFFFFFFFF, 1, 0xFFFFFFFF, 8, 0, 0x10, 126)
    attr_name = struct.pack("<IIIHBBI", 0xFFFFFFFF, 2, 3, 8, 0, 0x03, 3)
    start_element = node_header + attr_ext + attr_code + attr_name
    end_element = struct.pack("<HHIIIII", 0x0103, 16, 24, 1, 0xFFFFFFFF, 0xFFFFFFFF, 0)  # element name index 0
    size = 8 + len(pool) + len(start_element) + len(end_element)
    xml_header = struct.pack("<HHI", 0x0003, 8, size)
    return xml_header + pool + start_element + end_element


def self_test() -> None:
    fixture = _make_axml_test_fixture()
    result = patch_binary_manifest(fixture)
    again = patch_binary_manifest(result)
    if len(fixture) != len(result) or len(result) != len(again):
        raise SystemExit("FAIL V136 self-test: manifest patch changed binary XML length")
    # Root versionCode is the final typed data word in the first attribute.
    chunks = []
    pos = 8
    while pos < len(result):
        typ, hdr, size = struct.unpack_from("<HHI", result, pos)
        chunks.append((pos, typ, hdr, size))
        pos += size
    strings_chunk = next(p for p, typ, _, _ in chunks if typ == 0x0001)
    strings, _spans = _string_pool(result, strings_chunk, struct.unpack_from("<I", result, strings_chunk + 4)[0], 28)
    if TARGET_APP_VERSION_NAME not in strings:
        raise SystemExit("FAIL V136 self-test: versionName was not updated")
    code_chunk = next(p for p, typ, _, _ in chunks if typ == 0x0102)
    attr_start = struct.unpack_from("<H", result, code_chunk + 24)[0]
    attr0 = code_chunk + 16 + attr_start
    actual = struct.unpack_from("<I", result, attr0 + 16)[0]
    if actual != TARGET_APP_VERSION_CODE:
        raise SystemExit(f"FAIL V136 self-test: versionCode={actual}, expected {TARGET_APP_VERSION_CODE}")
    print("PASS V136 self-test: binary Android manifest is version-bumped in place with offsets preserved.")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--html", type=Path)
    parser.add_argument("--apk", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    if args.html and not args.apk and not args.output:
        patch_html(args.html)
        return 0
    if args.apk and args.output and not args.html:
        patch_apk(args.apk, args.output)
        return 0
    parser.error("use --html FILE, --apk INPUT.apk --output OUTPUT.apk, or --self-test")
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
