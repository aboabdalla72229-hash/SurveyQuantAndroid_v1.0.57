const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 8080;
const DATA = path.join(__dirname, 'data.json');
const KASHIER_MODE = (process.env.KASHIER_MODE || 'test').toLowerCase() === 'live' ? 'live' : 'test';
const KASHIER_API_BASE = KASHIER_MODE === 'live' ? 'https://api.kashier.io' : 'https://test-api.kashier.io';
const KASHIER_API_KEY = process.env.KASHIER_API_KEY || '';
const KASHIER_SECRET_KEY = process.env.KASHIER_SECRET_KEY || '';
const KASHIER_MID = process.env.KASHIER_MID || '';
const PUBLIC_BASE_URL = (process.env.PUBLIC_BASE_URL || '').replace(/\/$/, '');
const TRIAL_DAYS = 7;
const PLANS = {
  weekly: { amount: 15, days: 7, label: 'أسبوعي' },
  monthly: { amount: 55, days: 30, label: 'شهري' },
  yearly: { amount: 550, days: 365, label: 'سنوي' }
};

if (!fs.existsSync(DATA)) fs.writeFileSync(DATA, JSON.stringify({ users: {}, payments: {}, webhookEvents: {} }, null, 2));
const read = () => JSON.parse(fs.readFileSync(DATA, 'utf8'));
const write = x => fs.writeFileSync(DATA, JSON.stringify(x, null, 2));

app.use(cors());
app.use(express.json({ limit: '2mb' }));

app.get('/api/config', (req, res) => res.json({
  paymentProvider: 'Kashier',
  mode: KASHIER_MODE,
  trialDays: TRIAL_DAYS,
  plans: PLANS
}));

app.post('/api/register', (req, res) => {
  const { deviceId, name } = req.body || {};
  if (!deviceId) return res.status(400).json({ error: 'deviceId مطلوب' });
  const key = 'device:' + String(deviceId).trim();
  const d = read();
  if (!d.users[key]) {
    d.users[key] = {
      id: crypto.randomUUID(), name: name || '', deviceId: String(deviceId).trim(),
      createdAt: new Date().toISOString(),
      trialUntil: new Date(Date.now() + TRIAL_DAYS * 86400000).toISOString(),
      activeUntil: null
    };
    write(d);
  } else if (name && !d.users[key].name) {
    d.users[key].name = name; write(d);
  }
  res.json(d.users[key]);
});

app.get('/api/status/:deviceId', (req, res) => {
  const d = read(), key = 'device:' + decodeURIComponent(req.params.deviceId), u = d.users[key];
  if (!u) return res.status(404).json({ error: 'المستخدم غير موجود' });
  const now = Date.now();
  res.json({ ...u,
    trialActive: !!u.trialUntil && new Date(u.trialUntil).getTime() > now,
    subscriptionActive: !!u.activeUntil && new Date(u.activeUntil).getTime() > now
  });
});

function requireKashierConfig() {
  if (!KASHIER_API_KEY || !KASHIER_SECRET_KEY || !KASHIER_MID || !PUBLIC_BASE_URL) {
    const e = new Error('لم يتم إعداد مفاتيح Kashier أو PUBLIC_BASE_URL على السيرفر بعد');
    e.statusCode = 503; throw e;
  }
}

app.post('/api/kashier/create-session', async (req, res) => {
  try {
    requireKashierConfig();
    const { deviceId, plan } = req.body || {};
    const key = 'device:' + String(deviceId || '').trim();
    const p = PLANS[plan];
    if (!deviceId || !p) return res.status(400).json({ error: 'بيانات الحساب أو الباقة غير صحيحة' });
    const d = read();
    if (!d.users[key]) { d.users[key] = { id: crypto.randomUUID(), deviceId: String(deviceId).trim(), name: '', createdAt: new Date().toISOString(), trialUntil: new Date(Date.now() + TRIAL_DAYS * 86400000).toISOString(), activeUntil: null }; write(d); }
    const order = `SQ-${Date.now()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    d.payments[order] = {
      order, deviceId: String(deviceId).trim(), name: d.users[key].name || '', plan,
      amount: p.amount, currency: 'EGP', status: 'CREATED',
      createdAt: new Date().toISOString(), transactionId: null
    };
    write(d);

    const now = new Date();
    const expireAt = new Date(now.getTime() + 30 * 60 * 1000).toISOString();
    const body = {
      expireAt,
      maxFailureAttempts: 3,
      paymentType: 'credit',
      amount: p.amount.toFixed(2),
      currency: 'EGP',
      order,
      merchantRedirect: encodeURI(`${PUBLIC_BASE_URL}/api/kashier/return?order=${encodeURIComponent(order)}`),
      display: 'ar',
      type: 'one-time',
      allowedMethods: 'card,wallet',
      redirectMethod: null,
      merchantId: KASHIER_MID,
      failureRedirect: false,
      brandColor: '#0b7d58',
      defaultMethod: 'card',
      description: `SurveyQuant ${p.label} subscription`,
      manualCapture: false,
      customer: { reference: d.users[key].id },
      enable3DS: true,
      serverWebhook: `${PUBLIC_BASE_URL}/api/kashier/webhook`
    };
    const r = await fetch(`${KASHIER_API_BASE}/v3/payment/sessions`, {
      method: 'POST',
      headers: { Authorization: KASHIER_SECRET_KEY, 'api-key': KASHIER_API_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.sessionUrl) return res.status(502).json({ error: j.message || j.error || 'تعذر إنشاء جلسة الدفع من Kashier', details: j });
    d.payments[order].sessionId = j._id || null;
    d.payments[order].sessionUrl = j.sessionUrl;
    write(d);
    res.json({ ok: true, order, sessionUrl: j.sessionUrl, amount: p.amount, currency: 'EGP' });
  } catch (e) {
    res.status(e.statusCode || 500).json({ error: e.message || 'خطأ في إنشاء الدفع' });
  }
});

app.get('/api/kashier/status', (req, res) => {
  const deviceId = String(req.query.deviceId || '').trim();
  const order = String(req.query.order || '').trim();
  const d = read();
  const p = d.payments[order];
  const u = d.users['device:' + deviceId];
  if (!p || !u || p.deviceId !== deviceId) return res.status(404).json({ error: 'عملية الدفع غير موجودة' });
  const now = Date.now();
  res.json({
    paymentStatus: p.status,
    transactionId: p.transactionId,
    subscriptionActive: !!u.activeUntil && new Date(u.activeUntil).getTime() > now,
    activeUntil: u.activeUntil || null
  });
});

function verifyWebhook(data, headerSignature) {
  if (!KASHIER_API_KEY || !headerSignature || !data || !Array.isArray(data.signatureKeys)) return false;
  const keys = [...data.signatureKeys].sort();
  const payload = keys.map(k => `${k}=${encodeURIComponent(data[k] == null ? '' : String(data[k]))}`).join('&');
  const digest = crypto.createHmac('sha256', KASHIER_API_KEY).update(payload).digest('hex');
  return digest.length === String(headerSignature).length && crypto.timingSafeEqual(Buffer.from(digest.toLowerCase()), Buffer.from(String(headerSignature).toLowerCase()));
}

app.post('/api/kashier/webhook', (req, res) => {
  const body = req.body || {}, data = body.data || {}, signature = req.get('x-kashier-signature');
  if (!verifyWebhook(data, signature)) return res.status(401).send('invalid signature');
  const eventId = data.transactionId || `${body.event || 'event'}:${data.merchantOrderId || data.orderReference || ''}:${data.status || ''}`;
  const d = read();
  if (d.webhookEvents[eventId]) return res.status(409).send('already processed');
  d.webhookEvents[eventId] = new Date().toISOString();

  const order = data.merchantOrderId || data.orderReference || '';
  const p = d.payments[order];
  if (p) {
    p.status = data.status || 'UNKNOWN';
    p.transactionId = data.transactionId || null;
    p.kashierOrderId = data.kashierOrderId || null;
    p.method = data.method || data.paymentMethod || null;
    p.webhookAt = new Date().toISOString();
    if (data.status === 'SUCCESS') {
      const u = d.users['device:' + p.deviceId];
      if (u) {
        const base = u.activeUntil && new Date(u.activeUntil).getTime() > Date.now() ? new Date(u.activeUntil).getTime() : Date.now();
        u.activeUntil = new Date(base + PLANS[p.plan].days * 86400000).toISOString();
        p.subscriptionActivated = true;
      }
    }
  }
  write(d);
  return res.status(200).send('OK');
});

app.get('/api/kashier/return', (req, res) => {
  res.status(200).send(`<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SurveyQuant</title><body style="font-family:Arial;text-align:center;padding:40px"><h2>تمت العودة من صفحة الدفع</h2><p>يمكنك الرجوع إلى تطبيق مكتب فني مساحة. سيتم تفعيل الاشتراك تلقائيًا بعد تأكيد Kashier.</p><p>يمكنك إغلاق هذه الصفحة.</p></body></html>`);
});

app.get('/health', (req, res) => res.json({ ok: true, provider: 'Kashier', mode: KASHIER_MODE }));
app.listen(PORT, () => console.log(`SurveyQuant Kashier backend on :${PORT} (${KASHIER_MODE})`));
