#!/usr/bin/env python3
from pathlib import Path
import argparse, re, base64

PARSER = r'''function readTextPoints(text, format='TXT'){
 const out=[];const src=String(text||'').replace(/\0/g,'');const lines=src.split(/\r?\n/);let header=null;
 const fmt=String(format||'TXT').toUpperCase();
 const clean=s=>String(s??'').trim().replace(/^\ufeff/,'').replace(/^"|"$/g,'');
 const cellsOf=line=>{
  const s=String(line||'').trim();if(!s)return [];
  let delim='';if(s.includes('\t'))delim='\t';else if(s.includes(';'))delim=';';else if(s.includes(','))delim=',';
  if(!delim)return s.split(/\s+/).map(clean).filter(Boolean);
  const out=[];let cur='',quoted=false;
  for(let i=0;i<s.length;i++){const c=s[i];if(c==='"'){if(quoted&&s[i+1]==='"'){cur+='"';i++;}else quoted=!quoted;}else if(c===delim&&!quoted){out.push(clean(cur));cur='';}else cur+=c;}
  out.push(clean(cur));return out;
 };
 const number=v=>{let s=clean(v).replace(/\s/g,'');if(!s)return null;if(s.includes(',')&&!s.includes('.'))s=s.replace(',','.');const n=Number(s);return Number.isFinite(n)?n:null;};
 const normHead=s=>clean(s).toLowerCase().replace(/[\s._-]+/g,'').replace(/[^a-z0-9\u0600-\u06ff]/g,'');
 const aliases={id:['id','point','pointno','pointnumber','ptno','pt','station','stationno','name','number','رقم','رقمالنقطة','النقطة'],x:['x','e','east','easting','utme','coordx','شرق','شرقي'],y:['y','n','north','northing','utmn','coordy','شمال','شمالي'],z:['z','elev','elevation','rl','level','height','منسوب']};
 const add=(id,e,n,z)=>{if(Number.isFinite(e)&&Number.isFinite(n)&&Number.isFinite(z))out.push({id:String(id??'').trim()||('P'+(out.length+1)),e,n,z,layer:'SURVEY_POINTS'});};
 let sdrOrder='ENZ';
 if(fmt==='SDR')for(const ln of lines){if(/^00(?:NM|KI)/i.test(ln)){const flag=String(ln).length>44?String(ln).charAt(44):'';if(flag==='1')sdrOrder='NEZ';else if(flag==='2')sdrOrder='ENZ';else{const p=cellsOf(ln),tail=p[p.length-1];if(tail==='1')sdrOrder='NEZ';else if(tail==='2')sdrOrder='ENZ';}break;}}
 for(const raw of lines){const s=String(raw||'').trim();if(!s)continue;
  if(fmt==='SDR'&&/^08(?:TP|KI)/i.test(s)){
   const p=cellsOf(s);if(p.length>=5){const id=p[1]||('P'+(out.length+1)),a=number(p[2]),b=number(p[3]),z=number(p[4]);if(a!==null&&b!==null&&z!==null){add(id,sdrOrder==='NEZ'?b:a,sdrOrder==='NEZ'?a:b,z);continue;}}
   const id=s.substring(4,20).trim()||('P'+(out.length+1)),a=number(s.substring(20,36)),b=number(s.substring(36,52)),z=number(s.substring(52,68));if([a,b,z].every(v=>v!==null)){add(id,sdrOrder==='NEZ'?b:a,sdrOrder==='NEZ'?a:b,z);continue;}
   const nums=(s.match(/[+-]?(?:\d+(?:\.\d*)?|\.\d+)/g)||[]).map(Number).filter(Number.isFinite);if(nums.length>=3){const q=nums.slice(-3);add(id,sdrOrder==='NEZ'?q[1]:q[0],sdrOrder==='NEZ'?q[0]:q[1],q[2]);}continue;
  }
  const cells=cellsOf(s);if(cells.length<3)continue;const heads=cells.map(normHead);
  const pick=(keys,contains=[])=>heads.findIndex(h=>keys.includes(h)||contains.some(k=>h.includes(k)));
  const hx=pick(aliases.x,['easting','east','coordx','utme']),hy=pick(aliases.y,['northing','north','coordy','utmn']),hz=pick(aliases.z,['elevation','elev','height','level']),hid=pick(aliases.id,['pointno','pointnumber','stationno']);
  if(hx>=0&&hy>=0){header={id:hid,x:hx,y:hy,z:hz};continue;}
  if(header){const e=number(cells[header.x]),n=number(cells[header.y]);let z=header.z>=0?number(cells[header.z]):null;if(z===null){const rest=cells.map((_,i)=>i).filter(i=>i!==header.x&&i!==header.y&&i!==header.id).map(i=>number(cells[i])).filter(v=>v!==null);z=rest.length?rest[rest.length-1]:null;}const id=header.id>=0?cells[header.id]:'';add(id,e,n,z);continue;}
  // No header: point number is ID, never Easting or Northing.
  const nums=cells.map(number);
  if(cells.length>=4){add(cells[0],nums[1],nums[2],nums[3]);}
  else if(cells.length===3){add('',nums[0],nums[1],nums[2]);}
 }
 const seen=new Set();return out.filter(p=>{if(![p.e,p.n,p.z].every(Number.isFinite))return false;const k=p.e.toFixed(6)+'|'+p.n.toFixed(6);if(seen.has(k))return false;seen.add(k);return true;});
}'''


def once(s, old, new, label):
    n=s.count(old)
    if n != 1: raise SystemExit(f'{label}: expected one match, found {n}')
    return s.replace(old,new,1)


def patch_html(path: Path, engine_path: Path, pdfjs_path: Path, worker_path: Path, drop_path: Path, check=False):
    html=path.read_text(encoding='utf-8')
    marker='<!-- SURVEYQUANT_V176_RAW_CAD_MERGE_VECTOR_PDF_IDENTITY_GUARD -->'
    if marker in html:
        if check:
            need=['async function parsePointFiles(files,formatOverride=null)',
                  "parsePointFiles(fs,document.getElementById('fileToDxfType').value)",
                  'mergeRawDxfBoards(target.bytes,source.bytes)',
                  'sq162-imagetracer','sq163-pdfjs-worker','window.SurveyQuantCAD176',
                  'rejectIdentityAlignment','pdfOperatorPathsToCad','pdfTextToCad','استخراج خطوط CAD وحفظ DXF']
            miss=[x for x in need if x not in html]
            if miss: raise SystemExit('V176 marker exists but missing: '+', '.join(miss))
            if 'PDF output is editable POLYLINE/VERTEX/TEXT only, no IMAGE or IMAGEDEF' not in html:
                raise SystemExit('V176 vector-DXF output policy marker is missing')
            print('PASS V176 HTML patch checks')
            return
        raise SystemExit('V176 patch already installed')

    # Restore the robust point-row contract from the V175 patch while keeping it on V162 base.
    start=html.find('function readTextPoints('); end=html.find('\nfunction addCadEntity',start)
    if start<0 or end<0: raise SystemExit('Cannot locate readTextPoints')
    html=html[:start]+PARSER+'\n'+html[end:]
    old_reader="async function parsePointFiles(files){return Promise.all([...files].map(async f=>{const ext=String(f.name||'').toLowerCase().split('.').pop()||'txt';const bytes=new Uint8Array(await f.arrayBuffer());let best=[];for(const enc of ['utf-8','windows-1252','iso-8859-1']){const pts=readTextPoints(new TextDecoder(enc,{fatal:false}).decode(bytes),ext.toUpperCase());if(pts.length>best.length)best=pts;}return{file:f,points:best};}));}"
    new_reader="async function parsePointFiles(files,formatOverride=null){return Promise.all([...files].map(async f=>{const ext=String(f.name||'').toLowerCase().split('.').pop()||'txt';const fmt=String(formatOverride||ext).toUpperCase();const bytes=new Uint8Array(await f.arrayBuffer());if(!bytes.length)throw new Error('ملف النقاط فارغ: '+f.name);let best=[];for(const enc of ['utf-8','windows-1252','iso-8859-1']){const pts=readTextPoints(new TextDecoder(enc,{fatal:false}).decode(bytes),fmt);if(pts.length>best.length)best=pts;}return{file:f,points:best,format:fmt};}));}"
    html=once(html,old_reader,new_reader,'parsePointFiles')
    html=once(html,"const sets=await parsePointFiles(fs),pts=[],seen=new Set();","const sets=await parsePointFiles(fs,document.getElementById('fileToDxfType').value),pts=[],seen=new Set();",'file-to-DXF parser call')

    # Shared parser guard: Android content providers can report an empty stream/file.
    html=once(html,"async function parseFile(file,options={}){\n const ext=file.name.toLowerCase().split('.').pop();",
                    "async function parseFile(file,options={}){\n if(!file||!Number.isFinite(Number(file.size))||Number(file.size)<=0)throw new Error('الملف فارغ (صفر بايت) أو لم يُرجع مدير الملفات محتواه. أعد اختياره.');\n const ext=file.name.toLowerCase().split('.').pop();",'parseFile zero-byte guard')
    html=once(html," const bytes=new Uint8Array(await file.arrayBuffer());\n if(ext==='dxf')",
                    " const bytes=new Uint8Array(await file.arrayBuffer());\n if(!bytes.length)throw new Error('ملف '+file.name+' فارغ (صفر بايت) أو تعذر قراءة محتواه.');\n if(ext==='dxf')",'DXF byte guard')

    drop=drop_path.read_text(encoding='utf-8').strip()
    a=html.find('async function dropFilesMerge(){'); b=html.find('\nfunction downloadDroppedDXF()',a)
    if a<0 or b<0: raise SystemExit('Cannot locate dropFilesMerge')
    html=html[:a]+drop+'\n'+html[b:]

    # Remove the old V162 modal implementation and PDF.js bundle, but preserve its embedded ImageTracer engine.
    html,n=re.subn(r'<script\b(?=[^>]*\bid=["\']sq162-(?:pdfjs|cad-engine)["\'])[^>]*>[\s\S]*?</script\s*>','',html,flags=re.I)
    if n!=2: raise SystemExit(f'Expected to replace old V162 PDF.js and CAD engine scripts; removed {n}')
    if 'id="sq162-imagetracer"' not in html: raise SystemExit('The V162 ImageTracer script was not preserved')

    pdf=pdfjs_path.read_text(encoding='utf-8')
    worker=worker_path.read_bytes()
    if len(worker)<100000: raise SystemExit('PDF.js worker is too small or missing')
    eng=engine_path.read_text(encoding='utf-8')
    required=['mergeRawDxfBoards','rejectIdentityAlignment','svgPathsToCad','polylinesToDxf','pdfOperatorPathsToCad','pdfTextToCad','function ensurePdfWorker','root.SurveyQuantCAD176']
    missing=[x for x in required if x not in eng]
    if missing: raise SystemExit('V176 CAD engine missing: '+', '.join(missing))
    worker_tag='<script type="application/octet-stream" id="sq163-pdfjs-worker">'+base64.b64encode(worker).decode('ascii')+'</script>\n'
    block='\n<!-- SurveyQuant V176: raw CAD board merge and editable vector PDF output -->\n'+worker_tag
    block+='<script id="sq176-pdfjs">\n'+pdf.replace('</script>','<\\/script>')+'\n</script>\n'
    block+='<script id="sq176-cad-engine">\n'+eng.replace('</script>','<\\/script>')+'\n</script>\n'
    matches=list(re.finditer(r'</body\s*>',html,re.I))
    if matches:
        x=matches[-1]; html=html[:x.start()]+block+html[x.start():]
    else: html+=block
    html+='\n'+marker+'\n'
    html+='<!-- V176: projection merges original DXF records; PDF output is editable POLYLINE/VERTEX/TEXT only, no IMAGE or IMAGEDEF. -->\n'
    html+='<!-- sq176-point-row-contract: ID,Easting,Northing,Elevation; numeric ID excluded from coordinates -->\n'
    path.write_text(html,encoding='utf-8')
    print(f'PASS V176 HTML patch applied ({len(html):,} chars); original ImageTracer retained')


def main():
    p=argparse.ArgumentParser();p.add_argument('--html',type=Path,required=True);p.add_argument('--engine',type=Path,required=True)
    p.add_argument('--pdfjs',type=Path,required=True);p.add_argument('--pdf-worker',type=Path,required=True)
    p.add_argument('--drop-files-merge',type=Path,required=True);p.add_argument('--check-only',action='store_true');a=p.parse_args()
    patch_html(a.html,a.engine,a.pdfjs,a.pdf_worker,a.drop_files_merge,a.check_only)
if __name__=='__main__': main()
