#!/usr/bin/env python3
from __future__ import annotations
import argparse, re, tempfile, zipfile
from pathlib import Path

STATE_OLD = "const state={target:null,reference:null,targetPoints:[null,null],referencePoints:[null,null],active:{target:0,reference:0},tool:{target:'pick',reference:'pick'},snapMode:{target:'auto',reference:'auto'},views:{},undoBytes:null,undoName:null,idPoint:{target:null,reference:null},bound:false};"
STATE_NEW = "const state={target:null,reference:null,targetPoints:[null,null],referencePoints:[null,null],active:{target:0,reference:0},tool:{target:'pick',reference:'pick'},snapMode:{target:'auto',reference:'auto'},views:{},selectedEntity:null,undoStack:[],redoStack:[],idPoint:{target:null,reference:null},bound:false};"

OLD_DELETE_FUNCTION = r'''function deleteNearestEntityBytes(input,world,tolerance){
 const parsed=splitPairs(input),{bytes,pairs}=parsed,records=sectionRecords(pairs,'ENTITIES'),blocks=blockDefinitions(pairs);let best=null;
 for(let i=0;i<records.length;i++){const rec=records[i];if(rec.pairs.some(p=>p.code===67&&Number(p.value)===1))continue;const g=geometryInWorld(rec,blocks);let d=Infinity;
  for(const p of g.pts)d=Math.min(d,Math.hypot(p.x-world.x,p.y-world.y));for(const s of g.segments)d=Math.min(d,distPointSeg(world,s.a,s.b));if(Number.isFinite(d)&&(!best||d<best.distance))best={rec,index:i,distance:d};}
 if(!best||best.distance>tolerance)throw new Error('لم يتم العثور على عنصر قريب من موضع اللمس. كبّر الرسم واضغط على الخط أو النص مباشرة. إذا كان العنصر داخل بلوك فسيُحذف هذا الإدراج وحده.');
 const start=best.rec.start,end=best.rec.end;if(!(end>start))throw new Error('تعذر تحديد حدود العنصر للحذف بأمان.');const out=new Uint8Array(bytes.length-(end-start));out.set(bytes.slice(0,start),0);out.set(bytes.slice(end),start);return {bytes:out,deletedType:best.rec.type,deletedIndex:best.index,distance:best.distance,recoveredLines:parsed.recoveredLines||0};
}'''

NEW_DELETE_FUNCTION = r'''function findNearestEntityBytes(input,world,tolerance,layerVisibility){
 const parsed=splitPairs(input),{bytes,pairs}=parsed,records=sectionRecords(pairs,'ENTITIES'),blocks=blockDefinitions(pairs);let best=null;
 for(let i=0;i<records.length;i++){
  const rec=records[i];if(rec.pairs.some(p=>p.code===67&&Number(p.value)===1))continue;
  const entityLayer=recordString(rec,8)||'0';if(layerVisibility){const pair=Object.entries(layerVisibility).find(([name])=>String(name).toUpperCase()===entityLayer.toUpperCase());if(pair&&pair[1]===false)continue;}
  const g=geometryInWorld(rec,blocks);let d=Infinity;
  for(const p of g.pts)d=Math.min(d,Math.hypot(p.x-world.x,p.y-world.y));
  for(const s of g.segments)d=Math.min(d,distPointSeg(world,s.a,s.b));
  for(const t of g.texts||[])if(t.p){const textRadius=Math.max(0.15,Math.min(4,(Number(t.height)||2.5)*0.35));d=Math.min(d,Math.max(0,Math.hypot(t.p.x-world.x,t.p.y-world.y)-textRadius));}
  if(Number.isFinite(d)&&(!best||d<best.distance))best={rec,index:i,distance:d,geometry:g};
 }
 if(!best||best.distance>tolerance)throw new Error('لم يتم تحديد عنصر. كبّر اللوحة والمس الخط أو النص نفسه، ثم جرّب مرة أخرى.');
 const start=best.rec.start,end=best.rec.end;if(!(end>start))throw new Error('تعذر تحديد حدود العنصر بأمان.');
 const raw=bytes.slice(start,end);const layer=recordString(best.rec,8)||'0';
 return {bytes:bytes.slice(),start,end,type:best.rec.type,index:best.index,layer,distance:best.distance,geometry:best.geometry,raw,recoveredLines:parsed.recoveredLines||0};
}
function removeSelectedEntityBytes(input,selected){
 const parsed=splitPairs(input),bytes=parsed.bytes;
 if(!selected||!Number.isInteger(selected.start)||!Number.isInteger(selected.end)||selected.start<0||selected.end>bytes.length||selected.end<=selected.start)throw new Error('العنصر المحدد لم يعد موجودًا في نسخة العمل. حدده مرة أخرى.');
 if(!(selected.raw instanceof Uint8Array)||selected.raw.length!==selected.end-selected.start)throw new Error('بيانات العنصر المحدد غير مكتملة. حدده من اللوحة مرة أخرى.');
 for(let i=0;i<selected.raw.length;i++)if(bytes[selected.start+i]!==selected.raw[i])throw new Error('تغيرت اللوحة بعد التحديد. حدّد العنصر مرة أخرى قبل الحذف.');
 const out=new Uint8Array(bytes.length-(selected.end-selected.start));out.set(bytes.slice(0,selected.start),0);out.set(bytes.slice(selected.end),selected.start);
 return {bytes:out,deletedType:selected.type,deletedIndex:selected.index,layer:selected.layer,distance:selected.distance,recoveredLines:parsed.recoveredLines||0};
}
function deleteNearestEntityBytes(input,world,tolerance){const selected=findNearestEntityBytes(input,world,tolerance);return removeSelectedEntityBytes(input,selected);}'''

OLD_PICK_DELETE_BRANCH = r'''if(tool==='delete'){
  if(v.side!=='target'){status('الحذف متاح على اللوحة غير الموجّهة فقط حتى تظل اللوحة المرجعية الأصلية مرجعًا ثابتًا.',true);return;}
  try{const maxWorld=38/metrics(v).scale,removed=deleteNearestEntityBytes(state.target.bytes,world,maxWorld);state.undoBytes=state.target.bytes.slice();state.undoName=state.target.name;state.target.bytes=removed.bytes;state.target.name=state.target.name.replace(/\.dxf$/i,'')+'_EDITED.dxf';const old=[...state.targetPoints];state.targetPoints=[null,null];state.idPoint.target=null;loadView('target',state.target.bytes,state.target.name);fillReadouts();el('sq110UndoDelete').disabled=false;status('تم حذف عنصر '+removed.deletedType+' من نسخة العمل فقط. استخدم «تراجع عن الحذف» لاسترجاعه. أعد تحديد النقطتين لضمان دقة التوجيه.');return;}catch(e){status(e.message||String(e),true);return;}
 }'''

NEW_PICK_DELETE_BRANCH = r'''if(tool==='selectEntity'||tool==='delete'){
  if(v.side!=='target'){status('اختيار الحذف متاح على اللوحة غير الموجّهة فقط حتى تظل اللوحة المرجعية الأصلية مرجعًا ثابتًا.',true);return;}
  try{const maxWorld=44/Math.max(0.001,metrics(v).scale),found=findNearestEntityBytes(state.target.bytes,world,maxWorld,v.layerVisibility);state.selectedEntity={...found,sourceBytes:state.target.bytes};draw(v);const label=el('sq110TargetMode');if(label)label.textContent='تم تحديد '+found.type+' | Layer: '+found.layer+' | اضغط «حذف المحدد» أو اختر عنصرًا آخر';status('تم تحديد عنصر '+found.type+' على الطبقة '+found.layer+'. اضغط الآن «حذف المحدد». لم يتم تغيير الملف بعد.');return;}catch(e){status(e.message||String(e),true);return;}
 }'''

OLD_UNDO = r'''function undoDelete(){if(!state.undoBytes)return;state.target={bytes:state.undoBytes.slice(),name:state.undoName||state.target.name};state.undoBytes=null;state.undoName=null;loadView('target',state.target.bytes,state.target.name);state.targetPoints=[null,null];fillReadouts();el('sq110UndoDelete').disabled=true;status('تم التراجع عن آخر حذف. أعد تحديد النقطتين 1 و2.');}'''
NEW_HISTORY = r'''function updateDeleteHistoryButtons(){const undo=el('sq110UndoDelete'),redo=el('sq110RedoDelete');if(undo)undo.disabled=!state.undoStack.length;if(redo)redo.disabled=!state.redoStack.length;}
function targetSnapshot(){if(!state.target)return null;return {bytes:state.target.bytes.slice(),name:state.target.name,targetPoints:state.targetPoints.map(p=>p?{...p}:null),idPoint:state.idPoint.target?{...state.idPoint.target}:null};}
function restoreTargetSnapshot(s,msg){if(!s)return;state.target={bytes:s.bytes.slice(),name:s.name};state.targetPoints=s.targetPoints.map(p=>p?{...p}:null);state.idPoint.target=s.idPoint?{...s.idPoint}:null;state.selectedEntity=null;state.tool.target='pick';loadView('target',state.target.bytes,state.target.name);fillReadouts();updateDeleteHistoryButtons();updatePickLabels();const mode=el('sq110TargetMode');if(mode)mode.textContent='اختر النقطة 1 أو 2 على الرسم';status(msg);}
function deleteSelectedEntity(){if(!state.target) {status('افتح اللوحة غير الموجّهة أولًا.',true);return;}const selected=state.selectedEntity;if(!selected||selected.sourceBytes!==state.target.bytes){status('حدد عنصرًا على اللوحة أولًا باستخدام «تحديد عنصر»، ثم اضغط «حذف المحدد».',true);return;}try{const before=targetSnapshot(),removed=removeSelectedEntityBytes(state.target.bytes,selected);state.undoStack.push(before);if(state.undoStack.length>100)state.undoStack.shift();state.redoStack=[];state.target={bytes:removed.bytes,name:state.target.name.replace(/(?:_EDITED)*\.dxf$/i,'_EDITED.dxf')};state.selectedEntity=null;state.idPoint.target=null;state.tool.target='pick';loadView('target',state.target.bytes,state.target.name);fillReadouts();updateDeleteHistoryButtons();updatePickLabels();status('تم حذف العنصر '+removed.deletedType+' من الطبقة '+removed.layer+'. بقية بايتات اللوحة الأصلية محفوظة. استخدم «تراجع» لاسترجاعه أو «إعادة» لتنفيذ الحذف مجددًا.');}catch(e){status((e.message||String(e))+' لم يتم حذف أي عنصر.',true);}}
function undoDelete(){if(!state.undoStack.length)return;const current=targetSnapshot(),previous=state.undoStack.pop();state.redoStack.push(current);restoreTargetSnapshot(previous,'تم التراجع عن الحذف واستعادة العنصر واللوحة كما كانا.');}
function redoDelete(){if(!state.redoStack.length)return;const current=targetSnapshot(),next=state.redoStack.pop();state.undoStack.push(current);restoreTargetSnapshot(next,'تمت إعادة الحذف. يمكنك التراجع مرة أخرى.');}'''

TOOLBAR_OLD = '<button id="sq110Delete" class="sqori-preview" type="button">حذف عنصر</button><button id="sq110UndoDelete" class="sqori-preview" type="button" disabled>تراجع عن الحذف</button>'
TOOLBAR_NEW = '<button id="sq110SelectEntity" class="sqori-preview" type="button">تحديد عنصر</button><button id="sq110Delete" class="sqori-preview" type="button">حذف المحدد</button><button id="sq110UndoDelete" class="sqori-preview" type="button" disabled>تراجع</button><button id="sq110RedoDelete" class="sqori-preview" type="button" disabled>إعادة</button>'

OLD_TOOL_STATUS = "function updatePickLabels(){for(const side of ['target','reference']){const i=state.active[side],lab=el(side==='target'?'sq110TargetMode':'sq110ReferenceMode'),tool=state.tool[side];if(lab)lab.textContent=tool==='id'?'أداة ID Point: اضغط لقراءة X/Y':tool==='delete'?'أداة الحذف: اضغط على العنصر المراد حذفه':'اختيار النقطة '+(i+1)+' على '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية');}}"
NEW_TOOL_STATUS = "function updatePickLabels(){for(const side of ['target','reference']){const i=state.active[side],lab=el(side==='target'?'sq110TargetMode':'sq110ReferenceMode'),tool=state.tool[side];if(lab)lab.textContent=tool==='id'?'أداة ID Point: اضغط لقراءة X/Y':tool==='selectEntity'?'اضغط على العنصر لتحديده، ثم اضغط «حذف المحدد»':'اختيار النقطة '+(i+1)+' على '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية');}}"

OLD_SETTOOL = "function setTool(side,tool){state.tool[side]=tool;updatePickLabels();status(tool==='id'?'تم تفعيل ID Point على '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+'. اضغط نقطة لقراءة إحداثياتها.':tool==='delete'?'وضع الحذف: اضغط على العنصر في اللوحة غير الموجّهة لحذف ذلك العنصر كاملًا.':'تم إيقاف الأداة الإضافية.');}"
NEW_SETTOOL = "function setTool(side,tool){state.tool[side]=tool;if(tool!=='selectEntity')state.selectedEntity=null;updatePickLabels();if(state.views[side])draw(state.views[side]);status(tool==='id'?'تم تفعيل ID Point على '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+'. اضغط نقطة لقراءة إحداثياتها.':tool==='selectEntity'?'تم تفعيل تحديد العنصر. المس خطًا أو نصًا في اللوحة، وسيظهر تحديده قبل الحذف.':'تم إيقاف الأداة الإضافية.');}"

OLD_EVENTS = "} el('sq110Delete').addEventListener('click',()=>setTool('target',state.tool.target==='delete'?'pick':'delete'));el('sq110UndoDelete').addEventListener('click',undoDelete);el('sq110Preview').addEventListener('click',review);"
NEW_EVENTS = "} el('sq110SelectEntity').addEventListener('click',()=>setTool('target',state.tool.target==='selectEntity'?'pick':'selectEntity'));el('sq110Delete').addEventListener('click',deleteSelectedEntity);el('sq110UndoDelete').addEventListener('click',undoDelete);el('sq110RedoDelete').addEventListener('click',redoDelete);el('sq110Preview').addEventListener('click',review);"

OLD_LOAD_TARGET = "state.target={bytes:data.bytes,name:data.name};state.targetPoints=[null,null];state.undoBytes=null;el('sq110UndoDelete').disabled=true;}else"
NEW_LOAD_TARGET = "state.target={bytes:data.bytes,name:data.name};state.targetPoints=[null,null];state.selectedEntity=null;state.undoStack=[];state.redoStack=[];updateDeleteHistoryButtons();}else"

OLD_MOUNT_RESET = "state.views={};state.undoBytes=null;state.undoName=null;state.idPoint={target:null,reference:null};"
NEW_MOUNT_RESET = "state.views={};state.selectedEntity=null;state.undoStack=[];state.redoStack=[];state.idPoint={target:null,reference:null};"

# overlay injected just before point markers
OVERLAY_MARKER = "const arr=v.side==='target'?state.targetPoints:state.referencePoints;for(let i=0;i<2;i++)"
OVERLAY_CODE = r'''if(v.side==='target'&&state.selectedEntity&&state.selectedEntity.sourceBytes===state.target?.bytes&&state.selectedEntity.geometry){const sg=state.selectedEntity.geometry;c.save();c.strokeStyle='#ff4fd8';c.fillStyle='rgba(255,79,216,.20)';c.lineWidth=3.6;c.setLineDash([6,3]);c.lineCap='round';c.lineJoin='round';for(const seg of sg.segments||[]){if(!layerVisible(v,seg.layer))continue;const a=project(v,seg.a,m),b=project(v,seg.b,m);if(![a.x,a.y,b.x,b.y].every(Number.isFinite))continue;c.beginPath();c.moveTo(a.x,a.y);c.lineTo(b.x,b.y);c.stroke();}c.setLineDash([]);for(const p0 of sg.pts||[]){if(!layerVisible(v,p0.layer))continue;const q=project(v,p0,m);if(!Number.isFinite(q.x)||!Number.isFinite(q.y))continue;c.beginPath();c.arc(q.x,q.y,4.5,0,Math.PI*2);c.fill();c.stroke();}for(const tx of sg.texts||[]){if(!tx.p)continue;const q=project(v,tx.p,m);c.font='bold 13px sans-serif';const w=Math.min(240,Math.max(16,c.measureText(String(tx.text||'')).width+8));c.fillStyle='rgba(255,79,216,.18)';c.fillRect(q.x-2,q.y-15,w,18);c.strokeStyle='#ff4fd8';c.strokeRect(q.x-2,q.y-15,w,18);}c.restore();}const arr=v.side==='target'?state.targetPoints:state.referencePoints;for(let i=0;i<2;i++)'''


def replace_once(s: str, old: str, new: str, label: str) -> str:
    count = s.count(old)
    if count != 1:
        raise SystemExit(f'ERROR: expected exactly one patch point for {label}; found {count}')
    return s.replace(old, new, 1)

def patch_html(s: str) -> str:
    if 'function findNearestEntityBytes(input,world,tolerance)' in s and 'sq110RedoDelete' in s:
        raise SystemExit('ERROR: V129 delete/undo patch already applied.')
    s=replace_once(s, STATE_OLD, STATE_NEW, 'state history fields')
    s=replace_once(s, OLD_DELETE_FUNCTION, NEW_DELETE_FUNCTION, 'record select/remove engine')
    s=replace_once(s, OLD_PICK_DELETE_BRANCH, NEW_PICK_DELETE_BRANCH, 'two-phase entity selection')
    s=replace_once(s, OLD_UNDO, NEW_HISTORY, 'undo/redo history stack')
    s=replace_once(s, TOOLBAR_OLD, TOOLBAR_NEW, 'selection/delete/undo/redo toolbar')
    s=replace_once(s, OLD_TOOL_STATUS, NEW_TOOL_STATUS, 'selection mode label')
    s=replace_once(s, OLD_SETTOOL, NEW_SETTOOL, 'selection tool activation')
    s=replace_once(s, OLD_EVENTS, NEW_EVENTS, 'toolbar event handlers')
    s=replace_once(s, OLD_LOAD_TARGET, NEW_LOAD_TARGET, 'reset undo redo on target reload')
    s=replace_once(s, OLD_MOUNT_RESET, NEW_MOUNT_RESET, 'initialize undo redo stacks on open')
    s=replace_once(s, OVERLAY_MARKER, OVERLAY_CODE, 'selected element highlighting')
    # Add exported testable APIs without removing compatibility function.
    marker='window.__sqOrientation110API={VERSION,solve,transformBytes:universalTransformBytes,deleteNearestEntityBytes,splitPairs,sectionRecords,recordGeometry,geometryInWorld,blockDefinitions,parsePreview};'
    expanded='window.__sqOrientation110API={VERSION,solve,transformBytes:universalTransformBytes,deleteNearestEntityBytes,findNearestEntityBytes,removeSelectedEntityBytes,splitPairs,sectionRecords,recordGeometry,geometryInWorld,blockDefinitions,parsePreview};'
    s=replace_once(s, marker, expanded, 'selection API export')
    # Add undo/redo/delete functions to v111 window test API (the state stack is intentionally scoped to the existing orientation project).
    old_api="window.__sqOrientation111API=Object.assign(window.__sqOrientation110API,{state,loadView,fillReadouts,draw,calculation,exportTarget,status,showScreen,updatePickLabels,nearestSnap,metrics,project,unproject,refreshVisibleCadCanvas});"
    new_api="window.__sqOrientation111API=Object.assign(window.__sqOrientation110API,{state,loadView,fillReadouts,draw,calculation,exportTarget,status,showScreen,updatePickLabels,nearestSnap,metrics,project,unproject,refreshVisibleCadCanvas,deleteSelectedEntity,undoDelete,redoDelete,targetSnapshot});"
    s=replace_once(s, old_api, new_api, 'v111 API export')
    return s

def patch_apk(source: Path, output: Path):
    if not source.is_file(): raise SystemExit(f'ERROR: APK missing: {source}')
    output.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='sq-v129-',suffix='.apk',dir=output.parent);Path(tmp).unlink(missing_ok=True)
    changed=0
    try:
        with zipfile.ZipFile(source,'r') as zi, zipfile.ZipFile(tmp,'w') as zo:
            for info in zi.infolist():
                if re.match(r'^META-INF/[^/]+\.(?:SF|RSA|DSA|EC|MF)$', info.filename, re.I):
                    continue
                data=zi.read(info.filename)
                if info.filename=='assets/index.html':
                    data=patch_html(data.decode('utf-8')).encode('utf-8');changed+=1
                zo.writestr(info,data)
        if changed!=1: raise SystemExit(f'ERROR: expected assets/index.html exactly once, found {changed}')
        Path(tmp).replace(output)
    except Exception:
        Path(tmp).unlink(missing_ok=True);raise
    print(f'PATCHED APK HTML: {source} -> {output}; APK must be aligned and re-signed.')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--html',type=Path);p.add_argument('--apk',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args()
    if a.html and not a.apk and not a.output:
        src=a.html.read_text(encoding='utf-8');out=patch_html(src);a.html.write_text(out,encoding='utf-8',newline='');print(f'PATCHED HTML {a.html}: {len(src)} -> {len(out)} chars')
    elif a.apk and a.output and not a.html: patch_apk(a.apk,a.output)
    else: p.error('use --html PATH or --apk SOURCE.apk --output OUTPUT.apk')
if __name__=='__main__': main()
