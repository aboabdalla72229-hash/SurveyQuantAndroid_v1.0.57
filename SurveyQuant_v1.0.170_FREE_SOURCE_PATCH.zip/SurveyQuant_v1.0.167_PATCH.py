#!/usr/bin/env python3
from __future__ import annotations
import argparse,base64,re
from pathlib import Path
META='<meta name="surveyquant-v167" content="sq167-dwg-orientation-view-transform">'
def embed_engine(html:str,engine:bytes)->str:
    pattern=r'(<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">)([A-Za-z0-9+/=\r\n]+)(</script>)'
    payload=base64.b64encode(engine).decode('ascii')
    html,n=re.subn(pattern,lambda m:m.group(1)+payload+m.group(3),html,count=1,flags=re.I)
    if n!=1:raise ValueError(f'Expected one embedded CAD engine slot, found {n}')
    return html
def patch(html:str,engine:bytes)->str:
    if 'sq166-readonly-source-and-exact-pdf-raster' not in html:raise ValueError('V166 baseline must be present first')
    if 'sq167-dwg-orientation-view-transform' in html:raise ValueError('V167 already applied')
    head=re.search(r'<head\b[^>]*>',html,re.I)
    if not head:raise ValueError('HTML head not found')
    html=html[:head.end()]+META+html[head.end():]
    html=embed_engine(html,engine)
    validate(html,engine)
    return html
def validate(html:str,engine:bytes)->None:
    for m in (META,'sq166-readonly-source-and-exact-pdf-raster','sq164-cad-output-axis-fix','sqDownloadNameDialog','sq163-pdfjs-worker','sq162-wasm-binary','sq163RawCadOverlayMerge'):
        if m not in html:raise ValueError('Missing HTML marker: '+m)
    match=re.search(r'<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">([A-Za-z0-9+/=\r\n]+)</script>',html,re.I)
    if not match or base64.b64decode(match.group(1))!=engine:raise ValueError('Embedded CAD engine differs from tested V167 engine')
    text=engine.decode('utf-8')
    for m in ('SQ_V167_DWG_ORIENTATION_VIEW_TRANSFORM','function transformGeometryView','el(\'sq162-start-pick\').addEventListener','el(\'sq162-do-align\').addEventListener','el(\'sq162-reset-picks\').addEventListener','curve.points.push(q);prev=q;','state.source.viewGeom||state.source.geom'):
        if m not in text:raise ValueError('V167 engine missing: '+m)
    if 'ImageTracer.imagedataToSVG' in text:raise ValueError('PDF image tracer remains enabled')
    if 'state[which] = { file, bytes, geom, viewGeom:null, transform:null }' not in text:raise ValueError('Original source byte buffer is no longer retained')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--html',type=Path,required=True);ap.add_argument('--engine',type=Path,required=True);ap.add_argument('--check-only',action='store_true');a=ap.parse_args()
    html=a.html.read_text(encoding='utf-8');engine=a.engine.read_bytes()
    if a.check_only:validate(html,engine);print('PASS V167 HTML and embedded engine validation');return
    a.html.write_text(patch(html,engine),encoding='utf-8');print(f'PASS V167 injected {len(engine):,} engine bytes into {a.html}')
if __name__=='__main__':main()
