'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(process.argv[2]||__dirname);
const cad=require(path.join(root,'SurveyQuant_v1.0.177_CAD_ENGINE.js'));
const pdfjs=require(path.join(root,'pdfjs-v3.11.174.min.js'));
pdfjs.GlobalWorkerOptions.workerSrc=path.join(root,'pdf.worker.js');
(async()=>{
 const pdf=await pdfjs.getDocument({data:new Uint8Array(fs.readFileSync(path.join(root,'V190_EOCLIP_REAL_FIXTURE.pdf'))),disableWorker:true,useSystemFonts:true,isEvalSupported:false}).promise;
 try{
  const page=await pdf.getPage(1),viewport=page.getViewport({scale:1}),op=await page.getOperatorList();
  const clipCount=op.fnArray.filter(fn=>fn===pdfjs.OPS.clip||fn===pdfjs.OPS.eoClip).length;
  assert.ok(clipCount>=1,'fixture must exercise the actual PDF.js clip/eoClip operator');
  const paths=await cad.pdfOperatorPathsToCad(page,pdfjs,viewport);
  assert.ok(paths.length>=2,'the clipped stroke and clipped fill must both survive');
  const all=paths.flatMap(p=>p.points);
  assert.ok(all.every(p=>p.x>=39.9&&p.x<=140.1&&p.y>=79.9&&p.y<=180.1),'no converted point may escape the PDF clipping rectangle');
  assert.ok(paths.some(p=>p.filled),'clipped fill must remain editable geometry');
  const dxf=cad.polylinesToDxf(paths,viewport.width,viewport.height,1,[]),txt=new TextDecoder('windows-1252').decode(dxf.bytes);
  fs.writeFileSync(path.join(root,'V190_EOCLIP_REAL_TEST.dxf'),Buffer.from(dxf.bytes));
  assert.match(txt,/\nLWPOLYLINE\r?\n/);assert.match(txt,/\nHATCH\r?\n/);
  assert.doesNotMatch(txt,/\nIMAGE(?:\r?\n|$)|\nIMAGEDEF(?:\r?\n|$)/);
  console.log(JSON.stringify({pdfjs:pdfjs.version,actualClipOperators:clipCount,clippedPaths:paths.length,clippedVertices:all.length,allGeometryInsideClip:true,editableHatch:true,imageEntities:0,result:'PASS'},null,2));
 }finally{await pdf.destroy();}
})().catch(e=>{console.error(e);process.exit(1);});
