#!/usr/bin/env python3
"""Create true ezdxf MULTILEADER entities, transform with SurveyQuant JS, compare to ezdxf oracle."""
from __future__ import annotations
import argparse, math, subprocess, sys
from pathlib import Path
import ezdxf
from ezdxf.math import Matrix44, Vec2
from ezdxf.render.mleader import ConnectionSide


def near(a, b, label, tol=1e-7):
    if abs(float(a)-float(b)) > tol:
        raise AssertionError(f"{label}: {a!r} != {b!r} (delta={abs(float(a)-float(b))})")

def vec(a,b,label,tol=1e-7):
    aa=tuple(a);bb=tuple(b)
    if len(aa)!=len(bb): raise AssertionError(f"{label}: vector lengths differ: {len(aa)} vs {len(bb)}")
    for i,(x,y) in enumerate(zip(aa,bb)): near(x,y,f"{label}[{i}]",tol)

def create_input(path: Path):
    doc=ezdxf.new('R2018')
    msp=doc.modelspace()
    doc.layers.new('ANNO_TEXT', dxfattribs={'color':2})
    doc.layers.new('ANNO_BLOCK', dxfattribs={'color':3})
    doc.appids.new('SQ_ORIENT_TEST')
    blk=doc.blocks.new('CALLOUT_ICON')
    blk.add_line((0,0),(2,1), dxfattribs={'layer':'0'})
    blk.add_circle((1,1),0.4,dxfattribs={'layer':'0'})
    text=msp.add_multileader_mtext(dxfattribs={'layer':'ANNO_TEXT'})
    text.set_content(r'Test leader \\H2.5; absolute and \\H0.8x; relative', char_height=2.5)
    text.add_leader_line(ConnectionSide.left, [Vec2(10,10),Vec2(5,10)])
    text.set_connection_properties(landing_gap=0.5,dogleg_length=2)
    text.build(insert=Vec2(2,3))
    text.multileader.set_xdata('SQ_ORIENT_TEST', [(1000,'text-mleader-xdata-preserved')])
    block=msp.add_multileader_block(dxfattribs={'layer':'ANNO_BLOCK'})
    block.set_content('CALLOUT_ICON', scale=1.25)
    block.add_leader_line(ConnectionSide.left, [Vec2(20,20),Vec2(15,20)])
    block.set_connection_properties(landing_gap=0.7,dogleg_length=3)
    block.build(insert=Vec2(12,13), rotation=0.3)
    block.multileader.set_xdata('SQ_ORIENT_TEST', [(1000,'block-mleader-xdata-preserved')])
    doc.saveas(path)
    return [e.dxf.handle for e in msp.query('MULTILEADER')]

def compare_documents(output_path: Path, reference_path: Path, expected_handles: list[str]):
    a=ezdxf.readfile(output_path); b=ezdxf.readfile(reference_path)
    ea={e.dxf.handle:e for e in a.modelspace().query('MULTILEADER')}
    eb={e.dxf.handle:e for e in b.modelspace().query('MULTILEADER')}
    if set(ea)!=set(expected_handles) or set(eb)!=set(expected_handles):
        raise AssertionError(f"Entity handles/count changed: output={sorted(ea)}, reference={sorted(eb)}, expected={sorted(expected_handles)}")
    if {x for x in a.layers.entries.keys()} != {x for x in b.layers.entries.keys()}:
        raise AssertionError('Layer table changed between SurveyQuant output and oracle')
    for handle in expected_handles:
        x,y=ea[handle],eb[handle]
        label=f'MULTILEADER handle {handle}'
        for attr in ('layer','content_type','scale','arrow_head_size','dogleg_length','block_rotation','block_scale_vector','has_landing','has_dogleg'):
            if not x.dxf.hasattr(attr) and not y.dxf.hasattr(attr): continue
            vx=x.dxf.get(attr);vy=y.dxf.get(attr)
            if isinstance(vx,(int,float)) and isinstance(vy,(int,float)): near(vx,vy,f'{label} dxf.{attr}')
            elif hasattr(vx,'__iter__') and hasattr(vy,'__iter__') and not isinstance(vx,str): vec(vx,vy,f'{label} dxf.{attr}')
            elif vx!=vy: raise AssertionError(f'{label} dxf.{attr}: {vx!r} != {vy!r}')
        if x.get_xdata('SQ_ORIENT_TEST') != y.get_xdata('SQ_ORIENT_TEST'):
            raise AssertionError(f'{label}: XData changed')
        cx,cy=x.context,y.context
        for attr in ('base_point','plane_origin','plane_x_axis','plane_y_axis'):
            vec(getattr(cx,attr),getattr(cy,attr),f'{label} context.{attr}')
        for attr in ('scale','char_height','arrow_head_size','landing_gap_size'):
            near(getattr(cx,attr),getattr(cy,attr),f'{label} context.{attr}')
        if (cx.mtext is None)!=(cy.mtext is None) or (cx.block is None)!=(cy.block is None):
            raise AssertionError(f'{label}: MText/block content type changed')
        if cx.mtext:
            for attr in ('default_content','insert','text_direction','rotation','width','line_spacing_factor','line_spacing_style'):
                vx=getattr(cx.mtext,attr);vy=getattr(cy.mtext,attr)
                if isinstance(vx,(int,float)): near(vx,vy,f'{label} mtext.{attr}')
                elif hasattr(vx,'__iter__') and not isinstance(vx,str): vec(vx,vy,f'{label} mtext.{attr}')
                elif vx!=vy: raise AssertionError(f'{label} mtext.{attr}: {vx!r} != {vy!r}')
        if cx.block:
            for attr in ('block_record_handle','insert','scale','rotation'):
                vx=getattr(cx.block,attr);vy=getattr(cy.block,attr)
                if isinstance(vx,(int,float)): near(vx,vy,f'{label} block.{attr}')
                elif hasattr(vx,'__iter__') and not isinstance(vx,str): vec(vx,vy,f'{label} block.{attr}')
                elif vx!=vy: raise AssertionError(f'{label} block.{attr}: {vx!r} != {vy!r}')
            vec(tuple(cx.block.matrix44),tuple(cy.block.matrix44),f'{label} block.matrix44')
        if len(cx.leaders)!=len(cy.leaders): raise AssertionError(f'{label}: leader count changed')
        for li,(lx,ly) in enumerate(zip(cx.leaders,cy.leaders)):
            vec(lx.last_leader_point,ly.last_leader_point,f'{label} leader[{li}].last_leader_point')
            vec(lx.dogleg_vector,ly.dogleg_vector,f'{label} leader[{li}].dogleg_vector')
            near(lx.dogleg_length,ly.dogleg_length,f'{label} leader[{li}].dogleg_length')
            if len(lx.lines)!=len(ly.lines): raise AssertionError(f'{label}: leader line count changed')
            for lli,(llx,lly) in enumerate(zip(lx.lines,ly.lines)):
                if len(llx.vertices)!=len(lly.vertices): raise AssertionError(f'{label}: leader vertices changed count')
                for vi,(vx,vy) in enumerate(zip(llx.vertices,lly.vertices)):
                    vec(vx,vy,f'{label} leader[{li}].line[{lli}].vertex[{vi}]')
    print('PASS REAL-DXF ORACLE: SurveyQuant output matches ezdxf’s official MULTILEADER transform for text and block content, including placement, scale, rotation, vectors, leader lines, matrix, layer and XData.')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--html',type=Path,required=True)
    p.add_argument('--js-runner',type=Path,required=True)
    p.add_argument('--work-dir',type=Path,required=True)
    a=p.parse_args();a.work_dir.mkdir(parents=True,exist_ok=True)
    inp=a.work_dir/'real-mleader-input.dxf';out=a.work_dir/'real-mleader-surveyquant.dxf';ref=a.work_dir/'real-mleader-ezdxf-reference.dxf'
    handles=create_input(inp)
    # The point-pair transform is scale 2 + 90-degree rotation, with source (0,0)->(100,200).
    subprocess.run(['node',str(a.js_runner),str(a.html),str(inp),str(out)],check=True)
    doc=ezdxf.readfile(inp)
    mat=Matrix44.chain(Matrix44.scale(2),Matrix44.z_rotate(math.pi/2),Matrix44.translate(100,200,0))
    for e in doc.modelspace().query('MULTILEADER'):
        e.transform(mat)
    doc.saveas(ref)
    compare_documents(out,ref,handles)

if __name__=='__main__':main()
