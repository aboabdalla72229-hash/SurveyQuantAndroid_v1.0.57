SurveyQuant V1.0.148 - Orientation / DWG / 3D alignment fix

رفع الملفات:
1) ارفع SurveyQuant_v1.0.148_ORIENTATION_DWG_FULL_FIX_PATCH_KIT.zip إلى جذر المستودع.
2) ارفع build-v148-orientation-dwg-full-fix.yml إلى .github/workflows/build-v148-orientation-dwg-full-fix.yml.
3) افتح Actions وشغّل Build SurveyQuant v1.0.148 - Orientation + DWG + 3D Alignment Fix.
4) بعد نجاح البناء نزّل Artifact: SurveyQuant-v1.0.148-ORIENTATION-DWG-3D-ALIGNMENT-FIX.

الحزمة تحتوي patcher V147 المطلوب كمرحلة أساسية من V146، ثم patcher V148، والاختبارات ومعبّئ APK.

ملاحظات هندسية:
- التحويل بنقطتين يطابق النقطتين تحت similarity transform (دوران + مقياس موحد + إزاحة). لا يتم قص الإحداثيات السالبة تعسفيًا لأن ذلك يكسر التطابق.
- اختبار DWG في هذه الحزمة يختبر مسار التحويل والـWASM stub. لم يتم إرفاق ملف DWG الإنتاجي للمستخدم أو توقيع APK عبر Actions هنا.
- Proxy / Civil 3D objects whose geometry isn't exposed by the DWG-to-DXF engine may not survive as full native CAD objects.
