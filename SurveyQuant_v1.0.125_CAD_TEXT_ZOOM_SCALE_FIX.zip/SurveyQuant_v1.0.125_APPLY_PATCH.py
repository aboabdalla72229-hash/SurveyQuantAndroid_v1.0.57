#!/usr/bin/env python3
"""V125: inverse-zoom CAD text preview on both orientation canvases, without mutating drawing data."""
from pathlib import Path
import re
import sys

MANUAL_LOOP_OLD = "for(const t of drawing.texts){const p=toScreen(t.p,m);if(p.x<0||p.x>m.w||p.y<0||p.y>m.h)continue;ctx.fillStyle='#e9c46a';ctx.font='11px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);}"
MANUAL_LOOP_V123 = "for(const t of drawing.texts){const p=toScreen(t.p,m);if(p.x<0||p.x>m.w||p.y<0||p.y>m.h)continue;const textPixels=sqV123TextPixelHeight(t.height,m.scale);if(!Number.isFinite(textPixels)||textPixels<=0)continue;ctx.fillStyle='#e9c46a';ctx.font=textPixels+'px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);}"
MANUAL_LOOP_V124 = "for(const t of drawing.texts){const p=toScreen(t.p,m);if(p.x<0||p.x>m.w||p.y<0||p.y>m.h)continue;const textPixels=sqV124TextPixelHeight(t.height,m.scale);if(!Number.isFinite(textPixels)||textPixels<=0)continue;ctx.fillStyle='#e9c46a';ctx.font=textPixels+'px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);}"
MANUAL_LOOP_NEW = "for(const t of drawing.texts){const p=toScreen(t.p,m);if(p.x<0||p.x>m.w||p.y<0||p.y>m.h)continue;const textPixels=sqV125ManualTextPixelHeight(t.height,m.scale,zoom);if(!Number.isFinite(textPixels)||textPixels<=0)continue;ctx.fillStyle='#e9c46a';ctx.font=textPixels+'px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);}"
MANUAL_HELPER = "function sqV125ManualTextPixelHeight(height,scale,zoom){const h0=Number(height),s0=Number(scale),z0=Math.max(0.001,Math.abs(Number(zoom)||1));const h=Number.isFinite(h0)&&h0!==0?Math.abs(h0):2.5;const s=Number.isFinite(s0)&&s0>0?s0:0;const pixels=h*s/(z0*z0);return Number.isFinite(pixels)&&pixels>0?pixels:0;}\n"
REFERENCE_HELPER = "function sqV122NaturalTextPixels(v,t,m,p){/* V125: CAD annotation preview shrinks inversely when the board is zoomed in. Raw entity height and source bytes are untouched. */const raw=Number(t&&t.height),h=Number.isFinite(raw)&&raw!==0?Math.abs(raw):2.5;const z=Math.max(0.001,Math.abs(Number(v&&v.zoom)||1));const b0=Number(m&&m.base),s0=Number(m&&m.scale);const fitScale=Number.isFinite(b0)&&b0>0?b0:(Number.isFinite(s0)&&s0>0?s0/z:0);const pixels=h*fitScale/z;return Number.isFinite(pixels)&&pixels>0?pixels:0;}"
MANUAL_SCRIPT_ID = 'sq-orientation-manual-points-module'
REFERENCE_SCRIPT_ID = 'sq-orientation-reference-board-module'


def count_once(source: str, needle: str, label: str) -> None:
    n = source.count(needle)
    if n != 1:
        raise SystemExit(f'ERROR: {label}: expected exactly one occurrence, found {n}.')


def replace_manual(source: str, label: str) -> str:
    loops = (MANUAL_LOOP_OLD, MANUAL_LOOP_V123, MANUAL_LOOP_V124, MANUAL_LOOP_NEW)
    counts = [source.count(loop) for loop in loops]
    if counts == [1, 0, 0, 0] or counts == [0, 1, 0, 0] or counts == [0, 0, 1, 0]:
        source = source.replace(loops[counts.index(1)], MANUAL_LOOP_NEW, 1)
    elif counts != [0, 0, 0, 1]:
        raise SystemExit(f'ERROR: {label}: ambiguous CAD text renderer. old/V123/V124/V125 counts={counts}.')

    helper_count = source.count('function sqV125ManualTextPixelHeight(')
    if helper_count == 0:
        count_once(source, 'function draw(){', label + ' draw() anchor')
        source = source.replace('function draw(){', MANUAL_HELPER + 'function draw(){', 1)
    elif helper_count != 1:
        raise SystemExit(f'ERROR: {label}: duplicate V125 manual text helpers: {helper_count}.')

    if source.count('function metrics(){') != 1 or 'const scale=base*zoom;' not in source:
        raise SystemExit(f'ERROR: {label}: expected original metrics() with board zoom. Refusing to alter geometry.')
    if source.count('function toScreen(p,m)') != 1:
        raise SystemExit(f'ERROR: {label}: source coordinate projection function is missing.')
    if source.count('function sqV125ManualTextPixelHeight(') != 1 or source.count(MANUAL_LOOP_NEW) != 1:
        raise SystemExit(f'ERROR: {label}: inverse-zoom manual text renderer did not validate.')
    if MANUAL_LOOP_OLD in source or MANUAL_LOOP_V123 in source or MANUAL_LOOP_V124 in source:
        raise SystemExit(f'ERROR: {label}: fixed-size or non-inverse CAD text renderer remains.')
    return source


def replace_js_function(source: str, signature: str, replacement: str, label: str) -> str:
    count_once(source, signature, label + ' function')
    start = source.index(signature)
    brace = source.index('{', start)
    depth = 0
    quote = None
    escaped = False
    end = None
    for i in range(brace, len(source)):
        ch = source[i]
        if quote:
            if escaped:
                escaped = False
            elif ch == '\\':
                escaped = True
            elif ch == quote:
                quote = None
            continue
        if ch in ('"', "'", '`'):
            quote = ch
            continue
        if ch == '{':
            depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0:
                end = i + 1
                break
    if end is None:
        raise SystemExit(f'ERROR: {label}: unterminated JavaScript function.')
    existing = source[start:end]
    if 'V125: CAD annotation preview shrinks inversely' in existing:
        return source
    return source[:start] + replacement + source[end:]


def patch_reference(source: str, label: str) -> str:
    source = replace_js_function(source, 'function sqV122NaturalTextPixels(v,t,m,p)', REFERENCE_HELPER, label)
    count_once(source, 'size=sqV122NaturalTextPixels(v,t,m,p)', label + ' text renderer call')
    if 'function metrics(v)' not in source or 'scale:base*v.zoom' not in source:
        raise SystemExit(f'ERROR: {label}: board-view scale/zoom path missing.')
    if 'function universalTransformBytes(input,t)' not in source:
        raise SystemExit(f'ERROR: {label}: byte-preserving CAD transform missing.')
    return source


def patch_embedded_script(html: str, script_id: str, patch_fn, label: str) -> str:
    pattern = re.compile(r'(<script\b[^>]*\bid=["\']' + re.escape(script_id) + r'["\'][^>]*>)([\s\S]*?)(</script\s*>)', re.I)
    matches = list(pattern.finditer(html))
    if len(matches) != 1:
        raise SystemExit(f'ERROR: index.html: expected exactly one embedded {script_id}, found {len(matches)}.')
    m = matches[0]
    body = patch_fn(m.group(2), label)
    return html[:m.start(2)] + body + html[m.end(2):]


def main() -> int:
    if len(sys.argv) != 4:
        raise SystemExit('usage: SurveyQuant_v1.0.125_APPLY_PATCH.py MANUAL_MODULE.js REFERENCE_MODULE.js INDEX_PATH.html')
    manual_path, reference_path, index_path = map(Path, sys.argv[1:])
    manual = replace_manual(manual_path.read_text(encoding='utf-8'), manual_path.name)
    reference = patch_reference(reference_path.read_text(encoding='utf-8'), reference_path.name)
    html = index_path.read_text(encoding='utf-8')
    html = patch_embedded_script(html, MANUAL_SCRIPT_ID, replace_manual, 'index.html embedded manual renderer')
    html = patch_embedded_script(html, REFERENCE_SCRIPT_ID, patch_reference, 'index.html embedded dual-board renderer')

    # The same source text renderer must be present in the standalone modules and in the HTML Android WebView actually loads.
    for label, source in [('manual module', manual), ('reference module', reference), ('index.html', html)]:
        if 'function universalTransformBytes(input,t)' not in source:
            # The helper module itself does not always own the transform; it is checked on the integrated page below.
            if label == 'index.html':
                raise SystemExit('ERROR: index.html lost the byte-preserving CAD transform.')
        if label == 'manual module' or label == 'index.html':
            if 'function sqV125ManualTextPixelHeight(' not in source:
                raise SystemExit(f'ERROR: {label} missing inverse-zoom legacy renderer.')
        if label == 'reference module' or label == 'index.html':
            if 'V125: CAD annotation preview shrinks inversely' not in source:
                raise SystemExit(f'ERROR: {label} missing inverse-zoom dual-board renderer.')

    manual_path.write_text(manual, encoding='utf-8')
    reference_path.write_text(reference, encoding='utf-8')
    index_path.write_text(html, encoding='utf-8')
    print('PASS V125: CAD entity text in both orientation previews shrinks inversely as board zoom increases (1x / 2x / 4x).')
    print('PASS V125: text height is preview-only; source entity records, layers, and original bytes are not written or transformed by zoom.')
    print('PASS V125: fixed 11px CAD font and zoom-growing V122 preview formula are gone from active entity text loops.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
