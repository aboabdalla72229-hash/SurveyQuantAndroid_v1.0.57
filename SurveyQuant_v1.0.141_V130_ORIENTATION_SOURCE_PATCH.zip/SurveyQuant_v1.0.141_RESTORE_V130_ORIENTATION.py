#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, hashlib, re, struct, zipfile
from pathlib import Path

SCRIPT_IDS = (
    "sq-orientation-module",
    "sq-orientation-axis-reader-module",
    "sq-orientation-manual-points-module",
    "sq-orientation-reference-board-module",
    "sq-orientation-dxf-faithful-recovery-module",
    "sq-orientation-cad-preserve-module",
    "sq-orientation-v115-tools-module",
)
OLD_CODE, NEW_CODE = 140, 141
OLD_NAME, NEW_NAME = "1.0.140", "1.0.141"

def pattern(script_id: str) -> re.Pattern[str]:
    return re.compile(r'(<script\b(?=[^>]*\bid=["\']' + re.escape(script_id) + r'["\'])[^>]*>)([\s\S]*?)(</script\s*>)', re.I)

def script_body(html: str, script_id: str) -> str:
    found = list(pattern(script_id).finditer(html))
    if len(found) != 1:
        raise ValueError(f"Expected exactly one script {script_id!r}, got {len(found)}")
    return found[0].group(2)

def replace_body(html: str, script_id: str, body: str) -> str:
    matches = list(pattern(script_id).finditer(html))
    if len(matches) != 1:
        raise ValueError(f"Expected exactly one target script {script_id!r}, got {len(matches)}")
    m = matches[0]
    return html[:m.start(2)] + body + html[m.end(2):]

def apply(source: str, reference: str) -> tuple[str, dict[str, str]]:
    result, hashes = source, {}
    for sid in SCRIPT_IDS:
        ref_body = script_body(reference, sid)
        result = replace_body(result, sid, ref_body)
        hashes[sid] = hashlib.sha256(ref_body.encode("utf-8")).hexdigest()
    old = f"const SQ_APP_VERSION_CODE = {OLD_CODE};"
    new = f"const SQ_APP_VERSION_CODE = {NEW_CODE};"
    if result.count(old) != 1:
        raise ValueError(f"Expected exactly one app version constant {old!r}, found {result.count(old)}")
    result = result.replace(old, new, 1)
    if 'id="sq-v117-universal-dwg-bridge"' not in result:
        raise ValueError("V140 universal DWG bridge is missing")
    if "function sqDwgWasmRuntimePath()" not in result:
        raise ValueError("V140 DWG WASM runtime path helper is missing")
    if 'id="surveyquant-v140-fresh-board-session"' not in result:
        raise ValueError("V140 fresh-board session cleanup guard is missing")
    if new not in result:
        raise ValueError("App version was not updated to V141")
    for sid in SCRIPT_IDS:
        if script_body(result, sid) != script_body(reference, sid):
            raise AssertionError(f"V130 orientation module mismatch after transplant: {sid}")
    return result, hashes

def read_len8(data: bytes, pos: int) -> tuple[int, int]:
    first = data[pos]
    if first & 0x80: return (((first & 0x7F) << 8) | data[pos + 1]), pos + 2
    return first, pos + 1

def read_len16(data: bytes, pos: int) -> tuple[int, int]:
    first = struct.unpack_from("<H", data, pos)[0]
    if first & 0x8000:
        second = struct.unpack_from("<H", data, pos + 2)[0]
        return (((first & 0x7FFF) << 16) | second), pos + 4
    return first, pos + 2

def patch_manifest(manifest: bytes) -> bytes:
    if len(manifest) < 8 or struct.unpack_from("<H", manifest, 0)[0] != 0x0003:
        raise ValueError("AndroidManifest.xml is not Android binary XML")
    result = bytearray(manifest)
    pos = struct.unpack_from("<H", result, 2)[0]
    total = struct.unpack_from("<I", result, 4)[0]
    if total > len(result) or total < pos: raise ValueError("Invalid Android binary XML size")
    strings, spans, chunks = None, [], []
    while pos < total:
        if pos + 8 > total: raise ValueError("Truncated Android XML chunk")
        kind, header, size = struct.unpack_from("<HHI", result, pos)
        if size < header or pos + size > total: raise ValueError("Invalid Android XML chunk bounds")
        chunks.append((pos, kind, header, size))
        if kind == 0x0001:
            count, _styles, flags, strings_start, _styles_start = struct.unpack_from("<IIIII", result, pos + 8)
            if count > 100000: raise ValueError("Unreasonable string count")
            offsets_start, base = pos + header, pos + strings_start
            utf8 = bool(flags & 0x100)
            strings = []
            spans = []
            for i in range(count):
                rel = struct.unpack_from("<I", result, offsets_start + i * 4)[0]
                p = base + rel
                if utf8:
                    _chars, p = read_len8(result, p)
                    byte_len, p = read_len8(result, p)
                    begin, end = p, p + byte_len
                    strings.append(bytes(result[begin:end]).decode("utf-8", "strict"))
                    spans.append((begin, end, True))
                else:
                    char_len, p = read_len16(result, p)
                    begin, end = p, p + char_len * 2
                    strings.append(bytes(result[begin:end]).decode("utf-16le", "strict"))
                    spans.append((begin, end, False))
        pos += size
    if strings is None: raise ValueError("Android XML string pool missing")
    old_ids = [i for i, value in enumerate(strings) if value == OLD_NAME]
    if not old_ids and NEW_NAME not in strings:
        raise ValueError(f"Manifest has neither {OLD_NAME} nor {NEW_NAME}")
    for i in old_ids:
        begin, end, is_utf8 = spans[i]
        encoded = NEW_NAME.encode("utf-8" if is_utf8 else "utf-16le")
        if len(encoded) != end - begin: raise ValueError("Version-name replacement changes string length")
        result[begin:end] = encoded
        strings[i] = NEW_NAME
    fields = []
    for chunk_pos, kind, _header, size in chunks:
        if kind != 0x0102 or size < 36: continue
        name_idx = struct.unpack_from("<I", result, chunk_pos + 20)[0]
        if name_idx >= len(strings) or strings[name_idx] != "manifest": continue
        attr_start = struct.unpack_from("<H", result, chunk_pos + 24)[0]
        attr_size = struct.unpack_from("<H", result, chunk_pos + 26)[0]
        attr_count = struct.unpack_from("<H", result, chunk_pos + 28)[0]
        if attr_size < 20 or attr_count > 1024: raise ValueError("Invalid manifest attribute table")
        first = chunk_pos + 16 + attr_start
        for n in range(attr_count):
            at = first + n * attr_size
            name = struct.unpack_from("<I", result, at + 4)[0]
            if name < len(strings) and strings[name] == "versionCode":
                value_size, value_type = struct.unpack_from("<H", result, at + 12)[0], result[at + 15]
                if value_size < 8 or value_type not in (0x10, 0x11): raise ValueError("versionCode is not integer typed")
                fields.append(at + 16)
    if len(fields) != 1: raise ValueError(f"Expected one versionCode attribute, found {len(fields)}")
    struct.pack_into("<I", result, fields[0], NEW_CODE)
    return bytes(result)

def package_apk(input_apk: Path, output_apk: Path, html_path: Path) -> None:
    html_bytes = html_path.read_bytes()
    html = html_bytes.decode("utf-8")
    if 'const SQ_APP_VERSION_CODE = 141;' not in html or 'id="surveyquant-v140-fresh-board-session"' not in html:
        raise ValueError("Injected HTML is missing the V141 version or fresh-session guard")
    output_apk.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(input_apk, "r") as zin:
        names = [i.filename for i in zin.infolist()]
        if names.count("assets/index.html") != 1 or names.count("AndroidManifest.xml") != 1:
            raise ValueError("Base APK must contain one index.html and AndroidManifest.xml")
        seen = set()
        with zipfile.ZipFile(output_apk, "w", allowZip64=True) as zout:
            for info in zin.infolist():
                name = info.filename
                if name in seen: raise ValueError("Duplicate ZIP entry: " + name)
                seen.add(name)
                upper = name.upper()
                if upper.startswith("META-INF/") and (upper.endswith(".SF") or upper.endswith(".RSA") or upper.endswith(".DSA") or upper.endswith(".EC") or upper.endswith("MANIFEST.MF")):
                    continue
                data = zin.read(name)
                if name == "assets/index.html": data = html_bytes
                elif name == "AndroidManifest.xml": data = patch_manifest(data)
                zout.writestr(copy.copy(info), data)
    with zipfile.ZipFile(output_apk, "r") as check:
        if check.read("assets/index.html") != html_bytes: raise ValueError("APK HTML bytes do not match tested HTML")
        if patch_manifest(check.read("AndroidManifest.xml")) != check.read("AndroidManifest.xml"):
            raise ValueError("APK manifest version is not V141")
        if "assets/libredwg-writer/wasm/libredwg-web.wasm" not in check.namelist():
            raise ValueError("APK lost DWG WebAssembly runtime")
    print("PASS: packaged exact tested HTML, manifest versionName 1.0.141/versionCode 141, and retained DWG WASM runtime")

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-html", type=Path)
    ap.add_argument("--reference-html", type=Path)
    ap.add_argument("--output-html", type=Path)
    ap.add_argument("--apk-input", type=Path)
    ap.add_argument("--apk-output", type=Path)
    ap.add_argument("--html-to-inject", type=Path)
    args = ap.parse_args()
    if args.source_html and args.reference_html and args.output_html and not args.apk_input:
        patched, hashes = apply(args.source_html.read_text(encoding="utf-8"), args.reference_html.read_text(encoding="utf-8"))
        args.output_html.parent.mkdir(parents=True, exist_ok=True)
        args.output_html.write_text(patched, encoding="utf-8", newline="")
        for sid, digest in hashes.items(): print(f"PASS {sid} sha256={digest}")
        print("PASS: transplanted all seven V130 orientation modules; preserved V140 DWG bridge and fresh-session guard")
        return
    if args.apk_input and args.apk_output and args.html_to_inject:
        package_apk(args.apk_input, args.apk_output, args.html_to_inject)
        return
    ap.error("Use --source-html CURRENT --reference-html V130 --output-html OUT, or --apk-input APK --apk-output APK --html-to-inject HTML")
if __name__ == "__main__": main()
