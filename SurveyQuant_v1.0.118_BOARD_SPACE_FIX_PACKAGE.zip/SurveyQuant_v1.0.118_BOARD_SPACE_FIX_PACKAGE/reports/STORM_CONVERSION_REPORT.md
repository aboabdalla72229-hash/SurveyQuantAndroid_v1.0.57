# STORM DWG direct-conversion regression test

Executed against the writer-enabled LibreDWG-Web build that the APK will use. Passing this test confirms both input drawings convert to text DXF with entity and XY records; it does not certify every proprietary/proxy object or every visual property in every CAD application.

## Case 1

- Input: STORM ╪║┘К╪▒ ┘Е┘И╪м┘З┘З.dwg
- Result: PASS
- Input size: 1044855 bytes
- DWG signature: AC1032
- SHA-256: bda1107966cbd4976566bdd58cb7dc473fdd8328c235ff218c75cc424083dcb0
- Output size: 4757727 bytes
- Source model-space entity count (report-only): 1071
- Converted DXF entity records: 1128
- Source minus converted count (report-only): -57
- XY coordinate records: 7182
- Layers: 36
- Text payloads: 168
- EOF present: true
- Output file: STORM_1_converted.dxf

## Case 2

- Input: ┘Б┘Д┘Ж╪┤╪з╪к ╪к┘Ж┘Г STORM.dwg
- Result: PASS
- Input size: 1016253 bytes
- DWG signature: AC1024
- SHA-256: 86f09ea8fe7f8259479509a3cbf08b899e118127e2e4b02f8a61219356df2a84
- Output size: 1824112 bytes
- Source model-space entity count (report-only): 216
- Converted DXF entity records: 216
- Source minus converted count (report-only): 0
- XY coordinate records: 928
- Layers: 24
- Text payloads: 49
- EOF present: true
- Output file: STORM_2_converted.dxf


OVERALL: PASS for both user-provided STORM DWG inputs.

# STORM real-DXF orientation-engine test

This second regression test runs the app’s actual v111/v113 byte-preserving transform engine against both converted user-provided STORM boards using a known non-zero rotation and translation. It verifies that group-pair count and entity type sequence remain unchanged and that non-geometric pair values stay unchanged. Test transformation outputs are marked `ORIENTATION_ENGINE_TEST` and must not be used as the final site alignment because the points are generated for regression testing.

## Board 1: STORM_1_converted.dxf

- Result: PASS
- Test output: STORM_1_converted_ORIENTATION_ENGINE_TEST.dxf
- Entity records: 1129
- Group/value pairs: 289023
- Geometric values changed: 9344
- Non-geometric values changed: 0

## Board 2: STORM_2_converted.dxf

- Result: PASS
- Test output: STORM_2_converted_ORIENTATION_ENGINE_TEST.dxf
- Entity records: 217
- Group/value pairs: 83077
- Geometric values changed: 1259
- Non-geometric values changed: 0
