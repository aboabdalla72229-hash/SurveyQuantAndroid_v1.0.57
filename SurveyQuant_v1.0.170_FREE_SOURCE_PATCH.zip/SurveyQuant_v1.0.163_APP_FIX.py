#!/usr/bin/env python3
"""Patch the real SurveyQuant app's two-file CAD projection to merge raw DXF records."""
from __future__ import annotations
import argparse
from pathlib import Path

NEW_FUNCTION = r'''async function dropFilesMerge(){
 const progress=document.getElementById('dropFilesProgress');
 const results=document.getElementById('dropFilesResults');
 const summary=document.getElementById('dropFilesSummary');
 try{
  droppedDXF='';if(results)results.style.display='none';
  const src=document.getElementById('dropSurveyFiles').files[0],cad=document.getElementById('dropCadFile').files[0];
  if(!src||!cad)return alert('اختر ملف الإسقاط في الخانة الأولى ولوحة DWG/DXF المرجعية في الخانة الثانية.');
  const sourceExt=String(src.name).split('.').pop().toLowerCase(),targetExt=String(cad.name).split('.').pop().toLowerCase();
  const sourceIsCad=['dwg','dxf'].includes(sourceExt),targetIsCad=['dwg','dxf'].includes(targetExt);
  if(!targetIsCad)throw new Error('الخانة الثانية يجب أن تكون لوحة DWG أو DXF.');
  if(progress){progress.style.display='block';progress.textContent='⏳ جاري قراءة اللوحة المرجعية وتحويل DWG إلى DXF دون تحليل هندسي كامل...';}
  await new Promise(r=>setTimeout(r,20));
  const targetModel=await parseFile(cad,{rawOnly:true,conversionOnly:true,retainRawDWG:false});
  const targetBytes=targetModel?.rawDXFBytes instanceof Uint8Array?targetModel.rawDXFBytes:(targetModel?.rawDXFBytes?new Uint8Array(targetModel.rawDXFBytes):null);
  if(!targetBytes?.length)throw new Error('لم ينتج محرك CAD ملف DXF صالحًا من اللوحة المرجعية. لم يتم تعديل الملف الأصلي.');
  if(sourceIsCad){
   if(progress){progress.textContent='⏳ جاري تحويل اللوحة الأولى إلى DXF خام...';await new Promise(r=>setTimeout(r,20));}
   const sourceModel=await parseFile(src,{rawOnly:true,conversionOnly:true,retainRawDWG:false});
   const sourceBytes=sourceModel?.rawDXFBytes instanceof Uint8Array?sourceModel.rawDXFBytes:(sourceModel?.rawDXFBytes?new Uint8Array(sourceModel.rawDXFBytes):null);
   if(!sourceBytes?.length)throw new Error('لم ينتج محرك CAD ملف DXF صالحًا من اللوحة الأولى. لم يتم تعديل الملف الأصلي.');
   const engine=window.SurveyQuantCAD163;
   if(!engine||typeof engine.mergeRawDxfBoards!=='function')throw new Error('محرك الدمج الخام غير موجود في هذه النسخة.');
   if(progress){progress.textContent='⏳ جاري دمج سجلات الكيانات والبلوكات والليارات دون إعادة رسم...';await new Promise(r=>setTimeout(r,20));}
   const merged=engine.mergeRawDxfBoards(targetBytes,sourceBytes);
   droppedDXF=merged.bytes;const addedCad=merged.importedEntities||0;
   const outText=new TextDecoder('windows-1252').decode(droppedDXF);
   if(!/\bEOF\s*$/.test(outText.trim()))throw new Error('فشل التحقق النهائي من نهاية ملف DXF المدمج.');
   if(summary)summary.innerHTML=`تم دمج اللوحة <b>${escapeHtml(src.name)}</b> داخل <b>${escapeHtml(cad.name)}</b>.<br>سجلات عناصر المصدر: <b>${addedCad}</b> | تعريفات بلوكات مستوردة: <b>${merged.importedBlocks}</b> | طبقات جديدة: <b>${merged.importedLayers}</b>.<br><span class="muted">تم نسخ سجلات المصدر الأصلية من DXF الناتج عن المحول، مع إعادة ربط المقابض وأسماء الطبقات والأنماط والبلوكات المتعارضة. لم تُعد رسم عناصر المصدر أو المرجع. ملف الإخراج DXF، لذلك لا يكون نسخة ثنائية مطابقة لملفي DWG الأصليين. إذا احتوت اللوحة على مراجع خارجية أو كائنات لا يمكن ربطها بأمان، يوقف المحرك العملية بدل إسقاط بيانات ناقصة.</span>`;
  }else{
   if(progress){progress.textContent='⏳ جاري قراءة نقاط الملف الأول...';await new Promise(r=>setTimeout(r,20));}
   const sourceModel=await parseFile(src,{retainRawDWG:false});
   const additions=[];let addedPoints=0;
   if(Array.isArray(sourceModel.points)&&sourceModel.points.length){const ps=getPointStyleSettings();for(const p of sourceModel.points){addPointDetailEntities(additions,{e:Number(p.e),n:Number(p.n),z:Number(p.z||0),id:p.id||('P'+(addedPoints+1))},ps);addedPoints++;}}
   if(!additions.length)throw new Error('الملف الأول ليس DWG/DXF ولم أجد فيه نقاطًا مساحية مدعومة.');
   if(progress){progress.textContent='⏳ جاري إضافة النقاط مع الحفاظ على اللوحة المرجعية...';await new Promise(r=>setTimeout(r,20));}
   droppedDXF=mergeProjectionDxfPreservingReference(targetBytes,additions);
   const checkText=new TextDecoder('windows-1252').decode(droppedDXF);
   const validationIssue=inspectPreservedReferenceDXF(checkText);if(validationIssue)throw new Error(validationIssue+' تم إيقاف التصدير لحماية تفاصيل اللوحة المرجعية.');
   if(summary)summary.innerHTML=`تم إسقاط <b>${escapeHtml(src.name)}</b> على <b>${escapeHtml(cad.name)}</b>.<br>نقاط مضافة: <b>${addedPoints}</b>.<br><span class="muted">تم الحفاظ على سجلات اللوحة المرجعية وخصائصها الأصلية؛ أُضيفت النقاط فقط. الإحداثيات ثابتة: X = Easting (E) وY = Northing (N).</span>`;
  }
  if(results)results.style.display='block';
 }catch(e){console.error('dropFilesMerge',e);alert('تعذر إسقاط الملف على اللوحة: '+(e?.message||e));}
 finally{if(progress)progress.style.display='none';}
}'''

MARKERS = [
    'function parseDWGDatabase(db,options={}){',
    'window.parseFile = parseFile;',
    'sqV161RawReferenceOnly',
    'sq162-wasm-binary',
]

def apply(html: str) -> str:
    if 'sq163RawCadOverlayMerge' in html:
        raise ValueError('V163 app overlay patch already exists; refusing duplicate insertion.')
    for marker in MARKERS:
        if marker not in html:
            raise ValueError(f'Missing expected V161/V162 app marker: {marker}')
    start=html.find('async function dropFilesMerge(){')
    end=html.find('\nfunction downloadDroppedDXF()',start)
    if start<0 or end<=start:
        raise ValueError('Could not locate the original dropFilesMerge function.')
    old=html[start:end]
    if 'engine.mergeRawDxfBoards' in old:
        raise ValueError('Raw CAD merge path already exists; refusing duplicate replacement.')
    patched=html[:start]+NEW_FUNCTION+html[end:]
    patched=patched.replace('/* sqV161RawReferenceOnly: reference boards use a raw-preserving, conversion-only path. */', '/* sqV161RawReferenceOnly: reference boards use a raw-preserving, conversion-only path. */\n/* sq163RawCadOverlayMerge: DWG/DXF pairs are converted to DXF bytes and merged by raw records. */', 1)
    if patched.count('sq163RawCadOverlayMerge')!=1:
        raise ValueError('V163 patch marker insertion failed.')
    return patched

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--html',required=True,type=Path)
    p.add_argument('--check-only',action='store_true')
    a=p.parse_args();src=a.html.read_text(encoding='utf-8')
    if a.check_only:
        if 'sq163RawCadOverlayMerge' not in src or 'engine.mergeRawDxfBoards(targetBytes,sourceBytes)' not in src:
            raise SystemExit('V163 raw CAD overlay path is not active.')
        print('PASS V163 app patch: both CAD inputs use conversion-only raw DXF records; point-file projection remains supported.')
        return
    out=apply(src);a.html.write_text(out,encoding='utf-8')
    print(f'PASS V163 app patch: updated dropFilesMerge without changing its original point-file projection path ({len(out):,} characters).')
if __name__=='__main__': main()
