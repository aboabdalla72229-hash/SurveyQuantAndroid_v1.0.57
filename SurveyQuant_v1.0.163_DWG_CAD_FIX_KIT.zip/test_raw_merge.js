'use strict';
const assert=require('node:assert/strict');
const CAD=require('./SurveyQuant_v1.0.163_CAD_ENGINE.js');
const EOL='\r\n';
const pairs=a=>a.join(EOL)+EOL;
function table(name,handle,rows){return pairs(['0','TABLE','2',name,'5',handle,'330','0','100','AcDbSymbolTable','70',String(rows.length),...rows.flat() ,'0','ENDTAB']);}
function block(name,handle,owner,layer,colorLine){return pairs(['0','BLOCK','5',handle,'330',owner,'100','AcDbEntity','8','0','100','AcDbBlockBegin','2',name,'70','0','10','0','20','0','30','0','0','LINE','5',String(parseInt(handle,16)+1).toString(16).toUpperCase(),'330',owner,'100','AcDbEntity','8',layer,'62',String(colorLine),'100','AcDbLine','10','0','20','0','30','0','11','5','21','5','31','0','0','ENDBLK','5',String(parseInt(handle,16)+2).toString(16).toUpperCase(),'330',owner,'100','AcDbEntity','8','0','100','AcDbBlockEnd']);}
function doc(prefix){
 const target=prefix==='T';
 const modelHandle=target?'21':'121', blockRecordTable=target?'20':'120';
 const layerTable=target?'10':'110', ltypeTable=target?'12':'112', styleTable=target?'14':'114', dimTable=target?'16':'116', appTable=target?'18':'118';
 const blockName='WALLBLOCK', blockRecordHandle=target?'22':'122';
 const lcolor=target?'1':'6',dash=target?'DASH-A':'DASH-B',styleFont=target?'txt.shx':'romans.shx',dimScale=target?'1':'2';
 const b=[];
 b.push(pairs(['0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','9','$HANDSEED','5',target?'8F':'8F','0','ENDSEC']));
 b.push(pairs(['0','SECTION','2','TABLES']));
 b.push(table('BLOCK_RECORD',blockRecordTable,[['0','BLOCK_RECORD','5',modelHandle,'330',blockRecordTable,'100','AcDbSymbolTableRecord','100','AcDbBlockTableRecord','2','*Model_Space','70','0','280','0'],['0','BLOCK_RECORD','5',blockRecordHandle,'330',blockRecordTable,'100','AcDbSymbolTableRecord','100','AcDbBlockTableRecord','2',blockName,'70','0','280','0']]));
 b.push(table('LAYER',layerTable,[['0','LAYER','5',target?'11':'111','330',layerTable,'100','AcDbSymbolTableRecord','100','AcDbLayerTableRecord','2','0','70','0','62','7','6','CONTINUOUS'],['0','LAYER','5',target?'13':'113','330',layerTable,'100','AcDbSymbolTableRecord','100','AcDbLayerTableRecord','2','WALLS','70','0','62',lcolor,'6','CONTINUOUS']]));
 b.push(table('LTYPE',ltypeTable,[['0','LTYPE','5',target?'31':'131','330',ltypeTable,'100','AcDbSymbolTableRecord','100','AcDbLinetypeTableRecord','2','CONTINUOUS','70','0','3','Solid line','72','65','73','0','40','0'],['0','LTYPE','5',target?'32':'132','330',ltypeTable,'100','AcDbSymbolTableRecord','100','AcDbLinetypeTableRecord','2','DASHED','70','0','3',dash,'72','65','73','0','40','1']]));
 b.push(table('STYLE',styleTable,[['0','STYLE','5',target?'41':'141','330',styleTable,'100','AcDbSymbolTableRecord','100','AcDbTextStyleTableRecord','2','STANDARD','70','0','40','0','41','1','50','0','71','0','42','2.5','3',styleFont,'4','']]));
 b.push(table('DIMSTYLE',dimTable,[['0','DIMSTYLE','105',target?'51':'151','330',dimTable,'100','AcDbSymbolTableRecord','100','AcDbDimStyleTableRecord','2','STANDARD','3','STANDARD','70','0','40',dimScale]]));
 b.push(table('APPID',appTable,[['0','APPID','5',target?'61':'161','330',appTable,'100','AcDbSymbolTableRecord','100','AcDbRegAppTableRecord','2','ACAD','70','0'],['0','APPID','5',target?'62':'162','330',appTable,'100','AcDbSymbolTableRecord','100','AcDbRegAppTableRecord','2',target?'TARGET_APP':'TARGET_APP','70',target?'0':'1']]));
 b.push(pairs(['0','ENDSEC']));
 b.push(pairs(['0','SECTION','2','BLOCKS']));
 if(target)b.push(block(blockName,'70',blockRecordHandle,'WALLS',2));else b.push(block(blockName,'170',blockRecordHandle,'WALLS',6));
 b.push(pairs(['0','ENDSEC']));
 b.push(pairs(['0','SECTION','2','ENTITIES']));
 if(target){
   b.push(pairs(['0','LINE','5','80','330',modelHandle,'100','AcDbEntity','8','WALLS','6','CONTINUOUS','100','AcDbLine','10','100','20','100','30','0','11','200','21','200','31','0']));
 }else{
   b.push(pairs(['0','LINE','5','180','330',modelHandle,'100','AcDbEntity','8','WALLS','6','DASHED','100','AcDbLine','10','1','20','2','30','0','11','11','21','12','31','0','1001','TARGET_APP','1000','SOURCE RAW TEXT']));
   b.push(pairs(['0','INSERT','5','181','330',modelHandle,'100','AcDbEntity','8','WALLS','100','AcDbBlockReference','2','WALLBLOCK','10','20','20','30','30','0','41','1','42','1','43','1','50','0']));
 }
 b.push(pairs(['0','ENDSEC','0','EOF']));
 return new TextEncoder().encode(b.join(''));
}
const target=doc('T'),source=doc('S');
const out=CAD.mergeRawDxfBoards(target,source);
const text=new TextDecoder('windows-1252').decode(out.bytes);
assert.ok(text.includes('TARGET RAW')===false);
assert.ok(text.includes('SOURCE RAW TEXT'),'source raw XDATA/text group copied');
assert.ok(text.includes('SQ163_WALLS'),'colliding layer was renamed safely');
assert.ok(text.includes('SQ163_DASHED'),'colliding linetype was renamed safely');
assert.ok(text.includes('SQ163_STANDARD'),'colliding style/dimstyle records should be renamed safely');
assert.ok(text.includes('SQ163_WALLBLOCK'),'colliding block was renamed safely');
assert.ok(text.includes('SQ163_TARGET_APP'),'source APPID conflict should be renamed');
assert.ok(text.includes('0\r\nLINE\r\n5\r\n80\r\n330\r\n21'),'target entity handle and modelspace owner stay intact');
assert.ok(text.includes('1000\r\nSOURCE RAW TEXT'),'source XDATA string stays intact');
assert.equal((text.match(/\r\nSOURCE RAW TEXT\r\n/g)||[]).length,1);
assert.ok(out.importedBlocks>=1,'source block definition imported');
assert.ok(out.importedTableRecords.BLOCK_RECORD>=1,'source block record imported');
assert.ok(out.bytes.length>target.length,'merged DXF contains source data');
// Every handle appearing in entity/block/table record locations is unique in the fixture.
const handles=[];const lines=text.split(/\r?\n/);for(let i=0;i+1<lines.length;i+=2){if(lines[i]==='5'||lines[i]==='105'){const v=lines[i+1];if(/^[0-9A-F]+$/i.test(v))handles.push(v.toUpperCase());}}
assert.equal(handles.length,new Set(handles).size,'DXF object handles stay unique after merge');
console.log('PASS V163 raw DWG/DXF overlay merge: original target records retained; source ENTITIES/BLOCKS/LAYER/LTYPE/STYLE/DIMSTYLE/APPID copied without re-drawing; names and handles remapped; structural checks pass.');

// Legacy AC1009/R12 boards may not contain BLOCK_RECORD. They should still merge
// raw BLOCK + INSERT records by renaming conflicting block names, without making
// up modern tables or redrawing the geometry.
const r12 = blocks => [
 '0','SECTION','2','HEADER','9','$ACADVER','1','AC1009','0','ENDSEC',
 '0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','1',
 '0','LAYER','2','0','70','0','62','7','6','CONTINUOUS','0','ENDTAB','0','ENDSEC',
 '0','SECTION','2','BLOCKS', ...blocks.flatMap(name=>['0','BLOCK','2',name,'70','0','10','0','20','0','0','LINE','8','0','10','0','20','0','11','1','21','1','0','ENDBLK','8','0']),
 '0','ENDSEC','0','SECTION','2','ENTITIES','0','ENDSEC','0','EOF',''
].join('\n');
const legacyTarget = new TextEncoder().encode(r12(['B1']));
const legacySource = new TextEncoder().encode([
 '0','SECTION','2','HEADER','9','$ACADVER','1','AC1009','0','ENDSEC',
 '0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','1','0','LAYER','2','0','70','0','62','7','6','CONTINUOUS','0','ENDTAB','0','ENDSEC',
 '0','SECTION','2','BLOCKS','0','BLOCK','2','B1','70','0','10','0','20','0','0','LINE','8','0','10','5','20','5','11','8','21','8','0','ENDBLK','8','0','0','ENDSEC',
 '0','SECTION','2','ENTITIES','0','INSERT','8','0','2','B1','10','10','20','10','0','ENDSEC','0','EOF',''
].join('\n'));
const legacyMerged = CAD.mergeRawDxfBoards(legacyTarget, legacySource);
const legacyText = new TextDecoder().decode(legacyMerged.bytes);
assert.ok(legacyText.includes('2\nSQ163_B1'), 'legacy block name conflict is remapped');
assert.ok(legacyText.includes('2\nSQ163_B1\n10\n10\n20\n10'), 'legacy INSERT points to the remapped raw block');
assert.equal((legacyText.match(/0\nBLOCK\n/g)||[]).length,2,'legacy target block and imported source block are both present');
assert.ok(!legacyText.includes('2\nBLOCK_RECORD'),'legacy output does not invent a BLOCK_RECORD table');
console.log('PASS V163 legacy R12 raw block merge without BLOCK_RECORD.');
