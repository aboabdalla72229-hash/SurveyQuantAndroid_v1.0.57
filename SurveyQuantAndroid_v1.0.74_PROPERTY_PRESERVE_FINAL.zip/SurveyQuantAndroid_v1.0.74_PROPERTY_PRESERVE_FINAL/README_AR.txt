SurveyQuant Pro - v1.0.67 Property Preserve

هذه النسخة مبنية على مصدر v1.0.67 وتعدل فقط مرحلة إخراج مشروع إسقاط الملفات للحفاظ على خصائص لوحة DXF المرجعية.
منطق الإسقاط والإحداثيات X/Y في v1.0.67 لم يتم تغييره.

SurveyQuant Pro - Android WebView Wrapper

النسخة الحالية تغلف SurveyQuant_Suite_PRO_V18.html داخل تطبيق Android.
Target SDK = 33، Min SDK = 23.

مهم: ملف APK النهائي غير مُضمّن لأن بيئة البناء Android SDK/Gradle غير متاحة في جلسة إنشاء الملف الحالية.
عند فتح المشروع في Android Studio أو أي بيئة Gradle، نفّذ:
./gradlew assembleDebug
وسيخرج APK داخل app/build/outputs/apk/debug/.

الدفع والـBackend:
الواجهة الحالية لا تحتوي مفاتيح دفع سرية. يجب وضع Endpoint الـBackend الحقيقي ومتغيرات البيئة الخاصة بالدفع على الخادم، وليس داخل APK.
