(function (root, factory) {
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.SurveyQuantCAD163 = api;
  if (root && root.document) api.mount();
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
  'use strict';
  const SQ_V166_SOURCE_VIEW_ONLY_AND_EXACT_PDF_RASTER_UNDERLAY = true;
  const SQ_V167_DWG_ORIENTATION_VIEW_TRANSFORM = true;

  const enc = new TextEncoder();
  const SAFE_SEGMENT_LIMIT = 80000;
  const finite = Number.isFinite;
  const norm = n => Math.abs(n) < 1e-12 ? 0 : n;
  const fmt = n => {
    if (!finite(n)) throw new Error('نتجت قيمة إحداثية غير صالحة؛ أوقفت العملية لحماية الملف الأصلي.');
    n = norm(n);
    return String(Number(n.toPrecision(14)));
  };
  function decodeBytes(bytes) {
    return new TextDecoder('windows-1252').decode(bytes);
  }
  function readLine(bytes, start) {
    if (start >= bytes.length) return null;
    let end = start;
    while (end < bytes.length && bytes[end] !== 10) end++;
    let valueEnd = end;
    if (valueEnd > start && bytes[valueEnd - 1] === 13) valueEnd--;
    return { start, valueEnd, end: end < bytes.length ? end + 1 : end };
  }
  function pairText(bytes, line) {
    return decodeBytes(bytes.subarray(line.start, line.valueEnd)).trim();
  }
  function forEachPair(bytes, callback) {
    let pos = 0;
    while (pos < bytes.length) {
      const codeLine = readLine(bytes, pos);
      if (!codeLine) break;
      const valueLine = readLine(bytes, codeLine.end);
      if (!valueLine) break;
      const codeText = pairText(bytes, codeLine);
      const code = Number.parseInt(codeText, 10);
      callback({
        code,
        value: pairText(bytes, valueLine),
        start: codeLine.start,
        valueStart: valueLine.start,
        valueEnd: valueLine.valueEnd,
        end: valueLine.end,
      });
      pos = valueLine.end;
    }
  }
  function solve(sourceA, sourceB, targetA, targetB) {
    const dx1 = sourceB.x - sourceA.x, dy1 = sourceB.y - sourceA.y;
    const dx2 = targetB.x - targetA.x, dy2 = targetB.y - targetA.y;
    const d1 = Math.hypot(dx1, dy1), d2 = Math.hypot(dx2, dy2);
    if (![sourceA.x, sourceA.y, sourceB.x, sourceB.y, targetA.x, targetA.y, targetB.x, targetB.y].every(finite)) {
      throw new Error('إحداثيات نقاط التوجيه غير صالحة.');
    }
    if (d1 < 1e-9 || d2 < 1e-9) throw new Error('اختر نقطتين مختلفتين في كل لوحة.');
    const scale = d2 / d1;
    const angle = Math.atan2(dy2, dx2) - Math.atan2(dy1, dx1);
    const cos = Math.cos(angle), sin = Math.sin(angle);
    const apply = p => {
      const x = p.x - sourceA.x, y = p.y - sourceA.y;
      return { x: targetA.x + scale * (x * cos - y * sin), y: targetA.y + scale * (x * sin + y * cos) };
    };
    const mappedA = apply(sourceA), mappedB = apply(sourceB);
    return {
      scale,
      rotationRadians: angle,
      rotationDegrees: angle * 180 / Math.PI,
      apply,
      residualA: Math.hypot(mappedA.x - targetA.x, mappedA.y - targetA.y),
      residualB: Math.hypot(mappedB.x - targetB.x, mappedB.y - targetB.y),
    };
  }
  function transformGeometryView(geometry, transform) {
    if (!geometry || !transform || typeof transform.apply !== 'function') throw new Error('بيانات التوجيه غير مكتملة.');
    const mapPoint = p => transform.apply({x:Number(p.x),y:Number(p.y)});
    const angle = Number(transform.rotationDegrees)||0, scale=Number(transform.scale);
    if (!finite(scale) || scale<=0) throw new Error('مقياس التوجيه غير صالح.');
    const out = {
      ...geometry,
      segments: (geometry.segments||[]).map(seg=>({...seg,a:mapPoint(seg.a),b:mapPoint(seg.b)})),
      points: (geometry.points||[]).map(p=>({...p,...mapPoint(p)})),
      texts: (geometry.texts||[]).map(t=>({...t,position:mapPoint(t.position),height:(Number(t.height)||0)*scale,rotation:(Number(t.rotation)||0)+angle})),
      curves: (geometry.curves||[]).map(c=>({...c,center:c.center?mapPoint(c.center):c.center,radius:(Number(c.radius)||0)*scale,start:(Number(c.start)||0)+Number(transform.rotationRadians||0),points:(c.points||[]).map(mapPoint)}))
    };
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    const include=q=>{if(q&&finite(q.x)&&finite(q.y)){minX=Math.min(minX,q.x);minY=Math.min(minY,q.y);maxX=Math.max(maxX,q.x);maxY=Math.max(maxY,q.y);}};
    for(const seg of out.segments){include(seg.a);include(seg.b);}
    for(const point of out.points)include(point);
    for(const label of out.texts)include(label.position);
    for(const curve of out.curves){if(curve.center&&finite(curve.radius)){include({x:curve.center.x-curve.radius,y:curve.center.y-curve.radius});include({x:curve.center.x+curve.radius,y:curve.center.y+curve.radius});}for(const q of curve.points)include(q);}
    if(!finite(minX)){const c=mapPoint({x:(geometry.minX+geometry.maxX)/2,y:(geometry.minY+geometry.maxY)/2});minX=maxX=c.x;minY=maxY=c.y;}
    out.minX=minX;out.minY=minY;out.maxX=maxX;out.maxY=maxY;
    return out;
  }

  function applyEdits(source, edits) {
    const sorted = edits.slice().sort((a, b) => a.start - b.start || a.end - b.end);
    let total = source.length, cursor = 0;
    for (const edit of sorted) {
      if (!Number.isInteger(edit.start) || !Number.isInteger(edit.end) || edit.start < cursor || edit.end < edit.start || edit.end > source.length) {
        throw new Error('تداخلت تعديلات البايتات؛ أوقفت التحويل بدلًا من إتلاف DXF.');
      }
      total += (edit.insertBytes || new Uint8Array(0)).length - (edit.end - edit.start);
      cursor = edit.end;
    }
    const out = new Uint8Array(total);
    let sourcePos = 0, outPos = 0;
    for (const edit of sorted) {
      const span = edit.start - sourcePos;
      out.set(source.subarray(sourcePos, edit.start), outPos); outPos += span;
      const insert = edit.insertBytes || new Uint8Array(0);
      out.set(insert, outPos); outPos += insert.length; sourcePos = edit.end;
    }
    out.set(source.subarray(sourcePos), outPos); outPos += source.length - sourcePos;
    if (outPos !== out.length) throw new Error('فشل التحقق من حجم DXF الناتج.');
    return out;
  }
  function transformDxfBytes(rawBytes, sourceA, sourceB, targetA, targetB) {
    const bytes = rawBytes instanceof Uint8Array ? rawBytes : new Uint8Array(rawBytes);
    if (!bytes.length) throw new Error('ملف DXF فارغ.');
    const tr = solve(sourceA, sourceB, targetA, targetB);
    const eol = (() => { for (let i=0;i<bytes.length;i++) if(bytes[i]===10) return i>0&&bytes[i-1]===13?'\r\n':'\n'; return '\n'; })();
    const edits=[]; let pos=0,section='',needSectionName=false,blockHeaderPending=false,blockName='',tableHeaderPending=false,tableName='',entity=null,foundEntities=false,headerVariable='';
    const theta=tr.rotationRadians,cos=Math.cos(theta),sin=Math.sin(theta);
    const point=(x,y)=>tr.apply({x,y});
    const vector=(x,y)=>({x:tr.scale*(x*cos-y*sin),y:tr.scale*(x*sin+y*cos)});
    const add=(pair,value)=>edits.push({start:pair.valueStart,end:pair.valueEnd,insertBytes:enc.encode(fmt(value))});
    function flushEntity(){
      if(!entity)return;
      const type=String(entity.type||'').toUpperCase(),pairs=entity.pairs,by=new Map();
      for(const p of pairs){if(!by.has(p.code))by.set(p.code,[]);by.get(p.code).push(p);}
      for(let xc=10;xc<=18;xc++){
        const xs=by.get(xc)||[],ys=by.get(xc+10)||[];if(!xs.length||xs.length!==ys.length)continue;
        for(let i=0;i<xs.length;i++){
          const x=Number(xs[i].value),y=Number(ys[i].value);if(!finite(x)||!finite(y))continue;
          const isVector=(type==='ELLIPSE'&&xc===11)||(type==='MTEXT'&&xc===11)||((type==='XLINE'||type==='RAY')&&xc===11);
          const q=isVector?vector(x,y):point(x,y);add(xs[i],q.x);add(ys[i],q.y);
        }
      }
      const mul=c=>{for(const p of(by.get(c)||[])){const n=Number(p.value);if(finite(n))add(p,n*tr.scale);}};
      const rot=c=>{for(const p of(by.get(c)||[])){const n=Number(p.value);if(finite(n))add(p,((n+tr.rotationDegrees)%360+360)%360);}};
      let extra='';
      if(type==='CIRCLE'||type==='ARC')mul(40);
      if(['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(type))mul(40);
      if(type==='MTEXT')mul(41);
      if(['LWPOLYLINE','POLYLINE','VERTEX'].includes(type)){mul(40);mul(41);}
      if(type==='LINE')mul(39);
      if(type==='VERTEX')mul(41);
      if(type==='INSERT'){
        for(const c of [41,42,43,44,45]){if((by.get(c)||[]).length)mul(c);else if((c===41||c===42)&&pairs.length)extra+=`${c}${eol}${fmt(tr.scale)}${eol}`;}
        if((by.get(50)||[]).length)rot(50);else if(theta&&pairs.length)extra+=`50${eol}${fmt(tr.rotationDegrees)}${eol}`;
      }else if(type==='ARC'){rot(50);rot(51);}
      else if(type==='ELLIPSE'){/* major-axis vector is transformed above; parameter angles remain local */}
      else if(['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(type)){if((by.get(50)||[]).length)rot(50);else if(theta&&pairs.length)extra+=`50${eol}${fmt(tr.rotationDegrees)}${eol}`;}
      else if(type==='DIMENSION')rot(53);
      else if(type==='HATCH'){
        for(const c of [49,45,46,47,48])if((by.get(c)||[]).length)mul(c);
        for(const c of [50,51,52,53])if((by.get(c)||[]).length)rot(c);
      }
      // A uniform similarity transform must scale style-controlled annotations and linetype dashes too.
      if(type==='STYLE'){for(const c of [40,42])if((by.get(c)||[]).length)mul(c);}
      if(type==='DIMSTYLE'){for(const c of [40,41,42,43,44,45,46,47,48,140,141,142,143,144,145,146,147,148])if((by.get(c)||[]).length)mul(c);}
      if(type==='LTYPE')mul(49);
      if(extra&&pairs.length){const last=pairs[pairs.length-1];edits.push({start:last.end,end:last.end,insertBytes:enc.encode(extra)});}
      entity=null;
    }
    const scaledHeaderVars=new Set(['$LTSCALE','$CELTSCALE','$DIMSCALE','$TEXTSIZE','$DIMASZ','$DIMEXE','$DIMEXO','$DIMGAP','$DIMTXT','$DIMCEN','$DIMTSZ','$DIMBLK','$_PEXTMIN']);
    while(pos<bytes.length){
      const cl=readLine(bytes,pos);if(!cl)break;const vl=readLine(bytes,cl.end);if(!vl)break;
      const code=Number.parseInt(pairText(bytes,cl),10),value=pairText(bytes,vl),pair={code,value,start:cl.start,valueStart:vl.start,valueEnd:vl.valueEnd,end:vl.end};
      if(needSectionName&&code===2){section=value.toUpperCase();needSectionName=false;if(section==='ENTITIES')foundEntities=true;pos=vl.end;continue;}
      if(section==='HEADER'){
        if(code===9)headerVariable=value.toUpperCase();
        else if(code===40&&scaledHeaderVars.has(headerVariable)){const n=Number(value);if(finite(n))add(pair,n*tr.scale);headerVariable='';}
        else if(code!==0)headerVariable='';
      }
      if(section==='TABLES'&&tableHeaderPending&&code===2){tableName=value.toUpperCase();tableHeaderPending=false;pos=vl.end;continue;}
      if(section==='BLOCKS'&&blockHeaderPending&&code===2){blockName=value;blockHeaderPending=false;pos=vl.end;continue;}
      if(code===0){
        flushEntity();const u=value.toUpperCase();
        if(u==='SECTION'){needSectionName=true;pos=vl.end;continue;}
        if(u==='ENDSEC'){section='';blockName='';tableName='';pos=vl.end;continue;}
        if(section==='TABLES'){
          if(u==='TABLE'){tableHeaderPending=true;tableName='';pos=vl.end;continue;}
          if(u==='ENDTAB'){tableName='';pos=vl.end;continue;}
          if(tableName&&['STYLE','DIMSTYLE','LTYPE'].includes(tableName))entity={type:tableName,pairs:[]};
        }else if(section==='BLOCKS'){
          if(u==='BLOCK'){blockHeaderPending=true;pos=vl.end;continue;}
          if(u==='ENDBLK'){blockName='';pos=vl.end;continue;}
          // Anonymous dimension graphics are stored in drawing coordinates; named block definitions stay local.
          if(blockName.toUpperCase().startsWith('*D'))entity={type:u,pairs:[]};
        }else if(section==='ENTITIES')entity={type:u,pairs:[]};
      }else if(entity)entity.pairs.push(pair);
      pos=vl.end;
    }
    flushEntity();
    if(!foundEntities)throw new Error('لم يوجد قسم ENTITIES صالح في ملف DXF.');
    if(tr.scale<1e-12||!finite(tr.scale))throw new Error('مقياس التوجيه الناتج غير صالح.');
    return{bytes:applyEdits(bytes,edits),scale:tr.scale,rotationDegrees:tr.rotationDegrees,editCount:edits.length,mode:'raw-dxf-record-transform'};
  }
  function readGeometry(rawBytes, maxSegments = SAFE_SEGMENT_LIMIT) {
    const bytes=rawBytes instanceof Uint8Array?rawBytes:new Uint8Array(rawBytes);
    const main={segments:[],points:[],inserts:[],texts:[],curves:[],construction:[]},blocks=new Map();
    let active=main,currentBlock=null,blockHeader=null,section='',needSectionName=false,entity=null,pendingPolyline=null;
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity,totalGeomPoints=0,totalGeomSegments=0,currentCadStyle={layer:'0',color:'#182536',lineWeight:0};
    const styleHeights=new Map();let defaultTextHeight=0,headerVariable='';
    // STYLE fixed heights and $TEXTSIZE are used when a TEXT entity's group 40 is zero.
    let ss='',waitSec=false,tt='',waitTable=false,styleRec=null;
    forEachPair(bytes,p=>{
      const u=p.value.toUpperCase();
      if(p.code===0&&u==='SECTION'){waitSec=true;return;}
      if(waitSec&&p.code===2){ss=u;waitSec=false;return;}
      if(ss==='HEADER'){if(p.code===9)headerVariable=p.value.toUpperCase();else if(p.code===40&&headerVariable==='$TEXTSIZE'){defaultTextHeight=Math.abs(Number(p.value)||0);headerVariable='';}else if(p.code!==0)headerVariable='';}
      if(ss==='TABLES'){
        if(p.code===0&&u==='TABLE'){waitTable=true;return;}
        if(waitTable&&p.code===2){tt=u;waitTable=false;return;}
        if(p.code===0){if(styleRec&&styleRec.name)styleHeights.set(styleRec.name.toUpperCase(),styleRec.height||0);styleRec=tt==='STYLE'&&u==='STYLE'?{name:'',height:0}:null;return;}
        if(styleRec){if(p.code===2)styleRec.name=p.value;else if(p.code===40)styleRec.height=Number(p.value)||0;}
      }
      if(p.code===0&&u==='ENDSEC'){if(styleRec&&styleRec.name)styleHeights.set(styleRec.name.toUpperCase(),styleRec.height||0);styleRec=null;ss='';tt='';}
    });
    const layerColors=new Map();let layerSection='',layerWait=false,layerTable='',layerTableWait=false,layerRow=null;
    forEachPair(bytes,p=>{const u=p.value.toUpperCase();if(p.code===0&&u==='SECTION'){layerWait=true;return;}if(layerWait&&p.code===2){layerSection=u;layerWait=false;return;}if(layerSection!=='TABLES')return;if(p.code===0&&u==='TABLE'){layerTableWait=true;return;}if(layerTableWait&&p.code===2){layerTable=u;layerTableWait=false;return;}if(layerTable!=='LAYER')return;if(p.code===0){if(layerRow?.name)layerColors.set(layerRow.name.toUpperCase(),layerRow);layerRow=u==='LAYER'?{name:'',aci:7,rgb:null}:null;if(u==='ENDTAB')layerTable='';if(u==='ENDSEC')layerSection='';return;}if(layerRow){if(p.code===2)layerRow.name=p.value;else if(p.code===62)layerRow.aci=Math.abs(Number(p.value)||7);else if(p.code===420)layerRow.rgb=Number(p.value);}});
    if(layerRow?.name)layerColors.set(layerRow.name.toUpperCase(),layerRow);
    function addPoint(p){if(!p||!finite(p.x)||!finite(p.y)||totalGeomPoints>=maxSegments)return;totalGeomPoints++;active.points.push({...p,...currentCadStyle});if(active===main){minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);minY=Math.min(minY,p.y);maxY=Math.max(maxY,p.y);}}
    function addSegment(a,b,isCurveSegment=false,styleOverride=null){if(totalGeomSegments>=maxSegments||active.segments.length>=maxSegments||!a||!b||!finite(a.x)||!finite(a.y)||!finite(b.x)||!finite(b.y))return;totalGeomSegments++;active.segments.push({a,b,isCurveSegment,...(styleOverride||currentCadStyle)});if(active===main){minX=Math.min(minX,a.x,b.x);maxX=Math.max(maxX,a.x,b.x);minY=Math.min(minY,a.y,b.y);maxY=Math.max(maxY,a.y,b.y);}}
    function addText(label){if(!label||!label.text||!label.position||!finite(label.position.x)||!finite(label.position.y))return;if(active.texts.length>=12000)return;active.texts.push(label);if(active===main){minX=Math.min(minX,label.position.x);maxX=Math.max(maxX,label.position.x);minY=Math.min(minY,label.position.y);maxY=Math.max(maxY,label.position.y);}}
    function plainCadText(value){return String(value||'').replace(/\\P/gi,' ').replace(/\\~/g,' ').replace(/\\[ACFHQTW][^;]*;/gi,'').replace(/[{}]/g,'').replace(/\\\\/g,'\\').trim();}
    function cadTextColor(values,layerName='0'){let rgb=Number((values[420]||[])[0]),aci=Number((values[62]||[])[0]);if(finite(rgb)&&rgb>=0)return `#${(rgb&0xffffff).toString(16).padStart(6,'0')}`;if(!finite(aci)||aci===0||aci===256){const layer=layerColors.get(String(layerName||'0').toUpperCase());if(layer?.rgb!==null&&finite(layer?.rgb))return `#${(layer.rgb&0xffffff).toString(16).padStart(6,'0')}`;aci=layer?.aci||7;}aci=Math.abs(aci)||7;return ({1:'#d62828',2:'#d4a500',3:'#16833b',4:'#078caa',5:'#2458b5',6:'#ad3297',7:'#182536',8:'#666666',9:'#888888',10:'#d62828',11:'#ff5555',12:'#aa0000',13:'#aa5555',14:'#aa2222',15:'#772222',30:'#ff9900',40:'#ffff00',50:'#aaff00',60:'#00aa00',70:'#00ffaa',80:'#00aaff',90:'#0000ff',100:'#aa00ff',110:'#ff00aa',120:'#aa0055',130:'#ffaaaa',140:'#aaffaa',150:'#aaffff',160:'#aaaaff',170:'#ffaaff'})[aci]||'#182536';}
    function cadEntityStyle(values, layerName='0'){
      const layer=String(layerName||'0'),lw=Number((values[370]||[])[0]);
      return {layer,color:cadTextColor(values,layer),lineWeight:finite(lw)&&lw>0?lw:0};
    }

    function pointsFromPairs(byCode,xCode=10){const xs=byCode.get(xCode)||[],ys=byCode.get(xCode+10)||[],out=[];for(let i=0;i<Math.min(xs.length,ys.length);i++){const x=Number(xs[i]),y=Number(ys[i]);if(finite(x)&&finite(y))out.push({x,y});}return out;}
    function addArc(center,radius,start,sweep,type='arc',sample=true){if(!center||!(radius>0)||!finite(radius)||!finite(start)||!finite(sweep))return;const curve={type,center:{x:center.x,y:center.y},radius,start,sweep,points:[],...currentCadStyle};active.curves.push(curve);if(!sample)return;const n=Math.max(24,Math.min(2880,Math.ceil(Math.abs(sweep)*180/Math.PI/0.25)));let prev=null;for(let i=0;i<=n;i++){const a=start+sweep*i/n,q={x:center.x+radius*Math.cos(a),y:center.y+radius*Math.sin(a)};curve.points.push(q);prev=q;}}
    function addBulge(a,b,bulge){if(!a||!b)return;const c=Math.hypot(b.x-a.x,b.y-a.y);if(c<1e-12)return;if(!finite(bulge)||Math.abs(bulge)<1e-10){addSegment(a,b);return;}const theta=4*Math.atan(bulge),d=c*(1-bulge*bulge)/(4*bulge),mx=(a.x+b.x)/2,my=(a.y+b.y)/2,nx=-(b.y-a.y)/c,ny=(b.x-a.x)/c,center={x:mx+nx*d,y:my+ny*d},r=Math.hypot(a.x-center.x,a.y-center.y),start=Math.atan2(a.y-center.y,a.x-center.x);addArc(center,r,start,theta,'bulge',true);}
    function connectBulged(vertices,closed=false){if(!vertices.length)return;if(vertices.length===1){addPoint(vertices[0]);return;}for(let i=0;i<vertices.length-1;i++)addBulge(vertices[i],vertices[i+1],vertices[i].bulge||0);if(closed)addBulge(vertices[vertices.length-1],vertices[0],vertices[vertices.length-1].bulge||0);}
    function connect(list,closed=false){connectBulged(list.map(p=>({...p,bulge:0})),closed);}
    function finishPolyline(){if(pendingPolyline){const prior=currentCadStyle;currentCadStyle=pendingPolyline.style||prior;connectBulged(pendingPolyline.vertices,pendingPolyline.closed);currentCadStyle=prior;pendingPolyline=null;}}
    function flushEntity(){
      if(!entity)return;const priorCadStyle=currentCadStyle;const type=entity.type.toUpperCase(),values=entity.values,by=new Map();for(const [code,arr] of Object.entries(values))by.set(Number(code),arr);currentCadStyle=cadEntityStyle(values,String((values[8]||[])[0]||'0'));
      if(['TEXT','MTEXT','ATTRIB','ATTDEF','DIMENSION'].includes(type)){
        let p=pointsFromPairs(by,10)[0];const hAlign=Number((values[72]||[])[0]||0),vAlign=Number((values[73]||[])[0]||0);if(type==='TEXT'&&(hAlign!==0||vAlign!==0)){const aligned=pointsFromPairs(by,11)[0];if(aligned)p=aligned;}
        const rawParts=entity.textParts||[],rawText=rawParts.length?rawParts.map(x=>x.value).join(''):(values[1]||[]).join(''),label=plainCadText(rawText),styleName=String((values[7]||[])[0]||'STANDARD').toUpperCase(),fixedStyle=styleHeights.get(styleName)||0,entityHeight=Math.abs(Number((values[40]||[])[0])||0),height=entityHeight>0?entityHeight:(fixedStyle>0?fixedStyle:defaultTextHeight);
        if(p&&label&&type!=='DIMENSION')addText({type,position:p,text:label,height,rotation:Number((values[50]||[])[0]||0),layer:String((values[8]||[])[0]||'0'),color:cadTextColor(values,String((values[8]||[])[0]||'0')),style:styleName,widthFactor:Number((values[41]||[])[0]||1)});
        if(p&&type==='DIMENSION'&&label&&label!=='<>')addText({type:'DIMENSION',position:p,text:label,height,rotation:Number((values[53]||[])[0]||0),layer:String((values[8]||[])[0]||'0'),color:cadTextColor(values,String((values[8]||[])[0]||'0')),style:styleName});
      }
      if(type==='POLYLINE'){finishPolyline();pendingPolyline={vertices:[],closed:((Number((values[70]||[])[0])||0)&1)!==0,style:{...currentCadStyle}};}
      else if(type==='VERTEX'&&pendingPolyline){const pt=pointsFromPairs(by)[0];if(pt)pendingPolyline.vertices.push({...pt,bulge:Number((values[42]||[])[0]||0)});}
      else if(type==='SEQEND'&&pendingPolyline)finishPolyline();
      else{
        if(pendingPolyline)finishPolyline();
        if(type==='LINE'){const a=pointsFromPairs(by,10)[0],b=pointsFromPairs(by,11)[0];if(a&&b)addSegment(a,b);}
        else if(type==='LWPOLYLINE'){const pts=pointsFromPairs(by,10),bulges=values[42]||[],vertices=pts.map((p,i)=>({...p,bulge:Number(bulges[i]||0)}));connectBulged(vertices,(((Number((values[70]||[])[0])||0)&1)!==0));}
        else if(type==='SPLINE'){
          const fit=pointsFromPairs(by,11),ctrl=pointsFromPairs(by,10),degree=Math.max(1,Math.min(10,Number((values[71]||[])[0]||3))),knots=(values[40]||[]).map(Number),weights=(values[41]||[]).map(Number);let sampled=[];
          if(ctrl.length>=degree+1&&knots.length===ctrl.length+degree+1&&knots.every(finite)&&knots.every((v,i)=>i===0||v>=knots[i-1])){
            const n=ctrl.length-1,pdeg=Math.min(degree,n),lo=knots[pdeg],hi=knots[n+1];
            const evalAt=u=>{let span=n;if(u<hi){for(let k=pdeg;k<=n;k++)if(u>=knots[k]&&u<knots[k+1]){span=k;break;}}const d=[];for(let j=0;j<=pdeg;j++){const ix=span-pdeg+j,w=Number(weights[ix])>0?Number(weights[ix]):1;d.push({x:ctrl[ix].x*w,y:ctrl[ix].y*w,w});}for(let r=1;r<=pdeg;r++)for(let j=pdeg;j>=r;j--){const ix=span-pdeg+j,den=knots[ix+pdeg-r+1]-knots[ix],alpha=Math.abs(den)<1e-15?0:(u-knots[ix])/den;d[j]={x:(1-alpha)*d[j-1].x+alpha*d[j].x,y:(1-alpha)*d[j-1].y+alpha*d[j].y,w:(1-alpha)*d[j-1].w+alpha*d[j].w};}const z=d[pdeg];return z.w?{x:z.x/z.w,y:z.y/z.w}:null;};
            const count=Math.min(2048,Math.max(48,ctrl.length*24));for(let i=0;i<=count;i++){const q=evalAt(lo+(hi-lo)*i/count);if(q&&finite(q.x)&&finite(q.y))sampled.push(q);}
          }
          if(sampled.length<2){const src=fit.length>=2?fit:ctrl;if(src.length>=2){const count=Math.min(2048,(src.length-1)*32);for(let i=0;i<=count;i++){const t=i/count,seg=Math.min(src.length-2,Math.floor(t*(src.length-1))),u=t*(src.length-1)-seg,p0=src[Math.max(0,seg-1)],p1=src[seg],p2=src[seg+1],p3=src[Math.min(src.length-1,seg+2)],u2=u*u,u3=u2*u;sampled.push({x:.5*((2*p1.x)+(-p0.x+p2.x)*u+(2*p0.x-5*p1.x+4*p2.x-p3.x)*u2+(-p0.x+3*p1.x-3*p2.x+p3.x)*u3),y:.5*((2*p1.y)+(-p0.y+p2.y)*u+(2*p0.y-5*p1.y+4*p2.y-p3.y)*u2+(-p0.y+3*p1.y-3*p2.y+p3.y)*u3)});}}}
          if(sampled.length>=2){active.curves.push({type:'spline',points:sampled,...currentCadStyle});for(let i=1;i<sampled.length;i++)addSegment(sampled[i-1],sampled[i],true);}else connect(fit.length>=2?fit:ctrl,false);
        }
        else if(type==='CIRCLE'||type==='ARC'){const c=pointsFromPairs(by,10)[0],r=Number((values[40]||[])[0]);if(c&&r>0){let start=type==='ARC'?Number((values[50]||[])[0])*Math.PI/180:0,end=type==='ARC'?Number((values[51]||[])[0])*Math.PI/180:Math.PI*2;if(!finite(start))start=0;if(!finite(end))end=Math.PI*2;while(type==='ARC'&&end<=start)end+=Math.PI*2;addArc(c,r,start,type==='ARC'?end-start:Math.PI*2,type==='ARC'?'arc':'circle',true);}else if(c)addPoint(c);}
        else if(type==='ELLIPSE'){const c=pointsFromPairs(by,10)[0],major=pointsFromPairs(by,11)[0],ratio=Number((values[40]||[])[0]||1),t0=Number((values[41]||[])[0]||0),t1=Number((values[42]||[])[0]||Math.PI*2);if(c&&major&&ratio>0){const minor={x:-major.y*ratio,y:major.x*ratio},n=Math.max(48,Math.min(2048,Math.ceil(Math.abs(t1-t0)*256/Math.PI))),curve={type:'ellipse',points:[],...currentCadStyle};active.curves.push(curve);let prev=null;for(let i=0;i<=n;i++){const t=t0+(t1-t0)*i/n,q={x:c.x+major.x*Math.cos(t)+minor.x*Math.sin(t),y:c.y+major.y*Math.cos(t)+minor.y*Math.sin(t)};curve.points.push(q);prev=q;}}}
        else if(type==='XLINE'||type==='RAY'){const o=pointsFromPairs(by,10)[0],d=pointsFromPairs(by,11)[0];if(o&&d)active.construction.push({type,origin:o,direction:d});}
        else if(['SOLID','TRACE','3DFACE'].includes(type)){const pts=[];for(let code=10;code<=13;code++){const pt=pointsFromPairs(by,code)[0];if(pt)pts.push(pt);}connect(pts,pts.length>2);}
        else if(type==='INSERT'){const at=pointsFromPairs(by,10)[0];if(at){const name=String((values[2]||[])[0]||'').toUpperCase();active.inserts.push({name,layer:String((values[8]||[])[0]||'0'),x:at.x,y:at.y,sx:Number((values[41]||[])[0]??1),sy:Number((values[42]||[])[0]??1),rotation:Number((values[50]||[])[0]||0),style:{...currentCadStyle},cols:Math.max(1,Math.min(50,Number((values[70]||[])[0]||1))),rows:Math.max(1,Math.min(50,Number((values[71]||[])[0]||1))),colSpacing:Number((values[44]||[])[0]||0),rowSpacing:Number((values[45]||[])[0]||0)});}}
        else if(['POINT','TEXT','MTEXT','ATTRIB','ATTDEF','DIMENSION'].includes(type)){const pt=pointsFromPairs(by,10)[0];if(pt)addPoint(pt);}
      }
      entity=null;currentCadStyle=priorCadStyle;
    }
    function finishBlock(){if(!currentBlock&&!blockHeader)return;const meta=blockHeader||currentBlock||{},name=String(meta.name||currentBlock?.name||'').toUpperCase();if(name){const g=currentBlock||{segments:[],points:[],inserts:[],texts:[],curves:[],construction:[]};blocks.set(name,{name,baseX:Number(meta.baseX??currentBlock?.baseX)||0,baseY:Number(meta.baseY??currentBlock?.baseY)||0,geometry:g});}blockHeader=null;currentBlock=null;active=main;}
    let pos=0;
    while(pos<bytes.length&&main.segments.length<maxSegments){const cl=readLine(bytes,pos);if(!cl)break;const vl=readLine(bytes,cl.end);if(!vl)break;const code=Number.parseInt(pairText(bytes,cl),10),value=pairText(bytes,vl);
      if(needSectionName&&code===2){section=value.toUpperCase();needSectionName=false;pos=vl.end;continue;}
      if(code===0){flushEntity();const u=value.toUpperCase();if(u==='SECTION'){needSectionName=true;pos=vl.end;continue;}if(u==='ENDSEC'){if(section==='BLOCKS'&&(blockHeader||currentBlock))finishBlock();section='';active=main;pos=vl.end;continue;}
        if(section==='BLOCKS'){if(u==='BLOCK'){if(blockHeader||currentBlock)finishBlock();blockHeader={name:'',baseX:0,baseY:0};currentBlock={segments:[],points:[],inserts:[],texts:[],curves:[],construction:[]};active=currentBlock;entity=null;pos=vl.end;continue;}if(u==='ENDBLK'){finishBlock();entity=null;pos=vl.end;continue;}if(blockHeader&&currentBlock){currentBlock.name=blockHeader.name;currentBlock.baseX=blockHeader.baseX;currentBlock.baseY=blockHeader.baseY;blockHeader=null;}if(currentBlock)entity={type:value,values:Object.create(null)};
        }else if(section==='ENTITIES')entity={type:value,values:Object.create(null)};
      }else if(blockHeader&&section==='BLOCKS'){if(code===2)blockHeader.name=value;else if(code===10)blockHeader.baseX=Number(value);else if(code===20)blockHeader.baseY=Number(value);}
      else if(entity&&((code>=10&&code<=18)||(code>=20&&code<=28)||[1,2,3,7,8,39,40,41,42,44,45,50,51,62,70,71,72,73,74,210,220,230,420].includes(code))){if(!entity.values[code])entity.values[code]=[];entity.values[code].push(value);if(code===1||code===3){if(!entity.textParts)entity.textParts=[];entity.textParts.push({code,value});}}
      pos=vl.end;
    }
    flushEntity();finishPolyline();if(blockHeader||currentBlock)finishBlock();active=main;
    const identity={a:1,b:0,c:0,d:1,tx:0,ty:0};let instanceCount=0;
    function applyAffine(p,m){return{x:m.a*p.x+m.c*p.y+m.tx,y:m.b*p.x+m.d*p.y+m.ty};}
    function compose(m,n){return{a:m.a*n.a+m.c*n.b,b:m.b*n.a+m.d*n.b,c:m.a*n.c+m.c*n.d,d:m.b*n.c+m.d*n.d,tx:m.a*n.tx+m.c*n.ty+m.tx,ty:m.b*n.tx+m.d*n.ty+m.ty};}
    function expandInsert(insert,parent,depth){if(depth>8||instanceCount>20000||main.segments.length>=maxSegments)return;const block=blocks.get(insert.name);if(!block){const p=applyAffine({x:insert.x,y:insert.y},parent);active=main;addPoint(p);return;}const sx=finite(insert.sx)&&insert.sx!==0?insert.sx:1,sy=finite(insert.sy)&&insert.sy!==0?insert.sy:1,theta=(finite(insert.rotation)?insert.rotation:0)*Math.PI/180,co=Math.cos(theta),si=Math.sin(theta),a=co*sx,b=si*sx,c=-si*sy,d=co*sy,cols=insert.cols||1,rows=insert.rows||1;
      for(let row=0;row<rows&&instanceCount<=20000;row++)for(let col=0;col<cols&&instanceCount<=20000;col++){instanceCount++;const ox=insert.x+co*sx*insert.colSpacing*col-si*sy*insert.rowSpacing*row,oy=insert.y+si*sx*insert.colSpacing*col+co*sy*insert.rowSpacing*row,child={a,b,c,d,tx:ox-a*block.baseX-c*block.baseY,ty:oy-b*block.baseX-d*block.baseY},world=compose(parent,child);active=main;for(const seg of block.geometry.segments){if(main.segments.length>=maxSegments)break;let st=seg;if(seg.layer==='0'&&insert.layer){const il=layerColors.get(String(insert.layer).toUpperCase());st={...seg,layer:insert.layer,color:il?.rgb!==null&&finite(il?.rgb)?`#${(il.rgb&0xffffff).toString(16).padStart(6,'0')}`:il?.aci?cadTextColor({62:[il.aci]},insert.layer):insert.style?.color||seg.color,lineWeight:insert.style?.lineWeight||seg.lineWeight};}addSegment(applyAffine(seg.a,world),applyAffine(seg.b,world),!!seg.isCurveSegment,st);}for(const cv of(block.geometry.curves||[])){if(Array.isArray(cv.points)&&cv.points.length>1){const pts=cv.points.map(q=>applyAffine(q,world));main.curves.push({type:'block-curve',points:pts,...cv});}}for(const pt of block.geometry.points){if(main.points.length>=maxSegments)break;addPoint(applyAffine(pt,world));}const viewScale=Math.sqrt(Math.max(1e-12,Math.abs(world.a*world.d-world.b*world.c))),basisX=Math.hypot(world.a,world.b),basisY=Math.hypot(world.c,world.d),orthogonal=Math.abs(world.a*world.c+world.b*world.d)<1e-8*Math.max(1,basisX*basisY),uniform=Math.abs(basisX-basisY)<1e-8*Math.max(1,basisX,basisY);for(const label of(block.geometry.texts||[])){const angle=(Number(label.rotation)||0)*Math.PI/180,vx=world.a*Math.cos(angle)+world.c*Math.sin(angle),vy=world.b*Math.cos(angle)+world.d*Math.sin(angle),effectiveLayer=label.layer==='0'?(insert.layer||label.layer):label.layer,layerStyle=label.layer==='0'&&insert.layer?layerColors.get(String(insert.layer).toUpperCase()):null;addText({...label,position:applyAffine(label.position,world),height:(Number(label.height)||0)*viewScale,rotation:Math.atan2(vy,vx)*180/Math.PI,layer:effectiveLayer,color:layerStyle?.rgb!==null&&finite(layerStyle?.rgb)?`#${(layerStyle.rgb&0xffffff).toString(16).padStart(6,'0')}`:layerStyle?.aci?cadTextColor({62:[layerStyle.aci]},effectiveLayer):label.color});}for(const cv of(block.geometry.curves||[])){if(Array.isArray(cv.points)&&cv.points.length>1){const pts=cv.points.map(q=>applyAffine(q,world));if(cv.center&&uniform&&orthogonal){const rot=Math.atan2(world.b,world.a);main.curves.push({...cv,type:cv.type,center:applyAffine(cv.center,world),radius:cv.radius*basisX,start:cv.start+rot,points:pts});}else main.curves.push({type:'block-curve',points:pts});}}for(const nested of block.geometry.inserts)expandInsert(nested,world,depth+1);}
    }
    for(const ins of main.inserts)expandInsert(ins,identity,0);
    // XLINE/RAY axes are materialized only as temporary viewport segments, never in exported bytes.
    const span=finite(minX)?Math.max(100,Math.hypot(maxX-minX,maxY-minY)*3):1000;
    for(const ray of main.construction){const len=Math.hypot(ray.direction.x,ray.direction.y);if(len<1e-12)continue;const dx=ray.direction.x/len,dy=ray.direction.y/len,a=ray.type==='XLINE'?{x:ray.origin.x-dx*span,y:ray.origin.y-dy*span}:ray.origin,b={x:ray.origin.x+dx*span,y:ray.origin.y+dy*span};addSegment(a,b,false);}
    if(!main.segments.length&&!main.points.length&&!main.texts.length)throw new Error('لم أستطع استخراج خطوط أو بلوكات أو أسماء محاور قابلة للمعاينة من اللوحة.');
    if(!finite(minX)||!finite(maxX)){minX=0;maxX=1;minY=0;maxY=1;}if(maxX-minX<1e-9){minX-=.5;maxX+=.5;}if(maxY-minY<1e-9){minY-=.5;maxY+=.5;}
    return{segments:main.segments,points:main.points,texts:main.texts,curves:main.curves,minX,minY,maxX,maxY};
  }
  function nearestPoint(geometry, point) {
    let best = null, bestD2 = Infinity;
    for (const s of geometry.segments) {
      const dx = s.b.x - s.a.x, dy = s.b.y - s.a.y, den = dx * dx + dy * dy;
      const t = den ? Math.max(0, Math.min(1, ((point.x - s.a.x) * dx + (point.y - s.a.y) * dy) / den)) : 0;
      const q = { x: s.a.x + t * dx, y: s.a.y + t * dy };
      const d2 = (q.x - point.x) ** 2 + (q.y - point.y) ** 2;
      if (d2 < bestD2) { bestD2 = d2; best = q; }
    }
    if (!best && geometry.points.length) {
      for (const q of geometry.points) { const d2 = (q.x - point.x) ** 2 + (q.y - point.y) ** 2; if (d2 < bestD2) { bestD2 = d2; best = { x: q.x, y: q.y }; } }
    }
    if (!best) throw new Error('لا توجد عناصر مناسبة لالتقاط النقطة.');
    return best;
  }
  function snapPoint(geometry, point, mode='intersection', tolerance=1) {
    const tol=Math.max(1e-12,Number(tolerance)||1),tol2=tol*tol,candidates=[],seen=new Set();let nearest=null,nearestD2=Infinity;const nearSegments=[];
    const add=(x,y,type,d2)=>{if(!finite(x)||!finite(y)||d2>tol2)return;candidates.push({point:{x,y},type,distance:d2});};
    const angleOnArc=(a,c)=>{const full=Math.abs(c.sweep)>=Math.PI*2-1e-8;if(full)return true;let d=(a-c.start)%(Math.PI*2);if(d<0)d+=Math.PI*2;if(c.sweep>=0)return d<=c.sweep+1e-8;let r=(c.start-a)%(Math.PI*2);if(r<0)r+=Math.PI*2;return r<=-c.sweep+1e-8;};
    for(const seg of geometry.segments||[]){
      const dx=seg.b.x-seg.a.x,dy=seg.b.y-seg.a.y,den=dx*dx+dy*dy;
      const t=den?Math.max(0,Math.min(1,((point.x-seg.a.x)*dx+(point.y-seg.a.y)*dy)/den)):0;
      const q={x:seg.a.x+t*dx,y:seg.a.y+t*dy},d2=(q.x-point.x)**2+(q.y-point.y)**2;
      if(d2<nearestD2){nearestD2=d2;nearest={point:q,type:'nearest',distance:d2};}
      if(d2<=tol2*16)nearSegments.push({seg,d2});
      if(mode==='endpoint'||mode==='intersection')for(const ep of[seg.a,seg.b]){const d=(ep.x-point.x)**2+(ep.y-point.y)**2;add(ep.x,ep.y,'endpoint',d);}
      if(mode==='midpoint'||mode==='intersection'){const m={x:(seg.a.x+seg.b.x)/2,y:(seg.a.y+seg.b.y)/2},d=(m.x-point.x)**2+(m.y-point.y)**2;add(m.x,m.y,'midpoint',d);}
    }
    if(mode==='intersection'&&nearSegments.length>1){
      nearSegments.sort((a,b)=>a.d2-b.d2);const list=nearSegments.length>1800?nearSegments.slice(0,1800):nearSegments;
      for(let i=0;i<list.length;i++)for(let j=i+1;j<list.length;j++){
        const a=list[i].seg,b=list[j].seg,rx=a.b.x-a.a.x,ry=a.b.y-a.a.y,sx=b.b.x-b.a.x,sy=b.b.y-b.a.y,den=rx*sy-ry*sx;
        const scale=Math.max(1,Math.hypot(rx,ry)*Math.hypot(sx,sy));if(Math.abs(den)<1e-12*scale)continue;
        const qx=b.a.x-a.a.x,qy=b.a.y-a.a.y,t=(qx*sy-qy*sx)/den,u=(qx*ry-qy*rx)/den;
        if(t>=-1e-9&&t<=1+1e-9&&u>=-1e-9&&u<=1+1e-9){const x=a.a.x+t*rx,y=a.a.y+t*ry,d=(x-point.x)**2+(y-point.y)**2;if(d<=tol2){const k=`${Math.round(x/Math.max(tol,1e-9)*1e7)}:${Math.round(y/Math.max(tol,1e-9)*1e7)}`;if(!seen.has(k)){seen.add(k);add(x,y,'intersection',d);}}}
      }
    }
    if(mode==='intersection'||mode==='nearest'){
      const curves=(geometry.curves||[]).filter(c=>{if(!c||!c.center||!(Number(c.radius)>0)||!['arc','circle','bulge'].includes(c.type))return false;const dx=point.x-c.center.x,dy=point.y-c.center.y,len=Math.hypot(dx,dy);return Math.abs(len-c.radius)<=tol*1.5&&len>1e-15&&angleOnArc(Math.atan2(dy,dx),c);});
      // Snap the cursor to the analytic circular locus, not to a tessellated chord.
      for(const c of curves){const dx=point.x-c.center.x,dy=point.y-c.center.y,len=Math.hypot(dx,dy);if(len<1e-15)continue;const a=Math.atan2(dy,dx);if(!angleOnArc(a,c))continue;const q={x:c.center.x+c.radius*dx/len,y:c.center.y+c.radius*dy/len},d=(q.x-point.x)**2+(q.y-point.y)**2;if(mode==='nearest'&&d<nearestD2){nearestD2=d;nearest={point:q,type:'nearest',distance:d};}else if(mode==='intersection')add(q.x,q.y,'nearest',d);}
      if(mode==='intersection'){
        // Exact finite segment / circular-arc intersections.
        for(const c of curves)for(const item of nearSegments){const seg=item.seg,dx=seg.b.x-seg.a.x,dy=seg.b.y-seg.a.y,fx=seg.a.x-c.center.x,fy=seg.a.y-c.center.y,A=dx*dx+dy*dy;if(A<1e-20)continue;const B=2*(fx*dx+fy*dy),C=fx*fx+fy*fy-c.radius*c.radius,disc=B*B-4*A*C;if(disc<-1e-10)continue;const root=Math.sqrt(Math.max(0,disc));for(const t of[(-B-root)/(2*A),(-B+root)/(2*A)])if(t>=-1e-9&&t<=1+1e-9){const x=seg.a.x+t*dx,y=seg.a.y+t*dy,a=Math.atan2(y-c.center.y,x-c.center.x),d=(x-point.x)**2+(y-point.y)**2;if(angleOnArc(a,c)){const k=`arc:${Math.round(x/Math.max(tol,1e-9)*1e7)}:${Math.round(y/Math.max(tol,1e-9)*1e7)}`;if(!seen.has(k)){seen.add(k);add(x,y,'intersection',d);}}}}
        // Exact circle/arc to circle/arc intersections.
        for(let i=0;i<curves.length;i++)for(let j=i+1;j<curves.length;j++){const a=curves[i],b=curves[j],dx=b.center.x-a.center.x,dy=b.center.y-a.center.y,d=Math.hypot(dx,dy);if(d<1e-12||d>a.radius+b.radius+tol||d<Math.abs(a.radius-b.radius)-tol)continue;const x0=(a.radius*a.radius-b.radius*b.radius+d*d)/(2*d),h2=a.radius*a.radius-x0*x0;if(h2<-tol2)continue;const h=Math.sqrt(Math.max(0,h2)),mx=a.center.x+x0*dx/d,my=a.center.y+x0*dy/d,ox=-dy*h/d,oy=dx*h/d;for(const q of[{x:mx+ox,y:my+oy},{x:mx-ox,y:my-oy}]){const aa=Math.atan2(q.y-a.center.y,q.x-a.center.x),ab=Math.atan2(q.y-b.center.y,q.x-b.center.x),dist=(q.x-point.x)**2+(q.y-point.y)**2;if(angleOnArc(aa,a)&&angleOnArc(ab,b))add(q.x,q.y,'intersection',dist);}}
      }
    }
    if(nearest&&nearestD2<=tol2)candidates.push(nearest);
    for(const p of geometry.points||[]){const d=(p.x-point.x)**2+(p.y-point.y)**2;if(d<=tol2)add(p.x,p.y,'endpoint',d);if(d<nearestD2){nearestD2=d;nearest={point:{x:p.x,y:p.y},type:'nearest',distance:d};}}
    if(nearest&&nearestD2<=tol2)candidates.push(nearest);
    const priority={intersection:0,endpoint:1,midpoint:2,nearest:3};
    const allowed=mode==='nearest'?['nearest']:mode==='endpoint'?['endpoint','nearest']:mode==='midpoint'?['midpoint','nearest']:['intersection','endpoint','midpoint','nearest'];
    const valid=candidates.filter(c=>allowed.includes(c.type));if(!valid.length)return null;valid.sort((a,b)=>(priority[a.type]-priority[b.type])||a.distance-b.distance);
    const best=valid[0],labels={intersection:'تقاطع',endpoint:'نهاية عنصر',midpoint:'منتصف عنصر',nearest:'أقرب نقطة'};return{point:best.point,type:best.type,typeLabel:labels[best.type],distance:Math.sqrt(best.distance)};
  }
  function svgPathToPolylines(d, scale = 8, color = '#000000') {
    const tokens=String(d||'').match(/[A-Za-z]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?/g)||[];
    let i=0,cmd='',x=0,y=0,sx=0,sy=0,lastC=null,lastQ=null,path=[],paths=[];
    const isCmd=t=>/^[A-Za-z]$/.test(t),num=()=>Number(tokens[i++]),push=(px,py)=>{if(finite(px)&&finite(py))path.push({x:px,y:py});};
    const finish=closed=>{if(path.length>1)paths.push({points:path,closed,color});path=[];};
    const angle=(ux,uy,vx,vy)=>{const dot=ux*vx+uy*vy,det=ux*vy-uy*vx;return Math.atan2(det,dot);};
    while(i<tokens.length){if(isCmd(tokens[i]))cmd=tokens[i++];if(!cmd)break;const rel=cmd===cmd.toLowerCase(),upper=cmd.toUpperCase();
      if(upper==='Z'){push(sx,sy);finish(true);x=sx;y=sy;cmd='';lastC=lastQ=null;continue;}
      if(upper==='M'||upper==='L'||upper==='T'){if(i+1>=tokens.length)break;let nx=num(),ny=num();if(rel){nx+=x;ny+=y;}if(upper==='M'){if(path.length)finish(false);sx=nx;sy=ny;push(nx,ny);cmd=rel?'l':'L';}else if(upper==='T'){const qx=lastQ?2*x-lastQ.x:x,qy=lastQ?2*y-lastQ.y:y,ox=x,oy=y;for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*ox+2*u*t*qx+t*t*nx,u*u*oy+2*u*t*qy+t*t*ny);}lastQ={x:qx,y:qy};}else push(nx,ny);x=nx;y=ny;lastC=null;if(upper!=='T')lastQ=null;}
      else if(upper==='H'||upper==='V'){let z=num();if(rel)z+=upper==='H'?x:y;if(upper==='H')x=z;else y=z;push(x,y);lastC=lastQ=null;}
      else if(upper==='C'){if(i+5>=tokens.length)break;let x1=num(),y1=num(),x2=num(),y2=num(),nx=num(),ny=num();if(rel){x1+=x;y1+=y;x2+=x;y2+=y;nx+=x;ny+=y;}const ox=x,oy=y;for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*u*ox+3*u*u*t*x1+3*u*t*t*x2+t*t*t*nx,u*u*u*oy+3*u*u*t*y1+3*u*t*t*y2+t*t*t*ny);}x=nx;y=ny;lastC={x:x2,y:y2};lastQ=null;}
      else if(upper==='S'){if(i+3>=tokens.length)break;const x1=lastC?2*x-lastC.x:x,y1=lastC?2*y-lastC.y:y;let x2=num(),y2=num(),nx=num(),ny=num();if(rel){x2+=x;y2+=y;nx+=x;ny+=y;}const ox=x,oy=y;for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*u*ox+3*u*u*t*x1+3*u*t*t*x2+t*t*t*nx,u*u*u*oy+3*u*u*t*y1+3*u*t*t*y2+t*t*t*ny);}x=nx;y=ny;lastC={x:x2,y:y2};lastQ=null;}
      else if(upper==='Q'){if(i+3>=tokens.length)break;let x1=num(),y1=num(),nx=num(),ny=num();if(rel){x1+=x;y1+=y;nx+=x;ny+=y;}const ox=x,oy=y;for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*ox+2*u*t*x1+t*t*nx,u*u*oy+2*u*t*y1+t*t*ny);}x=nx;y=ny;lastQ={x:x1,y:y1};lastC=null;}
      else if(upper==='A'){
        if(i+6>=tokens.length)break;let rx=Math.abs(num()),ry=Math.abs(num()),phi=num()*Math.PI/180,large=!!num(),sweep=!!num(),nx=num(),ny=num();if(rel){nx+=x;ny+=y;}if(rx<1e-12||ry<1e-12||Math.hypot(nx-x,ny-y)<1e-12){push(nx,ny);x=nx;y=ny;continue;}
        const cp=Math.cos(phi),sp=Math.sin(phi),dx=(x-nx)/2,dy=(y-ny)/2,xp=cp*dx+sp*dy,yp=-sp*dx+cp*dy,lam=xp*xp/(rx*rx)+yp*yp/(ry*ry);if(lam>1){const k=Math.sqrt(lam);rx*=k;ry*=k;}
        const den=rx*rx*yp*yp+ry*ry*xp*xp,numc=Math.max(0,rx*rx*ry*ry-den),sgn=(large===sweep)?-1:1,coef=den?sgn*Math.sqrt(numc/den):0,cxp=coef*(rx*yp/ry),cyp=coef*(-ry*xp/rx),cx=cp*cxp-sp*cyp+(x+nx)/2,cy=sp*cxp+cp*cyp+(y+ny)/2;
        const ux=(xp-cxp)/rx,uy=(yp-cyp)/ry,vx=(-xp-cxp)/rx,vy=(-yp-cyp)/ry,theta=Math.atan2(uy,ux);let delta=angle(ux,uy,vx,vy);if(!sweep&&delta>0)delta-=Math.PI*2;if(sweep&&delta<0)delta+=Math.PI*2;
        const n=Math.max(16,Math.min(2048,Math.ceil(Math.abs(delta)*Math.max(rx,ry)/Math.max(.5,scale/4))));for(let k=1;k<=n;k++){const a=theta+delta*k/n,px=rx*Math.cos(a),py=ry*Math.sin(a);push(cx+cp*px-sp*py,cy+sp*px+cp*py);}x=nx;y=ny;lastC=lastQ=null;
      }else throw new Error('مسار SVG يحتوي أمرًا غير مدعوم: '+cmd);
    }
    if(path.length)finish(false);return paths;
  }
  function svgColorInfo(fill,style=''){
    let value=String(fill||'').trim().toLowerCase();if(!value||value==='none')value=String(style||'').match(/(?:^|;)\s*fill\s*:\s*([^;]+)/i)?.[1]?.trim().toLowerCase()||'';
    if(!value)return{white:false,aci:7,rgb:0};if(value==='none')return{white:true,aci:7,rgb:0xffffff};
    let rgb=null,m=value.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);if(m){let h=m[1];if(h.length===3)h=h.split('').map(c=>c+c).join('');rgb=parseInt(h,16);}else if((m=value.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i)))rgb=(Math.min(255,+m[1])<<16)|(Math.min(255,+m[2])<<8)|Math.min(255,+m[3]);
    if(rgb===null)return{white:/white/.test(value),aci:7,rgb:0};const r=(rgb>>16)&255,g=(rgb>>8)&255,b=rgb&255,white=r>=248&&g>=248&&b>=248;
    const palette=[{aci:1,r:255,g:0,b:0},{aci:2,r:255,g:255,b:0},{aci:3,r:0,g:255,b:0},{aci:4,r:0,g:255,b:255},{aci:5,r:0,g:0,b:255},{aci:6,r:255,g:0,b:255},{aci:7,r:0,g:0,b:0}];let best=palette[0],bd=Infinity;for(const c of palette){const d=(r-c.r)**2+(g-c.g)**2+(b-c.b)**2;if(d<bd){bd=d;best=c;}}return{white,aci:best.aci,rgb};
  }
  function svgPathsToCad(svg,width,height,curveScale=8){
    const xml=String(svg||'');if(!/<svg\b/i.test(xml))throw new Error('لم ينتج محرك التتبع مستند SVG صالحًا.');
    const paths=[],stack=[{tag:'svg',fill:'',stroke:'',opacity:1,fillOpacity:1,strokeOpacity:1}],tagRe=/<\/?([a-zA-Z][\w:-]*)\b([^>]*)>/g;
    const attrsOf=raw=>{const a={};for(const m of raw.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/g))a[m[1].toLowerCase()]=m[2]??m[3]??m[4]??'';return a;};
    const styleOf=style=>{const a={};for(const part of String(style||'').split(';')){const i=part.indexOf(':');if(i>0)a[part.slice(0,i).trim().toLowerCase()]=part.slice(i+1).trim();}return a;};
    const shapePath=(tag,a)=>{const n=k=>Number(a[k]||0);if(tag==='polyline'||tag==='polygon'){const nums=String(a.points||'').trim().split(/[\s,]+/).map(Number);if(nums.length<4||nums.length%2||nums.some(x=>!finite(x)))return'';let d=`M${nums[0]} ${nums[1]}`;for(let i=2;i<nums.length;i+=2)d+=`L${nums[i]} ${nums[i+1]}`;return d+(tag==='polygon'?'Z':'');}if(tag==='line')return`M${n('x1')} ${n('y1')}L${n('x2')} ${n('y2')}`;if(tag==='rect'){const x=n('x'),y=n('y'),w=n('width'),h=n('height');return w>0&&h>0?`M${x} ${y}H${x+w}V${y+h}H${x}Z`:'';}if(tag==='circle'||tag==='ellipse'){const cx=n('cx'),cy=n('cy'),rx=tag==='circle'?n('r'):n('rx'),ry=tag==='circle'?n('r'):n('ry');if(rx<=0||ry<=0)return'';return`M${cx-rx} ${cy}A${rx} ${ry} 0 1 0 ${cx+rx} ${cy}A${rx} ${ry} 0 1 0 ${cx-rx} ${cy}Z`;}return a.d||'';};
    for(const m of xml.matchAll(tagRe)){const closing=m[0].startsWith('</'),tag=m[1].toLowerCase();if(closing){for(let i=stack.length-1;i>0;i--){const hit=stack[i].tag===tag;stack.pop();if(hit)break;}continue;}
      const attrs=attrsOf(m[2]),sty=styleOf(attrs.style),parent=stack[stack.length-1],effective={tag,fill:attrs.fill??sty.fill??parent.fill,stroke:attrs.stroke??sty.stroke??parent.stroke,opacity:Number(attrs.opacity??sty.opacity??parent.opacity??1),fillOpacity:Number(attrs['fill-opacity']??sty['fill-opacity']??parent.fillOpacity??1),strokeOpacity:Number(attrs['stroke-opacity']??sty['stroke-opacity']??parent.strokeOpacity??1)};
      if(['path','polyline','polygon','line','rect','circle','ellipse'].includes(tag)){
        const d=shapePath(tag,attrs),paint=(effective.fill&&effective.fill.toLowerCase()!=='none'&&effective.fillOpacity>0)?effective.fill:(effective.stroke&&effective.stroke.toLowerCase()!=='none'&&effective.strokeOpacity>0?effective.stroke:effective.fill||effective.stroke||'black');
        if(d&&effective.opacity>0){const color=svgColorInfo(paint,'');if(!color.white){for(const p of svgPathToPolylines(d,curveScale,`#${color.rgb.toString(16).padStart(6,'0')}`)){p.aci=color.aci;p.rgb=color.rgb;paths.push(p);}}}
      }
      if(!/\/\s*>$/.test(m[0])&&!['path','polyline','polygon','line','rect','circle','ellipse'].includes(tag))stack.push(effective);
      else if(!/\/\s*>$/.test(m[0])&&['path','polyline','polygon','line','rect','circle','ellipse'].includes(tag))stack.push(effective);
    }
    const isFrame=p=>{const pts=p.points||[];if(!p.closed||pts.length<4||pts.length>1024)return false;const xs=pts.map(q=>q.x),ys=pts.map(q=>q.y),mnx=Math.min(...xs),mxx=Math.max(...xs),mny=Math.min(...ys),mxy=Math.max(...ys),bw=mxx-mnx,bh=mxy-mny;if(bw<width*.82||bh<height*.82||mnx>width*.10||mxx<width*.90||mny>height*.10||mxy<height*.90)return false;const margin=Math.max(1,Math.min(width,height)*.015),edgeCount=pts.filter(q=>Math.min(Math.abs(q.x-mnx),Math.abs(q.x-mxx),Math.abs(q.y-mny),Math.abs(q.y-mxy))<=margin).length;return edgeCount/pts.length>=.88;};
    const content=paths.filter(p=>!isFrame(p));if(!content.length)throw new Error('لم يتم استخراج محتوى اللوحة داخل الصفحة؛ تم اكتشاف إطار الورقة فقط. جرّب دقة PDF أعلى أو نسخة أوضح من الصورة.');
    const vertices=content.reduce((n,p)=>n+(p.points?.length||0),0);if(vertices<4)throw new Error('المحتوى المستخرج غير كافٍ لإنشاء لوحة DXF.');return content;
  }
  function polylinesToDxf(paths,width,height,factor){
    const layers=[...new Set(paths.map(p=>Number(p.aci)||7))].sort((a,b)=>a-b),layerName=c=>`TRACE_ACI_${c}`;
    let out='0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1009\n0\nENDSEC\n0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLTYPE\n70\n1\n0\nLTYPE\n2\nCONTINUOUS\n70\n0\n3\nSolid line\n72\n65\n73\n0\n40\n0.0\n0\nENDTAB\n0\nTABLE\n2\nLAYER\n70\n'+(layers.length+1)+'\n0\nLAYER\n2\n0\n70\n0\n62\n7\n6\nCONTINUOUS\n';
    for(const c of layers)out+=`0\nLAYER\n2\n${layerName(c)}\n70\n0\n62\n${c}\n6\nCONTINUOUS\n`;
    out+='0\nENDTAB\n0\nENDSEC\n0\nSECTION\n2\nBLOCKS\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n';let count=0,vertices=0;
    for(const p of paths){let v=p.points||[];if(v.length<2)continue;if(p.closed&&v.length>2&&Math.hypot(v[0].x-v[v.length-1].x,v[0].y-v[v.length-1].y)<1e-6)v=v.slice(0,-1);if(v.length<2)continue;const layer=layerName(Number(p.aci)||7),rgb=Number(p.rgb);out+=`0\nPOLYLINE\n8\n${layer}\n${finite(rgb)&&rgb>=0?`420\n${Math.round(rgb)&0xffffff}\n`:''}66\n1\n70\n${p.closed?1:0}\n`;for(const q of v){out+=`0\nVERTEX\n8\n${layer}\n10\n${fmt(q.x*factor)}\n20\n${fmt((height-q.y)*factor)}\n30\n0\n`;vertices++;}out+=`0\nSEQEND\n8\n${layer}\n`;count++;}
    if(!count)throw new Error('لم ينتج التحويل مسارات داخلية قابلة للحفظ.');out+='0\nENDSEC\n0\nEOF\n';return{bytes:enc.encode(out),count,vertices,layers};
  }
  /* Raw-record DXF board merge. Source entity records and supported symbol/block
     records are copied verbatim; only colliding handles, owners and symbol names
     are remapped. Unsupported external/object references fail closed. */
  function* dxfPairs(bytes, start=0, end=bytes.length) {
    let pos=start;
    while(pos<end){
      const c=readLine(bytes,pos); if(!c||c.end>end) break;
      const v=readLine(bytes,c.end); if(!v||v.end>end) break;
      yield {code:Number.parseInt(pairText(bytes,c),10),value:pairText(bytes,v),start:c.start,valueStart:v.start,valueEnd:v.valueEnd,end:v.end};
      pos=v.end;
    }
  }
  function dxfSectionBounds(bytes,name){
    let previous=null,active='',start=null;
    for(const p of dxfPairs(bytes)){
      if(previous&&previous.code===0&&previous.value.toUpperCase()==='SECTION'&&p.code===2){active=p.value.toUpperCase();start=p.end;}
      if(active===name.toUpperCase()&&p.code===0&&p.value.toUpperCase()==='ENDSEC')return {start,end:p.start,endPair:p};
      previous=p;
    }
    return null;
  }
  function dxfTableMap(bytes){
    const out=new Map();let previous=null,active=null,row=null,header=[];
    const finishRow=end=>{if(row){row.end=end;active.rows.push(row);row=null;}};
    const finishTable=()=>{if(active){if(active.endTab)finishRow(active.endTab.start);active.header=header;active.handle=header.find(p=>p.code===5)?.value||null;active.countPair=header.find(p=>p.code===70)||null;out.set(active.name,active);}active=null;header=[];};
    for(const p of dxfPairs(bytes)){
      if(previous&&previous.code===0&&previous.value.toUpperCase()==='TABLE'&&p.code===2){finishTable();active={name:p.value.toUpperCase(),start:previous.start,rows:[],endTab:null};header=[];row=null;}
      else if(active){
        if(p.code===0){if(p.value.toUpperCase()==='ENDTAB'){finishRow(p.start);active.endTab=p;finishTable();}else{finishRow(p.start);row={type:p.value.toUpperCase(),start:p.start,name:'',end:null};}}
        else if(row){if(p.code===2&&!row.name)row.name=p.value;}
        else header.push(p);
      }
      previous=p;
    }
    return out;
  }
  function dxfRowFields(bytes,row){return [...dxfPairs(bytes,row.start,row.end)];}
  function dxfRecordSignature(bytes,row){return dxfRowFields(bytes,row).filter(p=>![5,105,330].includes(p.code)).map(p=>`${p.code}:${p.value}`).join('\n');}
  function dxfBlockDefinitions(bytes){
    const sec=dxfSectionBounds(bytes,'BLOCKS');if(!sec)return [];
    const defs=[];let current=null;
    for(const p of dxfPairs(bytes,sec.start,sec.end)){
      if(p.code===0){
        const type=p.value.toUpperCase();
        if(type==='BLOCK'){if(current)throw new Error('تعريف BLOCK متداخل أو غير مغلق في اللوحة المصدر.');current={start:p.start,end:null,name:''};}
        else if(type==='ENDBLK'&&current){current.end=p.end;defs.push(current);current=null;}
      }else if(current&&p.code===2&&!current.name)current.name=p.value;
    }
    if(current)throw new Error('تعريف بلوك غير مكتمل في اللوحة المصدر.');
    return defs;
  }
  function dxfMaxHandle(bytes){let max=0n;for(const p of dxfPairs(bytes))if((p.code===5||p.code===105)&&/^[0-9A-F]+$/i.test(p.value)){const n=BigInt('0x'+p.value);if(n>max)max=n;}return max;}
  function dxfFindModelHandle(table,which){
    if(!table)return null;
    for(const r of table.rows){const n=String(r.name||'').replace(/[\s_-]/g,'').toUpperCase();if(n===which){const h=dxfRowFields(table._bytes,r).find(p=>p.code===5)?.value;return h||null;}}
    return null;
  }
  function dxfUniqueName(prefix,name,used,max=31){
    const base=String(name||'ITEM'),suffixBase=prefix+base;let candidate=suffixBase.slice(0,max),i=1;
    while(used.has(candidate.toUpperCase())){const suffix='_'+i++;candidate=suffixBase.slice(0,Math.max(1,max-suffix.length))+suffix;}
    used.add(candidate.toUpperCase());return candidate;
  }
  function dxfCollectHandles(bytes,ranges){
    const set=new Set();for(const [a,b] of ranges)for(const p of dxfPairs(bytes,a,b))if((p.code===5||p.code===105)&&/^[0-9A-F]+$/i.test(p.value))set.add(p.value.toUpperCase());return set;
  }
  function dxfRewriteRange(bytes,start,end,context,handleMap,edits){
    let entityType='';
    for(const p of dxfPairs(bytes,start,end)){
      if(p.code===0)entityType=p.value.toUpperCase();
      let replacement=null;
      if((p.code===5||p.code===105)&&handleMap.has(p.value.toUpperCase()))replacement=handleMap.get(p.value.toUpperCase());
      else if((p.code>=330&&p.code<=369)||p.code===1005){
        const h=p.value.toUpperCase();
        if(context.ownerMap?.has(h))replacement=context.ownerMap.get(h);
        else if(handleMap.has(h))replacement=handleMap.get(h);
        else if(/^[0-9A-F]+$/i.test(p.value))throw new Error(`يوجد مرجع DXF إلى مقبض خارجي ${p.value} (المجموعة ${p.code}) لم يمكن استيراده بأمان. لم يتم إنشاء ناتج ناقص.`);
      }
      if(replacement===null){
        const maps=context.names||{};
        if(p.code===8&&maps.LAYER?.has(p.value))replacement=maps.LAYER.get(p.value);
        else if(p.code===6&&maps.LTYPE?.has(p.value))replacement=maps.LTYPE.get(p.value);
        else if(p.code===7&&maps.STYLE?.has(p.value))replacement=maps.STYLE.get(p.value);
        else if(p.code===3&&entityType==='DIMENSION'&&maps.DIMSTYLE?.has(p.value))replacement=maps.DIMSTYLE.get(p.value);
        else if(p.code===1001&&maps.APPID?.has(p.value))replacement=maps.APPID.get(p.value);
        else if((entityType==='INSERT'||entityType==='DIMENSION')&&p.code===2&&maps.BLOCK?.has(p.value))replacement=maps.BLOCK.get(p.value);
        else if((entityType==='BLOCK'||entityType==='ENDBLK')&&(p.code===2||p.code===3)&&maps.BLOCK?.has(p.value))replacement=maps.BLOCK.get(p.value);
        else if(context.tableName&&p.code===2&&maps[context.tableName]?.has(p.value))replacement=maps[context.tableName].get(p.value);
        else if(context.tableName==='LAYER'&&p.code===6&&maps.LTYPE?.has(p.value))replacement=maps.LTYPE.get(p.value);
        else if(context.tableName==='DIMSTYLE'&&p.code===3&&maps.STYLE?.has(p.value))replacement=maps.STYLE.get(p.value);
      }
      if(replacement!==null&&String(replacement)!==p.value)edits.push({start:p.valueStart,end:p.valueEnd,insertBytes:enc.encode(String(replacement))});
    }
  }
  function dxfConcat(parts){let n=0;for(const p of parts)n+=p.length;const out=new Uint8Array(n);let at=0;for(const p of parts){out.set(p,at);at+=p.length;}return out;}
  function dxfParseHandseed(bytes){let previous=null;for(const p of dxfPairs(bytes)){if(previous&&previous.code===9&&previous.value.toUpperCase()==='$HANDSEED'&&p.code===5)return p;previous=p;}return null;}
  function mergeRawDxfBoards(targetInput,sourceInput){
    const target=targetInput instanceof Uint8Array?targetInput:new Uint8Array(targetInput),source=sourceInput instanceof Uint8Array?sourceInput:new Uint8Array(sourceInput);
    if(!target.length||!source.length)throw new Error('أحد ملفي DXF فارغ.');
    const ts=dxfSectionBounds(target,'ENTITIES'),ss=dxfSectionBounds(source,'ENTITIES'),tb=dxfSectionBounds(target,'BLOCKS'),sb=dxfSectionBounds(source,'BLOCKS');
    if(!ts||!ss)throw new Error('يجب أن يحتوي الملفان على قسم ENTITIES صالح.');
    if(!tb)throw new Error('اللوحة المرجعية لا تحتوي على قسم BLOCKS. أوقفت الدمج لحماية بنية الملف.');
    const tt=dxfTableMap(target),st=dxfTableMap(source);tt.forEach(v=>v._bytes=target);st.forEach(v=>v._bytes=source);
    if(!tt.has('LAYER')||!st.has('LAYER'))throw new Error('جدول LAYER مفقود في أحد الملفين.');
    const hasTargetBlockRecord=tt.has('BLOCK_RECORD'),hasSourceBlockRecord=st.has('BLOCK_RECORD');
    if(hasTargetBlockRecord!==hasSourceBlockRecord)throw new Error('إصدارا DXF يستخدمان بنيتين مختلفتين لجدول BLOCK_RECORD؛ أوقفت الدمج حتى لا تتغير بنية الملف.');
    const hasBlockRecord=hasTargetBlockRecord;
    const targetModel=hasBlockRecord?dxfFindModelHandle(tt.get('BLOCK_RECORD'),' *MODELSPACE'.trim()):null;
    const sourceModel=hasBlockRecord?dxfFindModelHandle(st.get('BLOCK_RECORD'),' *MODELSPACE'.trim()):null;
    if(hasBlockRecord&&(!targetModel||!sourceModel))throw new Error('تعذر تحديد Model Space في أحد الملفين.');
    const reserved=n=>String(n||'').replace(/[\s_-]/g,'').toUpperCase();
    const sysNames=new Set(['*MODELSPACE','*PAPERSPACE','*PAPERSPACE0']);
    const targetDefs=dxfBlockDefinitions(target),srcDefs=dxfBlockDefinitions(source);
    const targetBlockNames=new Set((hasBlockRecord?tt.get('BLOCK_RECORD').rows.map(r=>String(r.name||'')):targetDefs.map(d=>d.name)).map(n=>n.toUpperCase()));
    const defsByName=new Map(srcDefs.map(d=>[d.name.toUpperCase(),d]));
    const srcBlockRows=hasBlockRecord?st.get('BLOCK_RECORD').rows:[],blockMap=new Map();
    if(hasBlockRecord){
      for(const row of srcBlockRows){
        const name=row.name||'';if(!name)continue;
        if(sysNames.has(reserved(name)))continue;
        const def=defsByName.get(name.toUpperCase());if(!def)throw new Error(`تعريف البلوك ${name} مسجل في BLOCK_RECORD لكنه بلا بيانات BLOCK. أوقفت الدمج لمنع فقد العناصر.`);
        const mapped=targetBlockNames.has(name.toUpperCase())?dxfUniqueName('SQ163_',name,targetBlockNames,255):name;
        targetBlockNames.add(mapped.toUpperCase());blockMap.set(name,mapped);
      }
    }else{
      // Legacy R12/R13 DXF has no BLOCK_RECORD table. Preserve its block records
      // directly and remap names for INSERT/BLOCK references without inventing tables.
      for(const def of srcDefs){const name=def.name||'';if(!name||sysNames.has(reserved(name)))continue;const mapped=targetBlockNames.has(name.toUpperCase())?dxfUniqueName('SQ163_',name,targetBlockNames,31):name;targetBlockNames.add(mapped.toUpperCase());blockMap.set(name,mapped);}
    }
    for(const def of srcDefs)if(!sysNames.has(reserved(def.name))&&!blockMap.has(def.name))throw new Error(`تعريف البلوك ${def.name} غير مرتبط بسجل يمكن استيراده بأمان.`);
    const nameMaps={LAYER:new Map(),LTYPE:new Map(),STYLE:new Map(),DIMSTYLE:new Map(),APPID:new Map(),BLOCK:new Map(blockMap),BLOCK_RECORD:new Map(blockMap)};
    const tablesToMerge=['LAYER','LTYPE','STYLE','DIMSTYLE','APPID'];
    const plannedRows=new Map();
    for(const tableName of tablesToMerge){
      const srcTable=st.get(tableName),dstTable=tt.get(tableName);if(!srcTable){plannedRows.set(tableName,[]);continue;}
      if(!dstTable)throw new Error(`جدول ${tableName} غير موجود في اللوحة المرجعية بينما تحتاجه اللوحة المصدر.`);
      const existing=new Map(dstTable.rows.map(r=>[String(r.name||'').toUpperCase(),r])),used=new Set(existing.keys()),rows=[];
      for(const sr of srcTable.rows){
        const name=sr.name||'';if(!name)continue;
        if(tableName==='LAYER'&&name==='0'){const zero=existing.get('0');if(zero&&dxfRecordSignature(target,zero)!==dxfRecordSignature(source,sr))throw new Error('تعريف الطبقة 0 مختلف بين اللوحتين؛ أوقفت الدمج لحماية خصائصها.');nameMaps.LAYER.set(name,'0');continue;}
        const dr=existing.get(name.toUpperCase());
        if(!dr){nameMaps[tableName].set(name,name);rows.push(sr);used.add(name.toUpperCase());continue;}
        if(dxfRecordSignature(target,dr)===dxfRecordSignature(source,sr)){nameMaps[tableName].set(name,name);continue;}
        const mapped=dxfUniqueName('SQ163_',name,used,tableName==='LAYER'?31:255);nameMaps[tableName].set(name,mapped);rows.push(sr);
      }
      plannedRows.set(tableName,rows);
    }
    const reservedMap=new Map();
    if(hasBlockRecord)for(const name of ['*Model_Space','*Paper_Space','*Paper_Space0']){
      const sr=srcBlockRows.find(r=>reserved(r.name)===reserved(name)),tr=tt.get('BLOCK_RECORD').rows.find(r=>reserved(r.name)===reserved(name));
      if(sr&&tr){const sh=dxfRowFields(source,sr).find(p=>p.code===5)?.value,th=dxfRowFields(target,tr).find(p=>p.code===5)?.value;if(sh&&th)reservedMap.set(sh.toUpperCase(),th);}
    }
    const sourceRanges=[[ss.start,ss.end]];if(sb)for(const d of srcDefs)if(blockMap.has(d.name))sourceRanges.push([d.start,d.end]);
    for(const n of tablesToMerge)for(const r of plannedRows.get(n)||[])sourceRanges.push([r.start,r.end]);
    const blockRecordRows=hasBlockRecord?srcBlockRows.filter(r=>blockMap.has(r.name)):[];for(const r of blockRecordRows)sourceRanges.push([r.start,r.end]);
    const defined=dxfCollectHandles(source,sourceRanges),targetMax=dxfMaxHandle(target);let next=targetMax+1n;const handleMap=new Map();
    for(const h of defined){if(handleMap.has(h))throw new Error(`مقبض مكرر في المصدر: ${h}`);handleMap.set(h,(next++).toString(16).toUpperCase());}
    const ownerMap=new Map(reservedMap);
    for(const n of (hasBlockRecord?[...tablesToMerge,'BLOCK_RECORD']:tablesToMerge)){const a=st.get(n),b=tt.get(n);if(a?.handle&&b?.handle)ownerMap.set(a.handle.toUpperCase(),b.handle);}
    for(const row of blockRecordRows){const old=dxfRowFields(source,row).find(p=>p.code===5)?.value,newHandle=old&&handleMap.get(old.toUpperCase());if(old&&newHandle)ownerMap.set(old.toUpperCase(),newHandle);}
    const edits=[];
    dxfRewriteRange(source,ss.start,ss.end,{names:nameMaps,ownerMap},handleMap,edits);
    if(sb)for(const d of srcDefs)if(blockMap.has(d.name))dxfRewriteRange(source,d.start,d.end,{names:nameMaps,ownerMap},handleMap,edits);
    for(const n of tablesToMerge){const dst=tt.get(n);for(const r of plannedRows.get(n)||[])dxfRewriteRange(source,r.start,r.end,{names:nameMaps,ownerMap,tableName:n},handleMap,edits);}
    for(const r of blockRecordRows)dxfRewriteRange(source,r.start,r.end,{names:nameMaps,ownerMap,tableName:'BLOCK_RECORD'},handleMap,edits);
    const rewritten=edits.length?applyEdits(source,edits):source;
    const copied={};
    const rewrittenTables=dxfTableMap(rewritten);rewrittenTables.forEach(v=>v._bytes=rewritten);
    for(const n of tablesToMerge){copied[n]=[];const now=rewrittenTables.get(n);for(const r of plannedRows.get(n)||[]){const wanted=String(nameMaps[n].get(r.name)||r.name).toUpperCase();const matching=now?.rows.find(z=>z.name.toUpperCase()===wanted);if(!matching)throw new Error(`فشل تحديد سجل ${n} بعد إعادة ربط المراجع.`);copied[n].push(rewritten.subarray(matching.start,matching.end));}}
    const mappedBlockNames=new Set([...blockMap.values()].map(n=>n.toUpperCase()));
    copied.BLOCK_RECORD=[];if(hasBlockRecord)for(const r of rewrittenTables.get('BLOCK_RECORD').rows)if(mappedBlockNames.has(String(r.name||'').toUpperCase()))copied.BLOCK_RECORD.push(rewritten.subarray(r.start,r.end));
    const rewrittenDefs=dxfBlockDefinitions(rewritten);copied.BLOCKS=[];
    for(const d of rewrittenDefs)if(mappedBlockNames.has(d.name.toUpperCase()))copied.BLOCKS.push(rewritten.subarray(d.start,d.end));
    const newEnt=dxfSectionBounds(rewritten,'ENTITIES'),entityBytes=rewritten.subarray(newEnt.start,newEnt.end);
    const targetEdits=[];
    for(const n of (hasBlockRecord?[...tablesToMerge,'BLOCK_RECORD']:tablesToMerge)){const rows=copied[n]||[];if(!rows.length)continue;const t=tt.get(n);if(!t?.endTab)throw new Error(`لا يمكن إضافة سجلات جدول ${n}.`);targetEdits.push({start:t.endTab.start,end:t.endTab.start,insertBytes:dxfConcat(rows)});if(t.countPair)targetEdits.push({start:t.countPair.valueStart,end:t.countPair.valueEnd,insertBytes:enc.encode(String(t.rows.length+rows.length))});}
    if(copied.BLOCKS.length)targetEdits.push({start:tb.end,end:tb.end,insertBytes:dxfConcat(copied.BLOCKS)});
    if(entityBytes.length)targetEdits.push({start:ts.end,end:ts.end,insertBytes:entityBytes});
    const handseed=dxfParseHandseed(target);if(handseed)targetEdits.push({start:handseed.valueStart,end:handseed.valueEnd,insertBytes:enc.encode(next.toString(16).toUpperCase())});
    const merged=applyEdits(target,targetEdits),verifyTables=dxfTableMap(merged),verifyBlocks=dxfBlockDefinitions(merged),verifyEntities=dxfSectionBounds(merged,'ENTITIES');
    if(!verifyTables.get('LAYER')?.endTab||(hasBlockRecord&&!verifyTables.get('BLOCK_RECORD')?.endTab)||!verifyEntities)throw new Error('فشل التحقق البنيوي من DXF الناتج.');
    if(mappedBlockNames.size&&verifyBlocks.filter(d=>mappedBlockNames.has(d.name.toUpperCase())).length!==mappedBlockNames.size)throw new Error('لم يتم استيراد كل تعريفات البلوكات المصدرية.');
    let importedEntities=0;for(const p of dxfPairs(rewritten,newEnt.start,newEnt.end))if(p.code===0&&p.value.toUpperCase()!=='ENDSEC')importedEntities++;
  return {bytes:merged,sourceEntitiesBytes:entityBytes.length,importedEntities,importedBlocks:copied.BLOCKS.length,importedLayers:(copied.LAYER||[]).length,importedTableRecords:Object.fromEntries((hasBlockRecord?[...tablesToMerge,'BLOCK_RECORD']:tablesToMerge).map(n=>[n,(copied[n]||[]).length]))};
  }

  async function downloadBytes(bytes, filename, mime = 'application/dxf') {
    if (typeof root.safeDownloadFile === 'function') {
      // The app helper asks for the output name, writes to Downloads/SurveyQuant
      // through Android.saveFile, and sends the native completed-download notice.
      return await root.safeDownloadFile(bytes, filename, mime, false);
    }
    const blob = new Blob([bytes], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = root.document.createElement('a'); a.href = url; a.download = filename; a.style.display = 'none';
    root.document.body.appendChild(a); a.click(); a.remove();
    root.setTimeout(() => URL.revokeObjectURL(url), 1000);
    return url;
  }

  function makeRasterUnderlayDxf(imageName,width,height,factor=1){
    if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1)throw new Error('أبعاد صورة الصفحة غير صالحة.');
    if(!finite(factor)||factor<=0)throw new Error('عامل المقياس يجب أن يكون موجبًا.');
    const name=String(imageName||'pdf_page.png').replace(/[\\/\r\n\x00-\x1f]/g,'_').replace(/[^\w.() -]/g,'_');
    const fw=width*factor,fh=height*factor;
    if(!finite(fw)||!finite(fh)||fw<=0||fh<=0)throw new Error('أبعاد صورة الإخراج خارج النطاق.');
    const pairs=[
      '0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','9','$HANDSEED','5','34','0','ENDSEC',
      '0','SECTION','2','TABLES',
      '0','TABLE','2','LTYPE','5','1','330','0','100','AcDbSymbolTable','70','1',
      '0','LTYPE','5','2','330','1','100','AcDbSymbolTableRecord','100','AcDbLinetypeTableRecord','2','CONTINUOUS','70','0','3','Solid line','72','65','73','0','40','0.0','0','ENDTAB',
      '0','TABLE','2','LAYER','5','3','330','0','100','AcDbSymbolTable','70','1',
      '0','LAYER','5','4','330','3','100','AcDbSymbolTableRecord','100','AcDbLayerTableRecord','2','0','70','0','62','7','6','CONTINUOUS','0','ENDTAB',
      '0','TABLE','2','BLOCK_RECORD','5','9','330','0','100','AcDbSymbolTable','70','1',
      '0','BLOCK_RECORD','5','17','330','9','100','AcDbSymbolTableRecord','100','AcDbBlockTableRecord','2','*Model_Space','70','0','0','ENDTAB','0','ENDSEC',
      '0','SECTION','2','BLOCKS',
      '0','BLOCK','5','18','330','17','100','AcDbEntity','8','0','100','AcDbBlockBegin','2','*Model_Space','70','0','10','0','20','0','30','0','3','*Model_Space','1','',
      '0','ENDBLK','5','19','330','17','100','AcDbEntity','8','0','100','AcDbBlockEnd','0','ENDSEC',
      '0','SECTION','2','ENTITIES',
      '0','IMAGE','5','32','330','17','100','AcDbEntity','8','0','100','AcDbRasterImage','90','0',
      '10','0','20','0','30','0','11',fmt(factor),'21','0','31','0','12','0','22',fmt(factor),'32','0',
      '13',String(width),'23',String(height),'340','31','70','3','280','0','281','50','282','50','283','0','360','33',
      '71','1','91','2','14','-0.5','24','-0.5','14',fmt(width-0.5),'24',fmt(height-0.5),'290','0','0','ENDSEC',
      '0','SECTION','2','OBJECTS',
      '0','DICTIONARY','5','A','330','0','100','AcDbDictionary','281','1','3','ACAD_IMAGE_DICT','350','30',
      '0','DICTIONARY','5','30','330','A','100','AcDbDictionary','281','1','3','PDF_PAGE','350','31',
      '0','IMAGEDEF','5','31','102','{ACAD_REACTORS','330','30','330','33','102','}','330','30','100','AcDbRasterImageDef',
      '90','0','1',name,'10',String(width),'20',String(height),'11',fmt(factor),'21',fmt(factor),'280','1','281','0',
      '0','IMAGEDEF_REACTOR','5','33','330','32','100','AcDbRasterImageDefReactor','90','2','330','32',
      '0','ENDSEC','0','EOF',''
    ];
    return enc.encode(pairs.join('\r\n'));
  }
  function crc32(bytes){let c=0xffffffff;for(let i=0;i<bytes.length;i++){c^=bytes[i];for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;}
  function zipStore(entries){
    const enc8=new TextEncoder(),locals=[],centrals=[];let offset=0;
    const u16=n=>new Uint8Array([n&255,(n>>>8)&255]);
    const u32=n=>new Uint8Array([n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]);
    const join=parts=>{const size=parts.reduce((n,p)=>n+p.length,0),out=new Uint8Array(size);let p=0;for(const x of parts){out.set(x,p);p+=x.length;}return out;};
    for(const entry of entries){const name=enc8.encode(String(entry.name)),data=entry.data instanceof Uint8Array?entry.data:new Uint8Array(entry.data),crc=crc32(data);if(!name.length||name.length>65535)throw new Error('اسم ملف داخل الحزمة غير صالح.');
      const local=join([u32(0x04034b50),u16(20),u16(0x0800),u16(0),u16(0),u16(33),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),name,data]);locals.push(local);
      const central=join([u32(0x02014b50),u16(20),u16(20),u16(0x0800),u16(0),u16(0),u16(33),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),name]);centrals.push(central);offset+=local.length;
    }
    const centralBytes=join(centrals),localBytes=join(locals),end=join([u32(0x06054b50),u16(0),u16(0),u16(entries.length),u16(entries.length),u32(centralBytes.length),u32(localBytes.length),u16(0)]);
    return join([localBytes,centralBytes,end]);
  }
  async function canvasPngBytes(canvas){
    if(canvas.toBlob){const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('تعذر إخراج PNG من معاينة الصفحة.')),'image/png'));return new Uint8Array(await blob.arrayBuffer());}
    const url=canvas.toDataURL('image/png'),b64=url.slice(url.indexOf(',')+1),raw=atob(b64),out=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;
  }


  function ensurePdfWorker(lib,doc){
    if(!lib||!lib.GlobalWorkerOptions)throw new Error('إعداد عامل PDF.js غير متاح في هذه النسخة.');
    let workerUrl=root.__sq163PdfWorkerUrl||lib.GlobalWorkerOptions.workerSrc||'';
    if(!workerUrl){
      const node=doc.getElementById('sq163-pdfjs-worker');
      const base64=(node?.textContent||'').trim();
      if(!base64)throw new Error('ملف عامل PDF.js المضمّن غير موجود. أعد تثبيت حزمة التطبيق الكاملة.');
      const raw=atob(base64),bytes=new Uint8Array(raw.length);
      for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
      workerUrl=URL.createObjectURL(new Blob([bytes],{type:'text/javascript'}));
      root.__sq163PdfWorkerUrl=workerUrl;
      root.addEventListener?.('pagehide',()=>{try{URL.revokeObjectURL(workerUrl);}catch(_){}},{once:true});
    }
    lib.GlobalWorkerOptions.workerSrc=workerUrl;
    return workerUrl;
  }

  function mount() {
    if (!root.document || root.document.getElementById('sq162-cad-launch')) return;
    const doc = root.document;
    const style = doc.createElement('style');
    style.id = 'sq162-cad-style';
    style.textContent = `
      #sq162-cad-launch{position:fixed;right:14px;bottom:88px;z-index:2147483000;border:0;border-radius:28px;padding:12px 16px;background:#135ea8;color:#fff;font:700 14px system-ui;box-shadow:0 5px 20px #0004}
      #sq162-cad-overlay{position:fixed;inset:0;z-index:2147483001;background:#0009;display:none;align-items:center;justify-content:center;padding:10px;font-family:system-ui,sans-serif;color:#17202a}
      #sq162-cad-dialog{width:min(100%,980px);max-height:94vh;overflow:auto;background:#fff;border-radius:16px;padding:14px;box-sizing:border-box;direction:rtl;box-shadow:0 12px 55px #0006}
      #sq162-cad-dialog *{box-sizing:border-box} .sq162-head{display:flex;justify-content:space-between;align-items:center;gap:10px;border-bottom:1px solid #ddd;padding-bottom:10px;margin-bottom:10px}
      .sq162-actions{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.sq162-btn{border:0;border-radius:9px;padding:10px 13px;background:#155fa8;color:#fff;font-weight:700;font-size:13px}.sq162-btn:disabled{opacity:.45}.sq162-secondary{background:#e9eef4;color:#22313f}.sq162-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.sq162-panel{border:1px solid #d9e0e7;border-radius:11px;padding:10px;min-width:0}.sq162-panel label{display:block;font-size:13px;font-weight:700;margin-bottom:6px}.sq162-panel input[type=file]{width:100%;font-size:12px}.sq162-canvas{display:block;width:100%;height:420px;background:#fbfcfe;border:1px solid #e0e5eb;border-radius:7px;margin-top:8px;touch-action:none;cursor:grab;user-select:none}.sq162-view-tools{display:flex;align-items:center;gap:5px;flex-wrap:wrap;margin-top:8px}.sq162-view-tools .sq162-btn{padding:9px 13px;min-width:46px;min-height:42px}.sq162-zoom-value{font:600 11px system-ui;color:#34495e;min-width:42px;text-align:center}.sq162-snap-mode{max-width:170px;min-width:120px;padding:6px;border:1px solid #ccd5de;border-radius:8px;background:#fff;color:#1c2b38;font-size:11px}.sq162-note{font-size:12px;line-height:1.6;color:#465566}.sq162-status{padding:9px;border-radius:8px;background:#eef5fb;white-space:pre-wrap;font-size:13px;line-height:1.6;margin:8px 0}.sq162-tabs{display:flex;gap:7px;margin:6px 0 12px}.sq162-tab{border-radius:8px;padding:8px 11px;background:#e8edf2;color:#243342;border:0;font-weight:700}.sq162-tab.active{background:#155fa8;color:#fff}.sq162-section{display:none}.sq162-section.active{display:block}.sq162-scale{width:110px;max-width:35%;padding:8px;border:1px solid #c7d0da;border-radius:7px;direction:ltr}
      @media(max-width:650px){#sq162-cad-dialog{padding:10px}.sq162-grid{grid-template-columns:1fr}.sq162-canvas{height:380px}.sq162-head h3{font-size:16px}}
    `;
    doc.head.appendChild(style);
    const launch = doc.createElement('button'); launch.id = 'sq162-cad-launch'; launch.type = 'button'; launch.textContent = 'أدوات CAD';
    const overlay = doc.createElement('div'); overlay.id = 'sq162-cad-overlay';
    overlay.innerHTML = `
      <div id="sq162-cad-dialog" role="dialog" aria-modal="true" aria-label="أدوات CAD">
        <div class="sq162-head"><div><h3 style="margin:0">أدوات CAD المساحية</h3><div class="sq162-note">عرض الملف المختار، والتوجيه على الشاشة فقط. لا يتم حفظ أو تعديل ملف DWG الأصلي.</div></div><button id="sq162-close" class="sq162-btn sq162-secondary" type="button">إغلاق ومسح الملفات</button></div>
        <div class="sq162-tabs"><button class="sq162-tab active" data-tab="align" type="button">فتح وعرض اللوحات</button><button class="sq162-tab" data-tab="raster" type="button">صورة / PDF إلى DXF</button></div>
        <section id="sq162-tab-align" class="sq162-section active">
          <div class="sq162-note">اختر ملف DWG أو DXF للمعاينة فقط. لا يتم تعديل ملف المصدر أو إنشاء ملف CAD جديد. ملاحظة: هذه معاينة للعناصر التي يستطيع محرك القراءة الحالي تفسيرها، وليست عارضًا كاملًا لكل كائنات DWG المتخصصة أو Proxy Objects. إذا لم يستطع المحرك قراءة عناصر الرسم، ستظهر رسالة بدل عرض نقاط منفصلة على أنها لوحة.</div>
          <div class="sq162-grid" style="margin-top:10px">
            <div class="sq162-panel"><label for="sq162-source-file">اللوحة غير الموجهة (DWG / DXF)</label><input id="sq162-source-file" type="file" accept=".dwg,.dxf,application/dxf,application/octet-stream"><div class="sq162-view-tools" data-sq-view="source"><button class="sq162-btn sq162-secondary" data-sq-zoom="in" type="button" aria-label="تكبير">＋ تكبير</button><button class="sq162-btn sq162-secondary" data-sq-zoom="out" type="button" aria-label="تصغير">− تصغير</button><button class="sq162-btn sq162-secondary" data-sq-zoom="fit" type="button">احتواء الرسم</button><span class="sq162-zoom-value">100%</span></div><canvas id="sq162-source-canvas" class="sq162-canvas" aria-label="معاينة اللوحة غير الموجهة"></canvas><div id="sq162-source-info" class="sq162-note">لم يتم اختيار ملف بعد.</div></div>
            <div class="sq162-panel"><label for="sq162-target-file">اللوحة الموجهة المرجعية (DWG / DXF)</label><input id="sq162-target-file" type="file" accept=".dwg,.dxf,application/dxf,application/octet-stream"><div class="sq162-view-tools" data-sq-view="target"><button class="sq162-btn sq162-secondary" data-sq-zoom="in" type="button" aria-label="تكبير">＋ تكبير</button><button class="sq162-btn sq162-secondary" data-sq-zoom="out" type="button" aria-label="تصغير">− تصغير</button><button class="sq162-btn sq162-secondary" data-sq-zoom="fit" type="button">احتواء الرسم</button><span class="sq162-zoom-value">100%</span></div><canvas id="sq162-target-canvas" class="sq162-canvas" aria-label="معاينة اللوحة المرجعية"></canvas><div id="sq162-target-info" class="sq162-note">لم يتم اختيار ملف بعد.</div></div>
          </div>
          <div class="sq162-actions"><button id="sq162-start-pick" class="sq162-btn" type="button" disabled>اختيار نقطتي التوجيه</button><button id="sq162-do-align" class="sq162-btn" type="button" disabled>توجيه اللوحة على المرجع</button><button id="sq162-reset-picks" class="sq162-btn sq162-secondary" type="button" disabled>إلغاء التوجيه</button></div>
          <div id="sq162-align-status" class="sq162-status" aria-live="polite">اختر اللوحتين، ثم ابدأ التوجيه باختيار نقطتين من كل لوحة. التوجيه يغيّر العرض على الشاشة فقط ولا يكتب في ملف DWG الأصلي.</div>
        </section>
        <section id="sq162-tab-raster" class="sq162-section">
          <div class="sq162-note">إخراج مطابق بصريًا للصفحة الأصلية. يتم وضع صفحة PDF أو الصورة نفسها كصورة Raster داخل DXF، لذلك تبقى الألوان والنصوص وسُمك الخطوط والتفاصيل كما ظهرت في المعاينة. لا توجد إعادة رسم أو تحويل إلى نقاط وخطوط قابلة للتحرير. يتم تسليم DXF والصورة المرجعية معًا داخل ZIP حتى تظل الصورة مرتبطة بالملف.</div>
          <div class="sq162-panel" style="margin-top:10px"><label for="sq162-raster-file">اختر صورة أو PDF</label><input id="sq162-raster-file" type="file" accept="image/png,image/jpeg,image/webp,.jpg,.jpeg,.png,.webp,.pdf,application/pdf"><label for="sq162-pdf-page" style="margin-top:9px">رقم صفحة PDF</label><input id="sq162-pdf-page" type="number" min="1" step="1" value="1" class="sq162-scale"><label for="sq162-raster-scale" style="margin-top:9px">عامل المقياس (وحدة رسم لكل بكسل)</label><input id="sq162-raster-scale" type="number" min="0.000001" step="any" value="1" class="sq162-scale"><div class="sq162-actions"><button id="sq162-trace" class="sq162-btn" type="button" disabled>إخراج DXF مطابق بصريًا (ZIP)</button></div><div id="sq162-raster-status" class="sq162-status" aria-live="polite">اختر ملفًا للبدء.</div><canvas id="sq162-raster-canvas" class="sq162-canvas" style="display:none" aria-label="معاينة الصورة قبل التحويل"></canvas></div>
        </section>
        <div class="sq162-note" style="margin-top:10px">لا يُستخدم localStorage أو قاعدة بيانات لحفظ اللوحات في هذه الأداة. عند الإغلاق تُفرّغ الذاكرة المؤقتة وعناصر اختيار الملفات.</div>
      </div>`;
    doc.body.appendChild(launch); doc.body.appendChild(overlay);
    const el = id => doc.getElementById(id);
    const state = { source: null, target: null, pickStage: -1, picks: [], tracerFile: null, rasterCanvas: null, views: {source:{zoom:1,panX:0,panY:0,centerX:null,centerY:null},target:{zoom:1,panX:0,panY:0,centerX:null,centerY:null}}, snapModes:{source:'intersection',target:'intersection'}, hover:{source:null,target:null} };
    function status(text, id = 'sq162-align-status') { el(id).textContent = text; }
    function fileTitle(file) { return file && file.name ? file.name : 'drawing'; }
    function clearCanvas(canvas) { const c = canvas.getContext('2d'); c.clearRect(0, 0, canvas.width, canvas.height); }
    function clearDrawing(which) {
      state[which] = null; state.hover[which]=null; state.views[which]={zoom:1,panX:0,panY:0,centerX:null,centerY:null};
      const prefix = which === 'source' ? 'source' : 'target';
      el(`sq162-${prefix}-file`).value = ''; el(`sq162-${prefix}-info`).textContent = 'لم يتم اختيار ملف بعد.';
      clearCanvas(el(`sq162-${prefix}-canvas`));
      state.picks = []; state.pickStage = -1; updatePickUi();
    }
    function cleanup() {
      clearDrawing('source'); clearDrawing('target');
      state.tracerFile = null; state.rasterCanvas = null;
      el('sq162-raster-file').value = ''; el('sq162-pdf-page').value = '1'; el('sq162-raster-scale').value = '1';
      el('sq162-raster-canvas').style.display = 'none'; clearCanvas(el('sq162-raster-canvas'));
      el('sq162-trace').disabled = true; status('تم مسح الملفات والنقاط من الذاكرة المؤقتة.');
      status('اختر ملفًا للبدء.', 'sq162-raster-status');
    }
    function updatePickUi() {
      const ready=!!(state.source&&state.target);
      const start=el('sq162-start-pick'),align=el('sq162-do-align'),reset=el('sq162-reset-picks');
      if(start)start.disabled=!ready;
      if(align)align.disabled=!(ready&&state.pickStage===4&&!state.source.viewGeom);
      if(reset)reset.disabled=!(state.picks.length||state.source?.viewGeom);
      for(const which of ['source','target']){
        const c=el(`sq162-${which}-canvas`);
        if(c)c.style.outline=(state.pickStage>=0&&((which==='source'&&state.pickStage<2)||(which==='target'&&state.pickStage>=2&&state.pickStage<4)))?'3px solid #15945c':'none';
      }
    }
    function drawGeometry(which, canvas, geom, picks, firstPickIndex) {
      if (!geom) return;
      const dpr = Math.min(root.devicePixelRatio || 1, 2), w = Math.max(240, canvas.clientWidth || 280), h = Math.max(160, canvas.clientHeight || 300);
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      const ctx = canvas.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.fillStyle = '#fbfcfe'; ctx.fillRect(0, 0, w, h);
      const pad = 16, spanX=Math.max(1e-9,geom.maxX-geom.minX), spanY=Math.max(1e-9,geom.maxY-geom.minY), sx = (w - 2 * pad) / spanX, sy = (h - 2 * pad) / spanY, baseScale = Math.max(1e-12, Math.min(sx, sy));
      const view = state.views[which];
      if (!Number.isFinite(view.centerX) || !Number.isFinite(view.centerY)) { view.centerX=(geom.minX+geom.maxX)/2; view.centerY=(geom.minY+geom.maxY)/2; }
      view.zoom = Math.max(0.2, Math.min(10000, Number(view.zoom)||1));
      const sc = baseScale * view.zoom;
      const pt = p => ({ x: w/2 + (p.x-view.centerX)*sc + view.panX, y: h/2 - (p.y-view.centerY)*sc + view.panY });
      const toWorld = p => ({x:view.centerX+(p.x-w/2-view.panX)/sc,y:view.centerY-(p.y-h/2-view.panY)/sc});
      const baseLineWidth=Math.max(.6,Math.min(2,1/Math.sqrt(view.zoom)));
      const strokeGroups=new Map();
      const strokeKey=(o)=>{const color=o?.color||'#1976b8',lw=Number(o?.lineWeight)||0,width=lw>0?Math.max(.6,Math.min(5,lw/100*96/25.4)):baseLineWidth;return{key:`${color}|${width.toFixed(2)}`,color,width};};
      const groupFor=(o)=>{const st=strokeKey(o);let g=strokeGroups.get(st.key);if(!g){g={...st,draw:[]};strokeGroups.set(st.key,g);}return g;};
      for(const seg of (geom.segments||[])){if(seg.isCurveSegment)continue;const g=groupFor(seg),a=pt(seg.a),b=pt(seg.b);g.draw.push([a,b]);}
      for(const curve of (geom.curves||[])){const g=groupFor(curve);if(Array.isArray(curve.points)&&curve.points.length>1){g.draw.push(curve.points.map(pt));}else if(curve.center&&curve.radius>0){const c=pt(curve.center),r=curve.radius*sc;if(r>0&&r<1e7)g.draw.push({center:c,radius:r,start:curve.start||0,sweep:curve.sweep||Math.PI*2});}}
      for(const g of strokeGroups.values()){ctx.beginPath();ctx.strokeStyle=g.color;ctx.lineWidth=g.width;for(const path of g.draw){if(Array.isArray(path)){if(path.length<2)continue;ctx.moveTo(path[0].x,path[0].y);for(let i=1;i<path.length;i++)ctx.lineTo(path[i].x,path[i].y);}else if(path.center){ctx.moveTo(path.center.x+path.radius*Math.cos(path.start),path.center.y-path.radius*Math.sin(path.start));ctx.arc(path.center.x,path.center.y,path.radius,-path.start,-(path.start+path.sweep),true);}}ctx.stroke();}
      { ctx.strokeStyle = '#1976b8'; ctx.lineWidth = 1; for (const q of geom.points.slice(0, 8000)) { const p = pt(q); ctx.strokeStyle=q.color||'#1976b8';ctx.beginPath(); ctx.moveTo(p.x - 3, p.y); ctx.lineTo(p.x + 3, p.y); ctx.moveTo(p.x, p.y - 3); ctx.lineTo(p.x, p.y + 3); ctx.stroke(); } }
      // Axis names are often TEXT/MTEXT/ATTRIB entities inside blocks. Draw them
      // explicitly; no text or CAD record is recreated in the output file.
      for (const label of (geom.texts || []).slice(0, 6000)) {
        const q=pt(label.position);if(q.x < -100 || q.x > w+100 || q.y < -60 || q.y > h+60)continue;
        const rawH=Math.abs(Number(label.height)||0),scaledH=rawH>0?rawH*sc:5,fontSize=Math.max(.65,Math.min(Math.max(1,h*1.15),scaledH)),widthFactor=Math.max(.1,Math.min(10,Number(label.widthFactor)||1));
        if(rawH>0&&fontSize<.8)continue;
        ctx.save();ctx.translate(q.x,q.y);ctx.rotate(-(Number(label.rotation)||0)*Math.PI/180);ctx.scale(widthFactor,1);
        ctx.fillStyle=label.color||'#182536';ctx.font=`${fontSize}px sans-serif`;ctx.textBaseline='bottom';
        const txt=String(label.text||'').slice(0,180);if(txt)ctx.fillText(txt,0,-Math.max(.5,fontSize*.08));ctx.restore();
      }
      ctx.fillStyle = '#d63333';
      for (let i = 0; i < picks.length; i++) { const p = pt(picks[i]); ctx.beginPath(); ctx.arc(p.x,p.y,5,0,Math.PI*2); ctx.fill(); ctx.fillStyle='#fff';ctx.font='bold 11px sans-serif';ctx.fillText(String(i+firstPickIndex+1),p.x+7,p.y-7);ctx.fillStyle='#d63333'; }
      const hover=state.hover[which];
      if(hover?.point){const q=pt(hover.point);ctx.save();ctx.strokeStyle='#079455';ctx.fillStyle='#079455';ctx.lineWidth=2;ctx.beginPath();ctx.arc(q.x,q.y,8,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(q.x-13,q.y);ctx.lineTo(q.x+13,q.y);ctx.moveTo(q.x,q.y-13);ctx.lineTo(q.x,q.y+13);ctx.stroke();ctx.font='bold 11px system-ui';ctx.fillText(hover.typeLabel||'Snap',q.x+12,q.y-10);ctx.restore();}
      canvas._sqMap = { geom, width:w, height:h, pad, sc, baseScale, pt, toWorld, view };
      const toolbar=overlay.querySelector(`[data-sq-view="${which}"]`); if(toolbar){const z=toolbar.querySelector('.sq162-zoom-value');if(z)z.textContent=`${Math.round(view.zoom*100)}%`;const sel=toolbar.querySelector('.sq162-snap-mode');if(sel&&sel.value!==state.snapModes[which])sel.value=state.snapModes[which];}
    }
    let sqRedrawPending=false;
    function requestRedraw(){if(sqRedrawPending)return;sqRedrawPending=true;const raf=root.requestAnimationFrame||((fn)=>root.setTimeout(fn,16));raf(()=>{sqRedrawPending=false;redrawAll();});}
    function redrawAll() {
      if (state.source) drawGeometry('source',el('sq162-source-canvas'), state.source.viewGeom||state.source.geom, state.picks.slice(0, 2), 0);
      if (state.target) drawGeometry('target',el('sq162-target-canvas'), state.target.geom, state.picks.slice(2, 4), 2);
    }
    function fitView(which){const g=which==='source'?(state.source?.viewGeom||state.source?.geom):state.target?.geom;if(!g)return;state.views[which]={zoom:1,panX:0,panY:0,centerX:(g.minX+g.maxX)/2,centerY:(g.minY+g.maxY)/2};redrawAll();}
    function zoomView(which,factor,anchor){const c=el(`sq162-${which}-canvas`),map=c&&c._sqMap;if(!map)return;const view=state.views[which],a=anchor||{x:map.width/2,y:map.height/2},world=map.toWorld(a);view.zoom=Math.max(.2,Math.min(10000,view.zoom*factor));const sc=map.baseScale*view.zoom;view.panX=a.x-map.width/2-(world.x-view.centerX)*sc;view.panY=a.y-map.height/2+(world.y-view.centerY)*sc;redrawAll();}
    for(const toolbar of overlay.querySelectorAll('[data-sq-view]')){
      const which=toolbar.dataset.sqView;
      toolbar.addEventListener('click',e=>{const b=e.target.closest('[data-sq-zoom]');if(!b)return;const action=b.dataset.sqZoom;if(action==='fit')fitView(which);else zoomView(which,action==='in'?2:1/2);});
      const select=toolbar.querySelector('.sq162-snap-mode');
      if(select) select.addEventListener('change',()=>{state.snapModes[which]=select.value;status(`نمط الالتقاط: ${select.options[select.selectedIndex].text}`);});
    }
    async function loadCadFile(which, file) {
      if (!file) return;
      state.picks = []; state.pickStage = -1; updatePickUi();
      if (!/\.(dwg|dxf)$/i.test(file.name)) throw new Error('اختر ملف DWG أو DXF فقط.');
      if (typeof root.parseFile !== 'function') throw new Error('قارئ الملفات المشترك غير متاح في هذه الشاشة.');
      status('جارٍ فتح الملف للعرض فقط. لن يتم تعديل المصدر أو إنشاء لوحة بديلة...');
      const model = await root.parseFile(file, { rawOnly: true, conversionOnly: true, retainRawDWG: false });
      const raw = model && model.rawDXFBytes;
      if (!raw || !raw.length) throw new Error('لم يُنتج القارئ بيانات DXF. لا يمكن متابعة التوجيه دون ملف صالح.');
      const bytes = raw instanceof Uint8Array ? raw : new Uint8Array(raw);
      const geom = readGeometry(bytes);
      const drawableCount=(geom.segments?.length||0)+(geom.curves?.length||0)+(geom.texts?.length||0);
      if(!drawableCount) throw new Error('لم يعثر القارئ إلا على نقاط منفصلة أو عناصر غير مدعومة. أوقفت المعاينة بدل عرض سحابة نقاط على أنها اللوحة الأصلية. يلزم عارض DWG كامل لقراءة هذا الملف كما هو.');
      state[which] = { file, bytes, geom, viewGeom:null, transform:null };
      state.views[which]={zoom:1,panX:0,panY:0,centerX:(geom.minX+geom.maxX)/2,centerY:(geom.minY+geom.maxY)/2};
      el(`sq162-${which}-info`).textContent = `${file.name}\nمعاينة المصدر: ${geom.segments.length.toLocaleString()} مقطع، ${(geom.curves||[]).length.toLocaleString()} منحنى، ${((geom.texts||[]).length).toLocaleString()} نص/اسم. لم يتم تعديل الملف أو حفظ نسخة جديدة.`;
      redrawAll(); updatePickUi();
      status(`تم فتح ${file.name} للعرض فقط. بيانات المصدر الأصلية لم تُعدّل ولم تُحفظ منها لوحة جديدة.`);
    }
    el('sq162-source-file').addEventListener('change', async e => { try { await loadCadFile('source', e.target.files[0]); } catch (err) { clearDrawing('source'); status(String(err.message || err)); } });
    el('sq162-target-file').addEventListener('change', async e => { try { await loadCadFile('target', e.target.files[0]); } catch (err) { clearDrawing('target'); status(String(err.message || err)); } });
    // V167: four CAD snaps define a similarity transform of the source preview only.
    el('sq162-start-pick').addEventListener('click',()=>{
      if(!state.source||!state.target)return;
      state.source.viewGeom=null;state.source.transform=null;state.picks=[];state.pickStage=0;
      state.hover={source:null,target:null};state.views.source={zoom:1,panX:0,panY:0,centerX:(state.source.geom.minX+state.source.geom.maxX)/2,centerY:(state.source.geom.minY+state.source.geom.maxY)/2};
      updatePickUi();redrawAll();status('اختر النقطة الأولى على اللوحة غير الموجهة، ثم الثانية. بعد ذلك اختر النقطتين المناظرتين على اللوحة المرجعية.');
    });
    el('sq162-do-align').addEventListener('click',()=>{
      try{
        if(!state.source||!state.target||state.pickStage!==4||state.picks.length!==4)throw new Error('يلزم اختيار نقطتين من اللوحة الأصلية ونقطتين من اللوحة المرجعية.');
        const tr=solve(state.picks[0],state.picks[1],state.picks[2],state.picks[3]);
        const viewGeom=transformGeometryView(state.source.geom,tr);
        state.source.transform=tr;state.source.viewGeom=viewGeom;state.picks=[];state.pickStage=-1;state.hover={source:null,target:null};
        state.views.source={zoom:1,panX:0,panY:0,centerX:(viewGeom.minX+viewGeom.maxX)/2,centerY:(viewGeom.minY+viewGeom.maxY)/2};
        updatePickUi();redrawAll();
        status(`تم توجيه عرض اللوحة على المرجع. الدوران: ${fmt(tr.rotationDegrees)}° | المقياس: ${fmt(tr.scale)} | خطأ النقطتين: ${fmt(Math.max(tr.residualA,tr.residualB))} وحدة.\nملف DWG الأصلي وبياناته لم تتغير، ولم يتم إنشاء ملف CAD بديل. هذا تحويل عرض فقط للعناصر التي استطاع قارئ DWG تفسيرها.`);
      }catch(err){status(String(err?.message||err));}
    });
    el('sq162-reset-picks').addEventListener('click',()=>{
      if(state.source){state.source.viewGeom=null;state.source.transform=null;state.views.source={zoom:1,panX:0,panY:0,centerX:(state.source.geom.minX+state.source.geom.maxX)/2,centerY:(state.source.geom.minY+state.source.geom.maxY)/2};}
      state.picks=[];state.pickStage=-1;state.hover={source:null,target:null};updatePickUi();redrawAll();status('تم إلغاء التوجيه وإرجاع عرض اللوحة إلى إحداثيات الملف الأصلي. الملف نفسه لم يتغير.');
    });
    function updateSnapPreview(which,clientX,clientY){
      if(state.pickStage<0||state.pickStage>=4)return;
      const expected=state.pickStage<2?'source':'target';if(which!==expected)return;
      const canvas=el(`sq162-${which}-canvas`),map=canvas._sqMap;if(!map||!state[which])return;
      const rect=canvas.getBoundingClientRect(),pixel={x:clientX-rect.left,y:clientY-rect.top},world=map.toWorld(pixel);
      state.hover[which]=snapPoint(state[which].geom,world,state.snapModes[which]||'intersection',20/map.sc);
      requestRedraw();
    }
    function handleCanvasPick(which,clientX,clientY) {
      if (state.pickStage < 0 || state.pickStage >= 4) return;
      const expected = state.pickStage < 2 ? 'source' : 'target';
      if (which !== expected) { status(expected === 'source' ? 'اختر النقطة على اللوحة غير الموجهة أولًا.' : 'اختر النقطة المقابلة على اللوحة المرجعية أولًا.'); return; }
      const canvas=el(`sq162-${which}-canvas`),map=canvas._sqMap;if(!map)return;
      const rect=canvas.getBoundingClientRect(),pixel={x:clientX-rect.left,y:clientY-rect.top},world=map.toWorld(pixel);
      try {
        const snap=snapPoint(state[which].geom,world,state.snapModes[which]||'intersection',20/map.sc);
        if(!snap)throw new Error('لم يتم العثور على عنصر داخل مدى الالتقاط. كبّر اللوحة أو اختر نمط التقاط آخر.');
        state.picks.push({...snap.point,snapType:snap.type});state.hover[which]=null;state.pickStage++;updatePickUi();redrawAll();
        status(`تم التقاط ${snap.typeLabel} عند X=${fmt(snap.point.x)}، Y=${fmt(snap.point.y)}.`);
      } catch (err) { status(String(err.message || err)); }
    }
    function bindViewport(which){
      const canvas=el(`sq162-${which}-canvas`),pointers=new Map();let gesture=null;
      const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),mid=(a,b)=>({x:(a.x+b.x)/2,y:(a.y+b.y)/2});
      canvas.addEventListener('wheel',e=>{e.preventDefault();const r=canvas.getBoundingClientRect();zoomView(which,e.deltaY<0?1.22:1/1.22,{x:e.clientX-r.left,y:e.clientY-r.top});},{passive:false});
      canvas.addEventListener('pointerdown',e=>{
        canvas.setPointerCapture?.(e.pointerId);const r=canvas.getBoundingClientRect(),p={x:e.clientX-r.left,y:e.clientY-r.top};pointers.set(e.pointerId,p);updateSnapPreview(which,e.clientX,e.clientY);
        if(pointers.size===1){const v=state.views[which];gesture={type:'drag',start:p,last:p,panX:v.panX,panY:v.panY,moved:false};}
        else if(pointers.size===2){const q=[...pointers.values()],map=canvas._sqMap,center=mid(q[0],q[1]);gesture={type:'pinch',distance:Math.max(1,dist(q[0],q[1])),zoom:state.views[which].zoom,world:map?map.toWorld(center):null,center,viewCenter:{x:map?.view.centerX||0,y:map?.view.centerY||0}};}
      });
      canvas.addEventListener('pointermove',e=>{
        if(!pointers.has(e.pointerId))return;const r=canvas.getBoundingClientRect(),p={x:e.clientX-r.left,y:e.clientY-r.top};pointers.set(e.pointerId,p);
        if(pointers.size>=2&&gesture?.type==='pinch'){
          const q=[...pointers.values()],d=Math.max(1,dist(q[0],q[1])),center=mid(q[0],q[1]),view=state.views[which],map=canvas._sqMap;
          view.zoom=Math.max(.2,Math.min(10000,gesture.zoom*d/gesture.distance));if(map&&gesture.world){const sc=map.baseScale*view.zoom;view.panX=center.x-map.width/2-(gesture.world.x-view.centerX)*sc;view.panY=center.y-map.height/2+(gesture.world.y-view.centerY)*sc;}
          requestRedraw();
        }else if(pointers.size===1&&gesture?.type==='drag'){
          const dx=p.x-gesture.start.x,dy=p.y-gesture.start.y,travel=Math.hypot(dx,dy);
          if(travel>8){gesture.moved=true;const v=state.views[which];v.panX=gesture.panX+dx;v.panY=gesture.panY+dy;requestRedraw();}
          else if(!gesture.lastSnapPreviewAt||Date.now()-gesture.lastSnapPreviewAt>120){gesture.lastSnapPreviewAt=Date.now();updateSnapPreview(which,e.clientX,e.clientY);}
        }
      });
      const release=e=>{const was=gesture;pointers.delete(e.pointerId);if(pointers.size===0){if(was?.type==='drag'&&!was.moved)handleCanvasPick(which,e.clientX,e.clientY);gesture=null;}else if(pointers.size===1){const q=[...pointers.values()][0],v=state.views[which];gesture={type:'drag',start:q,last:q,panX:v.panX,panY:v.panY,moved:true};}};
      canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);if(!pointers.size)gesture=null;else if(pointers.size===1){const q=[...pointers.values()][0],v=state.views[which];gesture={type:'drag',start:q,last:q,panX:v.panX,panY:v.panY,moved:true};}});
    }
    bindViewport('source');bindViewport('target');
    // V167 view-only alignment: original file bytes are retained; only the source preview geometry is transformed.
    launch.addEventListener('click', () => { overlay.style.display = 'flex'; });
    el('sq162-close').addEventListener('click', () => { cleanup(); overlay.style.display = 'none'; });
    overlay.addEventListener('click', e => { if (e.target === overlay) { cleanup(); overlay.style.display = 'none'; } });
    doc.addEventListener('keydown', e => { if (e.key === 'Escape' && overlay.style.display === 'flex') { cleanup(); overlay.style.display = 'none'; } });
    for (const tab of overlay.querySelectorAll('[data-tab]')) tab.addEventListener('click', () => {
      for (const t of overlay.querySelectorAll('[data-tab]')) t.classList.toggle('active', t === tab);
      for (const s of overlay.querySelectorAll('.sq162-section')) s.classList.toggle('active', s.id === `sq162-tab-${tab.dataset.tab}`);
    });
    // Include DWG in any existing CAD picker that already accepts DXF, including pickers
    // created later by project screens, without changing unrelated image/document pickers.
    function broadenCadPickers(scope) {
      for (const input of scope.querySelectorAll ? scope.querySelectorAll('input[type="file"]') : []) {
        const accept = input.getAttribute('accept') || '';
        if (/\.dxf/i.test(accept) && !/\.dwg/i.test(accept)) input.setAttribute('accept', `${accept},.dwg`);
      }
    }
    broadenCadPickers(doc);
    if (root.MutationObserver) new root.MutationObserver(records => { for (const r of records) for (const n of r.addedNodes) if (n.nodeType === 1) broadenCadPickers(n); }).observe(doc.documentElement, { childList: true, subtree: true });

    // PDF/image pages are kept as a raster underlay; ImageTracer is intentionally not used.
    const rasterFileInput = el('sq162-raster-file'), traceBtn = el('sq162-trace'), rasterCanvas = el('sq162-raster-canvas');
    rasterFileInput.addEventListener('change', () => { state.tracerFile = rasterFileInput.files[0] || null; traceBtn.disabled = !state.tracerFile; status(state.tracerFile ? `تم اختيار ${state.tracerFile.name}.` : 'اختر ملفًا للبدء.', 'sq162-raster-status'); });
    traceBtn.addEventListener('click', async () => {
      const file = state.tracerFile; let pdf = null;
      try {
        if (!file) throw new Error('اختر صورة أو PDF أولًا.');
        traceBtn.disabled = true; status('جارٍ فتح الصفحة الأصلية وتجهيز إخراج مطابق للألوان والتفاصيل...', 'sq162-raster-status');
        const maxDim=3200,maxPixels=6000000;let canvas=doc.createElement('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:false});
        if (/\.pdf$/i.test(file.name) || file.type === 'application/pdf') {
          const lib=root.pdfjsLib,workerUrl=root.__sq163PdfWorkerUrl;
          if(!lib||typeof lib.getDocument!=='function')throw new Error('قارئ PDF غير محمّل. أغلق الشاشة وافتح التطبيق من جديد لتشغيل محرك PDF.');
          ensurePdfWorker(lib,doc);
          const task=lib.getDocument({data:new Uint8Array(await file.arrayBuffer()),useSystemFonts:true,isEvalSupported:false});
          pdf=await task.promise;
          const pageNumber=Math.max(1,Math.min(pdf.numPages,Number.parseInt(el('sq162-pdf-page').value||'1',10)||1));
          const page=await pdf.getPage(pageNumber),base=page.getViewport({scale:1});
          const scale=Math.min(4,maxDim/base.width,maxDim/base.height,Math.sqrt(maxPixels/(base.width*base.height)));
          const viewport=page.getViewport({scale});canvas.width=Math.max(1,Math.floor(viewport.width));canvas.height=Math.max(1,Math.floor(viewport.height));
          ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);
          await page.render({canvasContext:ctx,viewport,background:'#ffffff'}).promise;
        } else {
          const url=URL.createObjectURL(file);
          try{const image=new Image();image.src=url;await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(new Error('تعذر فتح الصورة.'));});const scale=Math.min(1,maxDim/image.naturalWidth,maxDim/image.naturalHeight,Math.sqrt(maxPixels/(image.naturalWidth*image.naturalHeight)));canvas.width=Math.max(1,Math.floor(image.naturalWidth*scale));canvas.height=Math.max(1,Math.floor(image.naturalHeight*scale));ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);}finally{URL.revokeObjectURL(url);}
        }
        if(!canvas.width||!canvas.height||canvas.width*canvas.height>maxPixels)throw new Error('دقة الصفحة تجاوزت الحد الآمن للمعالجة.');
        rasterCanvas.width=canvas.width;rasterCanvas.height=canvas.height;rasterCanvas.style.display='block';
        const previewContext=rasterCanvas.getContext('2d');previewContext.clearRect(0,0,rasterCanvas.width,rasterCanvas.height);previewContext.drawImage(canvas,0,0);
        const factor=Number(el('sq162-raster-scale').value);if(!finite(factor)||factor<=0)throw new Error('عامل المقياس يجب أن يكون رقمًا موجبًا.');
        const pngBytes=await canvasPngBytes(canvas),baseName=file.name.replace(/\.[^.]+$/,'').replace(/[^\w.() -]/g,'_')||'SurveyQuant_PDF';
        const imageName=`${baseName}_ORIGINAL_PAGE.png`,dxfName=`${baseName}_EXACT_RASTER.dxf`;
        const dxfBytes=makeRasterUnderlayDxf(imageName,canvas.width,canvas.height,factor);
        const bundle=zipStore([{name:dxfName,data:dxfBytes},{name:imageName,data:pngBytes}]);
        await downloadBytes(bundle,`${baseName}_EXACT_PDF_TO_DXF.zip`,'application/zip');
        status(`تم تجهيز حزمة DXF ذات صورة مطابقة بصريًا.\nالصفحة: ${canvas.width} × ${canvas.height} بكسل\nالملفات داخل ZIP: ${dxfName} + ${imageName}\nالصفحة داخل DXF صورة Raster من المعاينة نفسها وليست كيانات CAD قابلة للتحرير. فك ضغط الملفين في مجلد واحد قبل فتح DXF في AutoCAD أو أي عارض يدعم Raster Image Underlay. عامل المقياس: ${fmt(factor)} وحدة/بكسل.`, 'sq162-raster-status');
        canvas.width=1;canvas.height=1;
      } catch(err) { status(String(err?.message||err), 'sq162-raster-status'); }
      finally { try{if(pdf)await pdf.destroy();}catch(_){} traceBtn.disabled = !state.tracerFile; }
    });

    root.addEventListener('pagehide', cleanup, { once: true });
  }
  return { solve, transformGeometryView, transformDxfBytes, readGeometry, nearestPoint, snapPoint, mergeRawDxfBoards, svgPathToPolylines, svgPathsToCad, polylinesToDxf, makeRasterUnderlayDxf, zipStore, downloadBytes, mount };
});
