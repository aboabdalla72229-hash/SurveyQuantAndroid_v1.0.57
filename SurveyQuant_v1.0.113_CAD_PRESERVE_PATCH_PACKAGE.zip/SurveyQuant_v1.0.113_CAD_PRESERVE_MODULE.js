/* SurveyQuant v1.0.113: normalize only provable blank-line DXF pair shifts,
   complete preview for entity types omitted by the simplified renderer, and
   reject exports that would require dropping malformed nonblank source data. */
(function () {
  'use strict';
  const MANUAL = window.__sqManualOrientation109;
  const CORE = window.__sqOrientation111API;
  const RECOVERY = window.__sqOrientation112API;
  const ENGINE = window.__sqOrientTest;
  if (!MANUAL || !CORE || !RECOVERY || !ENGINE ||
      typeof MANUAL.parseDrawing !== 'function' ||
      typeof CORE.splitPairs !== 'function' ||
      typeof CORE.sectionRecords !== 'function' ||
      typeof CORE.blockDefinitions !== 'function' ||
      typeof CORE.geometryInWorld !== 'function' ||
      typeof ENGINE.transformBytes !== 'function') {
    throw new Error('SurveyQuant v113 CAD-preserve layer could not connect to existing readers.');
  }

  const stats = { blankLinesNormalized: 0, previewEntitiesAdded: 0, lastNormalization: null, lastExportValidation: null };
  const asBytes = input => input instanceof Uint8Array ? input : input instanceof ArrayBuffer ? new Uint8Array(input) : ArrayBuffer.isView(input) ? new Uint8Array(input.buffer, input.byteOffset, input.byteLength) : new Uint8Array(input);
  const originalSplitPairs = CORE.splitPairs.bind(CORE);
  const originalManualParse = MANUAL.parseDrawing.bind(MANUAL);
  const originalTransform = ENGINE.transformBytes.bind(ENGINE);

  function lineRecords(bytes) {
    const out = [];
    let i = 0;
    while (i < bytes.length) {
      const start = i;
      while (i < bytes.length && bytes[i] !== 10 && bytes[i] !== 13) i++;
      const contentEnd = i;
      if (i < bytes.length && bytes[i] === 13) i++;
      if (i < bytes.length && bytes[i] === 10) i++;
      out.push({ start, contentEnd, next: i });
    }
    return out;
  }
  function lineText(bytes, line) {
    let s = '';
    for (let i = line.start; i < line.contentEnd; i++) s += String.fromCharCode(bytes[i]);
    return s.replace(/^\uFEFF/, '').trim();
  }
  function isBlank(bytes, line) {
    for (let i = line.start; i < line.contentEnd; i++) if (![9, 10, 11, 12, 13, 32].includes(bytes[i])) return false;
    return true;
  }
  function groupCode(bytes, line) {
    const s = lineText(bytes, line);
    if (!/^[+-]?\d+$/.test(s)) return null;
    const n = Number(s);
    return Number.isSafeInteger(n) && n >= -5 && n <= 32767 ? n : null;
  }
  function removeLine(bytes, line) {
    const end = line.next;
    const out = new Uint8Array(bytes.length - (end - line.start));
    out.set(bytes.subarray(0, line.start), 0);
    out.set(bytes.subarray(end), line.start);
    return out;
  }

  // Only remove empty physical lines when their position proves they have
  // shifted code/value pairing. All non-empty source bytes remain byte-identical.
  function normalizeBlankPairLines(input) {
    let bytes = asBytes(input);
    let changed = 0;
    let attempts = 0;
    while (attempts++ < 10000) {
      const lines = lineRecords(bytes);
      let restart = false;
      for (let i = 0; i < lines.length - 1; i += 2) {
        const code = groupCode(bytes, lines[i]);
        if (code === null) {
          if (isBlank(bytes, lines[i]) && groupCode(bytes, lines[i + 1]) !== null) {
            bytes = removeLine(bytes, lines[i]);
            changed++;
            restart = true;
            break;
          }
          return { bytes, changed, valid: false, invalidLine: i + 1 };
        }
        // An inserted empty line between a group-code and its non-empty value
        // leaves the former value at the next expected code position.
        if (isBlank(bytes, lines[i + 1]) && i + 2 < lines.length && groupCode(bytes, lines[i + 2]) === null) {
          bytes = removeLine(bytes, lines[i + 1]);
          changed++;
          restart = true;
          break;
        }
      }
      if (!restart) {
        // The last physical line must not be a non-empty orphan. A trailing
        // newline itself is not represented as a physical record above.
        const finalLines = lineRecords(bytes);
        if (finalLines.length % 2 !== 0 && finalLines.length && !isBlank(bytes, finalLines[finalLines.length - 1])) {
          return { bytes, changed, valid: false, invalidLine: finalLines.length };
        }
        return { bytes, changed, valid: true, invalidLine: null };
      }
    }
    return { bytes, changed, valid: false, invalidLine: null };
  }

  function splitPairsWithNormalization(input) {
    const normalized = normalizeBlankPairLines(input);
    if (!normalized.valid) {
      // Let the existing reader report the actual parser error; never fabricate
      // a successful parse by silently dropping nonblank data rows.
      return originalSplitPairs(asBytes(input));
    }
    const parsed = originalSplitPairs(normalized.bytes);
    if (normalized.changed) {
      parsed.bytes = normalized.bytes;
      parsed.normalizedBlankLines = normalized.changed;
      stats.blankLinesNormalized += normalized.changed;
      stats.lastNormalization = { blankLinesRemoved: normalized.changed, originalBytes: asBytes(input).length, normalizedBytes: normalized.bytes.length };
    }
    return parsed;
  }
  CORE.splitPairs = splitPairsWithNormalization;

  MANUAL.parseDrawing = function parseDrawingWithStrictPairs(input) {
    const normalized = normalizeBlankPairLines(input);
    if (!normalized.valid) {
      throw new Error('تعذر قراءة DXF بأمان عند السطر ' + normalized.invalidLine + '. يوجد خلل غير ناتج عن سطر فارغ زائد؛ أُوقفت المعاينة حتى لا تظهر لوحة ناقصة أو تُفقد بياناتها.');
    }
    const model = originalManualParse(normalized.bytes);
    if (normalized.changed) {
      model.__sqDxfNormalization113 = { blankLinesRemoved: normalized.changed };
      model.previewWarning = 'تمت معالجة ' + normalized.changed + ' سطر فارغ زائد في نسخة القراءة فقط؛ بيانات الملف الأصلي لم تتغير.';
      stats.blankLinesNormalized += normalized.changed;
      stats.lastNormalization = { blankLinesRemoved: normalized.changed, originalBytes: asBytes(input).length, normalizedBytes: normalized.bytes.length };
    }
    addUnrenderedEntities(model, normalized.bytes);
    return model;
  };

  // Existing renderer covers standard survey entities but skips unknown and
  // some CAD types. Supplement only those types to prevent a partial drawing
  // from being mistaken for a complete preview. Preview additions never modify
  // DXF bytes or the exported source.
  const mainRendererTypes = new Set([
    'LINE','POINT','LWPOLYLINE','POLYLINE','CIRCLE','ARC','3DFACE','SOLID','TRACE',
    'SPLINE','LEADER','TEXT','MTEXT','ATTRIB','ATTDEF','ELLIPSE','INSERT',
    'VERTEX','SEQEND','BLOCK','ENDBLK'
  ]);
  const previewHandledByParsePreview = new Set([
    'DIMENSION','ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH',
    'SURFACE','HATCH','MLEADER','MLINE','TABLE','IMAGE','WIPEOUT','HELIX','OLE2FRAME',
    'PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY'
  ]);

  function matrixForInsert(rec, block) {
    const p = rec.pairs;
    const get = (code, fallback = 0) => {
      const pair = p.find(x => x.code === code);
      const n = pair ? Number(pair.value) : fallback;
      return Number.isFinite(n) ? n : fallback;
    };
    const ins = { x: get(10), y: get(20) };
    const sx = get(41, 1) || 1, sy = get(42, 1) || 1;
    const a = get(50) * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
    const bx = block.base?.x || 0, by = block.base?.y || 0;
    return p => ({
      x: ins.x + (p.x - bx) * sx * c - (p.y - by) * sy * s,
      y: ins.y + (p.x - bx) * sx * s + (p.y - by) * sy * c
    });
  }
  function addGeo(model, geo) {
    if (!geo) return 0;
    const n = (geo.pts?.length || 0) + (geo.segments?.length || 0) + (geo.texts?.length || 0);
    if (geo.pts?.length) model.anchors.push(...geo.pts);
    if (geo.segments?.length) model.segs.push(...geo.segments);
    if (geo.texts?.length) model.texts.push(...geo.texts);
    return n;
  }
  function supplementInsideBlock(model, rec, blocks, parent, depth, stack) {
    if (depth > 8) return 0;
    const name = String(rec.pairs.find(x => x.code === 2)?.value || '').trim().toUpperCase();
    const block = blocks.get(name);
    if (!block || stack.includes(name)) return 0;
    const local = matrixForInsert(rec, block);
    const composed = p => parent(local(p));
    let added = 0;
    for (const child of block.entities || []) {
      if (child.type === 'INSERT') {
        added += supplementInsideBlock(model, child, blocks, composed, depth + 1, stack.concat(name));
      } else if (!mainRendererTypes.has(child.type)) {
        // Inside a block, the primary renderer has already drawn supported
        // child entities, while unsupported ones have not been expanded.
        added += addGeo(model, CORE.geometryInWorld(child, blocks, composed, depth));
      }
    }
    return added;
  }
  function addUnrenderedEntities(model, bytes) {
    const parsed = splitPairsWithNormalization(bytes);
    if (parsed.recoveryCount && !parsed.normalizedBlankLines) {
      // A nonblank recovery gap is not safe to claim complete. Do not supplement
      // a potentially misaligned entity stream.
      return;
    }
    const records = CORE.sectionRecords(parsed.pairs, 'ENTITIES');
    const blocks = CORE.blockDefinitions(parsed.pairs);
    let added = 0;
    for (const rec of records) {
      if (rec.type === 'INSERT') {
        added += supplementInsideBlock(model, rec, blocks, p => p, 0, []);
        continue;
      }
      if (mainRendererTypes.has(rec.type) || previewHandledByParsePreview.has(rec.type)) continue;
      added += addGeo(model, CORE.geometryInWorld(rec, blocks));
    }
    if (added) {
      model.__sqOrientation113 = { supplementalGeometryItems: added };
      model.supplementalGeometryItems = (model.supplementalGeometryItems || 0) + added;
      stats.previewEntitiesAdded += added;
      if (!model.previewWarning) model.previewWarning = 'المعاينة عرضت أيضًا عناصر CAD إضافية لم يكن العارض القديم يرسمها. ملف الإخراج يحتفظ بسجلات DXF الأصلية ولا يعيد رسمها.';
    }
  }

  function multiset(values) {
    const m = new Map();
    for (const v of values) m.set(v, (m.get(v) || 0) + 1);
    return JSON.stringify(Array.from(m.entries()).sort((a, b) => String(a[0]).localeCompare(String(b[0]))));
  }
  function structureFingerprint(input) {
    const parsed = splitPairsWithNormalization(input);
    if ((parsed.recoveryCount || 0) > 0 && !parsed.normalizedBlankLines) {
      throw new Error('يوجد خلل بنيوي غير قابل للإصلاح بحذف أسطر فارغة فقط. لم يتم اعتماد التحويل حتى لا تُفقد عناصر.');
    }
    const records = CORE.sectionRecords(parsed.pairs, 'ENTITIES');
    const types = records.map(r => r.type);
    const layers = [];
    const text = [];
    for (const r of records) {
      for (const p of r.pairs) if (p.code === 8) layers.push(r.type + '\u0000' + String(p.value));
      if (['TEXT','MTEXT','ATTRIB','ATTDEF','DIMENSION','MLEADER'].includes(r.type)) {
        for (const p of r.pairs) if (p.code === 1 || p.code === 3) text.push(r.type + '\u0000' + String(p.value));
      }
    }
    return { entityCount: records.length, types: multiset(types), layers: multiset(layers), text: multiset(text), normalizedBlankLines: parsed.normalizedBlankLines || 0 };
  }

  function safeTransform(input, transform) {
    const normalized = normalizeBlankPairLines(input);
    if (!normalized.valid) throw new Error('أُوقف التصدير عند السطر ' + normalized.invalidLine + ' لأن إصلاحه يتطلب إسقاط بيانات غير فارغة. الملف الأصلي محفوظ ولم يُنشأ ملف ناقص.');
    const before = structureFingerprint(normalized.bytes);
    const result = originalTransform(normalized.bytes, transform);
    if (!result || !result.bytes) throw new Error('لم ينتج محرك التوجيه ملفًا.');
    if ((result.repairedBoundaries || 0) > 0 || (result.repairedMalformedRows || 0) > 0) {
      throw new Error('أُوقف التصدير لأن مسار الاستعادة كان سيحذف أجزاء من DXF. يلزم إصلاح المصدر دون إسقاط كيانات.');
    }
    const outputNorm = normalizeBlankPairLines(result.bytes);
    if (!outputNorm.valid || outputNorm.changed) throw new Error('ملف DXF الناتج لم يجتز تحقق بنية الأزواج دون تعديل إضافي. لم يتم تنزيله.');
    const after = structureFingerprint(outputNorm.bytes);
    if (before.types !== after.types || before.layers !== after.layers || before.text !== after.text || before.entityCount !== after.entityCount) {
      throw new Error('فشل تحقق الحفاظ على عناصر/طبقات/نصوص CAD بعد التوجيه. لم يتم تنزيل الناتج.');
    }
    result.bytes = outputNorm.bytes;
    result.v113Validation = {
      entitiesBefore: before.entityCount,
      entitiesAfter: after.entityCount,
      typeCountsUnchanged: true,
      layerAssignmentsUnchanged: true,
      textContentUnchanged: true,
      blankLinesNormalized: normalized.changed
    };
    stats.lastExportValidation = result.v113Validation;
    return result;
  }
  ENGINE.transformBytes = safeTransform;
  CORE.transformBytes = safeTransform;
  RECOVERY.transformBytes = safeTransform;
  window.__sqOrientation113API = {
    VERSION: '1.0.113', stats,
    normalizeBlankPairLines,
    structureFingerprint,
    parseDrawing: MANUAL.parseDrawing,
    transformBytes: safeTransform
  };
})();
