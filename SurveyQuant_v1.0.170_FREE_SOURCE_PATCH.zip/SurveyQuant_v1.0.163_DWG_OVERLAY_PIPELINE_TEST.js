'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const CAD=require('./SurveyQuant_v1.0.163_CAD_ENGINE.js');
const html=fs.readFileSync(process.argv[2],'utf8');
const start=html.indexOf('async function dropFilesMerge(){');
const end=html.indexOf('\nfunction downloadDroppedDXF()',start);
assert.ok(start>=0&&end>start,'V163 projection handler is present');
const handler=html.slice(start,end);
function dxf(label,x){return new TextEncoder().encode([
 '0','SECTION','2','HEADER','9','$ACADVER','1','AC1009','0','ENDSEC',
 '0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','1','0','LAYER','2','0','70','0','62','7','6','CONTINUOUS','0','ENDTAB','0','ENDSEC',
 '0','SECTION','2','BLOCKS','0','ENDSEC','0','SECTION','2','ENTITIES',
 '0','LINE','8','0','10',String(x),'20','0','11',String(x+10),'21','10','1000',label,
 '0','ENDSEC','0','EOF',''
].join('\n'));}
const files={dropSurveyFiles:{files:[{name:'source.dwg'}]},dropCadFile:{files:[{name:'reference.dwg'}]},dropFilesProgress:{style:{},textContent:''},dropFilesResults:{style:{display:'none'}},dropFilesSummary:{innerHTML:''}};
const calls=[];
const sandbox={
 window:{SurveyQuantCAD163:CAD},
 document:{getElementById:id=>files[id]||null},
 parseFile:async(file,options)=>{calls.push({file:file.name,options});return {rawDXFBytes:file.name==='source.dwg'?dxf('SOURCE_DWG_RAW',0):dxf('TARGET_DWG_RAW',100)};},
 TextDecoder,TextEncoder,Uint8Array,console,
 escapeHtml:s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),
 setTimeout:fn=>{fn();return 1;},alert:msg=>{throw new Error('Unexpected alert: '+msg);},
 droppedDXF:'',
};
(async()=>{
 const script=new vm.Script(`${handler}\n;dropFilesMerge().then(()=>droppedDXF);`);
 const merged=await script.runInNewContext(sandbox);
 assert.equal(calls.length,2,'both DWG inputs use shared converter');
 for(const c of calls){assert.equal(c.options.rawOnly,true);assert.equal(c.options.conversionOnly,true);assert.equal(c.options.retainRawDWG,false);}
 assert.ok(merged instanceof Uint8Array,'the output is a DXF byte stream');
 const out=new TextDecoder().decode(merged);
 assert.ok(out.includes('SOURCE_DWG_RAW'),'all source raw drawing entities are merged');
 assert.ok(out.includes('TARGET_DWG_RAW'),'reference board data remains intact');
 assert.ok(files.dropFilesResults.style.display==='block','the UI exposes the successful merged output');
 assert.ok(files.dropFilesSummary.innerHTML.includes('لم تُعد رسم'),'UI explains raw-record merging');
 console.log('PASS V163 DWG-to-DWG overlay pipeline: both DWG inputs request conversion-only raw DXF, merge the raw records, retain reference/source markers, and enable output UI.');
})().catch(e=>{console.error(e);process.exit(1);});
