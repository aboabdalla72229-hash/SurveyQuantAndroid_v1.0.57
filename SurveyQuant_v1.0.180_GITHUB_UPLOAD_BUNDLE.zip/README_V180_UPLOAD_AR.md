# رفع إصلاح SurveyQuant v1.0.180 من الهاتف

1. ارفع `SurveyQuant_v1.0.180_FIX_KIT.zip` إلى جذر مستودع `SurveyQuantAndroid_v1.0.57` بجانب ملفات الإصدارات السابقة.
2. ارفع `build-v180-session-reset-hybrid-pdf.yml` إلى المسار `.github/workflows/build-v180-session-reset-hybrid-pdf.yml`.
3. اعمل Commit للملفين. الـworkflow يبدأ تلقائيًا، ويستخدم run v179 رقم `41391995879` كأساس قابل للتبديل من `workflow_dispatch`.
4. افتح GitHub Actions وانتظر أن تظهر نتيجة `SurveyQuant-v1.0.180-FREE-SESSION-HYBRID-PDF-FIX`.
5. لا تثبت أي APK قبل أن تكون نتيجة البناء `success` ويظهر ملف APK الموقّع داخل الـArtifact.

الحزمة تختبر فعليًا واجهة التوجيه بعد تغيير كل ملف، وPDF المختلط وRaster-only وVector-only، وتتحقق من اسم DXF قبل بدء الاستخراج. تقرير الاختبار موجود في `V180_TEST_REPORT_AR.txt` داخل الإصلاح.
