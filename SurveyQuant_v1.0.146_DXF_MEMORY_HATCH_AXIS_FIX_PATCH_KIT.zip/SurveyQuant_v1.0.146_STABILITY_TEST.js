'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const htmlPath = process.argv[2];
assert(htmlPath, 'usage: node SurveyQuant_v1.0.146_STABILITY_TEST.js index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
function body(text,id){
  const re=new RegExp(`<script\\b(?=[^>]*\\bid=["']${id}["'])[^>]*>([\\s\\S]*?)<\\/script\\s*>`,'ig');
  const matches=[...text.matchAll(re)];
  assert.equal(matches.length,1,`expected exactly one script ${id}`);
  return matches[0][1];
}
assert(html.includes('const SQ_APP_VERSION_CODE = 146;'), 'versionCode 146');
assert(html.includes('surveyquant-v146-fresh-board-session'), 'fresh-session guard updated');
const window={__sqOrientTest:{}};
const document={readyState:'loading',addEventListener(){},getElementById(){return null;},querySelector(){return null;},querySelectorAll(){return [];},createElement(){return {style:{},appendChild(){},remove(){},click(){}};},head:{appendChild(){}},body:{appendChild(){},classList:{add(){},remove(){}}}};
const ctx={window,document,console,Uint8Array,ArrayBuffer,Map,Set,Math,Number,String,Object,RegExp,Error,Promise,Blob:global.Blob,URL:global.URL,TextEncoder,TextDecoder,performance:{now:()=>0},setTimeout,clearTimeout};
window.window=window;window.document=document;vm.createContext(ctx);
vm.runInContext(body(html,'sq-orientation-reference-board-module'),ctx,{timeout:10000});
const api=window.__sqOrientation110API;
assert(api&&api.transformBytes&&api.parsePreview&&api.validateDxfOutputLight,'orientation APIs must load');
const dxfHeader='0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1027\n9\n$DWGCODEPAGE\n3\nANSI_1252\n0\nENDSEC\n';
const hatchDxf=dxfHeader+`0\nSECTION\n2\nENTITIES\n0\nHATCH\n5\n100\n8\nHATCH_LAYER\n10\n1\n20\n1\n30\n0\n210\n0\n220\n0\n230\n1\n91\n1\n92\n2\n72\n0\n73\n1\n93\n4\n10\n1\n20\n1\n10\n2\n20\n1\n10\n2\n20\n2\n10\n1\n20\n2\n97\n0\n75\n0\n76\n1\n52\n0\n41\n1\n77\n0\n78\n1\n53\n0\n43\n10\n44\n20\n45\n1\n46\n2\n79\n0\n0\nENDSEC\n0\nEOF\n`;
const transform=api.solve({x:0,y:0},{x:10,y:0},{x:1000,y:2000},{x:1000,y:2020});
assert(Math.abs(transform.scale-2)<1e-10&&Math.abs(transform.angleDeg-90)<1e-8,'2 point Alignment transform should be scale=2, rotation=90');
const result=api.transformBytes(new TextEncoder().encode(hatchDxf),transform);
assert.equal(result.entitiesBefore,result.entitiesAfter,'HATCH entity count preserved');
const outPairs=api.splitPairs(result.bytes).pairs;
const records=api.sectionRecords(outPairs,'ENTITIES');
assert.equal(records.length,1);assert.equal(records[0].type,'HATCH');
const values=code=>records[0].pairs.filter(p=>p.code===code).map(p=>Number(p.value));
for(const [code,expected] of [[43,-40],[44,20],[45,-4],[46,2]]){
  assert(Math.abs(values(code)[0]-expected)<1e-8,`HATCH pattern code ${code}: expected ${expected}, got ${values(code)[0]}`);
}
assert(outPairs[outPairs.length-1].code===0&&outPairs[outPairs.length-1].value.toUpperCase()==='EOF','complete EOF survives output');
assert(result.entitiesBefore===result.entitiesAfter,'entity count/signature validation retains entity identity');
console.log('PASS V146: HATCH pattern-local origin/offset rotate and scale but never receive global translation.');
console.log('PASS V146: translated HATCH boundary, entity count/type, and terminal EOF remain valid.');

// Axis bubble text inside a block must be transformed into world coordinates for preview without decoding the whole DXF again.
const axisDxf=dxfHeader+`0\nSECTION\n2\nBLOCKS\n0\nBLOCK\n2\nAXIS_BUBBLE\n70\n0\n10\n0\n20\n0\n30\n0\n0\nTEXT\n8\nAXIS_NAMES\n10\n0\n20\n0\n40\n2.5\n1\nAX-01\n0\nENDBLK\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n0\nINSERT\n8\nAXIS_NAMES\n2\nAXIS_BUBBLE\n10\n100\n20\n200\n30\n0\n41\n1\n42\n1\n43\n1\n50\n0\n0\nLINE\n8\nGRID\n10\n100\n20\n200\n30\n0\n11\n120\n21\n200\n31\n0\n0\nENDSEC\n0\nEOF\n`;
window.__sqManualOrientation109={parseDrawing(){throw new Error('force low-memory fallback');}};
const drawing=api.parsePreview(new TextEncoder().encode(axisDxf));
const label=drawing.texts.find(t=>String(t.text||'').replace(/\s/g,'').toUpperCase()==='AX-01');
assert(label,'axis label AX-01 is restored from nested INSERT');
assert(Math.abs(label.p.x-100)<1e-8&&Math.abs(label.p.y-200)<1e-8,'nested axis-label location is transformed from block coordinates to WCS');
assert(drawing.segs.length>0,'preview still renders common geometry');
console.log('PASS V146: nested INSERT axis names are restored from parsed DXF records and placed in WCS.');

// Force the >1.5 MB fallback path with many ordinary lines. Preview is bounded; source remains complete.
const largeHeader=dxfHeader.replace('0\nENDSEC\n','999\n'+'P'.repeat(500000)+'\n0\nENDSEC\n');
let large=largeHeader+'0\nSECTION\n2\nENTITIES\n';
for(let i=0;i<24000;i++) large+=`0\nLINE\n8\nGRID\n10\n${i}\n20\n0\n30\n0\n11\n${i+1}\n21\n5\n31\n0\n`;
large+='0\nENDSEC\n0\nEOF\n';
const largeBytes=new TextEncoder().encode(large);
assert(largeBytes.length>1500000,'large preview fixture should trigger low-memory path');
const largeDrawing=api.parsePreview(largeBytes);
assert.equal(largeDrawing.originalEntityRecords,24000,'all input entities are still enumerated');
assert(largeDrawing.segs.length<=140000,'preview segments are bounded');
assert(largeDrawing.previewLowMemory===true,'large file must use low-memory preview mode');
const largeExport=api.transformBytes(largeBytes,transform);
assert.equal(largeExport.entitiesBefore,24000,'large source entity count before transform');
assert.equal(largeExport.entitiesAfter,24000,'large source entity count after transform');
assert.notEqual(largeExport.bytes,largeBytes,'output must be created without mutating source byte buffer');
const largeOutPairs=api.splitPairs(largeExport.bytes).pairs;
const largeOutRecords=api.sectionRecords(largeOutPairs,'ENTITIES');
assert.equal(largeOutRecords.length,24000,'all large-file LINE entities preserved');
assert(largeOutRecords[0].pairs.some(p=>p.code===10&&Math.abs(Number(p.value)-1000)<1e-8),'large-file first point was transformed, not left in place');
console.log(`PASS V146: large DXF preview and export (${largeDrawing.segs.length} preview segments; ${largeBytes.length} input bytes) are memory-aware; ${largeExport.entitiesAfter} entities remain after actual transformation.`);

// Static safety checks for accidental full-file re-decode and quadratic slicing.
const moduleBody=body(html,'sq-orientation-reference-board-module');
assert(!moduleBody.includes('new TextDecoder(encoding).decode(bytes)'), 'preview must not decode full DXF a second time');
assert(moduleBody.includes('output.set(bytes.subarray(sourcePos,op.start),destPos)'), 'single-allocation output writer is present');
assert(moduleBody.includes('function validateDxfOutputLight'), 'streamed output validator is installed');
console.log('PASS V146: no second full-file axis decode; single-allocation output writer and streaming output validator are installed.');
