'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const htmlPath = process.argv[2];
assert(htmlPath, 'usage: node SurveyQuant_v1.0.147_REGRESSION_TEST.js index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
assert(html.includes('const SQ_APP_VERSION_CODE = 147;'), 'version must be 147');
assert(html.includes('m.polylines.push(poly);m.entities.push(poly);'), 'raw DXF recovery must preserve original polyline closure/vertices');
assert(html.includes('function processHatchRecord()'), 'dedicated HATCH boundary transform must be present');
assert(html.includes('const startKey=first.a.key'), 'closed LINE-loop recovery must terminate by endpoint identity');

// Execute the actual concrete geometry functions extracted from the app, with only the
// app-independent helpers supplied by this harness.
function between(source, start, end) {
  const a = source.indexOf(start), b = source.indexOf(end, a + start.length);
  assert(a >= 0 && b > a, `missing source block: ${start}`);
  return source.slice(a, b);
}
const closure = between(html, 'function sqPolylineIsClosed(entity, vertices){', '\nfunction parseDXF(text){');
const concrete = between(html, 'function sqNormalizeConcreteVertices(input){', '\nfunction sqTriangulatePolygon2D(vertices){');
const concreteContext = {Math, Number, String, Array, Map, Set, Object, Infinity};
vm.createContext(concreteContext);
vm.runInContext(closure + '\n' + concrete + '\nthis.__closed=sqConcreteClosedPolylines; this.__area=v=>{let a=0;for(let i=0;i<v.length;i++){const p=v[i],q=v[(i+1)%v.length];a+=p.x*q.y-q.x*p.y;}return Math.abs(a)/2;};', concreteContext);
const line = (a,b,layer='SLAB') => ({a:{x:a[0],y:a[1],z:0},b:{x:b[0],y:b[1],z:0},layer});
const lineModel = {polylines:[],entities:[],segments:[
  line([0,0],[100,0]), line([100,0],[100,100]), line([100,100],[0,100]), line([0,100],[0,0])
]};
const recoveredLoops = concreteContext.__closed(lineModel, ' slab ');
assert.equal(recoveredLoops.length, 1, 'four LINE segments should recover one closed footprint');
assert.equal(concreteContext.__area(recoveredLoops[0].vertices), 10000, 'recovered footprint area must be exact');
assert.equal(recoveredLoops[0].recoveredFromLines, true, 'result must disclose LINE-loop recovery');

const poly = {type:'LWPOLYLINE', layer:'MAIN', closed:true, vertices:[{x:0,y:0},{x:40,y:0},{x:40,y:25},{x:0,y:25}]};
const polyModel = {polylines:[poly], entities:[{...poly,layer:'main'}],segments:[]};
const polys = concreteContext.__closed(polyModel,' MAIN ');
assert.equal(polys.length,1,'layer matching is normalized and duplicate closed polylines are deduplicated');
assert.equal(concreteContext.__area(polys[0].vertices),1000,'polyline area calculation stays correct');

// Raw record parsing must retain the actual closed flag and vertices even when the general DXF
// parser has to fall back because another entity in the drawing is unsupported.
const rawFunctions=between(html,'function sqRawDxfValue(rec, code, fallback=\'\') {','\nfunction sqExtractDxfAxisEntities(text){');
const blockExpander=between(html,'function sqConcreteExpandBlockPolylines(model){','\nasync function loadConcreteDxf(){');
const blockContext={Math,Number,String,Array,Map,Set,Object,Infinity, sqNormalizeConcreteVertices:concreteContext.sqNormalizeConcreteVertices};
vm.createContext(blockContext);
vm.runInContext(rawFunctions+'\n'+blockExpander+'\nthis.__raw=sqRawDxfGroupPolylines;this.__section=sqRawDxfSectionRecords;this.__expand=sqConcreteExpandBlockPolylines;',blockContext);
const nestedDxf=`0\nSECTION\n2\nBLOCKS\n0\nBLOCK\n2\nSLAB_OUTLINE\n70\n0\n10\n0\n20\n0\n30\n0\n0\nLWPOLYLINE\n8\n0\n70\n1\n90\n4\n10\n0\n20\n0\n10\n10\n20\n0\n10\n10\n20\n5\n10\n0\n20\n5\n0\nENDBLK\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n0\nINSERT\n8\nMAIN_LAYER\n2\nSLAB_OUTLINE\n10\n100\n20\n200\n30\n0\n41\n2\n42\n2\n43\n1\n50\n90\n0\nENDSEC\n0\nEOF\n`;
const blockRecords=blockContext.__raw(blockContext.__section(nestedDxf,'BLOCKS'));
assert.equal(blockRecords.filter(e=>e.type==='LWPOLYLINE').length,1,'raw DXF reader must retain the closed LWPOLYLINE inside a block');
const extractedBlocks=blockContext.__expand({rawDXF:nestedDxf,polylines:[],layers:new Map()});
assert.equal(extractedBlocks.length,1,'concrete layer must include the inserted closed outline');
assert.equal(extractedBlocks[0].layer,'MAIN_LAYER','layer 0 inside block inherits INSERT layer');
assert.equal(concreteContext.__area(extractedBlocks[0].vertices),200,'block scaling transforms area by scale squared');
assert(Math.abs(extractedBlocks[0].vertices[0].x-100)<1e-8&&Math.abs(extractedBlocks[0].vertices[0].y-200)<1e-8,'block base/insertion point is transformed');
assert(Math.abs(extractedBlocks[0].vertices[1].x-100)<1e-8&&Math.abs(extractedBlocks[0].vertices[1].y-220)<1e-8,'block rotation and scale are applied to concrete boundary');

// Execute the OCS transformation function from the app itself. The synthetic HATCH contains
// a header elevation, line/arc/ellipse/spline edge coordinates, seed point and pattern vectors.
const ocsBlock = between(html, ' const sq145OCSTypes=new Set(', '\n\n function transformRecord(rec, countForEntity=true)');
const ocsContext = {Math, Number, String, Array, Map, Set, Object, Infinity};
vm.createContext(ocsContext);
vm.runInContext(ocsBlock + '\nthis.__ocs=sq145TransformOCSRecord;', ocsContext);
const values = [
  [0,'HATCH'],[8,'A-HATCH'],[10,'0'],[20,'0'],[30,'0'],[210,'0'],[220,'0'],[230,'1'],
  [91,'1'],[92,'1'],[93,'4'],
  [72,'1'],[10,'0'],[20,'0'],[11,'100'],[21,'0'],
  [72,'2'],[10,'100'],[20,'0'],[40,'10'],[50,'0'],[51,'90'],[73,'1'],
  [72,'3'],[10,'100'],[20,'100'],[11,'10'],[21,'0'],[40,'0.5'],[50,'0'],[51,'90'],[73,'1'],
  [72,'4'],[94,'3'],[73,'0'],[74,'0'],[95,'0'],[96,'1'],[10,'50'],[20,'50'],[42,'1'],[97,'1'],[11,'60'],[21,'60'],[12,'2'],[22,'0'],[13,'0'],[23,'3'],
  [75,'0'],[76,'0'],[52,'0'],[41,'1'],[77,'0'],[78,'1'],[53,'0'],[43,'2'],[44,'3'],[45,'0'],[46,'5'],[79,'0'],[98,'1'],[10,'25'],[20,'30']
];
const pairs=values.map(([code,value],index)=>({code,value:String(value),index,start:index,valueStart:index+0.1,valueEnd:index+0.2,end:index+0.3}));
const rec={type:'HATCH',pairs};
const by=new Map();for(const p of pairs){if(!by.has(p.code))by.set(p.code,[]);by.get(p.code).push(p);}
const edits=new Map();
const change=(pair,value)=>{if(pair&&Number.isFinite(value))edits.set(pair.index,value);};
const num=v=>{const n=Number(v);return Number.isFinite(n)?n:null;};
const t={scale:2,angleDeg:90,c:0,s:1,tx:1000,ty:2000,
  point:(x,y)=>({x:1000-2*y,y:2000+2*x}),
  vector:(x,y)=>({x:-2*y,y:2*x})};
const ocsResult=ocsContext.__ocs(rec,by,new Map(),change,num,t,0,()=>{},()=>{});
assert(ocsResult && ocsResult.processed>0,'HATCH boundaries must be transformed');
const get=(code,occ=0)=>{const target=by.get(code)[occ];return target?edits.get(target.index)??Number(target.value):null;};
// The first 10/20/30 elevation origin is not a boundary vertex and must not receive tx/ty.
assert.equal(get(10,0),0,'HATCH elevation origin X must not receive the world translation');
assert.equal(get(20,0),0,'HATCH elevation origin Y must not receive the world translation');
// First line-edge start stays a full point; its endpoint is also transformed as a point.
assert.equal(get(10,1),1000,'HATCH edge start X must receive tx');
assert.equal(get(20,1),2000,'HATCH edge start Y must receive ty');
assert.equal(get(11,0),1000,'line-edge endpoint X must be transformed, not left behind');
assert.equal(get(21,0),2200,'line-edge endpoint Y must be transformed, not left behind');
// Arc radius scales, and edge angles rotate. Ellipse ratio does not scale; major-axis relative
// vector scales/rotates but must not receive translation.
assert.equal(get(40,0),20,'circular HATCH edge radius must scale');
assert.equal(get(50,0),90,'arc start angle must rotate in the new OCS');
assert(Math.abs(get(11,1))<1e-9,'ellipse major-axis vector X must rotate/scale without translation');
assert.equal(get(21,1),20,'ellipse major-axis vector Y must rotate/scale without translation');
assert.equal(get(40,1),0.5,'ellipse axis ratio must remain dimensionless');
// Spline fit points are points, but spline tangents are vectors.
assert.equal(get(11,2),880,'spline fit points must translate');
assert.equal(get(21,2),2120,'spline fit-point Y must translate');
assert(Math.abs(get(12,0))<1e-9,'spline tangent X must rotate/scale without translation');
assert.equal(get(22,0),4,'spline tangent Y must rotate/scale without translation');
// Pattern base and spacing are local vectors, while the seed point is an absolute OCS point.
assert.equal(get(43,0),-6,'hatch pattern base X must not receive tx/ty');
assert.equal(get(44,0),4,'hatch pattern base Y rotates/scales without translation');
assert.equal(get(45,0),-10,'hatch pattern spacing X rotates/scales without translation');
assert(Math.abs(get(46,0))<1e-9,'hatch pattern spacing Y rotates/scales without translation');
assert.equal(get(10,5),940,'hatch seed point X must be transformed as an absolute point');
assert.equal(get(20,5),2050,'hatch seed point Y must be transformed as an absolute point');

console.log('PASS V147: raw-DXF recovery preserves closed LWPOLYLINE/POLYLINE structure.');
console.log('PASS V147: four LINE segments recover a closed concrete footprint (area 10000).');
console.log('PASS V147: normalized layer matching and canonical polygon deduplication.');
console.log('PASS V147: concrete closed outlines inside INSERT blocks retain inherited layer, insertion, rotation, and scale.');
console.log('PASS V147: HATCH header, edge endpoints, arc radius/angles, ellipse axis vectors, spline points/tangents, pattern vectors, and seed points transform correctly.');
