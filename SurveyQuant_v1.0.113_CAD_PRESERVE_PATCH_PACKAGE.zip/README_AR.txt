SurveyQuant v1.0.113 CAD Preserve Patch

Changes:
- Normalize only provable extra blank physical lines that break DXF group-code/value alignment. Non-empty source bytes are not discarded.
- Supplement preview geometry for entity types omitted by the previous simplified canvas renderer, while retaining original DXF entity records for export.
- Validate entity type counts, entity count, layer assignments, and text content before offering a transformed DXF.
- Refuse export if the existing recovery path would need to discard malformed non-empty rows.

Important limitation:
This patch has synthetic regression coverage. The attached real test drawings are DWG files (AC1032 and AC1024), and the current runner environment cannot execute the app's remotely-loaded LibreDWG WebAssembly converter against them. Therefore, do not interpret passing synthetic tests or a successful Android build as proof that these exact STORM files have been validated. Test both real files in-app/CAD before release.
