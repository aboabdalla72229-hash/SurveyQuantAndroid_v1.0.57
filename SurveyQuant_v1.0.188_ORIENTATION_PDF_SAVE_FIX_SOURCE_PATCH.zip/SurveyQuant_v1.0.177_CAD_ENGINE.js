(function (root, factory) {
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) { root.SurveyQuantCAD176 = api; root.SurveyQuantCAD177 = api; }
  if (root && root.document) api.mount();
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
  'use strict';
  const SQ_V166_SOURCE_VIEW_ONLY_AND_EXACT_PDF_RASTER_UNDERLAY = true;
  const SQ_V167_DWG_ORIENTATION_VIEW_TRANSFORM = true;
  const SQ_V168_AXIS_SNAP_POINT_AND_RASTER_FIX = true;
  const SQ_V170_ORIENTATION_VIEWPORT_PER_BOARD_PICK_SNAP_AXES_EXTENTS_AND_PDF_WORKER = true;
  const SQ_V176_SEPARATE_PROJECT_CARDS = true;
  const SQ_V173_NO_DUPLICATE_HOME_FALLBACK = true;
  const SQ_V174_ORDERED_PICK_ALIGNMENT_DIAGNOSTICS = true;

  const enc = new TextEncoder();
  const SAFE_SEGMENT_LIMIT = 80000;
  const finite = Number.isFinite;
  const norm = n => Math.abs(n) < 1e-12 ? 0 : n;
  const fmt = n => {
    if (!finite(n)) throw new Error('نتجت قيمة إحداثية غير صالحة؛ أوقفت العملية لحماية الملف الأصلي.');
    n = norm(n);
    return String(Number(n.toPrecision(14)));
  };
  function decodeBytes(bytes) {
    return new TextDecoder('windows-1252').decode(bytes);
  }
  function readLine(bytes, start) {
    if (start >= bytes.length) return null;
    let end = start;
    while (end < bytes.length && bytes[end] !== 10) end++;
    let valueEnd = end;
    if (valueEnd > start && bytes[valueEnd - 1] === 13) valueEnd--;
    return { start, valueEnd, end: end < bytes.length ? end + 1 : end };
  }
  function pairText(bytes, line) {
    return decodeBytes(bytes.subarray(line.start, line.valueEnd)).trim();
  }
  function forEachPair(bytes, callback) {
    let pos = 0;
    while (pos < bytes.length) {
      const codeLine = readLine(bytes, pos);
      if (!codeLine) break;
      const valueLine = readLine(bytes, codeLine.end);
      if (!valueLine) break;
      const codeText = pairText(bytes, codeLine);
      const code = Number.parseInt(codeText, 10);
      callback({
        code,
        value: pairText(bytes, valueLine),
        start: codeLine.start,
        valueStart: valueLine.start,
        valueEnd: valueLine.valueEnd,
        end: valueLine.end,
      });
      pos = valueLine.end;
    }
  }
  function solve(sourceA, sourceB, targetA, targetB) {
    const values=[sourceA?.x,sourceA?.y,sourceB?.x,sourceB?.y,targetA?.x,targetA?.y,targetB?.x,targetB?.y].map(Number);
    if (!values.every(finite)) throw new Error('إحداثيات نقاط التوجيه غير صالحة.');
    sourceA={x:values[0],y:values[1]};sourceB={x:values[2],y:values[3]};
    targetA={x:values[4],y:values[5]};targetB={x:values[6],y:values[7]};
    const dx1=sourceB.x-sourceA.x,dy1=sourceB.y-sourceA.y;
    const dx2=targetB.x-targetA.x,dy2=targetB.y-targetA.y;
    const d1=Math.hypot(dx1,dy1),d2=Math.hypot(dx2,dy2);
    if(d1<1e-9||d2<1e-9)throw new Error('اختر نقطتين مختلفتين في كل لوحة.');
    if(!finite(d1)||!finite(d2))throw new Error('طول خط التوجيه خارج النطاق العددي المسموح.');
    const scale=d2/d1;
    // Signed angle from the source baseline to the corresponding target baseline.
    // atan2(cross,dot) avoids subtracting two bearings and is stable at +/-180 degrees.
    const cross=dx1*dy2-dy1*dx2,dot=dx1*dx2+dy1*dy2;
    const angle=Math.atan2(cross,dot),cos=Math.cos(angle),sin=Math.sin(angle);
    const translationX=targetA.x-scale*(sourceA.x*cos-sourceA.y*sin);
    const translationY=targetA.y-scale*(sourceA.x*sin+sourceA.y*cos);
    const apply=p=>({x:scale*(Number(p.x)*cos-Number(p.y)*sin)+translationX,y:scale*(Number(p.x)*sin+Number(p.y)*cos)+translationY});
    const mappedA=apply(sourceA),mappedB=apply(sourceB);
    const residualA=Math.hypot(mappedA.x-targetA.x,mappedA.y-targetA.y),residualB=Math.hypot(mappedB.x-targetB.x,mappedB.y-targetB.y);
    const tolerance=Math.max(1e-8,Math.max(Math.abs(targetA.x),Math.abs(targetA.y),Math.abs(targetB.x),Math.abs(targetB.y),d2)*1e-12);
    if(residualA>tolerance||residualB>tolerance)throw new Error('فشل التحقق من مطابقة نقطتي التوجيه. راجع ترتيب النقاط الأربع.');
    const degrees=angle*180/Math.PI;
    const bearing=d=>((d%360)+360)%360;
    return{scale,rotationRadians:angle,rotationDegrees:Math.abs(degrees)<1e-10?0:degrees,translationX,translationY,sourceLength:d1,targetLength:d2,sourceBearingDegrees:bearing(Math.atan2(dy1,dx1)*180/Math.PI),targetBearingDegrees:bearing(Math.atan2(dy2,dx2)*180/Math.PI),apply,residualA,residualB};
  }
  function rejectIdentityAlignment(picks){
    const d=alignmentDiagnostics(picks);
    const coordScale=Math.max(1,Math.abs(d.sourceA.x),Math.abs(d.sourceA.y),Math.abs(d.sourceB.x),Math.abs(d.sourceB.y),Math.abs(d.targetA.x),Math.abs(d.targetA.y),Math.abs(d.targetB.x),Math.abs(d.targetB.y));
    const tol=Math.max(1e-7,coordScale*1e-12);
    const identity=Math.abs(d.rotationDegrees)<1e-7&&Math.abs(d.scale-1)<1e-10&&Math.hypot(d.translationX,d.translationY)<=tol;
    if(identity)throw new Error('لم يتم اعتماد التوجيه: النقطتان المختارتان في المصدر والمرجع لهما الإحداثيات نفسها، والحساب ينتج دورانًا 0° ومقياس 1 وإزاحة 0. هذا تحويل بلا أي تغيير. اختر النقطتين المناظرتين من اللوحة المرجعية الصحيحة، وتأكد أنك لم تحمل الملف نفسه في الخانتين.');
    return d;
  }
  function alignmentDiagnostics(picks){
    if(!Array.isArray(picks)||picks.length!==4||!picks.every(p=>p&&finite(Number(p.x))&&finite(Number(p.y))))throw new Error('اختر النقاط الأربع بالترتيب: مصدر 1، مصدر 2، مرجع 1، مرجع 2.');
    const [sourceA,sourceB,targetA,targetB]=picks.map(p=>({x:Number(p.x),y:Number(p.y)})),tr=solve(sourceA,sourceB,targetA,targetB);
    return{sourceA,sourceB,targetA,targetB,sourceDelta:{x:sourceB.x-sourceA.x,y:sourceB.y-sourceA.y},targetDelta:{x:targetB.x-targetA.x,y:targetB.y-targetA.y},sourceLength:tr.sourceLength,targetLength:tr.targetLength,sourceBearingDegrees:tr.sourceBearingDegrees,targetBearingDegrees:tr.targetBearingDegrees,rotationDegrees:tr.rotationDegrees,scale:tr.scale,translationX:tr.translationX,translationY:tr.translationY,residualA:tr.residualA,residualB:tr.residualB};
  }
  function transformGeometryView(geometry, transform) {
    if (!geometry || !transform || typeof transform.apply !== 'function') throw new Error('بيانات التوجيه غير مكتملة.');
    const mapPoint = p => transform.apply({x:Number(p.x),y:Number(p.y)});
    const angle = Number(transform.rotationRadians)||0, scale=Number(transform.scale);
    if (!finite(scale) || scale<=0) throw new Error('مقياس التوجيه غير صالح.');
    const mapVector = v => ({x:scale*(Number(v.x)*Math.cos(angle)-Number(v.y)*Math.sin(angle)),y:scale*(Number(v.x)*Math.sin(angle)+Number(v.y)*Math.cos(angle))});
    const out = {
      ...geometry,
      segments: (geometry.segments||[]).map(seg=>({...seg,a:mapPoint(seg.a),b:mapPoint(seg.b)})),
      points: (geometry.points||[]).map(p=>({...p,...mapPoint(p)})),
      texts: (geometry.texts||[]).map(t=>({...t,position:mapPoint(t.position),height:(Number(t.height)||0)*scale,rotation:(Number(t.rotation)||0)+angle*180/Math.PI})),
      curves: (geometry.curves||[]).map(c=>({...c,center:c.center?mapPoint(c.center):c.center,radius:(Number(c.radius)||0)*scale,start:(Number(c.start)||0)+angle,points:(c.points||[]).map(mapPoint)})),
      raster: geometry.raster ? {...geometry.raster,insert:mapPoint(geometry.raster.insert),u:mapVector(geometry.raster.u),v:mapVector(geometry.raster.v)} : geometry.raster
    };
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    const include=q=>{if(q&&finite(q.x)&&finite(q.y)){minX=Math.min(minX,q.x);minY=Math.min(minY,q.y);maxX=Math.max(maxX,q.x);maxY=Math.max(maxY,q.y);}};
    for(const seg of out.segments){include(seg.a);include(seg.b);}
    for(const point of out.points)include(point);
    for(const label of out.texts)include(label.position);
    for(const curve of out.curves){if(curve.center&&finite(curve.radius)){include({x:curve.center.x-curve.radius,y:curve.center.y-curve.radius});include({x:curve.center.x+curve.radius,y:curve.center.y+curve.radius});}for(const q of curve.points)include(q);}
    if(out.raster){const r=out.raster,w=Number(r.width)||0,h=Number(r.height)||0,u=r.u||{x:0,y:0},v=r.v||{x:0,y:0};include(r.insert);include({x:r.insert.x+u.x*w,y:r.insert.y+u.y*w});include({x:r.insert.x+v.x*h,y:r.insert.y+v.y*h});include({x:r.insert.x+u.x*w+v.x*h,y:r.insert.y+u.y*w+v.y*h});}
    if(!finite(minX)){const c=mapPoint({x:(geometry.minX+geometry.maxX)/2,y:(geometry.minY+geometry.maxY)/2});minX=maxX=c.x;minY=maxY=c.y;}
    out.minX=minX;out.minY=minY;out.maxX=maxX;out.maxY=maxY;
    return out;
  }

  function applyEdits(source, edits) {
    const sorted = edits.slice().sort((a, b) => a.start - b.start || a.end - b.end);
    let total = source.length, cursor = 0;
    for (const edit of sorted) {
      if (!Number.isInteger(edit.start) || !Number.isInteger(edit.end) || edit.start < cursor || edit.end < edit.start || edit.end > source.length) {
        throw new Error('تداخلت تعديلات البايتات؛ أوقفت التحويل بدلًا من إتلاف DXF.');
      }
      total += (edit.insertBytes || new Uint8Array(0)).length - (edit.end - edit.start);
      cursor = edit.end;
    }
    const out = new Uint8Array(total);
    let sourcePos = 0, outPos = 0;
    for (const edit of sorted) {
      const span = edit.start - sourcePos;
      out.set(source.subarray(sourcePos, edit.start), outPos); outPos += span;
      const insert = edit.insertBytes || new Uint8Array(0);
      out.set(insert, outPos); outPos += insert.length; sourcePos = edit.end;
    }
    out.set(source.subarray(sourcePos), outPos); outPos += source.length - sourcePos;
    if (outPos !== out.length) throw new Error('فشل التحقق من حجم DXF الناتج.');
    return out;
  }
  function transformDxfBytes(rawBytes, sourceA, sourceB, targetA, targetB) {
    const bytes = rawBytes instanceof Uint8Array ? rawBytes : new Uint8Array(rawBytes);
    if (!bytes.length) throw new Error('ملف DXF فارغ.');
    const tr = solve(sourceA, sourceB, targetA, targetB);
    const eol = (() => { for (let i=0;i<bytes.length;i++) if(bytes[i]===10) return i>0&&bytes[i-1]===13?'\r\n':'\n'; return '\n'; })();
    const edits=[]; let pos=0,section='',needSectionName=false,blockHeaderPending=false,blockName='',tableHeaderPending=false,tableName='',entity=null,foundEntities=false,headerVariable='';
    const theta=tr.rotationRadians,cos=Math.cos(theta),sin=Math.sin(theta);
    const point=(x,y)=>tr.apply({x,y});
    const vector=(x,y)=>({x:tr.scale*(x*cos-y*sin),y:tr.scale*(x*sin+y*cos)});
    const add=(pair,value)=>edits.push({start:pair.valueStart,end:pair.valueEnd,insertBytes:enc.encode(fmt(value))});
    function flushEntity(){
      if(!entity)return;
      const type=String(entity.type||'').toUpperCase(),pairs=entity.pairs,by=new Map();
      for(const p of pairs){if(!by.has(p.code))by.set(p.code,[]);by.get(p.code).push(p);}
      for(let xc=10;xc<=18;xc++){
        const xs=by.get(xc)||[],ys=by.get(xc+10)||[];if(!xs.length||xs.length!==ys.length)continue;
        for(let i=0;i<xs.length;i++){
          const x=Number(xs[i].value),y=Number(ys[i].value);if(!finite(x)||!finite(y))continue;
          const isVector=(type==='ELLIPSE'&&xc===11)||(type==='MTEXT'&&xc===11)||((type==='XLINE'||type==='RAY')&&xc===11);
          const q=isVector?vector(x,y):point(x,y);add(xs[i],q.x);add(ys[i],q.y);
        }
      }
      const mul=c=>{for(const p of(by.get(c)||[])){const n=Number(p.value);if(finite(n))add(p,n*tr.scale);}};
      const rot=c=>{for(const p of(by.get(c)||[])){const n=Number(p.value);if(finite(n))add(p,((n+tr.rotationDegrees)%360+360)%360);}};
      let extra='';
      if(type==='CIRCLE'||type==='ARC')mul(40);
      if(['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(type))mul(40);
      if(type==='MTEXT')mul(41);
      if(['LWPOLYLINE','POLYLINE','VERTEX'].includes(type)){mul(40);mul(41);}
      if(type==='LINE')mul(39);
      if(type==='VERTEX')mul(41);
      if(type==='INSERT'){
        for(const c of [41,42,43,44,45]){if((by.get(c)||[]).length)mul(c);else if((c===41||c===42)&&pairs.length)extra+=`${c}${eol}${fmt(tr.scale)}${eol}`;}
        if((by.get(50)||[]).length)rot(50);else if(theta&&pairs.length)extra+=`50${eol}${fmt(tr.rotationDegrees)}${eol}`;
      }else if(type==='ARC'){rot(50);rot(51);}
      else if(type==='ELLIPSE'){/* major-axis vector is transformed above; parameter angles remain local */}
      else if(['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(type)){if((by.get(50)||[]).length)rot(50);else if(theta&&pairs.length)extra+=`50${eol}${fmt(tr.rotationDegrees)}${eol}`;}
      else if(type==='DIMENSION')rot(53);
      else if(type==='HATCH'){
        for(const c of [49,45,46,47,48])if((by.get(c)||[]).length)mul(c);
        for(const c of [50,51,52,53])if((by.get(c)||[]).length)rot(c);
      }
      // A uniform similarity transform must scale style-controlled annotations and linetype dashes too.
      if(type==='STYLE'){for(const c of [40,42])if((by.get(c)||[]).length)mul(c);}
      if(type==='DIMSTYLE'){for(const c of [40,41,42,43,44,45,46,47,48,140,141,142,143,144,145,146,147,148])if((by.get(c)||[]).length)mul(c);}
      if(type==='LTYPE')mul(49);
      if(extra&&pairs.length){const last=pairs[pairs.length-1];edits.push({start:last.end,end:last.end,insertBytes:enc.encode(extra)});}
      entity=null;
    }
    const scaledHeaderVars=new Set(['$LTSCALE','$CELTSCALE','$DIMSCALE','$TEXTSIZE','$DIMASZ','$DIMEXE','$DIMEXO','$DIMGAP','$DIMTXT','$DIMCEN','$DIMTSZ','$DIMBLK','$_PEXTMIN']);
    while(pos<bytes.length){
      const cl=readLine(bytes,pos);if(!cl)break;const vl=readLine(bytes,cl.end);if(!vl)break;
      const code=Number.parseInt(pairText(bytes,cl),10),value=pairText(bytes,vl),pair={code,value,start:cl.start,valueStart:vl.start,valueEnd:vl.valueEnd,end:vl.end};
      if(needSectionName&&code===2){section=value.toUpperCase();needSectionName=false;if(section==='ENTITIES')foundEntities=true;pos=vl.end;continue;}
      if(section==='HEADER'){
        if(code===9)headerVariable=value.toUpperCase();
        else if(code===40&&scaledHeaderVars.has(headerVariable)){const n=Number(value);if(finite(n))add(pair,n*tr.scale);headerVariable='';}
        else if(code!==0)headerVariable='';
      }
      if(section==='TABLES'&&tableHeaderPending&&code===2){tableName=value.toUpperCase();tableHeaderPending=false;pos=vl.end;continue;}
      if(section==='BLOCKS'&&blockHeaderPending&&code===2){blockName=value;blockHeaderPending=false;pos=vl.end;continue;}
      if(code===0){
        flushEntity();const u=value.toUpperCase();
        if(u==='SECTION'){needSectionName=true;pos=vl.end;continue;}
        if(u==='ENDSEC'){section='';blockName='';tableName='';pos=vl.end;continue;}
        if(section==='TABLES'){
          if(u==='TABLE'){tableHeaderPending=true;tableName='';pos=vl.end;continue;}
          if(u==='ENDTAB'){tableName='';pos=vl.end;continue;}
          if(tableName&&['STYLE','DIMSTYLE','LTYPE'].includes(tableName))entity={type:tableName,pairs:[]};
        }else if(section==='BLOCKS'){
          if(u==='BLOCK'){blockHeaderPending=true;pos=vl.end;continue;}
          if(u==='ENDBLK'){blockName='';pos=vl.end;continue;}
          // Anonymous dimension graphics are stored in drawing coordinates; named block definitions stay local.
          if(blockName.toUpperCase().startsWith('*D'))entity={type:u,pairs:[]};
        }else if(section==='ENTITIES')entity={type:u,pairs:[]};
      }else if(entity)entity.pairs.push(pair);
      pos=vl.end;
    }
    flushEntity();
    if(!foundEntities)throw new Error('لم يوجد قسم ENTITIES صالح في ملف DXF.');
    if(tr.scale<1e-12||!finite(tr.scale))throw new Error('مقياس التوجيه الناتج غير صالح.');
    return{bytes:applyEdits(bytes,edits),scale:tr.scale,rotationDegrees:tr.rotationDegrees,editCount:edits.length,mode:'raw-dxf-record-transform'};
  }
  function parseOle2Frame(values){
    try{
      const a=pointsFromPairsForOle(values,10),b=pointsFromPairsForOle(values,11);if(!a||!b)return null;
      const chunks=values[310]||[];if(!chunks.length)return null;
      const hex=chunks.join('');if(!hex.length||hex.length%2)return null;
      const ole=new Uint8Array(hex.length/2);for(let i=0;i<ole.length;i++)ole[i]=parseInt(hex.slice(i*2,i*2+2),16);
      const dv=new DataView(ole.buffer,ole.byteOffset,ole.byteLength);if(ole.length<48||dv.getUint32(0,true)!==0x501)return null;
      const classLen=dv.getUint32(8,true);const dibSizeOffset=24+classLen;if(classLen<1||dibSizeOffset+40>ole.length)return null;
      const dibLen=dv.getUint32(20+classLen,true),dibStart=dibSizeOffset;if(dibLen<40||dibStart+dibLen>ole.length)return null;
      const compression=dv.getUint32(dibStart+16,true);if(compression!==4)return null;
      const jpegStart=dibStart+40,jpegEnd=dibStart+dibLen;if(jpegEnd<=jpegStart)return null;
      const jpeg=ole.slice(jpegStart,jpegEnd);if(jpeg[0]!==0xff||jpeg[1]!==0xd8)return null;
      const left=Math.min(a.x,b.x),right=Math.max(a.x,b.x),bottom=Math.min(a.y,b.y),top=Math.max(a.y,b.y);
      if(!(right>left&&top>bottom))return null;
      return{left,right,bottom,top,jpeg,oleBytes:ole.length};
    }catch(_){return null;}
  }
  function pointsFromPairsForOle(values,base){const x=Number((values[base]||[])[0]),y=Number((values[base+10]||[])[0]);return finite(x)&&finite(y)?{x,y}:null;}
  function readGeometry(rawBytes, maxSegments = SAFE_SEGMENT_LIMIT) {
    const bytes=rawBytes instanceof Uint8Array?rawBytes:new Uint8Array(rawBytes);
    const main={segments:[],points:[],inserts:[],texts:[],curves:[],construction:[],oleFrames:[]},blocks=new Map();
    let active=main,currentBlock=null,blockHeader=null,section='',needSectionName=false,entity=null,pendingPolyline=null;
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity,totalGeomPoints=0,totalGeomSegments=0,currentCadStyle={layer:'0',color:'#182536',lineWeight:0};
    const styleHeights=new Map();let defaultTextHeight=0,headerVariable='';
    // STYLE fixed heights and $TEXTSIZE are used when a TEXT entity's group 40 is zero.
    let ss='',waitSec=false,tt='',waitTable=false,styleRec=null;
    forEachPair(bytes,p=>{
      const u=p.value.toUpperCase();
      if(p.code===0&&u==='SECTION'){waitSec=true;return;}
      if(waitSec&&p.code===2){ss=u;waitSec=false;return;}
      if(ss==='HEADER'){if(p.code===9)headerVariable=p.value.toUpperCase();else if(p.code===40&&headerVariable==='$TEXTSIZE'){defaultTextHeight=Math.abs(Number(p.value)||0);headerVariable='';}else if(p.code!==0)headerVariable='';}
      if(ss==='TABLES'){
        if(p.code===0&&u==='TABLE'){waitTable=true;return;}
        if(waitTable&&p.code===2){tt=u;waitTable=false;return;}
        if(p.code===0){if(styleRec&&styleRec.name)styleHeights.set(styleRec.name.toUpperCase(),styleRec.height||0);styleRec=tt==='STYLE'&&u==='STYLE'?{name:'',height:0}:null;return;}
        if(styleRec){if(p.code===2)styleRec.name=p.value;else if(p.code===40)styleRec.height=Number(p.value)||0;}
      }
      if(p.code===0&&u==='ENDSEC'){if(styleRec&&styleRec.name)styleHeights.set(styleRec.name.toUpperCase(),styleRec.height||0);styleRec=null;ss='';tt='';}
    });
    const layerColors=new Map();let layerSection='',layerWait=false,layerTable='',layerTableWait=false,layerRow=null;
    forEachPair(bytes,p=>{const u=p.value.toUpperCase();if(p.code===0&&u==='SECTION'){layerWait=true;return;}if(layerWait&&p.code===2){layerSection=u;layerWait=false;return;}if(layerSection!=='TABLES')return;if(p.code===0&&u==='TABLE'){layerTableWait=true;return;}if(layerTableWait&&p.code===2){layerTable=u;layerTableWait=false;return;}if(layerTable!=='LAYER')return;if(p.code===0){if(layerRow?.name)layerColors.set(layerRow.name.toUpperCase(),layerRow);layerRow=u==='LAYER'?{name:'',aci:7,rgb:null}:null;if(u==='ENDTAB')layerTable='';if(u==='ENDSEC')layerSection='';return;}if(layerRow){if(p.code===2)layerRow.name=p.value;else if(p.code===62)layerRow.aci=Math.abs(Number(p.value)||7);else if(p.code===420)layerRow.rgb=Number(p.value);}});
    if(layerRow?.name)layerColors.set(layerRow.name.toUpperCase(),layerRow);
    function addPoint(p){if(!p||!finite(p.x)||!finite(p.y)||totalGeomPoints>=maxSegments)return;totalGeomPoints++;active.points.push({...p,...currentCadStyle});if(active===main){minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);minY=Math.min(minY,p.y);maxY=Math.max(maxY,p.y);}}
    function addSegment(a,b,isCurveSegment=false,styleOverride=null){if(totalGeomSegments>=maxSegments||active.segments.length>=maxSegments||!a||!b||!finite(a.x)||!finite(a.y)||!finite(b.x)||!finite(b.y))return;totalGeomSegments++;active.segments.push({a,b,isCurveSegment,...(styleOverride||currentCadStyle)});if(active===main){minX=Math.min(minX,a.x,b.x);maxX=Math.max(maxX,a.x,b.x);minY=Math.min(minY,a.y,b.y);maxY=Math.max(maxY,a.y,b.y);}}
    function addText(label){if(!label||!label.text||!label.position||!finite(label.position.x)||!finite(label.position.y))return;if(active.texts.length>=12000)return;active.texts.push(label);if(active===main){minX=Math.min(minX,label.position.x);maxX=Math.max(maxX,label.position.x);minY=Math.min(minY,label.position.y);maxY=Math.max(maxY,label.position.y);}}
    function plainCadText(value){return String(value||'').replace(/\\P/gi,' ').replace(/\\~/g,' ').replace(/\\[ACFHQTW][^;]*;/gi,'').replace(/[{}]/g,'').replace(/\\\\/g,'\\').trim();}
    function cadTextColor(values,layerName='0'){let rgb=Number((values[420]||[])[0]),aci=Number((values[62]||[])[0]);if(finite(rgb)&&rgb>=0)return `#${(rgb&0xffffff).toString(16).padStart(6,'0')}`;if(!finite(aci)||aci===0||aci===256){const layer=layerColors.get(String(layerName||'0').toUpperCase());if(layer?.rgb!==null&&finite(layer?.rgb))return `#${(layer.rgb&0xffffff).toString(16).padStart(6,'0')}`;aci=layer?.aci||7;}aci=Math.abs(aci)||7;return ({1:'#d62828',2:'#d4a500',3:'#16833b',4:'#078caa',5:'#2458b5',6:'#ad3297',7:'#182536',8:'#666666',9:'#888888',10:'#d62828',11:'#ff5555',12:'#aa0000',13:'#aa5555',14:'#aa2222',15:'#772222',30:'#ff9900',40:'#ffff00',50:'#aaff00',60:'#00aa00',70:'#00ffaa',80:'#00aaff',90:'#0000ff',100:'#aa00ff',110:'#ff00aa',120:'#aa0055',130:'#ffaaaa',140:'#aaffaa',150:'#aaffff',160:'#aaaaff',170:'#ffaaff'})[aci]||'#182536';}
    function cadEntityStyle(values, layerName='0'){
      const layer=String(layerName||'0'),lw=Number((values[370]||[])[0]);
      return {layer,color:cadTextColor(values,layer),lineWeight:finite(lw)&&lw>0?lw:0};
    }

    function pointsFromPairs(byCode,xCode=10){const xs=byCode.get(xCode)||[],ys=byCode.get(xCode+10)||[],out=[];for(let i=0;i<Math.min(xs.length,ys.length);i++){const x=Number(xs[i]),y=Number(ys[i]);if(finite(x)&&finite(y))out.push({x,y});}return out;}
    function addArc(center,radius,start,sweep,type='arc',sample=true){if(!center||!(radius>0)||!finite(radius)||!finite(start)||!finite(sweep))return;const curve={type,center:{x:center.x,y:center.y},radius,start,sweep,points:[],...currentCadStyle};active.curves.push(curve);if(!sample)return;const n=Math.max(24,Math.min(2880,Math.ceil(Math.abs(sweep)*180/Math.PI/0.25)));let prev=null;for(let i=0;i<=n;i++){const a=start+sweep*i/n,q={x:center.x+radius*Math.cos(a),y:center.y+radius*Math.sin(a)};curve.points.push(q);prev=q;}}
    function addBulge(a,b,bulge){if(!a||!b)return;const c=Math.hypot(b.x-a.x,b.y-a.y);if(c<1e-12)return;if(!finite(bulge)||Math.abs(bulge)<1e-10){addSegment(a,b);return;}const theta=4*Math.atan(bulge),d=c*(1-bulge*bulge)/(4*bulge),mx=(a.x+b.x)/2,my=(a.y+b.y)/2,nx=-(b.y-a.y)/c,ny=(b.x-a.x)/c,center={x:mx+nx*d,y:my+ny*d},r=Math.hypot(a.x-center.x,a.y-center.y),start=Math.atan2(a.y-center.y,a.x-center.x);addArc(center,r,start,theta,'bulge',true);}
    function connectBulged(vertices,closed=false){if(!vertices.length)return;if(vertices.length===1){addPoint(vertices[0]);return;}for(let i=0;i<vertices.length-1;i++)addBulge(vertices[i],vertices[i+1],vertices[i].bulge||0);if(closed)addBulge(vertices[vertices.length-1],vertices[0],vertices[vertices.length-1].bulge||0);}
    function connect(list,closed=false){connectBulged(list.map(p=>({...p,bulge:0})),closed);}
    function finishPolyline(){if(pendingPolyline){const prior=currentCadStyle;currentCadStyle=pendingPolyline.style||prior;connectBulged(pendingPolyline.vertices,pendingPolyline.closed);currentCadStyle=prior;pendingPolyline=null;}}
    function flushEntity(){
      if(!entity)return;const priorCadStyle=currentCadStyle;const type=entity.type.toUpperCase(),values=entity.values,by=new Map();for(const [code,arr] of Object.entries(values))by.set(Number(code),arr);currentCadStyle=cadEntityStyle(values,String((values[8]||[])[0]||'0'));
      if(['TEXT','MTEXT','ATTRIB','ATTDEF','DIMENSION'].includes(type)){
        let p=pointsFromPairs(by,10)[0];const hAlign=Number((values[72]||[])[0]||0),vAlign=Number((values[73]||[])[0]||0);if(type==='TEXT'&&(hAlign!==0||vAlign!==0)){const aligned=pointsFromPairs(by,11)[0];if(aligned)p=aligned;}
        const rawParts=entity.textParts||[],rawText=rawParts.length?rawParts.map(x=>x.value).join(''):(values[1]||[]).join(''),label=plainCadText(rawText),styleName=String((values[7]||[])[0]||'STANDARD').toUpperCase(),fixedStyle=styleHeights.get(styleName)||0,entityHeight=Math.abs(Number((values[40]||[])[0])||0),height=entityHeight>0?entityHeight:(fixedStyle>0?fixedStyle:defaultTextHeight);
        if(p&&label&&type!=='DIMENSION')addText({type,position:p,text:label,height,rotation:Number((values[50]||[])[0]||0),layer:String((values[8]||[])[0]||'0'),color:cadTextColor(values,String((values[8]||[])[0]||'0')),style:styleName,widthFactor:Number((values[41]||[])[0]||1)});
        if(p&&type==='DIMENSION'&&label&&label!=='<>')addText({type:'DIMENSION',position:p,text:label,height,rotation:Number((values[53]||[])[0]||0),layer:String((values[8]||[])[0]||'0'),color:cadTextColor(values,String((values[8]||[])[0]||'0')),style:styleName});
      }
      if(type==='POLYLINE'){finishPolyline();pendingPolyline={vertices:[],closed:((Number((values[70]||[])[0])||0)&1)!==0,style:{...currentCadStyle}};}
      else if(type==='VERTEX'&&pendingPolyline){const pt=pointsFromPairs(by)[0];if(pt)pendingPolyline.vertices.push({...pt,bulge:Number((values[42]||[])[0]||0)});}
      else if(type==='SEQEND'&&pendingPolyline)finishPolyline();
      else{
        if(pendingPolyline)finishPolyline();
        if(type==='LINE'){const a=pointsFromPairs(by,10)[0],b=pointsFromPairs(by,11)[0];if(a&&b)addSegment(a,b);}
        else if(type==='LWPOLYLINE'){const pts=pointsFromPairs(by,10),bulges=values[42]||[],vertices=pts.map((p,i)=>({...p,bulge:Number(bulges[i]||0)}));connectBulged(vertices,(((Number((values[70]||[])[0])||0)&1)!==0));}
        else if(type==='SPLINE'){
          const fit=pointsFromPairs(by,11),ctrl=pointsFromPairs(by,10),degree=Math.max(1,Math.min(10,Number((values[71]||[])[0]||3))),knots=(values[40]||[]).map(Number),weights=(values[41]||[]).map(Number);let sampled=[];
          if(ctrl.length>=degree+1&&knots.length===ctrl.length+degree+1&&knots.every(finite)&&knots.every((v,i)=>i===0||v>=knots[i-1])){
            const n=ctrl.length-1,pdeg=Math.min(degree,n),lo=knots[pdeg],hi=knots[n+1];
            const evalAt=u=>{let span=n;if(u<hi){for(let k=pdeg;k<=n;k++)if(u>=knots[k]&&u<knots[k+1]){span=k;break;}}const d=[];for(let j=0;j<=pdeg;j++){const ix=span-pdeg+j,w=Number(weights[ix])>0?Number(weights[ix]):1;d.push({x:ctrl[ix].x*w,y:ctrl[ix].y*w,w});}for(let r=1;r<=pdeg;r++)for(let j=pdeg;j>=r;j--){const ix=span-pdeg+j,den=knots[ix+pdeg-r+1]-knots[ix],alpha=Math.abs(den)<1e-15?0:(u-knots[ix])/den;d[j]={x:(1-alpha)*d[j-1].x+alpha*d[j].x,y:(1-alpha)*d[j-1].y+alpha*d[j].y,w:(1-alpha)*d[j-1].w+alpha*d[j].w};}const z=d[pdeg];return z.w?{x:z.x/z.w,y:z.y/z.w}:null;};
            const count=Math.min(2048,Math.max(48,ctrl.length*24));for(let i=0;i<=count;i++){const q=evalAt(lo+(hi-lo)*i/count);if(q&&finite(q.x)&&finite(q.y))sampled.push(q);}
          }
          if(sampled.length<2){const src=fit.length>=2?fit:ctrl;if(src.length>=2){const count=Math.min(2048,(src.length-1)*32);for(let i=0;i<=count;i++){const t=i/count,seg=Math.min(src.length-2,Math.floor(t*(src.length-1))),u=t*(src.length-1)-seg,p0=src[Math.max(0,seg-1)],p1=src[seg],p2=src[seg+1],p3=src[Math.min(src.length-1,seg+2)],u2=u*u,u3=u2*u;sampled.push({x:.5*((2*p1.x)+(-p0.x+p2.x)*u+(2*p0.x-5*p1.x+4*p2.x-p3.x)*u2+(-p0.x+3*p1.x-3*p2.x+p3.x)*u3),y:.5*((2*p1.y)+(-p0.y+p2.y)*u+(2*p0.y-5*p1.y+4*p2.y-p3.y)*u2+(-p0.y+3*p1.y-3*p2.y+p3.y)*u3)});}}}
          if(sampled.length>=2){active.curves.push({type:'spline',points:sampled,...currentCadStyle});for(let i=1;i<sampled.length;i++)addSegment(sampled[i-1],sampled[i],true);}else connect(fit.length>=2?fit:ctrl,false);
        }
        else if(type==='CIRCLE'||type==='ARC'){const c=pointsFromPairs(by,10)[0],r=Number((values[40]||[])[0]);if(c&&r>0){let start=type==='ARC'?Number((values[50]||[])[0])*Math.PI/180:0,end=type==='ARC'?Number((values[51]||[])[0])*Math.PI/180:Math.PI*2;if(!finite(start))start=0;if(!finite(end))end=Math.PI*2;while(type==='ARC'&&end<=start)end+=Math.PI*2;addArc(c,r,start,type==='ARC'?end-start:Math.PI*2,type==='ARC'?'arc':'circle',true);}}
        else if(type==='ELLIPSE'){const c=pointsFromPairs(by,10)[0],major=pointsFromPairs(by,11)[0],ratio=Number((values[40]||[])[0]||1),t0=Number((values[41]||[])[0]||0),t1=Number((values[42]||[])[0]||Math.PI*2);if(c&&major&&ratio>0){const minor={x:-major.y*ratio,y:major.x*ratio},n=Math.max(48,Math.min(2048,Math.ceil(Math.abs(t1-t0)*256/Math.PI))),curve={type:'ellipse',points:[],...currentCadStyle};active.curves.push(curve);let prev=null;for(let i=0;i<=n;i++){const t=t0+(t1-t0)*i/n,q={x:c.x+major.x*Math.cos(t)+minor.x*Math.sin(t),y:c.y+major.y*Math.cos(t)+minor.y*Math.sin(t)};curve.points.push(q);prev=q;}}}
        else if(type==='XLINE'||type==='RAY'){const o=pointsFromPairs(by,10)[0],d=pointsFromPairs(by,11)[0];if(o&&d)active.construction.push({type,origin:o,direction:d,...currentCadStyle});}
        else if(['SOLID','TRACE','3DFACE'].includes(type)){const pts=[];for(let code=10;code<=13;code++){const pt=pointsFromPairs(by,code)[0];if(pt)pts.push(pt);}connect(pts,pts.length>2);}
        else if(type==='INSERT'){const at=pointsFromPairs(by,10)[0];if(at){const name=String((values[2]||[])[0]||'').toUpperCase();active.inserts.push({name,layer:String((values[8]||[])[0]||'0'),x:at.x,y:at.y,sx:Number((values[41]||[])[0]??1),sy:Number((values[42]||[])[0]??1),rotation:Number((values[50]||[])[0]||0),style:{...currentCadStyle},cols:Math.max(1,Math.min(50,Number((values[70]||[])[0]||1))),rows:Math.max(1,Math.min(50,Number((values[71]||[])[0]||1))),colSpacing:Number((values[44]||[])[0]||0),rowSpacing:Number((values[45]||[])[0]||0)});}}
        else if(type==='POINT'){const pt=pointsFromPairs(by,10)[0];if(pt)addPoint(pt);}
        else if(type==='OLE2FRAME'){const frame=parseOle2Frame(values);if(frame){active.oleFrames.push({...frame,...currentCadStyle});if(active===main){minX=Math.min(minX,frame.left);maxX=Math.max(maxX,frame.right);minY=Math.min(minY,frame.bottom);maxY=Math.max(maxY,frame.top);}}} 
      }
      entity=null;currentCadStyle=priorCadStyle;
    }
    function finishBlock(){if(!currentBlock&&!blockHeader)return;const meta=blockHeader||currentBlock||{},name=String(meta.name||currentBlock?.name||'').toUpperCase();if(name){const g=currentBlock||{segments:[],points:[],inserts:[],texts:[],curves:[],construction:[],oleFrames:[]};blocks.set(name,{name,baseX:Number(meta.baseX??currentBlock?.baseX)||0,baseY:Number(meta.baseY??currentBlock?.baseY)||0,geometry:g});}blockHeader=null;currentBlock=null;active=main;}
    let pos=0;
    while(pos<bytes.length&&main.segments.length<maxSegments){const cl=readLine(bytes,pos);if(!cl)break;const vl=readLine(bytes,cl.end);if(!vl)break;const code=Number.parseInt(pairText(bytes,cl),10),value=pairText(bytes,vl);
      if(needSectionName&&code===2){section=value.toUpperCase();needSectionName=false;pos=vl.end;continue;}
      if(code===0){flushEntity();const u=value.toUpperCase();if(u==='SECTION'){needSectionName=true;pos=vl.end;continue;}if(u==='ENDSEC'){if(section==='BLOCKS'&&(blockHeader||currentBlock))finishBlock();section='';active=main;pos=vl.end;continue;}
        if(section==='BLOCKS'){if(u==='BLOCK'){if(blockHeader||currentBlock)finishBlock();blockHeader={name:'',baseX:0,baseY:0};currentBlock={segments:[],points:[],inserts:[],texts:[],curves:[],construction:[],oleFrames:[]};active=currentBlock;entity=null;pos=vl.end;continue;}if(u==='ENDBLK'){finishBlock();entity=null;pos=vl.end;continue;}if(blockHeader&&currentBlock){currentBlock.name=blockHeader.name;currentBlock.baseX=blockHeader.baseX;currentBlock.baseY=blockHeader.baseY;blockHeader=null;}if(currentBlock)entity={type:value,values:Object.create(null)};
        }else if(section==='ENTITIES')entity={type:value,values:Object.create(null)};
      }else if(blockHeader&&section==='BLOCKS'){if(code===2)blockHeader.name=value;else if(code===10)blockHeader.baseX=Number(value);else if(code===20)blockHeader.baseY=Number(value);}
      else if(entity&&((code>=10&&code<=18)||(code>=20&&code<=28)||[1,2,3,7,8,39,40,41,42,44,45,50,51,62,70,71,72,73,74,90,210,220,230,310,420].includes(code))){if(!entity.values[code])entity.values[code]=[];entity.values[code].push(value);if(code===1||code===3){if(!entity.textParts)entity.textParts=[];entity.textParts.push({code,value});}}
      pos=vl.end;
    }
    flushEntity();finishPolyline();if(blockHeader||currentBlock)finishBlock();active=main;
    const identity={a:1,b:0,c:0,d:1,tx:0,ty:0};let instanceCount=0;
    function applyAffine(p,m){return{x:m.a*p.x+m.c*p.y+m.tx,y:m.b*p.x+m.d*p.y+m.ty};}
    function compose(m,n){return{a:m.a*n.a+m.c*n.b,b:m.b*n.a+m.d*n.b,c:m.a*n.c+m.c*n.d,d:m.b*n.c+m.d*n.d,tx:m.a*n.tx+m.c*n.ty+m.tx,ty:m.b*n.tx+m.d*n.ty+m.ty};}
    function expandInsert(insert,parent,depth){if(depth>8||instanceCount>20000||main.segments.length>=maxSegments)return;const block=blocks.get(insert.name);if(!block){return;}const sx=finite(insert.sx)&&insert.sx!==0?insert.sx:1,sy=finite(insert.sy)&&insert.sy!==0?insert.sy:1,theta=(finite(insert.rotation)?insert.rotation:0)*Math.PI/180,co=Math.cos(theta),si=Math.sin(theta),a=co*sx,b=si*sx,c=-si*sy,d=co*sy,cols=insert.cols||1,rows=insert.rows||1;
      for(let row=0;row<rows&&instanceCount<=20000;row++)for(let col=0;col<cols&&instanceCount<=20000;col++){instanceCount++;const ox=insert.x+co*sx*insert.colSpacing*col-si*sy*insert.rowSpacing*row,oy=insert.y+si*sx*insert.colSpacing*col+co*sy*insert.rowSpacing*row,child={a,b,c,d,tx:ox-a*block.baseX-c*block.baseY,ty:oy-b*block.baseX-d*block.baseY},world=compose(parent,child);active=main;for(const seg of block.geometry.segments){if(main.segments.length>=maxSegments)break;let st=seg;if(seg.layer==='0'&&insert.layer){const il=layerColors.get(String(insert.layer).toUpperCase());st={...seg,layer:insert.layer,color:il?.rgb!==null&&finite(il?.rgb)?`#${(il.rgb&0xffffff).toString(16).padStart(6,'0')}`:il?.aci?cadTextColor({62:[il.aci]},insert.layer):insert.style?.color||seg.color,lineWeight:insert.style?.lineWeight||seg.lineWeight};}addSegment(applyAffine(seg.a,world),applyAffine(seg.b,world),!!seg.isCurveSegment,st);}for(const cv of(block.geometry.curves||[])){if(Array.isArray(cv.points)&&cv.points.length>1){const pts=cv.points.map(q=>applyAffine(q,world));main.curves.push({type:'block-curve',points:pts,...cv});}}for(const ray of(block.geometry.construction||[])){const o=applyAffine(ray.origin,world),tip=applyAffine({x:ray.origin.x+ray.direction.x,y:ray.origin.y+ray.direction.y},world),dx=tip.x-o.x,dy=tip.y-o.y;if(Math.hypot(dx,dy)>1e-12){main.construction.push({...ray,origin:o,direction:{x:dx,y:dy}});}}for(const frame of(block.geometry.oleFrames||[])){const p1=applyAffine({x:frame.left,y:frame.top},world),p2=applyAffine({x:frame.right,y:frame.bottom},world);main.oleFrames.push({...frame,left:Math.min(p1.x,p2.x),right:Math.max(p1.x,p2.x),bottom:Math.min(p1.y,p2.y),top:Math.max(p1.y,p2.y)});}for(const pt of block.geometry.points){if(main.points.length>=maxSegments)break;addPoint(applyAffine(pt,world));}const viewScale=Math.sqrt(Math.max(1e-12,Math.abs(world.a*world.d-world.b*world.c))),basisX=Math.hypot(world.a,world.b),basisY=Math.hypot(world.c,world.d),orthogonal=Math.abs(world.a*world.c+world.b*world.d)<1e-8*Math.max(1,basisX*basisY),uniform=Math.abs(basisX-basisY)<1e-8*Math.max(1,basisX,basisY);for(const label of(block.geometry.texts||[])){const angle=(Number(label.rotation)||0)*Math.PI/180,vx=world.a*Math.cos(angle)+world.c*Math.sin(angle),vy=world.b*Math.cos(angle)+world.d*Math.sin(angle),effectiveLayer=label.layer==='0'?(insert.layer||label.layer):label.layer,layerStyle=label.layer==='0'&&insert.layer?layerColors.get(String(insert.layer).toUpperCase()):null;addText({...label,position:applyAffine(label.position,world),height:(Number(label.height)||0)*viewScale,rotation:Math.atan2(vy,vx)*180/Math.PI,layer:effectiveLayer,color:layerStyle?.rgb!==null&&finite(layerStyle?.rgb)?`#${(layerStyle.rgb&0xffffff).toString(16).padStart(6,'0')}`:layerStyle?.aci?cadTextColor({62:[layerStyle.aci]},effectiveLayer):label.color});}for(const cv of(block.geometry.curves||[])){if(Array.isArray(cv.points)&&cv.points.length>1){const pts=cv.points.map(q=>applyAffine(q,world));if(cv.center&&uniform&&orthogonal){const rot=Math.atan2(world.b,world.a);main.curves.push({...cv,type:cv.type,center:applyAffine(cv.center,world),radius:cv.radius*basisX,start:cv.start+rot,points:pts});}else main.curves.push({type:'block-curve',points:pts});}}for(const nested of block.geometry.inserts)expandInsert(nested,world,depth+1);}
    }
    for(const ins of main.inserts)expandInsert(ins,identity,0);
    // Recompute bounds from all real drawable geometry, including sampled arcs,
    // ellipses, block text and embedded images. Infinite axes are excluded.
    minX=Infinity;minY=Infinity;maxX=-Infinity;maxY=-Infinity;
    const includeXY=q=>{if(q&&finite(q.x)&&finite(q.y)){minX=Math.min(minX,q.x);maxX=Math.max(maxX,q.x);minY=Math.min(minY,q.y);maxY=Math.max(maxY,q.y);}};
    for(const seg of main.segments){includeXY(seg.a);includeXY(seg.b);}
    for(const point of main.points)includeXY(point);
    for(const label of main.texts)includeXY(label.position);
    for(const curve of main.curves){if(Array.isArray(curve.points))for(const q of curve.points)includeXY(q);if(curve.center&&Number(curve.radius)>0){const r=Number(curve.radius);includeXY({x:curve.center.x-r,y:curve.center.y-r});includeXY({x:curve.center.x+r,y:curve.center.y+r});}}
    for(const frame of main.oleFrames){includeXY({x:frame.left,y:frame.bottom});includeXY({x:frame.right,y:frame.top});}
    // V170: render XLINE/RAY only across the real drawing window. Their
    // synthetic infinite endpoints must never participate in the fit extents,
    // otherwise grid axes make the actual board microscopic.
    if(!finite(minX)||!finite(maxX)||!finite(minY)||!finite(maxY)){
      for(const ray of main.construction)includeXY(ray.origin);
    }
    if(finite(minX)&&finite(maxX)&&finite(minY)&&finite(maxY)){
      if(maxX-minX<1e-6){minX-=50;maxX+=50;}if(maxY-minY<1e-6){minY-=50;maxY+=50;}
      const dxBox=Math.max(maxX-minX,1e-6),dyBox=Math.max(maxY-minY,1e-6);
      const box={minX:minX-dxBox*.04,maxX:maxX+dxBox*.04,minY:minY-dyBox*.04,maxY:maxY+dyBox*.04};
      for(const ray of main.construction){
        const len=Math.hypot(Number(ray.direction?.x),Number(ray.direction?.y));
        if(!finite(len)||len<1e-12||!ray.origin||!finite(ray.origin.x)||!finite(ray.origin.y))continue;
        const dx=ray.direction.x/len,dy=ray.direction.y/len,o=ray.origin;
        let t0=ray.type==='RAY'?0:-Infinity,t1=Infinity,valid=true;
        if(Math.abs(dx)<1e-14){if(o.x<box.minX||o.x>box.maxX)valid=false;}
        else{const a=(box.minX-o.x)/dx,b=(box.maxX-o.x)/dx;t0=Math.max(t0,Math.min(a,b));t1=Math.min(t1,Math.max(a,b));}
        if(Math.abs(dy)<1e-14){if(o.y<box.minY||o.y>box.maxY)valid=false;}
        else{const a=(box.minY-o.y)/dy,b=(box.maxY-o.y)/dy;t0=Math.max(t0,Math.min(a,b));t1=Math.min(t1,Math.max(a,b));}
        if(!valid||!finite(t0)||!finite(t1)||t1<t0)continue;
        const a={x:o.x+dx*t0,y:o.y+dy*t0},b={x:o.x+dx*t1,y:o.y+dy*t1};
        if(Math.hypot(b.x-a.x,b.y-a.y)>1e-9)main.segments.push({a,b,isCurveSegment:false,isConstruction:true,...ray});
      }
    }
    if(!main.segments.length&&!main.points.length&&!main.texts.length&&!main.oleFrames.length)throw new Error('لم أستطع استخراج عناصر هندسية أو صور OLE مضمنة قابلة للمعاينة من اللوحة.');
    if(!finite(minX)||!finite(maxX)){minX=0;maxX=1;minY=0;maxY=1;}if(maxX-minX<1e-9){minX-=.5;maxX+=.5;}if(maxY-minY<1e-9){minY-=.5;maxY+=.5;}
    return{segments:main.segments,points:main.points,texts:main.texts,curves:main.curves,oleFrames:main.oleFrames,minX,minY,maxX,maxY};
  }
  function nearestPoint(geometry, point) {
    let best = null, bestD2 = Infinity;
    for (const s of geometry.segments) {
      const dx = s.b.x - s.a.x, dy = s.b.y - s.a.y, den = dx * dx + dy * dy;
      const t = den ? Math.max(0, Math.min(1, ((point.x - s.a.x) * dx + (point.y - s.a.y) * dy) / den)) : 0;
      const q = { x: s.a.x + t * dx, y: s.a.y + t * dy };
      const d2 = (q.x - point.x) ** 2 + (q.y - point.y) ** 2;
      if (d2 < bestD2) { bestD2 = d2; best = q; }
    }
    if (!best && geometry.points.length) {
      for (const q of geometry.points) { const d2 = (q.x - point.x) ** 2 + (q.y - point.y) ** 2; if (d2 < bestD2) { bestD2 = d2; best = { x: q.x, y: q.y }; } }
    }
    if (!best) throw new Error('لا توجد عناصر مناسبة لالتقاط النقطة.');
    return best;
  }
  function snapPoint(geometry, point, mode='intersection', tolerance=1) {
    const tol=Math.max(1e-12,Number(tolerance)||1),tol2=tol*tol,candidates=[],seen=new Set();let nearest=null,nearestD2=Infinity;const nearSegments=[];
    const add=(x,y,type,d2)=>{if(!finite(x)||!finite(y)||d2>tol2)return;candidates.push({point:{x,y},type,distance:d2});};
    const angleOnArc=(a,c)=>{const full=Math.abs(c.sweep)>=Math.PI*2-1e-8;if(full)return true;let d=(a-c.start)%(Math.PI*2);if(d<0)d+=Math.PI*2;if(c.sweep>=0)return d<=c.sweep+1e-8;let r=(c.start-a)%(Math.PI*2);if(r<0)r+=Math.PI*2;return r<=-c.sweep+1e-8;};
    for(const seg of geometry.segments||[]){
      const dx=seg.b.x-seg.a.x,dy=seg.b.y-seg.a.y,den=dx*dx+dy*dy;
      const t=den?Math.max(0,Math.min(1,((point.x-seg.a.x)*dx+(point.y-seg.a.y)*dy)/den)):0;
      const q={x:seg.a.x+t*dx,y:seg.a.y+t*dy},d2=(q.x-point.x)**2+(q.y-point.y)**2;
      if(d2<nearestD2){nearestD2=d2;nearest={point:q,type:'nearest',distance:d2};}
      if(d2<=tol2*16)nearSegments.push({seg,d2});
      if(mode==='endpoint'||mode==='intersection')for(const ep of[seg.a,seg.b]){const d=(ep.x-point.x)**2+(ep.y-point.y)**2;add(ep.x,ep.y,'endpoint',d);}
      if(mode==='midpoint'||mode==='intersection'){const m={x:(seg.a.x+seg.b.x)/2,y:(seg.a.y+seg.b.y)/2},d=(m.x-point.x)**2+(m.y-point.y)**2;add(m.x,m.y,'midpoint',d);}
    }
    if(mode==='intersection'&&nearSegments.length>1){
      nearSegments.sort((a,b)=>a.d2-b.d2);const list=nearSegments.length>1800?nearSegments.slice(0,1800):nearSegments;
      for(let i=0;i<list.length;i++)for(let j=i+1;j<list.length;j++){
        const a=list[i].seg,b=list[j].seg,rx=a.b.x-a.a.x,ry=a.b.y-a.a.y,sx=b.b.x-b.a.x,sy=b.b.y-b.a.y,den=rx*sy-ry*sx;
        const scale=Math.max(1,Math.hypot(rx,ry)*Math.hypot(sx,sy));if(Math.abs(den)<1e-12*scale)continue;
        const qx=b.a.x-a.a.x,qy=b.a.y-a.a.y,t=(qx*sy-qy*sx)/den,u=(qx*ry-qy*rx)/den;
        if(t>=-1e-9&&t<=1+1e-9&&u>=-1e-9&&u<=1+1e-9){const x=a.a.x+t*rx,y=a.a.y+t*ry,d=(x-point.x)**2+(y-point.y)**2;if(d<=tol2){const k=`${Math.round(x/Math.max(tol,1e-9)*1e7)}:${Math.round(y/Math.max(tol,1e-9)*1e7)}`;if(!seen.has(k)){seen.add(k);add(x,y,'intersection',d);}}}
      }
    }
    if(mode==='intersection'||mode==='nearest'){
      const curves=(geometry.curves||[]).filter(c=>{if(!c||!c.center||!(Number(c.radius)>0)||!['arc','circle','bulge'].includes(c.type))return false;const dx=point.x-c.center.x,dy=point.y-c.center.y,len=Math.hypot(dx,dy);return Math.abs(len-c.radius)<=tol*1.5&&len>1e-15&&angleOnArc(Math.atan2(dy,dx),c);});
      // Snap the cursor to the analytic circular locus, not to a tessellated chord.
      for(const c of curves){const dx=point.x-c.center.x,dy=point.y-c.center.y,len=Math.hypot(dx,dy);if(len<1e-15)continue;const a=Math.atan2(dy,dx);if(!angleOnArc(a,c))continue;const q={x:c.center.x+c.radius*dx/len,y:c.center.y+c.radius*dy/len},d=(q.x-point.x)**2+(q.y-point.y)**2;if(mode==='nearest'&&d<nearestD2){nearestD2=d;nearest={point:q,type:'nearest',distance:d};}else if(mode==='intersection')add(q.x,q.y,'nearest',d);}
      if(mode==='intersection'){
        // Exact finite segment / circular-arc intersections.
        for(const c of curves)for(const item of nearSegments){const seg=item.seg,dx=seg.b.x-seg.a.x,dy=seg.b.y-seg.a.y,fx=seg.a.x-c.center.x,fy=seg.a.y-c.center.y,A=dx*dx+dy*dy;if(A<1e-20)continue;const B=2*(fx*dx+fy*dy),C=fx*fx+fy*fy-c.radius*c.radius,disc=B*B-4*A*C;if(disc<-1e-10)continue;const root=Math.sqrt(Math.max(0,disc));for(const t of[(-B-root)/(2*A),(-B+root)/(2*A)])if(t>=-1e-9&&t<=1+1e-9){const x=seg.a.x+t*dx,y=seg.a.y+t*dy,a=Math.atan2(y-c.center.y,x-c.center.x),d=(x-point.x)**2+(y-point.y)**2;if(angleOnArc(a,c)){const k=`arc:${Math.round(x/Math.max(tol,1e-9)*1e7)}:${Math.round(y/Math.max(tol,1e-9)*1e7)}`;if(!seen.has(k)){seen.add(k);add(x,y,'intersection',d);}}}}
        // Exact circle/arc to circle/arc intersections.
        for(let i=0;i<curves.length;i++)for(let j=i+1;j<curves.length;j++){const a=curves[i],b=curves[j],dx=b.center.x-a.center.x,dy=b.center.y-a.center.y,d=Math.hypot(dx,dy);if(d<1e-12||d>a.radius+b.radius+tol||d<Math.abs(a.radius-b.radius)-tol)continue;const x0=(a.radius*a.radius-b.radius*b.radius+d*d)/(2*d),h2=a.radius*a.radius-x0*x0;if(h2<-tol2)continue;const h=Math.sqrt(Math.max(0,h2)),mx=a.center.x+x0*dx/d,my=a.center.y+x0*dy/d,ox=-dy*h/d,oy=dx*h/d;for(const q of[{x:mx+ox,y:my+oy},{x:mx-ox,y:my-oy}]){const aa=Math.atan2(q.y-a.center.y,q.x-a.center.x),ab=Math.atan2(q.y-b.center.y,q.x-b.center.x),dist=(q.x-point.x)**2+(q.y-point.y)**2;if(angleOnArc(aa,a)&&angleOnArc(ab,b))add(q.x,q.y,'intersection',dist);}}
      }
    }
    if(nearest&&nearestD2<=tol2)candidates.push(nearest);
    for(const p of geometry.points||[]){const d=(p.x-point.x)**2+(p.y-point.y)**2;if(d<=tol2)add(p.x,p.y,'endpoint',d);if(d<nearestD2){nearestD2=d;nearest={point:{x:p.x,y:p.y},type:'nearest',distance:d};}}
    if(nearest&&nearestD2<=tol2)candidates.push(nearest);
    const priority={intersection:0,endpoint:1,midpoint:2,nearest:3};
    const allowed=mode==='nearest'?['nearest']:mode==='endpoint'?['endpoint','nearest']:mode==='midpoint'?['midpoint','nearest']:['intersection','endpoint','midpoint','nearest'];
    const valid=candidates.filter(c=>allowed.includes(c.type));if(!valid.length)return null;valid.sort((a,b)=>(priority[a.type]-priority[b.type])||a.distance-b.distance);
    const best=valid[0],labels={intersection:'تقاطع',endpoint:'نهاية عنصر',midpoint:'منتصف عنصر',nearest:'أقرب نقطة'};return{point:best.point,type:best.type,typeLabel:labels[best.type],distance:Math.sqrt(best.distance)};
  }
  function svgPathToPolylines(d, scale = 8, color = '#000000') {
    const tokens=String(d||'').match(/[A-Za-z]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?/g)||[];
    let i=0,cmd='',x=0,y=0,sx=0,sy=0,lastC=null,lastQ=null,path=[],paths=[];
    const isCmd=t=>/^[A-Za-z]$/.test(t),num=()=>Number(tokens[i++]),push=(px,py)=>{if(finite(px)&&finite(py))path.push({x:px,y:py});};
    const finish=closed=>{if(path.length>1)paths.push({points:path,closed,color});path=[];};
    const angle=(ux,uy,vx,vy)=>{const dot=ux*vx+uy*vy,det=ux*vy-uy*vx;return Math.atan2(det,dot);};
    while(i<tokens.length){if(isCmd(tokens[i]))cmd=tokens[i++];if(!cmd)break;const rel=cmd===cmd.toLowerCase(),upper=cmd.toUpperCase();
      if(upper==='Z'){push(sx,sy);finish(true);x=sx;y=sy;cmd='';lastC=lastQ=null;continue;}
      if(upper==='M'||upper==='L'||upper==='T'){if(i+1>=tokens.length)break;let nx=num(),ny=num();if(rel){nx+=x;ny+=y;}if(upper==='M'){if(path.length)finish(false);sx=nx;sy=ny;push(nx,ny);cmd=rel?'l':'L';}else if(upper==='T'){const qx=lastQ?2*x-lastQ.x:x,qy=lastQ?2*y-lastQ.y:y,ox=x,oy=y;for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*ox+2*u*t*qx+t*t*nx,u*u*oy+2*u*t*qy+t*t*ny);}lastQ={x:qx,y:qy};}else push(nx,ny);x=nx;y=ny;lastC=null;if(upper!=='T')lastQ=null;}
      else if(upper==='H'||upper==='V'){let z=num();if(rel)z+=upper==='H'?x:y;if(upper==='H')x=z;else y=z;push(x,y);lastC=lastQ=null;}
      else if(upper==='C'){if(i+5>=tokens.length)break;let x1=num(),y1=num(),x2=num(),y2=num(),nx=num(),ny=num();if(rel){x1+=x;y1+=y;x2+=x;y2+=y;nx+=x;ny+=y;}const ox=x,oy=y;for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*u*ox+3*u*u*t*x1+3*u*t*t*x2+t*t*t*nx,u*u*u*oy+3*u*u*t*y1+3*u*t*t*y2+t*t*t*ny);}x=nx;y=ny;lastC={x:x2,y:y2};lastQ=null;}
      else if(upper==='S'){if(i+3>=tokens.length)break;const x1=lastC?2*x-lastC.x:x,y1=lastC?2*y-lastC.y:y;let x2=num(),y2=num(),nx=num(),ny=num();if(rel){x2+=x;y2+=y;nx+=x;ny+=y;}const ox=x,oy=y;for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*u*ox+3*u*u*t*x1+3*u*t*t*x2+t*t*t*nx,u*u*u*oy+3*u*u*t*y1+3*u*t*t*y2+t*t*t*ny);}x=nx;y=ny;lastC={x:x2,y:y2};lastQ=null;}
      else if(upper==='Q'){if(i+3>=tokens.length)break;let x1=num(),y1=num(),nx=num(),ny=num();if(rel){x1+=x;y1+=y;nx+=x;ny+=y;}const ox=x,oy=y;for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*ox+2*u*t*x1+t*t*nx,u*u*oy+2*u*t*y1+t*t*ny);}x=nx;y=ny;lastQ={x:x1,y:y1};lastC=null;}
      else if(upper==='A'){
        if(i+6>=tokens.length)break;let rx=Math.abs(num()),ry=Math.abs(num()),phi=num()*Math.PI/180,large=!!num(),sweep=!!num(),nx=num(),ny=num();if(rel){nx+=x;ny+=y;}if(rx<1e-12||ry<1e-12||Math.hypot(nx-x,ny-y)<1e-12){push(nx,ny);x=nx;y=ny;continue;}
        const cp=Math.cos(phi),sp=Math.sin(phi),dx=(x-nx)/2,dy=(y-ny)/2,xp=cp*dx+sp*dy,yp=-sp*dx+cp*dy,lam=xp*xp/(rx*rx)+yp*yp/(ry*ry);if(lam>1){const k=Math.sqrt(lam);rx*=k;ry*=k;}
        const den=rx*rx*yp*yp+ry*ry*xp*xp,numc=Math.max(0,rx*rx*ry*ry-den),sgn=(large===sweep)?-1:1,coef=den?sgn*Math.sqrt(numc/den):0,cxp=coef*(rx*yp/ry),cyp=coef*(-ry*xp/rx),cx=cp*cxp-sp*cyp+(x+nx)/2,cy=sp*cxp+cp*cyp+(y+ny)/2;
        const ux=(xp-cxp)/rx,uy=(yp-cyp)/ry,vx=(-xp-cxp)/rx,vy=(-yp-cyp)/ry,theta=Math.atan2(uy,ux);let delta=angle(ux,uy,vx,vy);if(!sweep&&delta>0)delta-=Math.PI*2;if(sweep&&delta<0)delta+=Math.PI*2;
        const n=Math.max(16,Math.min(2048,Math.ceil(Math.abs(delta)*Math.max(rx,ry)/Math.max(.5,scale/4))));for(let k=1;k<=n;k++){const a=theta+delta*k/n,px=rx*Math.cos(a),py=ry*Math.sin(a);push(cx+cp*px-sp*py,cy+sp*px+cp*py);}x=nx;y=ny;lastC=lastQ=null;
      }else throw new Error('مسار SVG يحتوي أمرًا غير مدعوم: '+cmd);
    }
    if(path.length)finish(false);return paths;
  }
  function svgColorInfo(fill,style=''){
    let value=String(fill||'').trim().toLowerCase();if(!value||value==='none')value=String(style||'').match(/(?:^|;)\s*fill\s*:\s*([^;]+)/i)?.[1]?.trim().toLowerCase()||'';
    if(!value)return{white:false,aci:7,rgb:0};if(value==='none')return{white:true,aci:7,rgb:0xffffff};
    let rgb=null,m=value.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);if(m){let h=m[1];if(h.length===3)h=h.split('').map(c=>c+c).join('');rgb=parseInt(h,16);}else if((m=value.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i)))rgb=(Math.min(255,+m[1])<<16)|(Math.min(255,+m[2])<<8)|Math.min(255,+m[3]);
    if(rgb===null)return{white:/white/.test(value),aci:7,rgb:0};const r=(rgb>>16)&255,g=(rgb>>8)&255,b=rgb&255,white=r>=248&&g>=248&&b>=248;
    const palette=[{aci:1,r:255,g:0,b:0},{aci:2,r:255,g:255,b:0},{aci:3,r:0,g:255,b:0},{aci:4,r:0,g:255,b:255},{aci:5,r:0,g:0,b:255},{aci:6,r:255,g:0,b:255},{aci:7,r:0,g:0,b:0}];let best=palette[0],bd=Infinity;for(const c of palette){const d=(r-c.r)**2+(g-c.g)**2+(b-c.b)**2;if(d<bd){bd=d;best=c;}}return{white,aci:best.aci,rgb};
  }
  function svgPathsToCad(svg,width,height,curveScale=8){
    const xml=String(svg||'');if(!/<svg\b/i.test(xml))throw new Error('لم ينتج محرك التتبع مستند SVG صالحًا.');
    const paths=[],stack=[{tag:'svg',fill:'',stroke:'',opacity:1,fillOpacity:1,strokeOpacity:1}],tagRe=/<\/?([a-zA-Z][\w:-]*)\b([^>]*)>/g;
    const attrsOf=raw=>{const a={};for(const m of raw.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/g))a[m[1].toLowerCase()]=m[2]??m[3]??m[4]??'';return a;};
    const styleOf=style=>{const a={};for(const part of String(style||'').split(';')){const i=part.indexOf(':');if(i>0)a[part.slice(0,i).trim().toLowerCase()]=part.slice(i+1).trim();}return a;};
    const shapePath=(tag,a)=>{const n=k=>Number(a[k]||0);if(tag==='polyline'||tag==='polygon'){const nums=String(a.points||'').trim().split(/[\s,]+/).map(Number);if(nums.length<4||nums.length%2||nums.some(x=>!finite(x)))return'';let d=`M${nums[0]} ${nums[1]}`;for(let i=2;i<nums.length;i+=2)d+=`L${nums[i]} ${nums[i+1]}`;return d+(tag==='polygon'?'Z':'');}if(tag==='line')return`M${n('x1')} ${n('y1')}L${n('x2')} ${n('y2')}`;if(tag==='rect'){const x=n('x'),y=n('y'),w=n('width'),h=n('height');return w>0&&h>0?`M${x} ${y}H${x+w}V${y+h}H${x}Z`:'';}if(tag==='circle'||tag==='ellipse'){const cx=n('cx'),cy=n('cy'),rx=tag==='circle'?n('r'):n('rx'),ry=tag==='circle'?n('r'):n('ry');if(rx<=0||ry<=0)return'';return`M${cx-rx} ${cy}A${rx} ${ry} 0 1 0 ${cx+rx} ${cy}A${rx} ${ry} 0 1 0 ${cx-rx} ${cy}Z`;}return a.d||'';};
    for(const m of xml.matchAll(tagRe)){const closing=m[0].startsWith('</'),tag=m[1].toLowerCase();if(closing){for(let i=stack.length-1;i>0;i--){const hit=stack[i].tag===tag;stack.pop();if(hit)break;}continue;}
      const attrs=attrsOf(m[2]),sty=styleOf(attrs.style),parent=stack[stack.length-1],effective={tag,fill:attrs.fill??sty.fill??parent.fill,stroke:attrs.stroke??sty.stroke??parent.stroke,opacity:Number(attrs.opacity??sty.opacity??parent.opacity??1),fillOpacity:Number(attrs['fill-opacity']??sty['fill-opacity']??parent.fillOpacity??1),strokeOpacity:Number(attrs['stroke-opacity']??sty['stroke-opacity']??parent.strokeOpacity??1)};
      if(['path','polyline','polygon','line','rect','circle','ellipse'].includes(tag)){
        const d=shapePath(tag,attrs),paint=(effective.fill&&effective.fill.toLowerCase()!=='none'&&effective.fillOpacity>0)?effective.fill:(effective.stroke&&effective.stroke.toLowerCase()!=='none'&&effective.strokeOpacity>0?effective.stroke:effective.fill||effective.stroke||'black');
        if(d&&effective.opacity>0){const color=svgColorInfo(paint,'');if(!color.white){for(const p of svgPathToPolylines(d,curveScale,`#${color.rgb.toString(16).padStart(6,'0')}`)){p.aci=color.aci;p.rgb=color.rgb;paths.push(p);}}}
      }
      if(!/\/\s*>$/.test(m[0])&&!['path','polyline','polygon','line','rect','circle','ellipse'].includes(tag))stack.push(effective);
      else if(!/\/\s*>$/.test(m[0])&&['path','polyline','polygon','line','rect','circle','ellipse'].includes(tag))stack.push(effective);
    }
    const isFrame=p=>{const pts=p.points||[];if(!p.closed||pts.length<4||pts.length>1024)return false;const xs=pts.map(q=>q.x),ys=pts.map(q=>q.y),mnx=Math.min(...xs),mxx=Math.max(...xs),mny=Math.min(...ys),mxy=Math.max(...ys),bw=mxx-mnx,bh=mxy-mny;if(bw<width*.82||bh<height*.82||mnx>width*.10||mxx<width*.90||mny>height*.10||mxy<height*.90)return false;const margin=Math.max(1,Math.min(width,height)*.015),edgeCount=pts.filter(q=>Math.min(Math.abs(q.x-mnx),Math.abs(q.x-mxx),Math.abs(q.y-mny),Math.abs(q.y-mxy))<=margin).length;return edgeCount/pts.length>=.88;};
    const content=paths.filter(p=>!isFrame(p));if(!content.length)throw new Error('لم يتم استخراج محتوى اللوحة داخل الصفحة؛ تم اكتشاف إطار الورقة فقط. جرّب دقة PDF أعلى أو نسخة أوضح من الصورة.');
    const vertices=content.reduce((n,p)=>n+(p.points?.length||0),0);if(vertices<4)throw new Error('المحتوى المستخرج غير كافٍ لإنشاء لوحة DXF.');return content;
  }
  const SQ187_R2000_TEMPLATE_B64 = 'ICAwClNFQ1RJT04KICAyCkhFQURFUgogIDkKJEFDQURWRVIKICAxCkFDMTAxNQogIDkKJEFDQURNQUlOVFZFUgogNzAKNgogIDkKJERXR0NPREVQQUdFCiAgMwpBTlNJXzEyNTIKICA5CiRJTlNCQVNFCiAxMAowLjAKIDIwCjAuMAogMzAKMC4wCiAgOQokRVhUTUlOCiAxMAoxZSsyMAogMjAKMWUrMjAKIDMwCjFlKzIwCiAgOQokRVhUTUFYCiAxMAotMWUrMjAKIDIwCi0xZSsyMAogMzAKLTFlKzIwCiAgOQokTElNTUlOCiAxMAowLjAKIDIwCjAuMAogIDkKJExJTU1BWAogMTAKNDIwLjAKIDIwCjI5Ny4wCiAgOQokT1JUSE9NT0RFCiA3MAowCiAgOQokUkVHRU5NT0RFCiA3MAoxCiAgOQokRklMTE1PREUKIDcwCjEKICA5CiRRVEVYVE1PREUKIDcwCjAKICA5CiRNSVJSVEVYVAogNzAKMQogIDkKJExUU0NBTEUKIDQwCjEuMAogIDkKJEFUVE1PREUKIDcwCjEKICA5CiRURVhUU0laRQogNDAKMi41CiAgOQokVFJBQ0VXSUQKIDQwCjEuMAogIDkKJFRFWFRTVFlMRQogIDcKU3RhbmRhcmQKICA5CiRDTEFZRVIKICA4CjAKICA5CiRDRUxUWVBFCiAgNgpCeUxheWVyCiAgOQokQ0VDT0xPUgogNjIKMjU2CiAgOQokQ0VMVFNDQUxFCiA0MAoxLjAKICA5CiRESVNQU0lMSAogNzAKMAogIDkKJERJTVNDQUxFCiA0MAoxLjAKICA5CiRESU1BU1oKIDQwCjIuNQogIDkKJERJTUVYTwogNDAKMC42MjUKICA5CiRESU1ETEkKIDQwCjMuNzUKICA5CiRESU1STkQKIDQwCjAuMAogIDkKJERJTURMRQogNDAKMC4wCiAgOQokRElNRVhFCiA0MAoxLjI1CiAgOQokRElNVFAKIDQwCjAuMAogIDkKJERJTVRNCiA0MAowLjAKICA5CiRESU1UWFQKIDQwCjIuNQogIDkKJERJTUNFTgogNDAKMi41CiAgOQokRElNVFNaCiA0MAowLjAKICA5CiRESU1UT0wKIDcwCjAKICA5CiRESU1MSU0KIDcwCjAKICA5CiRESU1USUgKIDcwCjAKICA5CiRESU1UT0gKIDcwCjAKICA5CiRESU1TRTEKIDcwCjAKICA5CiRESU1TRTIKIDcwCjAKICA5CiRESU1UQUQKIDcwCjEKICA5CiRESU1aSU4KIDcwCjgKICA5CiRESU1CTEsKICAxCgogIDkKJERJTUFTTwogNzAKMQogIDkKJERJTVNITwogNzAKMQogIDkKJERJTVBPU1QKICAxCgogIDkKJERJTUFQT1NUCiAgMQoKICA5CiRESU1BTFQKIDcwCjAKICA5CiRESU1BTFRECiA3MAozCiAgOQokRElNQUxURgogNDAKMC4wMzkzNzAwNzg3NAogIDkKJERJTUxGQUMKIDQwCjEuMAogIDkKJERJTVRPRkwKIDcwCjEKICA5CiRESU1UVlAKIDQwCjAuMAogIDkKJERJTVRJWAogNzAKMAogIDkKJERJTVNPWEQKIDcwCjAKICA5CiRESU1TQUgKIDcwCjAKICA5CiRESU1CTEsxCiAgMQoKICA5CiRESU1CTEsyCiAgMQoKICA5CiRESU1TVFlMRQogIDIKSVNPLTI1CiAgOQokRElNQ0xSRAogNzAKMAogIDkKJERJTUNMUkUKIDcwCjAKICA5CiRESU1DTFJUCiA3MAowCiAgOQokRElNVEZBQwogNDAKMS4wCiAgOQokRElNR0FQCiA0MAowLjYyNQogIDkKJERJTUpVU1QKIDcwCjAKICA5CiRESU1TRDEKIDcwCjAKICA5CiRESU1TRDIKIDcwCjAKICA5CiRESU1UT0xKCiA3MAowCiAgOQokRElNVFpJTgogNzAKOAogIDkKJERJTUFMVFoKIDcwCjAKICA5CiRESU1BTFRUWgogNzAKMAogIDkKJERJTVVQVAogNzAKMAogIDkKJERJTURFQwogNzAKMgogIDkKJERJTVRERUMKIDcwCjIKICA5CiRESU1BTFRVCiA3MAoyCiAgOQokRElNQUxUVEQKIDcwCjMKICA5CiRESU1UWFNUWQogIDcKU3RhbmRhcmQKICA5CiRESU1BVU5JVAogNzAKMAogIDkKJERJTUFERUMKIDcwCjAKICA5CiRESU1BTFRSTkQKIDQwCjAuMAogIDkKJERJTUFaSU4KIDcwCjAKICA5CiRESU1EU0VQCiA3MAo0NAogIDkKJERJTUFURklUCiA3MAozCiAgOQokRElNRlJBQwogNzAKMAogIDkKJERJTUxEUkJMSwogIDEKCiAgOQokRElNTFVOSVQKIDcwCjIKICA5CiRESU1MV0QKIDcwCi0yCiAgOQokRElNTFdFCiA3MAotMgogIDkKJERJTVRNT1ZFCiA3MAowCiAgOQokTFVOSVRTCiA3MAoyCiAgOQokTFVQUkVDCiA3MAo0CiAgOQokU0tFVENISU5DCiA0MAoxLjAKICA5CiRGSUxMRVRSQUQKIDQwCjEwLjAKICA5CiRBVU5JVFMKIDcwCjAKICA5CiRBVVBSRUMKIDcwCjIKICA5CiRNRU5VCiAgMQouCiAgOQokRUxFVkFUSU9OCiA0MAowLjAKICA5CiRQRUxFVkFUSU9OCiA0MAowLjAKICA5CiRUSElDS05FU1MKIDQwCjAuMAogIDkKJExJTUNIRUNLCiA3MAowCiAgOQokQ0hBTUZFUkEKIDQwCjAuMAogIDkKJENIQU1GRVJCCiA0MAowLjAKICA5CiRDSEFNRkVSQwogNDAKMC4wCiAgOQokQ0hBTUZFUkQKIDQwCjAuMAogIDkKJFNLUE9MWQogNzAKMAogIDkKJFREQ1JFQVRFCiA0MAoyNDYxMzQ5LjM5NDA3NDA3NAogIDkKJFREVUNSRUFURQogNDAKMjQ1ODUzMi4xNTM5OTY4OTgKICA5CiRURFVQREFURQogNDAKMjQ2MTM0OS4zOTQwNzQwNzQKICA5CiRURFVVUERBVEUKIDQwCjI0NTg1MzIuMTU0NDMxMQogIDkKJFRESU5EV0cKIDQwCjAuMAogIDkKJFREVVNSVElNRVIKIDQwCjAuMAogIDkKJFVTUlRJTUVSCiA3MAoxCiAgOQokQU5HQkFTRQogNTAKMC4wCiAgOQokQU5HRElSCiA3MAowCiAgOQokUERNT0RFCiA3MAowCiAgOQokUERTSVpFCiA0MAowLjAKICA5CiRQTElORVdJRAogNDAKMC4wCiAgOQokU1BMRlJBTUUKIDcwCjAKICA5CiRTUExJTkVUWVBFCiA3MAo2CiAgOQokU1BMSU5FU0VHUwogNzAKOAogIDkKJEhBTkRTRUVECiAgNQozMgogIDkKJFNVUkZUQUIxCiA3MAo2CiAgOQokU1VSRlRBQjIKIDcwCjYKICA5CiRTVVJGVFlQRQogNzAKNgogIDkKJFNVUkZVCiA3MAo2CiAgOQokU1VSRlYKIDcwCjYKICA5CiRVQ1NCQVNFCiAgMgoKICA5CiRVQ1NOQU1FCiAgMgoKICA5CiRVQ1NPUkcKIDEwCjAuMAogMjAKMC4wCiAzMAowLjAKICA5CiRVQ1NYRElSCiAxMAoxLjAKIDIwCjAuMAogMzAKMC4wCiAgOQokVUNTWURJUgogMTAKMC4wCiAyMAoxLjAKIDMwCjAuMAogIDkKJFVDU09SVEhPUkVGCiAgMgoKICA5CiRVQ1NPUlRIT1ZJRVcKIDcwCjAKICA5CiRVQ1NPUkdUT1AKIDEwCjAuMAogMjAKMC4wCiAzMAowLjAKICA5CiRVQ1NPUkdCT1RUT00KIDEwCjAuMAogMjAKMC4wCiAzMAowLjAKICA5CiRVQ1NPUkdMRUZUCiAxMAowLjAKIDIwCjAuMAogMzAKMC4wCiAgOQokVUNTT1JHUklHSFQKIDEwCjAuMAogMjAKMC4wCiAzMAowLjAKICA5CiRVQ1NPUkdGUk9OVAogMTAKMC4wCiAyMAowLjAKIDMwCjAuMAogIDkKJFVDU09SR0JBQ0sKIDEwCjAuMAogMjAKMC4wCiAzMAowLjAKICA5CiRQVUNTQkFTRQogIDIKCiAgOQokUFVDU05BTUUKICAyCgogIDkKJFBVQ1NPUkcKIDEwCjAuMAogMjAKMC4wCiAzMAowLjAKICA5CiRQVUNTWERJUgogMTAKMS4wCiAyMAowLjAKIDMwCjAuMAogIDkKJFBVQ1NZRElSCiAxMAowLjAKIDIwCjEuMAogMzAKMC4wCiAgOQokUFVDU09SVEhPUkVGCiAgMgoKICA5CiRQVUNTT1JUSE9WSUVXCiA3MAowCiAgOQokUFVDU09SR1RPUAogMTAKMC4wCiAyMAowLjAKIDMwCjAuMAogIDkKJFBVQ1NPUkdCT1RUT00KIDEwCjAuMAogMjAKMC4wCiAzMAowLjAKICA5CiRQVUNTT1JHTEVGVAogMTAKMC4wCiAyMAowLjAKIDMwCjAuMAogIDkKJFBVQ1NPUkdSSUdIVAogMTAKMC4wCiAyMAowLjAKIDMwCjAuMAogIDkKJFBVQ1NPUkdGUk9OVAogMTAKMC4wCiAyMAowLjAKIDMwCjAuMAogIDkKJFBVQ1NPUkdCQUNLCiAxMAowLjAKIDIwCjAuMAogMzAKMC4wCiAgOQokVVNFUkkxCiA3MAowCiAgOQokVVNFUkkyCiA3MAowCiAgOQokVVNFUkkzCiA3MAowCiAgOQokVVNFUkk0CiA3MAowCiAgOQokVVNFUkk1CiA3MAowCiAgOQokVVNFUlIxCiA0MAowLjAKICA5CiRVU0VSUjIKIDQwCjAuMAogIDkKJFVTRVJSMwogNDAKMC4wCiAgOQokVVNFUlI0CiA0MAowLjAKICA5CiRVU0VSUjUKIDQwCjAuMAogIDkKJFdPUkxEVklFVwogNzAKMQogIDkKJFNIQURFREdFCiA3MAozCiAgOQokU0hBREVESUYKIDcwCjcwCiAgOQokVElMRU1PREUKIDcwCjEKICA5CiRNQVhBQ1RWUAogNzAKNjQKICA5CiRQSU5TQkFTRQogMTAKMC4wCiAyMAowLjAKIDMwCjAuMAogIDkKJFBMSU1DSEVDSwogNzAKMAogIDkKJFBFWFRNSU4KIDEwCjFlKzIwCiAyMAoxZSsyMAogMzAKMWUrMjAKICA5CiRQRVhUTUFYCiAxMAotMWUrMjAKIDIwCi0xZSsyMAogMzAKLTFlKzIwCiAgOQokUExJTU1JTgogMTAKMC4wCiAyMAowLjAKICA5CiRQTElNTUFYCiAxMAo0MjAuMAogMjAKMjk3LjAKICA5CiRVTklUTU9ERQogNzAKMAogIDkKJFZJU1JFVEFJTgogNzAKMQogIDkKJFBMSU5FR0VOCiA3MAowCiAgOQokUFNMVFNDQUxFCiA3MAoxCiAgOQokVFJFRURFUFRICiA3MAozMDIwCiAgOQokQ01MU1RZTEUKICAyClN0YW5kYXJkCiAgOQokQ01MSlVTVAogNzAKMAogIDkKJENNTFNDQUxFCiA0MAoyMC4wCiAgOQokUFJPWFlHUkFQSElDUwogNzAKMQogIDkKJE1FQVNVUkVNRU5UCiA3MAoxCiAgOQokQ0VMV0VJR0hUCjM3MAotMQogIDkKJEVORENBUFMKMjgwCjAKICA5CiRKT0lOU1RZTEUKMjgwCjAKICA5CiRMV0RJU1BMQVkKMjkwCjAKICA5CiRJTlNVTklUUwogNzAKNgogIDkKJEhZUEVSTElOS0JBU0UKICAxCgogIDkKJFNUWUxFU0hFRVQKICAxCgogIDkKJFhFRElUCjI5MAoxCiAgOQokQ0VQU05UWVBFCjM4MAowCiAgOQokUFNUWUxFTU9ERQoyOTAKMQogIDkKJEZJTkdFUlBSSU5UR1VJRAogIDIKe0YzREMzMTczLUExN0UtNEM0RS05QzMwLTMyQjcxQTZDRTQ0Q30KICA5CiRWRVJTSU9OR1VJRAogIDIKezQ2Q0NDQUIxLTkwNDMtNDlCMS04MkVELTQ4NkVDMDBDQTZENX0KICA5CiRFWFROQU1FUwoyOTAKMQogIDkKJFBTVlBTQ0FMRQogNDAKMC4wCiAgOQokT0xFU1RBUlRVUAoyOTAKMAogIDAKRU5EU0VDCiAgMApTRUNUSU9OCiAgMgpDTEFTU0VTCiAgMApDTEFTUwogIDEKQUNEQkRJQ1RJT05BUllXREZMVAogIDIKQWNEYkRpY3Rpb25hcnlXaXRoRGVmYXVsdAogIDMKT2JqZWN0REJYIENsYXNzZXMKIDkwCjAKMjgwCjAKMjgxCjAKICAwCkNMQVNTCiAgMQpTVU4KICAyCkFjRGJTdW4KICAzClNDRU5FT0UKIDkwCjExNTMKMjgwCjAKMjgxCjAKICAwCkNMQVNTCiAgMQpWSVNVQUxTVFlMRQogIDIKQWNEYlZpc3VhbFN0eWxlCiAgMwpPYmplY3REQlggQ2xhc3NlcwogOTAKNDA5NQoyODAKMAoyODEKMAogIDAKQ0xBU1MKICAxCk1BVEVSSUFMCiAgMgpBY0RiTWF0ZXJpYWwKICAzCk9iamVjdERCWCBDbGFzc2VzCiA5MAoxMTUzCjI4MAowCjI4MQowCiAgMApDTEFTUwogIDEKU0NBTEUKICAyCkFjRGJTY2FsZQogIDMKT2JqZWN0REJYIENsYXNzZXMKIDkwCjExNTMKMjgwCjAKMjgxCjAKICAwCkNMQVNTCiAgMQpUQUJMRVNUWUxFCiAgMgpBY0RiVGFibGVTdHlsZQogIDMKT2JqZWN0REJYIENsYXNzZXMKIDkwCjQwOTUKMjgwCjAKMjgxCjAKICAwCkNMQVNTCiAgMQpNTEVBREVSU1RZTEUKICAyCkFjRGJNTGVhZGVyU3R5bGUKICAzCkFDREJfTUxFQURFUlNUWUxFX0NMQVNTCiA5MAo0MDk1CjI4MAowCjI4MQowCiAgMApDTEFTUwogIDEKRElDVElPTkFSWVZBUgogIDIKQWNEYkRpY3Rpb25hcnlWYXIKICAzCk9iamVjdERCWCBDbGFzc2VzCiA5MAowCjI4MAowCjI4MQowCiAgMApDTEFTUwogIDEKQ0VMTFNUWUxFTUFQCiAgMgpBY0RiQ2VsbFN0eWxlTWFwCiAgMwpPYmplY3REQlggQ2xhc3NlcwogOTAKMTE1MgoyODAKMAoyODEKMAogIDAKQ0xBU1MKICAxCk1FTlRBTFJBWVJFTkRFUlNFVFRJTkdTCiAgMgpBY0RiTWVudGFsUmF5UmVuZGVyU2V0dGluZ3MKICAzClNDRU5FT0UKIDkwCjEwMjQKMjgwCjAKMjgxCjAKICAwCkNMQVNTCiAgMQpBQ0RCREVUQUlMVklFV1NUWUxFCiAgMgpBY0RiRGV0YWlsVmlld1N0eWxlCiAgMwpPYmplY3REQlggQ2xhc3NlcwogOTAKMTAyNQoyODAKMAoyODEKMAogIDAKQ0xBU1MKICAxCkFDREJTRUNUSU9OVklFV1NUWUxFCiAgMgpBY0RiU2VjdGlvblZpZXdTdHlsZQogIDMKT2JqZWN0REJYIENsYXNzZXMKIDkwCjEwMjUKMjgwCjAKMjgxCjAKICAwCkNMQVNTCiAgMQpSQVNURVJWQVJJQUJMRVMKICAyCkFjRGJSYXN0ZXJWYXJpYWJsZXMKICAzCklTTQogOTAKMAoyODAKMAoyODEKMAogIDAKQ0xBU1MKICAxCkFDREJQTEFDRUhPTERFUgogIDIKQWNEYlBsYWNlSG9sZGVyCiAgMwpPYmplY3REQlggQ2xhc3NlcwogOTAKMAoyODAKMAoyODEKMAogIDAKQ0xBU1MKICAxCkxBWU9VVAogIDIKQWNEYkxheW91dAogIDMKT2JqZWN0REJYIENsYXNzZXMKIDkwCjAKMjgwCjAKMjgxCjAKICAwCkVORFNFQwogIDAKU0VDVElPTgogIDIKVEFCTEVTCiAgMApUQUJMRQogIDIKVlBPUlQKICA1CjgKMzMwCjAKMTAwCkFjRGJTeW1ib2xUYWJsZQogNzAKMQogIDAKVlBPUlQKICA1CjIzCjMzMAo4CjEwMApBY0RiU3ltYm9sVGFibGVSZWNvcmQKMTAwCkFjRGJWaWV3cG9ydFRhYmxlUmVjb3JkCiAgMgoqQWN0aXZlCiA3MAowCiAxMAowLjAKIDIwCjAuMAogMTEKMS4wCiAyMQoxLjAKIDEyCjAuMAogMjIKMC4wCiAxMwowLjAKIDIzCjAuMAogMTQKMC41CiAyNAowLjUKIDE1CjAuNQogMjUKMC41CiAxNgowLjAKIDI2CjAuMAogMzYKMS4wCiAxNwowLjAKIDI3CjAuMAogMzcKMC4wCiA0MAoxMDAwLjAKIDQxCjEuMzQKIDQyCjUwLjAKIDQzCjAuMAogNDQKMC4wCiA1MAowLjAKIDUxCjAuMAogNzEKMAogNzIKMTAwMAogNzMKMQogNzQKMwogNzUKMAogNzYKMAogNzcKMAogNzgKMAoyODEKMAogNjUKMAoxNDYKMC4wCiAgMApFTkRUQUIKICAwClRBQkxFCiAgMgpMVFlQRQogIDUKMgozMzAKMAoxMDAKQWNEYlN5bWJvbFRhYmxlCiA3MAozCiAgMApMVFlQRQogIDUKMjQKMzMwCjIKMTAwCkFjRGJTeW1ib2xUYWJsZVJlY29yZAoxMDAKQWNEYkxpbmV0eXBlVGFibGVSZWNvcmQKICAyCkJ5QmxvY2sKIDcwCjAKICAzCgogNzIKNjUKIDczCjAKIDQwCjAuMAogIDAKTFRZUEUKICA1CjI1CjMzMAoyCjEwMApBY0RiU3ltYm9sVGFibGVSZWNvcmQKMTAwCkFjRGJMaW5ldHlwZVRhYmxlUmVjb3JkCiAgMgpCeUxheWVyCiA3MAowCiAgMwoKIDcyCjY1CiA3MwowCiA0MAowLjAKICAwCkxUWVBFCiAgNQoyNgozMzAKMgoxMDAKQWNEYlN5bWJvbFRhYmxlUmVjb3JkCjEwMApBY0RiTGluZXR5cGVUYWJsZVJlY29yZAogIDIKQ29udGludW91cwogNzAKMAogIDMKCiA3Mgo2NQogNzMKMAogNDAKMC4wCiAgMApFTkRUQUIKICAwClRBQkxFCiAgMgpMQVlFUgogIDUKMQozMzAKMAoxMDAKQWNEYlN5bWJvbFRhYmxlCiA3MAoyCiAgMApMQVlFUgogIDUKMjcKMzMwCjEKMTAwCkFjRGJTeW1ib2xUYWJsZVJlY29yZAoxMDAKQWNEYkxheWVyVGFibGVSZWNvcmQKICAyCjAKIDcwCjAKIDYyCjcKICA2CkNvbnRpbnVvdXMKMzcwCi0zCjM5MAoxMwogIDAKTEFZRVIKICA1CjI4CjMzMAoxCjEwMApBY0RiU3ltYm9sVGFibGVSZWNvcmQKMTAwCkFjRGJMYXllclRhYmxlUmVjb3JkCiAgMgpEZWZwb2ludHMKIDcwCjAKIDYyCjcKICA2CkNvbnRpbnVvdXMKMjkwCjAKMzcwCi0zCjM5MAoxMwogIDAKRU5EVEFCCiAgMApUQUJMRQogIDIKU1RZTEUKICA1CjUKMzMwCjAKMTAwCkFjRGJTeW1ib2xUYWJsZQogNzAKMQogIDAKU1RZTEUKICA1CjI5CjMzMAo1CjEwMApBY0RiU3ltYm9sVGFibGVSZWNvcmQKMTAwCkFjRGJUZXh0U3R5bGVUYWJsZVJlY29yZAogIDIKU3RhbmRhcmQKIDcwCjAKIDQwCjAuMAogNDEKMS4wCiA1MAowLjAKIDcxCjAKIDQyCjIuNQogIDMKdHh0CiAgNAoKICAwCkVORFRBQgogIDAKVEFCTEUKICAyClZJRVcKICA1CjcKMzMwCjAKMTAwCkFjRGJTeW1ib2xUYWJsZQogNzAKMAogIDAKRU5EVEFCCiAgMApUQUJMRQogIDIKVUNTCiAgNQo2CjMzMAowCjEwMApBY0RiU3ltYm9sVGFibGUKIDcwCjAKICAwCkVORFRBQgogIDAKVEFCTEUKICAyCkFQUElECiAgNQozCjMzMAowCjEwMApBY0RiU3ltYm9sVGFibGUKIDcwCjMKICAwCkFQUElECiAgNQoyQQozMzAKMwoxMDAKQWNEYlN5bWJvbFRhYmxlUmVjb3JkCjEwMApBY0RiUmVnQXBwVGFibGVSZWNvcmQKICAyCkFDQUQKIDcwCjAKICAwCkFQUElECiAgNQoyRgozMzAKMwoxMDAKQWNEYlN5bWJvbFRhYmxlUmVjb3JkCjEwMApBY0RiUmVnQXBwVGFibGVSZWNvcmQKICAyCkhBVENIQkFDS0dST1VORENPTE9SCiA3MAowCiAgMApBUFBJRAogIDUKMzAKMzMwCjMKMTAwCkFjRGJTeW1ib2xUYWJsZVJlY29yZAoxMDAKQWNEYlJlZ0FwcFRhYmxlUmVjb3JkCiAgMgpFWkRYRgogNzAKMAogIDAKRU5EVEFCCiAgMApUQUJMRQogIDIKRElNU1RZTEUKICA1CjQKMzMwCjAKMTAwCkFjRGJTeW1ib2xUYWJsZQogNzAKMQoxMDAKQWNEYkRpbVN0eWxlVGFibGUKICAwCkRJTVNUWUxFCjEwNQoyQgozMzAKNAoxMDAKQWNEYlN5bWJvbFRhYmxlUmVjb3JkCjEwMApBY0RiRGltU3R5bGVUYWJsZVJlY29yZAogIDIKU3RhbmRhcmQKIDcwCjAKICAzCgogIDQKCiA0MAoxLjAKIDQxCjIuNQogNDIKMC42MjUKIDQzCjMuNzUKIDQ0CjEuMjUKIDQ1CjAuMAogNDYKMC4wCiA0NwowLjAKIDQ4CjAuMAoxNDAKMi41CjE0MQoyLjUKMTQyCjAuMAoxNDMKMC4wMzkzNzAwNzg3NAoxNDQKMS4wCjE0NQowLjAKMTQ2CjEuMAoxNDcKMC42MjUKMTQ4CjAuMAogNzEKMAogNzIKMAogNzMKMAogNzQKMAogNzUKMAogNzYKMAogNzcKMQogNzgKOAogNzkKMwoxNzAKMAoxNzEKMwoxNzIKMQoxNzMKMAoxNzQKMAoxNzUKMAoxNzYKMAoxNzcKMAoxNzgKMAoxNzkKMgoyNzEKMgoyNzIKMgoyNzMKMgoyNzQKMwoyNzUKMAoyNzYKMAoyNzcKMgoyNzgKNDQKMjc5CjAKMjgwCjAKMjgxCjAKMjgyCjAKMjgzCjAKMjg0CjgKMjg1CjAKMjg2CjAKMjg4CjAKMjg5CjMKMzcxCi0yCjM3MgotMgogIDAKRU5EVEFCCiAgMApUQUJMRQogIDIKQkxPQ0tfUkVDT1JECiAgNQo5CjMzMAowCjEwMApBY0RiU3ltYm9sVGFibGUKIDcwCjIKICAwCkJMT0NLX1JFQ09SRAogIDUKMTcKMzMwCjkKMTAwCkFjRGJTeW1ib2xUYWJsZVJlY29yZAoxMDAKQWNEYkJsb2NrVGFibGVSZWNvcmQKICAyCipNb2RlbF9TcGFjZQozNDAKMUEKICAwCkJMT0NLX1JFQ09SRAogIDUKMUIKMzMwCjkKMTAwCkFjRGJTeW1ib2xUYWJsZVJlY29yZAoxMDAKQWNEYkJsb2NrVGFibGVSZWNvcmQKICAyCipQYXBlcl9TcGFjZQozNDAKMUUKICAwCkVORFRBQgogIDAKRU5EU0VDCiAgMApTRUNUSU9OCiAgMgpCTE9DS1MKICAwCkJMT0NLCiAgNQoxOAozMzAKMTcKMTAwCkFjRGJFbnRpdHkKICA4CjAKMTAwCkFjRGJCbG9ja0JlZ2luCiAgMgoqTW9kZWxfU3BhY2UKIDcwCjAKIDEwCjAuMAogMjAKMC4wCiAzMAowLjAKICAzCipNb2RlbF9TcGFjZQogIDEKCiAgMApFTkRCTEsKICA1CjE5CjMzMAoxNwoxMDAKQWNEYkVudGl0eQogIDgKMAoxMDAKQWNEYkJsb2NrRW5kCiAgMApCTE9DSwogIDUKMUMKMzMwCjFCCjEwMApBY0RiRW50aXR5CiAgOAowCjEwMApBY0RiQmxvY2tCZWdpbgogIDIKKlBhcGVyX1NwYWNlCiA3MAowCiAxMAowLjAKIDIwCjAuMAogMzAKMC4wCiAgMwoqUGFwZXJfU3BhY2UKICAxCgogIDAKRU5EQkxLCiAgNQoxRAozMzAKMUIKMTAwCkFjRGJFbnRpdHkKICA4CjAKMTAwCkFjRGJCbG9ja0VuZAogIDAKRU5EU0VDCiAgMApTRUNUSU9OCiAgMgpFTlRJVElFUwogIDAKRU5EU0VDCiAgMApTRUNUSU9OCiAgMgpPQkpFQ1RTCiAgMApESUNUSU9OQVJZCiAgNQpBCjMzMAowCjEwMApBY0RiRGljdGlvbmFyeQoyODEKMQogIDMKQUNBRF9DT0xPUgozNTAKQgogIDMKQUNBRF9HUk9VUAozNTAKQwogIDMKQUNBRF9MQVlPVVQKMzUwCkQKICAzCkFDQURfTUFURVJJQUwKMzUwCkUKICAzCkFDQURfTUxFQURFUlNUWUxFCjM1MApGCiAgMwpBQ0FEX01MSU5FU1RZTEUKMzUwCjEwCiAgMwpBQ0FEX1BMT1RTRVRUSU5HUwozNTAKMTEKICAzCkFDQURfUExPVFNUWUxFTkFNRQozNTAKMTIKICAzCkFDQURfU0NBTEVMSVNUCjM1MAoxNAogIDMKQUNBRF9UQUJMRVNUWUxFCjM1MAoxNQogIDMKQUNBRF9WSVNVQUxTVFlMRQozNTAKMTYKICAzCkVaRFhGX01FVEEKMzUwCjJECiAgMApESUNUSU9OQVJZCiAgNQpCCjMzMApBCjEwMApBY0RiRGljdGlvbmFyeQoyODEKMQogIDAKRElDVElPTkFSWQogIDUKQwozMzAKQQoxMDAKQWNEYkRpY3Rpb25hcnkKMjgxCjEKICAwCkRJQ1RJT05BUlkKICA1CkQKMzMwCkEKMTAwCkFjRGJEaWN0aW9uYXJ5CjI4MQoxCiAgMwpNb2RlbAozNTAKMUEKICAzCkxheW91dDEKMzUwCjFFCiAgMApESUNUSU9OQVJZCiAgNQpFCjMzMApBCjEwMApBY0RiRGljdGlvbmFyeQoyODEKMQogIDMKQnlCbG9jawozNTAKMUYKICAzCkJ5TGF5ZXIKMzUwCjIwCiAgMwpHbG9iYWwKMzUwCjIxCiAgMApESUNUSU9OQVJZCiAgNQpGCjMzMApBCjEwMApBY0RiRGljdGlvbmFyeQoyODEKMQogIDMKU3RhbmRhcmQKMzUwCjJDCiAgMApESUNUSU9OQVJZCiAgNQoxMAozMzAKQQoxMDAKQWNEYkRpY3Rpb25hcnkKMjgxCjEKICAzClN0YW5kYXJkCjM1MAoyMgogIDAKRElDVElPTkFSWQogIDUKMTEKMzMwCkEKMTAwCkFjRGJEaWN0aW9uYXJ5CjI4MQoxCiAgMApBQ0RCRElDVElPTkFSWVdERkxUCiAgNQoxMgozMzAKQQoxMDAKQWNEYkRpY3Rpb25hcnkKMjgxCjEKICAzCk5vcm1hbAozNTAKMTMKMTAwCkFjRGJEaWN0aW9uYXJ5V2l0aERlZmF1bHQKMzQwCjEzCiAgMApBQ0RCUExBQ0VIT0xERVIKICA1CjEzCjMzMAoxMgogIDAKRElDVElPTkFSWQogIDUKMTQKMzMwCkEKMTAwCkFjRGJEaWN0aW9uYXJ5CjI4MQoxCiAgMApESUNUSU9OQVJZCiAgNQoxNQozMzAKQQoxMDAKQWNEYkRpY3Rpb25hcnkKMjgxCjEKICAwCkRJQ1RJT05BUlkKICA1CjE2CjMzMApBCjEwMApBY0RiRGljdGlvbmFyeQoyODEKMQogIDAKTEFZT1VUCiAgNQoxQQozMzAKRAoxMDAKQWNEYlBsb3RTZXR0aW5ncwogIDEKCiAgNApBMwogIDYKCiA0MAo3LjUKIDQxCjIwLjAKIDQyCjcuNQogNDMKMjAuMAogNDQKNDIwLjAKIDQ1CjI5Ny4wCiA0NgowLjAKIDQ3CjAuMAogNDgKMC4wCiA0OQowLjAKMTQwCjAuMAoxNDEKMC4wCjE0MgoxLjAKMTQzCjEuMAogNzAKMTAyNAogNzIKMQogNzMKMAogNzQKNQogIDcKCiA3NQoxNgogNzYKMAogNzcKMgogNzgKMzAwCjE0NwoxLjAKMTQ4CjAuMAoxNDkKMC4wCjEwMApBY0RiTGF5b3V0CiAgMQpNb2RlbAogNzAKMQogNzEKMAogMTAKMC4wCiAyMAowLjAKIDExCjQyMC4wCiAyMQoyOTcuMAogMTIKMC4wCiAyMgowLjAKIDMyCjAuMAogMTQKMWUrMjAKIDI0CjFlKzIwCiAzNAoxZSsyMAogMTUKLTFlKzIwCiAyNQotMWUrMjAKIDM1Ci0xZSsyMAoxNDYKMC4wCiAxMwowLjAKIDIzCjAuMAogMzMKMC4wCiAxNgoxLjAKIDI2CjAuMAogMzYKMC4wCiAxNwowLjAKIDI3CjEuMAogMzcKMC4wCiA3NgoxCjMzMAoxNwogIDAKTEFZT1VUCiAgNQoxRQozMzAKRAoxMDAKQWNEYlBsb3RTZXR0aW5ncwogIDEKCiAgNApBMwogIDYKCiA0MAo3LjUKIDQxCjIwLjAKIDQyCjcuNQogNDMKMjAuMAogNDQKNDIwLjAKIDQ1CjI5Ny4wCiA0NgowLjAKIDQ3CjAuMAogNDgKMC4wCiA0OQowLjAKMTQwCjAuMAoxNDEKMC4wCjE0MgoxLjAKMTQzCjEuMAogNzAKMAogNzIKMQogNzMKMAogNzQKNQogIDcKCiA3NQoxNgogNzYKMAogNzcKMgogNzgKMzAwCjE0NwoxLjAKMTQ4CjAuMAoxNDkKMC4wCjEwMApBY0RiTGF5b3V0CiAgMQpMYXlvdXQxCiA3MAoxCiA3MQoxCiAxMAowLjAKIDIwCjAuMAogMTEKNDIwLjAKIDIxCjI5Ny4wCiAxMgowLjAKIDIyCjAuMAogMzIKMC4wCiAxNAoxZSsyMAogMjQKMWUrMjAKIDM0CjFlKzIwCiAxNQotMWUrMjAKIDI1Ci0xZSsyMAogMzUKLTFlKzIwCjE0NgowLjAKIDEzCjAuMAogMjMKMC4wCiAzMwowLjAKIDE2CjEuMAogMjYKMC4wCiAzNgowLjAKIDE3CjAuMAogMjcKMS4wCiAzNwowLjAKIDc2CjEKMzMwCjFCCiAgMApNQVRFUklBTAogIDUKMUYKMTAyCntBQ0FEX1JFQUNUT1JTCjMzMApFCjEwMgp9CjMzMApFCjEwMApBY0RiTWF0ZXJpYWwKICAxCkJ5QmxvY2sKICAyCgogNzAKMAogNDAKMS4wCiA3MQoxCiA0MQoxLjAKIDkxCi0xMDIzNDEwMTc3CiA0MgoxLjAKIDcyCjEKICAzCgogNzMKMQogNzQKMQogNzUKMQogNDQKMC41CiA3MwowCiA0NQoxLjAKIDQ2CjEuMAogNzcKMQogIDQKCiA3OAoxCiA3OQoxCjE3MAoxCiA0OAoxLjAKMTcxCjEKICA2CgoxNzIKMQoxNzMKMQoxNzQKMQoxNDAKMS4wCjE0MQoxLjAKMTc1CjEKICA3CgoxNzYKMQoxNzcKMQoxNzgKMQoxNDMKMS4wCjE3OQoxCiAgOAoKMjcwCjEKMjcxCjEKMjcyCjEKMTQ1CjEuMAoxNDYKMS4wCjI3MwoxCiAgOQoKMjc0CjEKMjc1CjEKMjc2CjEKIDQyCjEuMAogNzIKMQogIDMKCiA3MwoxCiA3NAoxCiA3NQoxCiA5NAo2MwogIDAKTUFURVJJQUwKICA1CjIwCjEwMgp7QUNBRF9SRUFDVE9SUwozMzAKRQoxMDIKfQozMzAKRQoxMDAKQWNEYk1hdGVyaWFsCiAgMQpCeUxheWVyCiAgMgoKIDcwCjAKIDQwCjEuMAogNzEKMQogNDEKMS4wCiA5MQotMTAyMzQxMDE3NwogNDIKMS4wCiA3MgoxCiAgMwoKIDczCjEKIDc0CjEKIDc1CjEKIDQ0CjAuNQogNzMKMAogNDUKMS4wCiA0NgoxLjAKIDc3CjEKICA0CgogNzgKMQogNzkKMQoxNzAKMQogNDgKMS4wCjE3MQoxCiAgNgoKMTcyCjEKMTczCjEKMTc0CjEKMTQwCjEuMAoxNDEKMS4wCjE3NQoxCiAgNwoKMTc2CjEKMTc3CjEKMTc4CjEKMTQzCjEuMAoxNzkKMQogIDgKCjI3MAoxCjI3MQoxCjI3MgoxCjE0NQoxLjAKMTQ2CjEuMAoyNzMKMQogIDkKCjI3NAoxCjI3NQoxCjI3NgoxCiA0MgoxLjAKIDcyCjEKICAzCgogNzMKMQogNzQKMQogNzUKMQogOTQKNjMKICAwCk1BVEVSSUFMCiAgNQoyMQoxMDIKe0FDQURfUkVBQ1RPUlMKMzMwCkUKMTAyCn0KMzMwCkUKMTAwCkFjRGJNYXRlcmlhbAogIDEKR2xvYmFsCiAgMgoKIDcwCjAKIDQwCjEuMAogNzEKMQogNDEKMS4wCiA5MQotMTAyMzQxMDE3NwogNDIKMS4wCiA3MgoxCiAgMwoKIDczCjEKIDc0CjEKIDc1CjEKIDQ0CjAuNQogNzMKMAogNDUKMS4wCiA0NgoxLjAKIDc3CjEKICA0CgogNzgKMQogNzkKMQoxNzAKMQogNDgKMS4wCjE3MQoxCiAgNgoKMTcyCjEKMTczCjEKMTc0CjEKMTQwCjEuMAoxNDEKMS4wCjE3NQoxCiAgNwoKMTc2CjEKMTc3CjEKMTc4CjEKMTQzCjEuMAoxNzkKMQogIDgKCjI3MAoxCjI3MQoxCjI3MgoxCjE0NQoxLjAKMTQ2CjEuMAoyNzMKMQogIDkKCjI3NAoxCjI3NQoxCjI3NgoxCiA0MgoxLjAKIDcyCjEKICAzCgogNzMKMQogNzQKMQogNzUKMQogOTQKNjMKICAwCk1MSU5FU1RZTEUKICA1CjIyCjEwMgp7QUNBRF9SRUFDVE9SUwozMzAKMTAKMTAyCn0KMzMwCjEwCjEwMApBY0RiTWxpbmVTdHlsZQogIDIKU3RhbmRhcmQKIDcwCjAKICAzCgogNjIKMjU2CiA1MQo5MC4wCiA1Mgo5MC4wCiA3MQoyCiA0OQowLjUKIDYyCjI1NgogIDYKQllMQVlFUgogNDkKLTAuNQogNjIKMjU2CiAgNgpCWUxBWUVSCiAgMApNTEVBREVSU1RZTEUKICA1CjJDCjEwMgp7QUNBRF9SRUFDVE9SUwozMzAKRgoxMDIKfQozMzAKRgoxMDAKQWNEYk1MZWFkZXJTdHlsZQoxNzkKMgoxNzAKMgoxNzEKMQoxNzIKMAogOTAKMgogNDAKMC4wCiA0MQowLjAKMTczCjEKIDkxCi0xMDU2OTY0NjA4CiA5MgotMgoyOTAKMQogNDIKMi4wCjI5MQoxCiA0Mwo4LjAKICAzClN0YW5kYXJkCiA0NAo0LjAKMzAwCgozNDIKMjkKMTc0CjEKMTc1CjEKMTc2CjAKMTc4CjEKIDkzCi0xMDU2OTY0NjA4CiA0NQo0LjAKMjkyCjAKMjk3CjAKIDQ2CjQuMAogOTQKLTEwNTY5NjQ2MDgKIDQ3CjEuMAogNDkKMS4wCjE0MAoxLjAKMjk0CjEKMTQxCjAuMAoxNzcKMAoxNDIKMS4wCjI5NQowCjI5NgowCjE0MwozLjc1CjI3MQowCjI3Mgo5CjI3Mwo5CiAgMApESUNUSU9OQVJZCiAgNQoyRAozMzAKQQoxMDAKQWNEYkRpY3Rpb25hcnkKMjgwCjEKMjgxCjEKICAzCkNSRUFURURfQllfRVpEWEYKMzUwCjJFCiAgMwpXUklUVEVOX0JZX0VaRFhGCjM1MAozMQogIDAKRElDVElPTkFSWVZBUgogIDUKMkUKMzMwCjJECjEwMApEaWN0aW9uYXJ5VmFyaWFibGVzCjI4MAowCiAgMQoxLjQuNCBAIDIwMjYtMTEtMDRUMDk6Mjc6MjguNTkwNDk1KzAwOjAwCiAgMApESUNUSU9OQVJZVkFSCiAgNQozMQozMzAKMkQKMTAwCkRpY3Rpb25hcnlWYXJpYWJsZXMKMjgwCjAKICAxCjEuNC40IEAgMjAyNi0xMS0wNFQwOToyNzoyOC41OTExMzgrMDA6MDAKICAwCkVORFNFQwogIDAKRU9GCg==';
  function polylinesToDxf(paths,width,height,factor,texts=[]){
    if(!Array.isArray(paths))throw new Error('قائمة مسارات PDF غير صالحة.');
    width=Number(width);height=Number(height);factor=Number(factor);
    if(!finite(width)||!finite(height)||width<=0||height<=0||!finite(factor)||factor<=0)throw new Error('أبعاد الصفحة أو عامل المقياس غير صالح.');
    const validPaths=paths.filter(p=>Array.isArray(p?.points)&&p.points.length>=2);
    const validTexts=(texts||[]).filter(t=>t&&String(t.text||'').trim());
    if(!validPaths.length&&!validTexts.length)throw new Error('لا توجد عناصر متجهية أو نصوص قابلة للتحويل من صفحة PDF. لم يتم إنشاء ملف.');
    const fmtNum=v=>{const n=Number(v);if(!finite(n))throw new Error('إحداثي PDF غير صالح.');return fmt(n);};
    const pair=(code,value)=>`${code}\n${value}\n`;
    const escText=value=>{let out='';for(const ch of String(value??'')){const code=ch.codePointAt(0);if(code===10||code===13)out+=' ';else if(code<32)continue;else if(code<127)out+=ch;else if(code<=0xffff)out+='\\U+'+code.toString(16).toUpperCase().padStart(4,'0');else{const n=code-0x10000,hi=0xD800+(n>>10),lo=0xDC00+(n&1023);out+='\\U+'+hi.toString(16).toUpperCase().padStart(4,'0')+'\\U+'+lo.toString(16).toUpperCase().padStart(4,'0');}}return out.trim();};
    const colorValue=p=>{const v=Number(p?.rgb);return Number.isFinite(v)?Math.max(0,Math.min(0xffffff,Math.round(v))):0x000000;};
    const aciValue=p=>{const v=Math.round(Number(p?.aci)||7);return Math.max(1,Math.min(255,v));};
    const lineWeight=p=>{const points=Number(p?.lineWidth);if(!Number.isFinite(points)||points<0)return 25;const raw=Math.max(0,Math.min(211,points*35.2777777778)),allowed=[0,5,9,13,15,18,20,25,30,35,40,50,53,60,70,80,90,100,106,120,140,158,200,211];let best=allowed[0],dist=Infinity;for(const v of allowed){const d=Math.abs(v-raw);if(d<dist){dist=d;best=v;}}return best;};
    const all=[];
    const converted=(x,y)=>{const q={x:Number(x)*factor,y:(height-Number(y))*factor};if(!finite(q.x)||!finite(q.y))throw new Error('أحد إحداثيات PDF خارج النطاق العددي.');all.push(q);return q;};
    for(const p of validPaths)for(const q of p.points)converted(q.x,q.y);
    for(const t of validTexts)converted(t.x,t.y);
    let minX=Math.min(...all.map(p=>p.x)),minY=Math.min(...all.map(p=>p.y)),maxX=Math.max(...all.map(p=>p.x)),maxY=Math.max(...all.map(p=>p.y));
    const entityRecords=[];let handle=0x1000,vertices=0,polylineCount=0,textCount=0,hatchCount=0;
    const nextHandle=()=>{const h=handle.toString(16).toUpperCase();handle++;return h;};
    const fillGroups=new Map();
    for(let index=0;index<validPaths.length;index++){
      const p=validPaths[index];
      let v=p.points.map(q=>({x:Number(q.x),y:Number(q.y)}));
      if(v.length>2&&Math.hypot(v[0].x-v[v.length-1].x,v[0].y-v[v.length-1].y)<1e-7)v=v.slice(0,-1);
      if(p.filled){if(v.length<3)continue;const key=String(p.fillGroup??`fill-${index}`);if(!fillGroups.has(key))fillGroups.set(key,[]);fillGroups.get(key).push({points:v,rgb:colorValue(p),aci:aciValue(p),fillRule:p.fillRule||'nonzero'});continue;}
      if(v.length<2)continue;
      const rgb=colorValue(p),aci=aciValue(p),lw=lineWeight(p),closed=p.closed?1:0;
      let record=pair(0,'LWPOLYLINE')+pair(5,nextHandle())+pair(330,'17')+pair(100,'AcDbEntity')+pair(8,'0')+pair(62,aci)+pair(420,rgb)+pair(370,lw)+pair(100,'AcDbPolyline')+pair(90,v.length)+pair(70,closed);
      for(const q of v){const x=q.x*factor,y=(height-q.y)*factor;record+=pair(10,fmtNum(x))+pair(20,fmtNum(y));}
      entityRecords.push(record);vertices+=v.length;polylineCount++;
    }
    const area=poly=>{let a=0;for(let i=0;i<poly.length;i++){const p=poly[i],q=poly[(i+1)%poly.length];a+=p.x*q.y-q.x*p.y;}return a/2;};
    const inside=(poly,p)=>{let yes=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if(((a.y>p.y)!==(b.y>p.y))&&(p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x))yes=!yes;}return yes;};
    for(const group of fillGroups.values()){
      if(!group.length)continue;
      const first=group[0],polys=group.map(q=>q.points);
      let record=pair(0,'HATCH')+pair(5,nextHandle())+pair(330,'17')+pair(100,'AcDbEntity')+pair(8,'0')+pair(62,first.aci)+pair(420,first.rgb)+pair(100,'AcDbHatch')+pair(10,0)+pair(20,0)+pair(30,0)+pair(210,0)+pair(220,0)+pair(230,1)+pair(2,'SOLID')+pair(70,1)+pair(71,0)+pair(91,group.length);
      for(let i=0;i<group.length;i++){
        const poly=polys[i],a=area(poly);let sample={x:poly[0].x,y:poly[0].y};
        const p0=poly[0],p1=poly[1],dx=p1.x-p0.x,dy=p1.y-p0.y,len=Math.max(Math.hypot(dx,dy),1e-12),eps=Math.max(1e-8,Math.sqrt(Math.abs(a))*1e-7),side=a>=0?1:-1;
        sample={x:(p0.x+p1.x)/2+(-dy/len)*eps*side,y:(p0.y+p1.y)/2+(dx/len)*eps*side};
        let depth=0;for(let j=0;j<polys.length;j++)if(i!==j&&Math.abs(area(polys[j]))>Math.abs(a)+1e-9&&inside(polys[j],sample))depth++;
        const flags=2+(depth===0?1:(depth===1?16:0));
        record+=pair(92,flags)+pair(72,0)+pair(73,1)+pair(93,poly.length);
        for(const q of poly){record+=pair(10,fmtNum(q.x*factor))+pair(20,fmtNum((height-q.y)*factor));}
        record+=pair(97,0);vertices+=poly.length;
      }
      record+=pair(75,0)+pair(76,1)+pair(98,0);
      entityRecords.push(record);hatchCount++;
    }
    for(const t of validTexts){
      const x=Number(t.x)*factor,y=(height-Number(t.y))*factor,h=Math.max(.01,Number(t.height)||1)*factor,rot=Number(t.rotation)||0;
      if(![x,y,h,rot].every(finite))throw new Error('أحد عناصر النص في PDF يحتوي بيانات غير صالحة.');
      const rgb=colorValue(t),aci=aciValue(t),record=pair(0,'TEXT')+pair(5,nextHandle())+pair(330,'17')+pair(100,'AcDbEntity')+pair(8,'0')+pair(62,aci)+pair(420,rgb)+pair(100,'AcDbText')+pair(10,fmtNum(x))+pair(20,fmtNum(y))+pair(30,'0')+pair(40,fmtNum(h))+pair(1,escText(t.text))+pair(50,fmtNum(rot))+pair(7,'Standard')+pair(100,'AcDbText');
      entityRecords.push(record);textCount++;
    }
    if(!entityRecords.length)throw new Error('لم ينتج التحويل أي كيان CAD صالح. لم يتم إنشاء ملف.');
    let template='';
    try{const raw=atob(SQ187_R2000_TEMPLATE_B64);const bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));template=new TextDecoder('windows-1252').decode(bytes);}catch(e){throw new Error('تعذر تحميل قالب DXF R2000 الآمن: '+(e?.message||e));}
    const lines=template.split('\n');
    const setHeader=(name,values)=>{for(let i=0;i<lines.length-1;i++){if(lines[i].trim()==='9'&&lines[i+1].trim()==='$'+name){for(let j=i+2;j<lines.length-1&&lines[j].trim()!=='9'&&lines[j].trim()!=='0';j+=2){const code=Number(lines[j].trim());if(Object.prototype.hasOwnProperty.call(values,code))lines[j+1]=String(values[code]);}return;}}throw new Error('قالب DXF لا يحتوي متغير '+name);};
    setHeader('EXTMIN',{10:fmtNum(minX),20:fmtNum(minY),30:'0'});
    setHeader('EXTMAX',{10:fmtNum(maxX),20:fmtNum(maxY),30:'0'});
    setHeader('HANDSEED',{5:handle.toString(16).toUpperCase()});
    template=lines.join('\n');
    const marker='  2\nENTITIES\n';const section=template.indexOf(marker);
    if(section<0)throw new Error('قالب DXF لا يحتوي قسم ENTITIES.');
    const end=template.indexOf('  0\nENDSEC',section+marker.length);
    if(end<0)throw new Error('قالب DXF يحتوي قسم ENTITIES غير مكتمل.');
    const out=template.slice(0,end)+entityRecords.join('')+template.slice(end);
    if(!out.includes('$ACADVER\n  1\nAC1015')||!out.endsWith('EOF\n')||(!out.includes('LWPOLYLINE')&&!out.includes('HATCH')&&!out.includes('TEXT')))throw new Error('فشل التحقق البنيوي من ملف DXF R2000.');
    if(/\nIMAGE(?:\r?\n|$)|\nIMAGEDEF(?:\r?\n|$)/.test(out))throw new Error('تم اكتشاف كيان صورة غير مسموح به داخل DXF.');
    const bytes=enc.encode(out);
    return{bytes,count:polylineCount+hatchCount+textCount,polylineCount,hatchCount,vertices,layers:['0'],textCount,version:'AC1015'};
  }
  // Prefer native PDF vector paths before raster tracing; the result is editable CAD geometry.
  async function pdfOperatorPathsToCad(page,lib,viewport,maxVertices=250000){
    if(!page||typeof page.getOperatorList!=='function'||!lib?.OPS||!viewport?.convertToViewportPoint)return[];
    const list=await page.getOperatorList(),O=lib.OPS,paths=[];
    const rasterFns=new Set(['paintImageXObject','paintInlineImageXObject','paintImageMaskXObject','paintImageMaskXObjectGroup','paintImageXObjectRepeat','paintImageMaskXObjectRepeat','paintInlineImageXObjectGroup','paintSolidColorImageMask'].map(k=>O[k]).filter(Number.isInteger));
    const unsupportedFns=new Map([['paintXObject','كائن Form/XObject خارجي'],['paintFormXObjectBegin','بداية كائن Form خارجي'],['setStrokeColorSpace','مساحة لون خاصة للخط'],['setStrokeColor','لون خط من مساحة غير مدعومة'],['setStrokeColorN','لون خط خاص/Pattern'],['setFillColorSpace','مساحة لون خاصة للتعبئة'],['setFillColor','لون تعبئة من مساحة غير مدعومة'],['setFillColorN','لون تعبئة خاص/Pattern'],['clip','قص هندسي'],['eoClip','قص هندسي Even-Odd']].filter(([k])=>Number.isInteger(O[k])).map(([k])=>[O[k],k]));
    let matrix=[1,0,0,1,0,0],stroke=[0,0,0],fill=[0,0,0],lineWidth=1;
    const stack=[];let active=null,subpaths=[],fillGroupSerial=0;
    const rgb=v=>{if(v==null)return[0,0,0];let a;try{a=Array.from(v);}catch(_){a=[];}if(a.length<3)return[0,0,0];return a.slice(0,3).map(x=>Math.max(0,Math.min(255,Math.round(Number(x)||0))));};
    const ci=c=>{const[r,g,b]=c,white=r>=248&&g>=248&&b>=248,pal=[[1,255,0,0],[2,255,255,0],[3,0,255,0],[4,0,255,255],[5,0,0,255],[6,255,0,255],[7,0,0,0]];let best=pal[0],dist=Infinity;for(const q of pal){const d=(r-q[1])**2+(g-q[2])**2+(b-q[3])**2;if(d<dist){best=q;dist=d;}}return{aci:best[0],rgb:(r<<16)|(g<<8)|b,white};};
    const mul=(a,b)=>[a[0]*b[0]+a[2]*b[1],a[1]*b[0]+a[3]*b[1],a[0]*b[2]+a[2]*b[3],a[1]*b[2]+a[3]*b[3],a[0]*b[4]+a[2]*b[5]+a[4],a[1]*b[4]+a[3]*b[5]+a[5]];
    const pt=(x,y)=>{const px=matrix[0]*x+matrix[2]*y+matrix[4],py=matrix[1]*x+matrix[3]*y+matrix[5],q=viewport.convertToViewportPoint(px,py);return{x:Number(q[0]),y:Number(q[1])};};
    const push=(x,y)=>{if(!active)active=[];const q=pt(x,y),last=active[active.length-1];if(!last||Math.hypot(last.x-q.x,last.y-q.y)>1e-7)active.push(q);};
    const finish=(closed=false)=>{if(active?.length>=2)subpaths.push({points:active,closed:!!closed});active=null;};
    const cubic=(p0,p1,p2,p3)=>{for(let k=1;k<=64;k++){const t=k/64,u=1-t,q={x:u*u*u*p0.x+3*u*u*t*p1.x+3*u*t*t*p2.x+t*t*t*p3.x,y:u*u*u*p0.y+3*u*u*t*p1.y+3*u*t*t*p2.y+t*t*t*p3.y},last=active[active.length-1];if(!last||Math.hypot(last.x-q.x,last.y-q.y)>1e-7)active.push(q);}};
    const build=(ops,coords)=>{let i=0;const take=n=>{if(i+n>coords.length)throw new Error('مسار PDF vector غير مكتمل.');const a=coords.slice(i,i+n).map(Number);i+=n;if(a.some(v=>!Number.isFinite(v)))throw new Error('مسار PDF يحتوي إحداثيات غير رقمية.');return a;};
      for(const op of ops){if(op===O.moveTo){const[x,y]=take(2);finish(false);push(x,y);}else if(op===O.lineTo){const[x,y]=take(2);push(x,y);}else if(op===O.curveTo){const[x1,y1,x2,y2,x3,y3]=take(6);if(!active)throw new Error('منحنى PDF بلا نقطة بداية.');cubic(active[active.length-1],pt(x1,y1),pt(x2,y2),pt(x3,y3));}else if(op===O.curveTo2){const[x2,y2,x3,y3]=take(4);if(!active)throw new Error('منحنى PDF بلا نقطة بداية.');cubic(active[active.length-1],active[active.length-1],pt(x2,y2),pt(x3,y3));}else if(op===O.curveTo3){const[x1,y1,x3,y3]=take(4);if(!active)throw new Error('منحنى PDF بلا نقطة بداية.');cubic(active[active.length-1],pt(x1,y1),pt(x3,y3),pt(x3,y3));}else if(op===O.closePath){if(active?.length>=2){const f=active[0],last=active[active.length-1];if(Math.hypot(f.x-last.x,f.y-last.y)>1e-7)active.push({...f});finish(true);}}else if(op===O.rectangle){const[x,y,w,h]=take(4);finish(false);push(x,y);push(x+w,y);push(x+w,y+h);push(x,y+h);const f=active?.[0];if(f)active.push({...f});finish(true);}else throw new Error('أمر مسار PDF غير مدعوم: '+op);}
    };
    const paint=fn=>{const isFill=[O.fill,O.eoFill,O.fillStroke,O.eoFillStroke,O.closeFillStroke,O.closeEOFillStroke].includes(fn);finish([O.closeStroke,O.closeFillStroke,O.closeEOFillStroke].includes(fn));const isStroke=[O.stroke,O.closeStroke,O.fillStroke,O.eoFillStroke,O.closeFillStroke,O.closeEOFillStroke].includes(fn);if(isFill){const color=ci(fill),group=fillGroupSerial++,rule=[O.eoFill,O.eoFillStroke,O.closeEOFillStroke].includes(fn)?'evenodd':'nonzero';for(const q of subpaths){if(paths.length>=50000)throw new Error('ملف PDF يحتوي عدد مسارات يتجاوز الحد الآمن.');if(q.points.length>=3)paths.push({...q,filled:true,closed:true,fillRule:rule,fillGroup:group,aci:color.aci,rgb:color.rgb,lineWidth:0});}}if(isStroke){const color=ci(stroke);for(const q of subpaths){if(paths.length>=50000)throw new Error('ملف PDF يحتوي عدد مسارات يتجاوز الحد الآمن.');if(q.points.length>=2)paths.push({...q,filled:false,aci:color.aci,rgb:color.rgb,lineWidth});}}subpaths=[];active=null;};
    for(let n=0;n<list.fnArray.length;n++){const fn=list.fnArray[n],a=list.argsArray[n];
      if(rasterFns.has(fn))throw new Error('صفحة PDF تحتوي صورة نقطية أو عنصرًا صوريًا. لا يمكن إنشاء DXF هندسي مطابق لها بدون تحويل تقريبي؛ لم يتم إنشاء أي ملف.');
      if(unsupportedFns.has(fn))throw new Error('صفحة PDF تحتوي '+unsupportedFns.get(fn)+' لا يمكن تمثيله بأمان في DXF؛ أوقفت التحويل حتى لا يتم إسقاط عناصر أو تغيير ألوانها. لم يتم إنشاء أي ملف.');
      if(fn===O.paintFormXObjectEnd)throw new Error('صفحة PDF تحتوي كائن Form خارجيًا غير مدعوم؛ لم يتم إنشاء DXF ناقص.');
      if(fn===O.shadingFill)throw new Error('صفحة PDF تحتوي تدرجات أو تعبئات لونية غير قابلة للتمثيل كخطوط CAD مطابقة؛ لم يتم إنشاء أي ملف.');
      if(fn===O.setDash&&Array.isArray(a?.[0])&&a[0].some(v=>Math.abs(Number(v)||0)>1e-9))throw new Error('صفحة PDF تحتوي خطوطًا متقطعة أو نمط خط خاصًا غير مدعوم بدقة؛ لم يتم إنشاء أي ملف.');
      if(fn===O.save){stack.push({matrix:matrix.slice(),stroke:stroke.slice(),fill:fill.slice(),lineWidth});continue;}
      if(fn===O.restore){const q=stack.pop();if(q){matrix=q.matrix;stroke=q.stroke;fill=q.fill;lineWidth=q.lineWidth;}continue;}
      if(fn===O.transform&&Array.isArray(a)&&a.length>=6){matrix=mul(matrix,a.slice(0,6).map(Number));continue;}
      if(fn===O.setStrokeRGBColor){stroke=rgb(a);continue;}if(fn===O.setFillRGBColor){fill=rgb(a);continue;}if(fn===O.setStrokeCMYKColor||fn===O.setFillCMYKColor){const c=Array.from(a||[]).slice(0,4).map(v=>Math.max(0,Math.min(1,Number(v)||0)));while(c.length<4)c.push(0);const k=c[3],rgbC=[Math.round(255*(1-Math.min(1,c[0]+k))),Math.round(255*(1-Math.min(1,c[1]+k))),Math.round(255*(1-Math.min(1,c[2]+k)))];if(fn===O.setStrokeCMYKColor)stroke=rgbC;else fill=rgbC;continue;}
      if(fn===O.setStrokeGray||fn===O.setFillGray){const g=Math.round(Math.max(0,Math.min(1,Number(a?.[0])||0))*255);if(fn===O.setStrokeGray)stroke=[g,g,g];else fill=[g,g,g];continue;}
      if(fn===O.setLineWidth){lineWidth=Math.max(0,Number(a?.[0])||1);continue;}
      if(fn===O.constructPath){build(a?.[0]||[],a?.[1]||[]);continue;}
      if(fn===O.moveTo){const[x,y]=a;finish(false);push(x,y);continue;}if(fn===O.lineTo){const[x,y]=a;push(x,y);continue;}
      if(fn===O.curveTo){const[x1,y1,x2,y2,x3,y3]=a;cubic(active[active.length-1],pt(x1,y1),pt(x2,y2),pt(x3,y3));continue;}
      if(fn===O.closePath){if(active?.length>=2){const f=active[0];active.push({...f});finish(true);}continue;}
      if([O.stroke,O.closeStroke,O.fill,O.eoFill,O.fillStroke,O.eoFillStroke,O.closeFillStroke,O.closeEOFillStroke].includes(fn)){paint(fn);continue;}
      if(fn===O.endPath){active=null;subpaths=[];continue;}
    }
    const vertices=paths.reduce((n,q)=>n+q.points.length,0);if(vertices>maxVertices)throw new Error('ملف PDF يحتوي عدد رؤوس يتجاوز الحد الآمن.');
    return paths.filter(q=>q.points.length>=2&&q.points.every(v=>Number.isFinite(v.x)&&Number.isFinite(v.y)));
  }

  async function pdfTextToCad(page,viewport,maxItems=20000,lib=root.pdfjsLib){
    if(!page||typeof page.getTextContent!=='function'||!viewport?.convertToViewportPoint)return[];
    const content=await page.getTextContent({includeMarkedContent:false,disableNormalization:false}),out=[];const opList=await page.getOperatorList(),O=lib?.OPS,textColors=[];let currentFill=[0,0,0];const showOps=new Set([O?.showText,O?.showSpacedText,O?.nextLineShowText,O?.nextLineSetSpacingShowText].filter(Number.isInteger));for(let i=0;i<opList.fnArray.length;i++){const fn=opList.fnArray[i],a=opList.argsArray[i];if(fn===O?.setFillRGBColor)currentFill=Array.from(a||[]).slice(0,3).map(v=>Math.max(0,Math.min(255,Math.round(Number(v)||0))));else if(fn===O?.setFillGray){const g=Math.round(Math.max(0,Math.min(1,Number(a?.[0])||0))*255);currentFill=[g,g,g];}else if(fn===O?.setFillCMYKColor){const c=Array.from(a||[]).slice(0,4).map(v=>Math.max(0,Math.min(1,Number(v)||0)));while(c.length<4)c.push(0);const k=c[3];currentFill=[Math.round(255*(1-Math.min(1,c[0]+k))),Math.round(255*(1-Math.min(1,c[1]+k))),Math.round(255*(1-Math.min(1,c[2]+k)))];}else if(showOps.has(fn))textColors.push((currentFill[0]<<16)|(currentFill[1]<<8)|currentFill[2]);}const textColorMatch=textColors.length===(content.items||[]).length;if((content.items||[]).length>0&&!textColorMatch)throw new Error('تعذر مطابقة ألوان النصوص في PDF مع عناصر النص المستخرجة. أوقفت التحويل بدل تغيير ألوان النص بصمت.');const textPalette=[[1,0xff0000],[2,0xffff00],[3,0x00ff00],[4,0x00ffff],[5,0x0000ff],[6,0xff00ff],[7,0x000000]];const textAci=rgb=>{let best=7,dist=Infinity;for(const [aci,c] of textPalette){const dr=((rgb>>16)&255)-((c>>16)&255),dg=((rgb>>8)&255)-((c>>8)&255),db=(rgb&255)-(c&255),d=dr*dr+dg*dg+db*db;if(d<dist){dist=d;best=aci;}}return best;};
    const dxfUnicode=text=>{let result='';for(let i=0;i<String(text).length;i++){const c=String(text).charCodeAt(i);if(c<32&&c!==9)continue;if(c<127)result+=String.fromCharCode(c);else result+='\\U+'+c.toString(16).toUpperCase().padStart(4,'0');}return result.replace(/[\r\n]+/g,' ').trim();};
    for(const item of content.items||[]){if(!item||typeof item.str!=='string'||!item.str.trim())continue;if(out.length>=maxItems)throw new Error('PDF يحتوي عدد نصوص يتجاوز الحد الآمن.');const m=item.transform;if(!Array.isArray(m)||m.length<6||m.slice(0,6).some(v=>!Number.isFinite(Number(v))))continue;const a=Number(m[0]),b=Number(m[1]),p=viewport.convertToViewportPoint(Number(m[4]),Number(m[5])),q=viewport.convertToViewportPoint(Number(m[4])+a,Number(m[5])+b),h=Math.hypot(a,b);if(!Number.isFinite(h)||h<=0||!Number.isFinite(p[0])||!Number.isFinite(p[1]))continue;const text=dxfUnicode(item.str);if(text){const rgb=textColorMatch?(textColors[out.length]??0):0;out.push({text,x:Number(p[0]),y:Number(p[1]),height:h,rotation:Math.atan2(-(q[1]-p[1]),q[0]-p[0])*180/Math.PI,width:Number(item.width)||0,rgb,aci:textAci(rgb)});}}
    return out;
  }

  /* Raw-record DXF board merge. Source entity records and supported symbol/block
     records are copied verbatim; only colliding handles, owners and symbol names
     are remapped. Unsupported external/object references fail closed. */
  function* dxfPairs(bytes, start=0, end=bytes.length) {
    let pos=start;
    while(pos<end){
      const c=readLine(bytes,pos); if(!c||c.end>end) break;
      const v=readLine(bytes,c.end); if(!v||v.end>end) break;
      yield {code:Number.parseInt(pairText(bytes,c),10),value:pairText(bytes,v),start:c.start,valueStart:v.start,valueEnd:v.valueEnd,end:v.end};
      pos=v.end;
    }
  }
  function dxfSectionBounds(bytes,name){
    let previous=null,active='',start=null;
    for(const p of dxfPairs(bytes)){
      if(previous&&previous.code===0&&previous.value.toUpperCase()==='SECTION'&&p.code===2){active=p.value.toUpperCase();start=p.end;}
      if(active===name.toUpperCase()&&p.code===0&&p.value.toUpperCase()==='ENDSEC')return {start,end:p.start,endPair:p};
      previous=p;
    }
    return null;
  }
  function dxfTableMap(bytes){
    const out=new Map();let previous=null,active=null,row=null,header=[];
    const finishRow=end=>{if(row){row.end=end;active.rows.push(row);row=null;}};
    const finishTable=()=>{if(active){if(active.endTab)finishRow(active.endTab.start);active.header=header;active.handle=header.find(p=>p.code===5)?.value||null;active.countPair=header.find(p=>p.code===70)||null;out.set(active.name,active);}active=null;header=[];};
    for(const p of dxfPairs(bytes)){
      if(previous&&previous.code===0&&previous.value.toUpperCase()==='TABLE'&&p.code===2){finishTable();active={name:p.value.toUpperCase(),start:previous.start,rows:[],endTab:null};header=[];row=null;}
      else if(active){
        if(p.code===0){if(p.value.toUpperCase()==='ENDTAB'){finishRow(p.start);active.endTab=p;finishTable();}else{finishRow(p.start);row={type:p.value.toUpperCase(),start:p.start,name:'',end:null};}}
        else if(row){if(p.code===2&&!row.name)row.name=p.value;}
        else header.push(p);
      }
      previous=p;
    }
    return out;
  }
  function dxfRowFields(bytes,row){return [...dxfPairs(bytes,row.start,row.end)];}
  function dxfRecordSignature(bytes,row){return dxfRowFields(bytes,row).filter(p=>![5,105,330].includes(p.code)).map(p=>`${p.code}:${p.value}`).join('\n');}
  function dxfBlockDefinitions(bytes){
    const sec=dxfSectionBounds(bytes,'BLOCKS');if(!sec)return [];
    const defs=[];let current=null;
    for(const p of dxfPairs(bytes,sec.start,sec.end)){
      if(p.code===0){
        const type=p.value.toUpperCase();
        if(type==='BLOCK'){if(current)throw new Error('تعريف BLOCK متداخل أو غير مغلق في اللوحة المصدر.');current={start:p.start,end:null,name:''};}
        else if(type==='ENDBLK'&&current){current.end=p.end;defs.push(current);current=null;}
      }else if(current&&p.code===2&&!current.name)current.name=p.value;
    }
    if(current)throw new Error('تعريف بلوك غير مكتمل في اللوحة المصدر.');
    return defs;
  }
  function dxfMaxHandle(bytes){let max=0n;for(const p of dxfPairs(bytes))if((p.code===5||p.code===105)&&/^[0-9A-F]+$/i.test(p.value)){const n=BigInt('0x'+p.value);if(n>max)max=n;}return max;}
  function dxfFindModelHandle(table,which){
    if(!table)return null;
    for(const r of table.rows){const n=String(r.name||'').replace(/[\s_-]/g,'').toUpperCase();if(n===which){const h=dxfRowFields(table._bytes,r).find(p=>p.code===5)?.value;return h||null;}}
    return null;
  }
  function dxfUniqueName(prefix,name,used,max=31){
    const base=String(name||'ITEM'),suffixBase=prefix+base;let candidate=suffixBase.slice(0,max),i=1;
    while(used.has(candidate.toUpperCase())){const suffix='_'+i++;candidate=suffixBase.slice(0,Math.max(1,max-suffix.length))+suffix;}
    used.add(candidate.toUpperCase());return candidate;
  }
  function dxfCollectHandles(bytes,ranges){
    const set=new Set();for(const [a,b] of ranges)for(const p of dxfPairs(bytes,a,b))if((p.code===5||p.code===105)&&/^[0-9A-F]+$/i.test(p.value))set.add(p.value.toUpperCase());return set;
  }
  function dxfRewriteRange(bytes,start,end,context,handleMap,edits){
    let entityType='';
    for(const p of dxfPairs(bytes,start,end)){
      if(p.code===0)entityType=p.value.toUpperCase();
      let replacement=null;
      if((p.code===5||p.code===105)&&handleMap.has(p.value.toUpperCase()))replacement=handleMap.get(p.value.toUpperCase());
      else if((p.code>=330&&p.code<=369)||p.code===1005){
        const h=p.value.toUpperCase();
        if(context.ownerMap?.has(h))replacement=context.ownerMap.get(h);
        else if(handleMap.has(h))replacement=handleMap.get(h);
        else if(/^[0-9A-F]+$/i.test(p.value))throw new Error(`يوجد مرجع DXF إلى مقبض خارجي ${p.value} (المجموعة ${p.code}) لم يمكن استيراده بأمان. لم يتم إنشاء ناتج ناقص.`);
      }
      if(replacement===null){
        const maps=context.names||{};
        if(p.code===8&&maps.LAYER?.has(p.value))replacement=maps.LAYER.get(p.value);
        else if(p.code===6&&maps.LTYPE?.has(p.value))replacement=maps.LTYPE.get(p.value);
        else if(p.code===7&&maps.STYLE?.has(p.value))replacement=maps.STYLE.get(p.value);
        else if(p.code===3&&entityType==='DIMENSION'&&maps.DIMSTYLE?.has(p.value))replacement=maps.DIMSTYLE.get(p.value);
        else if(p.code===1001&&maps.APPID?.has(p.value))replacement=maps.APPID.get(p.value);
        else if((entityType==='INSERT'||entityType==='DIMENSION')&&p.code===2&&maps.BLOCK?.has(p.value))replacement=maps.BLOCK.get(p.value);
        else if((entityType==='BLOCK'||entityType==='ENDBLK')&&(p.code===2||p.code===3)&&maps.BLOCK?.has(p.value))replacement=maps.BLOCK.get(p.value);
        else if(context.tableName&&p.code===2&&maps[context.tableName]?.has(p.value))replacement=maps[context.tableName].get(p.value);
        else if(context.tableName==='LAYER'&&p.code===6&&maps.LTYPE?.has(p.value))replacement=maps.LTYPE.get(p.value);
        else if(context.tableName==='DIMSTYLE'&&p.code===3&&maps.STYLE?.has(p.value))replacement=maps.STYLE.get(p.value);
      }
      if(replacement!==null&&String(replacement)!==p.value)edits.push({start:p.valueStart,end:p.valueEnd,insertBytes:enc.encode(String(replacement))});
    }
  }
  function dxfConcat(parts){let n=0;for(const p of parts)n+=p.length;const out=new Uint8Array(n);let at=0;for(const p of parts){out.set(p,at);at+=p.length;}return out;}
  function dxfParseHandseed(bytes){let previous=null;for(const p of dxfPairs(bytes)){if(previous&&previous.code===9&&previous.value.toUpperCase()==='$HANDSEED'&&p.code===5)return p;previous=p;}return null;}
  function mergeRawDxfBoards(targetInput,sourceInput){
    const target=targetInput instanceof Uint8Array?targetInput:new Uint8Array(targetInput),source=sourceInput instanceof Uint8Array?sourceInput:new Uint8Array(sourceInput);
    if(!target.length||!source.length)throw new Error('أحد ملفي DXF فارغ.');
    const ts=dxfSectionBounds(target,'ENTITIES'),ss=dxfSectionBounds(source,'ENTITIES'),tb=dxfSectionBounds(target,'BLOCKS'),sb=dxfSectionBounds(source,'BLOCKS');
    if(!ts||!ss)throw new Error('يجب أن يحتوي الملفان على قسم ENTITIES صالح.');
    if(!tb)throw new Error('اللوحة المرجعية لا تحتوي على قسم BLOCKS. أوقفت الدمج لحماية بنية الملف.');
    const tt=dxfTableMap(target),st=dxfTableMap(source);tt.forEach(v=>v._bytes=target);st.forEach(v=>v._bytes=source);
    if(!tt.has('LAYER')||!st.has('LAYER'))throw new Error('جدول LAYER مفقود في أحد الملفين.');
    const hasTargetBlockRecord=tt.has('BLOCK_RECORD'),hasSourceBlockRecord=st.has('BLOCK_RECORD');
    if(hasTargetBlockRecord!==hasSourceBlockRecord)throw new Error('إصدارا DXF يستخدمان بنيتين مختلفتين لجدول BLOCK_RECORD؛ أوقفت الدمج حتى لا تتغير بنية الملف.');
    const hasBlockRecord=hasTargetBlockRecord;
    const targetModel=hasBlockRecord?dxfFindModelHandle(tt.get('BLOCK_RECORD'),' *MODELSPACE'.trim()):null;
    const sourceModel=hasBlockRecord?dxfFindModelHandle(st.get('BLOCK_RECORD'),' *MODELSPACE'.trim()):null;
    if(hasBlockRecord&&(!targetModel||!sourceModel))throw new Error('تعذر تحديد Model Space في أحد الملفين.');
    const reserved=n=>String(n||'').replace(/[\s_-]/g,'').toUpperCase();
    const sysNames=new Set(['*MODELSPACE','*PAPERSPACE','*PAPERSPACE0']);
    const targetDefs=dxfBlockDefinitions(target),srcDefs=dxfBlockDefinitions(source);
    const targetBlockNames=new Set((hasBlockRecord?tt.get('BLOCK_RECORD').rows.map(r=>String(r.name||'')):targetDefs.map(d=>d.name)).map(n=>n.toUpperCase()));
    const defsByName=new Map(srcDefs.map(d=>[d.name.toUpperCase(),d]));
    const srcBlockRows=hasBlockRecord?st.get('BLOCK_RECORD').rows:[],blockMap=new Map();
    if(hasBlockRecord){
      for(const row of srcBlockRows){
        const name=row.name||'';if(!name)continue;
        if(sysNames.has(reserved(name)))continue;
        const def=defsByName.get(name.toUpperCase());if(!def)throw new Error(`تعريف البلوك ${name} مسجل في BLOCK_RECORD لكنه بلا بيانات BLOCK. أوقفت الدمج لمنع فقد العناصر.`);
        const mapped=targetBlockNames.has(name.toUpperCase())?dxfUniqueName('SQ163_',name,targetBlockNames,255):name;
        targetBlockNames.add(mapped.toUpperCase());blockMap.set(name,mapped);
      }
    }else{
      // Legacy R12/R13 DXF has no BLOCK_RECORD table. Preserve its block records
      // directly and remap names for INSERT/BLOCK references without inventing tables.
      for(const def of srcDefs){const name=def.name||'';if(!name||sysNames.has(reserved(name)))continue;const mapped=targetBlockNames.has(name.toUpperCase())?dxfUniqueName('SQ163_',name,targetBlockNames,31):name;targetBlockNames.add(mapped.toUpperCase());blockMap.set(name,mapped);}
    }
    for(const def of srcDefs)if(!sysNames.has(reserved(def.name))&&!blockMap.has(def.name))throw new Error(`تعريف البلوك ${def.name} غير مرتبط بسجل يمكن استيراده بأمان.`);
    const nameMaps={LAYER:new Map(),LTYPE:new Map(),STYLE:new Map(),DIMSTYLE:new Map(),APPID:new Map(),BLOCK:new Map(blockMap),BLOCK_RECORD:new Map(blockMap)};
    const tablesToMerge=['LAYER','LTYPE','STYLE','DIMSTYLE','APPID'];
    const plannedRows=new Map();
    for(const tableName of tablesToMerge){
      const srcTable=st.get(tableName),dstTable=tt.get(tableName);if(!srcTable){plannedRows.set(tableName,[]);continue;}
      if(!dstTable)throw new Error(`جدول ${tableName} غير موجود في اللوحة المرجعية بينما تحتاجه اللوحة المصدر.`);
      const existing=new Map(dstTable.rows.map(r=>[String(r.name||'').toUpperCase(),r])),used=new Set(existing.keys()),rows=[];
      for(const sr of srcTable.rows){
        const name=sr.name||'';if(!name)continue;
        if(tableName==='LAYER'&&name==='0'){const zero=existing.get('0');if(zero&&dxfRecordSignature(target,zero)!==dxfRecordSignature(source,sr))throw new Error('تعريف الطبقة 0 مختلف بين اللوحتين؛ أوقفت الدمج لحماية خصائصها.');nameMaps.LAYER.set(name,'0');continue;}
        const dr=existing.get(name.toUpperCase());
        if(!dr){nameMaps[tableName].set(name,name);rows.push(sr);used.add(name.toUpperCase());continue;}
        if(dxfRecordSignature(target,dr)===dxfRecordSignature(source,sr)){nameMaps[tableName].set(name,name);continue;}
        const mapped=dxfUniqueName('SQ163_',name,used,tableName==='LAYER'?31:255);nameMaps[tableName].set(name,mapped);rows.push(sr);
      }
      plannedRows.set(tableName,rows);
    }
    const reservedMap=new Map();
    if(hasBlockRecord)for(const name of ['*Model_Space','*Paper_Space','*Paper_Space0']){
      const sr=srcBlockRows.find(r=>reserved(r.name)===reserved(name)),tr=tt.get('BLOCK_RECORD').rows.find(r=>reserved(r.name)===reserved(name));
      if(sr&&tr){const sh=dxfRowFields(source,sr).find(p=>p.code===5)?.value,th=dxfRowFields(target,tr).find(p=>p.code===5)?.value;if(sh&&th)reservedMap.set(sh.toUpperCase(),th);}
    }
    const sourceRanges=[[ss.start,ss.end]];if(sb)for(const d of srcDefs)if(blockMap.has(d.name))sourceRanges.push([d.start,d.end]);
    for(const n of tablesToMerge)for(const r of plannedRows.get(n)||[])sourceRanges.push([r.start,r.end]);
    const blockRecordRows=hasBlockRecord?srcBlockRows.filter(r=>blockMap.has(r.name)):[];for(const r of blockRecordRows)sourceRanges.push([r.start,r.end]);
    const defined=dxfCollectHandles(source,sourceRanges),targetMax=dxfMaxHandle(target);let next=targetMax+1n;const handleMap=new Map();
    for(const h of defined){if(handleMap.has(h))throw new Error(`مقبض مكرر في المصدر: ${h}`);handleMap.set(h,(next++).toString(16).toUpperCase());}
    const ownerMap=new Map(reservedMap);
    for(const n of (hasBlockRecord?[...tablesToMerge,'BLOCK_RECORD']:tablesToMerge)){const a=st.get(n),b=tt.get(n);if(a?.handle&&b?.handle)ownerMap.set(a.handle.toUpperCase(),b.handle);}
    for(const row of blockRecordRows){const old=dxfRowFields(source,row).find(p=>p.code===5)?.value,newHandle=old&&handleMap.get(old.toUpperCase());if(old&&newHandle)ownerMap.set(old.toUpperCase(),newHandle);}
    const edits=[];
    dxfRewriteRange(source,ss.start,ss.end,{names:nameMaps,ownerMap},handleMap,edits);
    if(sb)for(const d of srcDefs)if(blockMap.has(d.name))dxfRewriteRange(source,d.start,d.end,{names:nameMaps,ownerMap},handleMap,edits);
    for(const n of tablesToMerge){const dst=tt.get(n);for(const r of plannedRows.get(n)||[])dxfRewriteRange(source,r.start,r.end,{names:nameMaps,ownerMap,tableName:n},handleMap,edits);}
    for(const r of blockRecordRows)dxfRewriteRange(source,r.start,r.end,{names:nameMaps,ownerMap,tableName:'BLOCK_RECORD'},handleMap,edits);
    const rewritten=edits.length?applyEdits(source,edits):source;
    const copied={};
    const rewrittenTables=dxfTableMap(rewritten);rewrittenTables.forEach(v=>v._bytes=rewritten);
    for(const n of tablesToMerge){copied[n]=[];const now=rewrittenTables.get(n);for(const r of plannedRows.get(n)||[]){const wanted=String(nameMaps[n].get(r.name)||r.name).toUpperCase();const matching=now?.rows.find(z=>z.name.toUpperCase()===wanted);if(!matching)throw new Error(`فشل تحديد سجل ${n} بعد إعادة ربط المراجع.`);copied[n].push(rewritten.subarray(matching.start,matching.end));}}
    const mappedBlockNames=new Set([...blockMap.values()].map(n=>n.toUpperCase()));
    copied.BLOCK_RECORD=[];if(hasBlockRecord)for(const r of rewrittenTables.get('BLOCK_RECORD').rows)if(mappedBlockNames.has(String(r.name||'').toUpperCase()))copied.BLOCK_RECORD.push(rewritten.subarray(r.start,r.end));
    const rewrittenDefs=dxfBlockDefinitions(rewritten);copied.BLOCKS=[];
    for(const d of rewrittenDefs)if(mappedBlockNames.has(d.name.toUpperCase()))copied.BLOCKS.push(rewritten.subarray(d.start,d.end));
    const newEnt=dxfSectionBounds(rewritten,'ENTITIES'),entityBytes=rewritten.subarray(newEnt.start,newEnt.end);
    const targetEdits=[];
    for(const n of (hasBlockRecord?[...tablesToMerge,'BLOCK_RECORD']:tablesToMerge)){const rows=copied[n]||[];if(!rows.length)continue;const t=tt.get(n);if(!t?.endTab)throw new Error(`لا يمكن إضافة سجلات جدول ${n}.`);targetEdits.push({start:t.endTab.start,end:t.endTab.start,insertBytes:dxfConcat(rows)});if(t.countPair)targetEdits.push({start:t.countPair.valueStart,end:t.countPair.valueEnd,insertBytes:enc.encode(String(t.rows.length+rows.length))});}
    if(copied.BLOCKS.length)targetEdits.push({start:tb.end,end:tb.end,insertBytes:dxfConcat(copied.BLOCKS)});
    if(entityBytes.length)targetEdits.push({start:ts.end,end:ts.end,insertBytes:entityBytes});
    const handseed=dxfParseHandseed(target);if(handseed)targetEdits.push({start:handseed.valueStart,end:handseed.valueEnd,insertBytes:enc.encode(next.toString(16).toUpperCase())});
    const merged=applyEdits(target,targetEdits),verifyTables=dxfTableMap(merged),verifyBlocks=dxfBlockDefinitions(merged),verifyEntities=dxfSectionBounds(merged,'ENTITIES');
    if(!verifyTables.get('LAYER')?.endTab||(hasBlockRecord&&!verifyTables.get('BLOCK_RECORD')?.endTab)||!verifyEntities)throw new Error('فشل التحقق البنيوي من DXF الناتج.');
    if(mappedBlockNames.size&&verifyBlocks.filter(d=>mappedBlockNames.has(d.name.toUpperCase())).length!==mappedBlockNames.size)throw new Error('لم يتم استيراد كل تعريفات البلوكات المصدرية.');
    let importedEntities=0;for(const p of dxfPairs(rewritten,newEnt.start,newEnt.end))if(p.code===0&&p.value.toUpperCase()!=='ENDSEC')importedEntities++;
  return {bytes:merged,sourceEntitiesBytes:entityBytes.length,importedEntities,importedBlocks:copied.BLOCKS.length,importedLayers:(copied.LAYER||[]).length,importedTableRecords:Object.fromEntries((hasBlockRecord?[...tablesToMerge,'BLOCK_RECORD']:tablesToMerge).map(n=>[n,(copied[n]||[]).length]))};
  }

  async function downloadBytes(bytes, filename, mime = 'application/dxf') {
    if (typeof root.safeDownloadFile === 'function') {
      const saved=await root.safeDownloadFile(bytes, filename, mime, false, true);
      if(saved===null||saved===undefined||String(saved).startsWith('ERROR:'))throw new Error('لم يؤكد نظام Android حفظ ملف DXF. أعد المحاولة واختر مجلد التنزيلات، ولم يتم إعلان نجاح غير مؤكد.');
      return saved;
    }
    const blob = new Blob([bytes], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = root.document.createElement('a'); a.href = url; a.download = filename; a.style.display = 'none';
    root.document.body.appendChild(a); a.click(); a.remove();
    root.setTimeout(() => URL.revokeObjectURL(url), 1000);
    return url;
  }

  async function downloadPairedRasterFile(bytes, filename, mime) {
    // The DXF and its IMAGEDEF raster must keep their exact names in one folder.
    // Android.saveFile writes directly to Downloads/SurveyQuant without a rename prompt.
    const native=root.Android;
    if(!native||typeof native.saveFile!=='function')return await downloadBytes(bytes,filename,mime);
    const blob=bytes instanceof Blob?bytes:new Blob([bytes],{type:mime});
    const base64=await new Promise((resolve,reject)=>{const reader=new root.FileReader();reader.onload=()=>resolve(String(reader.result||'').split(',')[1]||'');reader.onerror=()=>reject(reader.error||new Error('تعذر تجهيز ملف PDF المرجعي للحفظ.'));reader.readAsDataURL(blob);});
    let result;
    if(base64.length>700000&&typeof native.startChunkedFile==='function'){
      const token=native.startChunkedFile(filename,mime);if(String(token).startsWith('ERROR'))throw new Error(String(token));
      try{const chunkSize=262140;for(let i=0;i<base64.length;i+=chunkSize){const part=native.appendChunk(token,base64.slice(i,i+chunkSize));if(part!=='OK')throw new Error(String(part));}result=native.finishChunkedFile(token,filename,mime);}
      catch(error){try{native.cancelChunkedFile(token);}catch(_){}throw error;}
    }else result=native.saveFile(filename,mime,base64);
    if(/^ERROR(?:[: ]|$)/i.test(String(result)))throw new Error(String(result));
    if(typeof native.notifyDownload==='function'){try{native.notifyDownload(filename,String(result),mime);}catch(error){console.warn('PDF raster download notification failed',error);}}
    return result;
  }

  function makeRasterUnderlayDxf(imageName,width,height,factor=1){
    if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1)throw new Error('أبعاد صورة الصفحة غير صالحة.');
    if(!finite(factor)||factor<=0)throw new Error('عامل المقياس يجب أن يكون موجبًا.');
    // DXF IMAGE entities reference a raster sidecar. Keep a short, ASCII-only
    // basename so desktop and mobile CAD readers can resolve it beside the DXF.
    const requested=String(imageName||'SQ_PDF_PAGE.jpg').split(/[\\/]/).pop();
    const name=requested.replace(/[^A-Za-z0-9_.-]/g,'_').slice(0,120)||'SQ_PDF_PAGE.jpg';
    if(!/\.(?:png|jpe?g|bmp|tiff?)$/i.test(name))throw new Error('امتداد صورة PDF المرجعية غير مدعوم.');
    const fw=width*factor,fh=height*factor;
    if(!finite(fw)||!finite(fh)||fw<=0||fh<=0)throw new Error('أبعاد صورة الإخراج خارج النطاق.');
    const pairs=[
      '0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','9','$DWGCODEPAGE','3','ANSI_1252','9','$HANDSEED','5','35','0','ENDSEC',
      '0','SECTION','2','CLASSES',
      '0','CLASS','1','IMAGE','2','AcDbRasterImage','3','ISM','90','2175','280','0','281','1',
      '0','CLASS','1','IMAGEDEF','2','AcDbRasterImageDef','3','ISM','90','0','280','0','281','0',
      '0','CLASS','1','IMAGEDEF_REACTOR','2','AcDbRasterImageDefReactor','3','ISM','90','1','280','0','281','0',
      '0','CLASS','1','RASTERVARIABLES','2','AcDbRasterVariables','3','ISM','90','0','280','0','281','0','0','ENDSEC',
      '0','SECTION','2','TABLES',
      '0','TABLE','2','LTYPE','5','1','330','0','100','AcDbSymbolTable','70','1',
      '0','LTYPE','5','2','330','1','100','AcDbSymbolTableRecord','100','AcDbLinetypeTableRecord','2','CONTINUOUS','70','0','3','Solid line','72','65','73','0','40','0.0','0','ENDTAB',
      '0','TABLE','2','LAYER','5','3','330','0','100','AcDbSymbolTable','70','1',
      '0','LAYER','5','4','330','3','100','AcDbSymbolTableRecord','100','AcDbLayerTableRecord','2','0','70','0','62','7','6','CONTINUOUS','0','ENDTAB',
      '0','TABLE','2','BLOCK_RECORD','5','9','330','0','100','AcDbSymbolTable','70','1',
      '0','BLOCK_RECORD','5','17','330','9','100','AcDbSymbolTableRecord','100','AcDbBlockTableRecord','2','*Model_Space','70','0','0','ENDTAB','0','ENDSEC',
      '0','SECTION','2','BLOCKS',
      '0','BLOCK','5','18','330','17','100','AcDbEntity','8','0','100','AcDbBlockBegin','2','*Model_Space','70','0','10','0','20','0','30','0','3','*Model_Space','1','',
      '0','ENDBLK','5','19','330','17','100','AcDbEntity','8','0','100','AcDbBlockEnd','0','ENDSEC',
      '0','SECTION','2','ENTITIES',
      '0','IMAGE','5','33','330','17','100','AcDbEntity','8','0','100','AcDbRasterImage','90','0',
      '10','0','20','0','30','0','11',fmt(factor),'21','0','31','0','12','0','22',fmt(factor),'32','0',
      '13',String(width),'23',String(height),'340','32','70','3','280','0','281','50','282','50','283','0','360','34',
      '71','1','91','2','14','-0.5','24','-0.5','14',fmt(width-0.5),'24',fmt(height-0.5),'290','0','0','ENDSEC',
      '0','SECTION','2','OBJECTS',
      '0','DICTIONARY','5','A','330','0','100','AcDbDictionary','281','1','3','ACAD_IMAGE_VARS','350','30','3','ACAD_IMAGE_DICT','350','31',
      '0','RASTERVARIABLES','5','30','330','A','100','AcDbRasterVariables','90','0','70','0','71','1','72','3',
      '0','DICTIONARY','5','31','330','A','100','AcDbDictionary','281','1','3','PDF_PAGE','350','32',
      '0','IMAGEDEF','5','32','102','{ACAD_REACTORS','330','31','330','34','102','}','330','31','100','AcDbRasterImageDef',
      '90','0','1','.'+String.fromCharCode(92)+name,'10',String(width),'20',String(height),'11',fmt(factor),'21',fmt(factor),'280','1','281','0',
      '0','IMAGEDEF_REACTOR','5','34','330','33','100','AcDbRasterImageDefReactor','90','2','330','33',
      '0','ENDSEC','0','EOF',''
    ];
    return enc.encode(pairs.join('\r\n'));
  }
  // V169: one self-contained DXF, tiled into static OLE2FRAME/DIB objects.
  // Autodesk documents OLE2FRAME binary payloads in groups 90/310; per-frame
  // tiles stay near 1600x1200 to avoid the high-resolution OLE display issue.
  function makeEmbeddedRasterDxf(tileInput,width,height,factor=1){
    const tiles=Array.isArray(tileInput)?tileInput:[{bytes:tileInput,width,height,x:0,y:0}];
    if(!tiles.length)throw new Error('لا توجد أجزاء صورة لتضمينها في DXF.');
    if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width>32767||height>32767)
      throw new Error('أبعاد صورة الصفحة غير صالحة لعنصر OLE/DIB.');
    if(!finite(factor)||factor<=0)throw new Error('عامل المقياس يجب أن يكون موجبًا.');
    const le32=n=>{const a=new Uint8Array(4);new DataView(a.buffer).setUint32(0,Number(n)>>>0,true);return a;};
    const le16=n=>{const a=new Uint8Array(2);new DataView(a.buffer).setUint16(0,Number(n)>>>0,true);return a;};
    const join=parts=>{const total=parts.reduce((v,p)=>v+p.length,0),out=new Uint8Array(total);let at=0;for(const p of parts){out.set(p,at);at+=p.length;}return out;};
    const framePairs=[];let handle=0x10;
    for(const tile of tiles){
      const image=tile.bytes instanceof Uint8Array?tile.bytes:new Uint8Array(tile.bytes);
      const tw=Number(tile.width),th=Number(tile.height),tx=Number(tile.x)||0,ty=Number(tile.y)||0;
      if(!image.length||image[0]!==0xff||image[1]!==0xd8||image[image.length-2]!==0xff||image[image.length-1]!==0xd9)
        throw new Error('بيانات JPEG المضمنة غير صالحة.');
      if(!Number.isInteger(tw)||!Number.isInteger(th)||tw<1||th<1||tw>1600||th>1200)
        throw new Error('يجب ألا يتجاوز جزء OLE الواحد 1600 × 1200 بكسل.');
      if(!Number.isInteger(tx)||!Number.isInteger(ty)||tx<0||ty<0||tx+tw>width||ty+th>height)
        throw new Error('موضع جزء الصورة خارج حدود الصفحة.');
      const fw=tw*factor,fh=th*factor;
      if(!finite(fw)||!finite(fh)||fw<=0||fh<=0||fw>1e12||fh>1e12)throw new Error('أبعاد إخراج DXF خارج النطاق المسموح.');
      const ansiName=enc.encode('DIB\0');
      // BITMAPINFOHEADER with BI_JPEG (4); JPEG bytes are carried in this DIB.
      const himetricW=Math.max(1,Math.min(0x7fffffff,Math.round(tw*25.4/96*100)));
      const himetricH=Math.max(1,Math.min(0x7fffffff,Math.round(th*25.4/96*100)));
      const dibHeader=join([le32(40),le32(tw),le32(th),le16(1),le16(0),le32(4),le32(image.length),le32(3780),le32(3780),le32(0),le32(0)]);
      const dib=join([dibHeader,image]);
      // OLE1 StandardPresentationObject: version 0x501, FormatID 5, DIB class.
      const ole=join([le32(0x501),le32(5),le32(ansiName.length),ansiName,
        le32(himetricW),le32((0x100000000-himetricH)>>>0),le32(dib.length),dib]);
      const x0=tx*factor,yTop=(height-ty)*factor,x1=(tx+tw)*factor,yBottom=(height-ty-th)*factor;
      framePairs.push('0','OLE2FRAME','5',handle.toString(16).toUpperCase(),'100','AcDbEntity','8','0','100','AcDbOle2Frame','70','2','3','Paintbrush Picture',
        '10',fmt(x0),'20',fmt(yTop),'30','0','11',fmt(x1),'21',fmt(yBottom),'31','0','71','3','72','0','90',String(ole.length));
      for(let i=0;i<ole.length;i+=127){let hex='';for(let j=i;j<Math.min(i+127,ole.length);j++)hex+=ole[j].toString(16).padStart(2,'0');framePairs.push('310',hex);}
      framePairs.push('1','OLE');handle++;
    }
    const pairs=[
      '0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','9','$DWGCODEPAGE','3','ANSI_1252','9','$INSBASE','10','0','20','0','30','0','9','$HANDSEED','5',handle.toString(16).toUpperCase(),'0','ENDSEC',
      '0','SECTION','2','TABLES',
      '0','TABLE','2','LTYPE','5','1','100','AcDbSymbolTable','70','1','0','LTYPE','5','2','100','AcDbSymbolTableRecord','100','AcDbLinetypeTableRecord','2','CONTINUOUS','70','0','3','Solid line','72','65','73','0','40','0.0','0','ENDTAB',
      '0','TABLE','2','LAYER','5','3','100','AcDbSymbolTable','70','1','0','LAYER','5','4','100','AcDbSymbolTableRecord','100','AcDbLayerTableRecord','2','0','70','0','62','7','6','CONTINUOUS','0','ENDTAB',
      '0','ENDSEC','0','SECTION','2','ENTITIES',...framePairs,'0','ENDSEC','0','EOF',''
    ];
    return enc.encode(pairs.join('\r\n'));
  }
  async function canvasJpegBytes(canvas,quality=0.96){
    if(canvas.toBlob){const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('تعذر إخراج صورة JPEG المضمنة.')),'image/jpeg',quality));return new Uint8Array(await blob.arrayBuffer());}
    const url=canvas.toDataURL('image/jpeg',quality),b64=url.slice(url.indexOf(',')+1),raw=atob(b64),out=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;
  }
  async function canvasJpegTiles(canvas,maxTileWidth=1600,maxTileHeight=1200,quality=0.97){
    const tiles=[];
    for(let y=0;y<canvas.height;y+=maxTileHeight){
      for(let x=0;x<canvas.width;x+=maxTileWidth){
        const width=Math.min(maxTileWidth,canvas.width-x),height=Math.min(maxTileHeight,canvas.height-y);
        const tileCanvas=document.createElement('canvas');tileCanvas.width=width;tileCanvas.height=height;
        const tileContext=tileCanvas.getContext('2d');if(!tileContext)throw new Error('تعذر إنشاء جزء صورة PDF.');
        tileContext.drawImage(canvas,x,y,width,height,0,0,width,height);
        const bytes=await canvasJpegBytes(tileCanvas,quality);tiles.push({bytes,width,height,x,y});
        tileCanvas.width=1;tileCanvas.height=1;
      }
    }
    return tiles;
  }
  function fingerprintBytes(bytes){const a=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);let h=2166136261;for(let i=0;i<a.length;i++)h=Math.imul(h^a[i],16777619)>>>0;return a.length+':'+h.toString(16).padStart(8,'0');}
  function fileFingerprint(file,bytes){
    const data=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);let a=0x811c9dc5,b=0x9e3779b9;
    for(let i=0;i<data.length;i++){a=Math.imul(a^data[i],0x01000193)>>>0;b=Math.imul(b^(data[i]+i),0x85ebca6b)>>>0;}
    return `${String(file?.name||'').toLowerCase()}|${data.length}|${Number(file?.lastModified)||0}|${a.toString(16).padStart(8,'0')}${b.toString(16).padStart(8,'0')}`;
  }
  function createOrientedDxfBytes(rawBytes,picks){
    if(!Array.isArray(picks)||picks.length!==4||!picks.every(p=>p&&finite(p.x)&&finite(p.y)))throw new Error('أربع نقاط توجيه صالحة مطلوبة لحفظ اللوحة.');
    rejectIdentityAlignment(picks);
    return transformDxfBytes(rawBytes,picks[0],picks[1],picks[2],picks[3]);
  }
  function crc32(bytes){let c=0xffffffff;for(let i=0;i<bytes.length;i++){c^=bytes[i];for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;}
  function zipStore(entries){
    const enc8=new TextEncoder(),locals=[],centrals=[];let offset=0;
    const u16=n=>new Uint8Array([n&255,(n>>>8)&255]);
    const u32=n=>new Uint8Array([n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]);
    const join=parts=>{const size=parts.reduce((n,p)=>n+p.length,0),out=new Uint8Array(size);let p=0;for(const x of parts){out.set(x,p);p+=x.length;}return out;};
    for(const entry of entries){const name=enc8.encode(String(entry.name)),data=entry.data instanceof Uint8Array?entry.data:new Uint8Array(entry.data),crc=crc32(data);if(!name.length||name.length>65535)throw new Error('اسم ملف داخل الحزمة غير صالح.');
      const local=join([u32(0x04034b50),u16(20),u16(0x0800),u16(0),u16(0),u16(33),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),name,data]);locals.push(local);
      const central=join([u32(0x02014b50),u16(20),u16(20),u16(0x0800),u16(0),u16(0),u16(33),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),name]);centrals.push(central);offset+=local.length;
    }
    const centralBytes=join(centrals),localBytes=join(locals),end=join([u32(0x06054b50),u16(0),u16(0),u16(entries.length),u16(entries.length),u32(centralBytes.length),u32(localBytes.length),u16(0)]);
    return join([localBytes,centralBytes,end]);
  }
  async function canvasPngBytes(canvas){
    if(canvas.toBlob){const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('تعذر إخراج PNG من معاينة الصفحة.')),'image/png'));return new Uint8Array(await blob.arrayBuffer());}
    const url=canvas.toDataURL('image/png'),b64=url.slice(url.indexOf(',')+1),raw=atob(b64),out=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;
  }


  function ensurePdfWorker(lib,doc){
    if(!lib||!lib.GlobalWorkerOptions)throw new Error('إعداد عامل PDF.js غير متاح في هذه النسخة.');
    let workerUrl=root.__sq176PdfWorkerUrl||'';
    if(!workerUrl){
      const node=doc.getElementById('sq163-pdfjs-worker');
      const base64=(node?.textContent||'').trim();
      if(!base64)throw new Error('ملف عامل PDF.js المضمّن غير موجود داخل التطبيق.');
      const raw=atob(base64),bytes=new Uint8Array(raw.length);
      for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
      workerUrl=URL.createObjectURL(new Blob([bytes],{type:'text/javascript'}));
      root.__sq176PdfWorkerUrl=workerUrl;
      root.addEventListener?.('pagehide',()=>{try{URL.revokeObjectURL(workerUrl);}catch(_){}},{once:true});
    }
    lib.GlobalWorkerOptions.workerSrc=workerUrl;
    return workerUrl;
  }

  function readStoredZipBytes(input){
    const bytes=input instanceof Uint8Array?input:new Uint8Array(input),view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),entries=new Map();let offset=0;
    while(offset+4<=bytes.length){const sig=view.getUint32(offset,true);if(sig===0x02014b50||sig===0x06054b50)break;if(sig!==0x04034b50)throw new Error('حزمة ZIP غير صالحة أو تالفة.');
      const flags=view.getUint16(offset+6,true),method=view.getUint16(offset+8,true),size=view.getUint32(offset+18,true),nameLen=view.getUint16(offset+26,true),extraLen=view.getUint16(offset+28,true);
      if((flags&8)!==0)throw new Error('حزمة ZIP تستخدم data descriptor غير مدعوم.');if(method!==0)throw new Error('هذه الأداة تقبل حزمة PDF-to-DXF المضغوطة بصيغة STORE فقط.');
      const nameStart=offset+30,nameEnd=nameStart+nameLen,dataStart=nameEnd+extraLen,dataEnd=dataStart+size;if(dataEnd>bytes.length)throw new Error('بيانات داخل ZIP مبتورة.');
      const name=new TextDecoder('utf-8').decode(bytes.subarray(nameStart,nameEnd));entries.set(name.toLowerCase(),{name,bytes:bytes.subarray(dataStart,dataEnd)});offset=dataEnd;
    }
    if(!entries.size)throw new Error('ملف ZIP لا يحتوي ملفات قابلة للقراءة.');return entries;
  }
  function rasterImageRecord(dxfBytes){
    const records=[];let rec=null;
    forEachPair(dxfBytes,p=>{if(p.code===0){if(rec)records.push(rec);rec={type:p.value.toUpperCase(),values:Object.create(null)};return;}if(rec){if(!rec.values[p.code])rec.values[p.code]=[];rec.values[p.code].push(p.value);}});if(rec)records.push(rec);
    const defs=new Map();for(const r of records)if(r.type==='IMAGEDEF'){const v=r.values,h=String((v[5]||[])[0]||'');defs.set(h,{filename:String((v[1]||[])[0]||''),width:Number((v[10]||[])[0]),height:Number((v[20]||[])[0])});}
    const image=records.find(r=>r.type==='IMAGE');if(!image)return null;const v=image.values,def=defs.get(String((v[340]||[])[0]||''));if(!def)return null;
    const vec=(base)=>({x:Number((v[base]||[])[0]||0),y:Number((v[base+10]||[])[0]||0)}),insert=vec(10),u=vec(11),vv=vec(12),width=Number((v[13]||[])[0]||def.width),height=Number((v[23]||[])[0]||def.height);
    if(![insert.x,insert.y,u.x,u.y,vv.x,vv.y,width,height].every(finite)||width<1||height<1)return null;
    return{filename:def.filename,insert,u,v:vv,width,height};
  }
  function buildRasterGeometry(record,image,url){
    const {insert,u,v,width,height}=record,corners=[insert,{x:insert.x+u.x*width,y:insert.y+u.y*width},{x:insert.x+v.x*height,y:insert.y+v.y*height},{x:insert.x+u.x*width+v.x*height,y:insert.y+u.y*width+v.y*height}],xs=corners.map(p=>p.x),ys=corners.map(p=>p.y);
    return{segments:[],points:[],texts:[],curves:[],raster:{image,url,insert,u,v,width,height},minX:Math.min(...xs),maxX:Math.max(...xs),minY:Math.min(...ys),maxY:Math.max(...ys)};
  }
  async function loadRasterZip(file,sourceBytes){
    const entries=readStoredZipBytes(sourceBytes instanceof Uint8Array?sourceBytes:await file.arrayBuffer()),dxfEntry=[...entries.values()].find(e=>/\.dxf$/i.test(e.name)),pngEntries=[...entries.values()].filter(e=>/\.png$/i.test(e.name));if(!dxfEntry)throw new Error('حزمة PDF-to-DXF لا تحتوي ملف DXF.');
    const record=rasterImageRecord(dxfEntry.bytes);if(!record)throw new Error('ملف DXF لا يحتوي مرجع IMAGE/IMAGEDEF صالحًا.');
    const base=record.filename.replace(/^.*[\\/]/,'').replace(/^\.\//,'').toLowerCase(),png=entries.get(base)||pngEntries.find(e=>e.name.toLowerCase()===base);if(!png)throw new Error('الصورة المرجعية غير موجودة داخل ZIP. فك الحزمة من جديد أو أعد تصدير PDF-to-DXF.');
    const url=root.URL.createObjectURL(new Blob([png.bytes],{type:'image/png'})),image=new root.Image();try{await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(new Error('تعذر تحميل صورة PDF المرفقة داخل ZIP.'));image.src=url;});}catch(e){root.URL.revokeObjectURL(url);throw e;}
    return{dxfBytes:dxfEntry.bytes,geom:buildRasterGeometry(record,image,url),rasterUrl:url};
  }

  function mount() {
    if (!root.document || root.document.getElementById('sq176-cad-project-host')) return;
    const doc = root.document;
    const style = doc.createElement('style');
    style.id = 'sq162-cad-style';
    style.textContent = `
      #sq176-cad-project-host{display:none}body.project-mode #sq176-cad-project-host{display:contents!important}body.project-mode #sq176-cad-project-host .project-card{display:none}body.project-mode #sq176-cad-project-host .project-card.active-project{display:block!important}.sq162-section{display:block!important}.sq176-project-card{width:100%;}
      #sq162-cad-dialog{width:min(100%,920px);max-height:88vh;overflow:auto;overscroll-behavior:contain;background:#fff;border-radius:16px;padding:14px;box-sizing:border-box;direction:rtl;box-shadow:0 12px 55px #0006}
      #sq162-cad-dialog *{box-sizing:border-box} .sq162-head{display:flex;justify-content:space-between;align-items:center;gap:10px;border-bottom:1px solid #ddd;padding-bottom:10px;margin-bottom:10px}
      .sq162-actions{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.sq162-btn{border:0;border-radius:9px;padding:10px 13px;background:#155fa8;color:#fff;font-weight:700;font-size:13px}.sq162-btn:disabled{opacity:.45}.sq162-secondary{background:#e9eef4;color:#22313f}.sq162-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}#sq162-cad-dialog [data-board-panel]{display:none!important}#sq162-cad-dialog [data-board-panel].active{display:block!important}.sq162-panel{border:1px solid #d9e0e7;border-radius:11px;padding:10px;min-width:0}.sq162-panel label{display:block;font-size:13px;font-weight:700;margin-bottom:6px}.sq162-panel input[type=file]{width:100%;font-size:12px}.sq162-canvas{display:block;width:100%;height:300px;max-height:38vh;background:#fbfcfe;border:1px solid #e0e5eb;border-radius:7px;margin-top:8px;touch-action:none;cursor:grab;user-select:none}.sq162-view-tools{display:flex;align-items:center;gap:5px;flex-wrap:wrap;margin-top:8px}.sq162-view-tools .sq162-btn{padding:9px 13px;min-width:46px;min-height:42px}.sq162-zoom-value{font:600 11px system-ui;color:#34495e;min-width:42px;text-align:center}.sq162-pick-step.active{background:#15945c;color:#fff}.sq162-pick-step.completed{border-color:#15945c;color:#116b42}.sq162-pick-panel{display:grid;gap:6px;margin-top:8px;padding:8px;background:#f4f7fa;border-radius:8px}.sq162-pick-actions{display:flex;gap:6px;flex-wrap:wrap}.sq162-pick-actions .sq162-btn{flex:1;min-width:130px}.sq162-zoom-slider{flex:1;min-width:85px;max-width:190px;accent-color:#155fa8;touch-action:pan-x}.sq162-snap-mode{max-width:170px;min-width:120px;padding:6px;border:1px solid #ccd5de;border-radius:8px;background:#fff;color:#1c2b38;font-size:11px}.sq162-note{font-size:12px;line-height:1.6;color:#465566}.sq162-status{padding:9px;border-radius:8px;background:#eef5fb;white-space:pre-wrap;font-size:13px;line-height:1.6;margin:8px 0}#sq162-transform-details{background:#f1f6fb;border:1px solid #d5e2ee;color:#18344c;font-family:ui-monospace,monospace;font-size:12px;direction:rtl}.sq162-tabs{display:flex;gap:7px;margin:6px 0 12px}.sq162-tab{border-radius:8px;padding:8px 11px;background:#e8edf2;color:#243342;border:0;font-weight:700}.sq162-tab.active{background:#155fa8;color:#fff}.sq162-section{display:none}.sq162-section.active{display:block}.sq162-scale{width:110px;max-width:35%;padding:8px;border:1px solid #c7d0da;border-radius:7px;direction:ltr}
      @media(max-width:650px){#sq162-cad-dialog{padding:9px;max-height:88vh}.sq162-grid{grid-template-columns:1fr}.sq162-canvas{height:245px;max-height:31vh}.sq162-head h3{font-size:16px}}
    `;
    doc.head.appendChild(style);
    const overlay = doc.createElement('div'); overlay.id = 'sq176-cad-project-host';
    overlay.innerHTML = `
      <div id="sq162-cad-dialog" role="dialog" aria-modal="true" aria-label="توجيه اللوحات">
        <section id="sq162-tab-align" class="sq162-section active">
          <div class="sq162-note">اختر ملف DWG أو DXF. بعد التوجيه استخدم زر حفظ DXF لإنشاء نسخة جديدة بالإحداثيات الموجهة، مع بقاء ملف المصدر كما هو. ملاحظة: هذه معاينة للعناصر التي يستطيع محرك القراءة الحالي تفسيرها، وليست عارضًا كاملًا لكل كائنات DWG المتخصصة أو Proxy Objects. إذا لم يستطع المحرك قراءة عناصر الرسم، ستظهر رسالة بدل عرض نقاط منفصلة على أنها لوحة.</div>
          <div class="sq162-board-switch" role="tablist" aria-label="اختيار اللوحة المعروضة"><button type="button" class="sq162-tab active" data-sq-board-tab="source" role="tab" aria-selected="true">اللوحة غير الموجهة</button><button type="button" class="sq162-tab" data-sq-board-tab="target" role="tab" aria-selected="false">اللوحة المرجعية الموجهة</button></div><div class="sq162-grid sq162-board-panels" style="margin-top:10px">
            <div class="sq162-panel sq162-board-panel active" data-board-panel="source"><label id="sq162-source-title" for="sq162-source-file">اللوحة غير الموجهة (DWG / DXF)</label><input id="sq162-source-file" type="file" accept=".dwg,.dxf,.zip,application/dxf,application/zip,application/octet-stream"><div class="sq162-view-tools" data-sq-view="source"><button class="sq162-btn sq162-secondary" data-sq-zoom="in" type="button" aria-label="تكبير داخل اللوحة">＋</button><button class="sq162-btn sq162-secondary" data-sq-zoom="out" type="button" aria-label="تصغير داخل اللوحة">−</button><button class="sq162-btn sq162-secondary" data-sq-zoom="fit" type="button">احتواء</button><input class="sq162-zoom-slider" type="range" min="0.2" max="100" step="0.1" value="1" aria-label="مستوى تكبير اللوحة"><span class="sq162-zoom-value">100%</span></div><canvas id="sq162-source-canvas" class="sq162-canvas" aria-label="معاينة اللوحة غير الموجهة"></canvas><div id="sq162-source-info" class="sq162-note">لم يتم اختيار ملف بعد.</div><div class="sq162-pick-panel" aria-label="اختيار نقاط اللوحة"><label>اختيار نقاط هذه اللوحة</label><div class="sq162-pick-actions"><button id="sq162-pick-0" class="sq162-btn sq162-secondary sq162-pick-step" data-pick-stage="0" type="button" disabled>اختيار النقطة الأولى</button><button id="sq162-pick-1" class="sq162-btn sq162-secondary sq162-pick-step" data-pick-stage="1" type="button" disabled>اختيار النقطة الثانية</button></div><select class="sq162-snap-mode" aria-label="نوع الالتقاط" data-sq-snap="source"><option value="intersection">التقاطع</option><option value="endpoint">نهاية عنصر</option><option value="midpoint">منتصف عنصر</option><option value="nearest">أقرب نقطة</option></select></div></div>
            <div class="sq162-panel sq162-board-panel" data-board-panel="target" hidden style="display:none"><label for="sq162-target-file">اللوحة المرجعية الموجهة (DWG / DXF)</label><input id="sq162-target-file" type="file" accept=".dwg,.dxf,.zip,application/dxf,application/zip,application/octet-stream"><div class="sq162-view-tools" data-sq-view="target"><button class="sq162-btn sq162-secondary" data-sq-zoom="in" type="button" aria-label="تكبير داخل اللوحة">＋</button><button class="sq162-btn sq162-secondary" data-sq-zoom="out" type="button" aria-label="تصغير داخل اللوحة">−</button><button class="sq162-btn sq162-secondary" data-sq-zoom="fit" type="button">احتواء</button><input class="sq162-zoom-slider" type="range" min="0.2" max="100" step="0.1" value="1" aria-label="مستوى تكبير اللوحة"><span class="sq162-zoom-value">100%</span></div><canvas id="sq162-target-canvas" class="sq162-canvas" aria-label="معاينة اللوحة المرجعية"></canvas><div id="sq162-target-info" class="sq162-note">لم يتم اختيار ملف بعد.</div><div class="sq162-pick-panel" aria-label="اختيار نقاط اللوحة"><label>اختيار نقاط هذه اللوحة</label><div class="sq162-pick-actions"><button id="sq162-pick-2" class="sq162-btn sq162-secondary sq162-pick-step" data-pick-stage="2" type="button" disabled>اختيار النقطة الأولى</button><button id="sq162-pick-3" class="sq162-btn sq162-secondary sq162-pick-step" data-pick-stage="3" type="button" disabled>اختيار النقطة الثانية</button></div><select class="sq162-snap-mode" aria-label="نوع الالتقاط" data-sq-snap="target"><option value="intersection">التقاطع</option><option value="endpoint">نهاية عنصر</option><option value="midpoint">منتصف عنصر</option><option value="nearest">أقرب نقطة</option></select></div></div>
          </div>
          <div class="sq162-actions" id="sq162-project-actions"><button id="sq162-do-align" class="sq162-btn" type="button" disabled>توجيه اللوحة على المرجع</button><button id="sq162-save-oriented" class="sq162-btn" type="button" disabled>حفظ اللوحة الموجهة DXF</button><button id="sq162-reset-picks" class="sq162-btn sq162-secondary" type="button" disabled>إلغاء التوجيه</button></div>
          <div id="sq162-transform-details" class="sq162-status" aria-live="polite">بيانات التوجيه: اختر النقاط بالترتيب. سيتم عرض اتجاه كل خط والدوران والإزاحة قبل اعتماد التحويل.</div>
          <div id="sq162-align-status" class="sq162-status" aria-live="polite">اختر اللوحتين ثم حدد النقاط الأربع يدويًا. بعد نجاح التوجيه استخدم زر «حفظ اللوحة الموجهة DXF» لإنشاء ملف مستقل دون تعديل ملف المصدر.</div>
        </section>
        <section id="sq162-tab-raster" class="sq162-section">
          <div class="sq162-note">يُنشأ ملف DXF هندسي واحد فقط من المسارات المتجهية والنصوص القابلة للاستخراج. لا يتم تصدير صور أو إرفاقها داخل DXF، ولا يتم تتبع الصفحة أو إعادة رسمها. إذا احتوت الصفحة صورًا نقطية أو تعبئات/تدرجات أو أنماط خطوط لا يمكن تمثيلها بدقة، يتوقف التحويل ويشرح السبب بدل إخراج لوحة ناقصة.</div>
          <div class="sq162-panel" style="margin-top:10px"><label for="sq162-raster-file">اختر ملف PDF فقط</label><input id="sq162-raster-file" type="file" accept=".pdf,application/pdf"><label for="sq162-pdf-page" style="margin-top:9px">رقم صفحة PDF</label><input id="sq162-pdf-page" type="number" min="1" step="1" value="1" class="sq162-scale"><label for="sq162-raster-scale" style="margin-top:9px">عامل المقياس (وحدة رسم لكل وحدة PDF/بكسل)</label><input id="sq162-raster-scale" type="number" min="0.000001" step="any" value="1" class="sq162-scale"><div class="sq162-actions"><button id="sq162-trace" class="sq162-btn" type="button" disabled>استخراج خطوط CAD وحفظ DXF</button></div><div id="sq162-raster-status" class="sq162-status" aria-live="polite">اختر ملفًا للبدء.</div><canvas id="sq162-raster-canvas" class="sq162-canvas" style="display:none" aria-label="معاينة الصورة قبل التحويل"></canvas></div>
        </section>
        <div class="sq162-note" style="margin-top:10px">لا يُستخدم localStorage أو قاعدة بيانات لحفظ اللوحات. يتم حفظ اللوحة الموجهة كملف DXF جديد في التنزيلات، بينما يظل ملف المصدر الأصلي دون تغيير.</div>
      </div>`;
    // V176: expose orientation and PDF as two independent first-class project cards.
    const dialog=overlay.querySelector('#sq162-cad-dialog');
    const alignSection=overlay.querySelector('#sq162-tab-align');
    const pdfSection=overlay.querySelector('#sq162-tab-raster');
    if(!dialog||!alignSection||!pdfSection)throw new Error('V176 project sections are incomplete.');
    const orientationCard=doc.createElement('div');orientationCard.id='sqOrientationCard';orientationCard.className='card project-card sq176-project-card';
    const orientationTitle=doc.createElement('h3');orientationTitle.textContent='📐 9. توجيه اللوحات';orientationCard.appendChild(orientationTitle);alignSection.classList.add('active');orientationCard.appendChild(alignSection);
    const pdfCard=doc.createElement('div');pdfCard.id='sqPdfDxfCard';pdfCard.className='card project-card sq176-project-card';
    const pdfTitle=doc.createElement('h3');pdfTitle.textContent='📄 10. تحويل PDF إلى DXF فقط';pdfCard.appendChild(pdfTitle);pdfSection.classList.add('active');pdfCard.appendChild(pdfSection);
    dialog.replaceChildren(orientationCard,pdfCard);dialog.style.cssText='width:100%;max-height:none;overflow:visible;background:transparent;border-radius:0;padding:0;box-shadow:none;direction:rtl';overlay.style.display='none';
    const projectContainer=doc.querySelector('.container')||doc.body;projectContainer.appendChild(overlay);
    const homeGrid=doc.querySelector('#homeMenu .home-menu');
    if(homeGrid){
      const addProjectButton=(id,label,cardId)=>{if(doc.getElementById(id))return;const b=doc.createElement('button');b.id=id;b.type='button';b.className='menu-btn';b.textContent=label;b.addEventListener('click',()=>{if(typeof root.openProjectPage==='function')root.openProjectPage(cardId);else{doc.body.classList.add('project-mode');orientationCard.classList.toggle('active-project',cardId==='sqOrientationCard');pdfCard.classList.toggle('active-project',cardId==='sqPdfDxfCard');}});homeGrid.appendChild(b);};
      addProjectButton('sq176-home-orientation-project','📐 9 توجيه اللوحات','sqOrientationCard');
      addProjectButton('sq176-home-pdf-project','📄 10 تحويل PDF إلى DXF','sqPdfDxfCard');
    }
    doc.addEventListener('click',e=>{const back=e.target&&e.target.closest?e.target.closest('.project-back'):null;if(back&&(orientationCard.classList.contains('active-project')||pdfCard.classList.contains('active-project')))cleanup();},true);
    const el = id => doc.getElementById(id);
    const state = { source: null, target: null, activeBoardSide:'source', loadSerial:{source:0,target:0}, pickStage: -1, picks: [null,null,null,null], lastAlignmentDiagnostics:null, tracerFile: null, rasterCanvas: null, views: {source:{zoom:1,panX:0,panY:0,centerX:null,centerY:null},target:{zoom:1,panX:0,panY:0,centerX:null,centerY:null}}, snapModes:{source:'intersection',target:'intersection'}, hover:{source:null,target:null} };
    function status(text, id = 'sq162-align-status') { const node=el(id);if(node)node.textContent=text; }
    function setSourceBoardMode(oriented){
      const sourceTab=overlay.querySelector('[data-sq-board-tab="source"]');
      const targetTab=overlay.querySelector('[data-sq-board-tab="target"]');
      const sourceTitle=el('sq162-source-title');
      if(sourceTab)sourceTab.textContent=oriented?'اللوحة الموجهة الناتجة':'اللوحة غير الموجهة';
      if(sourceTitle)sourceTitle.textContent=oriented?'اللوحة الموجهة الناتجة (نفس ملف المصدر بعد تحويل الإحداثيات)':'اللوحة غير الموجهة (DWG / DXF)';
      if(targetTab){targetTab.hidden=!!oriented;targetTab.style.display=oriented?'none':'';targetTab.setAttribute('aria-hidden',oriented?'true':'false');}
    }
    function activateBoardPanel(which){
      if(which!=='source'&&which!=='target')return;
      if(which==='target'&&overlay.querySelector('[data-sq-board-tab="target"]')?.hidden)return;
      state.activeBoardSide=which;
      for(const panel of overlay.querySelectorAll('[data-board-panel]')){const active=panel.dataset.boardPanel===which;panel.classList.toggle('active',active);panel.hidden=!active;panel.style.display=active?'block':'none';panel.setAttribute('aria-hidden',active?'false':'true');}
      for(const tab of overlay.querySelectorAll('[data-sq-board-tab]')){const active=tab.dataset.sqBoardTab===which;tab.classList.toggle('active',active);tab.setAttribute('aria-selected',active?'true':'false');}
      const raf=root.requestAnimationFrame||((fn)=>root.setTimeout(fn,16));raf(()=>redrawOne(which));
    }
    for(const tab of overlay.querySelectorAll('[data-sq-board-tab]'))tab.addEventListener('click',()=>activateBoardPanel(tab.dataset.sqBoardTab));
    function fileTitle(file) { return file && file.name ? file.name : 'drawing'; }
    function clearCanvas(canvas) { const c = canvas.getContext('2d'); c.clearRect(0, 0, canvas.width, canvas.height); }
    function invalidateAlignmentBecauseBoardChanged(changed){
      state.picks=[null,null,null,null];state.lastAlignmentDiagnostics=null;state.pickStage=-1;state.hover={source:null,target:null};setSourceBoardMode(false);
      if(state.source){state.source.alignment=null;state.source.transform=null;state.source.viewGeom=null;const g=state.source.geom;state.views.source={zoom:1,panX:0,panY:0,centerX:(g.minX+g.maxX)/2,centerY:(g.minY+g.maxY)/2};}
      for(const side of ['source','target'])if(state[side]){const g=state[side].geom;state.views[side]={zoom:1,panX:0,panY:0,centerX:(g.minX+g.maxX)/2,centerY:(g.minY+g.maxY)/2};const c=el(`sq162-${side}-canvas`);if(c)c._sqMap=null;}
      updatePickUi();
    }
    function clearDrawing(which) {
      state.loadSerial[which]=(state.loadSerial[which]||0)+1;
      if(state[which]?.rasterUrl)try{root.URL.revokeObjectURL(state[which].rasterUrl);}catch(_){}
      if(state[which]?.rasterUrls)for(const u of state[which].rasterUrls)try{root.URL.revokeObjectURL(u);}catch(_){}
      state[which]=null;state.lastAlignmentDiagnostics=null;state.pickStage=-1;state.picks=[null,null,null,null];state.hover={source:null,target:null};setSourceBoardMode(false);
      if(state.source){state.source.alignment=null;state.source.transform=null;state.source.viewGeom=null;}
      for(const side of ['source','target']){const prefix=side==='source'?'source':'target',canvas=el(`sq162-${prefix}-canvas`);if(side===which){const input=el(`sq162-${prefix}-file`),info=el(`sq162-${prefix}-info`);if(input)input.value='';if(info)info.textContent='لم يتم اختيار ملف بعد.';if(canvas){canvas._sqMap=null;clearCanvas(canvas);}}}
      if(state.activeBoardSide===which&&state[which=== 'source'?'target':'source'])activateBoardPanel(which==='source'?'target':'source');
      updatePickUi();
    }
    function cleanup() {
      clearDrawing('source'); clearDrawing('target');
      state.tracerFile = null; state.rasterCanvas = null;
      el('sq162-raster-file').value = ''; el('sq162-pdf-page').value = '1'; el('sq162-raster-scale').value = '1';
      const preview=el('sq162-raster-canvas');if(preview){preview.style.display='none';clearCanvas(preview);preview.width=1;preview.height=1;}
      const exportBtn=el('sq162-trace');if(exportBtn)exportBtn.disabled=true;setSourceBoardMode(false);state.activeBoardSide='source';activateBoardPanel('source');state.picks=[null,null,null,null];state.lastAlignmentDiagnostics=null;state.pickStage=-1;status('تم إنهاء الجلسة ومسح اللوحتين والنقاط والبيانات المؤقتة.');
      status('اختر ملف PDF للبدء.', 'sq162-raster-status');
    }
    if(!root.__sq187ProjectNavWrapped){
      const originalOpen=root.openProjectPage,originalClose=root.closeProjectPage;
      if(typeof originalOpen==='function')root.openProjectPage=function(id,...args){if((orientationCard.classList.contains('active-project')&&id!=='sqOrientationCard')||(pdfCard.classList.contains('active-project')&&id!=='sqPdfDxfCard'))cleanup();return originalOpen.call(this,id,...args);};
      if(typeof originalClose==='function')root.closeProjectPage=function(...args){if(orientationCard.classList.contains('active-project')||pdfCard.classList.contains('active-project'))cleanup();return originalClose.apply(this,args);};
      root.__sq187ProjectNavWrapped=true;
    }
    function refreshTransformDetails(){
      const box=el('sq162-transform-details');if(!box)return;
      const names=['المصدر 1','المصدر 2','المرجع 1','المرجع 2'];
      const livePicked=state.picks.every(Boolean);
      const saved=state.lastAlignmentDiagnostics;
      const displayPicks=livePicked?state.picks:(saved?[saved.sourceA,saved.sourceB,saved.targetA,saved.targetB]:state.picks);
      const lines=[`ملف المصدر: ${state.source?.file?.name||'لم يتم تحميله'} | بصمة: ${state.source?.fingerprint?.slice(-12)||'-'}`,`ملف المرجع: ${state.target?.file?.name||'لم يتم تحميله'} | بصمة: ${state.target?.fingerprint?.slice(-12)||'-'}`,...displayPicks.map((p,i)=>`${names[i]}: ${p?`X=${fmt(Number(p.x))} | Y=${fmt(Number(p.y))} | الملف=${p.boardFileName||'-'} | ${p.boardSide||'-'}`:'لم تُحدد بعد'}`)];
      const d=livePicked?alignmentDiagnostics(state.picks):saved;
      if(d){
        lines.push('',`خط المصدر: ΔX=${fmt(d.sourceDelta.x)} | ΔY=${fmt(d.sourceDelta.y)} | الطول=${fmt(d.sourceLength)} | الاتجاه=${fmt(d.sourceBearingDegrees)}°`,`خط المرجع: ΔX=${fmt(d.targetDelta.x)} | ΔY=${fmt(d.targetDelta.y)} | الطول=${fmt(d.targetLength)} | الاتجاه=${fmt(d.targetBearingDegrees)}°`,`الدوران المحسوب: ${fmt(d.rotationDegrees)}° | المقياس: ${fmt(d.scale)}`,`الإزاحة: ΔX=${fmt(d.translationX)} | ΔY=${fmt(d.translationY)}`,`خطأ المطابقة: ${fmt(Math.max(d.residualA,d.residualB))}`);
        if(Math.abs(d.rotationDegrees)<0.01)lines.push('تنبيه: اتجاه خط المصدر والمرجع متقارب جدًا، لذلك الدوران قريب من الصفر. راجع أن كل نقطة مرجعية تقابل النقطة نفسها في المصدر.');
        if(saved&&!livePicked)lines.push('تم اعتماد هذا التحويل. أُبقيت بياناته ظاهرة حتى إعادة اختيار النقاط أو تحميل لوحة أخرى.');
      }else{
        const remaining=state.picks.findIndex(p=>!p);lines.push('',`الخطوة التالية: ${remaining<0?'مراجعة الحساب':'اختيار '+names[remaining]}`);
      }
      box.textContent=lines.join('\n');
    }
    function updatePickUi() {
      const ready=!!(state.source&&state.target),align=el('sq162-do-align'),reset=el('sq162-reset-picks'),save=el('sq162-save-oriented');
      if(save)save.disabled=!(state.source?.alignment?.picks?.length===4&&state.source?.bytes?.length);
      const labels=['1. اختيار النقطة الأولى من المصدر','2. اختيار النقطة الثانية من المصدر','3. اختيار النقطة الأولى من المرجع','4. اختيار النقطة الثانية من المرجع'];
      const firstMissing=state.picks.findIndex(p=>!p);
      for(let i=0;i<4;i++){const b=el(`sq162-pick-${i}`);if(!b)continue;const hasBoard=i<2?!!state.source:!!state.target;b.disabled=!hasBoard||(!state.picks[i]&&firstMissing>=0&&i>firstMissing);b.classList.toggle('active',state.pickStage===i);b.classList.toggle('completed',!!state.picks[i]);b.textContent=(state.picks[i]?'✓ ':'')+labels[i];}
      if(align)align.disabled=!(ready&&state.picks.length===4&&state.picks.every(Boolean));
      if(reset)reset.disabled=!(state.picks.some(Boolean)||state.source?.viewGeom);
      for(const which of ['source','target']){const c=el(`sq162-${which}-canvas`),active=(which==='source'&&state.pickStage>=0&&state.pickStage<2)||(which==='target'&&state.pickStage>=2&&state.pickStage<4);if(c)c.style.outline=active?'3px solid #15945c':'none';}
      refreshTransformDetails();
    }
    function drawGeometry(which, canvas, geom, picks, firstPickIndex) {
      if (!geom) return;
      const dpr = Math.min(root.devicePixelRatio || 1, 2), w = Math.max(240, canvas.clientWidth || 280), h = Math.max(160, canvas.clientHeight || 300);
      const pixelW=Math.round(w*dpr),pixelH=Math.round(h*dpr);if(canvas.width!==pixelW)canvas.width=pixelW;if(canvas.height!==pixelH)canvas.height=pixelH;
      const ctx = canvas.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.fillStyle = '#fbfcfe'; ctx.fillRect(0, 0, w, h);
      const pad = 16, spanX=Math.max(1e-9,geom.maxX-geom.minX), spanY=Math.max(1e-9,geom.maxY-geom.minY), sx = (w - 2 * pad) / spanX, sy = (h - 2 * pad) / spanY, baseScale = Math.max(1e-12, Math.min(sx, sy));
      const view = state.views[which];
      if (!Number.isFinite(view.centerX) || !Number.isFinite(view.centerY)) { view.centerX=(geom.minX+geom.maxX)/2; view.centerY=(geom.minY+geom.maxY)/2; }
      view.zoom = Math.max(0.2, Math.min(10000, Number(view.zoom)||1));
      const sc = baseScale * view.zoom;
      const pt = p => ({ x: w/2 + (p.x-view.centerX)*sc + view.panX, y: h/2 - (p.y-view.centerY)*sc + view.panY });
      const toWorld = p => ({x:view.centerX+(p.x-w/2-view.panX)/sc,y:view.centerY-(p.y-h/2-view.panY)/sc});
      const baseLineWidth=Math.max(.6,Math.min(2,1/Math.sqrt(view.zoom)));
      if(geom.raster&&geom.raster.image){const r=geom.raster,top=pt({x:r.insert.x+r.v.x*r.height,y:r.insert.y+r.v.y*r.height});ctx.save();ctx.setTransform(dpr*r.u.x*sc,dpr*(-r.u.y*sc),dpr*(-r.v.x*sc),dpr*(r.v.y*sc),dpr*top.x,dpr*top.y);ctx.drawImage(r.image,0,0,r.width,r.height);ctx.restore();}
      for(const frame of(geom.oleFrames||[])){if(!frame.image)continue;const tl=pt({x:frame.left,y:frame.top}),br=pt({x:frame.right,y:frame.bottom});ctx.drawImage(frame.image,tl.x,tl.y,br.x-tl.x,br.y-tl.y);}
      let cached=geom._sqPathCache;
      if(!cached&&typeof root.Path2D==='function'){
        const groups=new Map();
        const groupFor=o=>{const color=o?.color||'#1976b8',lw=Number(o?.lineWeight)||0,width=lw>0?Math.max(.6,Math.min(5,lw/100*96/25.4)):1,key=`${color}|${width.toFixed(2)}`;let g=groups.get(key);if(!g){g={color,width,path:new root.Path2D()};groups.set(key,g);}return g;};
        for(const seg of(geom.segments||[])){if(seg.isCurveSegment)continue;const g=groupFor(seg);g.path.moveTo(seg.a.x,seg.a.y);g.path.lineTo(seg.b.x,seg.b.y);}
        for(const curve of(geom.curves||[])){const g=groupFor(curve);if(Array.isArray(curve.points)&&curve.points.length>1){const pts=curve.points;g.path.moveTo(pts[0].x,pts[0].y);for(let i=1;i<pts.length;i++)g.path.lineTo(pts[i].x,pts[i].y);}else if(curve.center&&Number(curve.radius)>0){const start=Number(curve.start)||0,sweep=Number(curve.sweep)||Math.PI*2;g.path.arc(curve.center.x,curve.center.y,curve.radius,start,start+sweep,false);}}
        cached=geom._sqPathCache=Array.from(groups.values());
      }
      if(cached&&typeof root.Path2D==='function'){
        ctx.save();ctx.setTransform(dpr*sc,0,0,-dpr*sc,dpr*(w/2-view.centerX*sc+view.panX),dpr*(h/2+view.centerY*sc+view.panY));
        for(const g of cached){ctx.strokeStyle=g.color;ctx.lineWidth=Math.max(.35,Math.min(5,g.width))/sc;ctx.stroke(g.path);}ctx.restore();
      }else{
        const strokeGroups=new Map();
        const strokeKey=o=>{const color=o?.color||'#1976b8',lw=Number(o?.lineWeight)||0,width=lw>0?Math.max(.6,Math.min(5,lw/100*96/25.4)):baseLineWidth;return{key:`${color}|${width.toFixed(2)}`,color,width};};
        const groupFor=o=>{const st=strokeKey(o);let g=strokeGroups.get(st.key);if(!g){g={...st,draw:[]};strokeGroups.set(st.key,g);}return g;};
        for(const seg of(geom.segments||[])){if(seg.isCurveSegment)continue;const g=groupFor(seg);g.draw.push([pt(seg.a),pt(seg.b)]);}
        for(const curve of(geom.curves||[])){const g=groupFor(curve);if(Array.isArray(curve.points)&&curve.points.length>1)g.draw.push(curve.points.map(pt));}
        for(const g of strokeGroups.values()){ctx.beginPath();ctx.strokeStyle=g.color;ctx.lineWidth=g.width;for(const path of g.draw){if(path.length<2)continue;ctx.moveTo(path[0].x,path[0].y);for(let i=1;i<path.length;i++)ctx.lineTo(path[i].x,path[i].y);}ctx.stroke();}
      }
      // POINT entities remain available to the snap engine but are not rendered as
      // fabricated '+' markers; the source drawing's own point symbols are not altered.
      // Axis names are often TEXT/MTEXT/ATTRIB entities inside blocks. Draw them
      // explicitly; no text or CAD record is recreated in the output file.
      for (const label of (geom.texts || []).slice(0, 12000)) {
        const q=pt(label.position);if(q.x < -100 || q.x > w+100 || q.y < -60 || q.y > h+60)continue;
        const rawH=Math.abs(Number(label.height)||0),scaledH=rawH>0?rawH*sc:5,fontSize=Math.max(1.25,Math.min(Math.max(1,h*1.15),scaledH)),widthFactor=Math.max(.1,Math.min(10,Number(label.widthFactor)||1));
        ctx.save();ctx.translate(q.x,q.y);ctx.rotate(-(Number(label.rotation)||0)*Math.PI/180);ctx.scale(widthFactor,1);
        ctx.fillStyle=label.color||'#182536';ctx.font=`${fontSize}px sans-serif`;ctx.textBaseline='bottom';
        const txt=String(label.text||'').slice(0,180);if(txt)ctx.fillText(txt,0,-Math.max(.5,fontSize*.08));ctx.restore();
      }
      ctx.fillStyle = '#d63333';
      for (let i = 0; i < picks.length; i++) { const p = pt(picks[i]); ctx.beginPath(); ctx.arc(p.x,p.y,5,0,Math.PI*2); ctx.fill(); ctx.fillStyle='#fff';ctx.font='bold 11px sans-serif';ctx.fillText(String((picks[i].pickIndex??(i+firstPickIndex))+1),p.x+7,p.y-7);ctx.fillStyle='#d63333'; }
      const hover=state.hover[which];
      if(hover?.point){const q=pt(hover.point);ctx.save();ctx.strokeStyle='#079455';ctx.fillStyle='#079455';ctx.lineWidth=2;ctx.beginPath();ctx.arc(q.x,q.y,8,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(q.x-13,q.y);ctx.lineTo(q.x+13,q.y);ctx.moveTo(q.x,q.y-13);ctx.lineTo(q.x,q.y+13);ctx.stroke();ctx.font='bold 11px system-ui';ctx.fillText(hover.typeLabel||'Snap',q.x+12,q.y-10);ctx.restore();}
      canvas._sqMap = { which, boardFingerprint:state[which]?.fingerprint||'', boardFileName:String(state[which]?.file?.name||''), geom, width:w, height:h, pad, sc, baseScale, pt, toWorld, view };
      const toolbar=overlay.querySelector(`[data-sq-view="${which}"]`); if(toolbar){const z=toolbar.querySelector('.sq162-zoom-value');if(z)z.textContent=`${Math.round(view.zoom*100)}%`;const slider=toolbar.querySelector('.sq162-zoom-slider');if(slider&&root.document.activeElement!==slider)slider.value=String(Math.max(.2,Math.min(100,view.zoom)));const sel=overlay.querySelector(`[data-sq-snap=\"${which}\"]`);if(sel&&sel.value!==state.snapModes[which])sel.value=state.snapModes[which];}
    }
    let sqRedrawPending=false;const sqDirtyViews=new Set();
    function requestRedraw(which){if(which)sqDirtyViews.add(which);else{sqDirtyViews.add('source');sqDirtyViews.add('target');}if(sqRedrawPending)return;sqRedrawPending=true;const raf=root.requestAnimationFrame||((fn)=>root.setTimeout(fn,16));raf(()=>{sqRedrawPending=false;const dirty=[...sqDirtyViews];sqDirtyViews.clear();for(const name of dirty)redrawOne(name);});}
    function redrawOne(which){if(which==='source'&&state.source)drawGeometry('source',el('sq162-source-canvas'),state.source.viewGeom||state.source.geom,state.picks.slice(0,2).map((p,i)=>p?{...p,pickIndex:i}:null).filter(Boolean),0);if(which==='target'&&state.target)drawGeometry('target',el('sq162-target-canvas'),state.target.geom,state.picks.slice(2,4).map((p,i)=>p?{...p,pickIndex:i+2}:null).filter(Boolean),2);}
    function redrawAll(){redrawOne(state.activeBoardSide);}
    function fitView(which){const g=which==='source'?(state.source?.viewGeom||state.source?.geom):state.target?.geom;if(!g)return;state.views[which]={zoom:1,panX:0,panY:0,centerX:(g.minX+g.maxX)/2,centerY:(g.minY+g.maxY)/2};redrawOne(which);}
    function zoomView(which,factor,anchor){const c=el(`sq162-${which}-canvas`),map=c&&c._sqMap;if(!map)return;const view=state.views[which],a=anchor||{x:map.width/2,y:map.height/2},world=map.toWorld(a);view.zoom=Math.max(.2,Math.min(10000,view.zoom*factor));const sc=map.baseScale*view.zoom;view.panX=a.x-map.width/2-(world.x-view.centerX)*sc;view.panY=a.y-map.height/2+(world.y-view.centerY)*sc;redrawOne(which);}
    for(const toolbar of overlay.querySelectorAll('[data-sq-view]')){
      const which=toolbar.dataset.sqView;
      toolbar.addEventListener('click',e=>{const b=e.target.closest('[data-sq-zoom]');if(!b)return;const action=b.dataset.sqZoom;if(action==='fit')fitView(which);else zoomView(which,action==='in'?2:1/2);});
      const select=overlay.querySelector(`[data-sq-snap="${which}"]`);
      if(select) select.addEventListener('change',()=>{state.snapModes[which]=select.value;status(`نمط الالتقاط على ${which==='source'?'اللوحة غير الموجهة':'اللوحة المرجعية'}: ${select.options[select.selectedIndex].text}`);});
      const slider=toolbar.querySelector('.sq162-zoom-slider');if(slider)slider.addEventListener('input',()=>{const map=el(`sq162-${which}-canvas`)._sqMap;if(!map)return;const target=Number(slider.value);zoomView(which,target/Math.max(.2,state.views[which].zoom));});
    }
    async function loadCadFile(which, file, ticket) {
      if (!file) return;
      if(ticket==null)ticket=++state.loadSerial[which];
      if(ticket!==state.loadSerial[which])return;
      if(state[which]?.rasterUrl)try{root.URL.revokeObjectURL(state[which].rasterUrl);}catch(_){}if(state[which]?.rasterUrls)for(const u of state[which].rasterUrls)try{root.URL.revokeObjectURL(u);}catch(_){}
      state[which]=null;invalidateAlignmentBecauseBoardChanged(which);activateBoardPanel(which);state.hover[which]=null;const canvas=el(`sq162-${which}-canvas`);canvas._sqMap=null;clearCanvas(canvas);
      el(`sq162-${which}-info`).textContent=`جارٍ قراءة الملف الجديد: ${file.name}`;
      if (!/\.(dwg|dxf|zip)$/i.test(file.name)) throw new Error('اختر DWG أو DXF أو حزمة PDF-to-DXF ZIP.');
      status('جارٍ فتح الملف المحدد. تتم قراءة بايتات الملف نفسه، وليس الاعتماد على الاسم وحده...');
      const sourceBytes=new Uint8Array(await file.arrayBuffer());
      if(ticket!==state.loadSerial[which])return;
      if(!sourceBytes.length)throw new Error(`الملف ${file.name} وصل من مدير الملفات بحجم صفر بايت. أعد اختياره أو انسخه إلى ذاكرة الهاتف أولًا.`);
      const fingerprint=fileFingerprint(file,sourceBytes);
      const other=which==='source'?'target':'source';
      if(state[other]?.fingerprint&&state[other].fingerprint.split('|').at(-1)===fingerprint.split('|').at(-1))throw new Error('تم اختيار نفس محتوى الملف في اللوحتين. حمّل ملف المصدر واللوحة المرجعية المختلفين.');
      let bytes,geom,rasterUrl=null,rasterUrls=[];
      if(/\.zip$/i.test(file.name)){
        const pkg=await loadRasterZip(file,sourceBytes);bytes=pkg.dxfBytes;geom=pkg.geom;rasterUrl=pkg.rasterUrl;
      }else{
        if (typeof root.parseFile !== 'function') throw new Error('قارئ الملفات المشترك غير متاح في هذه الشاشة.');
        const model = await root.parseFile(file, { rawOnly: true, conversionOnly: true, retainRawDWG: false, sourceBytes });
        const raw = model && model.rawDXFBytes;
        if (!raw || !raw.length) throw new Error('لم يُنتج القارئ بيانات DXF. لا يمكن متابعة التوجيه دون ملف صالح.');
        bytes = raw instanceof Uint8Array ? raw : new Uint8Array(raw);geom = readGeometry(bytes);
      }
      if(ticket!==state.loadSerial[which]){if(rasterUrl)try{root.URL.revokeObjectURL(rasterUrl);}catch(_){}for(const u of rasterUrls)try{root.URL.revokeObjectURL(u);}catch(_){}return;}
      if(Array.isArray(geom.oleFrames)&&geom.oleFrames.length){
        try{for(const frame of geom.oleFrames){const url=root.URL.createObjectURL(new Blob([frame.jpeg],{type:'image/jpeg'})),image=new root.Image();rasterUrls.push(url);await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(new Error('تعذر فك صورة OLE المضمنة داخل DXF.'));image.src=url;});frame.image=image;}}
        catch(e){for(const u of rasterUrls)try{root.URL.revokeObjectURL(u);}catch(_){}throw new Error('ملف DXF يحتوي OLE2FRAME لكن تعذر قراءة صورة الصفحة: '+(e?.message||e));}
      }
      const drawableCount=(geom.segments?.length||0)+(geom.curves?.length||0)+(geom.texts?.length||0)+(geom.raster?1:0)+(geom.oleFrames?.length||0);
      if(!drawableCount) throw new Error('لم يعثر القارئ على عناصر قابلة للعرض. أوقفت المعاينة بدل عرض علامات + غير موجودة في المصدر.');
      state[which] = { file, fingerprint, bytes:bytes.slice(), geom, viewGeom:null, transform:null, alignment:null, rasterUrl, rasterUrls };
      state.views[which]={zoom:1,panX:0,panY:0,centerX:(geom.minX+geom.maxX)/2,centerY:(geom.minY+geom.maxY)/2};
      el(`sq162-${which}-info`).textContent = `${file.name}\nبصمة الملف: ${fingerprint.slice(-16)}\nنطاق X: ${fmt(geom.minX)} إلى ${fmt(geom.maxX)} | نطاق Y: ${fmt(geom.minY)} إلى ${fmt(geom.maxY)}\nمعاينة: ${geom.segments.length.toLocaleString()} مقطع، ${(geom.curves||[]).length.toLocaleString()} منحنى، ${((geom.texts||[]).length).toLocaleString()} نص/اسم. تم تحميل بايتات الملف المختار نفسها.`;
      redrawAll(); updatePickUi();
      status(`تم فتح الملف المحدد ${file.name}. عند اختيار ملف آخر بالاسم نفسه ستتم قراءة محتواه الجديد ببصمة مختلفة.`);
    }
    for(const which of ['source','target']){
      const input=el(`sq162-${which}-file`);
      // Reset the HTML file-input value before opening the picker. Browsers otherwise
      // suppress change when a different path contains the same basename.
      input.addEventListener('click',()=>{input.value='';});
      input.addEventListener('change',async e=>{
        const file=e.target.files?.[0];if(!file)return;
        const ticket=++state.loadSerial[which];
        try{await loadCadFile(which,file,ticket);}
        catch(err){if(ticket===state.loadSerial[which]){clearDrawing(which);status(String(err?.message||err));}}
      });
    }
    // V168: every snap requires an explicit point-slot button; zoom/pan gestures never commit a point.
    const pickLabels=['النقطة الأولى على اللوحة غير الموجهة','النقطة الثانية على اللوحة غير الموجهة','النقطة الأولى المناظرة على اللوحة المرجعية','النقطة الثانية المناظرة على اللوحة المرجعية'];
    for(let i=0;i<4;i++)el(`sq162-pick-${i}`).addEventListener('click',()=>{
      const which=i<2?'source':'target';if(!state[which]){status('حمّل اللوحة الخاصة بهذا الاختيار أولًا.');return;}activateBoardPanel(which);
      if(i<2&&state.source?.viewGeom){state.source.viewGeom=null;state.source.transform=null;state.source.alignment=null;setSourceBoardMode(false);const g=state.source.geom;state.views.source={zoom:1,panX:0,panY:0,centerX:(g.minX+g.maxX)/2,centerY:(g.minY+g.maxY)/2};}
      const firstMissing=state.picks.findIndex(p=>!p);
      if(!state.picks[i]&&firstMissing>=0&&i!==firstMissing){status(`رتّب الاختيار: أكمل ${pickLabels[firstMissing]} أولًا حتى لا تتطابق نقاط غير متناظرة.`);return;}
      if(state.picks[i])for(let j=i;j<4;j++)state.picks[j]=null;
      state.lastAlignmentDiagnostics=null;state.pickStage=i;state.hover={source:null,target:null};updatePickUi();redrawAll();status(`وضع اختيار ${pickLabels[i]}. الترتيب إلزامي: مصدر 1 ثم مصدر 2 ثم المرجع 1 ثم المرجع 2.`);
    });
    el('sq162-do-align').addEventListener('click',()=>{
      try{
        if(!state.source||!state.target||state.picks.length!==4||!state.picks.every(Boolean))throw new Error('يلزم اختيار النقاط الأربع بالترتيب المطلوب قبل التوجيه.');
        const expected=[['source',state.source],['source',state.source],['target',state.target],['target',state.target]];
        for(let i=0;i<4;i++){const p=state.picks[i],[side,board]=expected[i];if(!p||p.boardSide!==side||p.canvasSide!==side||p.boardFingerprint!==board.fingerprint||p.canvasFingerprint!==board.fingerprint)throw new Error(`النقطة ${i+1} ليست مأخوذة من معاينة ملف ${side==='source'?'المصدر غير الموجه':'المرجع الموجه'} الحالي. أعد اختيار النقاط من اللوحة الصحيحة.`);}
        const picked=state.picks.map(p=>({x:Number(p.x),y:Number(p.y)}));
        rejectIdentityAlignment(picked);
        const tr=solve(picked[0],picked[1],picked[2],picked[3]);
        const viewGeom=transformGeometryView(state.source.geom,tr);
        state.source.transform=tr;state.source.alignment={picks:picked,createdAt:Date.now()};state.source.viewGeom=viewGeom;
        state.lastAlignmentDiagnostics=alignmentDiagnostics(picked);
        state.picks=[null,null,null,null];state.pickStage=-1;state.hover={source:null,target:null};
        state.views.source={zoom:1,panX:0,panY:0,centerX:(viewGeom.minX+viewGeom.maxX)/2,centerY:(viewGeom.minY+viewGeom.maxY)/2};
        setSourceBoardMode(true);activateBoardPanel('source');updatePickUi();redrawAll();
        const d=alignmentDiagnostics(picked);
        status(`تم توجيه اللوحة ومطابقة النقطتين.\nالدوران: ${fmt(d.rotationDegrees)}° | المقياس: ${fmt(d.scale)}\nإزاحة X: ${fmt(d.translationX)} | إزاحة Y: ${fmt(d.translationY)}\nاتجاه خط المصدر: ${fmt(d.sourceBearingDegrees)}° | اتجاه خط المرجع: ${fmt(d.targetBearingDegrees)}°\nخطأ المطابقة: ${fmt(Math.max(d.residualA,d.residualB))} وحدة.\nاضغط «حفظ اللوحة الموجهة DXF» لإنشاء ملف جديد. الملف الأصلي لم يتم استبداله أو تعديله.`);
      }catch(err){status(String(err?.message||err));}
    });
    el('sq162-save-oriented').addEventListener('click',async()=>{
      try{
        const src=state.source,alignment=src?.alignment;
        if(!src||!src.bytes?.length||!alignment?.picks||alignment.picks.length!==4)throw new Error('وجّه اللوحة أولًا واختر النقاط الأربع قبل الحفظ.');
        const out=createOrientedDxfBytes(src.bytes,alignment.picks);
        const base=String(src.file?.name||'SurveyQuant').replace(/\.[^.]+$/,'').replace(/[^\w.-]+/g,'_')||'SurveyQuant';
        const filename=`${base}_ORIENTED.dxf`;
        await downloadBytes(out.bytes,filename,'application/dxf');
        status(`تم حفظ اللوحة الموجهة في التنزيلات: ${filename}\nتم تطبيق التحويل على سجلات DXF الأصلية بما فيها INSERT وXLINE/RAY وتسميات المحاور. لم يتم استبدال ملف المصدر.`);
      }catch(err){status(String(err?.message||err));}
    });
    el('sq162-reset-picks').addEventListener('click',()=>{
      if(state.source){state.source.viewGeom=null;state.source.transform=null;state.source.alignment=null;state.views.source={zoom:1,panX:0,panY:0,centerX:(state.source.geom.minX+state.source.geom.maxX)/2,centerY:(state.source.geom.minY+state.source.geom.maxY)/2};}
      setSourceBoardMode(false);activateBoardPanel('source');state.picks=[null,null,null,null];state.lastAlignmentDiagnostics=null;state.pickStage=-1;state.hover={source:null,target:null};updatePickUi();redrawAll();status('تم إلغاء التوجيه وإرجاع عرض اللوحة إلى إحداثيات الملف الأصلي. الملف نفسه لم يتغير.');
    });
    function updateSnapPreview(which,clientX,clientY){
      if(state.pickStage<0||state.pickStage>=4)return;
      const expected=state.pickStage<2?'source':'target';if(which!==expected||state.activeBoardSide!==which)return;
      const canvas=el(`sq162-${which}-canvas`),board=state[which];let map=canvas._sqMap;if(!board)return;
      const expectedGeom=which==='source'?(board.viewGeom||board.geom):board.geom;
      if(!map||map.which!==which||map.boardFingerprint!==board.fingerprint||map.geom!==expectedGeom){redrawOne(which);map=canvas._sqMap;}
      if(!map||map.which!==which||map.boardFingerprint!==board.fingerprint||map.geom!==expectedGeom)return;
      const rect=canvas.getBoundingClientRect(),pixel={x:clientX-rect.left,y:clientY-rect.top},world=map.toWorld(pixel);
      state.hover[which]=snapPoint(map.geom,world,state.snapModes[which]||'intersection',8/map.sc);
      requestRedraw(which);
    }
    function handleCanvasPick(which,clientX,clientY) {
      if (state.pickStage < 0 || state.pickStage >= 4) return;
      const slot=state.pickStage,expected = slot < 2 ? 'source' : 'target';if(state.activeBoardSide!==which){status('اختر اللوحة المطلوبة من شريط التبديل أولًا.');return;}
      if (which !== expected) { status(expected === 'source' ? 'اختر النقطة على اللوحة غير الموجهة أولًا.' : 'اختر النقطة المقابلة على اللوحة المرجعية أولًا.'); return; }
      const canvas=el(`sq162-${which}-canvas`),board=state[which];let map=canvas._sqMap;
      try {
        if(!board||!board.fingerprint)throw new Error('ملف اللوحة المطلوبة غير محمّل أو بلا بصمة تحقق.');
        const expectedGeom=which==='source'?(board.viewGeom||board.geom):board.geom;
        if(!map||map.which!==which||map.boardFingerprint!==board.fingerprint||map.geom!==expectedGeom){redrawOne(which);map=canvas._sqMap;}
        if(!map||map.which!==which||map.boardFingerprint!==board.fingerprint||map.geom!==expectedGeom)throw new Error('توقفت عملية الاختيار: شاشة المعاينة لا تخص ملف اللوحة المحمّل حاليًا. أعد تحميل اللوحة.');
        const rect=canvas.getBoundingClientRect(),pixel={x:clientX-rect.left,y:clientY-rect.top},world=map.toWorld(pixel);
        const snap=snapPoint(map.geom,world,state.snapModes[which]||'intersection',8/map.sc),picked=snap||(map.geom.raster?{point:world,type:'manual',typeLabel:'نقطة يدوية على الصورة'}:null);
        if(!picked)throw new Error('لم يتم العثور على عنصر داخل مدى الالتقاط 8 بكسل. قرّب أكثر أو اختر نمط التقاط آخر.');
        state.picks[slot]={...picked.point,snapType:picked.type,boardSide:which,boardFingerprint:board.fingerprint,boardFileName:String(board.file?.name||''),canvasSide:map.which,canvasFingerprint:map.boardFingerprint};state.hover[which]=null;state.pickStage=-1;updatePickUi();redrawAll();
        status(`تم تثبيت ${pickLabels[slot]} من ملف ${board.file?.name||which}: ${picked.typeLabel} عند X=${fmt(picked.point.x)}، Y=${fmt(picked.point.y)}. بصمة اللوحة ${board.fingerprint.slice(-12)}.`);
      } catch (err) { status(String(err.message || err)); }
    }
    function bindViewport(which){
      const canvas=el(`sq162-${which}-canvas`),pointers=new Map();let gesture=null;
      const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),mid=(a,b)=>({x:(a.x+b.x)/2,y:(a.y+b.y)/2});
      canvas.addEventListener('wheel',e=>{e.preventDefault();const r=canvas.getBoundingClientRect();zoomView(which,e.deltaY<0?1.14:1/1.14,{x:e.clientX-r.left,y:e.clientY-r.top});},{passive:false});
      canvas.addEventListener('pointerdown',e=>{
        canvas.setPointerCapture?.(e.pointerId);const r=canvas.getBoundingClientRect(),p={x:e.clientX-r.left,y:e.clientY-r.top};pointers.set(e.pointerId,p);updateSnapPreview(which,e.clientX,e.clientY);
        if(pointers.size===1){const v=state.views[which];gesture={type:'drag',start:p,last:p,panX:v.panX,panY:v.panY,moved:false};}
        else if(pointers.size===2){const q=[...pointers.values()],map=canvas._sqMap,center=mid(q[0],q[1]);gesture={type:'pinch',distance:Math.max(1,dist(q[0],q[1])),zoom:state.views[which].zoom,world:map?map.toWorld(center):null,center,viewCenter:{x:map?.view.centerX||0,y:map?.view.centerY||0}};}
      });
      canvas.addEventListener('pointermove',e=>{
        if(!pointers.has(e.pointerId))return;const r=canvas.getBoundingClientRect(),p={x:e.clientX-r.left,y:e.clientY-r.top};pointers.set(e.pointerId,p);
        if(pointers.size>=2&&gesture?.type==='pinch'){
          const q=[...pointers.values()],d=Math.max(1,dist(q[0],q[1])),center=mid(q[0],q[1]),view=state.views[which],map=canvas._sqMap;
          view.zoom=Math.max(.2,Math.min(10000,gesture.zoom*d/gesture.distance));if(map&&gesture.world){const sc=map.baseScale*view.zoom;view.panX=center.x-map.width/2-(gesture.world.x-view.centerX)*sc;view.panY=center.y-map.height/2+(gesture.world.y-view.centerY)*sc;}
          requestRedraw(which);
        }else if(pointers.size===1&&gesture?.type==='drag'){
          const dx=p.x-gesture.start.x,dy=p.y-gesture.start.y,travel=Math.hypot(dx,dy);
          if(travel>8){gesture.moved=true;const v=state.views[which];v.panX=gesture.panX+dx;v.panY=gesture.panY+dy;requestRedraw(which);}
          else if(!gesture.lastSnapPreviewAt||Date.now()-gesture.lastSnapPreviewAt>120){gesture.lastSnapPreviewAt=Date.now();updateSnapPreview(which,e.clientX,e.clientY);}
        }
      });
      const release=e=>{const was=gesture;pointers.delete(e.pointerId);if(pointers.size===0){if(was?.type==='drag'&&!was.moved)handleCanvasPick(which,e.clientX,e.clientY);gesture=null;}else if(pointers.size===1){const q=[...pointers.values()][0],v=state.views[which];gesture={type:'drag',start:q,last:q,panX:v.panX,panY:v.panY,moved:true};}};
      canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);if(!pointers.size)gesture=null;else if(pointers.size===1){const q=[...pointers.values()][0],v=state.views[which];gesture={type:'drag',start:q,last:q,panX:v.panX,panY:v.panY,moved:true};}});
    }
    bindViewport('source');bindViewport('target');
    // V169: orientation is previewed first, then saved to a separate transformed DXF; source bytes stay unchanged.
    // V176 projects open from the home project grid, not a floating CAD modal.
    // Include DWG in any existing CAD picker that already accepts DXF, including pickers
    // created later by project screens, without changing unrelated image/document pickers.
    function broadenCadPickers(scope) {
      for (const input of scope.querySelectorAll ? scope.querySelectorAll('input[type="file"]') : []) {
        const accept = input.getAttribute('accept') || '';
        if (/\.dxf/i.test(accept) && !/\.dwg/i.test(accept)) input.setAttribute('accept', `${accept},.dwg`);
      }
    }
    broadenCadPickers(doc);
    if (root.MutationObserver) new root.MutationObserver(records => { for (const r of records) for (const n of r.addedNodes) if (n.nodeType === 1) broadenCadPickers(n); }).observe(doc.documentElement, { childList: true, subtree: true });

    // V188: single-board orientation output; session replacements reset all picks; Android save path does not invoke a JS prompt.
    // V187: PDF vector entities only. Raster pages, fills and unsupported line styles fail closed.
    const rasterFileInput=el('sq162-raster-file'),traceBtn=el('sq162-trace');
    rasterFileInput.addEventListener('click',()=>{rasterFileInput.value='';});
    rasterFileInput.addEventListener('change',()=>{
      state.tracerFile=rasterFileInput.files?.[0]||null;
      const file=state.tracerFile,valid=!!file&&(/\.pdf$/i.test(file.name)||file.type==='application/pdf');
      traceBtn.disabled=!valid;
      if(file&&!valid){state.tracerFile=null;rasterFileInput.value='';status('هذا المشروع يقبل PDF فقط. لم يتم اختيار صورة أو إنشاء أي ملف.','sq162-raster-status');return;}
      status(valid?`تم اختيار ملف PDF: ${file.name} (${file.size.toLocaleString()} بايت).`:'اختر ملف PDF للبدء.','sq162-raster-status');
    });
    traceBtn.addEventListener('click',async()=>{
      const file=state.tracerFile;let pdf=null;
      try{
        if(!file||!(/\.pdf$/i.test(file.name)||file.type==='application/pdf'))throw new Error('اختر ملف PDF فقط. لم يتم إنشاء أي ملف.');
        traceBtn.disabled=true;status('جارٍ فحص صفحة PDF واستخراج عناصرها المتجهية الأصلية دون تتبع صورة أو إعادة رسم...','sq162-raster-status');
        const lib=root.pdfjsLib;if(!lib||typeof lib.getDocument!=='function')throw new Error('قارئ PDF غير محمّل داخل التطبيق.');
        ensurePdfWorker(lib,doc);
        const data=new Uint8Array(await file.arrayBuffer());if(!data.length)throw new Error('وصل ملف PDF فارغًا من مدير الملفات. أعد اختياره.');
        let task=lib.getDocument({data,useSystemFonts:true,isEvalSupported:false,disableAutoFetch:true});
        try{pdf=await task.promise;}catch(workerError){task=lib.getDocument({data,useSystemFonts:true,isEvalSupported:false,disableWorker:true});pdf=await task.promise;}
        const requested=Math.max(1,Number.parseInt(el('sq162-pdf-page').value||'1',10)||1);if(requested>pdf.numPages)throw new Error(`رقم الصفحة ${requested} غير موجود. عدد صفحات الملف ${pdf.numPages}.`);
        const page=await pdf.getPage(requested),viewport=page.getViewport({scale:1});
        const paths=await pdfOperatorPathsToCad(page,lib,viewport);
        const pdfTexts=await pdfTextToCad(page,viewport,20000,lib);
        const factor=Number(el('sq162-raster-scale').value);if(!finite(factor)||factor<=0)throw new Error('عامل المقياس يجب أن يكون رقمًا موجبًا.');
        const result=polylinesToDxf(paths,viewport.width,viewport.height,factor,pdfTexts);
        if(!result.bytes||result.bytes.length<256||!result.count)throw new Error('لم تنتج الصفحة عناصر CAD قابلة للحفظ. لم يتم إنشاء أي ملف.');
        const dxfText=new TextDecoder('windows-1252').decode(result.bytes);
        if(!/\$ACADVER\s*\n\s*1\s*\nAC1015/.test(dxfText)||/\nIMAGE(?:\r?\n|$)|\nIMAGEDEF(?:\r?\n|$)/.test(dxfText))throw new Error('فشل فحص سلامة DXF R2000 أو تم اكتشاف كيان صورة. لم يتم حفظ الملف.');
        const baseName=(file.name.replace(/\.[^.]+$/,'').replace(/[^A-Za-z0-9_.()-]/g,'_').slice(0,48)||'SurveyQuant_PDF');
        const filename=`${baseName}_CAD.dxf`;
        await downloadBytes(result.bytes,filename,'application/dxf');
        status(`تم حفظ ملف DXF واحد فقط: ${filename}\nالإصدار: AutoCAD 2000 / AC1015 | المسارات: ${result.polylineCount.toLocaleString()} | المساحات المملوءة: ${(result.hatchCount||0).toLocaleString()} | الرؤوس: ${result.vertices.toLocaleString()} | النصوص: ${result.textCount.toLocaleString()}\nتم حفظ الألوان الأصلية كـ TrueColor وسُمك الخط كـ Lineweight. لا توجد صور أو ملفات جانبية داخل الناتج.`, 'sq162-raster-status');
      }catch(err){status(`لم يتم إنشاء أو حفظ أي ملف: ${String(err?.message||err)}`,'sq162-raster-status');}
      finally{try{if(pdf)await pdf.destroy();}catch(_){}traceBtn.disabled=!(state.tracerFile&&(/\.pdf$/i.test(state.tracerFile.name)||state.tracerFile.type==='application/pdf'));}
    });

    root.addEventListener('pagehide', cleanup);root.addEventListener('beforeunload',cleanup);
  }
  return { solve, alignmentDiagnostics, rejectIdentityAlignment, transformGeometryView, transformDxfBytes, createOrientedDxfBytes, fingerprintBytes, fileFingerprint, readGeometry, nearestPoint, snapPoint, mergeRawDxfBoards, svgPathToPolylines, svgPathsToCad, pdfOperatorPathsToCad, pdfTextToCad, polylinesToDxf, makeRasterUnderlayDxf, makeEmbeddedRasterDxf, downloadPairedRasterFile, canvasJpegBytes, canvasJpegTiles, zipStore, readStoredZipBytes, rasterImageRecord, buildRasterGeometry, loadRasterZip, downloadBytes, mount };
});

