#!/usr/bin/env node
'use strict';
const assert=require('node:assert/strict');
const cad=require('./SurveyQuant_v1.0.174_CAD_ENGINE.js');
const rad=d=>d*Math.PI/180, near=(a,b,t=1e-7)=>assert.ok(Math.abs(a-b)<=t,`${a} != ${b}`);
const scenarios=[
 {name:'CCW 90',angle:90,scale:2,tx:100,ty:-250},
 {name:'CW 90',angle:-90,scale:.75,tx:-1_250_000,ty:875_000},
 {name:'180',angle:180,scale:1.25,tx:5000,ty:9000},
 {name:'zero',angle:0,scale:1,tx:321,ty:654},
 {name:'oblique 37',angle:37,scale:3.25,tx:700_000,ty:850_000},
 {name:'oblique -143',angle:-143,scale:.125,tx:-800_000,ty:450_000}
];
for(const sc of scenarios){
 const a={x:576761.446,y:858279.357},b={x:a.x+123.4,y:a.y-56.7},c=Math.cos(rad(sc.angle)),s=Math.sin(rad(sc.angle));
 const map=p=>({x:sc.scale*(p.x*c-p.y*s)+sc.tx,y:sc.scale*(p.x*s+p.y*c)+sc.ty});
 const ta=map(a),tb=map(b),tr=cad.solve(a,b,ta,tb),diag=cad.alignmentDiagnostics([a,b,ta,tb]);
 near(tr.rotationDegrees,sc.angle,1e-7);near(tr.scale,sc.scale,1e-8);near(tr.translationX,sc.tx,1e-5);near(tr.translationY,sc.ty,1e-5);near(tr.apply(a).x,ta.x,1e-7);near(tr.apply(a).y,ta.y,1e-7);near(tr.apply(b).x,tb.x,1e-7);near(tr.apply(b).y,tb.y,1e-7);near(diag.rotationDegrees,sc.angle,1e-7);
}
const dxf=['0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','0','ENDSEC','0','SECTION','2','ENTITIES','0','LINE','8','GRID','10','576761.446','20','858279.357','30','0','11','576884.846','21','858222.657','31','0','0','LINE','8','DETAIL','10','576800','20','858300','30','0','11','576810','21','858310','31','0','0','ENDSEC','0','EOF',''].join('\r\n');
const a={x:576761.446,y:858279.357},b={x:576884.846,y:858222.657},angle=90,c=Math.cos(rad(angle)),s=Math.sin(rad(angle)),map=p=>({x:2*(p.x*c-p.y*s)+100,y:2*(p.x*s+p.y*c)-250}),ta=map(a),tb=map(b),saved=cad.createOrientedDxfBytes(new TextEncoder().encode(dxf),[a,b,ta,tb]);
assert.equal(saved.mode,'raw-dxf-record-transform');near(saved.rotationDegrees,90,1e-7);const out=new TextDecoder().decode(saved.bytes);assert.match(out,/10\r\n-1716458\.714/);assert.match(out,/20\r\n1153272\.892/);
assert.throws(()=>cad.solve({x:0,y:0},{x:0,y:0},{x:1,y:1},{x:2,y:2}),/نقطتين مختلفتين/);
console.log(JSON.stringify({ok:true,scenarios:scenarios.map(x=>x.name),cadRecordTransform:'PASS',largeSurveyCoordinates:'PASS',degenerateBaselineRejected:true},null,2));
