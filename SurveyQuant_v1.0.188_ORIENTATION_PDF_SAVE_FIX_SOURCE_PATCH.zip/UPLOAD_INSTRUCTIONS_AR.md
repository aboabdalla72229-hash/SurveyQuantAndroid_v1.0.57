# تعليمات رفع SurveyQuant v1.0.188

1. افتح مستودع `aboabdalla72229-hash/SurveyQuantAndroid_v1.0.57` ثم `Add file` ثم `Upload files`.
2. ارفع `SurveyQuant_v1.0.188_ORIENTATION_PDF_SAVE_FIX_SOURCE_PATCH.zip` مباشرة في جذر المستودع، وليس داخل مجلد فرعي.
3. ارفع ملف Workflow مع الحفاظ على مساره حرفياً: `.github/workflows/build-v188-orientation-pdf-save-fix.yml`.
4. اضغط `Commit changes` على فرع `main`.
5. افتح `Actions` ثم `Build SurveyQuant v1.0.188 Orientation PDF Save Fix` وشغّل `Run workflow` إذا لم يبدأ تلقائياً.
6. بعد نجاح البناء نزّل Artifact باسم `SurveyQuant-v1.0.188-ORIENTATION-PDF-SAVE-FIX`، واستخرج APK وثبّته بعد إزالة النسخة السابقة عند الحاجة.

ملاحظة: هذا الإصدار يصلح عزل شاشة التوجيه والحفظ ويضيف اختبارات CAD. تصدير DWG ما زال غير متاح في المحرك المضمن؛ إخراج الإسقاط المتاح DXF. كذلك لا يمكن ضمان تحويل PDF نقطي أو غير مدعوم إلى CAD مطابق حرفياً.
