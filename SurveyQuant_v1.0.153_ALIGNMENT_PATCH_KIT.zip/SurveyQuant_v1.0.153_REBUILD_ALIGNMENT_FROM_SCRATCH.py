#!/usr/bin/env python3
"""Replace the complete legacy orientation stack with one standalone Alignment command."""
from __future__ import annotations
import argparse, hashlib, re
from pathlib import Path

OLD_VERSION = 'const SQ_APP_VERSION_CODE = 150;'
NEW_VERSION = 'const SQ_APP_VERSION_CODE = 153;'
OLD_SESSION_ID = 'surveyquant-v150-fresh-board-session'
NEW_SESSION_ID = 'surveyquant-v153-fresh-alignment-session'
LEGACY_IDS = [
    'sq-orientation-module',
    'sq-orientation-axis-reader-module',
    'sq-orientation-manual-points-module',
    'sq-orientation-reference-board-module',
    'sq-orientation-dxf-faithful-recovery-module',
    'sq-orientation-cad-preserve-module',
    'sq-orientation-v115-tools-module',
]

def script_pattern(script_id: str) -> re.Pattern[str]:
    return re.compile(r'(<script\b(?=[^>]*\bid=["\']'+re.escape(script_id)+r'["\'])[^>]*>)([\s\S]*?)(</script\s*>)', re.I)

def exactly_one(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise ValueError(f'{label}: expected exactly one occurrence, found {count}')
    return source.replace(old, new, 1)

def patch(source: str, core: str, command: str) -> tuple[str, str]:
    source = exactly_one(source, OLD_VERSION, NEW_VERSION, 'application version')
    source = exactly_one(source, OLD_SESSION_ID, NEW_SESSION_ID, 'fresh-session marker')
    if source.count('window.parseFile = parseFile;') != 1:
        raise ValueError('Shared DWG/DXF parser is missing or duplicated.')
    if source.count('await LibreDwg.create(sqDwgWasmRuntimePath())') < 1:
        raise ValueError('Local LibreDWG reader is missing.')
    source = exactly_one(source, "'sqOriReferenceFile', 'sqOriTargetFile', 'sq108File',\n    'sq110TargetFile', 'sq110ReferenceFile'", "'sq153SourceFile', 'sq153ReferenceFile'", 'remove legacy file-picker IDs')

    modules = []
    for sid in LEGACY_IDS:
        matches = list(script_pattern(sid).finditer(source))
        if len(matches) != 1:
            raise ValueError(f'Legacy module {sid}: expected exactly one module, found {len(matches)}')
        modules.append((sid, matches[0].start(), matches[0].end()))
    first_start = modules[0][1]
    replacement = '<script id="sq153-alignment-core">\n' + core + '\n</script>\n<script id="sq153-alignment-command">\n' + command + '\n</script>'
    # Replace from the end so offsets remain valid, substituting the first legacy module with the new stack.
    for sid, start, end in reversed(modules):
        if sid == LEGACY_IDS[0]:
            source = source[:start] + replacement + source[end:]
        else:
            source = source[:start] + source[end:]

    for sid in LEGACY_IDS:
        if script_pattern(sid).search(source):
            raise ValueError('Legacy orientation module survived deletion: ' + sid)
    for marker in ['const SQ_APP_VERSION_CODE = 153;', 'id="sq153-alignment-core"', 'id="sq153-alignment-command"', 'function solveAlignment', 'transformDxfBytes', 'sq153Overlay', 'window.__sqAlignment153']:
        if marker not in source:
            raise ValueError('Fresh Alignment marker missing after patch: ' + marker)
    for marker in ['id="sq-orientation-module"', 'id="sq-orientation-reference-board-module"', 'id="sq-orientation-cad-preserve-module"', 'id="sq-orientation-dxf-faithful-recovery-module"', 'sqOriReferenceFile', 'sqOriTargetFile', 'sq108File', 'sq110TargetFile', 'sq110ReferenceFile']:
        if marker in source:
            raise ValueError('Old orientation stack still exists: ' + marker)
    report = '\n'.join([
        '# SurveyQuant v1.0.153 Alignment Rebuild Report',
        '',
        '- Replaced all seven legacy orientation modules with one standalone Alignment core and command UI.',
        '- New command computes a two-point 2D similarity transform: rotation, uniform scale, and translation.',
        '- Source and reference boards are held only in the active in-memory session and reset on close/reopen.',
        '- DXF output transforms only supported coordinate/angle/size group values in the original DXF record stream; it does not recreate/re-draw entities. Layer tables, handles, text, XData and other non-geometric records are regression-tested as preserved.',
        '- Zoom is raised to 100,000,000x fit scale with 2.5x/5x controls, pointer-anchored wheel zoom, pinch zoom, and a toggleable intersection OSNAP with priority snapping.',
        '- DWG files are read through the bundled LibreDWG converter and emitted as a new DXF because a native DWG writer is not bundled.',
        '- Unsupported opaque/custom CAD entity geometry fails closed instead of pretending an incomplete alignment succeeded.',
        '- Automated geometry checks are run separately by the build workflow; real-world drawings still need user validation.',
        '',
        f'- Final HTML SHA-256: `{hashlib.sha256(source.encode("utf-8")).hexdigest()}`',
        f'- Legacy modules removed: {len(LEGACY_IDS)}',
    ])
    return source, report

def main() -> None:
    p=argparse.ArgumentParser()
    p.add_argument('--input-html', type=Path, required=True)
    p.add_argument('--core-js', type=Path, required=True)
    p.add_argument('--command-js', type=Path, required=True)
    p.add_argument('--output-html', type=Path, required=True)
    p.add_argument('--report', type=Path, required=True)
    a=p.parse_args()
    src=a.input_html.read_text(encoding='utf-8')
    core=a.core_js.read_text(encoding='utf-8')
    command=a.command_js.read_text(encoding='utf-8')
    output,report=patch(src,core,command)
    a.output_html.parent.mkdir(parents=True,exist_ok=True)
    a.output_html.write_text(output,encoding='utf-8')
    a.report.parent.mkdir(parents=True,exist_ok=True)
    a.report.write_text(report+'\n',encoding='utf-8')
    print(report)

if __name__=='__main__':
    main()
