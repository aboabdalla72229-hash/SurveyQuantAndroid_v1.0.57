'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const htmlPath = process.argv[2];
assert(htmlPath, 'usage: node V148_ALIGNMENT_DXF_DWG_REGRESSION_TEST.js <index.html>');
const html = fs.readFileSync(htmlPath, 'utf8');
function getScript(id) {
  const re = new RegExp(`<script\\b(?=[^>]*\\bid=["']${id}["'])[^>]*>([\\s\\S]*?)<\\/script\\s*>`, 'i');
  const m = html.match(re); assert(m, `script ${id} present`); return m[1];
}
assert(html.includes('const SQ_APP_VERSION_CODE = 148;'));
assert(html.includes('height:44vh;min-height:250px;max-height:500px'));
assert(!html.includes("const sq145OCSTypes=new Set(['POINT','CIRCLE','ARC','INSERT','TEXT','ATTRIB','ATTDEF','MTEXT','SOLID','TRACE','LWPOLYLINE','POLYLINE','HATCH','LEADER','DIMENSION','SHAPE','VIEWPORT','IMAGE','WIPEOUT']);"), 'IMAGE/WIPEOUT must not go through entity OCS handling');
assert(html.includes('await LibreDwg.create(sqDwgWasmRuntimePath())'), 'DWG conversion must load the actual packaged WASM path');
assert(html.includes('transformWcsPointCodes=[10,13,14,15],transformOcsPointCodes=[11,12,16]'));

const window = {__sqOrientTest:{}};
const document = {readyState:'loading',baseURI:'file:///android_asset/index.html',addEventListener(){},getElementById(){return null;},querySelector(){return null;},querySelectorAll(){return [];},createElement(){return {style:{},appendChild(){},remove(){},click(){},setAttribute(){},addEventListener(){}};},head:{appendChild(){}},body:{appendChild(){},classList:{add(){},remove(){}}},documentElement:{appendChild(){}}};
const context = {window,document,console,Uint8Array,ArrayBuffer,Map,Set,Math,Number,String,Object,RegExp,Error,Promise,Blob:global.Blob,URL:global.URL,TextEncoder,TextDecoder,performance:{now:()=>0},setTimeout,clearTimeout};
window.window=window;window.document=document;vm.createContext(context);
vm.runInContext(getScript('sq-orientation-reference-board-module'), context, {timeout:5000});
const api = window.__sqOrientation110API;
assert(api && typeof api.transformBytes === 'function');
const t = api.solve({x:10,y:20},{x:20,y:20},{x:1000,y:2000},{x:1000,y:2020});
assert.equal(t.scale,2);
assert(t.residual1 <= t.tolerance && t.residual2 <= t.tolerance);
assert(Math.hypot(t.point(10,20).x-1000,t.point(10,20).y-2000)<1e-8);
assert(Math.hypot(t.point(20,20).x-1000,t.point(20,20).y-2020)<1e-8);

// Dimension intentionally mixes WCS and OCS positions and contains group 15/16,
// which the old exporter left behind at the source coordinates.
const fixture = `0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1027\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n0\nDIMENSION\n5\nD1\n8\nDIMENSIONS\n2\n*D1\n70\n1\n10\n5\n20\n4\n30\n1\n11\n6\n21\n7\n31\n2\n12\n8\n22\n9\n32\n3\n13\n10\n23\n11\n33\n4\n14\n12\n24\n13\n34\n5\n15\n14\n25\n15\n35\n6\n16\n16\n26\n17\n36\n7\n210\n0\n220\n1\n230\n0\n0\nIMAGE\n5\nI1\n8\nIMAGES\n10\n5\n20\n6\n30\n8\n11\n2\n21\n0\n31\n1\n12\n0\n22\n3\n32\n0\n13\n1200\n23\n800\n14\n0\n24\n0\n14\n100\n24\n0\n70\n3\n0\nWIPEOUT\n5\nW1\n8\nWIPEOUTS\n10\n7\n20\n8\n30\n9\n11\n1\n21\n0\n31\n0\n12\n0\n22\n1\n32\n0\n13\n0\n23\n0\n14\n0\n24\n0\n14\n100\n24\n100\n0\nCIRCLE\n5\nC1\n8\nGEOMETRY\n10\n100\n20\n200\n30\n10\n40\n5\n210\n0\n220\n1\n230\n0\n0\nENDSEC\n0\nEOF\n`;
const bytes = new TextEncoder().encode(fixture);
const out = api.transformBytes(bytes,t);
assert.equal(out.entitiesBefore,4); assert.equal(out.entitiesAfter,4);
const parsed = api.sectionRecords(api.splitPairs(out.bytes).pairs,'ENTITIES');
const rec=(type)=>{const r=parsed.find(x=>x.type===type);assert(r,`${type} retained`);return r;};
const val=(r,c,i=0)=>{const p=r.pairs.filter(q=>q.code===c)[i];assert(p,`${r.type} group ${c}[${i}] exists`);return Number(p.value);};
const dim=rec('DIMENSION');
// group 15 is WCS and must be transformed exactly, including Z around the recovered world-Z pivot.
const expected15=t.point(14,15);assert(Math.abs(val(dim,15)-expected15.x)<1e-8);assert(Math.abs(val(dim,25)-expected15.y)<1e-8);
// Source and destination points use same identity map; WCS point at (0,0) maps to target (1000,2000), demonstrating no hidden axis flip.
const img=rec('IMAGE');assert(Math.abs(val(img,10)-t.point(5,6).x)<1e-8);assert(Math.abs(val(img,20)-t.point(5,6).y)<1e-8);
// Image U/V axis vectors rotate + scale but never receive translation. Pixel sizes and clip paths remain local and byte values unchanged.
const expectedU=t.vector(2,0);assert(Math.abs(val(img,11)-expectedU.x)<1e-8);assert(Math.abs(val(img,21)-expectedU.y)<1e-8);assert.equal(val(img,13),1200);assert.equal(val(img,23),800);assert.equal(val(img,14,1),100);assert.equal(val(img,24,1),0);
const wipe=rec('WIPEOUT');assert(Math.abs(val(wipe,10)-t.point(7,8).x)<1e-8);assert(Math.abs(val(wipe,20)-t.point(7,8).y)<1e-8);const v=t.vector(1,0);assert(Math.abs(val(wipe,11)-v.x)<1e-8);assert(Math.abs(val(wipe,21)-v.y)<1e-8);assert.equal(val(wipe,14,1),100);assert.equal(val(wipe,24,1),100);
// WCS+OCS dimension position groups should all change consistently, including formerly skipped 15/16.
assert(Math.abs(val(dim,15)-14)>1e-6 || Math.abs(val(dim,25)-15)>1e-6);
assert(Math.abs(val(dim,16)-16)>1e-6 || Math.abs(val(dim,26)-17)>1e-6);
assert.equal(new TextDecoder().decode(out.bytes).trim().split(/\r?\n/).at(-1),'EOF');

// Simulate the DWG converter's module API to prove it passes the packaged WASM directory and validates bytes.
context.sqDwgWasmRuntimePath=()=> 'file:///android_asset/libredwg-writer/wasm';
let createPath=null, receivedBuffer=null;
context.sqValidateDwgConversion=converted=>{const u=converted instanceof Uint8Array?converted:new Uint8Array(converted);assert(u.length>64);assert(new TextDecoder().decode(u).includes('SECTION'));assert(/EOF\s*$/.test(new TextDecoder().decode(u)));return u;};
window.loadDWG=async()=>({LibreDwg:{create:async path=>{createPath=path;return {dwg_write_dxf:buffer=>{receivedBuffer=buffer;return new TextEncoder().encode('0\nSECTION\n2\nENTITIES\n0\nLINE\n8\n0\n10\n0\n20\n0\n11\n100\n21\n100\n0\nLINE\n8\n0\n10\n100\n20\n100\n11\n200\n21\n200\n0\nENDSEC\n0\nEOF\n');}};}}});
// Load the DWG orientation bridge after setting the runtime mocks.
vm.runInContext(getScript('sq-orientation-axis-reader-module'), context, {timeout:5000});
const apiDwg=window.__sqOriAxisAutoTest;assert(apiDwg&&typeof apiDwg.convertTargetToDxf==='function');
(async()=>{
 const raw=new TextEncoder().encode('AC1027 TEST DWG CONTENT');
 const target={name:'source.dwg',arrayBuffer:async()=>raw.buffer.slice(raw.byteOffset,raw.byteOffset+raw.byteLength)};
 const result=await apiDwg.convertTargetToDxf(target);
 assert.equal(createPath,'file:///android_asset/libredwg-writer/wasm');
 assert(receivedBuffer instanceof ArrayBuffer);assert.equal(result.name,'source.dxf');assert(result.bytes.length>64);
 console.log('PASS V148: exact two-point residual within numeric tolerance; no coordinate clamp/axis flip.');
 console.log('PASS V148: DIMENSION WCS groups 10/13/14/15 and OCS groups 11/12/16 transform separately.');
 console.log('PASS V148: IMAGE/WIPEOUT WCS insertion/axes transform while image sizes and clipping vertices remain local.');
 console.log('PASS V148: orientation DWG bridge uses packaged WASM runtime and checks converted DXF structure.');
 console.log('PASS V148: viewport is smaller; both canvas limits are 44vh/250-500px.');
})().catch(e=>{console.error(e);process.exitCode=1;});
