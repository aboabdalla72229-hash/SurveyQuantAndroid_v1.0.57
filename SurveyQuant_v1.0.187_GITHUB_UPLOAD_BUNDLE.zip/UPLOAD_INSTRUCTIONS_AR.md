# تعليمات رفع بناء SurveyQuant v1.0.187

## الملفات المطلوبة داخل المستودع

1. ارفع `SurveyQuant_v1.0.187_CLEAN_SESSION_PDF_DXF_SOURCE_PATCH.zip` إلى جذر المستودع، بجوار ملفات المشروع.
2. ارفع `build-v187-clean-session-pdf-dxf.yml` إلى المسار التالي حرفيًا:
   `.github/workflows/build-v187-clean-session-pdf-dxf.yml`

## تشغيل البناء

- افتح GitHub ثم المستودع `aboabdalla72229-hash/SurveyQuantAndroid_v1.0.57`.
- افتح تبويب Actions.
- اختر `Build SurveyQuant v1.0.187 Clean Orientation + PDF DXF Only`.
- اضغط Run workflow واترك `source_run_id` على القيمة الافتراضية `41326866230`.
- يجب أن تكون أسرار توقيع APK الأربعة المستخدمة في المشروع موجودة: `SURVEYQUANT_KEYSTORE_BASE64`, `SURVEYQUANT_KEYSTORE_PASSWORD`, `SURVEYQUANT_KEY_ALIAS`, `SURVEYQUANT_KEY_PASSWORD`.
- لا يعتبر البناء ناجحًا إلا بعد نجاح اختبارات المصدر وتدقيق DXF وتوقيع APK. الناتج سيكون Artifact باسم `SurveyQuant-v1.0.187-CLEAN-SESSION-PDF-DXF`.

## ما الذي يتغير

- شاشة التوجيه تعرض اللوحة المحددة فقط في الشاشة النشطة.
- استبدال أي لوحة يمسح نقاط التحويل الأربع والنتيجة القديمة من الجلسة.
- الخروج من مشروع التوجيه أو التحويل ينظف بيانات الجلسة المؤقتة.
- مشروع PDF يقبل PDF فقط ويصدر DXF واحدًا، دون إخراج صور أو تضمين IMAGE/IMAGEDEF.
- الملفات المتجهية المدعومة تصدر بصيغة DXF R2000، مع TrueColor وlineweight وHATCH للتعبئات المغلقة.
- الصفحات النقطية والتدرجات والقص وForm XObjects وبعض أنماط الألوان/الخطوط غير المدعومة يتم رفضها بدل تسليم DXF ناقص على أنه مطابق.

## حدود الاختبار

الاختبارات تشمل ملفات PDF تجريبية متجهية ومملوءة وصورة نقطية، واختبارات التوجيه وعزل الجلسة وتدقيق `ezdxf`. لم يتم اختبار ملف PDF المعماري الأصلي أو فتح APK على جهاز Android/AutoCAD الخاص بالمستخدم في هذه البيئة. المنحنيات المتجهية تتحول إلى polylines بتقسيم 64 خطوة لكل منحنى، لذلك لا يصح وصف كل صفحة PDF بأنها نسخة رياضية مطابقة 100% في كل الحالات.
