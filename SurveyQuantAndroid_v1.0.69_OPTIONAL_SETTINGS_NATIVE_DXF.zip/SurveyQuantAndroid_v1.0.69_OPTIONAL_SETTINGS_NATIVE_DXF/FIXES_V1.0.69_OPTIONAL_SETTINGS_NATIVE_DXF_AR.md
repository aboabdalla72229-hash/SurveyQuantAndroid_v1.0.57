# SurveyQuant v1.0.69

- Project output settings are session-only and are never persisted in localStorage.
- A new explicit checkbox controls whether optional output settings are applied. Default: OFF.
- Legacy saved project/compare settings are removed at startup.
- DXF-to-DXF projection bypasses all output settings and uses the native DXF merge path.
- Reference DXF remains the base document; source DXF resources are renamed only on actual name collisions to avoid changing reference properties.
- PNT/SDR XY behavior from v1.0.67 is retained.
