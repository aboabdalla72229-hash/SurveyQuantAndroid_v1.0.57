'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(process.argv[2]||__dirname);
const engine=fs.readFileSync(path.join(root,'SurveyQuant_v1.0.177_CAD_ENGINE.js'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const embeddedStart=html.indexOf('<script id="sq176-cad-engine">');
assert.ok(embeddedStart>=0,'embedded CAD engine not found');
const scriptStart=html.indexOf('>',embeddedStart)+1;
const scriptEnd=html.indexOf('</script>',scriptStart);
assert.ok(scriptEnd>scriptStart,'embedded CAD script terminator missing');
const embedded=html.slice(scriptStart,scriptEnd);
assert.equal(embedded.trim(),engine.trim(),'embedded and standalone CAD engines must be exactly synchronized');
for(const [name,source] of [['external engine',engine],['embedded app engine',embedded]]){
 assert.match(source,/function setSourceBoardMode\(oriented\)/,name+': oriented output mode missing');
 assert.match(source,/setSourceBoardMode\(true\);activateBoardPanel\('source'\)/,name+': after alignment must switch to transformed source');
 assert.match(source,/function redrawAll\(\)\{redrawOne\(state\.activeBoardSide\);\}/,name+': only selected board may be redrawn');
 assert.match(source,/#sq162-cad-dialog \[data-board-panel\]\{display:none!important\}/,name+': only the active panel may be visible');
 assert.match(source,/state\.picks=\[null,null,null,null\]/,name+': all four picks must be cleared');
 assert.match(source,/input\.addEventListener\('click',\(\)=>\{input\.value='';\}\)/,name+': selecting the same basename again must trigger change');
 assert.match(source,/root\.safeDownloadFile\(bytes, filename, mime, false, true\)/,name+': CAD save must bypass WebView JS prompt');
}
assert.match(html,/async function safeDownloadFile\(content, filename, mime='application\/octet-stream', autoOpen=false, skipPrompt=false\)/,'safe download helper must support prompt-free CAD save');
assert.match(html,/skipPrompt\?String\(filename\|\|'SurveyQuant_Output\.bin'\):chooseDownloadFilename/,'safe download must honor skipPrompt');
console.log(JSON.stringify({embeddedAndExternalEngine:'PASS',postAlignmentOnlyShowsOrientedSource:'PASS',oneVisibleCanvas:'PASS',newFileClearsAllFourPoints:'PASS',sameFilenameCanBeReplaced:'PASS',pdfAndOrientationSaveSkipPrompt:'PASS',result:'PASS'},null,2));
