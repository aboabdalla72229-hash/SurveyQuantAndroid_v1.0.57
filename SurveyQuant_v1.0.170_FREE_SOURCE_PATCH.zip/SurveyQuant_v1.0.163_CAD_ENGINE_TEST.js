'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const CAD = require('./SurveyQuant_v1.0.163_CAD_ENGINE.js');
const close = (a,b,eps=1e-7) => assert.ok(Math.abs(a-b) < eps, `${a} != ${b}`);

// A 10-unit source baseline must align to a 20-unit vertical target baseline:
// 2x scale, +90 degrees, with A mapped exactly to C and B to D.
const transform = CAD.solve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
close(transform.scale,2); close(transform.rotationDegrees,90);
const mappedA = transform.apply({x:0,y:0}), mappedB = transform.apply({x:10,y:0});
close(mappedA.x,100); close(mappedA.y,200); close(mappedB.x,100); close(mappedB.y,220);

const fixture = [
  '0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','0','ENDSEC',
  '0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','2',
  '0','LAYER','5','10','2','0','70','0','62','7','6','CONTINUOUS',
  '0','LAYER','5','11','2','ROADS','70','0','62','1','6','CONTINUOUS','0','ENDTAB','0','ENDSEC',
  '0','SECTION','2','ENTITIES',
  '0','LINE','5','20','100','AcDbEntity','8','ROADS','100','AcDbLine','10','0','20','0','30','0','11','10','21','0','31','0',
  '0','CIRCLE','5','21','8','ROADS','10','1','20','2','30','0','40','3',
  '0','TEXT','5','22','8','ROADS','10','1','20','1','40','2','1','AXIS A',
  '0','ENDSEC','0','EOF',''
].join('\r\n');
const input = new TextEncoder().encode(fixture);
const out = CAD.transformDxfBytes(input,{x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
const text = new TextDecoder('windows-1252').decode(out.bytes);
assert.ok(text.includes('0\r\nLINE\r\n5\r\n20\r\n100\r\nAcDbEntity\r\n8\r\nROADS'), 'entity order, handle and layer must remain');
assert.ok(text.includes('10\r\n100\r\n20\r\n200\r\n30\r\n0\r\n11\r\n100\r\n21\r\n220'), 'line endpoints must be aligned');
assert.ok(text.includes('10\r\n96\r\n20\r\n202\r\n30\r\n0\r\n40\r\n6'), 'circle center transforms and radius scales');
assert.ok(text.includes('1\r\nAXIS A'), 'text content must remain unchanged');
assert.ok(text.includes('2\r\nROADS'), 'layer name remains present');
assert.ok(out.editCount >= 8, 'expected entity coordinates and dimensions to be edited');

const geometry = CAD.readGeometry(input);
assert.ok(geometry.segments.length >= 1, 'preview geometry reads LINE entities');
const picked = CAD.nearestPoint(geometry,{x:4,y:0.1});
close(picked.x,4); close(picked.y,0);
let degenerate = false;
try { CAD.solve({x:1,y:1},{x:1,y:1},{x:0,y:0},{x:2,y:2}); } catch (_) { degenerate = true; }
assert.ok(degenerate, 'coincident control points must be rejected');

const traced = CAD.svgPathToPolylines('M 0 0 L 10 0 L 10 10 Z');
assert.equal(traced.length,1); assert.ok(traced[0].closed); assert.ok(traced[0].points.length >= 4);
const imageDxf = CAD.polylinesToDxf(traced,20,20,1);
assert.ok(new TextDecoder().decode(imageDxf.bytes).includes('POLYLINE'));
console.log('PASS V163: two-point similarity alignment, raw DXF coordinate edits, layer/handle/text retention, snap-preview, degenerate-point protection, and raster-trace DXF output.');
const cross = {segments:[{a:{x:0,y:5},b:{x:10,y:5}},{a:{x:5,y:0},b:{x:5,y:10}}],points:[]};
const isnap = CAD.snapPoint(cross,{x:5.1,y:5.1},'intersection',0.5);
assert.equal(isnap.type,'intersection'); close(isnap.point.x,5); close(isnap.point.y,5);
const endpoint = CAD.snapPoint(cross,{x:0.1,y:5.1},'endpoint',0.5);
assert.equal(endpoint.type,'endpoint'); close(endpoint.point.x,0); close(endpoint.point.y,5);
const midpoint = CAD.snapPoint(cross,{x:5,y:5.2},'midpoint',1);
assert.equal(midpoint.type,'midpoint');
const tooFar = CAD.snapPoint(cross,{x:50,y:50},'intersection',0.5);
assert.equal(tooFar,null);
console.log('PASS V163 snap tests: intersection, endpoint, midpoint, and no-snap tolerance.');

const uiSource=fs.readFileSync(require.resolve('./SurveyQuant_v1.0.163_CAD_ENGINE.js'),'utf8');
assert.ok(uiSource.includes('height:420px')&&uiSource.includes('height:380px'),'larger desktop and mobile preview canvases');
assert.ok(uiSource.includes("action==='in'?2:1/2")&&uiSource.includes('Math.min(10000'),'strong zoom range and 2x controls');
assert.ok(uiSource.includes('updateSnapPreview')&&uiSource.includes('hover?.point'),'visible snap preview is painted while picking');
assert.ok(uiSource.includes('value=\"intersection\"')&&uiSource.includes('value=\"endpoint\"')&&uiSource.includes('value=\"midpoint\"'),'intersection, endpoint and midpoint snap modes are available');
assert.ok(uiSource.includes("addEventListener('wheel'")&&uiSource.includes('pointers.size===2'),'wheel zoom and two-finger pinch gestures are available');
console.log('PASS V163 viewport controls: large zoom, pinch/pan, snap modes and visible snap preview.');

// Preview and snap must see axis geometry stored inside BLOCK definitions and
// placed by INSERT, not only entities directly in model space.
const blockFixture = [
  '0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','0','ENDSEC',
  '0','SECTION','2','BLOCKS',
  '0','BLOCK','5','10','2','AXIS_GRID','70','0','10','0','20','0',
  '0','LINE','8','0','10','0','20','0','11','10','21','0',
  '0','LINE','8','0','10','5','20','-5','11','5','21','5',
  '0','ENDBLK','8','0','0','ENDSEC',
  '0','SECTION','2','ENTITIES',
  '0','INSERT','8','0','2','AXIS_GRID','10','100','20','200','41','2','42','2','50','90',
  '0','ENDSEC','0','EOF',''
].join('\n');
const blockGeom=CAD.readGeometry(new TextEncoder().encode(blockFixture));
assert.equal(blockGeom.segments.length,2,'INSERT expands lines from its BLOCK definition');
const blockCross=CAD.snapPoint(blockGeom,{x:100.1,y:210.1},'intersection',1);
assert.equal(blockCross.type,'intersection','axis intersection inside inserted block is snappable');
close(blockCross.point.x,100);close(blockCross.point.y,210);
console.log('PASS V163 block-aware preview: inserted BLOCK geometry is transformed by scale/rotation/translation and exposes axis intersections to snap.');

