'use strict';
const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const file=process.argv[2];assert(file,'usage: node SurveyQuant_v1.0.151_ALIGNMENT_COMMAND_TEST.js patched-index.html');
const html=fs.readFileSync(file,'utf8');
assert.equal((html.match(/const SQ_APP_VERSION_CODE = 151;/g)||[]).length,1,'version code must be 151 exactly once');
assert.equal((html.match(/id="sq-alignment-command-module"/g)||[]).length,1,'new ALIGNMENT command module must be installed once');
const at=html.indexOf('<script id="sq-alignment-command-module">');assert(at>=0,'new module not found');
const end=html.indexOf('</script>',at);assert(end>at,'new module script closing tag missing');
const mod=html.slice(at,end);
for(const [token,label] of [
 ['window.sqOpenAlignmentCommand=show','new command entry point'],
 ["const oldBtn=$('sqOrientationMenuButton');if(oldBtn)oldBtn.remove();",'old menu button removal'],
 ["const oldCard=$('sqOrientationCard');if(oldCard)oldCard.remove();",'old project card removal'],
 ['id="sq110TargetCanvas"','source drawing canvas'],
 ['id="sq110ReferenceCanvas"','reference drawing canvas'],
 ['await api.openCad(file)','shared DXF/DWG reader'],
 ['engine.transformBytes(source.bytes,t)','geometric byte transformer'],
 ['result.entitiesBefore!==result.entitiesAfter','entity-count export guard'],
 ['signature!==lastPreviewSignature','require reviewed preview before export'],
 ["base+'_ALIGNED.dxf'",'new DXF output'],
 ['function resetSession(announce=false)','fresh-session reset'],
 ['s.loadSerial.target=(s.loadSerial.target||0)+1','invalidate older async loads'],
 ['لا تُجبر الإحداثيات على أن تكون موجبة','no forced coordinate sign mutation']
]) assert(mod.includes(token),'missing '+label);
assert(!/localStorage|sessionStorage|indexedDB/.test(mod),'alignment session must not persist board results between opens');
assert(!mod.includes('api.parsePreview(result.bytes)'),'export must not parse the entire output into a second large preview model');
assert(mod.includes('function fillExactReadouts()')&&mod.includes('String(n)'),'coordinate readouts must preserve full Number string precision');
assert(html.includes('window.parseFile = parseFile;'),'shared DWG parser export must remain available');
assert(html.includes('await LibreDwg.create(sqDwgWasmRuntimePath())'),'local DWG WASM runtime must be preserved');
assert(!html.includes("card.id = 'sqOrientationCard'"),'legacy project card constructor must be retired from the active source');
// Exercise the real two-point solver extracted from the production HTML.
const solveStart=html.indexOf('function solve(src1,src2,ref1,ref2){');
const solveEnd=html.indexOf('// Replace the prior guard',solveStart);
assert(solveStart>=0&&solveEnd>solveStart,'production alignment solver not found');
const ctx=vm.createContext({Math,Number,Error});
vm.runInContext(html.slice(solveStart,solveEnd)+'\nthis.solve=solve;',ctx,{timeout:5000});
const cases=[
 {s1:{x:-300,y:-200},s2:{x:-100,y:-200},r1:{x:5000,y:8000},r2:{x:5000,y:8400},scale:2,angle:90},
 {s1:{x:100,y:100},s2:{x:200,y:100},r1:{x:4000,y:7000},r2:{x:4100,y:7000},scale:1,angle:0},
 {s1:{x:0,y:0},s2:{x:0,y:50},r1:{x:576761.446,y:858279.357},r2:{x:576711.446,y:858279.357},scale:1,angle:90}
];
for(const c of cases){const t=ctx.solve(c.s1,c.s2,c.r1,c.r2);for(const [s,r] of [[c.s1,c.r1],[c.s2,c.r2]]){const p=t.point(s.x,s.y);assert(Math.hypot(p.x-r.x,p.y-r.y)<=Math.max(t.tolerance*2,1e-7),'point residual exceeded tolerance');}assert(Number.isFinite(t.scale)&&t.scale>0,'scale must be positive finite');}
console.log('PASS V151: old orientation card/menu removed and fresh ALIGNMENT command installed');
console.log('PASS V151: shared DWG/DXF reader, local WASM, fresh session, no persistent drawing cache, DXF output');
console.log('PASS V151: production two-point solver maps all test pairs to their reference coordinates within numeric tolerance');
