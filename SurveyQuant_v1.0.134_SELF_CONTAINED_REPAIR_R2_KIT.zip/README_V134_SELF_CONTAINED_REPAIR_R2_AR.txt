إصلاح SurveyQuant v1.0.134 R2

سبب فشل المحاولة السابقة: محرك LibreDWG تم بناؤه ونسخ ملف WASM بنجاح، ثم توقف الـWorkflow عند الأمر `wasm-opt` لأن Binaryen غير مثبت في صورة GitHub Runner.

حل R2: لم يعد wasm-opt متطلبًا إلزاميًا. إذا كان موجودًا يُستخدم كفحص إضافي؛ وإذا لم يكن موجودًا يتجاوزه الـWorkflow برسالة Notice، مع استمرار الفحوصات المطلوبة: وجود ملف WASM المنفصل، صحة توقيع WASM، فحص صياغة ملفات JavaScript، وفحص أصول APK بعد التعبئة.

ارفع الملف `build-v134-self-contained-dwg-dxf-repair-r2.yml` إلى المسار:
`.github/workflows/build-v134-self-contained-dwg-dxf-repair-r2.yml`
ثم شغّل Workflow باسم:
`Build SurveyQuant v1.0.134 - self-contained DWG DXF repair R2 (no hard wasm-opt dependency)`

لا يحتاج هذا الـWorkflow إلى رفع ملف V134 patch ZIP منفصلًا، لأن ملف التصحيح مضمّن بداخله ويُستخرج ويُتحقق من SHA-256 قبل التطبيق. ملفات الأساس V126 وتعديلات V129/V130/V131 تظل مطلوبة في جذر المستودع كما في مسار البناء السابق.

يشمل التصحيح: محرك DWG/DXF محلي ضمن APK، توليد تعريفات TypeScript مع `-s WASM_BIGINT=1`، هندسة رباعي الأرض والتحقق من الأطوال، ومسح localStorage وsessionStorage ومحاولة حذف قواعد IndexedDB التابعة لأصل التطبيق عند بداية التشغيل/مغادرة المستند.

تم التحقق محليًا من صياغة YAML وكتل Bash، وبصمة ملف ZIP المضمّن، وتشغيل patcher واختبار الانحدار على fixture ممثل. لم يتم بناء APK النهائي بالكامل على GitHub حتى الآن؛ يلزم انتظار نجاح الـWorkflow ثم اختبار ملفات DWG/DXF حقيقية على الهاتف قبل اعتبار النسخة نهائية.
