'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const htmlPath = process.argv[2] || '/mnt/data/v139source/index.html';
const html = fs.readFileSync(htmlPath,'utf8');
const match = html.match(/function sqOriSolveMultiple\(pairs\) \{[\s\S]*?\n\}/);
if (!match) throw new Error('solver missing');
const ctx = { Math, Number, Error, Array };
vm.createContext(ctx);
vm.runInContext(match[0] + ';this.__solve=sqOriSolveMultiple;',ctx);
const solve = ctx.__solve;
const transform=(x,y)=>({x:-100-2*y,y:300+2*x});
const points=[[0,0],[10,0],[0,10],[10,10],[20,15]].map(([x,y],i)=>({key:'P'+i,source:{x,y},reference:transform(x,y)}));
const r=solve(points);
for(const [k,want] of [['scale',2],['angleDeg',90],['tx',-100],['ty',300]]) if(Math.abs(r[k]-want)>1e-8)throw new Error(k+' mismatch '+r[k]);
if(r.inlierCount!==5||r.excludedCount!==0||r.rms>1e-8)throw new Error('clean fit residual validation failed '+JSON.stringify({inliers:r.inlierCount,excluded:r.excludedCount,rms:r.rms}));
const outlier=solve(points.concat([{key:'BAD',source:{x:30,y:20},reference:{x:-1140,y:1360}}]));
if(outlier.inlierCount!==5||outlier.excludedCount!==1)throw new Error('outlier was not rejected '+JSON.stringify({inliers:outlier.inlierCount,excluded:outlier.excludedCount}));
const q=outlier.point(20,15);if(Math.hypot(q.x-transform(20,15).x,q.y-transform(20,15).y)>1e-8)throw new Error('fit distorted by outlier');
// Reject poor correspondence sets rather than outputting an arbitrary transformation.
let rejected=false;try{solve(points.concat([{key:'BAD1',source:{x:30,y:20},reference:{x:8000,y:3000}},{key:'BAD2',source:{x:40,y:15},reference:{x:-3400,y:-9400}},{key:'BAD3',source:{x:50,y:9},reference:{x:10000,y:-500}},{key:'BAD4',source:{x:60,y:4},reference:{x:-18000,y:11000}}]));}catch(e){rejected=/فشل التحقق متعدد النقاط|لم تتفق تقاطعات/.test(e.message);}
if(!rejected)throw new Error('inconsistent matching set should be rejected');
if(!html.includes('return sqOriSolveMultiple(state.axisMatches)'))throw new Error('active calculation is not using the multipoint solution');
if(!html.includes("if(t==='XLINE'||t==='RAY'){const base=pointAt(rec,10);if(base)add(base);return {pts,segments};}"))throw new Error('XLINE/RAY false-segment guard missing');
console.log('PASS: exact translation/rotation/scale with negative reference X');
console.log('PASS: five consistent intersections yield negligible RMS');
console.log('PASS: one outlier rejected without distorting fitted transform');
console.log('PASS: inconsistent multi-point correspondences fail closed');
console.log('PASS: active calculation uses multipoint solver and XLINE/RAY picker fix is present');
