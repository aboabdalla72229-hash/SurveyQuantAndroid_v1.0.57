# حزمة V178

ترفع هذه الحزمة إلى جذر مستودع SurveyQuant باسم `SurveyQuant_v1.0.178_FIX_KIT.zip`.

تتضمن تصحيحات V176/V177 المطلوبة لإعادة بناء مصدر V162 النظيف، ثم محرك V178 الذي يعالج هوية نقاط المصدر والمرجع والحفظ عبر Android WebView. كما تتضمن اختبارات دمج DXF، اختبار بيانات المساحة ذات الإحداثيات الكبيرة والسالبة، واختبار واجهة Chromium للحفظ.

Workflow منفصل: `.github/workflows/build-v178-v162-orientation-save-fix.yml`.
المصدر الأساسي الافتراضي: V162 Actions run `40919113310`.

الاختبارات المحلية موثقة في `V178_TEST_REPORT_AR.txt`. اختبار Android bridge محاكاة في Chromium، وليس تشغيلًا على هاتف فعلي.
