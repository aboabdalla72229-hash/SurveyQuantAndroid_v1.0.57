'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const htmlPath=process.argv[2];
const enginePath=process.argv[3];
if(!htmlPath||!enginePath)throw new Error('Usage: node SurveyQuant_v1.0.164_APP_REGRESSION_TEST.js <index.html> <engine.js>');
const html=fs.readFileSync(htmlPath,'utf8'),engine=fs.readFileSync(enginePath,'utf8');
for(const [label,needle] of [
 ['named output dialog','id=\'sqDownloadNameDialog\''],
 ['user confirms a filename','حفظ وتنزيل'],
 ['output dialog tells user the save folder','Downloads/SurveyQuant'],
 ['async modal returns a selected name','const requestedName=await chooseDownloadFilename('],
 ['Android file-save bridge','window.Android.saveFile(finalName,mime,base64)'],
 ['Android download notification','window.Android.notifyDownload(finalName,String(result),mime)'],
 ['notification failure cannot mask saved file','Download notification failed after successful save'],
 ['drop-file DXF uses shared save helper','safeDownloadFile(droppedDXF'],
])assert.ok(html.includes(needle),label);
assert.ok(!html.includes("window.prompt('اكتب اسم اللوحة / الملف المخرج:"),'legacy browser prompt must be removed');
assert.ok(engine.includes('root.safeDownloadFile(bytes, filename, mime, false)'),'alignment/raster output must use app native save workflow');
assert.ok(engine.includes('texts: []')&&engine.includes('for (const label of (geom.texts || []).slice(0, 6000))'),'CAD preview draws extracted axis labels');
assert.ok(engine.includes('block.geometry.texts||[]'),'labels in inserted blocks are included');
const match=html.match(/<script\s+type="application\/octet-stream"\s+id="sq163-cad-engine">([A-Za-z0-9+/=\r\n]+)<\/script>/i);
assert.ok(match,'embedded CAD engine payload exists');
const embedded=Buffer.from(match[1].trim(),'base64');
assert.equal(embedded.toString('utf8'),engine,'the injected CAD engine exactly matches the unit-tested engine');
(async()=>{
 const calls=[];
 const source=html.slice(html.indexOf('async function safeDownloadFile('));
 // Static/packaging checks prove the production function path; the engine bridge itself
 // is exercised by the CAD_ENGINE_TEST against a fake Android-aware safeDownloadFile.
 assert.ok(source.indexOf('window.Android.saveFile')<source.indexOf('window.Android.notifyDownload'),'save must precede notification');
 console.log('PASS V164 app regression: filename dialog, native save + notification path, drop-DXF shared save, embedded engine identity, and axis-label rendering are wired.');
})().catch(e=>{console.error(e);process.exit(1);});
