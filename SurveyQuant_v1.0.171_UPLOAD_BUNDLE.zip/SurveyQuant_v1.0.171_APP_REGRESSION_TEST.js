'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const htmlFile=process.argv[2],engineFile=process.argv[3];
if(!htmlFile||!engineFile)throw new Error('Usage: node V171_APP_REGRESSION_TEST.js <patched-index.html> <engine.js>');
const html=fs.readFileSync(htmlFile,'utf8'),engine=fs.readFileSync(engineFile,'utf8');
for(const marker of ['sq170-orientation-canvas-zoom-per-board-picks-snap-wasm-binary-pdf-worker-ole-reader','sq171-home-shortcuts-pdf-image-underlay-paired-save','sq163-pdfjs-worker','sq162-wasm-binary','sq164-cad-output-axis-fix','sqDownloadNameDialog','sq166-readonly-source-and-exact-pdf-raster','sq167-dwg-orientation-view-transform','sq168-pdf-access-axis-points-explicit-snap-fix','sq169-orientation-save-block-axis-content-identity-single-dxf-ole','user-scalable=no','installGlobalPdfWorkerGuard','createByWasmInstance'])assert.ok(html.includes(marker),'Missing HTML marker: '+marker);
const embedded=html.match(/<script\s+type="application\/octet-stream"\s+id="sq163-cad-engine">([A-Za-z0-9+\/ =\r\n]+)<\/script>/i);
assert.ok(embedded,'embedded CAD engine missing');assert.equal(Buffer.from(embedded[1].replace(/\s/g,''),'base64').toString('utf8'),engine,'embedded engine differs from the tested V171 engine');
const menu=html.match(/<div class="home-menu">([\s\S]*?)<\/div>/i);assert.ok(menu,'home project grid missing');
for(const id of ['project1Card','profileCard','roadCard','pipeCard','landAreaCard','fileToDxfCard','cleanFilesCard','dropFilesCard']){
  assert.ok(html.includes(`id="${id}"`),'Existing project card disappeared: '+id);
  assert.ok(menu[1].includes(`openProjectPage('${id}')`),'Existing home-menu shortcut disappeared: '+id);
}
for(const marker of ['sq-home-orientation-project','sq-home-pdf-project','📐 9 توجيه اللوحات','📄 10 تحويل PDF إلى DXF','addHomeShortcut'])assert.ok(engine.includes(marker),'Missing restored shortcut behavior: '+marker);
for(const marker of ['function makeRasterUnderlayDxf','function downloadPairedRasterFile','const jpegBytes=await canvasJpegBytes(canvas,0.96)','await downloadPairedRasterFile(jpegBytes,imageName,\'image/jpeg\')','await downloadPairedRasterFile(dxfBytes,dxfName,\'application/dxf\')','IMAGE/IMAGEDEF القياسي بدل OLE2FRAME'])assert.ok(engine.includes(marker),'Missing V171 PDF pair behavior: '+marker);
assert.ok(engine.includes("'0','IMAGE'")&&engine.includes("'0','IMAGEDEF'"),'standard raster image entities are missing');
assert.ok(!engine.includes('makeEmbeddedRasterDxf(jpegTiles,canvas.width,canvas.height,factor)'),'PDF exporter still writes OLE2FRAME instead of IMAGE/IMAGEDEF');
assert.ok(engine.includes('const name=requested.replace(/[^A-Za-z0-9_.-]/g'), 'IMAGEDEF filename must be normalized to an ASCII basename');
assert.ok(engine.includes('const homeGrid=doc.querySelector(\'#homeMenu .home-menu\')'),'home shortcuts must be inserted into the visible original project grid');
console.log(JSON.stringify({ok:true,existingHomeProjectShortcuts:8,restoredHomeShortcuts:2,pdfExport:'standard IMAGE + IMAGEDEF + paired JPG sidecar',saveOrder:'JPG sidecar first, DXF second',embeddedEngineBytes:Buffer.byteLength(engine)},null,2));
