# V150 Root Cause Fix

- **version**: `150`
- **spline_preview**: `rational B-spline sampled; no control-polygon chords when knots missing`
- **session_reset**: `open/close and every new file attempt clear relevant in-memory board state`
- **dwg_path**: `uses canonical parseFile DWG->DXF parser and checks rawDXFBytes`
- **wcs_coordinate_diagnostic**: `point mapping residual and negative coordinates explicitly explained`
- **mobile_canvas**: `34vh, 200-360px`
- **sha256**: `aa009ff046428bd3b76ee3196a605359e701168b9cf685b53e72b3321c749022`
