/* SurveyQuant V1.0.151: fresh ALIGNMENT command UI/controller.
 * It removes the legacy orientation project's user entry points and mounts a clean two-board CAD ALIGN flow.
 * Drawing parsing, DWG->DXF reading, OSNAP and byte-preserving entity transforms are delegated to the app's tested core APIs.
 */
(function () {
'use strict';
if (window.__sqAlignment151Installed) return;
window.__sqAlignment151Installed = true;
const $ = id => document.getElementById(id);
const api = window.__sqOrientation111API;
let lastPreviewSignature=null;
function fillExactReadouts(){
 if(!api||!api.state)return;
 if(typeof api.fillReadouts==='function')api.fillReadouts();
 const fmt=v=>{if(!Number.isFinite(Number(v)))return '';const n=Number(v);return Object.is(n,-0)?'0':String(n);};
 const s=api.state;
 for(const [side,prefix,list] of [['target','T',s.targetPoints||[]],['reference','R',s.referencePoints||[]]]){
  for(let i=0;i<2;i++){
   const p=list[i]||null;
   for(const axis of ['X','Y']){const input=$('sq110'+prefix+(i+1)+axis);if(input)input.value=p&&Number.isFinite(Number(p[axis.toLowerCase()]))?fmt(p[axis.toLowerCase()]):'';}
  }
 }
}

const styleText = `
#sqOriOverlay.sq151-overlay{position:fixed;inset:0;z-index:2147483000;background:rgba(3,8,18,.92);display:none;overflow:auto;padding:5px;box-sizing:border-box}
#sqOriOverlay.sq151-overlay .sqori-dialog{width:min(98vw,900px);max-width:900px;max-height:94dvh;overflow:auto;margin:4px auto;padding:10px;background:#142033;color:#f3f7fb;border:1px solid #42536b;border-radius:16px;box-sizing:border-box;font-family:inherit}
#sqOriOverlay.sq151-overlay h2{font-size:20px;text-align:center;margin:8px 0 10px}#sqOriOverlay.sq151-overlay h3{font-size:15px;margin:8px 0}
#sqOriOverlay.sq151-overlay .sq151-note{font-size:12px;color:#cbd5e1;line-height:1.65;margin:6px 0}
#sqOriOverlay.sq151-overlay .sq151-tabs{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:8px 0}
#sqOriOverlay.sq151-overlay button{border:0;border-radius:8px;padding:9px 10px;font:inherit;font-size:13px;font-weight:750;cursor:pointer}
#sqOriOverlay.sq151-overlay .sqori-preview,#sqOriOverlay.sq151-overlay .sq151-blue{background:#2563eb;color:#fff}
#sqOriOverlay.sq151-overlay .sqori-run,#sqOriOverlay.sq151-overlay .sq151-green{background:#16803d;color:#fff}
#sqOriOverlay.sq151-overlay .sqori-close,#sqOriOverlay.sq151-overlay .sq151-gray{background:#374151;color:#fff}
#sqOriOverlay.sq151-overlay .sq151-red{background:#991b1b;color:#fff}
#sqOriOverlay.sq151-overlay .sq151-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
#sqOriOverlay.sq151-overlay label{display:block;font-size:13px;font-weight:700;margin:6px 0}
#sqOriOverlay.sq151-overlay input[type=file],#sqOriOverlay.sq151-overlay input[type=number],#sqOriOverlay.sq151-overlay select{width:100%;box-sizing:border-box;background:#0b1220;color:#fff;border:1px solid #42536b;border-radius:8px;padding:9px;margin-top:4px;min-width:0}
#sqOriOverlay.sq151-overlay .sq151-toolbar{display:flex;gap:5px;flex-wrap:wrap;margin:6px 0}
#sqOriOverlay.sq151-overlay .sq151-toolbar button{padding:7px 8px;font-size:12px}
#sqOriOverlay.sq151-overlay canvas{display:block;width:100%;height:32vh;min-height:180px;max-height:320px;border:1px solid #42536b;border-radius:10px;touch-action:none;background:#0b1220}
#sqOriOverlay.sq151-overlay .sq151-fileinfo{font-size:12px;color:#a7f3d0;overflow-wrap:anywhere;margin:4px 0}
#sqOriOverlay.sq151-overlay .sq151-status{display:none;white-space:pre-wrap;overflow-wrap:anywhere;border:1px solid #49617d;border-radius:9px;padding:9px;margin:8px 0;font-size:13px;line-height:1.7}
#sqOriOverlay.sq151-overlay .sq151-coordinate-table{width:100%;border-collapse:collapse;font-size:12px;margin:8px 0}
#sqOriOverlay.sq151-overlay .sq151-coordinate-table th,#sqOriOverlay.sq151-overlay .sq151-coordinate-table td{border:1px solid #34445a;padding:4px;text-align:center}
#sqOriOverlay.sq151-overlay .sq151-coordinate-table input{width:100%;min-width:0;box-sizing:border-box;background:#0b1220;color:#fff;border:1px solid #42536b;border-radius:5px;padding:6px}
#sqOriOverlay.sq151-overlay .sq151-bottom-actions{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:8px}
#sqOriOverlay.sq151-overlay details{border:1px solid #33445d;border-radius:7px;padding:5px;margin:5px 0}
#sqOriOverlay.sq151-overlay #sq110TLayerPanel,#sqOriOverlay.sq151-overlay #sq110RLayerPanel{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:2px;max-height:100px;overflow:auto}
@media(max-width:520px){#sqOriOverlay.sq151-overlay .sq151-grid{grid-template-columns:1fr}#sqOriOverlay.sq151-overlay .sq151-note{font-size:11px}#sqOriOverlay.sq151-overlay canvas{height:30vh;min-height:170px;max-height:270px}#sqOriOverlay.sq151-overlay .sq151-toolbar button{padding:6px;font-size:11px}}
`;

function createMarkup(){
 const host=document.createElement('div');
 host.id='sqOriOverlay';host.className='sqori-overlay sq151-overlay';host.style.display='none';
 host.innerHTML=`<div class="sqori-dialog" role="dialog" aria-modal="true" aria-labelledby="sq151Title">
 <button id="sq151Close" class="sqori-close" type="button" style="float:left">✕ إغلاق</button>
 <h2 id="sq151Title">ALIGNMENT | توجيه هندسي جديد</h2>
 <p class="sq151-note">اختر اللوحة غير الموجّهة، وحدد نقطتين عليها، ثم اختر اللوحة المرجعية وحدد النقطتين المناظرتين بالترتيب نفسه. يحسب الأمر الدوران والمقياس والإزاحة بتحويل تشابه هندسي واحد، ويعرض التراكب قبل التصدير. لا تُجبر الإحداثيات على أن تكون موجبة لأن ذلك يفسد التطابق.</p>
 <div class="sq151-tabs"><button id="sq110Step1" class="sqori-preview" type="button">1) اللوحة المصدر</button><button id="sq110Step2" class="sqori-preview" type="button">2) اللوحة المرجعية</button></div>
 <section id="sq110TargetScreen">
 <h3>اللوحة المصدر غير الموجّهة</h3>
 <label>فتح لوحة DXF أو DWG<input id="sq110TargetFile" type="file" accept=".dxf,.dwg,application/dxf,application/acad"></label>
 <p id="sq110TargetFileInfo" class="sq151-fileinfo"></p>
 <div class="sq151-toolbar">
 <button id="sq110TZoomIn" class="sqori-preview" type="button">تكبير +</button><button id="sq110TZoomBoost" class="sqori-preview" type="button">×5</button><input id="sq110TZoomRange" type="range" min="-0.8" max="5" step="0.01" value="0" aria-label="تكبير اللوحة" style="width:95px">
 <select id="sq110TSnapMode" aria-label="وضع الالتقاط"><option value="auto">OSNAP تلقائي</option><option value="intersection">تقاطع</option><option value="endpoint">رأس/نهاية</option><option value="midpoint">منتصف</option><option value="nearest">أقرب نقطة</option><option value="perpendicular">عمود</option><option value="free">نقرة حرة</option></select>
 <button id="sq110TZoomOut" class="sqori-preview" type="button">تصغير −</button><button id="sq110TFit" class="sqori-preview" type="button">ملاءمة</button><button id="sq110TId" class="sqori-preview" type="button">ID</button>
 <button id="sq110SelectEntity" class="sqori-preview" type="button">تحديد عناصر</button><button id="sq110Delete" class="sqori-preview" type="button">حذف</button><button id="sq110UndoDelete" class="sqori-preview" type="button" disabled>تراجع</button><button id="sq110RedoDelete" class="sqori-preview" type="button" disabled>إعادة</button>
 </div>
 <p id="sq110TargetMode" class="sq151-note">اختر النقطة 1 على اللوحة المصدر</p><canvas id="sq110TargetCanvas"></canvas>
 <details id="sq110TLayerDetails"><summary>طبقات المصدر (إظهار/إخفاء)</summary><div id="sq110TLayerPanel"></div></details>
 <p id="sq110TargetInfo" class="sq151-fileinfo"></p><p id="sq110TargetId" class="sq151-note">ID Point: غير مفعل</p>
 <div class="sq151-toolbar"><button id="sq110TSelect1" class="sqori-preview" type="button">اختيار النقطة 1</button><button id="sq110TSelect2" class="sqori-preview" type="button">اختيار النقطة 2</button><button id="sq110ToReference" class="sqori-green" style="background:#16803d;color:white" type="button">التالي: المرجع ←</button></div>
 </section>
 <section id="sq110ReferenceScreen" style="display:none">
 <h3>اللوحة المرجعية الموجّهة</h3>
 <label>فتح لوحة DXF أو DWG<input id="sq110ReferenceFile" type="file" accept=".dxf,.dwg,application/dxf,application/acad"></label>
 <p id="sq110ReferenceFileInfo" class="sq151-fileinfo"></p>
 <div class="sq151-toolbar">
 <button id="sq110RZoomIn" class="sqori-preview" type="button">تكبير +</button><button id="sq110RZoomBoost" class="sqori-preview" type="button">×5</button><input id="sq110RZoomRange" type="range" min="-0.8" max="5" step="0.01" value="0" aria-label="تكبير اللوحة المرجعية" style="width:95px">
 <select id="sq110RSnapMode" aria-label="وضع الالتقاط"><option value="auto">OSNAP تلقائي</option><option value="intersection">تقاطع</option><option value="endpoint">رأس/نهاية</option><option value="midpoint">منتصف</option><option value="nearest">أقرب نقطة</option><option value="perpendicular">عمود</option><option value="free">نقرة حرة</option></select>
 <button id="sq110RZoomOut" class="sqori-preview" type="button">تصغير −</button><button id="sq110RFit" class="sqori-preview" type="button">ملاءمة</button><button id="sq110RId" class="sqori-preview" type="button">ID</button>
 <button id="sq110RSelectEntity" class="sqori-preview" type="button">تحديد عناصر</button><button id="sq110RDelete" class="sqori-preview" type="button">حذف</button><button id="sq110RUndoDelete" class="sqori-preview" type="button" disabled>تراجع</button><button id="sq110RRedoDelete" class="sqori-preview" type="button" disabled>إعادة</button>
 </div>
 <p id="sq110ReferenceMode" class="sq151-note">اختر النقطة 1 على المرجع</p><canvas id="sq110ReferenceCanvas"></canvas>
 <details id="sq110RLayerDetails"><summary>طبقات المرجع (إظهار/إخفاء)</summary><div id="sq110RLayerPanel"></div></details>
 <p id="sq110ReferenceInfo" class="sq151-fileinfo"></p><p id="sq110ReferenceId" class="sq151-note">ID Point: غير مفعل</p>
 <div class="sq151-toolbar"><button id="sq110RSelect1" class="sqori-preview" type="button">اختيار النقطة 1</button><button id="sq110RSelect2" class="sqori-preview" type="button">اختيار النقطة 2</button><button id="sq110Back" class="sqori-preview" type="button">→ الرجوع للمصدر</button></div>
 </section>
 <h3>إحداثيات نقاط Alignment</h3>
 <div style="overflow-x:auto"><table class="sq151-coordinate-table"><thead><tr><th>النقطة</th><th>المصدر X</th><th>المصدر Y</th><th>المرجع X</th><th>المرجع Y</th></tr></thead><tbody>
 <tr><th>1</th><td><input id="sq110T1X" type="number" step="any" inputmode="decimal"></td><td><input id="sq110T1Y" type="number" step="any" inputmode="decimal"></td><td><input id="sq110R1X" type="number" step="any" inputmode="decimal"></td><td><input id="sq110R1Y" type="number" step="any" inputmode="decimal"></td></tr>
 <tr><th>2</th><td><input id="sq110T2X" type="number" step="any" inputmode="decimal"></td><td><input id="sq110T2Y" type="number" step="any" inputmode="decimal"></td><td><input id="sq110R2X" type="number" step="any" inputmode="decimal"></td><td><input id="sq110R2Y" type="number" step="any" inputmode="decimal"></td></tr>
 </tbody></table></div>
 <p id="sq110StatusPoint1" class="sq151-note">النقطة 1: لم تُحدد بعد</p><p id="sq110StatusPoint2" class="sq151-note">النقطة 2: لم تُحدد بعد</p>
 <p class="sq151-note">معاينة Alignment: المرجع باللون الأصلي، والمصدر المحوّل بخط سماوي. الضغط على التصدير يطبّق التحويل على نسخة DXF جديدة فقط. إدخال DWG مدعوم عبر محرك LibreDWG إلى DXF في الذاكرة؛ الناتج DXF حتى لا يتم ادعاء كتابة DWG أصلي دون محرك كتابة مناسب. الملفات الأصلية لا تتغير، ولا تُحفظ جلسات أو لوحات قديمة عند إغلاق الأمر.</p>
 <div class="sq151-bottom-actions"><button id="sq110Preview" class="sqori-preview" type="button">معاينة التراكب / Alignment</button><button id="sq110Export" class="sqori-run" type="button">تطبيق ALIGNMENT وإخراج DXF</button></div>
 <div id="sq110Status" class="sq151-status" role="status" aria-live="polite"></div>
 <p class="sq151-note">ملاحظة CAD: الكيانات القياسية القابلة للقراءة تُحوّل بتحويل هندسي موحّد. كائنات Proxy/Civil 3D أو المجسمات المملوكة التي لا يكشف محرك DWG/DXF هندستها الداخلية لا يمكن ضمان الحفاظ الكامل عليها عبر DXF نصي؛ سيوقف المحرك التصدير بدل إنشاء لوحة جزئية أو مشوّهة.</p>
 </div>`;
 document.body.appendChild(host);
}
function addStyles(){let s=$('sq151AlignmentStyle');if(s)return;s=document.createElement('style');s.id='sq151AlignmentStyle';s.textContent=styleText;document.head.appendChild(s);}
function installMenu(){
 const oldBtn=$('sqOrientationMenuButton');if(oldBtn)oldBtn.remove();
 const oldCard=$('sqOrientationCard');if(oldCard)oldCard.remove();
 const menu=document.querySelector('#homeMenu .home-menu');
 if(menu&&!$('sqAlignmentCommandMenu')){
  const b=document.createElement('button');b.type='button';b.className='menu-btn';b.id='sqAlignmentCommandMenu';b.textContent='⚙️ ALIGNMENT | توجيه هندسي';
  b.addEventListener('click',window.sqOpenAlignmentCommand);
  const payment=menu.querySelector('.payment-shortcut');if(payment)menu.insertBefore(b,payment);else menu.appendChild(b);
 }
}
function clearPreview(){
 lastPreviewSignature=null;
 const rv=api&&api.state&&api.state.views&&api.state.views.reference;if(!rv)return;
 if(rv._sq151OriginalBounds){rv.drawing.bounds=rv._sq151OriginalBounds;delete rv._sq151OriginalBounds;}
 rv.alignmentPreview=null;try{api.draw(rv);}catch(_){}
}
function resetSession(announce=false){
 if(!api||!api.state)return;
 const s=api.state;
 clearPreview();
 try{api.clearCanvasRuntime('target');}catch(_){}try{api.clearCanvasRuntime('reference');}catch(_){}
 s.loadSerial=s.loadSerial||{target:0,reference:0};s.loadSerial.target=(s.loadSerial.target||0)+1;s.loadSerial.reference=(s.loadSerial.reference||0)+1;
 s.target=null;s.reference=null;s.targetPoints=[null,null];s.referencePoints=[null,null];s.active={target:0,reference:0};s.tool={target:'pick',reference:'pick'};s.snapMode={target:'auto',reference:'auto'};s.views={};
 s.selectedEntity=null;s.selectedEntities=[];s.undoStack=[];s.redoStack=[];s.referenceSelectedEntity=null;s.referenceSelectedEntities=[];s.referenceUndoStack=[];s.referenceRedoStack=[];s.idPoint={target:null,reference:null};
 for(const id of ['sq110TargetFile','sq110ReferenceFile'])if($(id))$(id).value='';
 for(const id of ['sq110TargetFileInfo','sq110ReferenceFileInfo','sq110TargetInfo','sq110ReferenceInfo','sq110TargetId','sq110ReferenceId'])if($(id))$(id).textContent='';
 for(const id of ['sq110T1X','sq110T1Y','sq110T2X','sq110T2Y','sq110R1X','sq110R1Y','sq110R2X','sq110R2Y'])if($(id))$(id).value='';
 for(const id of ['sq110StatusPoint1','sq110StatusPoint2'])if($(id))$(id).textContent='النقطة '+(id.endsWith('1')?'1':'2')+': لم تُحدد بعد';
 for(const id of ['sq110TargetMode','sq110ReferenceMode'])if($(id))$(id).textContent='اختر النقطة 1 على الرسم';
 fillExactReadouts();if(api.updateDeleteHistoryButtons)api.updateDeleteHistoryButtons();if(api.showScreen)api.showScreen('target');
 if(announce&&api.status)api.status('جلسة ALIGNMENT جديدة. تم مسح اللوحتين والنقاط والمعاينة السابقة من الذاكرة؛ اختر اللوحتين من جديد.',false);
 else {const st=$('sq110Status');if(st){st.textContent='';st.style.display='none';}}
}
function show(){const overlay=$('sqOriOverlay');if(!overlay)return;resetSession(true);overlay.style.display='block';document.body.style.overflow='hidden';if(api.showScreen)api.showScreen('target');}
function close(){resetSession(false);const overlay=$('sqOriOverlay');if(overlay)overlay.style.display='none';document.body.style.overflow='';}
window.sqOpenAlignmentCommand=show;window.sqCloseAlignmentCommand=close;
// Old external links now enter the new command; the legacy user project is no longer presented.
window.sqOpenOrientationProject=show;window.sqCloseOrientationProject=close;

function status(msg,bad=false){if(api&&api.status)api.status(msg,bad);else{const b=$('sq110Status');if(b){b.style.display='block';b.textContent=msg;b.style.color=bad?'#fecaca':'#d1fae5';}}}
function clearSide(side){
 clearPreview();try{api.clearCanvasRuntime(side);}catch(_){}
 const s=api.state;s[side]=null;if(side==='target'){s.targetPoints=[null,null];s.selectedEntity=null;s.selectedEntities=[];s.undoStack=[];s.redoStack=[];}else{s.referencePoints=[null,null];s.referenceSelectedEntity=null;s.referenceSelectedEntities=[];s.referenceUndoStack=[];s.referenceRedoStack=[];}
 s.idPoint[side]=null;s.active[side]=0;s.tool[side]='pick';
 fillExactReadouts();if(api.updateDeleteHistoryButtons)api.updateDeleteHistoryButtons();
 for(const id of side==='target'?['sq110TargetFileInfo','sq110TargetInfo','sq110TargetId']:['sq110ReferenceFileInfo','sq110ReferenceInfo','sq110ReferenceId'])if($(id))$(id).textContent='';
}
async function loadFile(side,file){
 if(!api||!api.state)throw new Error('لم يتم تحميل محرك ALIGNMENT. أعد فتح الأمر.');
 const s=api.state;const token=(s.loadSerial[side]||0)+1;s.loadSerial[side]=token;
 if(api.showScreen)api.showScreen(side);clearSide(side);status('تم إخلاء خانة اللوحة السابقة. جاري قراءة '+file.name+' عبر قارئ CAD المشترك…');
 try{
  const data=await api.openCad(file);
  if(token!==s.loadSerial[side])return;
  if(!data||!(data.bytes instanceof Uint8Array)||data.bytes.length<64)throw new Error('لم يرجع قارئ CAD ملف DXF صالحًا للمعاينة.');
  s[side]={bytes:data.bytes.slice(),name:data.name||file.name,originalName:file.name,wasDWG:/\.dwg$/i.test(file.name)};
  const view=api.loadView(side,s[side].bytes,s[side].name);
  if(token!==s.loadSerial[side]){api.clearCanvasRuntime(side);s[side]=null;return;}
  view.canvas.addEventListener('pointerdown',clearPreview,{capture:true});
  s.active[side]=0;s.tool[side]='pick';s.snapMode[side]='auto';
  fillExactReadouts();if(api.updateDeleteHistoryButtons)api.updateDeleteHistoryButtons();api.draw(view);api.refreshVisibleCadCanvas(side);
  const info=$(side==='target'?'sq110TargetFileInfo':'sq110ReferenceFileInfo');if(info)info.textContent='الملف الأصلي: '+file.name+' | عناصر: '+view.drawing.entityCount+' | مقاطع: '+(view.drawing.segs||[]).length+' | طبقات: '+Object.keys(view.drawing.layers||{}).length+(s[side].wasDWG?' | قُرئ DWG عبر LibreDWG إلى DXF مؤقت بالذاكرة':' | DXF الأصلي قُرئ مباشرة');
  status('تم فتح '+file.name+' في جلسة مستقلة. اختر نقطتين متماثلتين على هذه اللوحة.');
 }catch(e){
  if(token!==s.loadSerial[side])return;
  try{api.clearCanvasRuntime(side);}catch(_){}s[side]=null;
  if(side==='target')s.targetPoints=[null,null];else s.referencePoints=[null,null];
  const info=$(side==='target'?'sq110TargetFileInfo':'sq110ReferenceFileInfo');if(info)info.textContent='';
  fillExactReadouts();status('تعذّر فتح '+file.name+': '+String(e&&e.message||e)+'. تم تفريغ هذه الخانة؛ لم تبقَ معاينة اللوحة السابقة مكان الملف الجديد.',true);
 }
}
function bindFileInput(side){const id=side==='target'?'sq110TargetFile':'sq110ReferenceFile';const input=$(id);input.addEventListener('change',e=>{const f=e.target.files&&e.target.files[0];e.target.value='';if(f)loadFile(side,f);});}
function choosePoint(side,index){clearPreview();const s=api.state;s.active[side]=index;s.tool[side]='pick';if(api.updatePickLabels)api.updatePickLabels();if(s.views[side])api.draw(s.views[side]);status('تم اختيار وضع النقطة '+(index+1)+' على '+(side==='target'?'اللوحة المصدر':'اللوحة المرجعية')+'. اضغط النقطة في الرسم باستخدام OSNAP.');}
function zoom(side,factor){const v=api.state.views[side];if(!v)return;const m=api.metrics(v),screen={x:m.w/2,y:m.h/2},world=api.unproject(v,screen,m);v.zoom=Math.max(.1584893,Math.min(100000,v.zoom*factor));const n=api.metrics(v);v.panX=screen.x-n.w/2-(world.x-n.cx)*n.scale;v.panY=screen.y-n.h/2+(world.y-n.cy)*n.scale;const slider=$(side==='target'?'sq110TZoomRange':'sq110RZoomRange');if(slider)slider.value=String(Math.log10(v.zoom));api.draw(v);}
function fit(side){const v=api.state.views[side];if(!v)return;v.zoom=1;v.panX=0;v.panY=0;const slider=$(side==='target'?'sq110TZoomRange':'sq110RZoomRange');if(slider)slider.value='0';api.draw(v);}
function bindTools(side,prefix){
 $(prefix+'ZoomIn').addEventListener('click',()=>zoom(side,1.5));$(prefix+'ZoomOut').addEventListener('click',()=>zoom(side,1/1.5));$(prefix+'ZoomBoost').addEventListener('click',()=>zoom(side,5));$(prefix+'ZoomRange').addEventListener('input',e=>{const v=api.state.views[side];if(!v)return;const target=Math.pow(10,Number(e.target.value)),factor=target/Math.max(.1584893,v.zoom);zoom(side,factor);});$(prefix+'Fit').addEventListener('click',()=>fit(side));
 $(prefix+'SnapMode').addEventListener('change',e=>{api.state.snapMode[side]=e.target.value;status('OSNAP: '+e.target.options[e.target.selectedIndex].text);});
 $(prefix+'Id').addEventListener('click',()=>{const s=api.state;s.tool[side]=s.tool[side]==='id'?'pick':'id';api.updatePickLabels();status(s.tool[side]==='id'?'ID Point مفعل. اضغط نقطة لقراءة إحداثيات WCS.':'تم إيقاف ID Point.');});
 for(const i of [0,1])$(prefix+'Select'+(i+1)).addEventListener('click',()=>choosePoint(side,i));
 const selectButton=$(side==='target'?'sq110SelectEntity':'sq110RSelectEntity');selectButton.addEventListener('click',()=>{const s=api.state;s.tool[side]=s.tool[side]==='selectEntity'?'pick':'selectEntity';clearPreview();api.updatePickLabels();if(s.views[side])api.draw(s.views[side]);});
 $(side==='target'?'sq110Delete':'sq110RDelete').addEventListener('click',()=>{clearPreview();if(side==='target')api.deleteSelectedEntity();else if(api.deleteReferenceEntity)api.deleteReferenceEntity();else status('أداة حذف عناصر المرجع غير متاحة.',true);});
 $(side==='target'?'sq110UndoDelete':'sq110RUndoDelete').addEventListener('click',()=>{clearPreview();if(side==='target')api.undoDelete();else if(api.undoReferenceDelete)api.undoReferenceDelete();});
 $(side==='target'?'sq110RedoDelete':'sq110RRedoDelete').addEventListener('click',()=>{clearPreview();if(side==='target')api.redoDelete();else if(api.redoReferenceDelete)api.redoReferenceDelete();});
}
function bindCoordinateInputs(){for(const [side,prefix] of [['target','T'],['reference','R']])for(let i=0;i<2;i++)for(const axis of ['X','Y']){
 const input=$('sq110'+prefix+(i+1)+axis);input.addEventListener('change',()=>{clearPreview();const xEl=$('sq110'+prefix+(i+1)+'X'),yEl=$('sq110'+prefix+(i+1)+'Y'),x=xEl.value.trim()===''?NaN:Number(xEl.value),y=yEl.value.trim()===''?NaN:Number(yEl.value),list=side==='target'?api.state.targetPoints:api.state.referencePoints;
 if(!xEl.value.trim()&&!yEl.value.trim()){list[i]=null;fillExactReadouts();return;}
 if(!Number.isFinite(x)||!Number.isFinite(y)){status('أدخل X وY صالحين للنقطة '+(i+1)+'.',true);return;}
 list[i]={...(list[i]||{}),x,y,kind:'إحداثيات WCS مدخلة يدويًا'};fillExactReadouts();if(api.state.views[side])api.draw(api.state.views[side]);status('تم تحديث إحداثيات WCS للنقطة '+(i+1)+'.');
 });
 }}
function boundsCorners(b,t){return [{x:b.minX,y:b.minY},{x:b.maxX,y:b.minY},{x:b.minX,y:b.maxY},{x:b.maxX,y:b.maxY}].map(p=>t.point(p.x,p.y));}
function unionBounds(a,b){return {minX:Math.min(a.minX,b.minX),minY:Math.min(a.minY,b.minY),maxX:Math.max(a.maxX,b.maxX),maxY:Math.max(a.maxY,b.maxY)};}
function alignmentSignature(){
 const s=api&&api.state;if(!s||!s.target||!s.reference)return null;
 const points=[...(s.targetPoints||[]),...(s.referencePoints||[])];if(points.length!==4||points.some(p=>!p||!Number.isFinite(p.x)||!Number.isFinite(p.y)))return null;
 return JSON.stringify([s.loadSerial&&s.loadSerial.target,s.loadSerial&&s.loadSerial.reference,s.target.originalName||s.target.name,s.target.bytes&&s.target.bytes.length,s.reference.originalName||s.reference.name,s.reference.bytes&&s.reference.bytes.length,...points.flatMap(p=>[p.x,p.y])]);
}
function calculate(){
 const s=api.state;if(!s.target||!s.reference)throw new Error('افتح اللوحة المصدر واللوحة المرجعية أولًا.');
 for(const [side,label] of [['target','المصدر'],['reference','المرجع']])if(!s[side+'Points'][0]||!s[side+'Points'][1])throw new Error('حدد النقطة 1 والنقطة 2 على '+label+' بالترتيب نفسه.');
 const t=api.calculation();const err=Math.max(t.residual1||0,t.residual2||0);if(!Number.isFinite(err)||err>Math.max(t.tolerance||1e-8,1e-8))throw new Error('فشل فحص التطابق العددي؛ لم يُعتمد Alignment.');return t;
}
function preview(){
 try{
  const t=calculate(),s=api.state,sv=s.views.target,rv=s.views.reference;if(!sv||!rv)throw new Error('تعذر الوصول إلى معاينة إحدى اللوحتين.');clearPreview();
  const transformed=boundsCorners(sv.drawing.bounds,t),mapped={minX:Math.min(...transformed.map(p=>p.x)),maxX:Math.max(...transformed.map(p=>p.x)),minY:Math.min(...transformed.map(p=>p.y)),maxY:Math.max(...transformed.map(p=>p.y))};
  rv._sq151OriginalBounds={...rv.drawing.bounds};rv.drawing.bounds=unionBounds(rv.drawing.bounds,mapped);rv.alignmentPreview={source:sv.drawing,transform:t};
  api.draw(rv);api.showScreen('reference');lastPreviewSignature=alignmentSignature();
  const statusText='معاينة ALIGNMENT جاهزة | المقياس ×'+t.scale.toPrecision(10)+' | الدوران '+t.angleDeg.toFixed(8)+'° | الإزاحة X='+t.tx.toFixed(6)+' وY='+t.ty.toFixed(6)+' | خطأ التطابق P1='+Number(t.residual1||0).toExponential(2)+'، P2='+Number(t.residual2||0).toExponential(2)+'. المرجع بلونه، والمصدر المتحوّل سماوي.';
  status(statusText,false);return t;
 }catch(e){clearPreview();status((e&&e.message)||String(e),true);return null;}
}
function fallbackSave(bytes,name){return new Promise(resolve=>{try{const blob=new Blob([bytes],{type:'application/dxf'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);resolve(url);}catch(_){resolve(null);}});}
async function exportAlignment(){
 try{
  const signature=alignmentSignature();if(!signature||signature!==lastPreviewSignature)throw new Error('اعرض معاينة التراكب وافحصها أولًا. تغيّرت اللوحات أو النقاط بعد آخر معاينة، لذلك لن أصدّر مطابقة لم تراجعها.');
  const t=calculate(),s=api.state,source=s.target;if(!source)throw new Error('اللوحة المصدر غير موجودة في الجلسة الحالية.');
  const engine=window.__sqOrientTest;if(!engine||typeof engine.transformBytes!=='function')throw new Error('محرك التحويل الهندسي غير جاهز.');
  status('جارٍ تطبيق تحويل ALIGNMENT على نسخة مستقلة. يتحقق المحرك من بنية DXF وعدد وأنواع الكيانات دون إنشاء نسخة معاينة ثانية كبيرة…',false);
  const result=engine.transformBytes(source.bytes,t);if(!result||!(result.bytes instanceof Uint8Array)||result.bytes.length<64)throw new Error('محرك CAD لم ينتج DXF صالحًا.');
  if(!Number.isFinite(result.entitiesBefore)||!Number.isFinite(result.entitiesAfter)||result.entitiesBefore!==result.entitiesAfter)throw new Error('لم يثبت فحص المحرك ثبات عدد الكيانات؛ أُلغي التصدير.');
  if(result.layersPreserved===false)throw new Error('لم يثبت المحرك الحفاظ على الطبقات؛ أُلغي التصدير.');
  const original=source.originalName||source.name,base=String(original).replace(/\.[^.]+$/,'').replace(/[\\/:*?"<>|]/g,'_'),name=base+'_ALIGNED.dxf';
  const save=typeof window.safeDownloadFile==='function'?await window.safeDownloadFile(result.bytes,name,'application/dxf'):await fallbackSave(result.bytes,name);
  if(save==null||save===false)throw new Error('لم يؤكد التطبيق حفظ الملف أو أُلغيت عملية الحفظ. الملف الأصلي لم يتغير.');
  status('تم إخراج '+name+' | كيانات: '+(result.entitiesBefore??'?')+'/'+(result.entitiesAfter??'?')+' | حقول هندسية معدّلة: '+(result.changedFields??'?')+' | الدوران '+t.angleDeg.toFixed(8)+'° | المقياس ×'+t.scale.toPrecision(10)+'. تم فحص بنية DXF وعدد وأنواع الكيانات دون إعادة تحليل كامل يستهلك الذاكرة. المدخل '+(source.wasDWG?'DWG حُوّل إلى DXF في الذاكرة':'DXF')+'؛ الناتج DXF جديد. لم يتغير الملف المصدر أو المرجع.',false);
 }catch(e){status((e&&e.message||String(e))+' لم يتم تعديل الملف الأصلي أو المرجعي، ولم يتم اعتماد ملف جزئي.',true);}
}
function bind(){
 if(!api||!api.state||!api.loadView||!api.openCad)throw new Error('الـCAD core API غير جاهز. لم يتم تركيب أمر ALIGNMENT.');
 $('sq151Close').addEventListener('click',close);$('sq110Step1').addEventListener('click',()=>api.showScreen('target'));$('sq110Step2').addEventListener('click',()=>api.showScreen('reference'));$('sq110ToReference').addEventListener('click',()=>{if(!api.state.targetPoints[0]||!api.state.targetPoints[1]){status('حدد نقطتي المصدر أولًا.');return;}api.showScreen('reference');});$('sq110Back').addEventListener('click',()=>api.showScreen('target'));
 bindFileInput('target');bindFileInput('reference');bindTools('target','sq110T');bindTools('reference','sq110R');bindCoordinateInputs();$('sq110Preview').addEventListener('click',preview);$('sq110Export').addEventListener('click',exportAlignment);
}
function boot(){
 if(document.documentElement.dataset.sq151AlignmentBooted==='1')return;document.documentElement.dataset.sq151AlignmentBooted='1';
 const legacy=$('sqOriOverlay');if(legacy)legacy.remove();
 addStyles();createMarkup();installMenu();
 bind();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
