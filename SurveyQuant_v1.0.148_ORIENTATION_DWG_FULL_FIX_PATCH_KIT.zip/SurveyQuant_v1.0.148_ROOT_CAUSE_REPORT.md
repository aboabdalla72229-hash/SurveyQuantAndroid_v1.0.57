# SurveyQuant V1.0.148 Root-cause report

## What changed
- DXF DIMENSION has mixed coordinate systems. WCS points at groups 10/13/14/15 and OCS points at 11/12/16 were being treated inconsistently, which can leave attachment points behind and create long diagonal streaks. V148 transforms the groups separately and scales Z about the recovered world-Z pivot.
- The world-Z pivot scanner now counts position points according to their actual coordinate space. IMAGE/WIPEOUT insertion points are separated from axis vectors and clipping-pixel data.
- IMAGE/WIPEOUT axes are transformed as WCS vectors, without translation. Their image size and clipping polygon/pixel coordinates stay local.
- The orientation screen's DWG converter now uses the app's packaged `sqDwgWasmRuntimePath()` and validates the converted DXF structure. The normal `parseFile()` DWG path already uses the same local WASM runtime; the orientation picker now follows the same resolver.
- The drawing viewports were reduced from 56vh, 360-640 px to 44vh, 250-500 px for phone display. Zoom controls remain available.
- Two-point similarity solve checks both residuals against a numerical tolerance. It does not arbitrarily clamp negative coordinates: if the reference's real coordinates are negative, clamping would break alignment.

## Validation
The suite passed two-point residual tests, DXF bytes tests for mixed WCS/OCS DIMENSION coordinates, IMAGE/WIPEOUT axes and clipping fields, 24,000 entities, HATCH edge types, concrete outline recovery, nested axis labels and DWG conversion path. MULTILEADER output was compared with ezdxf 1.4.4.

## Limits
The user's production DWG and reference drawing were not attached, and this environment could not run the signed GitHub Actions APK build. A real DWG test on the user's file and the GitHub signing step remain necessary before calling the application release field-validated.
