#!/usr/bin/env python3
"""V177 corrective patch applied after the V176 baseline patch to a V162 source tree."""
from pathlib import Path
import argparse, re, sys

MARKER='<!-- SURVEYQUANT_V177_SINGLE_READ_CANVAS_ID_AND_DXF_R12_FIX -->'

def once(s, old, new, label):
    n=s.count(old)
    if n!=1: raise SystemExit(f'{label}: expected exactly one match, found {n}')
    return s.replace(old,new,1)

def patch_html(html_path:Path, engine_path:Path, drop_path:Path, check=False):
    html=html_path.read_text(encoding='utf-8')
    if MARKER in html:
        if check:
            required=['options.sourceBytes','canvasFingerprint','canvasSide','AC1009','mergeRawDxfBoards(target.bytes,source.bytes)','لم يؤكد نظام Android حفظ ملف DXF']
            missing=[v for v in required if v not in html]
            if missing: raise SystemExit('V177 marker found but required code is missing: '+', '.join(missing))
            print('PASS V177 HTML check-only')
            return
        raise SystemExit('V177 patch already applied')
    if 'SURVEYQUANT_V176_RAW_CAD_MERGE_VECTOR_PDF_IDENTITY_GUARD' not in html:
        raise SystemExit('V176 base patch marker missing. Apply V176 patch to the V162 source first.')

    # 1. Read each Android document-provider File once. Pass the exact byte snapshot to
    #    the DWG worker and to the fallback parser. Do not trust File.size from SAF.
    worker_old="""async function sqParseDwgInWorker(file,timeoutMs=90000,options={}){
 const worker=await sqEnsureDwgWorker();if(!worker)return null;
 const buffer=await file.arrayBuffer();"""
    worker_new="""async function sqParseDwgInWorker(file,timeoutMs=90000,options={}){
 const worker=await sqEnsureDwgWorker();if(!worker)return null;
 const supplied=options.sourceBytes;let buffer;
 if(supplied instanceof Uint8Array)buffer=supplied.buffer.slice(supplied.byteOffset,supplied.byteOffset+supplied.byteLength);
 else if(supplied instanceof ArrayBuffer)buffer=supplied.slice(0);
 else if(ArrayBuffer.isView(supplied))buffer=supplied.buffer.slice(supplied.byteOffset,supplied.byteOffset+supplied.byteLength);
 else buffer=await file.arrayBuffer();
 if(!buffer.byteLength)throw new Error('مدير الملفات أعاد ملف DWG فارغًا. أعد اختيار الملف.');"""
    html=once(html,worker_old,worker_new,'single-read DWG worker')
    html=once(html,"""async function parseFile(file,options={}){
 if(!file||!Number.isFinite(Number(file.size))||Number(file.size)<=0)throw new Error('الملف فارغ (صفر بايت) أو لم يُرجع مدير الملفات محتواه. أعد اختياره.');
 const ext=file.name.toLowerCase().split('.').pop();""",
    """async function parseFile(file,options={}){
 if(!file)throw new Error('لم يتم اختيار ملف.');
 const ext=String(file.name||'').toLowerCase().split('.').pop();
 const supplied=options.sourceBytes;let sourceBytes;
 if(supplied instanceof Uint8Array)sourceBytes=supplied.slice();
 else if(supplied instanceof ArrayBuffer)sourceBytes=new Uint8Array(supplied.slice(0));
 else if(ArrayBuffer.isView(supplied))sourceBytes=new Uint8Array(supplied.buffer.slice(supplied.byteOffset,supplied.byteOffset+supplied.byteLength));
 else sourceBytes=new Uint8Array(await file.arrayBuffer());
 if(!sourceBytes.length)throw new Error('مدير الملفات أعاد ملفًا فارغًا: '+(file.name||'المحدد')+'. أعد اختياره.');""",'parseFile single byte snapshot')
    html=once(html,"""  const sourceBytes=new Uint8Array(await file.arrayBuffer());
  if(sourceBytes.length < 16)""","""  if(sourceBytes.length < 16)""",'DWG duplicate read')
    html=once(html,""" const bytes=new Uint8Array(await file.arrayBuffer());
 if(!bytes.length)throw new Error('ملف '+file.name+' فارغ (صفر بايت) أو تعذر قراءة محتواه.');""",""" const bytes=sourceBytes;""",'shared reader duplicate read')

    # 2. Ensure canvas picks are associated with the actual loaded board fingerprint and map.
    #    Embedded engine is replaced as one complete, versioned script to avoid drift.
    engine=engine_path.read_text(encoding='utf-8')
    must=['canvasFingerprint','canvasSide','boardFingerprint:state[which]?.fingerprint','const saved=await root.safeDownloadFile','AC1009','function polylinesToDxf']
    missing=[x for x in must if x not in engine]
    if missing: raise SystemExit('V177 CAD engine missing required fix: '+', '.join(missing))
    script_pattern=r'(<script\s+id=["\']sq176-cad-engine["\']\s*>)[\s\S]*?(</script\s*>)'
    hits=list(re.finditer(script_pattern,html,re.I))
    if len(hits)!=1: raise SystemExit(f'Expected exactly one embedded CAD engine, found {len(hits)}')
    m=hits[0]
    html=html[:m.start(1)]+m.group(1)+'\n'+engine.replace('</script>','<\\/script>')+'\n'+m.group(2)+html[m.end(2):]

    # 3. Replace the old two-board workflow with a single-read flow. The DXF input itself
    #    is retained byte-for-byte; DWG is converted once by LibreDWG into DXF.
    drop=drop_path.read_text(encoding='utf-8').strip()
    a=html.find('async function dropFilesMerge(){')
    b=html.find('\nfunction downloadDroppedDXF()',a)
    if a<0 or b<0: raise SystemExit('Cannot locate project 8 dropFilesMerge')
    html=html[:a]+drop+'\n'+html[b:]

    # 4. The PDF engine consumes a single PDF byte array, doesn't trust File.size, emits
    #    R12/AC1009 POLYLINE/VERTEX/TEXT records and won't claim success when save is cancelled.
    html=html.replace("        if (!file.size) throw new Error('الملف المختار فارغ (صفر بايت). أعد اختياره من مدير الملفات.');\n",'')
    html=html.replace("const data=new Uint8Array(await file.arrayBuffer());if(!data.length)throw new Error('تعذر قراءة بايتات PDF من مدير الملفات.');",
                      "const data=new Uint8Array(await file.arrayBuffer());if(!data.length)throw new Error('مدير الملفات أعاد PDF فارغًا. أعد اختيار الملف من ذاكرة الهاتف.');")
    if "AC1009" not in engine or "if(saved===null||saved===undefined" not in engine:
        raise SystemExit('Missing PDF output compatibility or confirmed-save guard')
    html+='\n'+MARKER+'\n'
    html+='<!-- V177: one file-byte snapshot is shared by the parser/worker; canvas point picks are bound to each loaded board; PDF exports are R12 vector entities, no raster image. -->\n'
    html_path.write_text(html,encoding='utf-8')
    print(f'PASS V177 patch applied: {len(html):,} HTML characters')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--html',type=Path,required=True)
    p.add_argument('--engine',type=Path,required=True)
    p.add_argument('--drop-files-merge',type=Path,required=True)
    p.add_argument('--check-only',action='store_true')
    a=p.parse_args()
    patch_html(a.html,a.engine,a.drop_files_merge,a.check_only)
if __name__=='__main__': main()
