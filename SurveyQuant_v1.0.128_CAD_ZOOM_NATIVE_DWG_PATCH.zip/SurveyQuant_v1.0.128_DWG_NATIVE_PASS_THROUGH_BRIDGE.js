(function () {
  'use strict';
  if (window.__SQ_V128_DWG_NATIVE_BRIDGE__) return;
  window.__SQ_V128_DWG_NATIVE_BRIDGE__ = true;
  var ACCEPT_TYPES = [
    '.dwg', '.dxf', 'application/dwg', 'application/x-dwg',
    'application/dxf', 'application/x-dxf', 'application/acad',
    'application/x-acad', 'image/vnd.dwg'
  ];
  var CAD_INPUT_IDS = new Set([
    'cadFileInput', 'concreteDxfInput', 'quantBeforeFile', 'quantAfterFile', 'quantFileInput',
    'profileFileInput', 'dropSurveyFiles', 'dropCadFile',
    'sqOriReferenceFile', 'sqOriTargetFile', 'sq108File',
    'sq110TargetFile', 'sq110ReferenceFile'
  ]);
  var NON_CAD_DATA_IDS = new Set(['fileToDxfInput', 'cleanFilesInput']);

  function isCadInput(input) {
    if (!input || String(input.tagName || '').toLowerCase() !== 'input' ||
        String(input.type || '').toLowerCase() !== 'file') return false;
    var id = String(input.id || '');
    if (NON_CAD_DATA_IDS.has(id)) return false;
    if (CAD_INPUT_IDS.has(id)) return true;
    var accept = String(input.accept || '').split(',').map(function (item) {
      return item.trim().toLowerCase();
    }).filter(Boolean);
    return accept.some(function (item) {
      return item === '.dxf' || item === '.dwg' || /(^|\/)vnd\.dwg$/.test(item) ||
        item === 'application/dxf' || item === 'application/x-dxf' ||
        item === 'application/acad' || item === 'application/x-acad';
    });
  }

  function addAcceptedTypes(input) {
    if (!isCadInput(input)) return;
    var current = String(input.accept || '').split(',').map(function (item) {
      return item.trim();
    }).filter(Boolean);
    ACCEPT_TYPES.forEach(function (item) {
      if (!current.some(function (existing) { return existing.toLowerCase() === item.toLowerCase(); })) current.push(item);
    });
    input.accept = current.join(',');
  }

  function scanInputs(root) {
    if (!root) return;
    if (root.nodeType === 1) addAcceptedTypes(root);
    if (typeof root.querySelectorAll === 'function') root.querySelectorAll('input[type="file"]').forEach(addAcceptedTypes);
  }

  scanInputs(document);
  if (typeof MutationObserver === 'function' && document.documentElement) {
    new MutationObserver(function (records) {
      records.forEach(function (record) {
        (record.addedNodes || []).forEach(scanInputs);
      });
    }).observe(document.documentElement, { childList: true, subtree: true });
  }

  // Do not globally intercept file-change/drop events or replace a DWG with a converted DXF.
  // The normal parseFile(file) path already has a DWG reader; orientation screens use their
  // own temporary conversion only where the orientation algorithm specifically needs DXF bytes.
  window.__sqV128DwgBridgeAPI = { scanInputs: scanInputs, isCadInput: isCadInput, mode: 'native-dwg-pass-through' };
  window.__sqV117DwgBridgeAPI = window.__sqV128DwgBridgeAPI;
})();
