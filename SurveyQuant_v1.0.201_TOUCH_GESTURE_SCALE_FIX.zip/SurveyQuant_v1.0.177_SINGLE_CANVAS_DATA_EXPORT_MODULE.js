/* SURVEYQUANT_V177_SINGLE_CANVAS_DATA_EXPORT_ADDENDUM */
/* SurveyQuant V177 addendum: single-canvas orientation + point/data export.
 * This layer deliberately uses the V177 CAD engine for parsing, snapping,
 * orientation and raw-record DXF merge. Session data remains in memory only.
 */
(function(root){
 'use strict';
 const MODULE_ID='sq177-single-canvas-data-export';
 // The inline script itself uses MODULE_ID. Use a distinct style sentinel for mount idempotence.
 const MOUNT_STYLE_ID=MODULE_ID+'-style';
 const CAD=()=>root.SurveyQuantCAD177||root.SurveyQuantCAD176||root.SurveyQuantCAD162;
 const state={orientation:{source:null,target:null,loadSerial:{source:0,target:0},picks:[null,null,null,null],step:-1,transform:null,displayGeom:null,virtualOffset:{x:0,y:0},view:{zoom:1,cx:0,cy:0,panX:0,panY:0},drag:null},dataLoadSerial:0,data:{board:null,points:[],nextId:1,selected:[],deleted:[],editMode:'pan',view:{zoom:1,cx:0,cy:0,panX:0,panY:0}}};
 const el=id=>root.document.getElementById(id);
 const fmt=n=>Number(n).toFixed(4).replace(/\.?0+$/,'');
 const safe=(v)=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const enc=new TextEncoder();
 function releaseBoard(board){if(board?.urls)for(const u of board.urls)try{root.URL.revokeObjectURL(u)}catch(_){}}
 async function decodeOleFrames(geom){const urls=[];for(const frame of(geom?.oleFrames||[])){if(frame.image||!frame.jpeg)continue;if(!root.URL?.createObjectURL||!root.Image||!root.Blob)continue;const url=root.URL.createObjectURL(new Blob([frame.jpeg],{type:'image/jpeg'})),image=new root.Image();urls.push(url);try{await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(new Error('تعذر فك صورة OLE المضمنة في لوحة CAD.'));image.src=url;});frame.image=image;}catch(e){for(const u of urls)try{root.URL.revokeObjectURL(u)}catch(_){}throw e;}}return urls;}
 function resetOrientation(){
  state.orientation.loadSerial.source++;state.orientation.loadSerial.target++;
  for(const k of ['source','target'])releaseBoard(state.orientation[k]);
  Object.assign(state.orientation,{source:null,target:null,picks:[null,null,null,null],step:-1,transform:null,displayGeom:null,virtualOffset:{x:0,y:0},view:{zoom:1,cx:0,cy:0,panX:0,panY:0},drag:null});
  const s=el('sq177-ori-source'),t=el('sq177-ori-target');if(s)s.value='';if(t)t.value='';
  ['source-info','target-info','status'].forEach(x=>{const n=el('sq177-ori-'+x);if(n)n.textContent=x==='status'?'تم تفريغ جلسة التوجيه.': 'لم يتم اختيار ملف.';});
  const c=el('sq177-ori-canvas');if(c){const ctx=c.getContext('2d');ctx.clearRect(0,0,c.width,c.height);c._sq177Map=null;}
  updateOriButtons();
 }
 function resetData(){
  state.dataLoadSerial++;
  const b=state.data.board;releaseBoard(b);
  state.data={board:null,points:[],nextId:1,selected:[],deleted:[],editMode:'pan',view:{zoom:1,cx:0,cy:0,panX:0,panY:0}};
  const f=el('sq177-data-file');if(f)f.value='';
  const c=el('sq177-data-canvas');if(c){const ctx=c.getContext('2d');ctx.clearRect(0,0,c.width,c.height);c._sq177Map=null;}
  const info=el('sq177-data-info');if(info)info.textContent='لم يتم اختيار لوحة.';
  renderDataPoints();dataStatus('تم مسح لوحة الداتا والنقاط من الجلسة الحالية.');
 }
 async function loadCad(file){
  if(!file)throw new Error('اختر ملف DWG أو DXF.');
  if(!/\.(dwg|dxf)$/i.test(file.name||''))throw new Error('المسموح به في هذا المشروع DWG أو DXF فقط.');
  const sourceBytes=new Uint8Array(await file.arrayBuffer());
  if(!sourceBytes.length)throw new Error('الملف فارغ أو لم يُرجع مدير الملفات محتواه.');
  if(typeof root.parseFile!=='function')throw new Error('قارئ DWG/DXF المشترك غير متاح.');
  const model=await root.parseFile(file,{rawOnly:true,conversionOnly:true,retainRawDWG:false,sourceBytes});
  const raw=model?.rawDXFBytes;
  if(!(raw instanceof Uint8Array)&&!(raw instanceof ArrayBuffer)&&!ArrayBuffer.isView(raw))throw new Error('محرك V177 لم يُنتج بايتات DXF أصلية للوحة.');
  const bytes=raw instanceof Uint8Array?raw.slice():new Uint8Array(raw.buffer||raw,raw.byteOffset||0,raw.byteLength||raw.length).slice();
  if(!bytes.length)throw new Error('نتيجة قراءة اللوحة فارغة.');
  const geom=CAD().readGeometry(bytes);
  const urls=await decodeOleFrames(geom);
  const drawable=(geom.segments?.length||0)+(geom.curves?.length||0)+(geom.texts?.length||0)+(geom.oleFrames?.length||0)+(geom.raster?1:0);
  if(!drawable)throw new Error('لم يعثر قارئ V177 على عناصر قابلة للعرض. تم إيقاف العملية بدل إنشاء لوحة وهمية.');
  return {file,bytes,geom,urls,fingerprint:CAD().fileFingerprint(file,sourceBytes),sourceBytes};
 }
 function clearAlignment(message){
  const o=state.orientation;o.picks=[null,null,null,null];o.step=-1;o.transform=null;o.displayGeom=null;
  if(o.source){const g=o.source.geom;o.virtualOffset=state.orientation.target?sideBySideOffset(g,state.orientation.target.geom):{x:0,y:0};}
  if(message)oriStatus(message);updateOriButtons();drawOrientation();
 }
 function center(g){return{x:(g.minX+g.maxX)/2,y:(g.minY+g.maxY)/2};}
 function sideBySideOffset(source,target){
  const a=center(source),b=center(target),span=Math.max(source.maxX-source.minX,source.maxY-source.minY,target.maxX-target.minX,target.maxY-target.minY,1);
  return{x:b.x-a.x+span*2.15,y:b.y-a.y};
 }
 function oriStatus(t){const n=el('sq177-ori-status');if(n)n.textContent=String(t||'');}
 function updateOriButtons(){
  const o=state.orientation;
  for(let i=0;i<4;i++){const b=el('sq177-ori-pick-'+i);if(b){b.disabled=!(i<2?o.source:o.target);b.classList.toggle('active',o.step===i);b.classList.toggle('completed',!!o.picks[i]);b.textContent=(o.picks[i]?'✓ ':'')+['1. نقطة المصدر الأولى','2. نقطة المصدر الثانية','3. نقطة المرجع الأولى','4. نقطة المرجع الثانية'][i];}}
  const a=el('sq177-ori-align');if(a)a.disabled=!(o.source&&o.target&&o.picks.every(Boolean));
  const s=el('sq177-ori-save');if(s)s.disabled=!(o.source&&o.transform&&o.picks.every(Boolean));
  const details=el('sq177-ori-details');if(details){if(o.picks.every(Boolean)){const d=alignment(o.picks);details.textContent=`مقياس المرجع / المصدر = ${fmt(d.targetLength)} ÷ ${fmt(d.sourceLength)} = ${fmt(d.scale)} | الدوران ${fmt(d.rotationDegrees)}° | ΔX ${fmt(d.tx)} | ΔY ${fmt(d.ty)}`;}else details.textContent='اختر نقطتين متطابقتين من اللوحة غير الموجهة، ثم النقطتين المناظرتين من اللوحة الموجهة. المقياس سيُحسب تلقائيًا من المرجع.';}
 }
 function alignment(picks){
  const [a,b,c,d]=picks.map(p=>({x:Number(p.x),y:Number(p.y)}));
  const sx=b.x-a.x,sy=b.y-a.y,tx=d.x-c.x,ty=d.y-c.y;
  const sl=Math.hypot(sx,sy),tl=Math.hypot(tx,ty);
  if(![a.x,a.y,b.x,b.y,c.x,c.y,d.x,d.y,sl,tl].every(Number.isFinite)||sl<1e-9||tl<1e-9)throw new Error('نقطتا كل لوحة يجب أن تكونا مختلفتين وصالحتين.');
  const angle=Math.atan2(sx*ty-sy*tx,sx*tx+sy*ty),scale=tl/sl;
  const tx0=c.x-(a.x*scale*Math.cos(angle)-a.y*scale*Math.sin(angle));
  const ty0=c.y-(a.x*scale*Math.sin(angle)+a.y*scale*Math.cos(angle));
  const apply=p=>({x:scale*(p.x*Math.cos(angle)-p.y*Math.sin(angle))+tx0,y:scale*(p.x*Math.sin(angle)+p.y*Math.cos(angle))+ty0});
  const mappedB=apply(b),secondResidual=Math.hypot(mappedB.x-d.x,mappedB.y-d.y);
  return {scale,rotationRadians:angle,rotationDegrees:angle*180/Math.PI,tx:tx0,ty:ty0,apply,sourceLength:sl,targetLength:tl,secondResidual};
 }
 function syntheticPicks(picks){
  if(!Array.isArray(picks)||picks.length!==4)throw new Error('أربع نقاط توجيه مطلوبة.');
  return picks.map(p=>({x:Number(p.x),y:Number(p.y)}));
 }
 function transformBounds(g,tr){const pts=[{x:g.minX,y:g.minY},{x:g.minX,y:g.maxY},{x:g.maxX,y:g.minY},{x:g.maxX,y:g.maxY}].map(tr.apply);return{minX:Math.min(...pts.map(p=>p.x)),minY:Math.min(...pts.map(p=>p.y)),maxX:Math.max(...pts.map(p=>p.x)),maxY:Math.max(...pts.map(p=>p.y))};}
 function unionBounds(a,b){return{minX:Math.min(a.minX,b.minX),minY:Math.min(a.minY,b.minY),maxX:Math.max(a.maxX,b.maxX),maxY:Math.max(a.maxY,b.maxY)};}
 function fitOri(){const o=state.orientation;if(!o.source&&!o.target)return;const a=o.source?(o.displayGeom||o.source.geom):null,b=o.target?.geom;let bounds=null;if(a){bounds=o.transform?{minX:a.minX,minY:a.minY,maxX:a.maxX,maxY:a.maxY}:{minX:a.minX+o.virtualOffset.x,minY:a.minY+o.virtualOffset.y,maxX:a.maxX+o.virtualOffset.x,maxY:a.maxY+o.virtualOffset.y};}if(b)bounds=bounds?unionBounds(bounds,b):b;if(!bounds)return;Object.assign(o.view,{zoom:1,cx:(bounds.minX+bounds.maxX)/2,cy:(bounds.minY+bounds.maxY)/2,panX:0,panY:0});drawOrientation();}
 function drawGeom(ctx,g,mapper,alpha,displayScale=1){if(!g)return;ctx.save();ctx.globalAlpha=alpha??1;ctx.lineCap='round';ctx.lineJoin='round';
  const raster=g.raster;if(raster?.image&&raster.insert&&raster.u&&raster.v){const topWorld={x:raster.insert.x+raster.v.x*raster.height,y:raster.insert.y+raster.v.y*raster.height},top=mapper(topWorld),x1=mapper({x:topWorld.x+raster.u.x,y:topWorld.y+raster.u.y}),y1=mapper({x:topWorld.x-raster.v.x,y:topWorld.y-raster.v.y});ctx.save();ctx.setTransform(x1.x-top.x,x1.y-top.y,y1.x-top.x,y1.y-top.y,top.x,top.y);ctx.drawImage(raster.image,0,0,raster.width,raster.height);ctx.restore();}
  for(const s of(g.segments||[])){if(!s.a||!s.b)continue;ctx.strokeStyle=s.color||'#246b9d';ctx.lineWidth=Math.max(.6,Math.min(3,(Number(s.lineWeight)||20)/25));const a=mapper(s.a),b=mapper(s.b);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();}
  for(const c of(g.curves||[])){ctx.strokeStyle=c.color||'#246b9d';ctx.lineWidth=Math.max(.6,Math.min(3,(Number(c.lineWeight)||20)/25));ctx.beginPath();if(Array.isArray(c.points)&&c.points.length>1){const a=mapper(c.points[0]);ctx.moveTo(a.x,a.y);for(let i=1;i<c.points.length;i++){const p=mapper(c.points[i]);ctx.lineTo(p.x,p.y);}}else if(c.center&&Number(c.radius)>0){const m=mapper(c.center),r=Math.abs(Number(c.radius))*displayScale;ctx.arc(m.x,m.y,r,Number(c.start)||0,(Number(c.start)||0)+(Number(c.sweep)||Math.PI*2));}ctx.stroke();}
  for(const t of(g.texts||[])){if(!t.position)continue;const p=mapper(t.position);ctx.save();ctx.translate(p.x,p.y);ctx.rotate(-(Number(t.rotation)||0)*Math.PI/180);const h=Math.max(7,Math.min(24,Math.abs(Number(t.height)||10)*displayScale));ctx.fillStyle=t.color||'#1d2d3d';ctx.font=`${h}px sans-serif`;ctx.textBaseline='bottom';ctx.fillText(String(t.text||'').slice(0,100),0,0);ctx.restore();}
  if(Array.isArray(g.oleFrames)&&g.oleFrames.length){for(const f of g.oleFrames){if(!f.image)continue;const a=mapper({x:f.left,y:f.top}),b=mapper({x:f.right,y:f.bottom});ctx.drawImage(f.image,a.x,a.y,b.x-a.x,b.y-a.y);}}
  ctx.restore();}
 function drawOrientation(){const o=state.orientation,c=el('sq177-ori-canvas');if(!c)return;const w=Math.max(280,c.clientWidth||320),h=Math.max(220,c.clientHeight||360),dpr=Math.min(root.devicePixelRatio||1,2);c.width=Math.round(w*dpr);c.height=Math.round(h*dpr);const ctx=c.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#fbfcfe';ctx.fillRect(0,0,w,h);
  const source=o.source?(o.displayGeom||o.source.geom):null,target=o.target?.geom;if(!source&&!target)return;
  let bounds=null;if(source){const bb=o.transform?{minX:source.minX,minY:source.minY,maxX:source.maxX,maxY:source.maxY}:{minX:source.minX+o.virtualOffset.x,minY:source.minY+o.virtualOffset.y,maxX:source.maxX+o.virtualOffset.x,maxY:source.maxY+o.virtualOffset.y};bounds=bb;}if(target)bounds=bounds?unionBounds(bounds,target):target;
  if(!bounds)return;const pad=18,spanX=Math.max(1e-8,bounds.maxX-bounds.minX),spanY=Math.max(1e-8,bounds.maxY-bounds.minY),base=Math.max(1e-12,Math.min((w-2*pad)/spanX,(h-2*pad)/spanY)),sc=base*o.view.zoom;
  const toScreen=p=>({x:w/2+(p.x-o.view.cx)*sc+o.view.panX,y:h/2-(p.y-o.view.cy)*sc+o.view.panY});
  const fromScreen=p=>({x:o.view.cx+(p.x-w/2-o.view.panX)/sc,y:o.view.cy-(p.y-h/2-o.view.panY)/sc});
  const targetMap=p=>toScreen(p),sourceMap=p=>toScreen(o.transform?p:{x:p.x+o.virtualOffset.x,y:p.y+o.virtualOffset.y}),sourcePickMap=p=>toScreen(o.transform?o.transform.apply(p):{x:p.x+o.virtualOffset.x,y:p.y+o.virtualOffset.y});
  drawGeom(ctx,target,targetMap,0.95,sc);drawGeom(ctx,source,sourceMap,0.78,sc);
  const marks=[];o.picks.forEach((p,i)=>{if(!p)return;const disp=i<2?sourcePickMap(p):targetMap(p);marks.push({p:disp,label:String(i+1),color:i<2?'#0876cf':'#d95f02'});});
  for(const m of marks){ctx.fillStyle=m.color;ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(m.p.x,m.p.y,6,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle='#111';ctx.font='bold 12px sans-serif';ctx.fillText(m.label,m.p.x+9,m.p.y-8);}
  c._sq177Map={toScreen,fromScreen,baseScale:base,scale:sc,sourceMap,targetMap,sourceGeom:o.source?.geom,targetGeom:o.target?.geom};
 }
 async function chooseOri(which,file){const o=state.orientation,ticket=++o.loadSerial[which];clearAlignment('تغيير اللوحة يمسح نقاط التوجيه الأربع والتحويل السابق.');if(which==='source'){releaseBoard(o.source);o.source=null;}else{releaseBoard(o.target);o.target=null;}o.virtualOffset=o.source&&o.target?sideBySideOffset(o.source.geom,o.target.geom):{x:0,y:0};if(!file){drawOrientation();updateOriButtons();return;}oriStatus('جارٍ قراءة '+file.name+' ...');try{const board=await loadCad(file);if(ticket!==o.loadSerial[which]){releaseBoard(board);return;}if(which==='source')o.source=board;else o.target=board;o.virtualOffset=o.source&&o.target?sideBySideOffset(o.source.geom,o.target.geom):{x:0,y:0};const info=el('sq177-ori-'+which+'-info');if(info)info.textContent=`${file.name}\nعناصر: ${(board.geom.segments?.length||0)+(board.geom.curves?.length||0)} | نصوص: ${(board.geom.texts||[]).length}\nبصمة: ${board.fingerprint.slice(-18)}`;o.view={zoom:1,cx:0,cy:0,panX:0,panY:0};fitOri();oriStatus('تم تحميل الملف الحالي. اللوحتان تظهران داخل مساحة رسم واحدة.');updateOriButtons();}catch(e){if(ticket!==o.loadSerial[which])return;if(which==='source'){releaseBoard(o.source);o.source=null;}else{releaseBoard(o.target);o.target=null;}o.virtualOffset=o.source&&o.target?sideBySideOffset(o.source.geom,o.target.geom):{x:0,y:0};oriStatus(e.message||String(e));drawOrientation();updateOriButtons();}}
 function startPick(i){const o=state.orientation;if(i<2&&!o.source||i>=2&&!o.target)return;if(o.transform){clearAlignment('تم إلغاء التحويل السابق لإعادة اختيار نقاط جديدة.');}const first=o.picks.findIndex(p=>!p);if(o.picks[i]===null&&first>=0&&i!==first){oriStatus('التزم بترتيب النقاط الأربع: مصدر 1، مصدر 2، مرجع 1، مرجع 2.');return;}if(o.picks[i]){for(let j=i;j<4;j++)o.picks[j]=null;}o.step=i;updateOriButtons();oriStatus('انقر على اللوحة داخل مساحة الرسم المشتركة لاختيار النقطة '+(i+1)+'.');}
 function pickOri(clientX,clientY){const o=state.orientation;if(o.step<0||o.step>3)return;const c=el('sq177-ori-canvas'),m=c?._sq177Map;if(!m)return;const r=c.getBoundingClientRect(),screen={x:clientX-r.left,y:clientY-r.top},world=m.fromScreen(screen),isSource=o.step<2,board=isSource?o.source:o.target;if(!board)return;const local=isSource&&!o.transform?{x:world.x-o.virtualOffset.x,y:world.y-o.virtualOffset.y}:world;const mode=el('sq177-ori-snap')?.value||'nearest';let snap=CAD().snapPoint(board.geom,local,mode,8/Math.max(m.scale,1e-12));const found=snap?.point||local;if(!Number.isFinite(found.x)||!Number.isFinite(found.y)){oriStatus('لم يتم التقاط نقطة صالحة.');return;}o.picks[o.step]={x:found.x,y:found.y,boardSide:isSource?'source':'target',fingerprint:board.fingerprint};o.step=-1;updateOriButtons();drawOrientation();oriStatus(`تم حفظ النقطة ${o.picks.findIndex(p=>p===null)+1||4} من ${board.file.name}: X=${fmt(found.x)} Y=${fmt(found.y)}.`);}
 function runAlignment(){
  const o=state.orientation;
  if(!o.source||!o.target||!o.picks.every(Boolean))throw new Error('حمّل اللوحة الموجهة أولاً، ثم غير الموجهة، واختر النقاط الأربع بالترتيب.');
  if(o.picks[0].fingerprint!==o.source.fingerprint||o.picks[1].fingerprint!==o.source.fingerprint||o.picks[2].fingerprint!==o.target.fingerprint||o.picks[3].fingerprint!==o.target.fingerprint)throw new Error('تم تغيير إحدى اللوحتين. أعد اختيار النقاط الأربع.');
  const p=syntheticPicks(o.picks),d=alignment(o.picks),tr=CAD().solve(p[0],p[1],p[2],p[3]);
  if(!Number.isFinite(tr.scale)||tr.scale<=0||Math.abs(tr.scale-d.scale)>Math.max(1e-10,d.scale*1e-10))throw new Error('معامل المقياس المحسوب من اللوحة المرجعية غير متطابق. أوقفت التوجيه.');
  o.transform=tr;o.displayGeom=CAD().transformGeometryView(o.source.geom,tr);o.view={zoom:1,cx:0,cy:0,panX:0,panY:0};fitOri();
  oriStatus(`تم التوجيه باستخدام مقياس اللوحة المرجعية تلقائيًا.\nطول خط النقطتين في غير الموجهة: ${fmt(d.sourceLength)}\nطول الخط المناظر في الموجهة: ${fmt(d.targetLength)}\nمعامل المقياس المطبق على كامل اللوحة: ${fmt(d.scale)}\nالدوران: ${fmt(d.rotationDegrees)}°\nالإزاحة X: ${fmt(d.tx)} | Y: ${fmt(d.ty)}\nفرق مطابقة النقطة الثانية: ${fmt(d.secondResidual)} وحدة.\nتم عرض اللوحة غير الموجهة بجوار المرجع قبل التوجيه، ثم نقلها إلى موضع المطابقة بعد الحساب.`);
  updateOriButtons();
 }
 async function saveOri(){const o=state.orientation;if(!o.source||!o.transform||!o.picks.every(Boolean))throw new Error('نفّذ التوجيه أولاً.');const p=syntheticPicks(o.picks),out=CAD().createOrientedDxfBytes(o.source.bytes,p);if(!out?.bytes?.length)throw new Error('محرك V177 لم ينتج DXF صالحاً.');const base=String(o.source.file.name||'SurveyQuant').replace(/\.[^.]+$/,'').replace(/[^\w.-]+/g,'_')||'SurveyQuant';const result=await root.safeDownloadFile(out.bytes,base+'_ORIENTED.dxf','application/dxf',false);if(result===null||result===undefined)throw new Error('تم إلغاء نافذة الحفظ؛ لم يتم إعلان نجاح الحفظ.');oriStatus('تم حفظ ملف DXF الموجه. ملف المصدر الأصلي لم يتم استبداله.');}
 function makeOrientationCard(){if(el('sq177OrientationCard'))return;const card=root.document.createElement('section');card.id='sq177OrientationCard';card.className='card project-card';card.innerHTML=`
  <h3>📐 9. توجيه اللوحات في شاشة واحدة</h3>
  <div class="info-list">الخانة الأولى: اللوحة الموجهة (المرجع). الخانة الثانية: اللوحة غير الموجهة التي سيتم إسقاطها بجوار المرجع. بعد اختيار نقطتين متناظرتين في كل لوحة، يحسب البرنامج معامل المقياس تلقائيًا من طول خط المرجع ÷ طول خط المصدر ويطبقه على كامل اللوحة.</div>
  <div class="sq177-grid"><label>1. اللوحة الموجهة (المرجع) DWG/DXF<input id="sq177-ori-target" type="file" accept=".dwg,.dxf"></label><label>2. اللوحة غير الموجهة المراد إسقاطها DWG/DXF<input id="sq177-ori-source" type="file" accept=".dwg,.dxf"></label></div>
  <div class="sq177-toolbar"><button type="button" data-zoom="in" data-canvas="ori">تكبير +</button><button type="button" data-zoom="out" data-canvas="ori">تصغير −</button><button type="button" data-zoom="fit" data-canvas="ori">احتواء اللوحتين</button><select id="sq177-ori-snap"><option value="intersection">التقاطع</option><option value="endpoint">نهاية عنصر</option><option value="midpoint">منتصف عنصر</option><option value="nearest">أقرب نقطة</option></select></div>
  <div class="sq177-picks">${[0,1,2,3].map(i=>`<button type="button" id="sq177-ori-pick-${i}" disabled>${['1. نقطة من غير الموجهة','2. النقطة الثانية من غير الموجهة','3. النقطة المناظرة من الموجهة','4. النقطة الثانية من الموجهة'][i]}</button>`).join('')}</div>
  <div id="sq177-ori-details" class="info-list">سيُحسب معامل المقياس تلقائيًا من المسافة بين النقطتين المناظرتين في اللوحة الموجهة مقارنة باللوحة غير الموجهة.</div>
  <canvas id="sq177-ori-canvas" class="sq177-canvas" aria-label="مساحة رسم مشتركة للوحتي المصدر والمرجع"></canvas>
  <div class="sq177-grid"><div id="sq177-ori-target-info" class="info-list">اللوحة الموجهة: لم يتم اختيار ملف.</div><div id="sq177-ori-source-info" class="info-list">اللوحة غير الموجهة: لم يتم اختيار ملف.</div></div>
  <div class="sq177-toolbar"><button id="sq177-ori-align" type="button" disabled>تنفيذ التوجيه</button><button id="sq177-ori-save" type="button" disabled>حفظ DXF الموجه</button><button id="sq177-ori-reset" type="button">مسح النقاط والتحويل</button></div><div id="sq177-ori-status" class="info-list">اختر اللوحة الموجهة في الخانة الأولى، ثم غير الموجهة في الخانة الثانية.</div>`;
  return card;}
 function renderDataPoints(){const box=el('sq177-data-points');if(!box)return;const d=state.data;box.innerHTML=d.points.length?d.points.map(p=>`<div class="sq177-point-row"><b>${safe(p.id)}</b><span>E ${fmt(p.easting)}</span><span>N ${fmt(p.northing)}</span><span>Z ${fmt(p.elevation)}</span><button type="button" data-remove-point="${safe(p.id)}">حذف</button></div>`).join(''):'لم يتم تحديد نقاط بعد.';}
 function dataStatus(t){const n=el('sq177-data-status');if(n)n.textContent=String(t||'');}
 function entityList(g){const out=[];for(const [kind,arr] of [['segments',g?.segments],['curves',g?.curves],['texts',g?.texts]])for(let i=0;i<(arr||[]).length;i++)out.push({kind,index:i,item:arr[i]});return out;}
 function distSegment(p,a,b){const dx=b.x-a.x,dy=b.y-a.y,l=dx*dx+dy*dy,t=l?Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/l)):0;return Math.hypot(p.x-a.x-t*dx,p.y-a.y-t*dy);}
 function entityDistance(p,e){const v=e.item;if(e.kind==='segments'&&v.a&&v.b)return distSegment(p,v.a,v.b);if(e.kind==='curves'){if(Array.isArray(v.points)&&v.points.length>1){let d=Infinity;for(let i=1;i<v.points.length;i++)d=Math.min(d,distSegment(p,v.points[i-1],v.points[i]));return d;}if(v.center&&Number(v.radius)>0)return Math.abs(Math.hypot(p.x-v.center.x,p.y-v.center.y)-Math.abs(Number(v.radius)));}if(e.kind==='texts'&&v.position)return Math.hypot(p.x-v.position.x,p.y-v.position.y);return Infinity;}
 function entityKey(e){return e.kind+':'+e.index;}
 function currentEntities(){const d=state.data;return entityList(d.board?.geom).filter(e=>!d.deleted.includes(entityKey(e)));}
 function selectAt(p){const d=state.data,m=el('sq177-data-canvas')?._sq177Map;if(!d.board||!m)return;const candidates=currentEntities().map(e=>({e,dist:entityDistance(p,e)})).sort((a,b)=>a.dist-b.dist);const hit=candidates[0];if(!hit||hit.dist>12/Math.max(m.scale,1e-9)){dataStatus('لم يتم العثور على عنصر قريب. كبّر اللوحة أو استخدم تحديد النافذة.');return;}d.selected=[entityKey(hit.e)];drawData();dataStatus(`تم تحديد ${hit.e.kind==='segments'?'خط':hit.e.kind==='curves'?'قوس/منحنى':'نص'} رقم ${hit.e.index+1}.`);}
 function selectWindow(a,b){const d=state.data;if(!d.board)return;const lo={x:Math.min(a.x,b.x),y:Math.min(a.y,b.y)},hi={x:Math.max(a.x,b.x),y:Math.max(a.y,b.y)};const inside=p=>p&&p.x>=lo.x&&p.x<=hi.x&&p.y>=lo.y&&p.y<=hi.y;d.selected=currentEntities().filter(e=>{const v=e.item;if(e.kind==='segments')return inside(v.a)&&inside(v.b);if(e.kind==='texts')return inside(v.position);if(Array.isArray(v.points))return v.points.length>0&&v.points.every(inside);if(v.center&&Number(v.radius)>0)return v.center.x-Number(v.radius)>=lo.x&&v.center.x+Number(v.radius)<=hi.x&&v.center.y-Number(v.radius)>=lo.y&&v.center.y+Number(v.radius)<=hi.y;return false;}).map(entityKey);drawData();dataStatus(`تم تحديد ${d.selected.length} عنصر داخل النافذة.`);}
 function selectSimilar(){const d=state.data;if(!d.board||!d.selected.length)return dataStatus('حدد عنصراً أولاً ثم اختر تحديد المشابه.');const key=d.selected[0],[kind,index]=key.split(':'),base=d.board.geom[kind]?.[Number(index)];if(!base)return;const signature=e=>{const v=e.item;return e.kind===kind&&(v.color||'')===(base.color||'')&&(v.layer||'')===(base.layer||'');};d.selected=currentEntities().filter(signature).map(entityKey);drawData();dataStatus(`تم تحديد ${d.selected.length} عناصر مشابهة حسب النوع واللون والطبقة المتاحة.`);}
 function deleteSelected(){const d=state.data;if(!d.selected.length)return dataStatus('لا توجد عناصر محددة للحذف.');const count=d.selected.length;d.deleted=[...new Set([...d.deleted,...d.selected])];d.selected=[];drawData();dataStatus(`تم حذف ${count} عنصر من مساحة التحرير الحالية فقط. الملف الأصلي لم يتغير، وتصدير DXF المعدل غير متاح حتى لا نفقد بيانات CAD غير المدعومة.`);}
 function restoreDeleted(){const d=state.data;if(!d.deleted.length)return dataStatus('لا توجد عناصر محذوفة لاستعادتها.');d.deleted=[];d.selected=[];drawData();dataStatus('تم التراجع عن الحذف واستعادة كل العناصر في مساحة التحرير.');}
 function drawData(){const d=state.data,c=el('sq177-data-canvas');if(!c)return;const w=Math.max(280,c.clientWidth||320),h=Math.max(220,c.clientHeight||360),r=Math.min(root.devicePixelRatio||1,2);c.width=w*r;c.height=h*r;const ctx=c.getContext('2d');ctx.setTransform(r,0,0,r,0,0);ctx.fillStyle='#fbfcfe';ctx.fillRect(0,0,w,h);if(!d.board)return;const g=d.board.geom,pad=18,spanX=Math.max(1e-9,g.maxX-g.minX),spanY=Math.max(1e-9,g.maxY-g.minY),base=Math.min((w-2*pad)/spanX,(h-2*pad)/spanY),sc=base*d.view.zoom;const toScreen=p=>({x:w/2+(p.x-d.view.cx)*sc+d.view.panX,y:h/2-(p.y-d.view.cy)*sc+d.view.panY}),fromScreen=p=>({x:d.view.cx+(p.x-w/2-d.view.panX)/sc,y:d.view.cy-(p.y-h/2-d.view.panY)/sc});
  const visible={...g,segments:(g.segments||[]).filter((_,i)=>!d.deleted.includes('segments:'+i)),curves:(g.curves||[]).filter((_,i)=>!d.deleted.includes('curves:'+i)),texts:(g.texts||[]).filter((_,i)=>!d.deleted.includes('texts:'+i))};drawGeom(ctx,visible,toScreen,1,sc);for(const key of d.selected){const [kind,ix]=key.split(':'),v=g[kind]?.[Number(ix)];if(!v)continue;ctx.save();ctx.strokeStyle='#ff8c00';ctx.fillStyle='#ff8c00';ctx.lineWidth=3;if(kind==='segments'&&v.a&&v.b){const a=toScreen(v.a),b=toScreen(v.b);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();}else if(kind==='curves'&&Array.isArray(v.points)){ctx.beginPath();v.points.forEach((p,i)=>{const q=toScreen(p);i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y)});ctx.stroke();}else if(kind==='curves'&&v.center&&Number(v.radius)>0){const q=toScreen(v.center);ctx.beginPath();ctx.arc(q.x,q.y,Math.abs(Number(v.radius))*sc,Number(v.start)||0,(Number(v.start)||0)+(Number(v.sweep)||Math.PI*2));ctx.stroke();}else if(kind==='texts'&&v.position){const q=toScreen(v.position);ctx.beginPath();ctx.arc(q.x,q.y,7,0,Math.PI*2);ctx.stroke();}ctx.restore();}const size=Math.max(.5,Math.min(32,(Number(el('sq177-data-marker-size')?.value)||.15)*sc)),style=el('sq177-data-marker-style')?.value||'cross',color=el('sq177-data-marker-color')?.value||'#e53935',labelMode=el('sq177-data-label-mode')?.value||'id',textColor=el('sq177-data-text-color')?.value||'#00695c';
  for(const p of d.points){const q=toScreen({x:p.easting,y:p.northing});ctx.save();ctx.strokeStyle=color;ctx.fillStyle=color;ctx.lineWidth=1.8;if(style==='circle'){ctx.beginPath();ctx.arc(q.x,q.y,size,0,Math.PI*2);ctx.stroke();}else if(style==='square'){ctx.strokeRect(q.x-size,q.y-size,size*2,size*2);}else{ctx.beginPath();ctx.moveTo(q.x-size,q.y);ctx.lineTo(q.x+size,q.y);ctx.moveTo(q.x,q.y-size);ctx.lineTo(q.x,q.y+size);ctx.stroke();}ctx.fillStyle=textColor;ctx.font='12px sans-serif';ctx.direction='ltr';ctx.fillText(labelMode==='xy'?`X=${fmt(p.easting)} Y=${fmt(p.northing)}`:p.id,q.x+size+3,q.y-size-2);ctx.restore();}
  c._sq177Map={toScreen,fromScreen,scale:sc,baseScale:base};}
 async function loadDataFile(file){resetData();if(!file)return;const ticket=state.dataLoadSerial;dataStatus('جارٍ قراءة '+file.name+' ...');try{const board=await loadCad(file);if(ticket!==state.dataLoadSerial){releaseBoard(board);return;}state.data.board=board;const g=board.geom;state.data.view={zoom:1,cx:(g.minX+g.maxX)/2,cy:(g.minY+g.maxY)/2,panX:0,panY:0};const info=el('sq177-data-info');if(info)info.textContent=`${file.name}\nبصمة: ${board.fingerprint.slice(-18)}\nعناصر: ${(g.segments?.length||0)+(g.curves?.length||0)} | نصوص: ${(g.texts||[]).length}`;drawData();dataStatus('انقر على اللوحة لتسجيل نقطة. X = Easting وY = Northing.');}catch(e){if(ticket!==state.dataLoadSerial)return;resetData();dataStatus(e.message||String(e));}}
 function addDataPoint(clientX,clientY){const d=state.data,c=el('sq177-data-canvas'),m=c?._sq177Map;if(!d.board||!m)return;const r=c.getBoundingClientRect(),local={x:clientX-r.left,y:clientY-r.top},world=m.fromScreen(local),mode=el('sq177-data-snap')?.value||'nearest';let snapped=mode==='manual'?null:CAD().snapPoint(d.board.geom,world,mode,9/Math.max(m.scale,1e-12));const p=snapped?.point||world;if(!Number.isFinite(p.x)||!Number.isFinite(p.y))return;const n=d.nextId++,id='P'+String(n).padStart(4,'0'),z=Number(el('sq177-data-elevation')?.value||0);d.points.push({id,easting:Number(p.x),northing:Number(p.y),elevation:Number.isFinite(z)?z:0,snap:snapped?.type||'manual'});renderDataPoints();drawData();dataStatus(`تمت إضافة ${id}: X=${fmt(p.x)}، Y=${fmt(p.y)}، Z=${fmt(z)}.`);}
 function csvText(points=state.data.points){const rows=[['ID','Easting','Northing','Elevation'],...points.map(p=>[p.id,fmt(p.easting),fmt(p.northing),fmt(p.elevation)])];return '\uFEFF'+rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');}
 function txtText(points=state.data.points){return 'ID\tEasting\tNorthing\tElevation\r\n'+points.map(p=>[p.id,fmt(p.easting),fmt(p.northing),fmt(p.elevation)].join('\t')).join('\r\n');}
 function sdrText(points=state.data.points){return '00NM,SurveyQuant,ENZ\r\n'+points.map(p=>`08TP,${p.id},${fmt(p.easting)},${fmt(p.northing)},${fmt(p.elevation)}`).join('\r\n')+'\r\n';}
 function xml(v){return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');}
 function colName(n){let s='';while(n){let r=(n-1)%26;s=String.fromCharCode(65+r)+s;n=Math.floor((n-1)/26);}return s;}
 function makeXlsx(points=state.data.points){if(!points.length)throw new Error('لا توجد نقاط للتصدير.');const rows=[['ID','Easting','Northing','Elevation'],...points.map(p=>[p.id,p.easting,p.northing,p.elevation])];let sheet='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
  rows.forEach((row,ri)=>{sheet+=`<row r="${ri+1}">`;row.forEach((v,ci)=>{const ref=colName(ci+1)+(ri+1);if(typeof v==='number'&&Number.isFinite(v))sheet+=`<c r="${ref}"><v>${v}</v></c>`;else sheet+=`<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${xml(v)}</t></is></c>`;});sheet+='</row>';});sheet+='</sheetData></worksheet>';
  const entries=[
   {name:'[Content_Types].xml',data:enc.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')},
   {name:'_rels/.rels',data:enc.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')},
   {name:'xl/workbook.xml',data:enc.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Survey Points" sheetId="1" r:id="rId1"/></sheets></workbook>')},
   {name:'xl/_rels/workbook.xml.rels',data:enc.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')},
   {name:'xl/worksheets/sheet1.xml',data:enc.encode(sheet)}
  ];return CAD().zipStore(entries);}
 function base64ToBytes(dataUrl){const s=dataUrl.slice(dataUrl.indexOf(',')+1),b=root.atob(s),out=new Uint8Array(b.length);for(let i=0;i<b.length;i++)out[i]=b.charCodeAt(i);return out;}
 function concat(parts){const len=parts.reduce((n,p)=>n+p.length,0),out=new Uint8Array(len);let at=0;for(const p of parts){out.set(p,at);at+=p.length;}return out;}
 function pdfPages(pages){const parts=[],offsets=[0];let length=0;const add=b=>{parts.push(b);length+=b.length;},str=s=>enc.encode(s),obj=(id,b)=>{offsets[id]=length;add(str(id+' 0 obj\n'));add(b);add(str('\nendobj\n'));};
  add(str('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n'));const pageCount=pages.length,last=2+3*pageCount;
  obj(1,str('<< /Type /Catalog /Pages 2 0 R >>'));
  let kids='';for(let i=0;i<pageCount;i++)kids+=(3+i*3)+' 0 R ';
  obj(2,str(`<< /Type /Pages /Kids [${kids.trim()}] /Count ${pageCount} >>`));
  for(let i=0;i<pageCount;i++){const pageId=3+i*3,contentId=pageId+1,imageId=pageId+2,p=pages[i],w=Number(p.width)||900,h=Number(p.height)||1200,jpg=p.bytes;const scale=Math.min(550/w,760/h),iw=w*scale,ih=h*scale,ix=(595-iw)/2,iy=(842-ih)/2,stream=`q\n${iw.toFixed(3)} 0 0 ${ih.toFixed(3)} ${ix.toFixed(3)} ${iy.toFixed(3)} cm\n/Im0 Do\nQ\n`;
   obj(pageId,str(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im0 ${imageId} 0 R >> >> /Contents ${contentId} 0 R >>`));
   const sb=str(stream);obj(contentId,concat([str(`<< /Length ${sb.length} >>\nstream\n`),sb,str('endstream')]));
   obj(imageId,concat([str(`<< /Type /XObject /Subtype /Image /Width ${w} /Height ${h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`),jpg,str('\nendstream')]));
  }
  const xref=length;let table=`xref\n0 ${last+1}\n0000000000 65535 f \n`;for(let i=1;i<=last;i++)table+=String(offsets[i]).padStart(10,'0')+' 00000 n \n';add(str(table+`trailer\n<< /Size ${last+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`));return concat(parts);}
 function makePdf(points=state.data.points){if(!points.length)throw new Error('لا توجد نقاط للتصدير.');const pages=[],perPage=34;for(let start=0;start<points.length;start+=perPage){const c=root.document.createElement('canvas');c.width=1000;c.height=1400;const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);const arabic=(el('sq177-data-language')?.value||'ar')==='ar';x.direction=arabic?'rtl':'ltr';x.textAlign=arabic?'right':'left';const right=arabic?920:80,left=arabic?80:80;x.fillStyle='#172b43';x.font='bold 34px Arial';x.fillText(arabic?'مكتب فني مساحة | كشف النقاط':'SurveyQuant | Point List',right,70);x.font='22px Arial';x.fillText(arabic?'رقم النقطة':'Point ID',left,140);x.fillText('Easting (X)',left+180,140);x.fillText('Northing (Y)',left+420,140);x.fillText(arabic?'المنسوب':'Elevation',left+690,140);x.strokeStyle='#52677d';x.lineWidth=2;x.beginPath();x.moveTo(70,160);x.lineTo(930,160);x.stroke();x.font='20px Arial';for(let i=0;i<Math.min(perPage,points.length-start);i++){const p=points[start+i],y=205+i*32;x.fillStyle=i%2?'#f1f5f9':'#fff';x.fillRect(65,y-24,870,30);x.fillStyle='#1b2d3e';x.fillText(p.id,left,y);x.fillText(fmt(p.easting),left+180,y);x.fillText(fmt(p.northing),left+420,y);x.fillText(fmt(p.elevation),left+690,y);}x.font='16px Arial';x.fillStyle='#64748b';x.fillText(`${Math.floor(start/perPage)+1} / ${Math.ceil(points.length/perPage)}`,right,1340);pages.push({width:c.width,height:c.height,bytes:base64ToBytes(c.toDataURL('image/jpeg',.93))});}return pdfPages(pages);}
 function aciColor(hex){const v=String(hex||'#ff3333').replace('#',''),r=parseInt(v.slice(0,2),16)||0,g=parseInt(v.slice(2,4),16)||0,b=parseInt(v.slice(4,6),16)||0;const palette=[[1,255,0,0],[2,255,255,0],[3,0,255,0],[4,0,255,255],[5,0,0,255],[6,255,0,255],[7,255,255,255],[8,128,128,128]];let best=palette[0],dist=Infinity;for(const q of palette){const d=(r-q[1])**2+(g-q[2])**2+(b-q[3])**2;if(d<dist){best=q;dist=d;}}return best[0];}
 function dxfEsc(s){let out='';for(const ch of String(s??'')){const cp=ch.codePointAt(0);if(cp===10||cp===13)out+=' ';else if(cp<32)continue;else if(cp<127)out+=ch;else if(cp<=0xffff)out+='\\U+'+cp.toString(16).toUpperCase().padStart(4,'0');else{const n=cp-0x10000;out+='\\U+'+(0xD800+(n>>10)).toString(16).toUpperCase()+'\\U+'+(0xDC00+(n&1023)).toString(16).toUpperCase();}}return out;}
 function annotationDxf(points=state.data.points){const marker=Number(el('sq177-data-marker-size')?.value)||.15,textHeight=Math.max(.05,Number(el('sq177-data-text-size')?.value)||.25),style=el('sq177-data-marker-style')?.value||'cross',aci=aciColor(el('sq177-data-marker-color')?.value),labelMode=el('sq177-data-label-mode')?.value||'id',textAci=aciColor(el('sq177-data-text-color')?.value);let s='0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1009\n9\n$DWGCODEPAGE\n3\nANSI_1252\n0\nENDSEC\n0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLTYPE\n70\n1\n0\nLTYPE\n2\nCONTINUOUS\n70\n0\n3\nSolid line\n72\n65\n73\n0\n40\n0.0\n0\nENDTAB\n0\nTABLE\n2\nLAYER\n70\n3\n';for(const [name,color] of [['0',7],['SURVEY_POINTS',aci],['SURVEY_LABELS',textAci]])s+=`0\nLAYER\n2\n${name}\n70\n0\n62\n${color}\n6\nCONTINUOUS\n`;s+='0\nENDTAB\n0\nTABLE\n2\nSTYLE\n70\n1\n0\nSTYLE\n2\nSTANDARD\n70\n0\n40\n0.0\n41\n1.0\n50\n0.0\n71\n0\n42\n2.5\n3\ntxt\n4\n\n0\nENDTAB\n0\nENDSEC\n0\nSECTION\n2\nBLOCKS\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n';
  for(const p of points){const x=p.easting,y=p.northing,z=p.elevation;if(![x,y,z].every(Number.isFinite))throw new Error('إحداثيات النقطة غير صالحة.');s+=`0\nPOINT\n8\nSURVEY_POINTS\n10\n${fmt(x)}\n20\n${fmt(y)}\n30\n${fmt(z)}\n`;if(style==='circle')s+=`0\nCIRCLE\n8\nSURVEY_POINTS\n10\n${fmt(x)}\n20\n${fmt(y)}\n30\n${fmt(z)}\n40\n${fmt(marker)}\n`;else if(style==='square'){const m=marker;s+=`0\nLINE\n8\nSURVEY_POINTS\n10\n${fmt(x-m)}\n20\n${fmt(y-m)}\n11\n${fmt(x+m)}\n21\n${fmt(y-m)}\n0\nLINE\n8\nSURVEY_POINTS\n10\n${fmt(x+m)}\n20\n${fmt(y-m)}\n11\n${fmt(x+m)}\n21\n${fmt(y+m)}\n0\nLINE\n8\nSURVEY_POINTS\n10\n${fmt(x+m)}\n20\n${fmt(y+m)}\n11\n${fmt(x-m)}\n21\n${fmt(y+m)}\n0\nLINE\n8\nSURVEY_POINTS\n10\n${fmt(x-m)}\n20\n${fmt(y+m)}\n11\n${fmt(x-m)}\n21\n${fmt(y-m)}\n`;}else{s+=`0\nLINE\n8\nSURVEY_POINTS\n10\n${fmt(x-marker)}\n20\n${fmt(y)}\n11\n${fmt(x+marker)}\n21\n${fmt(y)}\n0\nLINE\n8\nSURVEY_POINTS\n10\n${fmt(x)}\n20\n${fmt(y-marker)}\n11\n${fmt(x)}\n21\n${fmt(y+marker)}\n`;}
   const label=labelMode==='xy'?`X=${fmt(x)} Y=${fmt(y)}`:p.id;s+=`0\nTEXT\n8\nSURVEY_LABELS\n10\n${fmt(x+marker*1.4)}\n20\n${fmt(y+marker*1.4)}\n30\n${fmt(z)}\n40\n${fmt(textHeight)}\n1\n${dxfEsc(label)}\n7\nSTANDARD\n`;}
  s+='0\nENDSEC\n0\nEOF\n';return enc.encode(s);}
 async function saveFile(bytes,name,mime){const r=await root.safeDownloadFile(bytes,name,mime,false);if(r===null||r===undefined)throw new Error('تم إلغاء الحفظ. لم يتم إنشاء ملف في التنزيلات.');return r;}
 async function exportData(kind){const d=state.data;if(!d.board)throw new Error('حمّل لوحة DWG/DXF أولاً.');if(kind==='dxf'&&d.deleted.length)throw new Error('تم حذف عناصر من مساحة التحرير، لكن كاتب V177 الحالي لا يملك حذف سجلات DXF مع ضمان بقاء كل الكتل والبيانات الأصلية. لن أصدر ملفاً يحتوي العناصر المحذوفة وكأنه معدل. استعد العناصر أولاً؛ تصدير النقاط وحدها ما زال متاحاً.');if(!d.points.length)throw new Error('حدد نقطة واحدة على الأقل قبل التصدير.');const base=String(d.board.file.name||'SurveyQuant').replace(/\.[^.]+$/,'').replace(/[^\w.-]+/g,'_')||'SurveyQuant';let bytes,name,mime;
  if(kind==='csv'){bytes=enc.encode(csvText());name=base+'_POINTS.csv';mime='text/csv;charset=utf-8';}
  else if(kind==='txt'){bytes=enc.encode(txtText());name=base+'_POINTS.txt';mime='text/plain;charset=utf-8';}
  else if(kind==='sdr'){bytes=enc.encode(sdrText());name=base+'_POINTS.sdr';mime='text/plain;charset=utf-8';}
  else if(kind==='xlsx'){bytes=makeXlsx();name=base+'_POINTS.xlsx';mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';}
  else if(kind==='pdf'){bytes=makePdf();name=base+'_POINTS.pdf';mime='application/pdf';}
  else if(kind==='dxf'){const ann=annotationDxf(d.points),merged=CAD().mergeRawDxfBoards(d.board.bytes,ann);if(!merged?.bytes?.length)throw new Error('تعذر دمج النقاط مع DXF الأصلي. لم يتم إنشاء ملف مبسط بديل.');bytes=merged.bytes;name=base+'_POINTS.dxf';mime='application/dxf';}
  else throw new Error('صيغة تصدير غير معروفة.');
  await saveFile(bytes,name,mime);dataStatus(`تم حفظ ${name} بنجاح بعد تأكيد نظام الحفظ. عدد النقاط: ${d.points.length}. X = Easting وY = Northing.`);
 }
 function makeDataCard(){if(el('sq177DataExportCard'))return;const card=root.document.createElement('section');card.id='sq177DataExportCard';card.className='card project-card';card.innerHTML=`
  <h3>📍 11. إخراج داتا</h3><div class="info-list">حمّل اللوحة، ثم انقر لتحديد النقاط. تُحفظ البيانات في الأعمدة ID وEasting وNorthing وElevation، مع X = Easting وY = Northing. الإضافة على DXF تتم بدمج سجلات النقاط مع سجلات اللوحة الأصلية.</div>
  <label>اللوحة (DWG/DXF)<input id="sq177-data-file" type="file" accept=".dwg,.dxf"></label>
  <div class="sq177-toolbar"><button type="button" data-zoom="in" data-canvas="data">تكبير +</button><button type="button" data-zoom="out" data-canvas="data">تصغير −</button><button type="button" data-zoom="fit" data-canvas="data">احتواء</button><select id="sq177-data-snap"><option value="nearest">أقرب نقطة/عنصر</option><option value="intersection">التقاطع</option><option value="endpoint">نهاية عنصر</option><option value="midpoint">منتصف عنصر</option><option value="manual">نقطة يدوية</option></select></div>
  <div class="sq177-toolbar"><button type="button" data-edit-mode="pan" class="active">إضافة نقطة / تحريك اللوحة</button><button type="button" data-edit-mode="select">تحديد عنصر</button><button type="button" data-edit-mode="window">تحديد نافذة</button><button type="button" id="sq177-data-similar">تحديد مشابه</button><button type="button" id="sq177-data-delete" class="danger">حذف المحدد</button><button type="button" id="sq177-data-restore">استعادة المحذوف</button></div><div id="sq177-data-selection-info" class="info-list">التحديد والحذف داخل مساحة التحرير الحالية.</div><canvas id="sq177-data-canvas" class="sq177-canvas" aria-label="مساحة تحديد وتحرير عناصر CAD"></canvas>
  <div id="sq177-data-info" class="info-list">لم يتم اختيار لوحة.</div>
  <div class="sq177-grid"><label>طريقة كتابة العلامة<select id="sq177-data-label-mode"><option value="id">رقم النقطة</option><option value="xy">إحداثيات X/Y</option></select></label><label>لغة التقرير<select id="sq177-data-language"><option value="ar">العربية</option><option value="en">English</option></select></label><label>شكل العلامة<select id="sq177-data-marker-style"><option value="cross">+</option><option value="circle">دائرة</option><option value="square">مربع</option></select></label><label>حجم العلامة (وحدات اللوحة)<input id="sq177-data-marker-size" type="number" min="0.001" step="0.01" value="0.15"></label><label>ارتفاع النص<input id="sq177-data-text-size" type="number" min="0.001" step="0.01" value="0.25"></label><label>منسوب Z الافتراضي<input id="sq177-data-elevation" type="number" step="0.001" value="0"></label><label>لون العلامة<input id="sq177-data-marker-color" type="color" value="#e53935"></label><label>لون النص<input id="sq177-data-text-color" type="color" value="#00695c"></label></div>
  <div id="sq177-data-points" class="info-list">لم يتم تحديد نقاط بعد.</div>
  <div class="sq177-toolbar"><button type="button" data-export="csv">CSV</button><button type="button" data-export="txt">TXT</button><button type="button" data-export="sdr">SDR</button><button type="button" data-export="pdf">PDF</button><button type="button" data-export="xlsx">Excel</button><button type="button" data-export="dxf">حفظ اللوحة + النقاط DXF</button><button type="button" id="sq177-data-clear">مسح النقاط واللوحة</button></div><div id="sq177-data-status" class="info-list">اختر لوحة ثم انقر لإضافة نقطة.</div>`;return card;}
 function clampZoom(z){return Math.max(.15,Math.min(2500,z));}
 function attachCanvasGestures(c,config){
  if(!c||c.dataset.sq177Bound)return false;
  c.dataset.sq177Bound='1';
  if(c.style){c.style.touchAction='none';c.style.overscrollBehavior='contain';c.style.webkitUserSelect='none';}
  const active=new Map();let gesture=null;
  const view=config.viewGetter,draw=config.draw,kind=config.kind;
  const point=e=>{const r=c.getBoundingClientRect();return{x:Number(e.clientX)-r.left,y:Number(e.clientY)-r.top,clientX:Number(e.clientX),clientY:Number(e.clientY)};};
  const mode=()=>config.getMode?config.getMode():'pan';
  const two=()=>Array.from(active.entries()).slice(0,2);
  const startPinch=()=>{
   const entries=two();if(entries.length<2)return false;
   const a=entries[0][1],b=entries[1][1],center={x:(a.x+b.x)/2,y:(a.y+b.y)/2},distance=Math.max(1,Math.hypot(b.x-a.x,b.y-a.y));
   const m=c._sq177Map;if(!m)return false;
   gesture={type:'pinch',ids:entries.map(x=>x[0]),startDistance:distance,startZoom:view().zoom||1,anchorWorld:m.fromScreen(center),moved:true};
   return true;
  };
  const applyPinch=()=>{
   const entries=gesture?.ids?.map(id=>[id,active.get(id)]).filter(x=>x[1]);if(!entries||entries.length<2)return;
   const a=entries[0][1],b=entries[1][1],center={x:(a.x+b.x)/2,y:(a.y+b.y)/2},distance=Math.max(1,Math.hypot(b.x-a.x,b.y-a.y));
   const v=view(),m=c._sq177Map;if(!m)return;
   const z=clampZoom(gesture.startZoom*distance/gesture.startDistance),base=m.baseScale||m.scale/Math.max(v.zoom,1e-12),r=c.getBoundingClientRect();
   v.zoom=z;v.panX=center.x-r.width/2-(gesture.anchorWorld.x-v.cx)*base*z;v.panY=center.y-r.height/2+(gesture.anchorWorld.y-v.cy)*base*z;
   draw();
  };
  c.addEventListener('wheel',e=>{
   e.preventDefault();const v=view(),m=c._sq177Map;if(!m)return;const p=point(e),world=m.fromScreen(p),base=m.baseScale||m.scale/Math.max(v.zoom,1e-12),z=clampZoom((v.zoom||1)*(e.deltaY<0?1.15:1/1.15)),r=c.getBoundingClientRect();
   v.zoom=z;v.panX=p.x-r.width/2-(world.x-v.cx)*base*z;v.panY=p.y-r.height/2+(world.y-v.cy)*base*z;draw();
  },{passive:false});
  c.addEventListener('pointerdown',e=>{
   if(e.button!==undefined&&e.button!==0)return;e.preventDefault?.();
   try{c.setPointerCapture?.(e.pointerId);}catch(_){}
   active.set(e.pointerId,point(e));
   if(active.size===1){const q=active.get(e.pointerId),v=view();gesture={type:(kind==='data'&&mode()==='window')?'window':(kind==='data'&&mode()==='select')?'select':(kind==='data'?'point':'canvas'),id:e.pointerId,start:q,last:q,startView:{zoom:v.zoom,cx:v.cx,cy:v.cy,panX:v.panX,panY:v.panY},moved:false};}
   else if(active.size>=2){startPinch();}
  });
  c.addEventListener('pointermove',e=>{
   if(!active.has(e.pointerId))return;e.preventDefault?.();active.set(e.pointerId,point(e));
   if(active.size>=2){if(gesture?.type!=='pinch')startPinch();applyPinch();return;}
   if(!gesture||gesture.type==='pinch')return;
   const q=active.get(e.pointerId),dx=q.x-gesture.start.x,dy=q.y-gesture.start.y;
   if(Math.hypot(dx,dy)>6)gesture.moved=true;
   if(!gesture.moved)return;
   if(gesture.type==='window'){
    draw();const ctx=c.getContext('2d');ctx.save();ctx.strokeStyle='#ff8c00';ctx.fillStyle='rgba(255,140,0,.10)';ctx.lineWidth=1.6;ctx.setLineDash([6,4]);ctx.fillRect(gesture.start.x,gesture.start.y,dx,dy);ctx.strokeRect(gesture.start.x,gesture.start.y,dx,dy);ctx.restore();
   }else if(gesture.type==='canvas'||gesture.type==='point'){
    const v=view();v.panX=gesture.startView.panX+dx;v.panY=gesture.startView.panY+dy;draw();
   }
  });
  c.addEventListener('pointerup',e=>{
   if(!active.has(e.pointerId))return;e.preventDefault?.();
   const q=point(e),wasPinch=gesture?.type==='pinch';
   active.delete(e.pointerId);try{c.releasePointerCapture?.(e.pointerId);}catch(_){}
   if(wasPinch){
    if(active.size===1){const [id,remain]=active.entries().next().value,v=view();gesture={type:'canvas',id,start:remain,last:remain,startView:{zoom:v.zoom,cx:v.cx,cy:v.cy,panX:v.panX,panY:v.panY},moved:true};}
    else gesture=null;
    return;
   }
   if(active.size>0)return;
   const g=gesture;gesture=null;if(!g)return;
   const end=q,was=g.moved;
   if(kind==='ori'){
    if(!was&&config.onTap)config.onTap(e.clientX,e.clientY);
    return;
   }
   const m=c._sq177Map,r=c.getBoundingClientRect();
   if(g.type==='window'){
    if(was&&m&&config.onWindow){const a=m.fromScreen(g.start),b=m.fromScreen(end);config.onWindow(a,b);}else if(config.onTap)config.onTap(e.clientX,e.clientY,true);
    return;
   }
   if(g.type==='select'){
    if(!was&&config.onTap)config.onTap(e.clientX,e.clientY,false);
    return;
   }
   if(g.type==='point'&&!was&&config.onTap)config.onTap(e.clientX,e.clientY,false);
  });
  c.addEventListener('pointercancel',e=>{active.delete(e.pointerId);gesture=null;});
  c.addEventListener('lostpointercapture',e=>{if(active.has(e.pointerId)){active.delete(e.pointerId);if(active.size===0)gesture=null;}});
  return true;
 }
 function bindZoom(canvasId,viewGetter,draw,kind){
  const c=el(canvasId);if(!c)return;
  return attachCanvasGestures(c,{viewGetter,draw,kind,getMode:()=>state.data.editMode,
   onTap:(x,y,windowTap)=>{if(kind==='ori'){pickOri(x,y);return;}if(windowTap){dataStatus('اسحب بإصبع واحد داخل مساحة الرسم لرسم نافذة التحديد.');return;}const r=c.getBoundingClientRect(),m=c._sq177Map;if(!m)return;if(state.data.editMode==='select')selectAt(m.fromScreen({x:x-r.left,y:y-r.top}));else if(state.data.editMode==='point'||state.data.editMode==='pan')addDataPoint(x,y);},
   onWindow:(a,b)=>{if(kind==='data')selectWindow(a,b);}
  });
 }
 function bindControls(){
  el('sq177-ori-source')?.addEventListener('click',e=>{e.currentTarget.value='';});el('sq177-ori-target')?.addEventListener('click',e=>{e.currentTarget.value='';});
  el('sq177-ori-source')?.addEventListener('change',e=>chooseOri('source',e.target.files?.[0]));el('sq177-ori-target')?.addEventListener('change',e=>chooseOri('target',e.target.files?.[0]));
  for(let i=0;i<4;i++)el('sq177-ori-pick-'+i)?.addEventListener('click',()=>startPick(i));
  el('sq177-ori-align')?.addEventListener('click',()=>{try{runAlignment();}catch(e){oriStatus(e.message||String(e));}});
  el('sq177-ori-save')?.addEventListener('click',async()=>{try{await saveOri();}catch(e){oriStatus(e.message||String(e));}});
  el('sq177-ori-reset')?.addEventListener('click',()=>clearAlignment('تم مسح نقاط التوجيه والتحويل.'));
  el('sq177-data-file')?.addEventListener('click',e=>{e.currentTarget.value='';});el('sq177-data-file')?.addEventListener('change',e=>loadDataFile(e.target.files?.[0]));
  el('sq177-data-clear')?.addEventListener('click',resetData);el('sq177-data-similar')?.addEventListener('click',selectSimilar);el('sq177-data-delete')?.addEventListener('click',deleteSelected);el('sq177-data-restore')?.addEventListener('click',restoreDeleted);root.document.querySelectorAll('[data-edit-mode]').forEach(b=>b.addEventListener('click',()=>{state.data.editMode=b.dataset.editMode;root.document.querySelectorAll('[data-edit-mode]').forEach(x=>x.classList.toggle('active',x===b));dataStatus(state.data.editMode==='pan'?'انقر لإضافة نقطة، واسحب بإصبع واحد لتحريك اللوحة.':'وضع '+(state.data.editMode==='select'?'تحديد عنصر بالنقر':'تحديد نافذة بالسحب')+'.');}));
  el('sq177-data-points')?.addEventListener('click',e=>{const b=e.target.closest('[data-remove-point]');if(!b)return;state.data.points=state.data.points.filter(p=>p.id!==b.dataset.removePoint);renderDataPoints();drawData();});
  root.document.querySelectorAll('[data-export]').forEach(b=>b.addEventListener('click',async()=>{try{await exportData(b.dataset.export);}catch(e){dataStatus(e.message||String(e));}}));
  root.document.querySelectorAll('[data-zoom][data-canvas]').forEach(b=>b.addEventListener('click',()=>{const kind=b.dataset.canvas,action=b.dataset.zoom;if(kind==='ori'){if(action==='fit')fitOri();else{state.orientation.view.zoom=Math.max(.2,Math.min(1000,state.orientation.view.zoom*(action==='in'?2:.5)));drawOrientation();}}else{const d=state.data;if(action==='fit'&&d.board){const g=d.board.geom;d.view={zoom:1,cx:(g.minX+g.maxX)/2,cy:(g.minY+g.maxY)/2,panX:0,panY:0};drawData();}else{d.view.zoom=Math.max(.2,Math.min(1000,d.view.zoom*(action==='in'?2:.5)));drawData();}}}));
  bindZoom('sq177-ori-canvas',()=>state.orientation.view,drawOrientation,'ori');bindZoom('sq177-data-canvas',()=>state.data.view,drawData,'data');
  root.document.addEventListener('click',e=>{const active=(el('sq177OrientationCard')?.classList.contains('active-project'))||(el('sq177DataExportCard')?.classList.contains('active-project'));if(!active)return;const back=e.target.closest('.project-back');const otherMenu=e.target.closest('#homeMenu .menu-btn');if(back||(otherMenu&&!['sq177-home-orientation','sq177-home-data-export'].includes(otherMenu.id))){resetOrientation();resetData();}},true);
 }
 function mount(){const doc=root.document;if(!doc||doc.getElementById(MOUNT_STYLE_ID))return false;const cad=CAD();if(!cad||typeof root.parseFile!=='function'||typeof root.safeDownloadFile!=='function')return false;const required=['readGeometry','snapPoint','solve','transformGeometryView','createOrientedDxfBytes','mergeRawDxfBoards','fileFingerprint','zipStore'];const missing=required.filter(k=>typeof cad[k]!=='function');if(missing.length)throw new Error('V177 CAD engine API incomplete: '+missing.join(', '));
  const container=doc.querySelector('.container'),menu=doc.querySelector('#homeMenu .home-menu');if(!container||!menu)return false;
  const style=doc.createElement('style');style.id=MOUNT_STYLE_ID;style.textContent=`
   #sq177OrientationCard,#sq177DataExportCard{padding:12px}
   .sq177-canvas{touch-action:none!important;-ms-touch-action:none;overscroll-behavior:contain;-webkit-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent}
   .sq177-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:10px 0}
   .sq177-grid label,.sq177-grid input{min-width:0;display:block;width:100%}
   .sq177-grid input,.sq177-grid select,.sq177-toolbar select,#sq177OrientationCard input[type=file],#sq177DataExportCard input[type=file]{padding:9px;border:1px solid #ccd5df;border-radius:8px;max-width:100%;box-sizing:border-box}
   .sq177-toolbar,.sq177-picks{display:flex;gap:7px;flex-wrap:wrap;margin:10px 0;align-items:center}
   .sq177-toolbar button,.sq177-picks button{border:0;border-radius:8px;background:#155fa8;color:#fff;padding:10px 12px;font-weight:700;min-height:40px}
   .sq177-toolbar button.active{background:#0b7a53}.sq177-toolbar button.danger{background:#a62b2b}.sq177-picks button.completed{background:#168255}.sq177-picks button.active{outline:3px solid #85c9a8}.sq177-toolbar button:disabled,.sq177-picks button:disabled{opacity:.45}
   .sq177-canvas{display:block;width:100%;height:min(54vh,520px);min-height:260px;background:#fbfcfe;border:1px solid #d4dce5;border-radius:9px;touch-action:none;user-select:none}
   .sq177-check{display:flex;gap:8px;align-items:center;margin:10px 0}.sq177-check input{width:auto}
   .sq177-point-row{display:grid;grid-template-columns:1fr repeat(3,auto) auto;gap:9px;padding:7px;border-bottom:1px solid #d9e1e9;font-size:12px;align-items:center;direction:ltr}
   .sq177-point-row button{background:#a62b2b;color:#fff;border:0;border-radius:6px;padding:5px 8px}
   @media(max-width:600px){.sq177-grid{grid-template-columns:1fr}.sq177-toolbar button{flex:1}.sq177-point-row{grid-template-columns:1fr 1fr;}}
  `;doc.head.appendChild(style);
  const oldOri=el('sqOrientationCard'),oldBtn=el('sq176-home-orientation-project');if(oldOri){oldOri.style.display='none';oldOri.classList.remove('active-project');}if(oldBtn)oldBtn.style.display='none';
  const ori=makeOrientationCard(),data=makeDataCard();container.appendChild(ori);container.appendChild(data);
  const add=(id,label,cardId)=>{if(el(id))return;const b=doc.createElement('button');b.id=id;b.type='button';b.className='menu-btn';b.textContent=label;b.addEventListener('click',()=>{if(typeof root.openProjectPage==='function')root.openProjectPage(cardId);else{doc.body.classList.add('project-mode');doc.querySelectorAll('.project-card').forEach(c=>c.classList.remove('active-project'));el(cardId).classList.add('active-project');}});menu.appendChild(b);};
  add('sq177-home-orientation','📐 9 توجيه اللوحات (مساحة واحدة)','sq177OrientationCard');add('sq177-home-data-export','📍 11 إخراج داتا','sq177DataExportCard');bindControls();
  root.addEventListener('resize',()=>{drawOrientation();drawData();});
  root.SurveyQuantV177Addendum={version:'1.0.201-touch-gestures-auto-reference-scale',resetOrientation,resetData,alignment,syntheticPicks,csvText,txtText,sdrText,makeXlsx,makePdf,annotationDxf};
  root.SurveyQuantV177AddendumCore={alignment,syntheticPicks,sideBySideOffset,pdfPages,annotationDxf,attachCanvasGestures};
  return true;
 }
 root.SurveyQuantV177AddendumCore={alignment,syntheticPicks,sideBySideOffset,pdfPages,annotationDxf,csvText,txtText,sdrText,makeXlsx,makePdf,entityDistance,entityList,entityKey,attachCanvasGestures};
 function init(){if(mount())return;let tries=0;const timer=root.setInterval(()=>{tries++;if(mount()||tries>80)root.clearInterval(timer);},100);}
 if(root.document.readyState==='loading')root.document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})(window);
