# SurveyQuant V1.0.146 Automated Test Results

Date: 2026-10-24

## Results

- PASS: HATCH pattern base and offset are transformed as local vectors (rotate/scale only), not as world coordinates; translated boundary and EOF stay valid.
- PASS: nested INSERT axis-label recovery from parsed DXF group pairs places `AX-01` in expected WCS; avoids a second whole-file decode.
- PASS: synthetic 1,725,900-byte DXF containing 24,000 LINE entities completes preview/export transforms; output retains all 24,000 entities and correct EOF.
- PASS: single-allocation DXF writer and streaming valid-output validation are installed.
- PASS: two-point orientation engine and supported entity/layer/XData checks against V130 baseline.
- PASS: DWG all-project bridge, output validation, INSERT text transform and selection/delete regressions.
- PASS: alignment safety, Model/Paper-space consistency (groups 67/410), and opaque-proxy fail-safe regression.
- PASS: 3D LINE Z behavior and tilted OCS CIRCLE/TEXT WCS round-trip.
- PASS: MLEADER field/point/scale/rotation/matrix preservation against the `ezdxf 1.4.4` reference oracle.
- PASS: Python compile and JavaScript syntax checks, including 10 inline JavaScript blocks.
- PASS: HTML injection and Android manifest version update were locally packaged against the real V145 APK; local output was deliberately unsigned because the signing secrets are only available to the repository's GitHub Actions environment.

## Important limits

The large-DXF case is synthetic and was used to exercise memory behavior and preservation of entity counts. The actual DWG/DXF that produced the user's distorted output was not attached to this turn, so it has not been tested directly. These automated tests are not a substitute for opening the original project in CAD and surveying the transformed output against known coordinates. Opaque Civil 3D/Proxy/Solid geometry that is not exposed by a text DXF cannot be guaranteed by a DXF text transformer.

No V146 GitHub Actions run or signed V146 APK is being claimed here. The workflow and patch kit are provided for the repository build; the user must upload them and run Actions unless GitHub write/dispatch permissions are available.
