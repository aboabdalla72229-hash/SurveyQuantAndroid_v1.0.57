#!/usr/bin/env python3
from __future__ import annotations
import argparse,base64,re
from pathlib import Path
META='<meta name="surveyquant-v168" content="sq168-pdf-access-axis-points-explicit-snap-fix">'
def embed_engine(html:str,engine:bytes)->str:
    pattern=r'(<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">)([A-Za-z0-9+/=\r\n]+)(</script>)'
    payload=base64.b64encode(engine).decode('ascii')
    html,n=re.subn(pattern,lambda m:m.group(1)+payload+m.group(3),html,count=1,flags=re.I)
    if n!=1:raise ValueError(f'Expected one embedded CAD engine slot, found {n}')
    return html
def validate(html:str,engine:bytes)->None:
    for marker in (META,'sq167-dwg-orientation-view-transform','sq166-readonly-source-and-exact-pdf-raster','sq164-cad-output-axis-fix','sqDownloadNameDialog','sq163-pdfjs-worker','sq162-wasm-binary','sq163RawCadOverlayMerge'):
        if marker not in html:raise ValueError('Missing HTML marker: '+marker)
    match=re.search(r'<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">([A-Za-z0-9+/=\r\n]+)</script>',html,re.I)
    if not match or base64.b64decode(match.group(1))!=engine:raise ValueError('Embedded CAD engine differs from tested V168 engine')
    text=engine.decode('utf-8')
    for marker in ('SQ_V168_AXIS_SNAP_POINT_AND_RASTER_FIX','function transformGeometryView','sq162-pick-0','sq162-pick-1','sq162-pick-2','sq162-pick-3','state.picks.every(Boolean)','function loadRasterZip','function rasterImageRecord','function readStoredZipBytes','for(const ray of(block.geometry.construction||[]))','if(type===\'POINT\')'):
        if marker not in text:raise ValueError('V168 engine missing: '+marker)
    if 'sq162-start-pick' in text:raise ValueError('Old one-button auto-selection control remains')
    if 'state.pickStage!==4' in text:raise ValueError('Old auto-advance alignment gate remains')
    if 'for (const q of geom.points.slice(0, 8000))' in text:raise ValueError('Forced synthetic plus-mark rendering remains')
    if 'ImageTracer.imagedataToSVG' in text:raise ValueError('PDF image tracer remains enabled')
def patch(html:str,engine:bytes)->str:
    if 'sq167-dwg-orientation-view-transform' not in html:raise ValueError('V167 baseline must be present first')
    if 'sq168-pdf-access-axis-points-explicit-snap-fix' in html:raise ValueError('V168 already applied')
    head=re.search(r'<head\b[^>]*>',html,re.I)
    if not head:raise ValueError('HTML head not found')
    html=html[:head.end()]+META+html[head.end():]
    html=embed_engine(html,engine)
    validate(html,engine)
    return html
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--html',type=Path,required=True);ap.add_argument('--engine',type=Path,required=True);ap.add_argument('--check-only',action='store_true');a=ap.parse_args()
    html=a.html.read_text(encoding='utf-8');engine=a.engine.read_bytes()
    if a.check_only:validate(html,engine);print('PASS V168 HTML and embedded engine validation');return
    a.html.write_text(patch(html,engine),encoding='utf-8');print(f'PASS V168 injected {len(engine):,} engine bytes into {a.html}')
if __name__=='__main__':main()
