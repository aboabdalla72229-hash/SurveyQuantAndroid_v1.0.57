(function () {
'use strict';

const SQ_ORI_SUPPORTED = new Set([
  'LINE','POINT','CIRCLE','ARC','LWPOLYLINE','POLYLINE','VERTEX','SEQEND',
  'TEXT','MTEXT','ATTRIB','ATTDEF','INSERT','SOLID','TRACE','3DFACE',
  'SPLINE','ELLIPSE','RAY','XLINE','LEADER','HATCH'
]);
const SQ_ORI_REQUIRES_NATIVE_CAD = new Set([
  'DIMENSION','MESH','3DSOLID','BODY','REGION','SURFACE','ACAD_PROXY_ENTITY',
  'ACAD_PROXY_OBJECT','MLEADER','MLINE','IMAGE','WIPEOUT','TABLE','HELIX',
  'OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY'
]);

function sqOriSolve(ref1, ref2, src1, src2) {
  const dRef = Math.hypot(ref2.x - ref1.x, ref2.y - ref1.y);
  const dSrc = Math.hypot(src2.x - src1.x, src2.y - src1.y);
  if (![ref1.x,ref1.y,ref2.x,ref2.y,src1.x,src1.y,src2.x,src2.y].every(Number.isFinite)) {
    throw new Error('أدخل إحداثيات رقمية صحيحة للنقاط الأربع.');
  }
  if (dRef < 1e-9 || dSrc < 1e-9) throw new Error('النقطتان في كل لوحة يجب أن تكونا مختلفتين.');
  const angle = Math.atan2(ref2.y-ref1.y, ref2.x-ref1.x) -
                Math.atan2(src2.y-src1.y, src2.x-src1.x);
  const scale = dRef / dSrc;
  if (!Number.isFinite(scale) || scale < 1e-9 || scale > 1e9) {
    throw new Error('معامل المقياس غير منطقي. راجع وحدات وإحداثيات النقطتين.');
  }
  const c = Math.cos(angle), s = Math.sin(angle);
  const tx = ref1.x - scale * (c*src1.x - s*src1.y);
  const ty = ref1.y - scale * (s*src1.x + c*src1.y);
  return {
    scale, angle, angleDeg: angle*180/Math.PI, c, s, tx, ty,
    ref1: {x:ref1.x,y:ref1.y}, ref2: {x:ref2.x,y:ref2.y},
    src1: {x:src1.x,y:src1.y}, src2: {x:src2.x,y:src2.y},
    point: function (x,y) { return {x:scale*(c*x-s*y)+tx, y:scale*(s*x+c*y)+ty}; },
    vector: function (x,y) { return {x:scale*(c*x-s*y), y:scale*(s*x+c*y)}; }
  };
}

function sqOriAscii(bytes, start, end) {
  let out = '';
  for (let i=start;i<end;i++) out += String.fromCharCode(bytes[i]);
  return out;
}
function sqOriNumber(value, label) {
  const n = Number(String(value).trim());
  if (!Number.isFinite(n)) throw new Error('قيمة إحداثي غير رقمية (' + label + '). لم يتم إخراج ملف.');
  return n;
}
function sqOriFormat(n) {
  if (!Number.isFinite(n)) throw new Error('نتيجة تحويل غير صالحة.');
  if (Math.abs(n) < 5e-12) n = 0;
  return n.toFixed(10).replace(/(\.\d*?)0+$/,'$1').replace(/\.$/,'');
}
function sqOriAngle(deg) {
  let out = deg % 360;
  if (out < 0) out += 360;
  return out;
}
function sqOriSplitLines(bytes) {
  const lines = [];
  let i = (bytes.length >= 3 && bytes[0]===0xEF && bytes[1]===0xBB && bytes[2]===0xBF) ? 3 : 0;
  while (i < bytes.length) {
    const start = i;
    while (i < bytes.length && bytes[i] !== 10 && bytes[i] !== 13) i++;
    const contentEnd = i;
    if (i < bytes.length && bytes[i] === 13) i++;
    if (i < bytes.length && bytes[i] === 10) i++;
    lines.push({start,contentEnd,next:i});
  }
  return lines;
}
function sqOriPairs(bytes) {
  const lines = sqOriSplitLines(bytes);
  if (lines.length < 6 || lines.length % 2 !== 0) throw new Error('بنية DXF النصية غير مكتملة أو تالفة.');
  const pairs = [];
  for (let i=0;i<lines.length;i+=2) {
    const codeLine = lines[i], valueLine = lines[i+1];
    const rawCode = sqOriAscii(bytes,codeLine.start,codeLine.contentEnd).trim().replace(/^\uFEFF/,'');
    const code = Number(rawCode);
    if (!Number.isInteger(code)) throw new Error('تعذر قراءة أكواد DXF عند السطر ' + (i+1) + '.');
    pairs.push({
      code, value:sqOriAscii(bytes,valueLine.start,valueLine.contentEnd).trim(),
      valueStart:valueLine.start, valueEnd:valueLine.contentEnd, index:pairs.length
    });
  }
  return pairs;
}
function sqOriEntityRecords(pairs) {
  let section = '', active = null;
  const entities = [];
  let hasEntitiesSection = false;
  function pushActive() { if (active) entities.push(active); active = null; }
  for (let i=0;i<pairs.length;i++) {
    const p = pairs[i];
    if (p.code===0 && p.value.toUpperCase()==='SECTION') {
      pushActive();
      section = (pairs[i+1] ? pairs[i+1].value : '').toUpperCase();
      if (section==='ENTITIES') hasEntitiesSection = true;
      continue;
    }
    if (p.code===0 && p.value.toUpperCase()==='ENDSEC') {
      pushActive(); section = ''; continue;
    }
    if (section==='ENTITIES' && p.code===0) {
      pushActive();
      active = {type:p.value.toUpperCase(),pairs:[p]};
      continue;
    }
    if (section==='ENTITIES' && active) active.pairs.push(p);
  }
  pushActive();
  if (!hasEntitiesSection) throw new Error('لم يتم العثور على قسم ENTITIES داخل ملف DXF.');
  return entities;
}
function sqOriHasXY(pairs) {
  return pairs.some(p => (p.code>=10 && p.code<=18) || (p.code>=20 && p.code<=28) || p.code===43 || p.code===44);
}
function sqOriPaperSpace(pairs) {
  const p = pairs.find(x=>x.code===67);
  return !!p && Number(p.value)===1;
}
function sqOriCheckExtrusion(entity) {
  const px = entity.pairs.find(p=>p.code===210);
  const py = entity.pairs.find(p=>p.code===220);
  const pz = entity.pairs.find(p=>p.code===230);
  if (!px && !py && !pz) return;
  const x = px ? sqOriNumber(px.value,210) : 0;
  const y = py ? sqOriNumber(py.value,220) : 0;
  const z = pz ? sqOriNumber(pz.value,230) : 1;
  if (Math.abs(x)>1e-9 || Math.abs(y)>1e-9 || Math.abs(z-1)>1e-9) {
    throw new Error('توجد عناصر بمستوى أو اتجاه ثلاثي الأبعاد غير افتراضي ('+entity.type+'). أوقفنا التصدير لحماية تفاصيل اللوحة.');
  }
}
function sqOriEditValue(edits, pair, value) {
  edits.set(pair.index, {pair, value:sqOriFormat(value)});
}
function sqOriTransformBytes(input, transform) {
  const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
  if (bytes.length < 16) throw new Error('ملف DXF فارغ أو أقصر من المتوقع.');
  const signature = sqOriAscii(bytes,0,Math.min(bytes.length,22));
  if (signature.indexOf('AutoCAD Binary DXF') >= 0) {
    throw new Error('هذا ملف DXF ثنائي. افتحه في CAD واحفظه بصيغة DXF نصية ASCII ثم أعد المحاولة.');
  }
  const pairs = sqOriPairs(bytes);
  const entities = sqOriEntityRecords(pairs);
  const edits = new Map();
  const foundUnsupported = [];
  let transformedCount = 0;

  for (const entity of entities) {
    if (sqOriPaperSpace(entity.pairs)) continue;
    const type = entity.type;
    const hasXY = sqOriHasXY(entity.pairs);
    if (SQ_ORI_REQUIRES_NATIVE_CAD.has(type) || (!SQ_ORI_SUPPORTED.has(type) && hasXY)) {
      foundUnsupported.push(type);
      continue;
    }
    if (!SQ_ORI_SUPPORTED.has(type)) continue;
    sqOriCheckExtrusion(entity);

    const byCode = new Map();
    for (const p of entity.pairs) {
      if (!byCode.has(p.code)) byCode.set(p.code, []);
      byCode.get(p.code).push(p);
    }
    function transformXY(xCode,yCode,mode) {
      const xs = byCode.get(xCode) || [], ys = byCode.get(yCode) || [];
      const count = Math.min(xs.length,ys.length);
      for (let i=0;i<count;i++) {
        const x = sqOriNumber(xs[i].value,xCode), y = sqOriNumber(ys[i].value,yCode);
        const q = mode==='vector' ? transform.vector(x,y) : transform.point(x,y);
        sqOriEditValue(edits,xs[i],q.x);
        sqOriEditValue(edits,ys[i],q.y);
      }
    }

    for (let xCode=10;xCode<=18;xCode++) {
      // Legacy POLYLINE's 10/20 pair is a required dummy origin, not a vertex.
      if (type==='POLYLINE' && xCode===10) continue;
      let mode = 'point';
      if (xCode===11 && (type==='MTEXT' || type==='ELLIPSE' || type==='RAY' || type==='XLINE')) mode='vector';
      if (type==='SPLINE' && (xCode===12 || xCode===13)) mode='vector';
      transformXY(xCode,xCode+10,mode);
    }
    if (type==='HATCH') {
      transformXY(43,44,'point');
      transformXY(45,46,'vector');
    }

    const scaleCodes = [];
    if (type==='CIRCLE' || type==='ARC') scaleCodes.push(40);
    if (type==='TEXT' || type==='MTEXT' || type==='ATTRIB' || type==='ATTDEF') {
      scaleCodes.push(40);
      if (type==='MTEXT') scaleCodes.push(41);
    }
    if (type==='INSERT') { scaleCodes.push(41,42); }
    if (type==='HATCH') scaleCodes.push(41);
    if (type==='LINE' || type==='LWPOLYLINE' || type==='POLYLINE' || type==='SPLINE' ||
        type==='ELLIPSE' || type==='SOLID' || type==='TRACE' || type==='3DFACE' ||
        type==='TEXT' || type==='MTEXT' || type==='ATTRIB' || type==='ATTDEF' ||
        type==='INSERT' || type==='POINT' || type==='CIRCLE' || type==='ARC' || type==='LEADER') {
      scaleCodes.push(48);
    }
    for (const code of new Set(scaleCodes)) {
      for (const p of byCode.get(code)||[]) {
        const n = sqOriNumber(p.value,code);
        if (n!==0) sqOriEditValue(edits,p,n*transform.scale);
      }
    }

    const rotationCodes = [];
    if (type==='ARC') rotationCodes.push(50,51);
    if (type==='INSERT' || type==='TEXT' || type==='ATTRIB' || type==='ATTDEF') rotationCodes.push(50);
    if (type==='MTEXT' && !(byCode.get(11)&&byCode.get(21))) rotationCodes.push(50);
    if (type==='HATCH') rotationCodes.push(52,53);
    for (const code of rotationCodes) {
      for (const p of byCode.get(code)||[]) {
        const n = sqOriNumber(p.value,code);
        sqOriEditValue(edits,p,sqOriAngle(n+transform.angleDeg));
      }
    }
    transformedCount++;
  }
  if (foundUnsupported.length) {
    const list = Array.from(new Set(foundUnsupported)).slice(0,8).join(', ');
    throw new Error('لم يتم إخراج الملف لأن به عناصر تحتاج محرك CAD أصليًا للحفاظ عليها: '+list+'. لم يتم تغيير الملف الأصلي.');
  }
  if (!transformedCount) throw new Error('لم نجد عناصر مسموحًا بتوجيهها في مساحة الرسم. لم يتم إخراج ملف.');
  const ordered = Array.from(edits.values()).sort((a,b)=>a.pair.valueStart-b.pair.valueStart);
  const chunks = [];
  let cursor = 0, total = 0;
  for (const item of ordered) {
    chunks.push(bytes.slice(cursor,item.pair.valueStart));
    const repl = new TextEncoder().encode(item.value);
    chunks.push(repl);
    total += item.pair.valueStart-cursor + repl.length;
    cursor = item.pair.valueEnd;
  }
  chunks.push(bytes.slice(cursor));
  total += bytes.length-cursor;
  const out = new Uint8Array(total);
  let offset=0;
  for (const chunk of chunks) { out.set(chunk,offset); offset+=chunk.length; }
  return {bytes:out, transformedCount, changedFields:ordered.length};
}

function sqOriReadPoint(prefix) {
  const xRaw = document.getElementById(prefix+'X').value.trim();
  const yRaw = document.getElementById(prefix+'Y').value.trim();
  if (!xRaw || !yRaw) throw new Error('أكمل إحداثيات النقاط الأربع قبل الحساب.');
  const x = Number(xRaw), y = Number(yRaw);
  if (!Number.isFinite(x) || !Number.isFinite(y)) throw new Error('أدخل إحداثيات رقمية صحيحة.');
  return {x,y};
}
function sqOriInputs() {
  return {
    ref1:sqOriReadPoint('sqOriR1'), ref2:sqOriReadPoint('sqOriR2'),
    src1:sqOriReadPoint('sqOriS1'), src2:sqOriReadPoint('sqOriS2')
  };
}
function sqOriSolveFromUI() {
  const p = sqOriInputs();
  return sqOriSolve(p.ref1,p.ref2,p.src1,p.src2);
}
function sqOriMessage(message, bad) {
  const box = document.getElementById('sqOriStatus');
  if (!box) return;
  box.style.display = 'block';
  box.style.color = bad ? '#ffc6c6' : '#d1fae5';
  box.style.borderColor = bad ? '#b91c1c' : '#15803d';
  box.textContent = message;
}
function sqOriPreview() {
  try {
    const r = sqOriSolveFromUI();
    const deg = r.angleDeg.toFixed(6);
    const preview = 'معامل المقياس: '+r.scale.toPrecision(10)+' | زاوية الدوران: '+deg+'°';
    const p1 = r.point(r.src1.x,r.src1.y), p2 = r.point(r.src2.x,r.src2.y);
    const error = Math.max(Math.hypot(p1.x-r.ref1.x,p1.y-r.ref1.y),Math.hypot(p2.x-r.ref2.x,p2.y-r.ref2.y));
    sqOriMessage(preview+' | خطأ التطابق الحسابي: '+error.toExponential(2),false);
    return r;
  } catch(e) { sqOriMessage(e.message||String(e),true); return null; }
}
function sqOriDownload(bytes, targetName) {
  const blob = new Blob([bytes], {type:'application/dxf'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href=url;
  const base=targetName.replace(/\.[^.]+$/,'').replace(/[\\/:*?"<>|]/g,'_');
  a.download=base+'_ORIENTED.dxf';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(function(){URL.revokeObjectURL(url);},1500);
}
async function sqOriExecute() {
  try {
    const refFile = document.getElementById('sqOriReferenceFile').files[0];
    const targetFile = document.getElementById('sqOriTargetFile').files[0];
    if (!refFile || !targetFile) throw new Error('اختر اللوحة المرجعية واللوحة المطلوب توجيهها.');
    if (!/\.(dxf|dwg)$/i.test(refFile.name)) throw new Error('صيغة اللوحة المرجعية يجب أن تكون DWG أو DXF.');
    if (!/\.dxf$/i.test(targetFile.name)) {
      throw new Error('حفاظًا على تفاصيل الملف، هذه النسخة لا تكتب DWG الأصلي. وجّه ملف DXF نصيًا فقط الآن. توجيه DWG وملفات Civil 3D المتخصصة يحتاج محرك كتابة CAD أصليًا، ولن نحوّل الملف تلقائيًا إلى صيغة قد تفقد البيانات.');
    }
    const transform = sqOriPreview();
    if (!transform) return;
    const bytes = new Uint8Array(await targetFile.arrayBuffer());
    const result = sqOriTransformBytes(bytes,transform);
    sqOriDownload(result.bytes,targetFile.name);
    sqOriMessage('تم إنشاء نسخة DXF جديدة. العناصر التي تمت معالجتها: '+result.transformedCount+' | الحقول الهندسية المحدثة: '+result.changedFields+'. اللوحة المرجعية والملف الأصلي لم يتغيرا.',false);
  } catch(e) {
    sqOriMessage((e && e.message) ? e.message : String(e),true);
  }
}

function sqOriMount() {
  // Register the project in the real home menu. The project-card CSS hides all
  // cards until openProjectPage activates one, so a hidden card alone is unreachable.
  const homeMenu = document.querySelector('#homeMenu .home-menu');
  if (homeMenu && !document.getElementById('sqOrientationMenuButton')) {
    const menuButton = document.createElement('button');
    menuButton.type = 'button';
    menuButton.className = 'menu-btn';
    menuButton.id = 'sqOrientationMenuButton';
    menuButton.textContent = '🧭 10 توجيه اللوح بنقطتين';
    menuButton.addEventListener('click', function () {
      if (typeof window.openProjectPage === 'function') {
        window.openProjectPage('sqOrientationCard');
      } else {
        const project = document.getElementById('sqOrientationCard');
        if (project) {
          document.body.classList.add('project-mode');
          document.querySelectorAll('.project-card').forEach(function (item) {
            item.classList.remove('active-project');
          });
          project.classList.add('active-project');
        }
      }
    });
    const paymentButton = homeMenu.querySelector('.payment-shortcut');
    if (paymentButton) homeMenu.insertBefore(menuButton, paymentButton);
    else homeMenu.appendChild(menuButton);
  }
  if (document.getElementById('sqOrientationCard')) return;
  const ref = document.getElementById('project1Card');
  if (!ref || !ref.parentNode) return;
  const card = document.createElement('div');
  card.className = 'card project-card';
  card.id = 'sqOrientationCard';
  card.innerHTML =
    '<h3>🧭 توجيه لوح CAD / Civil بنقطتين</h3>'+ 
    '<div class="info-list">مطابقة نقطتين معلومتين لحساب الدوران والمقياس والإزاحة، مع إنشاء نسخة DXF جديدة دون إعادة رسم العناصر.</div>'+ 
    '<button class="btn-blue" type="button" onclick="sqOpenOrientationProject()">🧭 فتح مشروع توجيه اللوح</button>';
  ref.parentNode.insertBefore(card,ref);

  const style = document.createElement('style');
  style.id='sqOrientationStyle';
  style.textContent =
    '.sqori-overlay{position:fixed;inset:0;z-index:2147483000;background:rgba(3,8,18,.88);display:none;overflow:auto;padding:14px;box-sizing:border-box}'+
    '.sqori-dialog{max-width:920px;margin:12px auto;background:#182333;color:#f3f7fb;border:1px solid #34445a;border-radius:16px;padding:16px;box-sizing:border-box;font-family:inherit}'+
    '.sqori-dialog h2,.sqori-dialog h3{margin:8px 0 12px}.sqori-dialog label{display:block;font-weight:700;margin:7px 0}.sqori-dialog input{box-sizing:border-box;max-width:100%;width:100%;min-width:0;background:#0f1722;color:#fff;border:1px solid #42536b;border-radius:8px;padding:9px;margin-top:5px}'+
    '.sqori-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.sqori-group{border:1px solid #34445a;border-radius:12px;padding:10px;margin:10px 0}.sqori-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.sqori-actions button{border:0;border-radius:8px;padding:11px 15px;font-weight:800;cursor:pointer}.sqori-help{font-size:13px;line-height:1.7;color:#c6d1df}.sqori-status{display:none;white-space:pre-wrap;border:1px solid;border-radius:10px;padding:10px;margin-top:12px;line-height:1.7;overflow-wrap:anywhere}.sqori-close{float:left;background:#374151;color:white}.sqori-run{background:#15803d;color:#fff}.sqori-preview{background:#2563eb;color:white}.sqori-cancel{background:#4b5563;color:white}@media(max-width:600px){.sqori-grid{grid-template-columns:1fr}.sqori-dialog{padding:11px}.sqori-overlay{padding:5px}}';
  document.head.appendChild(style);

  const overlay = document.createElement('div');
  overlay.className='sqori-overlay';
  overlay.id='sqOriOverlay';
  overlay.innerHTML =
    '<div class="sqori-dialog" role="dialog" aria-modal="true" aria-labelledby="sqOriTitle">'+
      '<button class="sqori-close" type="button" onclick="sqCloseOrientationProject()">✕ إغلاق</button>'+
      '<h2 id="sqOriTitle">🧭 توجيه اللوح بنقطتين معلومتين</h2>'+
      '<p class="sqori-help">أدخل إحداثيات النقطتين المتناظرتين. النقطة 1 في اللوحة المطلوب توجيهها تطابق النقطة 1 المرجعية، والنقطة 2 تطابق النقطة 2 المرجعية. الحساب يستخدم X وY كما هما، ولا يبدّل المحورين.</p>'+
      '<div class="sqori-grid">'+
        '<label>اللوحة المرجعية الموجهة (DWG / DXF)<input id="sqOriReferenceFile" type="file" accept=".dxf,.dwg"></label>'+
        '<label>اللوحة المطلوب توجيهها (DXF نصي في هذه النسخة)<input id="sqOriTargetFile" type="file" accept=".dxf,.dwg"></label>'+
      '</div>'+
      '<div class="sqori-grid">'+
        '<section class="sqori-group"><h3>إحداثيات اللوحة المرجعية</h3>'+ 
          '<label>النقطة 1: X<input id="sqOriR1X" type="number" step="any" inputmode="decimal"></label>'+ 
          '<label>النقطة 1: Y<input id="sqOriR1Y" type="number" step="any" inputmode="decimal"></label>'+ 
          '<label>النقطة 2: X<input id="sqOriR2X" type="number" step="any" inputmode="decimal"></label>'+ 
          '<label>النقطة 2: Y<input id="sqOriR2Y" type="number" step="any" inputmode="decimal"></label></section>'+ 
        '<section class="sqori-group"><h3>إحداثيات اللوحة غير الموجهة</h3>'+ 
          '<label>النقطة 1: X<input id="sqOriS1X" type="number" step="any" inputmode="decimal"></label>'+ 
          '<label>النقطة 1: Y<input id="sqOriS1Y" type="number" step="any" inputmode="decimal"></label>'+ 
          '<label>النقطة 2: X<input id="sqOriS2X" type="number" step="any" inputmode="decimal"></label>'+ 
          '<label>النقطة 2: Y<input id="sqOriS2Y" type="number" step="any" inputmode="decimal"></label></section>'+ 
      '</div>'+ 
      '<div class="sqori-help">حماية البيانات: لا يتم لمس اللوحة المرجعية أو الملف الأصلي. تُعالَج عناصر DXF ثنائية الأبعاد المعروفة فقط. إذا احتوى الملف على كائنات تتطلب محرك CAD أصليًا، فسيوقف البرنامج الإخراج بدل إنشاء ملف ناقص.</div>'+ 
      '<div class="sqori-help" style="margin-top:6px">تنبيه صيغة: محرك DWG الموجود حاليًا في التطبيق للقراءة فقط. لذلك لا تكتب هذه النسخة ملف DWG ولا تحوّله تلقائيًا إلى DXF، حمايةً لعناصر Civil 3D والبيانات المخصصة.</div>'+ 
      '<div class="sqori-actions"><button class="sqori-preview" id="sqOriPreviewBtn" type="button">🧮 معاينة الحساب</button><button class="sqori-run" id="sqOriRunBtn" type="button">✅ توجيه وإخراج نسخة DXF</button><button class="sqori-cancel" type="button" onclick="sqCloseOrientationProject()">إلغاء</button></div>'+ 
      '<div class="sqori-status" id="sqOriStatus" role="status" aria-live="polite"></div>'+ 
    '</div>';
  document.body.appendChild(overlay);
  document.getElementById('sqOriPreviewBtn').addEventListener('click',sqOriPreview);
  document.getElementById('sqOriRunBtn').addEventListener('click',sqOriExecute);
  document.getElementById('sqOriReferenceFile').addEventListener('change',function(){
    const f=this.files[0]; if(f) sqOriMessage('تم اختيار اللوحة المرجعية: '+f.name+'. لن يتم تعديلها.',false);
  });
  document.getElementById('sqOriTargetFile').addEventListener('change',function(){
    const f=this.files[0]; if(f && !/\.dxf$/i.test(f.name)) sqOriMessage('تم اختيار DWG. لن نعدّله أو نحوّله تلقائيًا في هذه النسخة لأن محرك الكتابة الأصلية غير متوفر.',true);
    else if(f) sqOriMessage('تم اختيار اللوحة المطلوب توجيهها: '+f.name+'. سيتم حفظ نسخة جديدة.',false);
  });
}
window.sqOpenOrientationProject = function () {
  const overlay=document.getElementById('sqOriOverlay');
  if(overlay) overlay.style.display='block';
};
window.sqCloseOrientationProject = function () {
  const overlay=document.getElementById('sqOriOverlay');
  if(overlay) overlay.style.display='none';
};
window.__sqOrientTest = {solve:sqOriSolve, transformBytes:sqOriTransformBytes};
if (typeof document !== 'undefined') {
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded',sqOriMount,{once:true});
  else sqOriMount();
}
})();
