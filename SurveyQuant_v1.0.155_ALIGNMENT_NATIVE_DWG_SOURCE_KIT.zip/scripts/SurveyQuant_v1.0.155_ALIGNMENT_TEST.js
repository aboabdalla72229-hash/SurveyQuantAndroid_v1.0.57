'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const core = require('./SurveyQuant_v1.0.155_ALIGNMENT_CORE.js');
const command = fs.readFileSync(path.join(__dirname, 'SurveyQuant_v1.0.155_ALIGNMENT_COMMAND.js'), 'utf8');
const htmlPath = process.env.SQ_V155_HTML || path.join(__dirname, '../SurveyQuant_v1.0.155_ALIGNMENT_NATIVE_DWG.html');

// Two-point CAD Alignment: a 10-unit source baseline becomes a 20-unit vertical baseline.
const t = core.solveAlignment({x:0,y:0},{x:10,y:0},{x:100,y:100},{x:100,y:120});
assert.ok(Math.abs(t.scale - 2) < 1e-10);
assert.ok(Math.abs(t.angleDeg - 90) < 1e-8);
assert.ok(Math.hypot(t.tx-100,t.ty-100) < 1e-8);
assert.ok(t.residual < 1e-8);

// OSNAP intersection mathematics.
const hit = core.segmentIntersection({x:0,y:0},{x:10,y:10},{x:0,y:10},{x:10,y:0});
assert.ok(hit && Math.abs(hit.x-5)<1e-9 && Math.abs(hit.y-5)<1e-9);
assert.equal(core.segmentIntersection({x:0,y:0},{x:1,y:0},{x:0,y:1},{x:1,y:1}), null);
assert.equal(core.segmentIntersection({x:0,y:0},{x:1,y:0},{x:2,y:-1},{x:2,y:1}), null);

// Raw DXF fixture: no entity reconstruction, preserves handles, layer table and XData.
const input = [
'0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','0','ENDSEC',
'0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','1','0','LAYER','5','ABCD','2','ROAD','70','0','62','7','6','CONTINUOUS','0','ENDTAB','0','ENDSEC',
'0','SECTION','2','BLOCKS',
'0','BLOCK','5','B001','8','0','2','AXIS_LABEL','70','0','10','5','20','0','30','0',
'0','TEXT','5','B002','8','AXIS','10','6','20','0','30','0','40','1','1','GRID A','50','0',
'0','ENDBLK','5','B003','8','0',
'0','ENDSEC',
'0','SECTION','2','ENTITIES',
'0','LINE','5','A1B2','8','ROAD','10','0','20','0','30','0','11','10','21','0','31','0','1001','SURVEYQUANT','1000','KEEP XDATA',
'0','CIRCLE','8','ROAD','10','5','20','0','30','0','40','2',
'0','TEXT','8','ROAD','10','1','20','0','30','0','40','2','1','AXIS A','50','0',
'0','LWPOLYLINE','8','ROAD','90','2','70','0','38','0','10','0','20','0','10','10','20','0',
'0','INSERT','5','B010','8','ROAD','2','AXIS_LABEL','10','3','20','4','30','0','41','2','42','2','43','1','50','30',
'0','XLINE','5','B011','8','AXIS','10','0','20','1','30','0','11','0','21','1','31','0',
'0','ENDSEC','0','EOF',''
].join('\r\n');
const result = core.transformDxfBytes(new Uint8Array(Buffer.from(input, 'latin1')), t);
assert.ok(result.entitiesTransformed >= 7, `transformed ${result.entitiesTransformed}`);
const out = Buffer.from(result.bytes).toString('latin1');
assert.match(out,/0\r\nLINE\r\n5\r\nA1B2\r\n/);
assert.match(out,/1001\r\nSURVEYQUANT\r\n1000\r\nKEEP XDATA\r\n/);
assert.match(out,/5\r\nABCD\r\n2\r\nROAD\r\n70\r\n0\r\n62\r\n7\r\n6\r\nCONTINUOUS/);
assert.match(out,/1\r\nGRID A\r\n/);
assert.match(out,/2\r\nAXIS_LABEL\r\n/);
assert.match(out,/5\r\nB010\r\n/);
assert.match(out,/0\r\nXLINE\r\n5\r\nB011\r\n/);
assert.equal((out.match(/0\r\nLINE\r\n/g)||[]).length,1,'alignment must not redraw or duplicate a LINE');
assert.match(out,/0\r\nEOF\r\n?$/);
assert.equal(result.types.LINE,1);
assert.equal(result.types.INSERT,1);

// Crucial block invariant: scale/rotation are applied to the BLOCK definition once, not twice via INSERT.
const insertStart = out.indexOf('0\r\nINSERT\r\n');
const insertEnd = out.indexOf('0\r\nXLINE\r\n', insertStart);
const insertRecord = out.slice(insertStart, insertEnd);
assert.match(insertRecord,/41\r\n2\r\n42\r\n2\r\n43\r\n1\r\n50\r\n30\r\n/,'INSERT instance scales/rotation remain unchanged while its insertion point is aligned');

// Preserve block content semantics: block base point and label geometry are transformed in local coordinates only.
const blockStart=out.indexOf('0\r\nBLOCK\r\n');
const blockEnd=out.indexOf('0\r\nENDBLK\r\n',blockStart);
const blockRecord=out.slice(blockStart,blockEnd);
assert.match(blockRecord,/10\r\n0\r\n20\r\n10\r\n/,'block base point follows the 2D scale/rotation without drawing translation');
const blockTextStart=blockRecord.indexOf('0\r\nTEXT\r\n');
const blockTextEnd=blockRecord.indexOf('0\r\n',blockTextStart+4);
assert.ok(blockTextStart>=0 && /0\r\nTEXT\r\n5\r\nB002[\s\S]*?10\r\n0\r\n20\r\n12\r\n30\r\n0\r\n40\r\n2\r\n1\r\nGRID A\r\n/.test(blockRecord),'block-contained axis text is linearly transformed and remains in the block');

const unsupported = ['0','SECTION','2','ENTITIES','0','ACAD_PROXY_ENTITY','8','0','310','0102ABCD','0','ENDSEC','0','EOF',''].join('\n');
assert.throws(()=>core.transformDxfBytes(new TextEncoder().encode(unsupported),t),/غير مكشوفة/);
assert.throws(()=>core.solveAlignment({x:0,y:0},{x:0,y:0},{x:1,y:1},{x:2,y:2}),/نقطتين متطابقتين/);
assert.match(command,/const ZOOM_MIN=1e-8, ZOOM_MAX=1e8/);
assert.match(command,/sq155SnapIntersection/);
assert.match(command,/CORE\.segmentIntersection/);
assert.match(command,/wheel/);
assert.match(command,/sq155SourceZoomStrong/);
assert.match(command,/!session\.boards\.source\?\.canExport/,'never enable export without raw CAD records');


if (htmlPath) {
  const html=fs.readFileSync(htmlPath,'utf8');
  for(const marker of ['concreteCard','concreteDxfInput','concreteModel','calculateConcreteDxf','calculateConcreteManual','خرسانة'])
    assert.ok(!html.toLowerCase().includes(marker.toLowerCase()), 'removed concrete project marker: '+marker);
  assert.match(html,/SQ_APP_VERSION_CODE = 155/);
  assert.match(html,/id="sq155-alignment-core"/);
  assert.match(html,/id="sq155-alignment-command"/);
  assert.match(html,/sqAlignmentPreviewFromBlocks/);
  assert.match(html,/memory access out of bounds/);
  assert.match(html,/sqAlignmentPreviewFromBlocks|alignmentPreviewEntities/,'DWG axis/label block preview support is wired in HTML');
  assert.doesNotMatch(html,/window\.__sqAlignment154/);
}
console.log('PASS V155 Alignment tests: two-point similarity transform; intersection OSNAP; raw group-code preservation; no LINE redraw; block definitions transformed once; INSERT properties remain unchanged; XLINE support; handles/layers/XData preserved; unsupported opaque entities fail closed; DWG block label preview and export gating present.');
