from pathlib import Path
import os, shutil, base64
from playwright.sync_api import sync_playwright
import ezdxf
root=Path(__file__).resolve().parent
html=(root/'index.html').read_text(encoding='utf-8')
source=root/'source_A.dxf'; target=root/'target_B.dxf'
with sync_playwright() as p:
    exe=os.environ.get('CHROMIUM_BIN') or shutil.which('chromium') or shutil.which('chromium-browser')
    b=p.chromium.launch(executable_path=exe,headless=True,args=['--no-sandbox','--allow-file-access-from-files'])
    page=b.new_page(viewport={'width':430,'height':900}); errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    dialogs=[]
    page.on('dialog',lambda d:(dialogs.append(d.message),d.accept()))
    page.set_content(html,wait_until='domcontentloaded',timeout=90000)
    page.evaluate("window.prompt=(message,defaultValue)=>defaultValue;window.__nativeSaved=null;window.__nativeNotified=null;window.Android={saveFile:(filename,mime,base64)=>{window.__nativeSaved={filename,mime,base64};},notifyDownload:(filename,path,mime)=>{window.__nativeNotified={filename,path,mime};}};")
    assert page.evaluate('typeof window.SurveyQuantCAD181')=='object'
    page.locator('button[onclick="openProjectPage(\'dropFilesCard\')"]').click()
    page.wait_for_timeout(100)
    page.locator('#dropSurveyFiles').set_input_files(str(source))
    page.locator('#dropCadFile').set_input_files(str(target))
    page.locator('button[onclick="dropFilesMerge()"]:visible').click()
    try: page.wait_for_function("document.getElementById('dropFilesResults').style.display==='block'",timeout=30000)
    except Exception:
        print('FAILED DUAL CAD', {'progress':page.locator('#dropFilesProgress').inner_text(), 'summary':page.locator('#dropFilesSummary').inner_text(), 'dialogs':dialogs, 'page_errors':errors})
        raise
    summary=page.locator('#dropFilesSummary').inner_text()
    assert 'source_A.dxf' in summary and 'target_B.dxf' in summary,summary
    page.evaluate('downloadDroppedDXF()')
    page.wait_for_function('window.__nativeSaved!==null',timeout=10000)
    saved=page.evaluate('window.__nativeSaved')
    assert saved['filename']=='SurveyQuant_Dropped_Files.dxf',saved['filename']
    out=root/'V181_TWO_DXF_MERGE_UI_TEST.dxf';out.write_bytes(base64.b64decode(saved['base64']))
    doc=ezdxf.readfile(out); audit=doc.audit(); m=doc.modelspace()
    assert not audit.errors and not audit.fixes,(audit.errors,audit.fixes)
    assert len(m.query('LINE'))>=2 and len(m.query('POLYLINE'))>=2,(len(m.query('LINE')),len(m.query('POLYLINE')))
    assert 'version' not in summary.lower()
    # Dark appearance and removal of instructional-only text from target screens.
    page.evaluate("document.body.classList.remove('project-mode');document.querySelectorAll('.project-card').forEach(x=>x.classList.remove('active-project'));openProjectPage('sqOrientationCard');")
    page.wait_for_timeout(100)
    orientation=page.evaluate("""()=>({bg:getComputedStyle(document.getElementById('sqOrientationCard')).backgroundColor,
      panel:getComputedStyle(document.querySelector('#sqOrientationCard .sq162-panel')).backgroundColor,
      label:getComputedStyle(document.querySelector('#sqOrientationCard h3')).color,
      help:document.querySelector('#sqOrientationCard .sq162-note:not([id])') ? getComputedStyle(document.querySelector('#sqOrientationCard .sq162-note:not([id])')).display : 'none'})""")
    assert orientation['bg'] in ('rgb(16, 25, 37)','rgb(16, 25, 37)') and orientation['help']=='none',orientation
    page.evaluate("document.body.classList.remove('project-mode');document.querySelectorAll('.project-card').forEach(x=>x.classList.remove('active-project'));openProjectPage('sqPdfDxfCard');")
    page.wait_for_timeout(100)
    pdf=page.evaluate("""()=>({bg:getComputedStyle(document.getElementById('sqPdfDxfCard')).backgroundColor,
      help:document.querySelector('#sqPdfDxfCard .sq162-note:not([id])') ? getComputedStyle(document.querySelector('#sqPdfDxfCard .sq162-note:not([id])')).display : 'none'})""")
    assert pdf['bg']=='rgb(16, 25, 37)' and pdf['help']=='none',pdf
    # Both upload controls explicitly accept DXF and DWG, so either pair order works.
    accept_source=page.locator('#dropSurveyFiles').get_attribute('accept') or ''
    accept_target=page.locator('#dropCadFile').get_attribute('accept') or ''
    assert '.dxf' in accept_source and '.dwg' in accept_source and '.dxf' in accept_target and '.dwg' in accept_target
    print({'merge_summary':summary,'modelspace_entities':len(m),'orientation_theme':orientation,'pdf_theme':pdf,'page_errors':errors[:8],'result':'PASS'})
    b.close()
