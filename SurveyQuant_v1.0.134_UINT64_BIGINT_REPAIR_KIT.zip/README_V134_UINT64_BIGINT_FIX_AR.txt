إصلاح خطأ uint64_t في بناء SurveyQuant v1.0.134

محتويات الحزمة:
- build-v134-uint64-tsd-fix.yml: Workflow جديد باسمه الخاص لتجنب تشغيل نسخة قديمة من الـ Workflow.
- SurveyQuant_v1.0.134_OFFLINE_DWG_DXF_EXACT_LAND_QUAD_PATCH.zip: حزمة تعديل التطبيق التي يتطلبها مسار البناء (ارفعها إلى جذر المستودع بالاسم نفسه إذا لم تكن موجودة بالفعل).
- V134_UINT64_BIGINT_FIX_REPORT_AR.txt: تقرير الاختبارات المحلية وحدودها.

طريقة الرفع:
1. ارفع ملف build-v134-uint64-tsd-fix.yml إلى:
   .github/workflows/build-v134-uint64-tsd-fix.yml
2. تأكد أن ملف PATCH التالي موجود بجذر المستودع:
   SurveyQuant_v1.0.134_OFFLINE_DWG_DXF_EXACT_LAND_QUAD_PATCH.zip
3. من تبويب GitHub Actions شغّل Workflow بالاسم:
   Build SurveyQuant v1.0.134 - uint64_t TSD BIGINT repair
4. في سجل خطوة بناء المحرك ابحث عن السطر:
   Verified build:wasm: ... -s WASM_BIGINT=1 --emit-tsd libredwg-web.d.ts
   يجب أن يحتوي الأمر النهائي فعلًا على -s WASM_BIGINT=1.

لا تعِد تشغيل الـ Workflow القديم باسم Offline DWG/DXF + Exact Land Quadrilateral لتفادي التباس النتائج.

الاختبارات المحلية نجحت لصياغة YAML، ومقاطع Bash، وتعديل scripts في package.json محاكٍ لإعداد upstream. لم يتم ادعاء نجاح بناء Emscripten أو APK قبل تشغيله على GitHub.
