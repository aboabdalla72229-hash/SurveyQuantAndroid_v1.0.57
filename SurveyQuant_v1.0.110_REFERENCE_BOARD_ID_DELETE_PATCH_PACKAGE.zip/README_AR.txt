SurveyQuant v1.0.110 - Reference Board Matching + ID 1/2 + Delete/Undo
- Two separate screens: target/unoriented board and reference board.
- Pick point 1 and point 2 on each board in matching order. Local X/Y values auto-fill.
- Calculate a 2D similarity transform mapping target point 1 to reference point 1 and target point 2 to reference point 2.
- Original reference bytes are never transformed or overwritten. The target result is saved as a new DXF.
- Adds OSNAP intersection-first selection, touch pan/pinch zoom, ID Point, entity deletion from the editable target copy, and one-step undo.
- DXF transform edits exposed XY coordinate fields in-place to preserve layer/color/text/XData/handle and other raw fields; it no longer refuses the entire drawing because an entity is unknown or has a non-default extrusion vector. Z values and opaque native binary payloads remain unchanged. Opaque payloads that expose no editable XY data cannot be geometrically transformed without their native CAD engine; those records do not block the output.
- Preview draws the geometry available through the app's current DXF preview parser. Raw DXF data/metadata not used by the preview remains preserved in the output.
