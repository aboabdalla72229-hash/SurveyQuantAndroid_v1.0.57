'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const modulePath=process.argv[2]||path.join(__dirname,'SurveyQuant_v1.0.177_SINGLE_CANVAS_DATA_EXPORT_MODULE.js');
const outDir=process.argv[3]||__dirname;
const cadPath=process.argv[4];
assert.ok(cadPath&&fs.existsSync(cadPath),'V177 CAD engine path is required for the raw DXF merge test');
const cad=require(cadPath);
function crc32(buf){let c=0xffffffff;for(const b of buf){c^=b;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;}
function zipStore(entries){const locals=[],centrals=[];let offset=0;const u16=n=>{const b=Buffer.alloc(2);b.writeUInt16LE(n);return b;};const u32=n=>{const b=Buffer.alloc(4);b.writeUInt32LE(n>>>0);return b;};for(const e of entries){const name=Buffer.from(e.name,'utf8'),data=Buffer.from(e.data),crc=crc32(data);const local=Buffer.concat([u32(0x04034b50),u16(20),u16(0x0800),u16(0),u16(0),u16(33),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),name,data]);const central=Buffer.concat([u32(0x02014b50),u16(20),u16(20),u16(0x0800),u16(0),u16(0),u16(33),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),name]);locals.push(local);centrals.push(central);offset+=local.length;}const lb=Buffer.concat(locals),cb=Buffer.concat(centrals);return new Uint8Array(Buffer.concat([lb,cb,u32(0x06054b50),u16(0),u16(0),u16(entries.length),u16(entries.length),u32(cb.length),u32(lb.length),u16(0)]));}
const jpeg=fs.readFileSync(path.join(__dirname,'V177_TEST_PIXEL.jpg'));
const fakeCtx={fillRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fillText(){},save(){},restore(){},setLineDash(){},strokeRect(){},arc(){},translate(){},rotate(){},drawImage(){},setTransform(){}};
const doc={readyState:'loading',addEventListener(){},getElementById(){return null;},createElement(tag){if(tag!=='canvas')throw new Error('Unexpected element '+tag);return{width:0,height:0,getContext(){return fakeCtx;},toDataURL(){return 'data:image/jpeg;base64,'+jpeg.toString('base64');}};}};
const window={document:doc,SurveyQuantCAD177:cad,setInterval,clearInterval,addEventListener(){},atob:global.atob};
const context={window,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,DataView,Math,Number,String,Map,Set,Promise,console,atob:global.atob};
vm.createContext(context);vm.runInContext(fs.readFileSync(modulePath,'utf8'),context,{filename:modulePath});
const core=window.SurveyQuantV177AddendumCore;assert.ok(core,'V202 core helpers must be published');

// Alignment prompts alternate boards exactly as requested: source P1, reference P1, source P2, reference P2.
const sequence=[0,1,2,3].map(i=>core.alignmentStage(i));
assert.equal(JSON.stringify(sequence),JSON.stringify([{side:'source',slot:0},{side:'target',slot:2},{side:'source',slot:1},{side:'target',slot:3}]));
assert.deepEqual([0,1,2,3].map(core.alignmentPickSlot),[0,2,1,3]);
const picks=[{x:10,y:20},{x:110,y:20},{x:1000,y:2000},{x:1000,y:2200}];
const solved=core.alignment(picks);
assert.equal(solved.scale,2);
assert.ok(Math.abs(solved.rotationDegrees-90)<1e-9);
assert.ok(Math.abs(solved.apply(picks[0]).x-picks[2].x)<1e-8&&Math.abs(solved.apply(picks[0]).y-picks[2].y)<1e-8);
assert.ok(Math.abs(solved.apply(picks[1]).x-picks[3].x)<1e-8&&Math.abs(solved.apply(picks[1]).y-picks[3].y)<1e-8);

// Point IDs are plain numeric strings, with renumbering contract after removal.
assert.deepEqual([1,2,3,4,5].map(core.pointIdForSequence),['1','2','3','4','5']);
assert.throws(()=>core.pointIdForSequence(0),/رقم النقطة/);
const samples=[
 {id:'1',easting:576761.446,northing:858279.357,elevation:12.345},
 {id:'2',easting:576765.125,northing:858284.875,elevation:13.25},
 {id:'3',easting:576769.5,northing:858289.25,elevation:0}
];
const bnt=core.bntText(samples);assert.match(bnt,/^ID,Easting,Northing,Elevation\r?\n1,576761\.446,858279\.357,12\.345/m);
const csv=core.csvText(samples),txt=core.txtText(samples),sdr=core.sdrText(samples);
assert.match(csv,/(?:"1"|1),"576761\.446","858279\.357"/);
assert.match(txt,/^1\t576761\.446\t858279\.357\t12\.345/m);
assert.match(sdr,/08TP,1,576761\.446,858279\.357,12\.345/);
assert.doesNotMatch(csv,/P0001|B0001/);assert.doesNotMatch(sdr,/P0001|B0001/);

// Visual mark style, marker size and text size must be encoded in the board-DXF annotation layer.
const ann=core.annotationDxf(samples,{markerSize:0.75,textSize:1.25,markerStyle:'circle',markerColor:'#ff0000',textColor:'#0000ff',labelMode:'id'});
const annText=new TextDecoder().decode(ann);
assert.match(annText,/\nCIRCLE\r?\n/);
assert.match(annText,/\n40\r?\n0\.75\r?\n/,'selected marker size is written as circle radius');
assert.match(annText,/\n40\r?\n1\.25\r?\n/,'selected point-label size is written into DXF TEXT height');
assert.match(annText,/\n1\r?\n1\r?\n/,'first point label is the numeric ID 1');
assert.match(annText,/SURVEY_POINTS/);assert.match(annText,/SURVEY_LABELS/);

// Exercise the exact raw-record board merge used by the Board DXF save button.
// Exercise the exact V177 solver and oriented-DXF writer used by the Alignment workflow.
const engineSolved=cad.solve(picks[0],picks[1],picks[2],picks[3]);
assert.equal(engineSolved.scale,2);
assert.ok(Math.abs(engineSolved.rotationDegrees-90)<1e-9);
assert.ok(Math.hypot(engineSolved.apply(picks[0]).x-picks[2].x,engineSolved.apply(picks[0]).y-picks[2].y)<1e-8);
assert.ok(Math.hypot(engineSolved.apply(picks[1]).x-picks[3].x,engineSolved.apply(picks[1]).y-picks[3].y)<1e-8);
const board=cad.polylinesToDxf([{points:[{x:10,y:20},{x:110,y:20},{x:110,y:30}],closed:true,aci:3,rgb:0x00ff00}],64,64,1).bytes;
const oriented=cad.createOrientedDxfBytes(board,picks);
assert.ok(oriented?.bytes instanceof Uint8Array&&oriented.bytes.length>board.length);
const unchanged=core.buildBoardDxfBytes(board,[],{});assert.notEqual(unchanged,board);assert.deepEqual(Array.from(unchanged),Array.from(board),'board-only DXF export must preserve the original board byte-for-byte when there are no points');
const mergedBytes=core.buildBoardDxfBytes(board,samples,{markerSize:0.75,textSize:1.25,markerStyle:'circle',markerColor:'#ff0000',textColor:'#0000ff',labelMode:'id'});
assert.ok(mergedBytes instanceof Uint8Array&&mergedBytes.length>board.length);
const mergedText=new TextDecoder('windows-1252').decode(mergedBytes);
assert.match(mergedText,/SURVEY_POINTS/);assert.match(mergedText,/SURVEY_LABELS/);assert.match(mergedText,/CIRCLE/);
fs.mkdirSync(outDir,{recursive:true});
fs.writeFileSync(path.join(outDir,'V202_BOARD_WITH_POINTS_TEST.dxf'),Buffer.from(mergedBytes));
fs.writeFileSync(path.join(outDir,'V202_ORIENTED_SOURCE_TEST.dxf'),Buffer.from(oriented.bytes));

// Existing one/two-finger touch engine remains shared by both canvases.
class FakeCanvas{constructor(){this.dataset={};this.style={};this.listeners={};this.rect={left:0,top:0,width:200,height:200};this._ctx={save(){},restore(){},setLineDash(){},fillRect(){},strokeRect(){}};}addEventListener(n,f){(this.listeners[n]||=[]).push(f);}fire(n,e){for(const f of this.listeners[n]||[])f({...e,preventDefault(){}});}getBoundingClientRect(){return this.rect;}getContext(){return this._ctx;}setPointerCapture(){}releasePointerCapture(){}}
const pointer=(id,x,y)=>({pointerId:id,button:0,clientX:x,clientY:y});
const canvas=new FakeCanvas(),view={zoom:1,cx:100,cy:100,panX:0,panY:0};let mode='window';const windows=[];
function draw(){canvas._sq177Map={baseScale:1,scale:view.zoom,fromScreen:p=>({x:view.cx+(p.x-100-view.panX)/view.zoom,y:view.cy-(p.y-100-view.panY)/view.zoom})};}draw();
assert.equal(core.attachCanvasGestures(canvas,{viewGetter:()=>view,draw,kind:'data',getMode:()=>mode,onWindow:(a,b)=>windows.push([a,b])}),true);
canvas.fire('pointerdown',pointer(1,50,100));canvas.fire('pointerdown',pointer(2,150,100));canvas.fire('pointermove',pointer(2,190,100));assert.ok(view.zoom>1,'pinch zoom must still work');canvas.fire('pointerup',pointer(1,50,100));canvas.fire('pointerup',pointer(2,190,100));
canvas.fire('pointerdown',pointer(3,30,30));canvas.fire('pointermove',pointer(3,80,85));canvas.fire('pointerup',pointer(3,80,85));assert.equal(windows.length,1,'window drag must be routed to CAD window selection');

console.log(JSON.stringify({
 alignmentSequence:sequence,
 alignment:{scale:solved.scale,rotationDegrees:solved.rotationDegrees,secondResidual:solved.secondResidual},
 numericPointIds:[1,2,3,4,5].map(core.pointIdForSequence),
 pointFormats:{SDR:true,BNT_ASCII:true,CSV:true,TXT:true,Excel:core.makeXlsx(samples).length>100,PDF:core.makePdf(samples).length>100},
 boardDXF:{rawBoardKept:true,pointEntitiesMerged:true,markerStyle:'circle',markerSize:0.75,textSize:1.25,bytes:mergedBytes.length},
 orientationWriter:{scale:engineSolved.scale,rotationDegrees:engineSolved.rotationDegrees,orientedDxfBytes:oriented.bytes.length},
 touch:{pinch:true,windowSelection:true},
 result:'PASS'
},null,2));
