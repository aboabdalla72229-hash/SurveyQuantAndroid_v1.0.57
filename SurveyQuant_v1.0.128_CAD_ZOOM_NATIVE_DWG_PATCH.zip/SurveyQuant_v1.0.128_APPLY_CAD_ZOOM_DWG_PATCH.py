#!/usr/bin/env python3
"""SurveyQuant v1.0.128 CAD preview and native-DWG pass-through patch."""
from __future__ import annotations
import argparse, os, re, tempfile, zipfile
from pathlib import Path

OLD_ACTIVE = "size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale*Math.max(0.001,Number(v.zoom)||1))"
OLD_ACTIVE_V127 = "fitTextSize=Math.min(4.5,Math.abs(Number(t.height)||2.5)*m.base*0.35),size=Math.max(0.1,fitTextSize/Math.max(1,Number(v.zoom)||1))"
NEW_ACTIVE = "fitTextSize=Math.min(10,Math.max(6,Math.abs(Number(t.height)||2.5)*m.base*0.8)),size=Math.max(1.15,fitTextSize/Math.sqrt(Math.max(1,Number(v.zoom)||1)))"
OLD_FALLBACK = "ctx.fillStyle='#e9c46a';ctx.font='11px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);"
OLD_FALLBACK_V127 = "ctx.fillStyle='#e9c46a';const fitTextSize=Math.min(4.5,Math.abs(Number(t.height)||2.5)*(m.scale/Math.max(0.001,zoom))*0.35);ctx.font=(Math.max(0.1,fitTextSize/Math.max(1,zoom)))+'px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);"
NEW_FALLBACK = "ctx.fillStyle='#e9c46a';const fitTextSize=Math.min(10,Math.max(6,Math.abs(Number(t.height)||2.5)*(m.scale/Math.max(0.001,zoom))*0.8));ctx.font=(Math.max(1.15,fitTextSize/Math.sqrt(Math.max(1,zoom))))+'px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);"
BRIDGE_ID = 'sq-v117-universal-dwg-bridge'

PASSIVE_BRIDGE = r"""(function () {
  'use strict';
  if (window.__SQ_V128_DWG_NATIVE_BRIDGE__) return;
  window.__SQ_V128_DWG_NATIVE_BRIDGE__ = true;
  var ACCEPT_TYPES = [
    '.dwg', '.dxf', 'application/dwg', 'application/x-dwg',
    'application/dxf', 'application/x-dxf', 'application/acad',
    'application/x-acad', 'image/vnd.dwg'
  ];
  var CAD_INPUT_IDS = new Set([
    'cadFileInput', 'concreteDxfInput', 'quantBeforeFile', 'quantAfterFile', 'quantFileInput',
    'profileFileInput', 'dropSurveyFiles', 'dropCadFile',
    'sqOriReferenceFile', 'sqOriTargetFile', 'sq108File',
    'sq110TargetFile', 'sq110ReferenceFile'
  ]);
  var NON_CAD_DATA_IDS = new Set(['fileToDxfInput', 'cleanFilesInput']);

  function isCadInput(input) {
    if (!input || String(input.tagName || '').toLowerCase() !== 'input' ||
        String(input.type || '').toLowerCase() !== 'file') return false;
    var id = String(input.id || '');
    if (NON_CAD_DATA_IDS.has(id)) return false;
    if (CAD_INPUT_IDS.has(id)) return true;
    var accept = String(input.accept || '').split(',').map(function (item) {
      return item.trim().toLowerCase();
    }).filter(Boolean);
    return accept.some(function (item) {
      return item === '.dxf' || item === '.dwg' || /(^|\/)vnd\.dwg$/.test(item) ||
        item === 'application/dxf' || item === 'application/x-dxf' ||
        item === 'application/acad' || item === 'application/x-acad';
    });
  }

  function addAcceptedTypes(input) {
    if (!isCadInput(input)) return;
    var current = String(input.accept || '').split(',').map(function (item) {
      return item.trim();
    }).filter(Boolean);
    ACCEPT_TYPES.forEach(function (item) {
      if (!current.some(function (existing) { return existing.toLowerCase() === item.toLowerCase(); })) current.push(item);
    });
    input.accept = current.join(',');
  }

  function scanInputs(root) {
    if (!root) return;
    if (root.nodeType === 1) addAcceptedTypes(root);
    if (typeof root.querySelectorAll === 'function') root.querySelectorAll('input[type="file"]').forEach(addAcceptedTypes);
  }

  scanInputs(document);
  if (typeof MutationObserver === 'function' && document.documentElement) {
    new MutationObserver(function (records) {
      records.forEach(function (record) {
        (record.addedNodes || []).forEach(scanInputs);
      });
    }).observe(document.documentElement, { childList: true, subtree: true });
  }

  // Do not globally intercept file-change/drop events or replace a DWG with a converted DXF.
  // The normal parseFile(file) path already has a DWG reader; orientation screens use their
  // own temporary conversion only where the orientation algorithm specifically needs DXF bytes.
  window.__sqV128DwgBridgeAPI = { scanInputs: scanInputs, isCadInput: isCadInput, mode: 'native-dwg-pass-through' };
  window.__sqV117DwgBridgeAPI = window.__sqV128DwgBridgeAPI;
})();"""

def apply_once(source: str, old_options, new: str, label: str) -> str:
    found_new = source.count(new)
    counts = [source.count(o) for o in old_options]
    if found_new == 1 and sum(counts) == 0:
        return source
    if found_new != 0 or sum(counts) != 1:
        raise SystemExit(f'ERROR: {label}: expected one known original or one already-patched formula; new={found_new}, old_counts={counts}')
    for old in old_options:
        if source.count(old) == 1:
            return source.replace(old, new, 1)
    raise SystemExit(f'ERROR: {label}: unsupported original formula')

def replace_exact(source: str, old: str, new: str, expected: int, label: str) -> str:
    count = source.count(old)
    if count == 0 and new in source:
        return source
    if count != expected:
        raise SystemExit(f'ERROR: {label}: expected {expected} old tokens, found {count}')
    return source.replace(old, new)

def patch_html(source: str) -> str:
    result = apply_once(source, [OLD_ACTIVE, OLD_ACTIVE_V127], NEW_ACTIVE, 'active CAD text formula')
    result = apply_once(result, [OLD_FALLBACK, OLD_FALLBACK_V127], NEW_FALLBACK, 'fallback CAD text formula')

    # Preserve zoom anchoring and sensitivity; only raise the ceiling.
    result = replace_exact(result,
        'v.zoom=Math.max(.1584893,Math.min(1000,Number(value)||1))',
        'v.zoom=Math.max(.1584893,Math.min(100000,Number(value)||1))', 1, 'zoom setter ceiling')
    result = replace_exact(result,
        'v.zoom=Math.max(.15,Math.min(1000,v.pinch.zoom*distance/v.pinch.distance))',
        'v.zoom=Math.max(.15,Math.min(100000,v.pinch.zoom*distance/v.pinch.distance))', 1, 'pinch zoom ceiling')
    result = replace_exact(result,
        'v.zoom=Math.max(.15,Math.min(1000,v.zoom*(e.deltaY<0?1.2:1/1.2)))',
        'v.zoom=Math.max(.15,Math.min(100000,v.zoom*(e.deltaY<0?1.2:1/1.2)))', 1, 'wheel zoom ceiling')
    slider_old = 'max="3" step="0.01" value="0" aria-label="تكبير اللوحة حتى 1000 مرة"'
    slider_new = 'max="5" step="0.01" value="0" aria-label="تكبير اللوحة حتى 100000 مرة"'
    result = replace_exact(result, slider_old, slider_new, 2, 'two orientation zoom sliders')

    pattern = re.compile(r'(<script id="' + re.escape(BRIDGE_ID) + r'">)([\s\S]*?)(</script>)', re.I)
    matches = list(pattern.finditer(result))
    if len(matches) != 1:
        raise SystemExit(f'ERROR: expected exactly one V117 bridge script to replace, found {len(matches)}')
    m = matches[0]
    result = result[:m.start(2)] + '\n' + PASSIVE_BRIDGE + '\n' + result[m.end(2):]

    checks = [
        ('function parseFile(file)', 'native file parser'),
        ("if(ext==='dwg')", 'native DWG branch'),
        ('lib.dwg_read_data(bytes,Types.DWG)', 'native DWG reader call'),
        ('function metrics(v){', 'drawing metrics function'),
        ('scale:base*v.zoom', 'unchanged geometry zoom scale'),
        ('function setZoom(side,value){const v=state.views[side];if(!v)return;', 'anchored zoom setter'),
        ('function universalTransformBytes(input,t)', 'byte-preserving CAD transform'),
        ('convertTargetToDxf:sqOriConvertTargetToDxf', 'orientation-local DWG converter'),
        ('fitTextSize=Math.min(10,Math.max(6,Math.abs(Number(t.height)||2.5)*m.base*0.8))', 'new readable proportional text sizing'),
        ('Math.min(100000,Number(value)||1)', 'extended zoom limit'),
        ("mode: 'native-dwg-pass-through'", 'pass-through DWG bridge'),
    ]
    for needle, label in checks:
        if needle not in result:
            raise SystemExit('ERROR: invariant missing after patch: ' + label)
    match = pattern.search(result)
    bridge = match.group(2)
    if re.search(r'addEventListener\([\'\"]change[\'\"]', bridge) or re.search(r'addEventListener\([\'\"]drop[\'\"]', bridge) or 'dispatchEvent(new Event' in bridge:
        raise SystemExit('ERROR: bridge still intercepts/replaces selected DWG files')
    if 'input.__sqV117DwgBusy' in bridge or 'new DataTransfer()' in bridge:
        raise SystemExit('ERROR: global file-replacement bridge remains enabled')
    return result

def patch_apk(source_apk: Path, output_apk: Path) -> None:
    if not source_apk.is_file(): raise SystemExit(f'ERROR: APK missing: {source_apk}')
    output_apk.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='sq-v128-', suffix='.apk', dir=output_apk.parent); os.close(fd)
    count = 0
    try:
        with zipfile.ZipFile(source_apk, 'r') as zin, zipfile.ZipFile(tmp, 'w') as zout:
            for info in zin.infolist():
                name = info.filename
                if re.match(r'^META-INF/[^/]+\.(?:SF|RSA|DSA|EC|MF)$', name, re.I): continue
                data = zin.read(name)
                if name == 'assets/index.html':
                    data = patch_html(data.decode('utf-8')).encode('utf-8'); count += 1
                zout.writestr(info, data)
        if count != 1: raise SystemExit(f'ERROR: expected assets/index.html once, found {count}')
        Path(tmp).replace(output_apk)
    except Exception:
        Path(tmp).unlink(missing_ok=True); raise
    print(f'PATCHED APK HTML: {source_apk} -> {output_apk}; signatures must be regenerated.')

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--html', type=Path)
    p.add_argument('--apk', type=Path)
    p.add_argument('--output', type=Path)
    a = p.parse_args()
    if a.html and not a.apk and not a.output:
        src = a.html.read_text(encoding='utf-8'); out = patch_html(src)
        a.html.write_text(out, encoding='utf-8', newline=''); print(f'PATCHED HTML {a.html}: {len(src)} -> {len(out)} chars'); return
    if a.apk and a.output and not a.html:
        patch_apk(a.apk, a.output); return
    p.error('use --html PATH or --apk SOURCE.apk --output OUTPUT.apk')
if __name__ == '__main__': main()
