#!/usr/bin/env python3
from pathlib import Path
import argparse,base64,re
META='<meta name="surveyquant-v174" content="sq174-ordered-matched-points-bearing-rotation-translation-validation">'
def main():
 p=argparse.ArgumentParser();p.add_argument('--html',type=Path,required=True);p.add_argument('--engine',type=Path,required=True);p.add_argument('--check-only',action='store_true');a=p.parse_args()
 html=a.html.read_text(encoding='utf-8');engine=a.engine.read_bytes()
 if 'sq173-pdfjs-readonly-getdocument-runtime-startup-fix' not in html:raise SystemExit('V173 base marker missing')
 if META not in html:
  if a.check_only:raise SystemExit('V174 metadata missing')
  html=html.replace('<head>','<head>'+META,1)
 slot=re.compile(r'(<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">)([A-Za-z0-9+/=\r\n]+)(</script>)',re.I)
 match=slot.search(html)
 if not match:raise SystemExit('embedded CAD engine slot missing')
 if a.check_only:
  if base64.b64decode(match.group(2))!=engine:raise SystemExit('embedded engine differs from tested V174 engine')
  for marker in (b'SQ_V174_ORDERED_PICK_ALIGNMENT_DIAGNOSTICS',b'function alignmentDiagnostics',b'rotationDegrees',b'translationX'):
   if marker not in engine:raise SystemExit('engine missing '+marker.decode())
  if b'sq162-transform-details' not in engine:raise SystemExit('diagnostic panel missing from engine markup')
  print('PASS V174 patch verification');return
 html,n=slot.subn(lambda m:m.group(1)+base64.b64encode(engine).decode()+m.group(3),html,count=1)
 if n!=1:raise SystemExit('engine replacement failed')
 a.html.write_text(html,encoding='utf-8');print('PASS V174 engine embedded and source patched')
if __name__=='__main__':main()
