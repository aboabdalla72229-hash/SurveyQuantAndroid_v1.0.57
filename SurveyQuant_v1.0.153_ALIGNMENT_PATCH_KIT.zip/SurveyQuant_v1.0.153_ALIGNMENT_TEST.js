'use strict';
const assert=require('node:assert/strict');
const core=require('./SurveyQuant_v1.0.153_ALIGNMENT_CORE.js');
const t=core.solveAlignment({x:0,y:0},{x:10,y:0},{x:100,y:100},{x:100,y:120});
assert.ok(Math.abs(t.scale-2)<1e-10);
assert.ok(Math.abs(t.angleDeg-90)<1e-8);
assert.ok(Math.hypot(t.tx-100,t.ty-100)<1e-8);
assert.ok(t.residual<1e-8);
const crossHit=core.segmentIntersection({x:0,y:0},{x:10,y:10},{x:0,y:10},{x:10,y:0});
assert.ok(crossHit && Math.abs(crossHit.x-5)<1e-9 && Math.abs(crossHit.y-5)<1e-9,'intersection snap math');
assert.equal(core.segmentIntersection({x:0,y:0},{x:1,y:0},{x:0,y:1},{x:1,y:1}),null,'parallel non-intersection');
assert.equal(core.segmentIntersection({x:0,y:0},{x:1,y:0},{x:2,y:-1},{x:2,y:1}),null,'intersection outside first segment');
const input=[
'0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','0','ENDSEC',
'0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','1','0','LAYER','5','ABCD','2','ROAD','70','0','62','7','6','CONTINUOUS','0','ENDTAB','0','ENDSEC',
'0','SECTION','2','ENTITIES',
'0','LINE','5','A1B2','8','ROAD','10','0','20','0','30','0','11','10','21','0','31','0','1001','SURVEYQUANT','1000','KEEP XDATA',
'0','CIRCLE','8','ROAD','10','5','20','0','30','0','40','2',
'0','TEXT','8','ROAD','10','1','20','0','30','0','40','2','1','AXIS A','50','0',
'0','LWPOLYLINE','8','ROAD','90','2','70','0','38','0','10','0','20','0','10','10','20','0',
'0','INSERT','8','ROAD','2','BLOCKA','10','3','20','4','30','0','41','1','42','1','43','1','50','30',
'0','ENDSEC','0','EOF',''
].join('\r\n');
const before=Buffer.from(input,'latin1');
const result=core.transformDxfBytes(new Uint8Array(before),t);
assert.ok(result.entitiesTransformed>=5,`transformed ${result.entitiesTransformed}`);
const out=Buffer.from(result.bytes).toString('latin1');
assert.match(out,/10\r\n100\r\n20\r\n100/); // transformed LINE start
assert.match(out,/40\r\n4(?:\.0*)?\r\n/); // circle radius / text height scaled
assert.match(out,/1\r\nAXIS A\r\n/); // original text retained
assert.match(out,/2\r\nBLOCKA\r\n/); // insert block retained
assert.match(out,/41\r\n2(?:\.0*)?\r\n/); // insert scale adjusted
assert.match(out,/2\r\nROAD\r\n/); // layer name retained
assert.match(out,/5\r\nA1B2\r\n/); // entity handle retained
assert.match(out,/1001\r\nSURVEYQUANT\r\n1000\r\nKEEP XDATA\r\n/); // XData is retained
assert.match(out,/5\r\nABCD\r\n2\r\nROAD\r\n70\r\n0\r\n62\r\n7\r\n6\r\nCONTINUOUS/); // original layer record is kept intact
assert.equal((out.match(/0\r\nLINE\r\n/g)||[]).length,1,'no redraw or duplicate LINE entity');
assert.match(out,/0\r\nEOF\r\n?$/);
assert.equal(result.types.LINE,1);
assert.equal(result.types.CIRCLE,1);
assert.equal(result.types.TEXT,1);
assert.equal(result.types.LWPOLYLINE,1);
assert.equal(result.types.INSERT,1);
const unsupported=[ '0','SECTION','2','ENTITIES','0','ACAD_PROXY_ENTITY','8','0','310','0102ABCD','0','ENDSEC','0','EOF','' ].join('\n');
assert.throws(()=>core.transformDxfBytes(new TextEncoder().encode(unsupported),t),/غير مكشوفة/ );
assert.throws(()=>core.solveAlignment({x:0,y:0},{x:0,y:0},{x:1,y:1},{x:2,y:2}),/نقطتين متطابقتين/);
const fs=require('node:fs');const command=fs.readFileSync(require('node:path').join(__dirname,'SurveyQuant_v1.0.153_ALIGNMENT_COMMAND.js'),'utf8');
assert.match(command,/const ZOOM_MIN=1e-8, ZOOM_MAX=1e8/,'huge zoom range');
assert.match(command,/sq153SnapIntersection/,'visible intersection snap toggle');
assert.match(command,/CORE\.segmentIntersection/,'intersection snap calls tested geometry function');
assert.match(command,/wheel/,'wheel zoom support');
assert.match(command,/sq153SourceZoomStrong/,'strong zoom button');
console.log('PASS V153: two-point alignment math, real segment intersection math, enhanced zoom controls, OSNAP intersection switch, preserved handles/XData/layer records, and fail-closed opaque CAD protection.');
