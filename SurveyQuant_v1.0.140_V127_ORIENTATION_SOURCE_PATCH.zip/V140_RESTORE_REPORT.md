# SurveyQuant V140 restoration report

Restored embedded orientation modules byte-for-byte from V127.

- `sq-orientation-module` SHA-256: `775daab9684935d34f9feb21baa5444471c7763e587d7b0ac605c996988d4de6`
- `sq-orientation-axis-reader-module` SHA-256: `274ac3a49965234ae3f5e6d0c4fdc350fa96b361c28365a562c7f0bd3677bd28`
- `sq-orientation-manual-points-module` SHA-256: `7fdcdb6ac53f5a9809070fc804164b58aa5af96bb91dcfd2435223694ff0e215`
- `sq-orientation-reference-board-module` SHA-256: `72f54e3f428883167991be2b828b9468f3607db48d0120ca0e5ad670e362dc99`
- `sq-orientation-dxf-faithful-recovery-module` SHA-256: `1ae88e62eae5183a9232cd27a431f2c2b14f366acdd97687735615a3b6f07854`
- `sq-orientation-cad-preserve-module` SHA-256: `b18bf0108557805df857b24b8cdb6937365f2c4d4f3d130985ce1aa99d2dfb20`
- `sq-orientation-v115-tools-module` SHA-256: `4b0d53a080e1ca26a5cad52678fc3fe810568e83e08088bed735fc15333de3a4`

The V136 universal DWG picker bridge and WASM path helper were retained.
Board-only storage is cleared on startup and pagehide; returning to the app reloads the WebView unless returning from Android's file chooser.
Local app preferences and device/payment identity keys are preserved.
