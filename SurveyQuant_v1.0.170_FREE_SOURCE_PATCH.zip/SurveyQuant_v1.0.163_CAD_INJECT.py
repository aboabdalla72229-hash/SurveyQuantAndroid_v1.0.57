#!/usr/bin/env python3
"""Inject local CAD alignment, snap/zoom, image tracer, and PDF.js with its worker."""
from __future__ import annotations
import argparse, base64, re
from pathlib import Path

IDS = {
    'tracer': 'sq163-imagetracer',
    'pdfjs': 'sq163-pdfjs-main',
    'pdfworker': 'sq163-pdfjs-worker',
    'engine': 'sq163-cad-engine',
}

def script_payload(name: str, data: bytes) -> str:
    encoded = base64.b64encode(data).decode('ascii')
    return f'<script type="application/octet-stream" id="{IDS[name]}">{encoded}</script>'

def bootstrap() -> str:
    return r'''<script id="sq163-runtime-bootstrap">
(function(){
 'use strict';
 if(window.__sq163RuntimeStarting)return;window.__sq163RuntimeStarting=true;
 function readPayload(id){var n=document.getElementById(id);if(!n)throw new Error('الملف المضمّن مفقود: '+id);var b=atob((n.textContent||'').trim()),a=new Uint8Array(b.length);for(var i=0;i<b.length;i++)a[i]=b.charCodeAt(i);n.textContent='';n.remove();return a;}
 function loadBlobScript(id){return new Promise(function(resolve,reject){try{var bytes=readPayload(id),url=URL.createObjectURL(new Blob([bytes],{type:'text/javascript'})),s=document.createElement('script');s.async=false;s.src=url;s.onload=function(){URL.revokeObjectURL(url);resolve();};s.onerror=function(){URL.revokeObjectURL(url);reject(new Error('تعذر تشغيل محرك مضمّن: '+id));};(document.head||document.documentElement).appendChild(s);}catch(e){reject(e);}});}
 function makePdfWorkerUrl(){var bytes=readPayload('sq163-pdfjs-worker');var url=URL.createObjectURL(new Blob([bytes],{type:'text/javascript'}));window.__sq163PdfWorkerUrl=url;if(window.pdfjsLib&&window.pdfjsLib.GlobalWorkerOptions)window.pdfjsLib.GlobalWorkerOptions.workerSrc=url;else throw new Error('واجهة إعداد عامل PDF.js غير موجودة.');window.addEventListener('pagehide',function(){try{URL.revokeObjectURL(url);}catch(_){}},{once:true});}
 (async function(){
  try{
   await loadBlobScript('sq163-imagetracer');
   if(!window.ImageTracer||typeof window.ImageTracer.imagedataToSVG!=='function')throw new Error('لم يتم تسجيل محرك ImageTracer.');
   await loadBlobScript('sq163-pdfjs-main');
   if(!window.pdfjsLib||typeof window.pdfjsLib.getDocument!=='function')throw new Error('لم يتم تسجيل قارئ PDF.js.');
   makePdfWorkerUrl();
   if(window.pdfjsLib.GlobalWorkerOptions.workerSrc!==window.__sq163PdfWorkerUrl)throw new Error('لم يتم ضبط مسار عامل PDF.js المضمّن.');
   await loadBlobScript('sq163-cad-engine');
   if(!window.SurveyQuantCAD163||typeof window.SurveyQuantCAD163.mount!=='function')throw new Error('لم يتم تشغيل أدوات CAD الإصدار 163.');
   window.__sq163RuntimeReady=true;window.dispatchEvent(new CustomEvent('surveyquant-cad-ready'));
   console.info('SurveyQuant V163 offline CAD, PDF worker and ImageTracer ready');
  }catch(e){window.__sq163RuntimeError=String(e&&e.message||e);console.error('SurveyQuant V163 runtime initialization failed',e);}
 })();
})();
</script>'''

def validate(html: str, tracer: bytes, pdfjs: bytes, worker: bytes, engine: bytes) -> None:
    if 'sq163-runtime-bootstrap' in html:
        if html.count('sq163-runtime-bootstrap') != 1:
            raise ValueError('V163 runtime bootstrap must occur exactly once')
        if 'sq163-pdfjs-worker' not in html or 'GlobalWorkerOptions.workerSrc' not in html:
            raise ValueError('PDF.js workerSrc bootstrap is missing')
    engine_text=engine.decode('utf-8')
    if 'disableWorker: true' in engine_text:
        raise ValueError('PDF.js still disables the worker while requiring workerSrc')
    if 'isEvalSupported: false' not in engine_text:
        raise ValueError('PDF.js must keep isEvalSupported=false for the PDF.js 3.x security workaround')
    if 'mergeRawDxfBoards' not in engine.decode('utf-8'):
        raise ValueError('Raw DXF entity merge engine missing')
    if 'SurveyQuantCAD163' not in engine.decode('utf-8'):
        raise ValueError('CAD engine global version marker missing')
    if 'sq162-snap-mode' not in engine.decode('utf-8') or 'pointercancel' not in engine.decode('utf-8'):
        raise ValueError('Zoom/snap viewport controls missing')
    limits = {'ImageTracer': 10_000, 'PDF.js main': 100_000, 'PDF.js worker': 100_000, 'CAD engine': 30_000}
    for label, data in [('ImageTracer',tracer),('PDF.js main',pdfjs),('PDF.js worker',worker),('CAD engine',engine)]:
        if len(data) < limits[label]:
            raise ValueError(f'{label} bundle is unexpectedly small ({len(data)} bytes)')
    if re.search(r'<script[^>]+src=["\'](?:https?:)?//', html, re.I):
        raise ValueError('External remote script URL detected; V163 must work offline')

def main() -> None:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--html',required=True,type=Path)
    p.add_argument('--core',required=True,type=Path)
    p.add_argument('--imagetracer',required=True,type=Path)
    p.add_argument('--pdfjs',required=True,type=Path)
    p.add_argument('--pdf-worker',required=True,type=Path)
    p.add_argument('--check-only',action='store_true')
    a=p.parse_args()
    files={'tracer':a.imagetracer.read_bytes(),'pdfjs':a.pdfjs.read_bytes(),'pdfworker':a.pdf_worker.read_bytes(),'engine':a.core.read_bytes()}
    html=a.html.read_text(encoding='utf-8')
    if a.check_only:
        validate(html,*[files[k] for k in ('tracer','pdfjs','pdfworker','engine')])
        for name,ident in IDS.items():
            if html.count(f'id="{ident}"')!=1: raise SystemExit(f'Expected one embedded payload: {ident}')
        print('PASS V163 injector: real PDF.js worker is embedded and workerSrc is set to a local Blob URL; ImageTracer and CAD engine are embedded once.')
        return
    if 'sq163-runtime-bootstrap' in html or 'sq163-cad-engine' in html:
        raise SystemExit('V163 runtime already appears in HTML; refusing duplicate injection.')
    validate('', *[files[k] for k in ('tracer','pdfjs','pdfworker','engine')])
    payload='\n'.join(script_payload(name,files[name]) for name in ('tracer','pdfjs','pdfworker','engine'))+'\n'+bootstrap()+'\n'
    if '</body>' in html.lower():
        index=html.lower().rfind('</body>');html=html[:index]+payload+html[index:]
    else:html+=payload
    a.html.write_text(html,encoding='utf-8')
    print(f'PASS V163 inject: ImageTracer {len(files["tracer"]):,} B, PDF.js {len(files["pdfjs"]):,} B, worker {len(files["pdfworker"]):,} B, CAD engine {len(files["engine"]):,} B')

if __name__=='__main__':main()
