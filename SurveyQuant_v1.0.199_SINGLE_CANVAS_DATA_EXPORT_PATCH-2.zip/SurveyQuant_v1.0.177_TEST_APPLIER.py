#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys, tempfile
here=Path(__file__).resolve().parent
applier=here/'SurveyQuant_v1.0.177_APPLY_SINGLE_CANVAS_DATA_PATCH.py'
package_test=here/'SurveyQuant_v1.0.177_TEST_ADDENDUM_PACKAGE.py'
module=here/'SurveyQuant_v1.0.177_SINGLE_CANVAS_DATA_EXPORT_MODULE.js'
with tempfile.TemporaryDirectory() as td:
    html=Path(td)/'index.html'
    html.write_text('''<!doctype html><html><head></head><body>
<script>window.SurveyQuantCAD177={}; window.SurveyQuantCAD176=window.SurveyQuantCAD177; async function parseFile(){}; window.safeDownloadFile=()=>{};</script>
<div id="homeMenu"><div class="home-menu"></div></div>
</body></html>''',encoding='utf-8')
    r=subprocess.run([sys.executable,str(applier),'--html',str(html),'--module',str(module)],capture_output=True,text=True)
    assert r.returncode==0,r.stdout+r.stderr
    r=subprocess.run([sys.executable,str(package_test),'--html',str(html),'--module',str(module)],capture_output=True,text=True)
    assert r.returncode==0,r.stdout+r.stderr
    r=subprocess.run([sys.executable,str(applier),'--html',str(html),'--module',str(module),'--check-only'],capture_output=True,text=True)
    assert r.returncode==0,r.stdout+r.stderr
    r=subprocess.run([sys.executable,str(applier),'--html',str(html),'--module',str(module)],capture_output=True,text=True)
    assert r.returncode!=0 and 'already integrated' in (r.stdout+r.stderr)
print('PASS safe appender: injection, idempotent check, duplicate refusal')
