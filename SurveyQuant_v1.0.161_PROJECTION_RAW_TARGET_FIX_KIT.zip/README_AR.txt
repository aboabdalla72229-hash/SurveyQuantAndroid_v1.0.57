SurveyQuant v1.0.161: إصلاح بطء إسقاط DWG والخروج المفاجئ

الملفات داخل الحزمة:
1) SurveyQuant_v1.0.161_PROJECTION_RAW_TARGET_FIX.py
2) SurveyQuant_v1.0.161_PROJECTION_RAW_TARGET_TEST.js
3) .github/workflows/build-v161-projection-raw-target-fix.yml

ارفع الملفات من الهاتف بالترتيب التالي حتى لا يبدأ البناء قبل اكتمال الملفات:
1. ارفع ملف Python إلى جذر المستودع.
2. ارفع ملف JavaScript الاختبار إلى جذر المستودع.
3. ارفع ملف YAML إلى المسار .github/workflows/build-v161-projection-raw-target-fix.yml أخيرًا.

بعدها افتح تبويب Actions، واختر:
Build SurveyQuant v1.0.161 Projection Raw-Target Fix
ثم Run workflow. اترك source_run_id كما هو: 40514133976.

بعد نجاح البناء نزّل APK من Artifact باسم:
SurveyQuant-v1.0.161-FREE-PROJECTION-RAW-TARGET-FIX

مهم:
- فحصت سكربت V160 ثم V161 على مصدر V159 الحقيقي، واجتازت اختبارات regression وفحص JavaScript.
- جرّبت تغليف APK غير موقّع: نجح فحص APK وظهر كود الإصدار 161، والـHTML المعدل موجود داخل assets/index.html.
- لم يُوقّع APK هنا ولم يُختبر بعد على هاتفك بملفي DWG الفعليين، لذلك يلزم تشغيل Workflow ثم تجربة الإسقاط على الجهاز.
- خطأ Release immutable في v1.0.160 سببه أن GitHub يمنع تعديل أصول Release غير القابلة للتغيير. هذا الـWorkflow ينشر على tag جديد v1.0.161، ولا يحاول استبدال ملفات v1.0.160.
