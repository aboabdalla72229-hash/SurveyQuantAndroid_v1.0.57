'use strict';
const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const modulePath = process.argv[2] || path.join(__dirname,'SurveyQuant_v1.0.106_ORIENTATION_HOME_MENU_MODULE.js');
const src = fs.readFileSync(modulePath,'utf8');
const window = { addEventListener() {} };
const document = { readyState:'loading', addEventListener() {} };
const ctx = { window, document, Uint8Array, TextEncoder, Blob, URL, Math, Number, String, Map, Set, Array, Error };
vm.runInNewContext(src,ctx,{filename:modulePath});
const api = window.__sqOrientTest;
assert(api && typeof api.solve==='function' && typeof api.transformBytes==='function','test API not exported');
const tr = api.solve({x:100,y:200},{x:100,y:220},{x:0,y:0},{x:10,y:0});
assert(Math.abs(tr.scale-2)<1e-10,'wrong scale');
assert(Math.abs(tr.angleDeg-90)<1e-9,'wrong rotation');
const p1=tr.point(0,0), p2=tr.point(10,0);
assert(Math.hypot(p1.x-100,p1.y-200)<1e-9,'first point not mapped');
assert(Math.hypot(p2.x-100,p2.y-220)<1e-9,'second point not mapped');
const sample = ['0','SECTION','2','ENTITIES','0','LINE','5','A1','8','ROAD','10','0','20','0','30','0','11','10','21','0','31','0','0','CIRCLE','5','A2','8','MARKS','10','2','20','2','30','5','40','3','0','TEXT','5','A3','8','LABELS','10','3','20','4','30','0','40','2','1','نقطة محفوظة','50','0','0','ENDSEC','0','EOF',''].join('\r\n');
const input = new TextEncoder().encode(sample);
const result = api.transformBytes(input,tr);
const output = Buffer.from(result.bytes).toString('utf8');
assert(output.includes('\r\n10\r\n100\r\n20\r\n200\r\n30\r\n0\r\n11\r\n100\r\n21\r\n220\r\n31\r\n0'),'LINE coordinates not transformed');
assert(output.includes('\r\n10\r\n96\r\n20\r\n204\r\n30\r\n5\r\n40\r\n6'),'CIRCLE center/radius not transformed');
assert(output.includes('نقطة محفوظة'),'UTF-8 text content not preserved');
assert(output.includes('\r\n5\r\nA1\r\n8\r\nROAD'),'entity handle/layer changed');
assert(result.transformedCount===3,'unexpected entity count');
assert(result.changedFields>=10,'not enough geometric fields updated');
const unsupported = new TextEncoder().encode(['0','SECTION','2','ENTITIES','0','ACAD_PROXY_ENTITY','5','AA','10','1','20','2','0','ENDSEC','0','EOF',''].join('\n'));
assert.throws(()=>api.transformBytes(unsupported,tr),/محرك CAD أصلي/,'proxy object must be rejected safely');
assert.throws(()=>api.solve({x:0,y:0},{x:0,y:0},{x:0,y:0},{x:1,y:0}),/مختلفتين/,'coincident points must be rejected');
console.log('PASS: two-point similarity transform, coordinate edits, radius/scale, text-byte preservation, and unsupported-object safety.');

// Integration regression: mount the module into a minimal home-menu DOM and verify
// the visible project button activates the same project card as app navigation.
class FakeElement {
  constructor(doc, tagName) {
    this.doc = doc; this.tagName = tagName; this.children = []; this.parentNode = null;
    this.listeners = {}; this._id = ''; this.className = ''; this.textContent = '';
    this.style = {}; this.value = ''; this.files = []; this._innerHTML = '';
    const self = this;
    this.classList = {
      add(name) { const s = new Set(self.className.split(/\s+/).filter(Boolean)); s.add(name); self.className = [...s].join(' '); },
      remove(name) { self.className = self.className.split(/\s+/).filter(x => x && x !== name).join(' '); },
      contains(name) { return self.className.split(/\s+/).includes(name); }
    };
  }
  set id(v) { this._id = v; if (v && this.doc) this.doc.ids.set(v, this); }
  get id() { return this._id; }
  set innerHTML(v) {
    this._innerHTML = v;
    const re = /\bid=["']([^"']+)["']/g; let m;
    while ((m = re.exec(v))) if (!this.doc.ids.has(m[1])) {
      const child = new FakeElement(this.doc, 'div'); child.id = m[1];
    }
  }
  get innerHTML() { return this._innerHTML; }
  appendChild(child) {
    if (child.parentNode) child.parentNode.children = child.parentNode.children.filter(x => x !== child);
    child.parentNode = this; this.children.push(child); if (child.id) this.doc.ids.set(child.id, child); return child;
  }
  insertBefore(child, ref) {
    if (!ref || !this.children.includes(ref)) return this.appendChild(child);
    if (child.parentNode) child.parentNode.children = child.parentNode.children.filter(x => x !== child);
    const i = this.children.indexOf(ref); child.parentNode = this; this.children.splice(i, 0, child);
    if (child.id) this.doc.ids.set(child.id, child); return child;
  }
  querySelector(selector) {
    const cls = selector.startsWith('.') ? selector.slice(1) : '';
    const queue = [...this.children];
    while (queue.length) {
      const el = queue.shift();
      if (cls && el.className.split(/\s+/).includes(cls)) return el;
      queue.push(...el.children);
    }
    return null;
  }
  addEventListener(name, fn) { (this.listeners[name] ||= []).push(fn); }
  click() { for (const fn of (this.listeners.click || [])) fn({target:this}); if (typeof this.onclick === 'function') this.onclick(); }
}
function verifyHomeMenuMount() {
  const ids = new Map();
  const doc = {
    ids, readyState:'complete',
    createElement(tag) { return new FakeElement(doc, tag); },
    getElementById(id) { return ids.get(id) || null; },
    querySelector(selector) { return selector === '#homeMenu .home-menu' ? homeGrid : null; },
    querySelectorAll(selector) {
      if (selector !== '.project-card') return [];
      return container.children.filter(x => x.className.split(/\s+/).includes('project-card'));
    }
  };
  doc.body = new FakeElement(doc,'body'); doc.head = new FakeElement(doc,'head');
  const container = doc.createElement('div'); doc.body.appendChild(container);
  const home = doc.createElement('div'); home.id = 'homeMenu'; container.appendChild(home);
  const homeGrid = doc.createElement('div'); homeGrid.className = 'home-menu'; home.appendChild(homeGrid);
  for (let i=0;i<9;i++) { const b=doc.createElement('button'); b.className='menu-btn'; homeGrid.appendChild(b); }
  const payment = doc.createElement('button'); payment.className='menu-btn payment-shortcut'; homeGrid.appendChild(payment);
  const project1 = doc.createElement('div'); project1.id='project1Card'; project1.className='card project-card'; container.appendChild(project1);
  let opened = null;
  const win = { openProjectPage(id) {
    opened=id;
    doc.querySelectorAll('.project-card').forEach(x=>x.classList.remove('active-project'));
    const target=doc.getElementById(id); if(target) target.classList.add('active-project');
  }};
  vm.runInNewContext(src, {
    window:win, document:doc, Uint8Array, TextEncoder, Blob, URL, Math, Number, String, Map, Set, Array, Error
  }, {filename:'orientation-home-menu-integration.js'});
  const button=doc.getElementById('sqOrientationMenuButton');
  const card=doc.getElementById('sqOrientationCard');
  assert(button, 'orientation menu button was not created');
  assert(button.parentNode===homeGrid, 'orientation button is not inside the home project menu');
  assert(homeGrid.children.indexOf(button) < homeGrid.children.indexOf(payment), 'orientation button should be listed before payment');
  assert(card && card.parentNode===container, 'orientation project card was not mounted');
  assert(button.textContent.includes('توجيه اللوح'), 'orientation button label is missing');
  button.click();
  assert.strictEqual(opened, 'sqOrientationCard', 'menu click did not open the orientation project');
  assert(card.classList.contains('active-project'), 'orientation card did not become the active visible project');
}
verifyHomeMenuMount();
console.log('PASS: home-menu button is created, listed before payment, and activates the orientation project card.');
