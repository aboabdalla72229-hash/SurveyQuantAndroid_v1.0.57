'use strict';
const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const indexPath = process.argv[2];
if (!indexPath) throw new Error('Usage: node dxf-parser-restoration-test.js <index.html>');
const html = fs.readFileSync(indexPath, 'utf8');
function section(startMarker, endMarker) {
  const start = html.indexOf(startMarker);
  const end = html.indexOf(endMarker, start);
  assert(start >= 0 && end > start, `Could not extract ${startMarker}`);
  return html.slice(start, end);
}

// Test the same parser function shipped in the app, using a predictable parser result.
const closureHelper = section('function sqPolylineIsClosed(entity, vertices){', '\nfunction parseDXF(text){');
const parserFunction = section('function parseDXF(text){', '\nasync function loadDWG(){');
const fakeEntities = [
  { type: 'POINT', layer: 'PTS', position: { x: 10, y: 20, z: 3 } },
  { type: 'LINE', layer: 'LINES', vertices: [{ x: 0, y: 0, z: 0 }, { x: 5, y: 6, z: 0 }] },
  { type: 'LWPOLYLINE', layer: 'BOUNDARY', closed: true, vertices: [{ x: 0, y: 0 }, { x: 4, y: 0 }, { x: 4, y: 3 }, { x: 0, y: 3 }] },
  { type: 'CIRCLE', layer: 'CIRCLES', center: { x: 2, y: 2, z: 0 }, radius: 1 },
  { type: 'ARC', layer: 'ARCS', center: { x: 2, y: 2, z: 0 }, radius: 1, startAngle: 0, endAngle: 90 },
  { type: 'TEXT', layer: 'LEVELS', startPoint: { x: 4, y: 6, z: 0 }, text: '123.45', height: 0.3 },
  { type: 'MTEXT', layer: 'LABELS', position: { x: 8, y: 9, z: 0 }, text: 'LEVEL A', height: 0.25 },
  { type: 'INSERT', layer: 'BLOCKS', position: { x: 1, y: 1, z: 0 }, name: 'TAG', attribs: [{ tag: 'ELEV', value: '125.50', position: { x: 1, y: 1, z: 0 } }] }
];
const context = {
  console,
  DxfParser: class { parseSync() { return { entities: fakeEntities, tables: { layers: { layers: { '0': { name: '0' } } } } }; } },
  p3: (x, y, z) => ({ x: Number(x || 0), y: Number(y || 0), z: Number(z || 0) }),
  addCadEntity: (model, type, layer, data) => model.entities.push({ type, layer, ...data }),
  entityTextValue: e => String(e.text ?? e.string ?? e.value ?? ''),
  textNumber: value => { const s = String(value ?? '').trim(); if (!s) return null; const n = Number(s); return Number.isFinite(n) ? n : null; },
  sqExtractDxfAxisEntities: () => []
};
vm.createContext(context);
vm.runInContext(closureHelper + '\n' + parserFunction + '\nthis.__parseDXF=parseDXF;', context);
const model = context.__parseDXF('synthetic-dxf');
const types = model.entities.map(e => e.type);
for (const expected of ['POINT', 'LINE', 'LWPOLYLINE', 'CIRCLE', 'ARC', 'TEXT', 'MTEXT', 'INSERT', 'ATTRIB']) {
  assert(types.includes(expected), `DXF parser did not retain ${expected}`);
}
assert.strictEqual(model.polylines.length, 1, 'Closed polyline missing from parsed model');
assert.strictEqual(model.polylines[0].closed, true, 'Closed polyline was not recognized as closed');
assert.strictEqual(model.elevTexts.length, 2, 'Elevation text/attribute was not extracted');
assert(model.segments.length >= 4, 'Expected line and closed-boundary segments');
console.log('PASS: DXF parser handles POINT/LINE/LWPOLYLINE/CIRCLE/ARC/TEXT/MTEXT/INSERT without undefined-type errors.');

// Test the actual modern DXF writer for the two branches that had undefined `type` references.
const modernWriter = section('function sqBuildModernEntityRecords(entities,pairs,startHandle){', '\nfunction sqApplyByteEdits(source,edits){');
const writerContext = {
  console,
  safeNum: v => Number.isFinite(Number(v)) ? Number(v) : 0,
  asciiLayerName: s => String(s || '0').replace(/[^A-Za-z0-9_$-]/g, '_'),
  asciiText: s => String(s ?? ''),
  sqFindModelSpaceHandle: () => '1F',
  sqMaxDxfHandle: () => 100n
};
vm.createContext(writerContext);
vm.runInContext(modernWriter + '\nthis.__writeModern=sqBuildModernEntityRecords;', writerContext);
const written = writerContext.__writeModern([
  { type: 'CIRCLE', layer: 'CIRCLE_TEST', center: { x: 1, y: 2, z: 0 }, radius: 3 },
  { type: 'ARC', layer: 'ARC_TEST', center: { x: 4, y: 5, z: 0 }, radius: 6, startAngle: 10, endAngle: 80 }
], [], 100n);
assert(written.text.includes('\nCIRCLE\n'), 'Modern DXF writer failed to write CIRCLE');
assert(written.text.includes('\nARC\n'), 'Modern DXF writer failed to write ARC');
console.log('PASS: Modern DXF writer emits CIRCLE and ARC entities without an undefined-type exception.');

// Verify projection returned to the previously used reference-byte-preserving path.
const dropFunction = section('async function dropFilesMerge(){', '\nfunction resetProjectInputs(');
assert(dropFunction.includes('mergeProjectionDxfPreservingReference(targetModel.rawDXFBytes,additions)'), 'Projection no longer uses the original reference-preserving merge');
assert(!dropFunction.includes('mergeNativeDxfDrawingsPreservingDetails'), 'Unexpected alternate native merger still active');
assert(dropFunction.includes('inspectPreservedReferenceDXF'), 'Projection lost its DXF safety validation');
const modernWriterFull = section('function sqBuildModernEntityRecords(entities,pairs,startHandle){', '\nfunction sqApplyByteEdits(source,edits){');
assert(!/else if\(type===['"](?:CIRCLE|ARC)['"]/.test(modernWriterFull), 'Writer still tests a free type variable');
const renderer = section('function renderModelCanvas(model,title){', '\nfunction dataUrlBytes(');
assert(!/else if\(type===['"](?:CIRCLE|ARC)['"]/.test(renderer), 'Renderer still tests a free type variable');
for (const id of ['project1Card', 'profileCard', 'dropFilesCard', 'paymentPage', 'paymentCard']) assert(html.includes(`id="${id}"`), `Missing required project/payment element ${id}`);
for (const forbidden of ['id="orientationCard"', 'function calculateOrientationByAxes(', 'function downloadOrientedDXF(', 'class="bottom-activate"']) assert(!html.includes(forbidden), `Removed UI/function returned: ${forbidden}`);
assert(html.includes('const SQ_APP_VERSION_CODE = 104;'), 'Runtime version marker is not v104');
console.log('PASS: Projection path restored; required projects and payment page remain; orientation card and fixed bottom payment bar are absent.');

// Byte-preservation regression: an existing reference DXF's entity bytes stay unchanged.
const mergeHelperNames = [
  ['function sqDxfPairsWithOffsets(text){', '\nfunction sqFindDxfSection('],
  ['function sqFindDxfSection(pairs,name){', '\nfunction sqFindDxfLayerTable('],
  ['function sqFindDxfLayerTable(pairs){', '\nfunction sqConcatBytes('],
  ['function sqConcatBytes(parts){', '\nfunction sqEncodeAscii('],
  ['function sqEncodeAscii(text){', '\nfunction sqFindDxfTable('],
  ['function sqDxfVersion(pairs){', '\nfunction sqFindModelSpaceHandle('],
  ['function sqFindHandseedPair(pairs){', '\nfunction sqMaxDxfHandle('],
  ['function sqMaxDxfHandle(pairs){', '\nfunction sqBuildModernLayerRows('],
  ['function sqApplyByteEdits(source,edits){', '\nfunction mergeProjectionDxfPreservingReference('],
  ['function mergeProjectionDxfPreservingReference(rawBytes, additions){', '\nasync function downloadQuantDXF('],
  ['function inspectPreservedReferenceDXF(content){', '\nfunction validatePreservedReferenceDXF('],
  ['function asciiLayerName(name){', '\nfunction asciiText('],
  ['function asciiText(s){', '\nfunction uniqueLayerTable('],
  ['function safeNum(v){', '\nfunction entityToR12('],
  ['function entityToR12(ent){', '\nfunction buildR12FromEntities(']
];
let mergeParts = '';
for (const [startMarker, endMarker] of mergeHelperNames) mergeParts += section(startMarker, endMarker) + '\n';
const mergeContext = {
  console, TextEncoder, TextDecoder, Uint8Array, BigInt, Number, String, Array, Object, Map, Set, Math, RegExp,
  safeNum: v => Number.isFinite(Number(v)) ? Number(v) : 0,
  asciiText: s => String(s ?? '').replace(/\\/g, '/').replace(/[\r\n]/g, ' ').replace(/[^\x20-\x7E]/g, '?').slice(0, 250),
};
vm.createContext(mergeContext);
vm.runInContext(mergeParts + '\nthis.__merge=mergeProjectionDxfPreservingReference; this.__inspect=inspectPreservedReferenceDXF;', mergeContext);
const referenceEntities = [
  '0','CIRCLE','8','0','10','111.125','20','222.25','30','3','40','8',
  '0','TEXT','8','0','10','50','20','60','30','0','40','2.5','1','ORIGINAL_TEXT_STYLE'
].join('\n') + '\n';
const targetDxf = [
  '0','SECTION','2','HEADER','9','$ACADVER','1','AC1009','0','ENDSEC',
  '0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','1',
  '0','LAYER','2','0','70','0','62','7','6','CONTINUOUS','0','ENDTAB','0','ENDSEC',
  '0','SECTION','2','ENTITIES',
].join('\n') + '\n' + referenceEntities + ['0','ENDSEC','0','EOF'].join('\n') + '\n';
const mergedBytes = mergeContext.__merge(new TextEncoder().encode(targetDxf), [
  { type: 'LINE', layer: 'ADDED_FROM_SOURCE', color: 3, a: { x: 1, y: 2, z: 0 }, b: { x: 3, y: 4, z: 0 } }
]);
const mergedText = new TextDecoder('windows-1252').decode(mergedBytes);
assert(mergedText.includes(referenceEntities), 'Reference DXF entity bytes were altered or re-created');
assert(mergedText.includes('ADDED_FROM_SOURCE'), 'Added entity layer was not inserted');
assert(mergedText.includes('\nLINE\n'), 'Added DXF entity was not inserted');
assert.strictEqual(mergeContext.__inspect(mergedText), '', 'Reference-preserving projection produced invalid DXF structure');
console.log('PASS: Overlay leaves the original reference entity records byte-identical and appends only new elements.');
