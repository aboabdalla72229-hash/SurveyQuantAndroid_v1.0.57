#!/usr/bin/env python3
from pathlib import Path
import argparse, re
p=argparse.ArgumentParser(); p.add_argument('--engine',type=Path,required=True); a=p.parse_args()
p=a.engine; s=p.read_text(encoding='utf-8')
def once(old,new,label):
 global s
 n=s.count(old)
 if n!=1: raise SystemExit(f'{label}: expected one match, found {n}')
 s=s.replace(old,new,1)

# Keep PDF pages as a high-resolution color raster IMAGE reference, rather than tracing/thresholding them.
helper=r'''  function imageReferenceDxf(imageFilename, pixelWidth, pixelHeight, unitsPerPixel) {
    const w = Math.floor(Number(pixelWidth)), h = Math.floor(Number(pixelHeight)), scale = Number(unitsPerPixel);
    if (!Number.isInteger(w) || !Number.isInteger(h) || w < 1 || h < 1 || w > 20000 || h > 20000) throw new Error('أبعاد صورة PDF غير صالحة.');
    if (!finite(scale) || scale <= 0 || scale > 1e9) throw new Error('عامل المقياس يجب أن يكون رقمًا موجبًا صالحًا.');
    const name = String(imageFilename || 'PDF_PAGE.png').replace(/[\r\n]/g, '_').replace(/[\\/]/g, '_');
    const drawingWidth = w * scale, drawingHeight = h * scale;
    if (!finite(drawingWidth) || !finite(drawingHeight) || drawingWidth <= 0 || drawingHeight <= 0) throw new Error('أبعاد لوحة PDF بعد المقياس غير صالحة.');
    // The page is a raster IMAGE underlay: no thresholding or polyline tracing.
    const rows = [
      '0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','9','$HANDSEED','5','40','0','ENDSEC',
      '0','SECTION','2','CLASSES',
      '0','CLASS','1','IMAGE','2','AcDbRasterImage','3','ISM','90','2175','91','0','280','0','281','1',
      '0','CLASS','1','IMAGEDEF','2','AcDbRasterImageDef','3','ISM','90','0','91','0','280','0','281','0',
      '0','CLASS','1','IMAGEDEF_REACTOR','2','AcDbRasterImageDefReactor','3','ISM','90','1','91','0','280','0','281','0',
      '0','ENDSEC',
      '0','SECTION','2','TABLES',
      '0','TABLE','2','LTYPE','5','2','330','0','100','AcDbSymbolTable','70','1','0','LTYPE','5','25','330','2','100','AcDbSymbolTableRecord','100','AcDbLinetypeTableRecord','2','CONTINUOUS','70','0','3','Solid line','72','65','73','0','40','0.0','0','ENDTAB',
      '0','TABLE','2','LAYER','5','1','330','0','100','AcDbSymbolTable','70','1','0','LAYER','5','27','330','1','100','AcDbSymbolTableRecord','100','AcDbLayerTableRecord','2','0','70','0','62','7','6','CONTINUOUS','0','ENDTAB',
      '0','TABLE','2','STYLE','5','5','330','0','100','AcDbSymbolTable','70','1','0','STYLE','5','29','330','5','100','AcDbSymbolTableRecord','100','AcDbTextStyleTableRecord','2','STANDARD','70','0','40','0.0','41','1.0','50','0.0','71','0','42','2.5','3','txt','4','','0','ENDTAB',
      '0','TABLE','2','BLOCK_RECORD','5','3','330','0','100','AcDbSymbolTable','70','2',
      '0','BLOCK_RECORD','5','1F','330','3','100','AcDbSymbolTableRecord','100','AcDbBlockTableRecord','2','*Model_Space','70','0','280','1','281','0',
      '0','BLOCK_RECORD','5','20','330','3','100','AcDbSymbolTableRecord','100','AcDbBlockTableRecord','2','*Paper_Space','70','0','280','1','281','0','0','ENDTAB','0','ENDSEC',
      '0','SECTION','2','BLOCKS',
      '0','BLOCK','5','21','330','1F','100','AcDbEntity','8','0','100','AcDbBlockBegin','2','*Model_Space','70','0','10','0.0','20','0.0','30','0.0','3','*Model_Space','1','',
      '0','ENDBLK','5','22','330','1F','100','AcDbEntity','8','0','100','AcDbBlockEnd',
      '0','BLOCK','5','23','330','20','100','AcDbEntity','8','0','100','AcDbBlockBegin','2','*Paper_Space','70','0','10','0.0','20','0.0','30','0.0','3','*Paper_Space','1','',
      '0','ENDBLK','5','24','330','20','100','AcDbEntity','8','0','100','AcDbBlockEnd','0','ENDSEC',
      '0','SECTION','2','ENTITIES',
      '0','IMAGE','5','32','330','1F','100','AcDbEntity','8','0','100','AcDbRasterImage','90','0',
      '10','0.0','20','0.0','30','0.0',
      '11',fmt(scale),'21','0.0','31','0.0','12','0.0','22',fmt(scale),'32','0.0',
      '13',fmt(w),'23',fmt(h),'340','31','70','3','280','0','281','50','282','50','283','0','360','33','71','1','91','2',
      '14','-0.5','24','-0.5','14',fmt(w-0.5),'24',fmt(h-0.5),'290','0','0','ENDSEC',
      '0','SECTION','2','OBJECTS',
      '0','DICTIONARY','5','A','330','0','100','AcDbDictionary','281','1','3','ACAD_IMAGE_DICT','350','30',
      '0','DICTIONARY','5','30','330','A','100','AcDbDictionary','280','1','281','1','3','Raster_0001','350','31',
      '0','IMAGEDEF','5','31','102','{ACAD_REACTORS','330','30','330','33','102','}','330','30','100','AcDbRasterImageDef','90','0','1',name,
      '10',fmt(w),'20',fmt(h),'11','0.01','21','0.01','280','1','281','0',
      '0','IMAGEDEF_REACTOR','5','33','330','32','100','AcDbRasterImageDefReactor','90','2','330','32',
      '0','ENDSEC','0','EOF'
    ];
    return enc.encode(rows.join('\r\n') + '\r\n');
  }
'''
# Insert helper before vector export.
needle='  function polylinesToDxf(paths, width, height, factor) {'
if 'function imageReferenceDxf(' not in s: once(needle,helper+needle,'insert IMAGE DXF helper')
# Preserve real bulge arcs in the orientation screen preview (the DXF records remain unchanged).
bulge=r"""    function connectBulged(pointsList, bulges, closed = false) {
      if (!pointsList.length) return;
      if (pointsList.length === 1) { addPoint(pointsList[0]); return; }
      const count = closed ? pointsList.length : pointsList.length - 1;
      for (let i = 0; i < count && segments.length < maxSegments; i++) {
        const a = pointsList[i], b = pointsList[(i + 1) % pointsList.length], bulge = Number((bulges || [])[i]) || 0;
        addPoint(a);
        const dx = b.x-a.x, dy = b.y-a.y, chord = Math.hypot(dx,dy);
        if (Math.abs(bulge)<1e-10 || chord<1e-10) { addSegment(a,b); continue; }
        const theta=4*Math.atan(bulge), offset=chord*(1-bulge*bulge)/(4*bulge);
        const cx=(a.x+b.x)/2-dy/chord*offset, cy=(a.y+b.y)/2+dx/chord*offset;
        const radius=Math.hypot(a.x-cx,a.y-cy), start=Math.atan2(a.y-cy,a.x-cx);
        const steps=Math.max(2,Math.min(240,Math.ceil(Math.abs(theta)*48)));
        let previous=a;
        for(let k=1;k<=steps&&segments.length<maxSegments;k++) { const angle=start+theta*k/steps, next={x:cx+radius*Math.cos(angle),y:cy+radius*Math.sin(angle)}; addSegment(previous,next); previous=next; }
      }
      if(!closed) addPoint(pointsList[pointsList.length-1]);
    }
"""
once("    function finishPolyline() {\n      if (pendingPolyline) { connect(pendingPolyline.points, pendingPolyline.closed); pendingPolyline = null; }\n    }", bulge+"    function finishPolyline() {\n      if (pendingPolyline) { connectBulged(pendingPolyline.points, pendingPolyline.bulges, pendingPolyline.closed); pendingPolyline = null; }\n    }", 'bulge preview helper')
once("pendingPolyline = { points: [], closed: ((Number((values[70] || [])[0]) || 0) & 1) !== 0 };", "pendingPolyline = { points: [], bulges: [], closed: ((Number((values[70] || [])[0]) || 0) & 1) !== 0 };", 'classic polyline bulges')
once("const p = pointsFromPairs(byCode)[0]; if (p) pendingPolyline.points.push(p);", "const p = pointsFromPairs(byCode)[0]; if (p) { pendingPolyline.points.push(p); pendingPolyline.bulges.push(Number((values[42] || [])[0]) || 0); }", 'classic vertex bulge')
once("const ps = pointsFromPairs(byCode, 10); connect(ps, type === 'LWPOLYLINE' && (((Number((values[70] || [])[0]) || 0) & 1) !== 0));", "const ps = pointsFromPairs(byCode, 10); if (type === 'LWPOLYLINE') connectBulged(ps, values[42] || [], (((Number((values[70] || [])[0]) || 0) & 1) !== 0)); else connect(ps, false);", 'LWPOLYLINE bulge preview')
# Show translation as a first-class part of the two-point similarity result.
once("    const cos = Math.cos(angle), sin = Math.sin(angle);", "    const cos = Math.cos(angle), sin = Math.sin(angle);\n    const translationX = targetA.x - scale * (sourceA.x * cos - sourceA.y * sin);\n    const translationY = targetA.y - scale * (sourceA.x * sin + sourceA.y * cos);", 'translation calculation')
once("      rotationDegrees: angle * 180 / Math.PI,\n      apply,", "      rotationDegrees: angle * 180 / Math.PI,\n      translationX, translationY,\n      apply,", 'translation result')
once("return { bytes: out, scale: tr.scale, rotationDegrees: tr.rotationDegrees, editCount: edits.length };", "return { bytes: out, scale: tr.scale, rotationDegrees: tr.rotationDegrees, translationX: tr.translationX, translationY: tr.translationY, editCount: edits.length };", 'translation metadata')
pat=r"status\(`تم إنشاء DXF الموجّه\..*?`\);"
rep=r"""status(`تم إنشاء DXF الموجّه من اللوحة الأولى على اللوحة المرجعية الثانية.\nالدوران: ${fmt(result.rotationDegrees)} درجة\nالإزاحة X: ${fmt(result.translationX)}\nالإزاحة Y: ${fmt(result.translationY)}\nمعامل المقياس: ${fmt(result.scale)}\nعدد مواضع التعديل: ${result.editCount}\nتم تعديل إحداثيات عناصر DXF الأصلية دون تحويل الأقواس أو المنحنيات إلى خطوط.`);"""
s,n=re.subn(pat,rep,s,count=1,flags=re.S)
if n!=1: raise SystemExit(f'alignment metrics display: expected one match, got {n}')
once("const vectorOnly = type === 'ELLIPSE' && xCode === 11;", "const vectorOnly = (type === 'ELLIPSE' && xCode === 11) || ((type === 'RAY' || type === 'XLINE') && xCode === 11) || (type === 'IMAGE' && (xCode === 11 || xCode === 12));", 'direction vector transform')
once("if (type === 'CIRCLE' || type === 'ARC') setMultiplied(40);", "if (type === 'CIRCLE' || type === 'ARC') setMultiplied(40);\n      if (type === 'HATCH') { setMultiplied(41); setMultiplied(43); setMultiplied(44); setMultiplied(45); setMultiplied(46); setRotated(52); setRotated(53); }", 'HATCH transformation')
once("else if (type === 'DIMENSION') setRotated(53);", "else if (type === 'DIMENSION') { setRotated(50); setRotated(51); setRotated(53); }", 'DIMENSION rotation')
once('return { solve, transformDxfBytes, readGeometry, nearestPoint, svgPathToPolylines, polylinesToDxf, mount };', 'return { solve, transformDxfBytes, readGeometry, nearestPoint, svgPathToPolylines, polylinesToDxf, imageReferenceDxf, mount };', 'export IMAGE DXF helper')
# Extend object URL lifetime because PDF produces two consecutive downloads.
once("root.setTimeout(() => URL.revokeObjectURL(url), 1000);", "root.setTimeout(() => URL.revokeObjectURL(url), 30000);", 'download URL lifetime')
# Use a more informative note and fix reset control id.
old="<div class=\"sq162-note\">استخراج متجهات مجاني داخل التطبيق باستخدام ImageTracer. الناتج يتتبع الخطوط المرئية، ولا يستعيد النصوص أو الإحداثيات أو المقياس الأصلي من صورة ممسوحة ضوئيًا. اضبط عامل المقياس إذا كنت تعرف قيمة مناسبة.</div>"
new="<div class=\"sq162-note\">ملف PDF: يحافظ الإخراج على مظهر الصفحة بألوانها وسمك خطوطها وتفاصيلها كمرجع صورة عالي الدقة داخل DXF، وينزّل ملف PNG مرافقًا يجب إبقاؤه بجانب DXF. الصور العادية تستمر في مسار التتبع المنفصل.</div>"
if old not in s: raise SystemExit('missing PDF explanatory note')
s=s.replace(old,new,1)
once("el('sq162-raster-pdf-page').value = '1';", "el('sq162-pdf-page').value = '1';", 'reset PDF page control')
# The same PDF.js rendering is retained; branch out before thresholding/tracing so colors remain intact.
once("if (!root.ImageTracer || typeof root.ImageTracer.imagedataToSVG !== 'function') throw new Error('محرك التتبع المجاني غير محمّل في هذه النسخة.');", "const isPdf = /\\.pdf$/i.test(file.name) || file.type === 'application/pdf';\n        if (!isPdf && (!root.ImageTracer || typeof root.ImageTracer.imagedataToSVG !== 'function')) throw new Error('محرك التتبع المجاني غير محمّل في هذه النسخة.');", 'allow PDF without image tracer')
once("const sc = Math.min(2, maxDim / base.width, maxDim / base.height);", "const sc = Math.min(4, 5600 / base.width, 5600 / base.height, Math.sqrt(14000000 / Math.max(1, base.width * base.height)));", 'PDF high resolution')
branch=r'''        if (isPdf) {
          const factor = Number(el('sq162-raster-scale').value);
          if (!finite(factor) || factor <= 0) throw new Error('عامل المقياس يجب أن يكون رقمًا موجبًا.');
          const pngBlob = await new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('تعذر إنشاء PNG المرافق لملف DXF.')), 'image/png'));
          const baseName = file.name.replace(/\.[^.]+$/, '').replace(/[^A-Za-z0-9_.-]/g, '_');
          const pngName = `${baseName}_PDF_PAGE_${pageNumber}.png`, dxfName = `${baseName}_PDF_PAGE_${pageNumber}.dxf`;
          const dxfBytes = imageReferenceDxf(pngName, canvas.width, canvas.height, factor);
          rasterCanvas.width = canvas.width; rasterCanvas.height = canvas.height; rasterCanvas.style.display = 'block';
          rasterCanvas.getContext('2d').drawImage(canvas, 0, 0);
          const pngUrl = URL.createObjectURL(pngBlob), a = doc.createElement('a'); a.href = pngUrl; a.download = pngName; a.style.display = 'none'; doc.body.appendChild(a); a.click(); a.remove(); root.setTimeout(() => URL.revokeObjectURL(pngUrl), 30000);
          root.setTimeout(() => downloadBytes(dxfBytes, dxfName), 600);
          status(`تم إنشاء DXF يحافظ على مظهر صفحة PDF بالألوان والتفاصيل.\nالدقة: ${canvas.width} × ${canvas.height} بكسل\\nتم تنزيل ملفي DXF وPNG مرافق. احتفظ بهما في المجلد نفسه لظهور اللوحة في AutoCAD/DWG.\nعامل المقياس: ${fmt(factor)} وحدة/بكسل.`, 'sq162-raster-status');
          canvas.width = 1; canvas.height = 1; return;
        }
'''
once("        if (canvas.width * canvas.height > maxDim * maxDim) throw new Error('حجم الصفحة أكبر من الحد الآمن للتحويل.');", branch+"        if (canvas.width * canvas.height > maxDim * maxDim) throw new Error('حجم الصفحة أكبر من الحد الآمن للتحويل.');", 'PDF sidecar branch')
# PDF should not rasterize at the old 1400 px cap, which applies only to image tracing.
once("await page.render({ canvasContext: ctx, viewport }).promise;", "await page.render({ canvasContext: ctx, viewport, intent: 'print' }).promise;", 'PDF print rendering intent')
once("const maxDim = 1400; let canvas = doc.createElement('canvas')", "const maxDim = 1400; let pageNumber = 1; let canvas = doc.createElement('canvas')", 'PDF page scope')
once("const pageNumber = Math.max(1, Math.min(pdf.numPages, Number.parseInt(el('sq162-pdf-page').value || '1', 10) || 1));", "pageNumber = Math.max(1, Math.min(pdf.numPages, Number.parseInt(el('sq162-pdf-page').value || '1', 10) || 1));", 'PDF page assignment')
if s.count('function imageReferenceDxf(')!=1: raise SystemExit('IMAGE helper injection failed')
if 'imageReferenceDxf(pngName, canvas.width, canvas.height, factor)' not in s: raise SystemExit('PDF IMAGE output branch missing')
p.write_text(s,encoding='utf-8')
print('PASS V163 patch: PDF uses color PNG IMAGE underlay; two-point CAD transform refinements applied.')
