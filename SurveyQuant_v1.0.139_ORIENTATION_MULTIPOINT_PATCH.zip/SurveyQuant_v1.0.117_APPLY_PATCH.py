#!/usr/bin/env python3
"""Fail-closed V117 patch: proportional CAD annotation scale + shared DWG import."""
from pathlib import Path
import re
import sys

OLD_FORMULAS = (
    "size=Math.max(5.5,Math.min(15,Math.abs(Number(t.height)||2.5)*m.scale));",
    "size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale);",
)
NEW_FORMULA = "size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale*Math.max(0.001,Number(v.zoom)||1));"
BRIDGE_ID = 'sq-v117-universal-dwg-bridge'

if len(sys.argv) != 4:
    raise SystemExit("usage: SurveyQuant_v1.0.117_APPLY_PATCH.py REFERENCE_MODULE.js INDEX_PATH.html DWG_BRIDGE.js")

module_path, index_path, bridge_path = map(Path, sys.argv[1:])
bridge = bridge_path.read_text(encoding="utf-8")

# Validate the bridge before changing either production file.
required_bridge = [
    "window.sqOriConvertTargetToDxf",
    "ACCEPT_TYPES",
    "MutationObserver",
    "convertList",
    "new DataTransfer()",
    r"\.dwg",
    r"\.dxf",
]
missing = [item for item in required_bridge if item not in bridge]
if missing:
    raise SystemExit("ERROR: V117 DWG bridge missing required pieces: " + ", ".join(missing))
if r"\\.dwg" in bridge:
    raise SystemExit("ERROR: bridge contains a broken double-escaped DWG extension matcher.")
if bridge.count(r"/\.dwg$/i") != 4:
    raise SystemExit(f"ERROR: expected four correct case-insensitive .dwg matchers; found {bridge.count(r'/\.dwg$/i')}.")

updated = []
for path in (module_path, index_path):
    source = path.read_text(encoding="utf-8")
    found_target = source.count(NEW_FORMULA)
    found_old = sum(source.count(formula) for formula in OLD_FORMULAS)
    if found_target == 1 and found_old == 0:
        pass  # Idempotent re-application.
    elif found_target == 0 and found_old == 1:
        for formula in OLD_FORMULAS:
            if formula in source:
                source = source.replace(formula, NEW_FORMULA, 1)
                break
    else:
        raise SystemExit(
            f"ERROR: {path.name}: expected one known old text-size formula or the V117 formula; "
            f"old={found_old}, new={found_target}. Refusing an ambiguous replacement."
        )

    if "function universalTransformBytes(input,t)" not in source:
        raise SystemExit(f"ERROR: {path.name}: byte-preserving CAD transform is missing; refusing patch.")
    if source.count(NEW_FORMULA) != 1 or any(formula in source for formula in OLD_FORMULAS):
        raise SystemExit(f"ERROR: {path.name}: proportional CAD text scaling did not verify.")
    updated.append((path, source))

html = updated[1][1]
pattern = re.compile(r'(<script id="' + re.escape(BRIDGE_ID) + r'">)[\s\S]*?(</script>)', re.I)
match_count = len(pattern.findall(html))
if match_count == 1:
    html = pattern.sub(lambda m: m.group(1) + "\n" + bridge.rstrip() + "\n" + m.group(2), html, count=1)
elif match_count == 0:
    if "</body>" not in html.lower():
        raise SystemExit("ERROR: HTML body end not found; cannot install shared DWG bridge.")
    html, count = re.subn(
        r"</body\s*>",
        lambda _m: '<script id="' + BRIDGE_ID + '">\n' + bridge.rstrip() + '\n</script>\n</body>',
        html, count=1, flags=re.I
    )
    if count != 1:
        raise SystemExit("ERROR: could not inject the V117 DWG bridge exactly once.")
else:
    raise SystemExit(f"ERROR: found {match_count} duplicate V117 bridge tags.")

for token, label in [
    (NEW_FORMULA, "V117 proportional text formula"),
    ('id="' + BRIDGE_ID + '"', "embedded DWG bridge"),
    ('window.sqOriConvertTargetToDxf', "DWG-to-DXF converter hook"),
    ("function universalTransformBytes(input,t)", "byte-preserving CAD transform"),
]:
    if token not in html:
        raise SystemExit(f"ERROR: final HTML verification failed: {label} is missing.")
if html.count('id="' + BRIDGE_ID + '"') != 1:
    raise SystemExit("ERROR: final HTML contains duplicate DWG bridge tags.")

# Apply the files only after all anchors and final checks have passed.
updated[0][0].write_text(updated[0][1], encoding="utf-8")
index_path.write_text(html, encoding="utf-8")
bridge_path.write_text(bridge, encoding="utf-8")
print("PASS: CAD text uses entity height × fit scale × board zoom, without the old fixed 5.5–15 px clamp.")
print("PASS: DWG/DXF accepted in existing and dynamically created file pickers.")
print("PASS: shared DWG-to-DXF converter is wired into file selection and drag/drop.")
print("PASS: byte-preserving CAD transform remains present; the original drawing bytes are not changed by preview zoom.")
