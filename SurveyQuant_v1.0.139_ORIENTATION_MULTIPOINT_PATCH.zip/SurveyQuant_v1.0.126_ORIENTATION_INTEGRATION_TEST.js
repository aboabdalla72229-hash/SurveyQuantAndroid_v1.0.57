'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const [referencePath,preservePath,toolsPath,indexPath]=process.argv.slice(2);
assert(referencePath&&preservePath&&toolsPath&&indexPath,'usage: test reference.js preserve.js tools.js index.html');
const enc=new TextEncoder(),dec=new TextDecoder('latin1');
function harness(){
 const listeners={};
 const document={readyState:'loading',addEventListener(n,fn){(listeners[n]||(listeners[n]=[])).push(fn);},getElementById(){return null;},querySelector(){return null;},createElement(){return {style:{},addEventListener(){},setAttribute(){}};}};
 const window={devicePixelRatio:1,__sqManualOrientation109:{parseDrawing(){return {segs:[],anchors:[],texts:[],bounds:{minX:0,minY:0,maxX:1,maxY:1},entityCount:0};},findNearestIntersection(){return null;}},__sqOrientTest:{transformBytes:null}};
 const context={window,document,Uint8Array,ArrayBuffer,DataView,TextEncoder,TextDecoder,Blob,URL,setTimeout,clearTimeout,Map,Set,Number,String,Math,Error,RegExp,Object,Array,Promise,JSON,console,Intl};
 vm.createContext(context);return {context,window,document,listeners};
}
const h=harness();
vm.runInContext(fs.readFileSync(referencePath,'utf8'),h.context,{filename:referencePath});
const core=h.window.__sqOrientation111API;
assert(core,'orientation API must load');
assert(core.nearestSnap,'OSNAP snap engine must be exposed for verification');
assert(core.solve,'two-point transform solver must be exposed');
function dxf(pairs){return enc.encode(pairs.join('\r\n')+'\r\n');}
const classic=dxf([
 '0','SECTION','2','ENTITIES',
 '0','POLYLINE','8','ROAD','66','1','70','0','10','0','20','0',
 '0','VERTEX','8','ROAD','10','1','20','2','30','0',
 '0','VERTEX','8','ROAD','10','3','20','4','30','0',
 '0','SEQEND','8','ROAD','0','ENDSEC','0','EOF'
]);
const transform=core.solve({x:0,y:0},{x:1,y:0},{x:100,y:200},{x:101,y:200});
const moved=core.transformBytes(classic,transform);
assert(moved.bytes instanceof Uint8Array,'transform outputs bytes');
const rows=dec.decode(moved.bytes).split(/\r?\n/);let vertices=[],owner='';
for(let i=0;i<rows.length-1;i+=2){const code=Number(rows[i].trim()),value=rows[i+1];if(code===0)owner=value.trim().toUpperCase();if(owner==='VERTEX'&&code===10)vertices.push({x:Number(value)});}
assert.deepEqual(vertices.map(x=>x.x),[101,103],'classic POLYLINE vertices must move, not remain behind');
assert.match(dec.decode(moved.bytes),/\r?\n101\r?\n/,'translated vertex must occur in DXF output');
// Exercise every snap path with a small deterministic drawing in screen coordinates.
const view={side:'target',canvas:{clientWidth:300,clientHeight:300,width:300,height:300},drawing:{bounds:{minX:0,minY:0,maxX:10,maxY:10},segs:[{a:{x:0,y:5},b:{x:10,y:5}},{a:{x:5,y:0},b:{x:5,y:10}}],anchors:[{x:0,y:5},{x:10,y:5},{x:5,y:0},{x:5,y:10}]},zoom:1,panX:0,panY:0};
const m=core.metrics(view),cross=core.project(view,{x:5,y:5},m);
h.window.__sqManualOrientation109.findNearestIntersection=(segs,screen,projector,tol)=>{const p=projector({x:5,y:5});return Math.hypot(p.x-screen.x,p.y-screen.y)<=tol?{point:{x:5,y:5}}:null;};
for(const mode of ['auto','intersection','endpoint','midpoint','nearest','perpendicular','free']){
 h.window.__sqOrientation111API.state.snapMode={target:mode,reference:mode};
 const screen=mode==='endpoint'?core.project(view,{x:0,y:5},core.metrics(view)):cross;
 const world=core.unproject(view,screen,core.metrics(view));
 const point=core.nearestSnap(view,world,screen);
 assert(point&&Number.isFinite(point.p.x)&&Number.isFinite(point.p.y),'snap mode '+mode+' must return a valid point');
}
// No export veto: v113 wrapper must return its transformed output even if preservation metadata changes.
h.window.__sqOrientTest.transformBytes=(input,t)=>({bytes:enc.encode('0\nSECTION\n2\nENTITIES\n0\nLINE\n8\nDIFFERENT_LAYER\n10\n999\n20\n999\n11\n1000\n21\n1000\n0\nENDSEC\n0\nEOF\n'),repairedBoundaries:3,repairedMalformedRows:1});
h.window.__sqOrientation111API.transformBytes=(input,t)=>h.window.__sqOrientTest.transformBytes(input,t);
h.window.__sqOrientation112API={transformBytes:input=>h.window.__sqOrientTest.transformBytes(input)};
h.window.__sqManualOrientation109.parseDrawing=()=>({segs:[],anchors:[],texts:[],bounds:{minX:0,minY:0,maxX:1,maxY:1},entityCount:1});
h.window.__sqOrientation111API.splitPairs=()=>({pairs:[],bytes:new Uint8Array()});
h.window.__sqOrientation111API.sectionRecords=()=>[];
h.window.__sqOrientation111API.blockDefinitions=()=>new Map();
h.window.__sqOrientation111API.geometryInWorld=()=>({pts:[],segments:[],texts:[]});
vm.runInContext(fs.readFileSync(preservePath,'utf8'),h.context,{filename:preservePath});
const passthrough=h.window.__sqOrientation113API.transformBytes(classic,transform);
assert(passthrough.bytes&&passthrough.bytes.length>0,'export wrapper must never veto an available generated file');
assert(passthrough.v115Diagnostics&&passthrough.v115Diagnostics.recoveredBoundaries===3,'preservation differences must be diagnostics only');
// Check feature wiring, writer-enabled engine URL and no injected v114 veto handler.
const index=fs.readFileSync(indexPath,'utf8');
for(const needle of ['SQ_WRITER_ENGINE_URL','libredwg-writer/dist/libredwg-web.js','const SQ_APP_VERSION_CODE = 126;','height:230px;min-height:230px;max-height:230px','sq110TZoomRange','sq110TSnapMode','sq110ReadAxesBtn','window.__sqOrientation115Tools'])assert(index.includes(needle),'missing integration '+needle);
assert(!index.includes('auditDxfPreservation(source, transformed)'), 'the v114 hard-veto auditor must not be used');
vm.runInContext(fs.readFileSync(toolsPath,'utf8'),h.context,{filename:toolsPath});
console.log('PASS v115: classic POLYLINE geometry transforms; seven snap modes; OSNAP exposure; export audit is diagnostic-only; writer engine and live auto-axes UI are integrated.');
