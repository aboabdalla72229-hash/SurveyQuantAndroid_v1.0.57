# SurveyQuant V1.0.147 automated test results

Status: PASS for the listed automated source/fixture tests. This is not a claim that the user's unavailable original DWG/DXF was validated or that a newly signed APK has already been built.

## Root-cause regression tests

- PASS: HATCH line/arc/ellipse/spline boundary coordinates transform together; no origin/end-point mismatch that produces long diagonal streaks.
- PASS: HATCH header elevation/origin is not mistaken for a world boundary vertex; pattern base/offset remain local vectors and are rotated/scaled without world translation.
- PASS: Circular arc radius and angles, ellipse major-axis vector, spline fit/tangent data, and seed points follow their respective DXF semantics.
- PASS: Four LINE entities recover one closed footprint, area 10000.
- PASS: Layer-name normalization and canonical polygon deduplication.
- PASS: closed LWPOLYLINE/POLYLINE records can be recovered from raw DXF records.
- PASS: closed outline inside INSERT handles base point, insertion point, rotation, XY scale, and inherited layer; fixture area is 200 after insert transform.
- PASS: layer picker reports closed-boundary counts and can choose a layer with valid outlines.

## Existing regression coverage

- PASS: 24000 LINE entities (1725900 input bytes) remain 24000 after byte-level DXF transformation; memory-aware preview path, single-allocation writer and streaming validation are present.
- PASS: V130 shared DWG parser, output validation, INSERT text transform, selection and deletion preservation tests.
- PASS: V130 orientation engine, two-point transformation, supported XData, entity count, EOF and ordinary OCS handling.
- PASS: alignment safety, Model/Paper space consistency, opaque proxy guard, and overlay preflight tests.
- PASS: tilted OCS CIRCLE/TEXT round-trip to expected WCS coordinates and 3D LINE scaling.
- PASS: axis labels in nested INSERT and top-level TEXT are found and positioned in WCS.
- PASS: MULTILEADER transform matches ezdxf 1.4.4 oracle for placement, scale, rotation, vectors, leader lines, matrix, layer and XData.
- PASS: 10 inline JavaScript blocks parse with `node --check`.
- PASS: Python patcher and APK packager compile; packaged source retains the local DWG WASM asset in its explicit checks.

## Remaining validation

- Not run: GitHub Actions V147 signed build (requires the repository workflow and signing secrets).
- Not run: visual/quantity validation against the exact original source/target files from the user's screenshots. Those files were not attached; only screenshots were supplied.
- DXF recovery handles well-formed closed polylines, closed loops of lines, and readable closed outlines within INSERT. Opaque Civil 3D/Proxy/Solid payloads still require native CAD conversion because their actual geometry may not be represented in plain DXF records.
