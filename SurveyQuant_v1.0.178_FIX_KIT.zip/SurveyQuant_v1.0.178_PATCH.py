#!/usr/bin/env python3
"""Install the V178 orientation capture and Android-native save fix into V177 HTML."""
from pathlib import Path
import argparse, re

MARKER = '<!-- SURVEYQUANT_V178_ORIENTATION_CAPTURE_AND_NATIVE_SAVE_FIX -->'
REQUIRED = [
    'SQ_V178_ORIENTATION_CAPTURE_AND_NATIVE_SAVE',
    'root.Android',
    'native.saveFile(filename,mime,base64)',
    'native.startChunkedFile',
    'native.finishChunkedFile',
    'cadFingerprint',
    'boardFileName',
    'createOrientedDxfBytes(src.bytes,alignment.picks)',
    'if(!out?.bytes?.length||!Number(out.editCount))',
    'تم إرسال الملف إلى Downloads/SurveyQuant',
]

def patch_html(html_path: Path, engine_path: Path, check=False):
    html = html_path.read_text(encoding='utf-8')
    engine = engine_path.read_text(encoding='utf-8')
    missing = [v for v in REQUIRED if v not in engine]
    if missing:
        raise SystemExit('V178 engine missing required fix markers: ' + ', '.join(missing))
    if MARKER in html:
        if not check:
            raise SystemExit('V178 patch already applied')
        missing = [v for v in REQUIRED if v not in html]
        if missing:
            raise SystemExit('V178 marker exists but required engine code is missing: ' + ', '.join(missing))
        print('PASS V178 HTML check-only: orientation provenance and Android save fix are embedded')
        return
    if 'SURVEYQUANT_V177_SINGLE_READ_CANVAS_ID_AND_DXF_R12_FIX' not in html:
        raise SystemExit('V177 base patch marker missing; apply V176 and V177 patches first')
    pattern = r'(<script\s+id=["\']sq176-cad-engine["\']\s*>)[\s\S]*?(</script\s*>)'
    hits = list(re.finditer(pattern, html, re.I))
    if len(hits) != 1:
        raise SystemExit(f'Expected exactly one embedded CAD engine, found {len(hits)}')
    m = hits[0]
    replacement = m.group(1) + '\n' + engine.replace('</script>', '<\\/script>') + '\n' + m.group(2)
    html = html[:m.start()] + replacement + html[m.end():]
    html += '\n' + MARKER + '\n<!-- V178: ordered board-specific point provenance; nonzero CAD transform verification; direct Android save accepts Java void-return; reopens and audits generated DXF. -->\n'
    html_path.write_text(html, encoding='utf-8')
    print(f'PASS V178 patch applied: {len(html):,} HTML characters')

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--html', type=Path, required=True)
    p.add_argument('--engine', type=Path, required=True)
    p.add_argument('--check-only', action='store_true')
    a = p.parse_args()
    patch_html(a.html, a.engine, a.check_only)

if __name__ == '__main__':
    main()
