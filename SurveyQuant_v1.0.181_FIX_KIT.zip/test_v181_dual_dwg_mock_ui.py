"""UI branch test for two .dwg uploads. The DWG conversion worker is mocked;
this validates the dual-DWG route/merge handoff, not LibreDWG decoding itself."""
from pathlib import Path
import os, shutil, base64
from playwright.sync_api import sync_playwright
import ezdxf
root=Path(__file__).resolve().parent
html=(root/'index.html').read_text(encoding='utf-8')
# Valid DXF payloads are renamed .dwg and fed through a deterministic parseFile
# stub. Real DWG header/LibreDWG conversion is explicitly outside this mock.
source=root/'source_A.dxf'; target=root/'target_B.dxf'
with sync_playwright() as p:
    exe=os.environ.get('CHROMIUM_BIN') or shutil.which('chromium') or shutil.which('chromium-browser')
    b=p.chromium.launch(executable_path=exe,headless=True,args=['--no-sandbox','--allow-file-access-from-files'])
    page=b.new_page(viewport={'width':430,'height':900})
    page.set_content(html,wait_until='domcontentloaded',timeout=90000)
    page.evaluate("""()=>{
      window.__nativeSaved=null;window.prompt=(message,defaultValue)=>defaultValue;
      window.Android={saveFile:(filename,mime,base64)=>window.__nativeSaved={filename,mime,base64}};
      const original=window.parseFile;
      window.__v181OriginalParseFile=original;
      window.parseFile=async(file,options={})=>{
        if(/\\.dwg$/i.test(file.name)) return {source:'DWG',convertedFromDWG:true,rawDXFBytes:new Uint8Array(await file.arrayBuffer()),entities:[],layers:new Map(),points:[],segments:[],polylines:[]};
        return original(file,options);
      };
    }""")
    page.locator('button[onclick="openProjectPage(\'dropFilesCard\')"]').click()
    page.locator('#dropSurveyFiles').set_input_files({'name':'source_mock.dwg','mimeType':'application/octet-stream','buffer':source.read_bytes()})
    page.locator('#dropCadFile').set_input_files({'name':'target_mock.dwg','mimeType':'application/octet-stream','buffer':target.read_bytes()})
    page.locator('button[onclick="dropFilesMerge()"]:visible').click()
    page.wait_for_function("document.getElementById('dropFilesResults').style.display==='block'",timeout=30000)
    summary=page.locator('#dropFilesSummary').inner_text()
    assert 'source_mock.dwg' in summary and 'target_mock.dwg' in summary,summary
    page.evaluate('downloadDroppedDXF()')
    page.wait_for_function('window.__nativeSaved!==null',timeout=10000)
    saved=page.evaluate('window.__nativeSaved')
    out=root/'V181_TWO_DWG_MOCK_MERGE_UI_TEST.dxf';out.write_bytes(base64.b64decode(saved['base64']))
    doc=ezdxf.readfile(out);audit=doc.audit()
    assert not audit.errors and not audit.fixes,(audit.errors,audit.fixes)
    assert len(doc.modelspace().query('LINE'))>=2 and len(doc.modelspace().query('POLYLINE'))>=2
    print({'mocked_source':'source_mock.dwg','mocked_target':'target_mock.dwg','merged_entities':len(doc.modelspace()),'audit_errors':len(audit.errors),'result':'PASS (mocked DWG conversion path only)'})
    b.close()
