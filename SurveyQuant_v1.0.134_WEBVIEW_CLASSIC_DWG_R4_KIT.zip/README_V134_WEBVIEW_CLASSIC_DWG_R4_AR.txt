SurveyQuant v1.0.134 R4: WebView classic DWG output-name fix

سبب فشل R3: Vite 5.4.15 ينتج libredwg-web.iife.js عندما يُطلب تنسيق IIFE، بينما كانت خطوة البناء تبحث عن libredwg-web.js.

الرفع إلى:
.github/workflows/build-v134-webview-classic-dwg-r4.yml

ثم شغّل:
Build SurveyQuant v1.0.134 - Android WebView classic DWG runtime R4

لا ترفع ملف التصحيح منفصلًا؛ فهو مضمّن داخل الـWorkflow.

تم التحقق محليًا من YAML وكتل Bash، ومن خطوة تطبيع اسم IIFE. لم يتم تشغيل بناء GitHub الكامل أو إصدار APK R4 بعد.
