'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const CAD = require('./SurveyQuant_v1.0.162_CAD_ENGINE.js');
const close = (a,b,eps=1e-6) => assert.ok(Math.abs(a-b) < eps, `${a} != ${b}`);
const parsePairs = text => {
  const lines = text.replace(/\r/g, '').split('\n');
  const pairs = [];
  for (let i=0; i+1<lines.length; i+=2) pairs.push([Number(lines[i].trim()), lines[i+1].trim()]);
  return pairs;
};
const entity = (pairs, type, occurrence=0) => {
  let seen=-1, active=false, out=[];
  for (const p of pairs) {
    if (p[0]===0) {
      if (active) return out;
      if (p[1].toUpperCase()===type.toUpperCase() && ++seen===occurrence) { active=true; out=[]; }
    } else if (active) out.push(p);
  }
  return out;
};
const v = (pairs, code) => pairs.filter(p=>p[0]===code).map(p=>Number(p[1]));

// Two-point similarity: source -> directed reference.
const tr = CAD.solve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
close(tr.scale,2); close(tr.rotationDegrees,90); close(tr.translationX,100); close(tr.translationY,200);
close(tr.residualA,0); close(tr.residualB,0);
const mapped = tr.apply({x:2,y:3}); close(mapped.x,94); close(mapped.y,204);

// Verify the actual DXF edit changes coordinates but does not redraw entity types,
// handles, layer names, bulges, text content, lineweight or other CAD metadata.
const fixture = [
  '0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','0','ENDSEC',
  '0','SECTION','2','TABLES','0','TABLE','2','LAYER','5','F','330','0','100','AcDbSymbolTable','70','1','0','LAYER','5','10','330','F','100','AcDbSymbolTableRecord','100','AcDbLayerTableRecord','2','ROADS','70','0','62','1','6','CONTINUOUS','0','ENDTAB','0','ENDSEC',
  '0','SECTION','2','ENTITIES',
  '0','LINE','5','20','8','ROADS','370','50','10','0','20','0','30','0','11','10','21','0','31','0',
  '0','CIRCLE','5','21','8','ROADS','10','1','20','2','30','0','40','3',
  '0','ARC','5','22','8','ROADS','10','1','20','2','40','3','50','0','51','90',
  '0','LWPOLYLINE','5','23','100','AcDbEntity','8','ROADS','100','AcDbPolyline','90','2','70','0','10','0','20','0','42','0.414213562373095','10','10','20','0','42','0',
  '0','RAY','5','24','8','ROADS','10','0','20','0','11','1','21','0',
  '0','XLINE','5','25','8','ROADS','10','0','20','0','11','1','21','0',
  '0','TEXT','5','26','8','ROADS','10','1','20','1','40','2','1','AXIS A',
  '0','ENDSEC','0','EOF',''
].join('\r\n');
const input = new TextEncoder().encode(fixture);
const result = CAD.transformDxfBytes(input,{x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
const output = new TextDecoder('windows-1252').decode(result.bytes);
fs.writeFileSync(process.env.SQ163_ALIGNED_DXF_TEST || '/tmp/sq163_aligned_test.dxf', result.bytes);
const pairs = parsePairs(output);
assert.ok(output.includes('0\r\nLINE\r\n5\r\n20'), 'LINE entity handle retained');
assert.ok(output.includes('8\r\nROADS') && output.includes('1\r\nAXIS A'), 'layer names and text retained');
assert.ok(output.includes('370\r\n50'), 'explicit lineweight retained');
const line = entity(pairs,'LINE'); close(v(line,10)[0],100); close(v(line,20)[0],200); close(v(line,11)[0],100); close(v(line,21)[0],220);
const circle=entity(pairs,'CIRCLE'); close(v(circle,10)[0],96); close(v(circle,20)[0],202); close(v(circle,40)[0],6);
const arc=entity(pairs,'ARC'); close(v(arc,10)[0],96); close(v(arc,20)[0],202); close(v(arc,40)[0],6); close(v(arc,50)[0],90); close(v(arc,51)[0],180);
const lw=entity(pairs,'LWPOLYLINE'); close(v(lw,10)[0],100); close(v(lw,20)[0],200); close(v(lw,10)[1],100); close(v(lw,20)[1],220); close(v(lw,42)[0],0.414213562373095);
for (const kind of ['RAY','XLINE']) { const a=entity(pairs,kind); close(v(a,10)[0],100); close(v(a,20)[0],200); close(v(a,11)[0],0); close(v(a,21)[0],2); }
close(result.translationX,100); close(result.translationY,200);
assert.ok(result.editCount >= 25, 'coordinates, radii and angles are changed in-place');

// Preview tessellates the LWPOLYLINE bulge as a curve, not a straight chord.
const geometry = CAD.readGeometry(new TextEncoder().encode([
  '0','SECTION','2','ENTITIES',
  '0','LWPOLYLINE','90','2','70','0','10','0','20','0','42','0.414213562373095','10','10','20','0','42','0',
  '0','ENDSEC','0','EOF',''
].join('\r\n')));
assert.ok(geometry.segments.length > 2, 'bulged polyline preview contains arc segments');
assert.ok(geometry.minY < -1, 'bulged arc has its true curved extent rather than a flat chord');

// DXF image-underlay output is valid AC1015 and retains a relative PNG filename.
const imgBytes = CAD.imageReferenceDxf('plan_page_1.png',1600,900,0.25);
const imgText = new TextDecoder().decode(imgBytes);
assert.ok(imgText.includes('1\r\nplan_page_1.png'), 'relative sidecar name appears in IMAGEDEF');
assert.ok(imgText.includes('0\r\nIMAGE\r\n'), 'one native DXF IMAGE entity is written');
assert.ok(imgText.includes('1\r\nAC1015'), 'R2000-compatible DXF version is written');
const imgPath = process.env.SQ163_IMAGE_DXF_TEST || '/tmp/sq163_pdf_underlay_test.dxf';
fs.writeFileSync(imgPath,imgBytes);
let degenerate=false;
try { CAD.solve({x:1,y:1},{x:1,y:1},{x:0,y:0},{x:2,y:2}); } catch (_) { degenerate=true; }
assert.ok(degenerate,'coincident control points are rejected');
console.log('PASS V163 CAD tests: exact two-point similarity metrics; in-place LINE/CIRCLE/ARC/LWPOLYLINE/RAY/XLINE transformation; bulge-curve preview; layer/handle/lineweight/text retention; valid raster IMAGE DXF.');
