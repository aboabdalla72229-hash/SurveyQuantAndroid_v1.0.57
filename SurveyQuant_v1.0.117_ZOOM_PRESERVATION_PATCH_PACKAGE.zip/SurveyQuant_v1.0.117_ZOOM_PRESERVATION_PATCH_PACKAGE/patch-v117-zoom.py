from pathlib import Path
import sys

module_path, index_path = map(Path, sys.argv[1:])
pairs = [
  ("v.zoom=Math.max(.1584893,Math.min(1000,Number(value)||1));",
   "v.zoom=Math.max(.1584893,Math.min(1000000,Number(value)||1));", 1, "slider/button zoom limit"),
  ("v.zoom=Math.max(.15,Math.min(1000,v.pinch.zoom*distance/v.pinch.distance));",
   "v.zoom=Math.max(.15,Math.min(1000000,v.pinch.zoom*distance/v.pinch.distance));const slider=el(v.side==='target'?'sq110TZoomRange':'sq110RZoomRange');if(slider)slider.value=String(Math.log10(v.zoom));", 1, "pinch zoom limit and slider sync"),
  ("v.zoom=Math.max(.15,Math.min(1000,v.zoom*(e.deltaY<0?1.2:1/1.2)));",
   "v.zoom=Math.max(.15,Math.min(1000000,v.zoom*(e.deltaY<0?1.2:1/1.2)));const slider=el(v.side==='target'?'sq110TZoomRange':'sq110RZoomRange');if(slider)slider.value=String(Math.log10(v.zoom));", 1, "wheel zoom limit and slider sync"),
  ('max="3" step="0.01" value="0" aria-label="تكبير اللوحة حتى 1000 مرة"',
   'max="6" step="0.01" value="0" aria-label="تكبير اللوحة حتى 1,000,000 مرة"', 2, "logarithmic slider range"),
  ("تكبير ×5</button>", "تكبير ×10</button>", 2, "zoom boost label"),
  ("v.zoom*5);});el('sq110'+prefix+'ZoomRange'", "v.zoom*10);});el('sq110'+prefix+'ZoomRange'", 1, "zoom boost factor"),
]
for path in (module_path, index_path):
    text = path.read_text(encoding="utf-8")
    for old, new, expected, label in pairs:
        count = text.count(old)
        if count != expected:
            raise SystemExit(f"ERROR: {path.name}: expected {expected} matches for {label}, found {count}")
        text = text.replace(old, new)
    for forbidden in (
        "Math.min(1000,Number(value)||1)",
        "Math.min(1000,v.pinch.zoom*distance/v.pinch.distance)",
        "Math.min(1000,v.zoom*(e.deltaY<0?1.2:1/1.2))",
        'max="3" step="0.01" value="0" aria-label="تكبير اللوحة حتى 1000 مرة"',
    ):
        if forbidden in text:
            raise SystemExit(f"ERROR: old zoom limit remains in {path.name}: {forbidden}")
    path.write_text(text, encoding="utf-8")
print("PASS v117: zoom cap is 1,000,000x, slider has six logarithmic decades, ×10 boost works, and zoom stays view-only.")
