(function () {
  'use strict';
  if (window.__SQ_V121_DWG_BRIDGE__) return;
  window.__SQ_V121_DWG_BRIDGE__ = true;

  var MIME = 'application/dxf';
  var ACCEPT_TYPES = [
    '.dwg', '.dxf', 'application/dwg', 'application/x-dwg',
    'application/dxf', 'application/x-dxf', 'application/acad',
    'application/x-acad', 'image/vnd.dwg'
  ];

  function asDxfFile(result, sourceFile) {
    if (result && result.ok === false) {
      throw new Error(result.error || result.message || 'تعذر تحويل ملف DWG.');
    }

    var value = result;
    if (value && typeof value === 'object' &&
        !(typeof Blob === 'function' && value instanceof Blob) &&
        !(typeof File === 'function' && value instanceof File) &&
        !(value instanceof ArrayBuffer) && !ArrayBuffer.isView(value) &&
        !Array.isArray(value)) {
      var keys = ['file', 'blob', 'bytes', 'dxfBytes', 'data', 'output', 'text', 'dxf', 'content', 'buffer'];
      for (var i = 0; i < keys.length; i++) {
        if (value[keys[i]] != null) { value = value[keys[i]]; break; }
      }
    }

    var sourceName = String(sourceFile && sourceFile.name || 'drawing.dwg');
    var name = sourceName.replace(/\.dwg$/i, '.dxf');
    if (!/\.dxf$/i.test(name)) name += '.dxf';

    if (typeof File === 'function' && value instanceof File) {
      return new File([value], name, { type: MIME, lastModified: Date.now() });
    }
    if (typeof Blob === 'function' && value instanceof Blob) {
      if (!value.size) throw new Error('ملف DXF الناتج فارغ.');
      return new File([value], name, { type: MIME, lastModified: Date.now() });
    }
    if (typeof value === 'string') {
      if (!value.trim() || !/(SECTION|ENTITIES|HEADER|EOF)/i.test(value)) {
        throw new Error('المحوّل لم يُرجع ملف DXF نصيًا صالحًا.');
      }
      return new File([value], name, { type: MIME, lastModified: Date.now() });
    }
    if (Array.isArray(value)) value = new Uint8Array(value);
    if (value instanceof ArrayBuffer || ArrayBuffer.isView(value)) {
      if (!value.byteLength) throw new Error('ملف DXF الناتج فارغ.');
      return new File([value], name, { type: MIME, lastModified: Date.now() });
    }
    throw new Error('صيغة نتيجة محوّل DWG غير معروفة.');
  }

  function getConverter() {
    if (typeof window.sqOriConvertTargetToDxf === 'function') return window.sqOriConvertTargetToDxf;
    var apis = [window.__sqOrientation115Tools, window.__sqOrientation113API, window.__sqOrientation111API];
    var names = ['sqOriConvertTargetToDxf', 'convertTargetToDxf', 'convertDwgToDxf', 'dwgToDxf'];
    for (var a = 0; a < apis.length; a++) {
      var api = apis[a];
      if (!api) continue;
      for (var i = 0; i < names.length; i++) {
        if (typeof api[names[i]] === 'function') return api[names[i]].bind(api);
      }
    }
    return null;
  }

  async function convertOne(file) {
    var converter = getConverter();
    if (!converter) throw new Error('محوّل DWG غير متاح في هذه الشاشة. لم يتم تعديل الملف الأصلي.');
    return asDxfFile(await converter(file), file);
  }

  async function convertList(files) {
    var result = [];
    for (var i = 0; i < files.length; i++) {
      result.push(/\.dwg$/i.test(String(files[i] && files[i].name || '')) ? await convertOne(files[i]) : files[i]);
    }
    return result;
  }

  function addAcceptedTypes(input) {
    if (!input || String(input.tagName || '').toLowerCase() !== 'input' ||
        String(input.type || '').toLowerCase() !== 'file') return;
    var current = String(input.accept || '').split(',').map(function (item) {
      return item.trim();
    }).filter(Boolean);
    ACCEPT_TYPES.forEach(function (item) {
      if (!current.some(function (existing) { return existing.toLowerCase() === item.toLowerCase(); })) {
        current.push(item);
      }
    });
    input.accept = current.join(',');
  }

  function scanInputs(root) {
    if (!root) return;
    if (root.nodeType === 1) addAcceptedTypes(root);
    if (typeof root.querySelectorAll === 'function') {
      root.querySelectorAll('input[type="file"]').forEach(addAcceptedTypes);
    }
  }

  function makeDataTransfer(files) {
    if (typeof DataTransfer !== 'function') throw new Error('هذا المتصفح لا يدعم تجهيز قائمة الملفات المحوّلة.');
    var transfer = new DataTransfer();
    files.forEach(function (file) { transfer.items.add(file); });
    return transfer;
  }

  scanInputs(document);
  if (typeof MutationObserver === 'function' && document.documentElement) {
    new MutationObserver(function (records) {
      records.forEach(function (record) {
        (record.addedNodes || []).forEach(scanInputs);
      });
    }).observe(document.documentElement, { childList: true, subtree: true });
  }

  document.addEventListener('change', function (event) {
    var input = event.target;
    if (!input || String(input.tagName || '').toLowerCase() !== 'input' ||
        String(input.type || '').toLowerCase() !== 'file') return;
    var files = Array.prototype.slice.call(input.files || []);
    if (!files.some(function (file) { return /\.dwg$/i.test(file.name || ''); }) || input.__sqV121DwgBusy) return;

    event.preventDefault();
    event.stopImmediatePropagation();
    input.__sqV121DwgBusy = true;
    convertList(files).then(function (converted) {
      input.files = makeDataTransfer(converted).files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    }).catch(function (error) {
      console.error('[SurveyQuant V121] DWG import failed:', error);
      input.value = '';
      alert('تعذر قراءة ملف DWG. تأكد من سلامة الملف ثم أعد المحاولة.\n' + String(error && error.message || error));
    }).finally(function () {
      input.__sqV121DwgBusy = false;
    });
  }, true);

  document.addEventListener('drop', function (event) {
    var data = event.dataTransfer;
    var files = data ? Array.prototype.slice.call(data.files || []) : [];
    if (!files.some(function (file) { return /\.dwg$/i.test(file.name || ''); })) return;

    event.preventDefault();
    event.stopImmediatePropagation();
    convertList(files).then(function (converted) {
      var transfer = makeDataTransfer(converted);
      var synthetic;
      if (typeof DragEvent === 'function') {
        synthetic = new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: transfer });
      } else {
        synthetic = new Event('drop', { bubbles: true, cancelable: true });
        Object.defineProperty(synthetic, 'dataTransfer', { value: transfer });
      }
      event.target.dispatchEvent(synthetic);
    }).catch(function (error) {
      console.error('[SurveyQuant V121] dropped DWG import failed:', error);
      alert('تعذر تحويل ملف DWG. ' + String(error && error.message || error));
    });
  }, true);

  window.__sqV121DwgBridgeAPI = { asDxfFile: asDxfFile, convertOne: convertOne, scanInputs: scanInputs };
})();
