'use strict';
const assert=require('node:assert/strict');
const CAD=require('./SurveyQuant_v1.0.165_CAD_ENGINE.js');
const close=(a,b,e=1e-6)=>assert.ok(Math.abs(a-b)<=e,`${a} != ${b}`);
const enc=s=>new TextEncoder().encode(s);
const dec=b=>new TextDecoder('windows-1252').decode(b);

// Exact two-point similarity solution.
const tr=CAD.solve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
close(tr.scale,2);close(tr.rotationDegrees,90);

// Real DXF entities, including native ARC, CIRCLE, bulged LWPOLYLINE, ELLIPSE,
// SPLINE, TEXT/MTEXT, INSERT array spacing, HATCH angles and style tables.
const fixture=[
'0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','9','$LTSCALE','40','2','0','ENDSEC',
'0','SECTION','2','TABLES',
'0','TABLE','2','LAYER','70','1','0','LAYER','5','10','2','0','70','0','62','3','420','65280','6','CONTINUOUS','0','ENDTAB',
'0','TABLE','2','STYLE','70','1','0','STYLE','5','11','2','AXIS_STYLE','40','2','41','1','50','0','71','0','42','2','3','txt.shx','0','ENDTAB',
'0','TABLE','2','DIMSTYLE','70','1','0','DIMSTYLE','105','12','2','STANDARD','140','2','141','1','147','0.5','0','ENDTAB',
'0','TABLE','2','LTYPE','70','1','0','LTYPE','5','13','2','DASHED','49','0.5','49','-0.25','0','ENDTAB','0','ENDSEC',
'0','SECTION','2','ENTITIES',
'0','ARC','5','20','8','0','62','1','420','16711680','10','1','20','2','30','0','40','2','50','0','51','90',
'0','CIRCLE','5','21','8','0','10','3','20','4','40','5',
'0','LWPOLYLINE','5','22','8','0','90','3','70','1','10','0','20','0','42','0.41421356237','10','10','20','0','42','0','10','10','20','10','42','0',
'0','ELLIPSE','5','23','8','0','10','5','20','5','11','5','21','0','40','0.5','41','0','42','6.283185307',
'0','SPLINE','5','24','8','0','70','8','71','3','72','0','73','3','74','0','10','0','20','0','10','5','20','5','10','10','20','0',
'0','TEXT','5','25','8','0','7','AXIS_STYLE','10','4','20','5','40','0','41','0.7','50','0','1','GRID-A',
'0','MTEXT','5','26','8','0','10','6','20','6','11','1','21','0','40','2','41','8','50','0','1','GRID-B',
'0','INSERT','5','27','8','0','2','AXIS_BLOCK','10','10','20','20','41','2','42','3','43','1','44','4','45','5','50','30','70','2','71','1',
'0','HATCH','5','28','8','0','49','0.5','50','15','52','30','53','45',
'0','ENDSEC','0','EOF',''
].join('\r\n');
const input=enc(fixture),aligned=CAD.transformDxfBytes(input,{x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220}),out=dec(aligned.bytes);
assert.equal(aligned.mode,'raw-dxf-record-transform');
// Preserve original CAD entity types: no curve becomes a LINE or a reconstructed polyline.
const entityTypes=s=>{let section='',need=false,out=[];for(const [i,line] of s.split(/\r?\n/).entries()){if(i%2!==0)continue;const code=Number(line.trim()),value=(s.split(/\r?\n/)[i+1]||'').trim();if(need&&code===2){section=value.toUpperCase();need=false;continue;}if(code===0&&value==='SECTION'){need=true;continue;}if(code===0&&value==='ENDSEC'){section='';continue;}if(code===0&&section==='ENTITIES'&&value!=='EOF')out.push(value.toUpperCase());}return out;};
assert.deepEqual(entityTypes(out),entityTypes(fixture));
assert.match(out,/0\r\nARC\r\n/);assert.match(out,/0\r\nCIRCLE\r\n/);assert.match(out,/0\r\nLWPOLYLINE\r\n/);assert.match(out,/0\r\nELLIPSE\r\n/);assert.match(out,/0\r\nSPLINE\r\n/);
// ARC center/radius/angles are transformed mathematically, not flattened into lines.
assert.match(out,/10\r\n96\r\n20\r\n202\r\n30\r\n0\r\n40\r\n4\r\n50\r\n90\r\n51\r\n180/);
// Bulge is invariant under rotation + uniform scaling, while original group 42 remains.
assert.match(out,/42\r\n0\.41421356237/);
assert.match(out,/62\r\n1\r\n420\r\n16711680/,'entity ACI and true-colour values are preserved exactly');
assert.match(out,/62\r\n3\r\n420\r\n65280/,'LAYER ACI and true-colour values are preserved exactly');
// Ellipse major-axis vector rotates/scales, ratio and parameter range remain unchanged.
assert.match(out,/11\r\n0\r\n21\r\n10/);assert.match(out,/40\r\n0\.5/);
// Text height from fixed STYLE table is scaled. Entity width factor is dimensionless and stays 0.7.
assert.match(out,/40\r\n0\r\n41\r\n0\.7/);assert.match(out,/40\r\n4\r\n41\r\n16/);
assert.match(out,/2\r\nAXIS_STYLE\r\n40\r\n4/);
assert.match(out,/140\r\n4/);assert.match(out,/49\r\n1/);assert.match(out,/49\r\n-0\.5/);
assert.match(out,/\$LTSCALE\r\n40\r\n4/);
assert.match(out,/41\r\n4\r\n42\r\n6\r\n43\r\n2\r\n44\r\n8\r\n45\r\n10/);
assert.match(out,/49\r\n1\r\n50\r\n105\r\n52\r\n120\r\n53\r\n135/);
assert.ok(aligned.editCount>=30,'raw DXF numeric fields are edited in place');

// Geometry preview reads native arcs and bulges as curves, retains their sample geometry for snaps,
// reads fixed-height style text, and expands XLINE/RAY for viewport snapping only.
const geomFixture=[
'0','SECTION','2','HEADER','9','$TEXTSIZE','40','3','0','ENDSEC',
'0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','1','0','LAYER','2','GRID_GREEN','62','3','420','65280','0','ENDTAB','0','TABLE','2','STYLE','70','1','0','STYLE','2','AXIS_STYLE','40','2','0','ENDTAB','0','ENDSEC',
'0','SECTION','2','ENTITIES',
'0','ARC','10','0','20','0','40','10','50','0','51','90',
'0','CIRCLE','10','20','20','20','40','5',
'0','LWPOLYLINE','90','2','70','0','10','30','20','0','42','0.41421356237','10','40','20','0','42','0',
'0','LINE','10','-10','20','0','11','10','21','0',
'0','LINE','10','0','20','-10','11','0','21','10',
'0','XLINE','10','0','20','0','11','1','21','1',
'0','SPLINE','70','8','71','3','72','0','73','3','74','0','10','0','20','0','10','5','20','5','10','10','20','0',
'0','TEXT','7','AXIS_STYLE','10','5','20','5','40','0','1','A1',
'0','TEXT','10','-5','20','-5','40','0','1','DEFAULT-SIZE',
'0','TEXT','8','GRID_GREEN','10','-8','20','-8','40','1','1','GREEN-AXIS',
'0','ENDSEC','0','EOF',''
].join('\n');
const geom=CAD.readGeometry(enc(geomFixture));
assert.ok(geom.curves.length>=3,'ARC, CIRCLE and bulged polyline retained as curve preview data');
assert.ok(geom.curves.find(c=>c.type==='arc')?.points?.length>300,'ARC preview keeps dense analytic curve samples');
assert.ok(geom.curves.some(c=>c.type==='spline'&&c.points.length>20),'SPLINE preview uses a smooth curve rather than straight chords');
assert.ok(geom.segments.some(s=>s.isCurveSegment),'curved display/snap tessellation is explicitly distinguished');
assert.ok(geom.segments.length>200,'curve preview geometry is dense enough for intersection snapping');
assert.ok(geom.segments.some(s=>s.a.x!==s.b.x||s.a.y!==s.b.y),'XLINE was expanded for viewport only');
assert.equal(geom.texts.find(t=>t.text==='A1').height,2,'fixed STYLE text height used when entity height is zero');
assert.equal(geom.texts.find(t=>t.text==='DEFAULT-SIZE').height,3,'$TEXTSIZE supplies a drawing-based height when STYLE has no fixed height');
assert.equal(geom.texts.find(t=>t.text==='GREEN-AXIS').color,'#00ff00','BYLAYER axis label inherits true color from the LAYER table');

// Intersection snap no longer truncates at 48 nearby fragments; the real crossing survives
// even when more than 48 decoy fragments are nearer to the cursor.
const dense={segments:[],points:[],texts:[]};
for(let i=0;i<70;i++){const y=0.001*i;dense.segments.push({a:{x:-1,y},b:{x:1,y}});}
dense.segments.push({a:{x:0.3,y:-1},b:{x:0.3,y:1}},{a:{x:-1,y:0.3},b:{x:1,y:0.3}});
const isnap=CAD.snapPoint(dense,{x:0.31,y:0.31},'intersection',0.5);
assert.equal(isnap.type,'intersection');close(isnap.point.x,0.3);close(isnap.point.y,0.3);
const arcGeom=CAD.readGeometry(enc(geomFixture));const arcSnap=CAD.snapPoint(arcGeom,{x:7.07,y:7.07},'intersection',0.3);assert.ok(arcSnap,'arc snap returns a candidate');
const exactArc={segments:[{a:{x:-10,y:Math.sqrt(50)},b:{x:10,y:Math.sqrt(50)},isCurveSegment:false}],points:[],curves:[{type:'arc',center:{x:0,y:0},radius:10,start:0,sweep:Math.PI/2}]};
const exactArcHit=CAD.snapPoint(exactArc,{x:7.05,y:7.08},'intersection',0.2);assert.equal(exactArcHit.type,'intersection','snap finds exact line/circular-arc intersection rather than chord approximation');close(exactArcHit.point.x,Math.sqrt(50),1e-7);close(exactArcHit.point.y,Math.sqrt(50),1e-7);
const tangentArc={segments:[{a:{x:-10,y:10},b:{x:10,y:10}}],points:[],curves:[{type:'circle',center:{x:0,y:0},radius:10,start:0,sweep:Math.PI*2}]};const tangentHit=CAD.snapPoint(tangentArc,{x:0,y:10},'intersection',.1);assert.equal(tangentHit.type,'intersection','tangent contact between line and circle is detected');close(tangentHit.point.x,0);close(tangentHit.point.y,10);

// Curves inside BLOCK definitions must stay curves in the preview after INSERT rotation/scale.
const blockFixture=['0','SECTION','2','BLOCKS','0','BLOCK','2','AXIS_CURVE','10','0','20','0','0','ARC','10','0','20','0','40','10','50','0','51','90','0','TEXT','10','5','20','0','40','2','1','AXIS-LABEL','0','ENDBLK','0','ENDSEC','0','SECTION','2','ENTITIES','0','INSERT','2','AXIS_CURVE','10','100','20','50','41','2','42','1','50','45','0','ENDSEC','0','EOF',''].join('\n');
const blockGeom=CAD.readGeometry(enc(blockFixture));assert.ok(blockGeom.curves.some(c=>c.type==='block-curve'&&c.points.length>100),'block ARC samples are transformed as a curve during INSERT expansion');assert.ok(blockGeom.segments.some(s=>s.isCurveSegment),'expanded block curve segments retain curve flag');
const blockLabel=blockGeom.texts.find(t=>t.text==='AXIS-LABEL');assert.ok(blockLabel,'axis name inside block is shown in the alignment preview');close(blockLabel.position.x,100+5*Math.sqrt(2),1e-5);close(blockLabel.position.y,50+5*Math.sqrt(2),1e-5);close(blockLabel.height,2*Math.sqrt(2),1e-5);

// SVG export test uses the same SVG vector paths as the raster/PDF preview. Supports A commands,
// color groups, ignores white page background and refuses a frame-only false-success export.
const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><g fill="#000000"><path d="M 0 0 L 100 0 L 100 100 L 0 100 Z"/><path d="M 10 10 L 90 10 L 90 90 L 10 90 Z"/><path d="M 20 50 A 10 10 0 0 1 40 50"/><path fill="#eeeeee" d="M 20 20 L 30 20 L 30 30 L 20 30 Z"/></g><path fill="#ffffff" d="M0 0 L100 0 L100 100 L0 100 Z"/></svg>`;
const traced=CAD.svgPathsToCad(svg,100,100,8);assert.ok(traced.length>=2,'inner board geometry and SVG arc survive path extraction');
assert.ok(traced.some(p=>p.points.length>8),'SVG arc converted to curve vertices');
assert.ok(traced.some(p=>p.rgb===0xeeeeee),'pale CAD line colours are retained instead of being treated as white paper');
const dxf=CAD.polylinesToDxf(traced,100,100,0.01);const dxftxt=dec(dxf.bytes);assert.ok(dxftxt.includes('TRACE_ACI_7'));assert.ok(dxftxt.includes('POLYLINE'));assert.ok(dxftxt.includes('420\n15658734'),'raster/PDF vector output retains exact RGB true colour');assert.ok(dxf.vertices>20);
let frameOnly=false;try{CAD.svgPathsToCad('<svg><path fill="#000000" d="M0 0 L100 0 L100 100 L0 100 Z"/></svg>',100,100);}catch(e){frameOnly=/إطار الورقة فقط/.test(e.message);}assert.ok(frameOnly,'frame-only output is rejected, not delivered as a successful drawing');
let insetFrameOnly=false;try{CAD.svgPathsToCad('<svg width="100" height="100"><path d="M5 5 L95 5 L95 95 L5 95 Z"/></svg>',100,100);}catch(e){insetFrameOnly=/إطار الورقة فقط/.test(e.message);}assert.ok(insetFrameOnly,'inset page border is also rejected, not exported as the only CAD object');

// Preserve original source bytes outside the numeric fields: alignment never converts the canvas
// or geometry preview back into a new drawing.
const sourceText=dec(input),outText=out;
assert.ok(outText.includes('GRID')===sourceText.includes('GRID'));
assert.ok(outText.includes('0\r\nARC\r\n'));
assert.ok(outText.includes('0\r\nLWPOLYLINE\r\n'));
assert.ok(outText.includes('0\r\nSPLINE\r\n'));
console.log('PASS V165: raw DXF transform retains ARC/CIRCLE/ELLIPSE/SPLINE/bulges and entity types; annotation styles and MINSERT scale; curved preview and XLINE snapping; dense crossing snap; SVG arc/color extraction; frame-only PDF/image conversion rejected.');
