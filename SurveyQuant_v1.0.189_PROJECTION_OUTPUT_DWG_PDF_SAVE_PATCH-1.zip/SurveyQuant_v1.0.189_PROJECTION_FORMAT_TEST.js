'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(process.argv[2] || __dirname);
const cad = require(path.join(root, 'SurveyQuant_v1.0.177_CAD_ENGINE.js'));
const io = require(path.join(root, 'SurveyQuant_v1.0.189_PROJECTION_IO.js'));

const enc = new TextEncoder();
const decoder = new TextDecoder('windows-1252');
function makeDxf(points, color) {
  return cad.polylinesToDxf([{ points, closed: false, aci: color, rgb: color === 1 ? 0xff0000 : 0x0000ff }], 100, 100, 1).bytes;
}
const targetDxf = makeDxf([{x:10,y:10},{x:20,y:10}], 1);
const sourceDxf = makeDxf([{x:40,y:40},{x:50,y:40},{x:50,y:60}], 5);

function fakeFile(name, dxfBytes) {
  const data = Buffer.from(dxfBytes);
  return { name, size: data.length, async arrayBuffer() { return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength); }, convertedDxfBytes: new Uint8Array(data) };
}
async function parseFile(file, opts) {
  assert.equal(opts.rawOnly, true, 'CAD import must use raw-only mode');
  if (/\.dwg$/i.test(file.name)) {
    assert.equal(opts.conversionOnly, true, 'DWG import must explicitly convert to DXF without retaining DWG state');
    return { rawDXFBytes: file.convertedDxfBytes, source: 'DWG' };
  }
  return { source: 'DXF' };
}

(async () => {
  const combos = [['dxf','dxf'],['dxf','dwg'],['dwg','dxf'],['dwg','dwg']];
  const comboResults = [];
  for (const [sourceExt, targetExt] of combos) {
    const source = await io.readCadBytes(fakeFile(`source.${sourceExt}`, sourceDxf), parseFile);
    const target = await io.readCadBytes(fakeFile(`target.${targetExt}`, targetDxf), parseFile);
    const merged = cad.mergeRawDxfBoards(target.bytes, source.bytes);
    const text = decoder.decode(merged.bytes);
    assert.ok(merged.importedEntities >= 1, `${sourceExt}/${targetExt}: source CAD entities must be merged`);
    assert.ok((text.match(/\nLWPOLYLINE\r?\n/g) || []).length >= 2, `${sourceExt}/${targetExt}: target and source polylines must both survive`);
    assert.match(text, /\nEOF\r?\n$/);
    fs.writeFileSync(path.join(root, `V189_PAIR_${sourceExt.toUpperCase()}_${targetExt.toUpperCase()}.dxf`), Buffer.from(merged.bytes));
    comboResults.push({ source: sourceExt.toUpperCase(), target: targetExt.toUpperCase(), imported: merged.importedEntities });
  }

  // A native Java bridge may be a void method. The CAD engine must accept the request
  // sentinel and never treat undefined as a confirmed path/URI or crash the PDF save.
  global.safeDownloadFile = async () => 'ANDROID_SAVE_REQUESTED';
  const saved = await cad.downloadBytes(new Uint8Array([48,10,69,79,70]), 'sample.dxf', 'application/dxf');
  assert.equal(saved, 'ANDROID_SAVE_REQUESTED');

  let directArgs = null;
  const direct = await io.exportMergedCad(targetDxf, 'dxf', async (...args) => { directArgs = args; return 'ANDROID_SAVE_REQUESTED'; }, 'Merged');
  assert.equal(direct.direct, true);
  assert.equal(direct.savedFormat, 'dxf');
  assert.equal(directArgs[1], 'Merged.dxf');

  let externalArgs = null;
  const external = await io.exportMergedCad(sourceDxf, 'dwg', async (...args) => { externalArgs = args; return 'ANDROID_SAVE_REQUESTED'; }, 'Merged');
  assert.equal(external.direct, false);
  assert.equal(external.requestedFormat, 'dwg');
  assert.equal(external.savedFormat, 'dxf', 'do not mislabel a DXF intermediate as DWG');
  assert.equal(externalArgs[1], 'Merged.dxf');
  assert.match(external.converterUrl, /anyconv\.com\/ar\/.*dxf.*dwg/i);

  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  assert.match(html, /id="dropFilesOutputFormat"[\s\S]*?<option value="dxf"[\s\S]*?<option value="dwg"/);
  assert.match(html, /function downloadDroppedDXF\(\)[\s\S]*?resolveExportFormat/);
  assert.match(html, /dropFilesOutputFormat/);
  assert.match(html, /imagetostl\.com\/convert\/cad\/dwg/, 'free external DWG-to-DXF fallback link must be visible');
  assert.match(html, /enteringSurveyProject\|\|leavingSurveyProject\)cleanup\(\)/, 'every orientation/PDF session entry must be clean');
  assert.match(html, /return hasUri\?result:'ANDROID_SAVE_REQUESTED'/, 'void Android save bridge must return a safe sentinel');
  assert.match(html, /if\(state\.activeBoardSide===which\)activateBoardPanel\(which\)/, 'clearing active source must not expose the other board');
  assert.match(html, /setSourceBoardMode\(true\);activateBoardPanel\('source'\)/, 'successful orientation must show only transformed source board');

  console.log(JSON.stringify({
    fourInputPairs: comboResults,
    outputDXF: 'direct Android save request',
    outputDWG: 'DXF saved as intermediate + AnyConv external conversion link, no fake .dwg extension',
    androidVoidSaveBridge: 'PASS',
    newSessionClearsState: 'PASS',
    oneBoardAtATime: 'PASS',
    result: 'PASS'
  }, null, 2));
})().catch(error => { console.error(error); process.exit(1); });
