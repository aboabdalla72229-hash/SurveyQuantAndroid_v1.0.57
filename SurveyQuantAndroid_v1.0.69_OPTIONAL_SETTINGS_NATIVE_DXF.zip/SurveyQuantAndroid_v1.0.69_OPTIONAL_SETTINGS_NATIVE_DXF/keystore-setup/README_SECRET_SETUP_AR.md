# إعداد توقيع سلسلة تحديث SurveyQuant 1.0.57

هذه نسخة بداية جديدة تستخدم مفتاح Release جديدًا. لا ترفع ملف JKS أو ملف Base64 أو ملفات كلمات المرور إلى مستودع GitHub العام.

من صفحة المستودع افتح:
Settings → Secrets and variables → Actions → New repository secret

أنشئ الأسرار التالية بالأسماء الحرفية:

1. `SURVEYQUANT_KEYSTORE_BASE64`: انسخ المحتوى الكامل من `SURVEYQUANT_KEYSTORE_BASE64.txt`.
2. `SURVEYQUANT_KEYSTORE_PASSWORD`: انسخ القيمة من `SURVEYQUANT_KEYSTORE_PASSWORD.txt`.
3. `SURVEYQUANT_KEY_ALIAS`: انسخ القيمة من `SURVEYQUANT_KEY_ALIAS.txt`.
4. `SURVEYQUANT_KEY_PASSWORD`: انسخ القيمة من `SURVEYQUANT_KEY_PASSWORD.txt`.

ثم افتح Actions وشغّل `Build SurveyQuant v1.0.57 Release` يدويًا.

احتفظ بملف `surveyquant-release-157.jks` وكلمات المرور في مكان آمن. يجب استخدام المفتاح نفسه في كل تحديث لاحق. لأن هذا مفتاح جديد، قد يلزم إزالة APK قديم ذي توقيع مختلف قبل تثبيت النسخة الجديدة، وقد يؤدي ذلك إلى حذف بيانات التطبيق المحلية.
