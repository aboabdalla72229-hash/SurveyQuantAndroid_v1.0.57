'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const [manualPath, referencePath, htmlPath] = process.argv.slice(2);
assert(manualPath && referencePath && htmlPath, 'usage: test.js MANUAL_MODULE.js REFERENCE_MODULE.js INDEX_PATH.html');
const manual = fs.readFileSync(manualPath, 'utf8');
const reference = fs.readFileSync(referencePath, 'utf8');
const html = fs.readFileSync(htmlPath, 'utf8');
const manualHelperMatch = manual.match(/function sqV125ManualTextPixelHeight\(height,scale,zoom\)\{[^}]*\}/);
assert(manualHelperMatch, 'manual inverse-zoom helper is missing');
const manualHelper = vm.runInNewContext('(' + manualHelperMatch[0].replace('function sqV125ManualTextPixelHeight(height,scale,zoom)', 'function(height,scale,zoom)') + ')', { Number, Math });
const refMatch = reference.match(/function sqV122NaturalTextPixels\(v,t,m,p\)\{[^}]*\}/);
assert(refMatch, 'dual-board inverse-zoom helper is missing');
const referenceHelper = vm.runInNewContext('(' + refMatch[0].replace('function sqV122NaturalTextPixels(v,t,m,p)', 'function(v,t,m,p)') + ')', { Number, Math });
function close(a,b,msg){assert(Math.abs(a-b)<1e-10,`${msg}: expected ${b}, got ${a}`);}
// scale is the rendered geometry scale (fitScale * zoom). The text size must shrink in inverse proportion.
const h = 2.5, fit = 0.4;
const manualSize = z => manualHelper(h, fit*z, z);
const referenceSize = z => referenceHelper({zoom:z},{height:h,p:{x:100,y:200}},{base:fit,scale:fit*z},{x:100*fit*z,y:200*fit*z});
for (const [label, fn] of [['manual canvas',manualSize],['two-board preview',referenceSize]]) {
  close(fn(1), 1.0, `${label} at zoom 1x`);
  close(fn(2), 0.5, `${label} at zoom 2x`);
  close(fn(4), 0.25, `${label} at zoom 4x`);
  assert(fn(4)<fn(2) && fn(2)<fn(1), `${label}: text must get smaller as the board zooms in`);
  assert(fn(4)<5.5, `${label}: no 5.5px minimum clamp is allowed`);
}
const entity = {height:2.5, text:'GRID A1', layer:'GRID', xdata:{tag:'keep'}};
const before = JSON.stringify(entity);
manualHelper(entity.height, fit*4, 4);
referenceHelper({zoom:4},{height:entity.height,p:{x:0,y:0}},{base:fit,scale:fit*4},{x:0,y:0});
assert.equal(JSON.stringify(entity), before, 'preview measurement must not mutate source entity attributes');
for (const [label, source] of [['manual module',manual],['reference module',reference],['integrated HTML',html]]) {
  assert(!source.includes("ctx.font='11px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);"), `${label}: fixed CAD text font remains`);
}
assert(reference.includes('function universalTransformBytes(input,t)'), 'reference module: byte-preserving CAD transform missing');
assert(html.includes('function universalTransformBytes(input,t)'), 'integrated HTML: byte-preserving CAD transform missing');
assert(manual.includes('V125') && reference.includes('V125'), 'V125 inverse-zoom rule not integrated in both standalone modules');
assert(html.includes('function sqV125ManualTextPixelHeight('), 'integrated HTML missing legacy renderer fix');
assert(html.includes('V125: CAD annotation preview shrinks inversely'), 'integrated HTML missing dual-board renderer fix');
assert(!html.includes("size=Math.max(5.5,Math.min(15,Math.abs(Number(t.height)||2.5)*m.scale));"), 'old fixed font clamp remains');
console.log('PASS V125: both orientation text renderers shrink inversely at zoom 1x / 2x / 4x, no fixed font floor, and no entity mutation.');
