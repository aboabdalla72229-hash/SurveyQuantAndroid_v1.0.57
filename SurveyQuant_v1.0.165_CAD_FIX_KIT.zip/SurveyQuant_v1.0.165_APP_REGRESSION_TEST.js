'use strict';
const fs=require('node:fs');
const assert=require('node:assert/strict');
const htmlFile=process.argv[2],engineFile=process.argv[3];
if(!htmlFile||!engineFile)throw new Error('Usage: node SurveyQuant_v1.0.165_APP_REGRESSION_TEST.js <patched-index.html> <engine.js>');
const html=fs.readFileSync(htmlFile,'utf8'),engine=fs.readFileSync(engineFile,'utf8');
for(const marker of [
  'sq165-native-curves-exact-snap-raster-fix','sq164-cad-output-axis-fix','sqDownloadNameDialog',
  'const requestedName=await chooseDownloadFilename(','window.Android.saveFile(finalName,mime,base64)',
  'window.Android.notifyDownload(finalName,String(result),mime)','sq163RawCadOverlayMerge',
  'sq163-pdfjs-worker','sq162-wasm-binary','GlobalWorkerOptions.workerSrc=url'
])assert.ok(html.includes(marker),'V165 HTML marker missing: '+marker);
const match=html.match(/<script\s+type="application\/octet-stream"\s+id="sq163-cad-engine">([A-Za-z0-9+/=\r\n]+)<\/script>/i);
assert.ok(match,'Embedded CAD engine slot missing');
assert.equal(Buffer.from(match[1],'base64').toString('utf8'),engine,'embedded CAD engine differs from tested engine source');
for(const marker of [
  'SQ_V165_NATIVE_CURVES_RAW_TRANSFORM_SNAP_AND_RASTER_EXPORT',
  "mode:'raw-dxf-record-transform'", "else if(type==='SPLINE')", 'angleOnArc',
  'const content=paths.filter(p=>!isFrame(p))','ctx.lineTo(q.x,q.y)',
  'root.safeDownloadFile(bytes, filename, mime, false)'
])assert.ok(engine.includes(marker),'engine regression marker missing: '+marker);
assert.ok(!engine.includes('const content=paths.filter(p=>isFrame(p))'),'raster export must not choose the page frame as the drawing');
assert.ok(!html.includes("window.prompt('اكتب اسم اللوحة / الملف المخرج:"),'legacy save prompt remains');
console.log('PASS V165 app regression: V164 save/name/notification and DWG/PDF runtime retained; tested V165 engine embedded byte-for-byte; native curves/raw DXF export and page-content filtering verified.');
