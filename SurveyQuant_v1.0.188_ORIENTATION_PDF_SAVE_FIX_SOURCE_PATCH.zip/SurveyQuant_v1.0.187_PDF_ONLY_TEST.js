'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(process.argv[2]||__dirname);
const cad=require(path.join(root,'SurveyQuant_v1.0.177_CAD_ENGINE.js'));
const pdfjs=require(path.join(root,'pdfjs-v3.11.174.min.js'));
const worker=path.join(root,'pdf.worker.js');
pdfjs.GlobalWorkerOptions.workerSrc=worker;
async function readPdf(p){return pdfjs.getDocument({data:new Uint8Array(fs.readFileSync(p)),disableWorker:true,useSystemFonts:true,isEvalSupported:false}).promise;}
(async()=>{
 const vector=await readPdf(path.join(root,'V177_VECTOR_TEST.pdf'));
 try{
  const page=await vector.getPage(1),view=page.getViewport({scale:1});
  const paths=await cad.pdfOperatorPathsToCad(page,pdfjs,view),texts=await cad.pdfTextToCad(page,view);
  const dxf=cad.polylinesToDxf(paths,view.width,view.height,1,texts);
  fs.writeFileSync(path.join(root,'V187_VECTOR_PDF_TEST.dxf'),Buffer.from(dxf.bytes));
  const str=new TextDecoder('windows-1252').decode(dxf.bytes);
  assert.match(str,/AC1015/);assert.match(str,/LWPOLYLINE/);assert.match(str,/\n420\r?\n/);assert.match(str,/\n370\r?\n/);
  assert.doesNotMatch(str,/\nIMAGE(?:\r?\n|$)|\nIMAGEDEF(?:\r?\n|$)/);
  assert.ok(dxf.count>=paths.length&&dxf.vertices>=20);
 }finally{await vector.destroy();}
 const filled=await readPdf(path.join(root,'V187_FILLED_VECTOR_FIXTURE.pdf'));
 try{const page=await filled.getPage(1),view=page.getViewport({scale:1});const paths=await cad.pdfOperatorPathsToCad(page,pdfjs,view),texts=await cad.pdfTextToCad(page,view,20000,pdfjs);assert.ok(paths.some(p=>p.filled),'PDF filled areas must survive as fill geometry');const dxf=cad.polylinesToDxf(paths,view.width,view.height,1,texts),str=new TextDecoder('windows-1252').decode(dxf.bytes);fs.writeFileSync(path.join(root,'V187_FILLED_VECTOR_TEST.dxf'),Buffer.from(dxf.bytes));assert.match(str,/\nHATCH\r?\n/);assert.match(str,/\n420\r?\n/);assert.ok(dxf.hatchCount>=1);}
 finally{await filled.destroy();}
 const raster=await readPdf(path.join(root,'V187_RASTER_FIXTURE.pdf'));
 try{const page=await raster.getPage(1),view=page.getViewport({scale:1});await assert.rejects(()=>cad.pdfOperatorPathsToCad(page,pdfjs,view),/صور نقطية|صورة نقطية/);}
 finally{await raster.destroy();}
 console.log(JSON.stringify({vectorPdf:'editable DXF R2000 entities with TrueColor/lineweight',filledPdf:'solid HATCH entities retained',rasterPdf:'rejected without image output or raster tracing',result:'PASS'},null,2));
})().catch(e=>{console.error(e);process.exit(1)});
