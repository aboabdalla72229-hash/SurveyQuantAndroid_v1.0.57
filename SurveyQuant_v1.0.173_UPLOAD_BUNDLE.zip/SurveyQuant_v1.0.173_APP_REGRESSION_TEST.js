#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const [htmlFile,engineFile]=process.argv.slice(2);
if(!htmlFile||!engineFile)throw new Error('Usage: node V173_APP_REGRESSION_TEST.js <index.html> <CAD_ENGINE.js>');
const html=fs.readFileSync(htmlFile,'utf8'),engine=fs.readFileSync(engineFile,'utf8');
const slot=html.match(/<script\s+type="application\/octet-stream"\s+id="sq163-cad-engine">([A-Za-z0-9+/=\r\n]+)<\/script>/i);
assert.ok(slot,'embedded CAD engine missing');
assert.equal(Buffer.from(slot[1].replace(/\s/g,''),'base64').toString('utf8'),engine,'embedded engine differs from tested V173 engine');
const menu=html.match(/<div class="home-menu">([\s\S]*?)<\/div>/i);assert.ok(menu,'home grid missing');
assert.equal([...menu[1].matchAll(/<button\b/gi)].length,10,'exactly ten static buttons must remain in the project grid');
for(const id of ['project1Card','profileCard','roadCard','pipeCard','landAreaCard','fileToDxfCard','cleanFilesCard','dropFilesCard']){
 assert.ok(html.includes(`id="${id}"`),'legacy project card missing: '+id);
 assert.ok(menu[1].includes(`openProjectPage('${id}')`),'legacy project button missing: '+id);
}
assert.ok(menu[1].includes('id="sq172-home-orientation-project"'),'orientation shortcut missing');
assert.ok(menu[1].includes('id="sq172-home-pdf-project"'),'PDF shortcut missing');
assert.ok(menu[1].includes("sq172OpenCadProject('align')"),'orientation shortcut not wired to align tab');
assert.ok(menu[1].includes("sq172OpenCadProject('raster')"),'PDF shortcut not wired to raster tab');
assert.ok(html.includes('sq173-pdfjs-readonly-getdocument-runtime-startup-fix'),'V173 marker missing');
assert.ok(html.includes('PDF.js 4+ exposes getDocument as a getter-only property. Never replace it.'),'read-only PDF.js compatibility note missing');
assert.ok(html.includes('lib.GlobalWorkerOptions.workerSrc=url;'),'worker configuration missing');
assert.ok(!html.includes('lib.getDocument=guarded')&&!html.includes('lib.getDocument = guarded'),'getDocument must not be overwritten');
assert.ok(!html.includes('renderImageSideRows();'),'undefined startup callback must be removed');
assert.ok(html.includes("window.addEventListener('surveyquant-cad-error',onError)"),'project launch must receive runtime errors');
assert.ok(html.includes("cadOverlay.querySelector('[data-tab=align]')")&&html.includes("cadOverlay.querySelector('[data-tab=raster]')"),'runtime must verify both CAD project tabs');
assert.ok(engine.includes('SQ_V173_NO_DUPLICATE_HOME_FALLBACK'),'V173 duplicate-button fix missing from CAD engine');
assert.ok(engine.includes("doc.getElementById('sq172-home-orientation-project')"),'engine must recognize the static orientation button');
assert.ok(engine.includes("doc.getElementById('sq172-home-pdf-project')"),'engine must recognize the static PDF button');
console.log(JSON.stringify({ok:true,staticHomeButtons:10,legacyProjects:8,newProjects:['align','raster'],pdfjsGetterSafe:true,undefinedStartupCallRemoved:true,noDuplicateDynamicButtons:true},null,2));
