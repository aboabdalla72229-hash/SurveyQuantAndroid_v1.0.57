# إصلاح v1.0.64

- إصلاح مسار SDR المفصول 08TP/08KI: Northing ثم Easting ثم Elevation يتم تطبيعه داخليًا إلى X=Easting وY=Northing.
- إصلاح مسار SDR الرقمي الاحتياطي بنفس قاعدة X=E وY=N.
- إصلاح إخراج SDR المنظف ليحافظ على الترتيب الأصلي Northing, Easting, Elevation بدل عكسهما.
- باقي ملفات PNT/TXT/CSV تستمر على X=E وY=N.
