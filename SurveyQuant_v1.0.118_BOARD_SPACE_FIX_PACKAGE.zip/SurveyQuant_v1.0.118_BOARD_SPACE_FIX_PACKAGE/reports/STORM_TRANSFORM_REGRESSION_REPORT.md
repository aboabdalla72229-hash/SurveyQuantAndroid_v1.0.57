

# STORM real-DXF orientation-engine test

This second regression test runs the app’s actual v111/v113 byte-preserving transform engine against both converted user-provided STORM boards using a known non-zero rotation and translation. It verifies that group-pair count and entity type sequence remain unchanged and that non-geometric pair values stay unchanged. Test transformation outputs are marked `ORIENTATION_ENGINE_TEST` and must not be used as the final site alignment because the points are generated for regression testing.

## Board 1: STORM_1_converted.dxf

- Result: PASS
- Test output: STORM_1_converted_ORIENTATION_ENGINE_TEST.dxf
- Entity records: 1129
- Group/value pairs: 289023
- Geometric values changed: 9344
- Non-geometric values changed: 0

## Board 2: STORM_2_converted.dxf

- Result: PASS
- Test output: STORM_2_converted_ORIENTATION_ENGINE_TEST.dxf
- Entity records: 217
- Group/value pairs: 83077
- Geometric values changed: 1259
- Non-geometric values changed: 0


# STORM real-DXF orientation-engine test

This second regression test runs the app’s actual v111/v113 byte-preserving transform engine against both converted user-provided STORM boards using a known non-zero rotation and translation. It verifies that group-pair count and entity type sequence remain unchanged and that non-geometric pair values stay unchanged. Test transformation outputs are marked `ORIENTATION_ENGINE_TEST` and must not be used as the final site alignment because the points are generated for regression testing.

## Board 1: STORM_1_converted.dxf

- Result: PASS
- Test output: STORM_1_converted_ORIENTATION_ENGINE_TEST.dxf
- Entity records: 1129
- Group/value pairs: 289023
- Geometric values changed: 9344
- Non-geometric values changed: 0

## Board 2: STORM_2_converted.dxf

- Result: PASS
- Test output: STORM_2_converted_ORIENTATION_ENGINE_TEST.dxf
- Entity records: 217
- Group/value pairs: 83077
- Geometric values changed: 1259
- Non-geometric values changed: 0


# STORM real-DXF orientation-engine test

This second regression test runs the app’s actual v111/v113 byte-preserving transform engine against both converted user-provided STORM boards using a known non-zero rotation and translation. It verifies that group-pair count and entity type sequence remain unchanged and that non-geometric pair values stay unchanged. Test transformation outputs are marked `ORIENTATION_ENGINE_TEST` and must not be used as the final site alignment because the points are generated for regression testing.

## Board 1: STORM_1_converted.dxf

- Result: PASS
- Test output: STORM_1_converted_ORIENTATION_ENGINE_TEST.dxf
- Entity records: 1129
- Group/value pairs: 289023
- Geometric values changed: 9344
- Non-geometric values changed: 0

## Board 2: STORM_2_converted.dxf

- Result: PASS
- Test output: STORM_2_converted_ORIENTATION_ENGINE_TEST.dxf
- Entity records: 217
- Group/value pairs: 83077
- Geometric values changed: 1259
- Non-geometric values changed: 0
