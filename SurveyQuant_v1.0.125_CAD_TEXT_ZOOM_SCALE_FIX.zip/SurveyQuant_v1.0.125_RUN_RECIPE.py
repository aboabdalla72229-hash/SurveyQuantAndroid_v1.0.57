#!/usr/bin/env python3
"""Build V125 using the historical V116 CAD builder, adding only V125 fixes.

The immutable V116 build recipe is loaded from Git history. This adapter changes
release labels/version numbers and inserts the V125 text/DWG patch before the
historical verification, signing, and APK packaging steps.
"""
from pathlib import Path
import os
import re
import subprocess
import sys

BASE_SHA = "865d4bf0e15f39145f9f76c664ff83633083d026"
BASE_PATH = ".github/workflows/build-v116-orientation-full-fidelity.yml"


def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise SystemExit(f"ERROR: {label}: expected one anchor, found {count}.")
    return source.replace(old, new, 1)


def transformed_builder() -> str:
    workspace = os.environ.get("GITHUB_WORKSPACE")
    if not workspace:
        raise SystemExit("ERROR: GITHUB_WORKSPACE is missing; run this recipe inside GitHub Actions.")
    raw = subprocess.check_output(
        ["git", "show", f"{BASE_SHA}:{BASE_PATH}"],
        cwd=workspace, text=True, encoding="utf-8"
    )

    source = raw.replace("v1.0.116", "v1.0.125")
    source = source.replace("1.0.116", "1.0.125")
    source = source.replace("v116", "v125").replace("V116", "V125")
    source = source.replace("r'\\g<1>116'", "r'\\g<1>125'")
    source = source.replace("versionCode[[:space:]]+116", "versionCode[[:space:]]+125")
    source = source.replace("1\\.0\\.116", "1\\.0\\.125")
    source = source.replace("Failed to set HTML app version code to 115.", "Failed to set HTML app version code to 125.")
    source = source.replace("SQ_APP_VERSION_CODE = 116;", "SQ_APP_VERSION_CODE = 125;")
    source = source.replace(
        "SurveyQuant_v1.0.125_CAD_FIDELITY_ORIENTATION_FIX.apk",
        "SurveyQuant_v1.0.125_CAD_TEXT_ZOOM_SCALE_FIX.apk"
    )
    source = source.replace(
        "SurveyQuant_v1.0.125_CAD_FIDELITY_SOURCE_PATCH.zip",
        "SurveyQuant_v1.0.125_CAD_TEXT_ZOOM_SCALE_SOURCE_PATCH.zip"
    )
    source = source.replace(
        "SurveyQuant-v1.0.125-CAD-FIDELITY-ORIENTATION-FIX",
        "SurveyQuant-v1.0.125-CAD-TEXT-ZOOM-SCALE-FIX"
    )

    source = replace_once(
        source,
        '      - ".github/workflows/build-v125-orientation-full-fidelity.yml"',
        '      - ".github/workflows/build-v125-cad-text-zoom-scale.yml"',
        "V125 workflow path"
    )
    source = replace_once(
        source,
        '      - "SurveyQuant_v1.0.115_ORIENTATION_FINAL_PATCH_PACKAGE.zip"\n',
        '      - "SurveyQuant_v1.0.115_ORIENTATION_FINAL_PATCH_PACKAGE.zip"\n'
        '      - "SurveyQuant_v1.0.125_CAD_TEXT_ZOOM_SCALE_FIX.zip"\n',
        "V125 ZIP push trigger"
    )

    injected_step = '''      - name: Apply V122 natural CAD text scale and universal DWG import
        shell: bash
        run: |
          set -euo pipefail
          test -n "${V122_PATCHER:-}" || { echo "ERROR: V122 patcher path is missing."; exit 1; }
          test -n "${V122_TEST:-}" || { echo "ERROR: V122 test path is missing."; exit 1; }
          test -n "${V122_BRIDGE:-}" || { echo "ERROR: V122 DWG bridge path is missing."; exit 1; }
          python3 "$V122_PATCHER" "$REFERENCE_MODULE" "$INDEX_PATH" "$V122_BRIDGE"
          node --check "$V122_BRIDGE"
          node "$V122_TEST" "$REFERENCE_MODULE" "$INDEX_PATH" "$V122_BRIDGE"
          grep -Fq 'const SQ_APP_VERSION_CODE = 125;' "$INDEX_PATH"

'''
    source = replace_once(
        source,
        '          mkdir -p "$RELEASE/source-patch"\n',
        '          mkdir -p "$RELEASE/source-patch"\n'
        '          cp "$V122_PATCHER" "$RELEASE/source-patch/SurveyQuant_v1.0.122_APPLY_PATCH.py"\n'
        '          cp "$V122_BRIDGE" "$RELEASE/source-patch/SurveyQuant_v1.0.122_DWG_IMPORT_BRIDGE.js"\n'
        '          cp "$V122_TEST" "$RELEASE/source-patch/SurveyQuant_v1.0.122_DWG_TEXT_SCALE_TEST.js"\n'
        '          cp "$V125_PATCHER" "$RELEASE/source-patch/SurveyQuant_v1.0.125_APPLY_PATCH.py"\n'
        '          cp "$V125_TEST" "$RELEASE/source-patch/SurveyQuant_v1.0.125_CAD_TEXT_ZOOM_SCALE_TEST.js"\n',
        "include V122 and V125 patch sources in the final source bundle"
    )

    v125_injected_step = '''      - name: Apply inverse-zoom CAD text preview on both orientation canvases (V125)
        shell: bash
        run: |
          set -euo pipefail
          test -s "${V125_PATCHER:-}" || { echo "ERROR: V125 renderer patcher is missing."; exit 1; }
          test -s "${V125_TEST:-}" || { echo "ERROR: V125 renderer test is missing."; exit 1; }
          python3 "$V125_PATCHER" "$MANUAL_MODULE" "$REFERENCE_MODULE" "$INDEX_PATH"
          node --check "$MANUAL_MODULE"
          node "$V125_TEST" "$MANUAL_MODULE" "$REFERENCE_MODULE" "$INDEX_PATH"

'''
    source = replace_once(
        source,
        "      - name: Verify original projects and CAD orientation integration\n",
        injected_step + v125_injected_step + "      - name: Verify original projects and CAD orientation integration\n",
        "insert V122 and V125 patches before historical integration checks"
    )

    required = [
        "name: Build SurveyQuant v1.0.125",
        '      - ".github/workflows/build-v125-cad-text-zoom-scale.yml"',
        'python3 "$V122_PATCHER" "$REFERENCE_MODULE" "$INDEX_PATH" "$V122_BRIDGE"',
        'python3 "$V125_PATCHER" "$MANUAL_MODULE" "$REFERENCE_MODULE" "$INDEX_PATH"',
        'node "$V125_TEST" "$MANUAL_MODULE" "$REFERENCE_MODULE" "$INDEX_PATH"',
        'const SQ_APP_VERSION_CODE = 125;',
        "gradle --no-daemon clean assembleRelease --stacktrace",
        "actions/upload-artifact@v4",
        "SurveyQuant_v1.0.125_CAD_TEXT_ZOOM_SCALE_FIX.apk",
        "SurveyQuant_v1.0.125_CAD_TEXT_ZOOM_SCALE_SOURCE_PATCH.zip",
        "function universalTransformBytes(input,t)",
        'node "$V122_TEST" "$REFERENCE_MODULE" "$INDEX_PATH" "$V122_BRIDGE"',
    ]
    missing = [token for token in required if token not in source]
    if missing:
        raise SystemExit("ERROR: transformed V125 recipe failed validation: " + ", ".join(missing))
    return source


def resolve_expressions(value: str, shell_script: bool = False) -> str:
    pattern = re.compile(r"\$\{\{\s*(.*?)\s*\}\}")

    def replacement(match: re.Match) -> str:
        expr = match.group(1).strip()
        if expr == "runner.temp":
            return os.environ.get("RUNNER_TEMP", "/tmp")
        if expr == "github.run_id":
            return os.environ.get("GITHUB_RUN_ID", "0")
        if expr == "github.token":
            return "$GH_TOKEN" if shell_script else os.environ.get("GH_TOKEN", "")
        if expr.startswith("secrets."):
            key = expr.split(".", 1)[1]
            return "$" + key if shell_script else os.environ.get(key, "")
        if expr.startswith("env."):
            key = expr.split(".", 1)[1]
            return "$" + key if shell_script else os.environ.get(key, "")
        raise SystemExit(f"ERROR: unhandled Actions expression in historical run step: ${{{{ {expr} }}}}")
    return pattern.sub(replacement, value)


def load_github_env() -> None:
    path = os.environ.get("GITHUB_ENV")
    if not path or not Path(path).exists():
        return
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if "=" in line and not line.startswith("<<"):
            key, value = line.split("=", 1)
            if key and "\n" not in key:
                os.environ[key] = value


def load_github_path() -> None:
    path = os.environ.get("GITHUB_PATH")
    if not path or not Path(path).exists():
        return
    entries = [x for x in Path(path).read_text(encoding="utf-8").splitlines() if x]
    current = os.environ.get("PATH", "").split(os.pathsep)
    for entry in reversed(entries):
        if entry not in current:
            current.insert(0, entry)
    os.environ["PATH"] = os.pathsep.join(current)


def main() -> int:
    workspace = os.environ.get("GITHUB_WORKSPACE")
    if not workspace:
        raise SystemExit("ERROR: GITHUB_WORKSPACE is missing; run this recipe inside GitHub Actions.")
    workspace_path = Path(workspace).resolve()
    if not workspace_path.is_dir():
        raise SystemExit(f"ERROR: GITHUB_WORKSPACE is not an existing directory: {workspace_path}")

    try:
        import yaml
    except ImportError:
        raise SystemExit("ERROR: PyYAML is required. Install python3-yaml before running this recipe.")

    source = transformed_builder()
    data = yaml.safe_load(source)
    steps = data.get("jobs", {}).get("build", {}).get("steps", [])
    run_steps = [step for step in steps if isinstance(step, dict) and isinstance(step.get("run"), str)]
    if len(run_steps) < 12:
        raise SystemExit(f"ERROR: historical build recipe appears incomplete ({len(run_steps)} run steps).")

    print(f"V125: validated the historical V116 CAD builder; executing {len(run_steps)} shell steps.", flush=True)
    for idx, step in enumerate(run_steps, 1):
        name = str(step.get("name", f"historical run step {idx}"))
        raw_script = resolve_expressions(step["run"], shell_script=True)
        step_env = os.environ.copy()
        for key, raw_value in (step.get("env") or {}).items():
            if not isinstance(raw_value, str):
                step_env[key] = str(raw_value)
                continue
            value = raw_value.strip()
            match = re.fullmatch(r"\$\{\{\s*secrets\.([A-Za-z_][A-Za-z0-9_]*)\s*\}\}", value)
            if match:
                step_env[key] = step_env.get(match.group(1), "")
            else:
                step_env[key] = resolve_expressions(raw_value, shell_script=False)

        workdir = step.get("working-directory")
        if workdir:
            workdir = os.path.expandvars(resolve_expressions(str(workdir), shell_script=False))
            cwd = Path(workdir)
            if not cwd.is_absolute():
                cwd = workspace_path / cwd
        else:
            cwd = workspace_path

        print(f"::group::V125 recipe step {idx}/{len(run_steps)}: {name}", flush=True)
        result = subprocess.run(
            ["bash", "--noprofile", "--norc", "-e", "-o", "pipefail", "-c", raw_script],
            cwd=str(cwd), env=step_env, check=False
        )
        print("::endgroup::", flush=True)
        if result.returncode:
            print(f"ERROR: historical step failed ({result.returncode}): {name}", file=sys.stderr, flush=True)
            return result.returncode
        load_github_env()
        load_github_path()

    print("PASS: all V125 historical shell steps completed. Check the uploaded artifact for the signed APK.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
