SurveyQuant v1.0.106: Orientation Home Menu Fix

This patch fixes reachability of the two-point CAD orientation project. It adds a menu button to the existing home project menu before the separate payment shortcut, and routes the click through the app's existing openProjectPage navigation so the hidden project card becomes active and visible.

The regression test runs the transform and DXF safety tests, plus a minimal DOM integration test verifying that the menu button is created, is placed in the home menu, and activates sqOrientationCard.

The project creates a new text-DXF output and keeps the original input/reference unchanged. The current implementation does not write native DWG or claim preservation of Civil 3D proxy/native CAD objects.
