#!/usr/bin/env python3
"""Fix the live V148 orientation preview/snap WCS path and axis label placement."""
from __future__ import annotations
import argparse, hashlib, re
from pathlib import Path

OLD_VERSION = 'const SQ_APP_VERSION_CODE = 148;'
NEW_VERSION = 'const SQ_APP_VERSION_CODE = 149;'
SCRIPT_ID = 'sq-orientation-reference-board-module'

HELPERS = r'''const SQ_PREVIEW_OCS_TYPES = new Set(['POINT','CIRCLE','ARC','INSERT','TEXT','ATTRIB','ATTDEF','LWPOLYLINE','POLYLINE','SOLID','TRACE','HATCH','SHAPE']);
function sqPreviewNormal(rec){
 const nx=pairVal(rec,210)??0,ny=pairVal(rec,220)??0,nz=pairVal(rec,230)??1,d=Math.hypot(nx,ny,nz);
 if(!Number.isFinite(d)||d<1e-14)return {x:0,y:0,z:1};
 return {x:nx/d,y:ny/d,z:nz/d};
}
function sqPreviewIsOcsEntity(rec){
 const t=String(rec&&rec.type||'').toUpperCase();
 if(!SQ_PREVIEW_OCS_TYPES.has(t))return false;
 if(t==='POLYLINE'){const flags=pairVal(rec,70)||0;if(flags&(8|16|64))return false;}
 return true;
}
function sqPreviewBasis(rec){
 const n=sqPreviewNormal(rec);let ax;
 if(Math.abs(n.x)<1/64&&Math.abs(n.y)<1/64){ax={x:n.z,y:0,z:-n.x};}
 else{ax={x:-n.y,y:n.x,z:0};}
 let ad=Math.hypot(ax.x,ax.y,ax.z);if(ad<1e-14){ax={x:1,y:0,z:0};ad=1;}
 ax={x:ax.x/ad,y:ax.y/ad,z:ax.z/ad};
 let ay={x:n.y*ax.z-n.z*ax.y,y:n.z*ax.x-n.x*ax.z,z:n.x*ax.y-n.y*ax.x};
 const yd=Math.hypot(ay.x,ay.y,ay.z);if(yd>1e-14)ay={x:ay.x/yd,y:ay.y/yd,z:ay.z/yd};else ay={x:0,y:1,z:0};
 return {x:ax,y:ay,z:n};
}
function sqPreviewElevation(rec,code=10){
 const t=String(rec&&rec.type||'').toUpperCase();
 if(t==='LWPOLYLINE')return pairVal(rec,38)??0;
 if(t==='POLYLINE')return pairVal(rec,30)??0;
 return pairVal(rec,code+20)??pairVal(rec,30)??0;
}
function sqPreviewPointToWcs(rec,p,code=10){
 if(!p)return null;
 if(!sqPreviewIsOcsEntity(rec))return {x:p.x,y:p.y};
 const b=sqPreviewBasis(rec),z=sqPreviewElevation(rec,code);
 return {x:b.x.x*p.x+b.y.x*p.y+b.z.x*z,y:b.x.y*p.x+b.y.y*p.y+b.z.y*z};
}
function sqPreviewTextDirection(rec,degrees=0){
 const a=(Number(degrees)||0)*Math.PI/180,dx=Math.cos(a),dy=Math.sin(a);
 if(!sqPreviewIsOcsEntity(rec))return {x:dx,y:dy};
 const b=sqPreviewBasis(rec);return {x:b.x.x*dx+b.y.x*dy,y:b.x.y*dx+b.y.y*dy};
}
function sqPreviewHasNonCanonicalOcs(rec){
 if(!sqPreviewIsOcsEntity(rec))return false;
 const n=sqPreviewNormal(rec);return Math.abs(n.x)>1e-10||Math.abs(n.y)>1e-10||Math.abs(n.z-1)>1e-10;
}
function sqPreviewApplyMatrix(m,p){return {x:m.a*p.x+m.b*p.y+m.tx,y:m.c*p.x+m.d*p.y+m.ty};}
function sqPreviewInsertMatrix(rec,basePoint){
 const raw=pointAt(rec,10)||{x:0,y:0},origin=sqPreviewPointToWcs(rec,raw,10)||{x:0,y:0},b=sqPreviewBasis(rec);
 const sx=pairVal(rec,41)??1,sy=pairVal(rec,42)??1,ang=(pairVal(rec,50)||0)*Math.PI/180,co=Math.cos(ang),si=Math.sin(ang);
 const a=sx*(co*b.x.x+si*b.y.x),bb=sy*(-si*b.x.x+co*b.y.x),c=sx*(co*b.x.y+si*b.y.y),d=sy*(-si*b.x.y+co*b.y.y),bx=basePoint&&Number.isFinite(basePoint.x)?basePoint.x:0,by=basePoint&&Number.isFinite(basePoint.y)?basePoint.y:0;
 return {a,b:bb,c,d,tx:origin.x-a*bx-bb*by,ty:origin.y-c*bx-d*by};
}
'''

GEOMETRY = r'''function geometryInWorld(rec,blocks,parent=null,depth=0,budget=null){
 const empty={pts:[],segments:[],texts:[]};
 if(!parent)parent=p=>p;
 if(typeof parent.vector!=='function'){try{parent.vector=p=>p;}catch(_){}}
 if(!budget)budget={remaining:90000,maxSegments:140000,segments:0,maxPoints:180000,points:0,maxTexts:18000,texts:0,truncated:false};
 if(depth>10||budget.remaining<=0||budget.segments>=budget.maxSegments||budget.points>=budget.maxPoints){budget.truncated=true;return empty;}budget.remaining--;
 if(depth<8&&rec.type==='INSERT'){
  const block=blocks&&blocks.get(recordString(rec,2).toUpperCase());
  if(block){
   const matrix=sqPreviewInsertMatrix(rec,block.base),local=p=>sqPreviewApplyMatrix(matrix,p),composed=p=>parent(local(p));
   composed.vector=v=>{const q={x:matrix.a*v.x+matrix.b*v.y,y:matrix.c*v.x+matrix.d*v.y};return parent.vector?parent.vector(q):q;};
   for(const child of block.entities)mergeGeometry(empty,geometryInWorld(child,blocks,composed,depth+1,budget));
   if(!empty.pts.length)empty.pts.push({...parent(sqPreviewPointToWcs(rec,pointAt(rec,10)||{x:0,y:0},10)),layer:recordString(rec,8)||'0'});
   return empty;
  }
 }
 if(depth<8&&rec.type==='DIMENSION'){
  const dimName=recordString(rec,2).toUpperCase(),dimBlock=blocks&&blocks.get(dimName);
  if(dimBlock&&dimBlock.entities&&dimBlock.entities.length){for(const child of dimBlock.entities)mergeGeometry(empty,geometryInWorld(child,blocks,parent,depth+1,budget));return empty;}
 }
 const raw=recordGeometry(rec),mapPoint=p=>parent(sqPreviewPointToWcs(rec,p,10)),layer=recordString(rec,8)||'0',aci=pairVal(rec,62),tc=pairVal(rec,420),lw=pairVal(rec,370),lt=recordString(rec,6)||'CONTINUOUS';
 if(['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(rec.type)){raw.pts.length=0;raw.segments.length=0;}
 const style={layer,aci,trueColor:tc,lineweight:lw,linetype:lt.toUpperCase(),entityType:rec.type};
 for(let i=0;i<raw.pts.length&&budget.points<budget.maxPoints;i++){empty.pts.push({...mapPoint(raw.pts[i]),...style,pointEntity:rec.type==='POINT'});budget.points++;}
 if(raw.pts.length>0&&budget.points>=budget.maxPoints)budget.truncated=true;
 for(let i=0;i<raw.segments.length&&budget.segments<budget.maxSegments;i++){const seg=raw.segments[i];empty.segments.push({a:mapPoint(seg.a),b:mapPoint(seg.b),...style});budget.segments++;}
 if(raw.segments.length>0&&budget.segments>=budget.maxSegments)budget.truncated=true;
 if(['TEXT','MTEXT','ATTRIB','ATTDEF','DIMENSION','MLEADER','LEADER'].includes(rec.type)&&budget.texts<budget.maxTexts){
  const type=String(rec.type||'').toUpperCase(),prefers11=['TEXT','ATTRIB','ATTDEF'].includes(type)&&((pairVal(rec,72)||0)!==0||(pairVal(rec,73)||0)!==0)&&pointAt(rec,11),code=prefers11?11:(pointAt(rec,10)?10:11),p=pointAt(rec,code),txt=rec.pairs.filter(x=>x.code===1||x.code===3).map(x=>x.value).join('');
  if(p&&txt){const w=parent(sqPreviewPointToWcs(rec,p,code)),dir0=sqPreviewTextDirection(rec,pairVal(rec,50)||0),dir=parent.vector?parent.vector(dir0):dir0,rotation=Math.atan2(dir.y,dir.x)*180/Math.PI;
   empty.texts.push({p:w,text:txt.replace(/\P/g,' ').replace(/[{}]/g,' ').trim().slice(0,250),...style,height:pairVal(rec,40)||2.5,rotation});budget.texts++;if(budget.points<budget.maxPoints){empty.pts.push({...w,...style,pointEntity:false});budget.points++;}else budget.truncated=true;}
 }else if(budget.texts>=budget.maxTexts)budget.truncated=true;
 return empty;
}
'''

def exactly_one(text: str, old: str, new: str, label: str) -> str:
    n=text.count(old)
    if n!=1: raise ValueError(f'{label}: expected exactly one match, got {n}')
    return text.replace(old,new,1)

def patch(source: str) -> tuple[str,dict]:
    # Modify only the active dual-board orientation module.
    m=re.search(r'(<script\b(?=[^>]*\bid=["\']'+re.escape(SCRIPT_ID)+r'["\'])[^>]*>)([\s\S]*?)(</script\s*>)',source,re.I)
    if not m: raise ValueError('active dual-board orientation module not found')
    body=m.group(2)
    if source.count(OLD_VERSION)!=1: raise ValueError('expected one V148 version constant in the full source')
    source=source.replace(OLD_VERSION,NEW_VERSION,1)
    # Re-find the module offsets because the version replacement may precede this script.
    m=re.search(r'(<script\b(?=[^>]*\bid=[\"\']'+re.escape(SCRIPT_ID)+r'[\"\'])[^>]*>)([\s\S]*?)(</script\s*>)',source,re.I)
    if not m: raise ValueError('active dual-board orientation module disappeared after version bump')
    body=m.group(2)

    point_anchor="function pointAt(rec,xcode,idx=0){const x=pairVal(rec,xcode,idx),y=pairVal(rec,xcode+10,idx);return x===null||y===null?null:{x,y};}\n"
    if body.count(point_anchor)!=1: raise ValueError('pointAt anchor missing or duplicated')
    body=body.replace(point_anchor,point_anchor+HELPERS,1)

    start=body.find('function geometryInWorld(')
    end=body.find('function distPointSeg(',start)
    if start<0 or end<0: raise ValueError('geometryInWorld section boundaries not found')
    body=body[:start]+GEOMETRY+body[end:]

    old_point="const point=(rec,baseCode)=>{const x=pairNumber(rec,baseCode,NaN),y=pairNumber(rec,baseCode+10,NaN);return Number.isFinite(x)&&Number.isFinite(y)?{x,y}:null;};"
    new_point="const point=(rec,baseCode)=>{const x=pairNumber(rec,baseCode,NaN),y=pairNumber(rec,baseCode+10,NaN);return Number.isFinite(x)&&Number.isFinite(y)?sqPreviewPointToWcs(rec,{x,y},baseCode):null;};"
    body=exactly_one(body,old_point,new_point,'axis-label point conversion')

    old_insert="if(type==='INSERT'){const name=pairString(rec,2).toUpperCase(),block=blocks&&blocks.get(name);if(!block||stack.includes(name))return;const ins=point(rec,10)||{x:0,y:0},sx=pairNumber(rec,41,1)||1,sy=pairNumber(rec,42,1)||1,ang=pairNumber(rec,50,0)*Math.PI/180,co=Math.cos(ang),si=Math.sin(ang),bx=block.base?.x||0,by=block.base?.y||0;const local={a:co*sx,b:-si*sy,c:si*sx,d:co*sy,tx:ins.x-co*sx*bx+si*sy*by,ty:ins.y-si*sx*bx-co*sy*by},next=compose(m,local);stack.push(name);for(const child of block.entities||[]){if(visited>=maxVisited){base.previewTruncated=true;break;}walk(child,next,layer,depth+1);}stack.pop();return;}"
    new_insert="if(type==='INSERT'){const name=pairString(rec,2).toUpperCase(),block=blocks&&blocks.get(name);if(!block||stack.includes(name))return;const local=sqPreviewInsertMatrix(rec,block.base),next=compose(m,local);stack.push(name);for(const child of block.entities||[]){if(visited>=maxVisited){base.previewTruncated=true;break;}walk(child,next,layer,depth+1);}stack.pop();return;}"
    body=exactly_one(body,old_insert,new_insert,'nested INSERT label transform')

    # Rewrite text label placement so WCS direction vectors follow both OCS basis and nested block transform.
    at=body.find(' function addText(rec,m,inheritedLayer){')
    until=body.find('\n function walk(',at)
    if at<0 or until<0: raise ValueError('axis text label function boundaries missing')
    add_text=r''' function addText(rec,m,inheritedLayer){
  if((base.texts||[]).length>=18000){base.previewTruncated=true;return;}
  const type=String(rec.type||'').toUpperCase();if(!['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(type))return;
  const raw=textLabel(rec);if(!isAxis(raw))return;
  const xcode=(type==='TEXT'||type==='ATTRIB'||type==='ATTDEF')&&(pairNumber(rec,72,0)!==0||pairNumber(rec,73,0)!==0)&&point(rec,11)?11:10;
  const p=point(rec,xcode);if(!p)return;const w=mapPoint(m,p),label=decodeValue(raw).replace(/\\P/gi,' ').replace(/[{}]/g,' ').trim();if(!Number.isFinite(w.x)||!Number.isFinite(w.y))return;
  const theta=pairNumber(rec,50,0),dir0=sqPreviewTextDirection(rec,theta),dir={x:m.a*dir0.x+m.b*dir0.y,y:m.c*dir0.x+m.d*dir0.y},angle=Math.atan2(dir.y,dir.x)*180/Math.PI;
  const layer=pairString(rec,8)||'0',effectiveLayer=layer==='0'&&inheritedLayer?inheritedLayer:layer,det=Math.abs(m.a*m.d-m.b*m.c),scale=Math.sqrt(Math.max(1e-12,det));
  const tx={p:{x:w.x,y:w.y},text:label,height:Math.abs(pairNumber(rec,40,2.5))*scale,rotation:angle,layer:effectiveLayer,aci:pairNumber(rec,62,256),trueColor:Number.isFinite(pairNumber(rec,420,NaN))?pairNumber(rec,420,NaN):null};
  const duplicate=(base.texts||[]).findIndex(t=>String(t.text||'').trim().toUpperCase()===label.toUpperCase()&&t.p&&Math.hypot(t.p.x-w.x,t.p.y-w.y)<1e-4);
  if(duplicate>=0){base.texts[duplicate]={...base.texts[duplicate],...tx};return;}
  base.texts.push(tx);base.anchors.push({x:w.x,y:w.y,layer:effectiveLayer,pointEntity:false});
 }'''
    body=body[:at]+add_text+body[until:]

    # Reorder parsePreview: scan records first, detect non-canonical OCS, then select parser/fallback. This avoids parsing a large DXF before knowing it requires WCS conversion.
    start=body.find('function parsePreview(bytes){')
    if start<0: raise ValueError('parsePreview function not found')
    init_end=body.find(" if(!base)base={segs:[],anchors:[],texts:[]",start)
    if init_end<0: raise ValueError('parsePreview initialization boundary not found')
    oldprefix=body[start:init_end]
    newprefix=r'''function parsePreview(bytes){
 const MEMORY_SAFE_PREVIEW_BYTES=1500000;
 const parsed=splitPairs(bytes),allSpaces=sectionRecords(parsed.pairs,'ENTITIES'),blocks=blockDefinitions(parsed.pairs),parsedLayers=layerDefinitions(parsed.pairs);
 const isPaperRec=rec=>(rec.pairs||[]).some(p=>p.code===67&&Number(p.value)===1)||(rec.pairs||[]).some(p=>p.code===410&&String(p.value||'').trim().toUpperCase()!=='MODEL');
 const hasWorldXY=rec=>{const codes=new Set((rec.pairs||[]).map(p=>p.code));for(let x=10;x<=18;x++)if(codes.has(x)&&codes.has(x+10))return true;return ['POINT','INSERT','HATCH','DIMENSION'].includes(rec.type);};
 const modelSpaceRecords=allSpaces.filter(r=>!isPaperRec(r)),paperSpaceRecords=allSpaces.filter(isPaperRec);
 const all=modelSpaceRecords.some(hasWorldXY)?modelSpaceRecords:paperSpaceRecords;
 const nestedRecords=[];for(const b of blocks.values())for(const rec of b.entities||[])nestedRecords.push(rec);
 const needsWcsPreview=[...all,...nestedRecords].some(sqPreviewHasNonCanonicalOcs);
 const api=window.__sqManualOrientation109;let base=null,primaryError=null;
 if(needsWcsPreview)primaryError=new Error('تم تفعيل معاينة WCS لأن اللوحة تحتوي على عناصر OCS بمحاور غير قياسية.');
 else if(bytes.length<=MEMORY_SAFE_PREVIEW_BYTES&&api&&typeof api.parseDrawing==='function'){try{base=api.parseDrawing(bytes);}catch(e){primaryError=e;}}
 else primaryError=new Error('تم استخدام مسار المعاينة منخفض الذاكرة لهذا الملف الكبير.');
 let usedFallback=!base;
'''
    body=body[:start]+newprefix+body[init_end:]
    # Expose why WCS preview was selected and don't hide preview warnings from the user.
    body=exactly_one(body,"base.previewLowMemory=bytes.length>MEMORY_SAFE_PREVIEW_BYTES;","base.previewLowMemory=bytes.length>MEMORY_SAFE_PREVIEW_BYTES;base.previewWcsFallback=needsWcsPreview;",'WCS preview diagnostics')
    # Shrink the actual canvas, not only a hidden/legacy screen.
    body=body.replace('height:44vh;min-height:250px;max-height:500px','height:38vh;min-height:220px;max-height:420px')
    if 'height:38vh;min-height:220px;max-height:420px' not in body: raise ValueError('dual-board preview height was not changed')
    # Make the feature/version visibly distinguishable in the live alignment screen.
    body=exactly_one(body,'<h2>🧭 توجيه لوحة إلى لوحة مرجعية بالنقطتين</h2>','<h2>🧭 Alignment كامل للوحة | WCS • V149</h2>', 'live dialog heading')
    source=source[:m.start(2)]+body+source[m.end(2):]
    source=exactly_one(source,'id="surveyquant-v148-fresh-board-session"','id="surveyquant-v149-fresh-board-session"','fresh-session version tag')
    # Catch preview warnings/truncation instead of hiding them in the status text.
    old_info="if(info)info.textContent='الملف: '+file.name+' | العناصر: '+view.drawing.entityCount+' | المعاينة هندسية؛ كائنات CAD الغامضة تُرفض قبل الإخراج بدل تركها في موقعها القديم.';status('تم فتح '+file.name+'. اختر النقطة 1 ثم 2؛ سيظهر رقم كل نقطة تلقائيًا على الرسم.'+(view.drawing.previewRecoveryMessage?' '+view.drawing.previewRecoveryMessage:''));"
    new_info="if(info)info.textContent='الملف: '+file.name+' | العناصر: '+view.drawing.entityCount+' | المعاينة: '+(view.drawing.previewWcsFallback?'WCS/OCS مصحح':view.drawing.previewLowMemory?'وضع ذاكرة منخفضة':'عادي')+(view.drawing.previewTruncated?' | تنبيه: المعاينة محدودة':'')+' | كائنات CAD الغامضة تُفحص قبل الإخراج.';status('تم فتح '+file.name+'. اختر النقطة 1 ثم 2؛ سيظهر رقم كل نقطة تلقائيًا على الرسم.'+(view.drawing.previewWarning?' تنبيه المعاينة: '+view.drawing.previewWarning:'')+(view.drawing.previewRecoveryMessage?' '+view.drawing.previewRecoveryMessage:''));"
    source=exactly_one(source,old_info,new_info,'user-facing preview diagnostics')
    return source,{'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'wcs_fallback_for_noncanonical_ocs':True,'insert_ocs_basis':True,'axis_label_wcs':True,'new_version':149}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--input-html',type=Path,required=True)
    p.add_argument('--output-html',type=Path,required=True)
    p.add_argument('--report',type=Path,required=True)
    a=p.parse_args()
    source=a.input_html.read_text(encoding='utf-8')
    result,details=patch(source)
    a.output_html.parent.mkdir(parents=True,exist_ok=True)
    a.output_html.write_text(result,encoding='utf-8',newline='')
    a.report.write_text(
      '# V149 WCS Preview / Axis Root Cause Fix\n\n'
      '- V148 source hash was preserved as input; active dual-board orientation module patched.\n'
      '- WCS/OCS basis conversion now happens before point snapping, bounds, and canvas projection.\n'
      '- INSERT placement transforms include the extrusion normal and nested block coordinates.\n'
      '- Axis text extraction reads OCS points into WCS and maps text direction through nested inserts.\n'
      '- Non-canonical OCS files use the corrected WCS preview path before the legacy parser can supply raw local XY.\n'
      '- Dual-board screen height reduced to 38vh (220-420px).\n'
      '- APK version code/name updated to 149/1.0.149.\n\n'
      f"- Source SHA-256: `{details['source_sha256']}`\n",encoding='utf-8')
    print(f"PASS: patched V148 to V149; source SHA-256 {details['source_sha256']}")
if __name__=='__main__':main()
