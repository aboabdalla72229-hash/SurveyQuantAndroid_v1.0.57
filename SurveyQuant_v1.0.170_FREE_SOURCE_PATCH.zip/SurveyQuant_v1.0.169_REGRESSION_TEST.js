'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const cad = require('./SurveyQuant_v1.0.169_CAD_ENGINE.js');

function blockAxisFixture(){
  const p=[
    '0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','0','ENDSEC',
    '0','SECTION','2','BLOCKS',
    '0','BLOCK','5','20','100','AcDbEntity','8','0','100','AcDbBlockBegin','2','GRID_AXES','10','0','20','0','30','0',
    '0','XLINE','8','GRID_AXES','10','0','20','0','30','0','11','1','21','0','31','0',
    '0','RAY','8','GRID_AXES','10','0','20','0','30','0','11','0','21','1','31','0',
    '0','TEXT','8','GRID_LABELS','10','0','20','5','30','0','40','1.5','1','A-1',
    '0','ENDBLK','5','21','100','AcDbEntity','8','0','100','AcDbBlockEnd','0','ENDSEC',
    '0','SECTION','2','ENTITIES',
    '0','INSERT','5','50','100','AcDbEntity','8','0','100','AcDbBlockReference','2','GRID_AXES','10','500','20','900','30','0','41','1','42','1','43','1','50','0',
    '0','ENDSEC','0','EOF',''
  ];
  return new TextEncoder().encode(p.join('\r\n'));
}

function testBlockAxesAndLabels(){
  const raw=blockAxisFixture();
  const original=Buffer.from(raw).toString('hex');
  const g=cad.readGeometry(raw);
  assert.strictEqual(g.segments.length,2,'block XLINE and RAY must both materialize after INSERT extents are known');
  assert(g.segments.every(s=>[s.a.x,s.a.y,s.b.x,s.b.y].every(Number.isFinite)),'block axes must never contain NaN/Infinity');
  assert(g.texts.some(t=>t.text==='A-1'),'block-contained axis label should be retained');
  assert.deepStrictEqual(Buffer.from(raw).toString('hex'),original,'reading must not mutate source DXF');
  const picks=[{x:500,y:900},{x:600,y:900},{x:2000,y:3000},{x:2000,y:3200}];
  const saved=cad.createOrientedDxfBytes(raw,picks);
  assert(saved.bytes instanceof Uint8Array && saved.bytes.length>raw.length,'orientation save must return a new DXF byte stream');
  assert.strictEqual(saved.rotationDegrees,90);
  assert.strictEqual(saved.scale,2);
  const moved=cad.readGeometry(saved.bytes);
  assert.strictEqual(moved.segments.length,2,'saved oriented DXF must retain both block axes');
  assert(moved.texts.some(t=>t.text==='A-1'),'saved oriented DXF must retain axis labels');
  assert(Math.abs(moved.texts.find(t=>t.text==='A-1').position.x-1990)<1e-8);
  assert(Math.abs(moved.texts.find(t=>t.text==='A-1').position.y-3000)<1e-8);
  assert(Math.abs(moved.segments[0].a.x-2000)<1e-8 && Math.abs(moved.segments[0].b.x-2000)<1e-8,'XLINE should rotate into a vertical axis');
  return {segments:g.segments.length,texts:g.texts.length,exportSegments:moved.segments.length,exportTexts:moved.texts.length};
}

function testSameBasenameFingerprint(){
  const fileA={name:'same-board.dwg',size:4,lastModified:12345};
  const fileB={name:'same-board.dwg',size:4,lastModified:12345};
  const fpA=cad.fileFingerprint(fileA,new Uint8Array([1,2,3,4]));
  const fpB=cad.fileFingerprint(fileB,new Uint8Array([1,2,3,5]));
  assert.notStrictEqual(fpA,fpB,'same name, same size and mtime but different content must have distinct fingerprints');
  return {fingerprintA:fpA.slice(-16),fingerprintB:fpB.slice(-16)};
}

function testSelfContainedPdfDxf(jpegPaths,outPath){
  const rects=[
    {x:0,y:0,width:1600,height:1132},
    {x:1600,y:0,width:1600,height:1132},
    {x:0,y:1132,width:1600,height:1132},
    {x:1600,y:1132,width:1600,height:1132},
  ];
  assert.strictEqual(jpegPaths.length,4,'Real PDF fixture must be split into four embedded tiles');
  const tiles=jpegPaths.map((path,i)=>({bytes:new Uint8Array(fs.readFileSync(path)),...rects[i]}));
  const dxf=cad.makeEmbeddedRasterDxf(tiles,3200,2264,1);
  fs.writeFileSync(outPath,dxf);
  const txt=Buffer.from(dxf).toString('latin1');
  assert.strictEqual((txt.match(/\nOLE2FRAME\r?\n/g)||[]).length,4,'DXF should contain four tiled OLE2FRAME objects');
  assert(!/\nIMAGE\r?\n|\nIMAGEDEF\r?\n|\.png/i.test(txt),'single-file DXF must not reference IMAGE/IMAGEDEF or PNG sidecar');
  assert(!txt.includes('PK\x03\x04'),'PDF export result must not be ZIP');
  return {dxfBytes:dxf.length,jpegBytes:tiles.reduce((n,t)=>n+t.bytes.length,0),tiles:tiles.length,maxTile:'1600x1132'};
}

const fixture=blockAxisFixture();
const result={
  blockAxesAndOrientationSave:testBlockAxesAndLabels(),
  sameBasenameFingerprint:testSameBasenameFingerprint(),
  api:{makeEmbeddedRasterDxf:typeof cad.makeEmbeddedRasterDxf,createOrientedDxfBytes:typeof cad.createOrientedDxfBytes,fileFingerprint:typeof cad.fileFingerprint},
};
if(process.argv.length>2){const a=process.argv.slice(2);result.pdfDxf=testSelfContainedPdfDxf(a.slice(0,-1),a[a.length-1]||path.join(process.cwd(),'v169-test.pdf.dxf'));}
console.log(JSON.stringify({ok:true,...result},null,2));
