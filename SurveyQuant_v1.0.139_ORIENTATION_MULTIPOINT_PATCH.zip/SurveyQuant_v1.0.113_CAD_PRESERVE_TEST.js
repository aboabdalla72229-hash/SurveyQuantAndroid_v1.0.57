'use strict';
const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const [enginePath, axisPath, manualPath, referencePath, recoveryPath, preservePath] = process.argv.slice(2);
assert([enginePath,axisPath,manualPath,referencePath,recoveryPath,preservePath].every(Boolean),'Usage: test.js v106.js v107.js v109.js v111.js v112.js v113.js');
const document={readyState:'loading',addEventListener(){},getElementById(){return null;}};
const window={addEventListener(){},removeEventListener(){}};
const ctx={window,document,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,Blob,URL,Math,Number,String,Map,Set,Array,Object,RegExp,Error,Infinity,Promise,JSON,parseInt,parseFloat,console};
vm.createContext(ctx);
for(const file of [enginePath,axisPath,manualPath,referencePath,recoveryPath,preservePath])vm.runInContext(fs.readFileSync(file,'utf8'),ctx,{filename:file});
const api=ctx.window.__sqOrientation113API;
const manual=ctx.window.__sqManualOrientation109;
const core=ctx.window.__sqOrientation111API;
const previewApi=ctx.window.__sqOrientation110API;
assert(api&&api.VERSION==='1.0.113','v113 API missing');
function dxf(lines){return new TextEncoder().encode(lines.join('\n')+'\n');}
function txt(bytes){return new TextDecoder().decode(bytes);}
const lines=['0','SECTION','2','HEADER','9','$ACADVER','1','AC1027','0','ENDSEC',
'0','SECTION','2','ENTITIES',
'0','LINE','8','ROAD','10','0','20','0','11','10','21','0',
'0','XLINE','8','AXIS','10','5','20','5','11','1','21','0',
'0','TEXT','8','LABELS','10','2','20','3','40','1','1','BUILDING_A',
'0','CIRCLE','8','CURVES','10','8','20','8','40','2',
'0','ENDSEC','0','EOF'];
const valid=dxf(lines);
const model=manual.parseDrawing(valid);
assert(model.segs.length>=25,'standard line/circle should remain rendered');
assert(model.texts.some(t=>String(t.text).includes('BUILDING_A')),'UTF-8 text should remain present');
assert(model.supplementalGeometryItems>0,'XLINE / previously omitted entity geometry should be supplemented');
const previewModel=previewApi.parsePreview(valid);
assert(previewModel.segs.length>=model.segs.length,'the actual board preview path should use supplemented geometry');

// Case 1: blank line inserted where the next group code should be. The normalizer
// removes only that empty physical line and preserves all entity records.
const sourceText=txt(valid);
const badCodeBlank=new TextEncoder().encode(sourceText.replace('\n0\nCIRCLE','\n\n0\nCIRCLE'));
const norm1=api.normalizeBlankPairLines(badCodeBlank);
assert(norm1.valid&&norm1.changed===1,'blank line on group-code row should be normalized');
const recovered1=manual.parseDrawing(badCodeBlank);
assert(recovered1.texts.some(t=>String(t.text).includes('BUILDING_A')),'text after blank-code-row recovery should survive');
assert(txt(norm1.bytes).includes('BUILDING_A'),'all text bytes should survive blank-row normalization');
const safeBlankExport=api.transformBytes(badCodeBlank,core.solve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220}));
assert(safeBlankExport.v113Validation&&safeBlankExport.v113Validation.blankLinesNormalized===1,'blank-row DXF should export only after lossless normalization');
assert(txt(safeBlankExport.bytes).includes('BUILDING_A'),'blank-row export must preserve non-empty drawing text');

// Case 2: blank line inserted between a code and its value.
const badValueBlank=new TextEncoder().encode(sourceText.replace('8\nROAD','8\n\nROAD'));
const norm2=api.normalizeBlankPairLines(badValueBlank);
assert(norm2.valid&&norm2.changed===1,'blank line between code and value should be normalized');
assert(txt(norm2.bytes).includes('ROAD'),'layer names must survive normalization');

// Two-point transform: structure, layer assignment, text, and entity count must
// be identical while the XY position changes. Original source bytes immutable.
const t=core.solve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
const inputCopy=valid.slice();
const result=api.transformBytes(valid,t);
assert.deepStrictEqual(Array.from(valid),Array.from(inputCopy),'original bytes must not mutate');
assert(result.v113Validation&&result.v113Validation.typeCountsUnchanged,'entity type counts must be validated');
assert.strictEqual(result.v113Validation.entitiesBefore,result.v113Validation.entitiesAfter,'entity count must remain identical');
assert(result.v113Validation.layerAssignmentsUnchanged&&result.v113Validation.textContentUnchanged,'layers/text must be preserved');
assert(txt(result.bytes).includes('BUILDING_A'),'Arabic text must be retained in export');
assert(/10\n100(?:\.0+)?\n20\n200(?:\.0+)?/.test(txt(result.bytes)),'first source coordinate should be translated to expected target frame');

// The v113 exporter must refuse unknown non-empty corruption rather than
// silently generating a partial DXF.
const badCorrupt=new TextEncoder().encode(sourceText.replace('0\nCIRCLE','NOT-A-CODE\nCIRCLE'));
assert.throws(()=>api.transformBytes(badCorrupt,t),/السطر|خلل بنيوي|إسقاط بيانات/,'unsafe corrupted files should not be exported');
console.log('PASS v1.0.113: blank-line DXF alignment fixed without dropping non-empty bytes; unsupported preview entities supplemented; type/layer/text/entity-count preservation validated; unsafe corrupt export rejected.');
