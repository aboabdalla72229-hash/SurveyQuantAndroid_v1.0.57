'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const engine = require('./SurveyQuant_v1.0.181_CAD_ENGINE.js');

function near(a,b,t=1e-7){assert.ok(Math.abs(a-b)<=t,`${a} != ${b} within ${t}`);}

// Large UTM-like coordinates: this catches the global-origin rotation/cancellation defect.
const picks=[
  {x:576761.446,y:858279.357},
  {x:576771.446,y:858279.357},
  {x:1934000.000,y:2500000.000},
  {x:1934000.000,y:2500020.000},
];
const diag=engine.alignmentDiagnostics(picks);
near(diag.rotationDegrees,90,1e-9);
near(diag.scale,2,1e-12);
near(diag.residualA,0,1e-8);
near(diag.residualB,0,1e-8);
assert.ok(Math.abs(diag.translationX)>1e6 && Math.abs(diag.translationY)>1e6,'expected nonzero global translation');

// Arbitrary angle and different scale/translation.
const p2=[
  {x:612345.12,y:3344556.78},
  {x:612355.12,y:3344556.78},
  {x:2300100.5,y:3520000.25},
  {x:2300114.6421356237,y:3520014.3921356237},
];
const d2=engine.alignmentDiagnostics(p2);
assert.ok(Math.abs(d2.rotationDegrees-45)<1e-8,`unexpected second rotation ${d2.rotationDegrees}`);
near(d2.scale,2,1e-8);
near(d2.residualA,0,1e-7); near(d2.residualB,0,1e-7);

// Exact DXF record transform: the source baseline must map to the target baseline.
const raw=new TextEncoder().encode([
 '0','SECTION','2','HEADER','9','$ACADVER','1','AC1009','0','ENDSEC',
 '0','SECTION','2','ENTITIES','0','LINE','5','10','8','0',
 '10','576761.446','20','858279.357','30','0',
 '11','576771.446','21','858279.357','31','0',
 '0','ENDSEC','0','EOF',''
].join('\n'));
const oriented=engine.createOrientedDxfBytes(raw,picks);
assert.equal(oriented.rotationDegrees,90); near(oriented.scale,2,1e-12); assert.ok(oriented.editCount>=4);
const out=new TextDecoder().decode(oriented.bytes);
assert.match(out,/10\n1934000\n20\n2500000/);
assert.match(out,/11\n1934000\n21\n2500020/);

// Identity is a deliberate rejection, not a silent zero transform.
assert.throws(()=>engine.createOrientedDxfBytes(raw,[
 {x:100,y:200},{x:110,y:200},{x:100,y:200},{x:110,y:200}
]),/بلا أي تغيير/);

// Overlay two actual DXF fixture files as native records, not traced/rebuilt geometry.
const root=__dirname;
const source=new Uint8Array(fs.readFileSync(path.join(root,'source_A.dxf')));
const target=new Uint8Array(fs.readFileSync(path.join(root,'target_B.dxf')));
const merged=engine.mergeRawDxfBoards(target,source);
assert.ok(merged.bytes.length>target.length);
assert.ok(merged.importedEntities>=1);
const mergedText=new TextDecoder('windows-1252').decode(merged.bytes);
assert.match(mergedText,/\nENTITIES\n/); assert.ok(mergedText.trim().endsWith('EOF'));
fs.writeFileSync(path.join(root,'V181_TWO_DXF_MERGE_ENGINE_TEST.dxf'),merged.bytes);

// Arabic must be kept as DXF Unicode escapes exactly once, not replaced by '?'.
const pdfDxf=engine.polylinesToDxf([],400,300,1,[{text:'محور A-١',x:10,y:20,height:8,width:40,rgb:0x13a6d8}]);
const pdfText=new TextDecoder().decode(pdfDxf.bytes);
assert.match(pdfText,/\\U\+0645/); assert.match(pdfText,/\\U\+0661/);
assert.ok(!pdfText.includes('1\n???'));
assert.match(pdfText,/420\n1287896/); // 0x13A6D8 true RGB

console.log(JSON.stringify({
  orientation:{rotation:diag.rotationDegrees,scale:diag.scale,translation:[diag.translationX,diag.translationY],residuals:[diag.residualA,diag.residualB]},
  arbitrary:{rotation:d2.rotationDegrees,scale:d2.scale},
  orientedDxf:{bytes:oriented.bytes.length,editedRecords:oriented.editCount},
  dualDxfMerge:{bytes:merged.bytes.length,entities:merged.importedEntities,blocks:merged.importedBlocks,layers:merged.importedLayers},
  arabicText:{unicodeEscape:true,trueColor:true},
  result:'PASS'
},null,2));
