'use strict';
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const file = process.argv[2];
if (!file || !fs.existsSync(file)) throw new Error('Usage: node TEST.js index.html');
const html = fs.readFileSync(file, 'utf8');
function region(startToken, endToken) {
  const a = html.indexOf(startToken);
  assert(a >= 0, `missing: ${startToken}`);
  const b = html.indexOf(endToken, a + startToken.length);
  assert(b > a, `missing boundary: ${endToken}`);
  return html.slice(a, b);
}

assert(html.includes('SURVEYQUANT_V131_ENGINEERING_CAD_PRESERVE'), 'V131 marker missing');
assert(!/\<option\s+value="auto_low"/.test(html), 'auto_low must be removed from all UI selectors');
const singleCalc = region('async function loadAndAnalyze(){', 'function validateGeneratedDXF(content){');
assert(!singleCalc.includes('lowestClosedContour') && !singleCalc.includes('autoLowBoundaryLevel'), 'single surface still depends on perimeter contour');
assert(singleCalc.includes('الحفر Cut') && singleCalc.includes('الردم Fill'), 'single surface cut/fill output missing');
const standAlone = region('function calculateStandaloneSurfaceStats(model,typeId,targetId){', 'function attachComparisonQuantities(');
assert(!standAlone.includes('lowestClosedContour') && !standAlone.includes('clipConvexPolygon'), 'independent quantity is still perimeter-clipped');
assert(standAlone.includes('net:fill-cut'), 'independent net volume missing');
const comparison = region('function attachComparisonQuantities(', 'function sqBBoxTriangle(');
assert(comparison.includes("calculateStandaloneSurfaceStats({points:before},'cmpBeforeLevelType'") && comparison.includes("calculateStandaloneSurfaceStats({points:after},'cmpAfterLevelType'"), 'both layers must be independently calculated');
assert(comparison.includes('quantityDifference:standaloneAfter.net-standaloneBefore.net'), 'difference of separate quantities missing');
const report = region('async function compareQuantLayers(){', 'function downloadQuantComparisonDXF()');
assert(report.includes('حصر الطبقة الأولى مستقلًا') && report.includes('حصر الطبقة الثانية مستقلًا') && report.includes('المقارنة الفعلية بين الطبقتين على المساحة المشتركة'), 'report must present both independent quantities then comparison');

const orient = region('function parsePreview(bytes){', 'function loadView(side,bytes,name)');
assert(!/for\(const rec of all\)\{if\(usedFallback\)\{addGeometry/.test(orient), 'duplicate composite geometry expansion returned');
assert(orient.includes('Re-expanding records here duplicates complex lines') && orient.includes('fallbackPreviewTypes'), 'orientation preview single-pass protection missing');

const genericExport = region('async function exportModelDrawing(model,title,base,kind){', 'function exportCADDrawing(k)');
assert(genericExport.includes("kind==='dxf'&&model.rawDXFBytes instanceof Uint8Array"), 'DXF pass-through bytes not used');
const profileExport = region('function buildProfileDXFWithOriginal(rows,model,layer,fmt){', 'function validateProfileDXFOutput(content,model){');
assert(profileExport.includes('if(model?.rawDXFBytes instanceof Uint8Array)'), 'profile output must preserve raw DXF for converted DWG too');
const mergeProj = region('async function dropFilesMerge(){', 'function downloadDroppedDXF()');
assert(mergeProj.includes('if(targetModel.rawDXFBytes instanceof Uint8Array)') && mergeProj.includes('mergeProjectionDxfPreservingReference(targetModel.rawDXFBytes,additions)'), 'DWG projection must preserve converted source bytes');
const quantOut = region('async function downloadQuantDXF(){', 'async function inspectCAD()');
assert(quantOut.includes('mergeProjectionDxfPreservingReference(cadModel.rawDXFBytes,additions)'), 'quantities output must overlay source CAD bytes rather than reconstruct it');
assert(quantOut.includes('CAD_PRESERVED.dxf'), 'source-preserving output filename missing');
assert(html.includes("function exportProfileDrawing(k){if(k==='dxf')return downloadProfileDXF()"), 'profile export must use preservation path');

// Runtime regression: when raw CAD bytes exist, generic DXF export must return a byte-for-byte copy,
// even if none of the drawing entity types are understood by the preview parser.
const expMatch = genericExport.match(/async function exportModelDrawing\(model,title,base,kind\)\{[\s\S]*?\n\}/);
assert(expMatch, 'exportModelDrawing runtime body missing');
let downloaded = null;
const ctx = {
  Uint8Array,
  safeDownloadFile: async (data, name, mime) => { downloaded = {data, name, mime}; return true; },
  buildR12FromEntities: () => { throw new Error('Should not reconstruct an original CAD file'); },
  alert: () => { throw new Error('Unexpected alert during raw DXF export'); }
};
vm.createContext(ctx);
vm.runInContext(expMatch[0], ctx);
const originalBytes = new Uint8Array([0, 1, 13, 10, 255, 65, 0, 66]);
ctx.originalBytes = originalBytes;
vm.runInContext("exportModelDrawing({rawDXFBytes:originalBytes,entities:[]},'CAD','test_native','dxf')", ctx).then(() => {
  assert(downloaded, 'download not called');
  assert.deepStrictEqual(Array.from(downloaded.data), Array.from(originalBytes), 'native CAD bytes were changed');
  assert.strictEqual(downloaded.name, 'test_native.dxf');

  // Runtime regression: successful primary orientation parsing must never invoke the second geometry expander.
  const parseMatch = orient.match(/function parsePreview\(bytes\)\{[\s\S]*?\n\}/);
  assert(parseMatch, 'parsePreview runtime body missing');
  let expansionCalls = 0;
  const baseDrawing = {
    segs: [{a:{x:0,y:0},b:{x:10,y:0},layer:'AXIS'}],
    anchors: [{x:0,y:0,layer:'AXIS'}],
    texts: [{p:{x:1,y:1},text:'A1',layer:'AXIS',height:2.5}],
    layers: {}, entityCount: 3, unsupported: 0
  };
  const ctx2 = {
    window: {__sqManualOrientation109: {parseDrawing: () => baseDrawing}},
    splitPairs: () => ({pairs:[], recoveryCount:0}),
    sectionRecords: () => [{type:'HATCH'}, {type:'DIMENSION'}],
    blockDefinitions: () => new Map(), layerDefinitions: () => ({}),
    geometryInWorld: () => { expansionCalls++; return {pts:[],segments:[{a:{x:1,y:1},b:{x:2,y:2}}],texts:[]}; }
  };
  vm.createContext(ctx2);
  vm.runInContext(parseMatch[0], ctx2);
  const parsed = vm.runInContext('parsePreview(new Uint8Array([1,2,3]))', ctx2);
  assert.strictEqual(expansionCalls, 0, 'complex entities were redundantly expanded');
  assert.strictEqual(parsed.segs.length, 1, 'preview segments were duplicated');
  assert(parsed.texts.some(t => t.text === 'A1'), 'axis label/text was lost from preview');
  assert(parsed.unsupported >= 2, 'complex entity indicators are not counted');
  console.log('PASS: V131 CAD preservation, orientation single-pass preview, independent layer quantities, and removed perimeter-contour quantity method.');
}).catch(e => { console.error(e); process.exitCode = 1; });
