#!/usr/bin/env python3
"""V173 runtime bootstrap repair for read-only PDF.js and startup callback crash."""
from __future__ import annotations
import argparse, re, base64
from pathlib import Path

META = '<meta name="surveyquant-v173" content="sq173-pdfjs-readonly-getdocument-runtime-startup-fix">'
OLD_GUARD = "function installGlobalPdfWorkerGuard(){var lib=window.pdfjsLib;if(!lib||!lib.GlobalWorkerOptions||typeof lib.getDocument!=='function')throw new Error('تعذر تثبيت عامل PDF.js العام للمشروعات.');var url=makePdfWorkerUrl();lib.GlobalWorkerOptions.workerSrc=url;if(lib.getDocument.__sqV170WorkerGuard)return;var original=lib.getDocument;var guarded=function(){var current=window.__sq163PdfWorkerUrl||url;lib.GlobalWorkerOptions.workerSrc=current;return original.apply(this,arguments);};Object.defineProperty(guarded,'__sqV170WorkerGuard',{value:true});lib.getDocument=guarded;window.ensureSurveyQuantPdfWorker=function(){var active=window.__sq163PdfWorkerUrl||url;lib.GlobalWorkerOptions.workerSrc=active;return active;};}"
NEW_GUARD = """function installGlobalPdfWorkerGuard(){
  var lib=window.pdfjsLib;
  if(!lib||!lib.GlobalWorkerOptions||typeof lib.getDocument!=='function')throw new Error('تعذر تثبيت عامل PDF.js العام للمشروعات.');
  var url=makePdfWorkerUrl();
  // PDF.js 4+ exposes getDocument as a getter-only property. Never replace it.
  // The supported worker configuration point is GlobalWorkerOptions.workerSrc.
  lib.GlobalWorkerOptions.workerSrc=url;
  window.ensureSurveyQuantPdfWorker=function(){
    var active=window.__sq163PdfWorkerUrl||url;
    lib.GlobalWorkerOptions.workerSrc=active;
    return active;
  };
  if(lib.GlobalWorkerOptions.workerSrc!==url)throw new Error('لم يتم تثبيت مسار عامل PDF.js المضمّن.');
}"""
OLD_STALE_CALL = 'showQuantMode(\'compare\');renderLandSideRows();renderImageSideRows();'
NEW_STALE_CALL = 'showQuantMode(\'compare\');renderLandSideRows();'
OLD_CATCH = "}catch(e){window.__sq163RuntimeError=String(e&&e.message||e);console.error('SurveyQuant V163 runtime initialization failed',e);}"
NEW_CATCH = """}catch(e){
    window.__sq163RuntimeError=String(e&&e.message||e||'خطأ غير معروف أثناء تشغيل محرك المشاريع');
    try{window.dispatchEvent(new CustomEvent('surveyquant-cad-error',{detail:{message:window.__sq163RuntimeError}}));}catch(_){}
    console.error('SurveyQuant V163 runtime initialization failed',e);
  }"""
OLD_READY = "window.__sq163RuntimeReady=true;window.dispatchEvent(new CustomEvent('surveyquant-cad-ready'));"
NEW_READY = """if(!document.getElementById('sq162-cad-overlay'))window.SurveyQuantCAD163.mount();
   var cadOverlay=document.getElementById('sq162-cad-overlay');
   if(!cadOverlay||!cadOverlay.querySelector('[data-tab=align]')||!cadOverlay.querySelector('[data-tab=raster]'))throw new Error('تم تحميل محرك CAD لكن نافذة المشروعات لم تكتمل.');
   window.__sq163RuntimeReady=true;window.dispatchEvent(new CustomEvent('surveyquant-cad-ready'));"""
OLD_HELPER = """<script id="sq172-home-shortcuts-handler">
(function(){
  'use strict';
  window.sq172OpenCadProject=function(tabName){
    var open=function(){
      var launch=document.getElementById('sq162-cad-launch');
      var overlay=document.getElementById('sq162-cad-overlay');
      if(!launch||!overlay)return false;
      overlay.style.display='flex';
      var tab=overlay.querySelector('[data-tab="'+tabName+'"]');
      if(tab)tab.click();
      return true;
    };
    if(open())return;
    var onReady=function(){if(!open())window.alert('تعذر فتح المشروع. أغلق التطبيق وافتحه مرة أخرى.');};
    window.addEventListener('surveyquant-cad-ready',onReady,{once:true});
    window.setTimeout(function(){
      window.removeEventListener('surveyquant-cad-ready',onReady);
      if(!document.getElementById('sq162-cad-overlay'))window.alert('محرك المشروع لم يكتمل تشغيله. راجع ملفات التطبيق ثم أعد فتحه.');
    },15000);
  };
})();
</script>"""
NEW_HELPER = """<script id="sq173-home-shortcuts-handler">
(function(){
  'use strict';
  window.sq172OpenCadProject=function(tabName){
    var finished=false,timer=null;
    var cleanup=function(){if(finished)return;finished=true;window.removeEventListener('surveyquant-cad-ready',onReady);window.removeEventListener('surveyquant-cad-error',onError);if(timer)window.clearTimeout(timer);};
    var open=function(){
      var overlay=document.getElementById('sq162-cad-overlay');
      if(!overlay)return false;
      var tab=overlay.querySelector('[data-tab="'+tabName+'"]');
      if(!tab)return false;
      overlay.style.display='flex';tab.click();return true;
    };
    var onReady=function(){cleanup();if(!open())window.alert('اكتمل تحميل المحرك لكن تبويب المشروع غير موجود: '+tabName);};
    var onError=function(e){cleanup();var msg=e&&e.detail&&e.detail.message||window.__sq163RuntimeError||'خطأ غير معروف';window.alert('تعذر تشغيل محرك المشاريع: '+msg);};
    if(window.__sq163RuntimeError){onError({detail:{message:window.__sq163RuntimeError}});return;}
    if(open())return;
    window.addEventListener('surveyquant-cad-ready',onReady);
    window.addEventListener('surveyquant-cad-error',onError);
    timer=window.setTimeout(function(){cleanup();if(!open())window.alert('انتهت مهلة تحميل محرك المشاريع. أعد فتح التطبيق وأرسل تقرير التشخيص.');},20000);
  };
})();
</script>"""

def patch_html(html: str) -> str:
    if 'sq172-static-visible-home-project-shortcuts-pdf-image-pair' not in html:
        raise ValueError('V172 baseline marker missing')
    if 'sq173-pdfjs-readonly-getdocument-runtime-startup-fix' in html:
        raise ValueError('V173 already applied')
    if html.count(OLD_GUARD) != 1:
        raise ValueError(f'Expected exactly one old PDF.js guard, found {html.count(OLD_GUARD)}')
    html = html.replace(OLD_GUARD, NEW_GUARD, 1)
    if html.count(OLD_STALE_CALL) != 1:
        raise ValueError(f'Expected one stale renderImageSideRows call, found {html.count(OLD_STALE_CALL)}')
    html = html.replace(OLD_STALE_CALL, NEW_STALE_CALL, 1)
    if html.count(OLD_CATCH) != 1:
        raise ValueError(f'Expected one runtime catch, found {html.count(OLD_CATCH)}')
    html = html.replace(OLD_CATCH, NEW_CATCH, 1)
    if html.count(OLD_READY) != 1:
        raise ValueError(f'Expected one runtime ready point, found {html.count(OLD_READY)}')
    html = html.replace(OLD_READY, NEW_READY, 1)
    if html.count(OLD_HELPER) != 1:
        raise ValueError(f'Expected one V172 home handler, found {html.count(OLD_HELPER)}')
    html = html.replace(OLD_HELPER, NEW_HELPER, 1)
    html = html.replace('<head>', '<head>' + META, 1)
    validate(html)
    return html

def validate(html: str) -> None:
    required = [
      'sq173-pdfjs-readonly-getdocument-runtime-startup-fix',
      'PDF.js 4+ exposes getDocument as a getter-only property. Never replace it.',
      'lib.GlobalWorkerOptions.workerSrc=url;',
      'window.ensureSurveyQuantPdfWorker=function()',
      'sq173-home-shortcuts-handler',
      "window.addEventListener('surveyquant-cad-error',onError)",
      "document.getElementById('sq162-cad-overlay')",
      "cadOverlay.querySelector('[data-tab=align]')",
      "cadOverlay.querySelector('[data-tab=raster]')",
      "showQuantMode('compare');renderLandSideRows();",
      'window.__sq163RuntimeError=String(e&&e.message||e||',
      "window.dispatchEvent(new CustomEvent('surveyquant-cad-ready'))",
      'sq172-home-orientation-project','sq172-home-pdf-project',
      "sq172OpenCadProject('align')","sq172OpenCadProject('raster')"
    ]
    for item in required:
        if item not in html: raise ValueError('V173 missing marker: '+item)
    if 'renderImageSideRows();' in html: raise ValueError('V173 retained undefined startup function renderImageSideRows')
    if 'lib.getDocument=guarded' in html or 'lib.getDocument = guarded' in html: raise ValueError('V173 still replaces read-only PDF.js getDocument')
    menu=re.search(r'<div class="home-menu">([\s\S]*?)</div>',html,re.I)
    if not menu or len(re.findall(r'<button\b',menu.group(1),re.I))!=10: raise ValueError('V173 home menu must keep all ten project buttons')
    for card in ['project1Card','profileCard','roadCard','pipeCard','landAreaCard','fileToDxfCard','cleanFilesCard','dropFilesCard']:
        if f'id="{card}"' not in html: raise ValueError('Missing legacy card '+card)

def main():
    p=argparse.ArgumentParser();p.add_argument('--html',type=Path,required=True);p.add_argument('--engine',type=Path,required=True);p.add_argument('--check-only',action='store_true');a=p.parse_args()
    s=a.html.read_text(encoding='utf-8');engine=a.engine.read_bytes()
    if b'SQ_V173_NO_DUPLICATE_HOME_FALLBACK' not in engine:raise ValueError('V173 CAD engine is missing duplicate-shortcut prevention marker')
    if a.check_only:
        validate(s)
        slot=re.search(r'<script\s+type=\"application/octet-stream\"\s+id=\"sq163-cad-engine\">([A-Za-z0-9+/=\r\n]+)</script>',s,re.I)
        if not slot or base64.b64decode(slot.group(1))!=engine:raise ValueError('Embedded V173 CAD engine differs from tested source')
        print('PASS V173: PDF.js getter-safe bootstrap, startup callback repair, unique project shortcuts, and exact embedded engine');return
    s=patch_html(s)
    slot=re.compile(r'(<script\s+type=\"application/octet-stream\"\s+id=\"sq163-cad-engine\">)([A-Za-z0-9+/=\r\n]+)(</script>)',re.I)
    s,n=slot.subn(lambda m:m.group(1)+base64.b64encode(engine).decode('ascii')+m.group(3),s,count=1)
    if n!=1:raise ValueError('Could not replace embedded CAD engine payload')
    a.html.write_text(s,encoding='utf-8');print(f'PASS V173 patch: {a.html} ({len(s):,} chars)')
if __name__=='__main__':main()
