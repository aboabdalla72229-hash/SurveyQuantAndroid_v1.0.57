(function(){
'use strict';
const VERSION='1.0.110';
const el=id=>document.getElementById(id);
const num=v=>{const n=Number(v);return Number.isFinite(n)?n:null;};
const ascii=(b,a,z)=>{let s='';for(let i=a;i<z;i++)s+=String.fromCharCode(b[i]);return s;};
function splitPairs(input){
 const bytes=input instanceof Uint8Array?input:new Uint8Array(input), lines=[];let i=(bytes.length>=3&&bytes[0]===239&&bytes[1]===187&&bytes[2]===191)?3:0;
 while(i<bytes.length){const start=i;while(i<bytes.length&&bytes[i]!==10&&bytes[i]!==13)i++;const ce=i;if(i<bytes.length&&bytes[i]===13)i++;if(i<bytes.length&&bytes[i]===10)i++;lines.push({start,ce,next:i});}
 if(lines.length<6||lines.length%2)throw new Error('ملف DXF النصي غير مكتمل أو ثنائي. احفظه DXF نصيًا ASCII ثم أعد المحاولة.');
 const pairs=[];for(let k=0;k<lines.length;k+=2){const cl=lines[k],vl=lines[k+1],code=Number(ascii(bytes,cl.start,cl.ce).trim().replace(/^\uFEFF/,''));if(!Number.isInteger(code))throw new Error('بنية DXF غير صالحة عند السطر '+(k+1));pairs.push({code,value:ascii(bytes,vl.start,vl.ce).trim(),start:cl.start,valueStart:vl.start,valueEnd:vl.ce,end:vl.next,index:pairs.length});}
 return {bytes,pairs};
}
function sectionRecords(pairs, wanted){
 let section='',active=null;const out=[];
 const flush=()=>{if(active){out.push(active);active=null;}};
 for(let i=0;i<pairs.length;i++){
  const p=pairs[i];
  if(p.code===0&&p.value.toUpperCase()==='SECTION'){flush();section=String(pairs[i+1]?.value||'').toUpperCase();i++;continue;}
  if(p.code===0&&p.value.toUpperCase()==='ENDSEC'){flush();section='';continue;}
  if(section!==wanted)continue;
  if(p.code===0){flush();active={type:p.value.toUpperCase(),pairs:[p],start:p.start,end:p.end};}
  else if(active){active.pairs.push(p);active.end=p.end;}
 }
 flush();
 // A classic POLYLINE is one deletable entity plus its VERTEX/SEQEND records.
 const merged=[];
 for(let i=0;i<out.length;i++){
  const r=out[i];if(r.type==='POLYLINE'){
   const all=r.pairs.slice();let end=r.end,j=i+1;
   while(j<out.length&&(out[j].type==='VERTEX'||out[j].type==='SEQEND')){all.push(...out[j].pairs);end=out[j].end;const done=out[j].type==='SEQEND';j++;if(done)break;}
   merged.push({type:r.type,pairs:all,start:r.start,end});i=j-1;
  }else if(r.type!=='VERTEX'&&r.type!=='SEQEND')merged.push(r);
 }
 return merged;
}
function pairVal(rec,code,occ=0){const p=rec.pairs.filter(x=>x.code===code)[occ];return p?num(p.value):null;}
function pointAt(rec,xcode,idx=0){const x=pairVal(rec,xcode,idx),y=pairVal(rec,xcode+10,idx);return x===null||y===null?null:{x,y};}
function recordGeometry(rec){
 const t=rec.type,p=rec.pairs,pts=[],segments=[];
 const add=p=>{if(p&&Number.isFinite(p.x)&&Number.isFinite(p.y))pts.push(p);};
 if(t==='LINE'){add(pointAt(rec,10));add(pointAt(rec,11));if(pts.length>=2)segments.push({a:pts[0],b:pts[1]});return {pts,segments};}
 if(t==='CIRCLE'||t==='ARC'){
  const c=pointAt(rec,10),r=pairVal(rec,40);if(c&&r>0){let start=t==='ARC'?(pairVal(rec,50)||0)*Math.PI/180:0,end=t==='ARC'?(pairVal(rec,51)||0)*Math.PI/180:Math.PI*2;while(end<=start)end+=2*Math.PI;const n=Math.max(24,Math.ceil((end-start)*24));let prev=null;for(let i=0;i<=n;i++){const a=start+(end-start)*i/n,q={x:c.x+r*Math.cos(a),y:c.y+r*Math.sin(a)};pts.push(q);if(prev)segments.push({a:prev,b:q});prev=q;}}return {pts,segments};
 }
 if(t==='LWPOLYLINE'||t==='POLYLINE'){
  const xs=p.filter(x=>x.code===10),ys=p.filter(x=>x.code===20);for(let i=0;i<Math.min(xs.length,ys.length);i++){const x=num(xs[i].value),y=num(ys[i].value);if(x!==null&&y!==null)add({x,y});}
  if(t==='POLYLINE'){for(let i=0;i<p.length;i++){if(p[i].code===0&&p[i].value.toUpperCase()==='VERTEX'){let x=null,y=null;for(let j=i+1;j<p.length&&p[j].code!==0;j++){if(p[j].code===10&&x===null)x=num(p[j].value);if(p[j].code===20&&y===null)y=num(p[j].value);}if(x!==null&&y!==null)add({x,y});}}}
  for(let i=1;i<pts.length;i++)segments.push({a:pts[i-1],b:pts[i]});if((pairVal(rec,70)||0)&1&&pts.length>2)segments.push({a:pts[pts.length-1],b:pts[0]});return {pts,segments};
 }
 // Prefer the first point pair for INSERT/TEXT/POINT and endpoint pairs for common lines.
 const codes=[];for(let x=10;x<=18;x++){const xs=p.filter(q=>q.code===x),ys=p.filter(q=>q.code===x+10);for(let k=0;k<Math.min(xs.length,ys.length);k++){const xx=num(xs[k].value),yy=num(ys[k].value);if(xx!==null&&yy!==null)codes.push({i:xs[k].index,p:{x:xx,y:yy}});}}
 codes.sort((a,b)=>a.i-b.i);for(const c of codes)add(c.p);
 if(pts.length>1)for(let i=1;i<pts.length;i++)segments.push({a:pts[i-1],b:pts[i]});
 return {pts,segments};
}
function distPointSeg(p,a,b){const dx=b.x-a.x,dy=b.y-a.y,d=dx*dx+dy*dy;let t=d>1e-20?((p.x-a.x)*dx+(p.y-a.y)*dy)/d:0;t=Math.max(0,Math.min(1,t));return Math.hypot(p.x-a.x-t*dx,p.y-a.y-t*dy);}
function deleteNearestEntityBytes(input,world,tolerance){
 const {bytes,pairs}=splitPairs(input),records=sectionRecords(pairs,'ENTITIES');let best=null;
 for(let i=0;i<records.length;i++){
  const rec=records[i];if(rec.pairs.some(p=>p.code===67&&Number(p.value)===1))continue;
  const g=recordGeometry(rec);let d=Infinity;
  for(const p of g.pts)d=Math.min(d,Math.hypot(p.x-world.x,p.y-world.y));
  for(const s of g.segments)d=Math.min(d,distPointSeg(world,s.a,s.b));
  if(Number.isFinite(d)&&(!best||d<best.distance))best={rec,index:i,distance:d};
 }
 if(!best||best.distance>tolerance)throw new Error('لم يتم العثور على عنصر قريب بما يكفي للحذف. كبّر اللوحة وحاول على الخط أو النص نفسه.');
 const out=new Uint8Array(bytes.length-(best.rec.end-best.rec.start));out.set(bytes.slice(0,best.rec.start),0);out.set(bytes.slice(best.rec.end),best.rec.start);
 return {bytes:out,deletedType:best.rec.type,deletedIndex:best.index,distance:best.distance};
}
function format(n){if(!Number.isFinite(n))throw new Error('التحويل أنتج إحداثيًا غير صالح.');if(Math.abs(n)<5e-12)n=0;return n.toFixed(10).replace(/(\.\d*?)0+$/,'$1').replace(/\.$/,'');}
function angle360(a){a%=360;if(a<0)a+=360;return a;}
function universalTransformBytes(input,t){
 const {bytes,pairs}=splitPairs(input);if(ascii(bytes,0,Math.min(bytes.length,22)).includes('AutoCAD Binary DXF'))throw new Error('هذا DXF ثنائي. احفظه بصيغة DXF نصية ASCII.');
 const records=sectionRecords(pairs,'ENTITIES'),edits=new Map();let transformedEntities=0,unchangedOpaque=0;
 for(const rec of records){
  const p=rec.pairs;if(p.some(x=>x.code===67&&Number(x.value)===1))continue;
  const by=new Map();for(const x of p){if(!by.has(x.code))by.set(x.code,[]);by.get(x.code).push(x);}
  let entityChanged=false;
  const change=(pair,value)=>{if(!pair||!Number.isFinite(value))return;edits.set(pair.index,{pair,value:format(value)});entityChanged=true;};
  function xy(xc,yc,mode){const xs=by.get(xc)||[],ys=by.get(yc)||[];for(let j=0;j<Math.min(xs.length,ys.length);j++){
   // In a legacy POLYLINE, group 10/20 on the parent is only a dummy origin.
   if(rec.type==='POLYLINE'&&xc===10)continue;
   const x=num(xs[j].value),y=num(ys[j].value);if(x===null||y===null)continue;
   const q=mode==='vector'?t.vector(x,y):t.point(x,y);change(xs[j],q.x);change(ys[j],q.y);
  }}
  // Apply a 2D similarity to every exposed XY coordinate pair, including unknown
  // and proxy entity records. Keep Z, handle/owner, layer, color, lineweight,
  // text content, XData, extrusion and all other bytes unchanged.
  for(let xc=10;xc<=18;xc++){
   let mode='point';
   if((rec.type==='MTEXT'||rec.type==='ELLIPSE'||rec.type==='RAY'||rec.type==='XLINE')&&xc===11)mode='vector';
   if(rec.type==='IMAGE'&&(xc===11||xc===12))mode='vector';
   if(rec.type==='SPLINE'&&(xc===12||xc===13))mode='vector';
   xy(xc,xc+10,mode);
  }
  if(rec.type==='HATCH'){xy(43,44,'point');xy(45,46,'vector');}
  const scaleCodes=[];
  if(['CIRCLE','ARC','TEXT','MTEXT','ATTRIB','ATTDEF'].includes(rec.type))scaleCodes.push(40);
  if(rec.type==='MTEXT')scaleCodes.push(41);
  if(rec.type==='INSERT')scaleCodes.push(41,42);
  if(rec.type==='HATCH')scaleCodes.push(41);
  if(by.has(48))scaleCodes.push(48);
  for(const code of new Set(scaleCodes))for(const pair of by.get(code)||[]){const n=num(pair.value);if(n!==null&&n!==0)change(pair,n*t.scale);}
  let rotationCodes=[];
  if(['ARC','INSERT','TEXT','ATTRIB','ATTDEF'].includes(rec.type))rotationCodes=[50, ...(rec.type==='ARC'?[51]:[])];
  if(rec.type==='MTEXT'&&!(by.has(11)&&by.has(21)))rotationCodes=[50];
  if(rec.type==='HATCH')rotationCodes=[52,53];
  for(const code of rotationCodes)for(const pair of by.get(code)||[]){const n=num(pair.value);if(n!==null)change(pair,angle360(n+t.angleDeg));}
  if(entityChanged)transformedEntities++;else if(!['SEQEND','VERTEX'].includes(rec.type))unchangedOpaque++;
 }
 // Never block a 2D orientation just because an entity advertises a non-default
 // extrusion vector or uses an unfamiliar class. If it exposes XY pairs, those
 // pairs are transformed; opaque binary payloads remain byte-for-byte intact.
 const ordered=Array.from(edits.values()).sort((a,b)=>a.pair.valueStart-b.pair.valueStart);let chunks=[],cursor=0,total=0;
 for(const item of ordered){chunks.push(bytes.slice(cursor,item.pair.valueStart));const replacement=new TextEncoder().encode(item.value);chunks.push(replacement);total+=item.pair.valueStart-cursor+replacement.length;cursor=item.pair.valueEnd;}
 chunks.push(bytes.slice(cursor));total+=bytes.length-cursor;const output=new Uint8Array(total);let offset=0;for(const chunk of chunks){output.set(chunk,offset);offset+=chunk.length;}
 return {bytes:output,transformedCount:transformedEntities,changedFields:ordered.length,unchangedOpaque};
}
function solve(src1,src2,ref1,ref2){
 const dS=Math.hypot(src2.x-src1.x,src2.y-src1.y),dR=Math.hypot(ref2.x-ref1.x,ref2.y-ref1.y);
 if(![src1.x,src1.y,src2.x,src2.y,ref1.x,ref1.y,ref2.x,ref2.y].every(Number.isFinite))throw new Error('اختر النقطتين 1 و2 من كل لوحة أولًا.');
 if(dS<1e-8||dR<1e-8)throw new Error('النقطتان 1 و2 في كل لوحة يجب أن تكونا مختلفتين.');
 const angle=Math.atan2(ref2.y-ref1.y,ref2.x-ref1.x)-Math.atan2(src2.y-src1.y,src2.x-src1.x),scale=dR/dS;
 if(!Number.isFinite(scale)||scale<1e-9||scale>1e9)throw new Error('المقياس المحسوب غير منطقي. تحقق من ترتيب النقاط ووحدات اللوحتين.');
 const c=Math.cos(angle),s=Math.sin(angle),tx=ref1.x-scale*(c*src1.x-s*src1.y),ty=ref1.y-scale*(s*src1.x+c*src1.y);
 return {scale,angle,angleDeg:angle*180/Math.PI,c,s,tx,ty,point:(x,y)=>({x:scale*(c*x-s*y)+tx,y:scale*(s*x+c*y)+ty}),vector:(x,y)=>({x:scale*(c*x-s*y),y:scale*(s*x+c*y)})};
}
// Replace the prior guard that rejected unsupported/proxy and non-default OCS
// entities, retaining its byte-preserving DXF editing strategy.
if(window.__sqOrientTest)window.__sqOrientTest.transformBytes=universalTransformBytes;
const state={target:null,reference:null,targetPoints:[null,null],referencePoints:[null,null],active:{target:0,reference:0},tool:{target:'pick',reference:'pick'},views:{},undoBytes:null,undoName:null,idPoint:{target:null,reference:null},bound:false};
function status(msg,bad=false){const n=el('sq110Status');if(!n)return;n.textContent=msg;n.style.display='block';n.style.color=bad?'#fecaca':'#d1fae5';n.style.borderColor=bad?'#b91c1c':'#15803d';}
function bytesOfDxf(file){return file.arrayBuffer().then(b=>new Uint8Array(b));}
async function openCad(file){if(!file)throw new Error('اختر ملف اللوحة.');const ext=file.name.toLowerCase().split('.').pop();if(ext==='dxf')return {bytes:await bytesOfDxf(file),name:file.name};if(ext==='dwg'){
  const api=window.__sqOriAxisAutoTest;if(!api||typeof api.convertTargetToDxf!=='function')throw new Error('محرك قراءة DWG غير متاح. احفظ اللوحة DXF نصيًا ثم افتحها.');
  const converted=await api.convertTargetToDxf(file);return {bytes:converted.bytes,name:converted.name||file.name.replace(/\.dwg$/i,'.dxf')};
 }throw new Error('الصيغة المدعومة لهذه العملية هي DXF أو DWG الذي يمكن تحويله إلى DXF.');}
function resetView(v){v.zoom=1;v.panX=0;v.panY=0;v.pointerMap.clear();v.mode='';v.drag=null;v.pinch=null;}
function parsePreview(bytes){
 const api=window.__sqManualOrientation109;let base=null,primaryError=null;
 try{base=api.parseDrawing(bytes);}catch(e){primaryError=e;}
 const all=sectionRecords(splitPairs(bytes).pairs,'ENTITIES');
 if(!base)base={segs:[],anchors:[],texts:[],bounds:{minX:Infinity,minY:Infinity,maxX:-Infinity,maxY:-Infinity},entityCount:all.length,unsupported:all.length};
 if(!base.segs)base.segs=[];if(!base.anchors)base.anchors=[];if(!base.texts)base.texts=[];
 const extraTypes=new Set(['DIMENSION','ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH','SURFACE','HATCH','MLEADER','MLINE','TABLE','IMAGE','WIPEOUT','HELIX','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY']);
 for(const rec of all){
  if(!extraTypes.has(rec.type))continue;
  const g=recordGeometry(rec);if(!g.pts.length)continue;
  // Add an outline approximation for entity families not completely rendered by
  // the old lightweight canvas parser. The raw DXF remains authoritative and is
  // preserved during export; this is a pickable visual aid, not a CAD re-save.
  for(const p of g.pts)base.anchors.push({x:p.x,y:p.y});
  for(const seg of g.segments)base.segs.push(seg);
  if(['DIMENSION','ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','HATCH','TABLE','IMAGE','WIPEOUT'].includes(rec.type))base.unsupported=(base.unsupported||0)+1;
 }
 if(!all.length)throw new Error(primaryError?.message||'لم يتم العثور على كيانات في قسم ENTITIES داخل DXF.');
 const pts=[];for(const seg of base.segs){pts.push(seg.a,seg.b);}for(const p of base.anchors)pts.push(p);for(const tx of base.texts)if(tx.p)pts.push(tx.p);
 if(pts.length){let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;for(const p of pts){minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);}if(maxX-minX<1e-9){minX-=.5;maxX+=.5;}if(maxY-minY<1e-9){minY-=.5;maxY+=.5;}base.bounds={minX,minY,maxX,maxY};}
 else {base.bounds={minX:0,minY:0,maxX:1,maxY:1};base.previewWarning='تحتوي اللوحة على كيانات محفوظة، لكن لا تكشف هذه الكيانات إحداثيات قابلة للمعاينة في القارئ الحالي. ستظل بيانات DXF الأصلية موجودة في الناتج.';}
 base.entityCount=Math.max(base.entityCount||0,all.length);base.originalEntityRecords=all.length;return base;
}
function loadView(side,bytes,name){const api=window.__sqManualOrientation109;if(!api||typeof api.parseDrawing!=='function')throw new Error('قارئ اللوحة غير جاهز. أغلق شاشة التوجيه وأعد فتحها.');const drawing=parsePreview(bytes);const old=state.views[side];if(old&&old.resizeHandler)window.removeEventListener('resize',old.resizeHandler);const canvasId=side==='target'?'sq110TargetCanvas':'sq110ReferenceCanvas',prior=el(canvasId);if(prior&&prior.parentNode){const fresh=prior.cloneNode(false);prior.parentNode.replaceChild(fresh,prior);}const viewer={side,bytes,name,drawing,canvas:el(canvasId),ctx:null,zoom:1,panX:0,panY:0,pointerMap:new Map(),mode:'',drag:null,pinch:null,didDrag:false,suppressTap:false};if(!viewer.canvas)throw new Error('لم يتم إنشاء مساحة عرض اللوحة '+side);state.views[side]=viewer;setupCanvas(viewer);return viewer;}
function metrics(v){const w=v.canvas.clientWidth||v.canvas.width||300,h=v.canvas.clientHeight||v.canvas.height||320,b=v.drawing.bounds,pad=18,base=Math.max(1e-12,Math.min((w-pad*2)/Math.max(1e-9,b.maxX-b.minX),(h-pad*2)/Math.max(1e-9,b.maxY-b.minY)));return {w,h,cx:(b.minX+b.maxX)/2,cy:(b.minY+b.maxY)/2,base,scale:base*v.zoom};}
function project(v,p,m=metrics(v)){return {x:m.w/2+(p.x-m.cx)*m.scale+v.panX,y:m.h/2-(p.y-m.cy)*m.scale+v.panY};}
function unproject(v,p,m=metrics(v)){return {x:m.cx+(p.x-m.w/2-v.panX)/m.scale,y:m.cy-(p.y-m.h/2-v.panY)/m.scale};}
function draw(v){if(!v||!v.ctx||!v.drawing)return;const m=metrics(v),c=v.ctx;c.clearRect(0,0,m.w,m.h);c.fillStyle='#0b1220';c.fillRect(0,0,m.w,m.h);if(v.drawing.previewWarning){c.fillStyle='#fbbf24';c.font='13px sans-serif';c.fillText(v.drawing.previewWarning.slice(0,95),12,24);}c.lineWidth=1;c.strokeStyle='#aebdce';c.lineCap='round';c.lineJoin='round';c.beginPath();
 for(const seg of v.drawing.segs){const a=project(v,seg.a,m),b=project(v,seg.b,m);if((a.x<-1200&&b.x<-1200)||(a.x>m.w+1200&&b.x>m.w+1200)||(a.y<-1200&&b.y<-1200)||(a.y>m.h+1200&&b.y>m.h+1200))continue;c.moveTo(a.x,a.y);c.lineTo(b.x,b.y);}c.stroke();
 for(const t of v.drawing.texts){const p=project(v,t.p,m);if(p.x<0||p.x>m.w||p.y<0||p.y>m.h)continue;c.fillStyle='#f4d58d';c.font='11px sans-serif';c.fillText(t.text,p.x+3,p.y-3);}
 const arr=v.side==='target'?state.targetPoints:state.referencePoints;
 for(let i=0;i<2;i++){const item=arr[i];if(!item)continue;const p=project(v,item);c.beginPath();c.fillStyle=i===0?'#2dd4bf':'#fb7185';c.strokeStyle='#fff';c.lineWidth=1.7;c.arc(p.x,p.y,8,0,Math.PI*2);c.fill();c.stroke();c.fillStyle='#fff';c.font='bold 13px sans-serif';c.fillText(String(i+1),p.x+10,p.y-9);}
 const id=state.idPoint[v.side];if(id){const p=project(v,id);c.strokeStyle='#fbbf24';c.lineWidth=2;c.beginPath();c.moveTo(p.x-9,p.y);c.lineTo(p.x+9,p.y);c.moveTo(p.x,p.y-9);c.lineTo(p.x,p.y+9);c.stroke();c.fillStyle='#fbbf24';c.font='bold 12px sans-serif';c.fillText('ID',p.x+10,p.y-10);}
 const count=el(v.side==='target'?'sq110TargetInfo':'sq110ReferenceInfo');if(count)count.textContent='كيانات DXF: '+v.drawing.entityCount+' | مقاطع مرئية: '+v.drawing.segs.length+' | تكبير ×'+v.zoom.toFixed(2)+(v.drawing.unsupported?' | عناصر خاصة محفوظة بالناتج: '+v.drawing.unsupported:'');
}
function setupCanvas(v){const c=v.canvas;if(!c)return;const resize=()=>{const r=c.getBoundingClientRect(),dpr=Math.max(1,window.devicePixelRatio||1);c.width=Math.max(1,Math.round(r.width*dpr));c.height=Math.max(1,Math.round(r.height*dpr));v.ctx=c.getContext('2d');v.ctx.setTransform(dpr,0,0,dpr,0,0);draw(v);};v.resizeHandler=resize;resize();c.addEventListener('pointerdown',e=>{
  e.preventDefault();v.pointerMap.set(e.pointerId,{x:e.clientX,y:e.clientY});try{c.setPointerCapture(e.pointerId);}catch(_){}
  if(v.pointerMap.size>=2){v.suppressTap=true;const pair=Array.from(v.pointerMap.values()).slice(0,2),center={x:(pair[0].x+pair[1].x)/2,y:(pair[0].y+pair[1].y)/2},r=c.getBoundingClientRect(),local={x:center.x-r.left,y:center.y-r.top};v.pinch={distance:Math.max(1,Math.hypot(pair[0].x-pair[1].x,pair[0].y-pair[1].y)),zoom:v.zoom,world:unproject(v,local)};v.mode='pinch';v.drag=null;v.didDrag=true;
  }else{v.mode='panOrTap';v.drag={id:e.pointerId,x:e.clientX,y:e.clientY,panX:v.panX,panY:v.panY};v.didDrag=false;v.suppressTap=false;}
 });
 c.addEventListener('pointermove',e=>{if(!v.pointerMap.has(e.pointerId))return;v.pointerMap.set(e.pointerId,{x:e.clientX,y:e.clientY});if(v.mode==='pinch'&&v.pointerMap.size>=2&&v.pinch){const pair=Array.from(v.pointerMap.values()).slice(0,2),center={x:(pair[0].x+pair[1].x)/2,y:(pair[0].y+pair[1].y)/2},distance=Math.max(1,Math.hypot(pair[0].x-pair[1].x,pair[0].y-pair[1].y)),r=c.getBoundingClientRect(),local={x:center.x-r.left,y:center.y-r.top};v.zoom=Math.max(.15,Math.min(120,v.pinch.zoom*distance/v.pinch.distance));const m=metrics(v);v.panX=local.x-m.w/2-(v.pinch.world.x-m.cx)*m.scale;v.panY=local.y-m.h/2+(v.pinch.world.y-m.cy)*m.scale;v.didDrag=true;draw(v);return;}if(v.mode==='panOrTap'&&v.drag&&v.drag.id===e.pointerId){if(Math.hypot(e.clientX-v.drag.x,e.clientY-v.drag.y)>5)v.didDrag=true;if(v.didDrag){v.panX=v.drag.panX+e.clientX-v.drag.x;v.panY=v.drag.panY+e.clientY-v.drag.y;draw(v);}}});
 c.addEventListener('pointerup',e=>{const wasPinch=v.mode==='pinch'||v.pointerMap.size>1,wasTap=!wasPinch&&v.mode==='panOrTap'&&v.drag&&v.drag.id===e.pointerId&&!v.didDrag&&!v.suppressTap;v.pointerMap.delete(e.pointerId);try{c.releasePointerCapture(e.pointerId);}catch(_){}if(wasPinch){v.suppressTap=true;v.pinch=null;if(v.pointerMap.size===1){const p=Array.from(v.pointerMap.entries())[0];v.mode='panOrTap';v.drag={id:p[0],x:p[1].x,y:p[1].y,panX:v.panX,panY:v.panY};v.didDrag=true;}else{v.mode='';v.drag=null;}return;}if(wasTap)pick(v,e.clientX,e.clientY);v.drag=null;v.mode='';v.didDrag=false;v.suppressTap=false;});
 c.addEventListener('pointercancel',e=>{v.pointerMap.delete(e.pointerId);v.mode='';v.drag=null;v.pinch=null;v.suppressTap=true;});c.addEventListener('wheel',e=>{e.preventDefault();const r=c.getBoundingClientRect(),pt={x:e.clientX-r.left,y:e.clientY-r.top},m=metrics(v),world=unproject(v,pt,m);v.zoom=Math.max(.15,Math.min(120,v.zoom*(e.deltaY<0?1.2:1/1.2)));const n=metrics(v);v.panX=pt.x-n.w/2-(world.x-n.cx)*n.scale;v.panY=pt.y-n.h/2+(world.y-n.cy)*n.scale;draw(v);},{passive:false});window.addEventListener('resize',resize);
}
function nearestSnap(v,world,screen){const api=window.__sqManualOrientation109,m=metrics(v),segs=v.drawing.segs,projector=p=>project(v,p,m);let cross=null;if(api&&typeof api.findNearestIntersection==='function')cross=api.findNearestIntersection(segs,screen,projector,20);if(cross)return {p:cross.point,kind:'تقاطع OSNAP'};let best=null;const test=(p,kind)=>{const q=projector(p),d=Math.hypot(q.x-screen.x,q.y-screen.y);if(!best||d<best.d)best={p,d,kind};};for(const p of v.drawing.anchors)test(p,'رأس/نقطة');for(const s of segs){const a=s.a,b=s.b,dx=b.x-a.x,dy=b.y-a.y,d=dx*dx+dy*dy;if(d<1e-20)continue;let u=((world.x-a.x)*dx+(world.y-a.y)*dy)/d;u=Math.max(0,Math.min(1,u));test({x:a.x+u*dx,y:a.y+u*dy},'على خط');}return best&&best.d<=22?{p:best.p,kind:best.kind}:null;}
function fillReadouts(){for(let i=0;i<2;i++){const n=i+1,src=state.targetPoints[i],ref=state.referencePoints[i];for(const [id,p] of [['sq110T'+n,src],['sq110R'+n,ref]]){const x=el(id+'X'),y=el(id+'Y');if(x)x.value=p?p.x.toFixed(6):'';if(y)y.value=p?p.y.toFixed(6):'';}const s=el('sq110StatusPoint'+n);if(s)s.textContent='النقطة '+n+': '+(src&&ref?'مطابقة بين اللوحتين':src?'تم تحديدها في غير الموجّهة':ref?'تم تحديدها في المرجعية':'لم تُحدد بعد');}updatePickLabels();}
function updatePickLabels(){for(const side of ['target','reference']){const i=state.active[side],lab=el(side==='target'?'sq110TargetMode':'sq110ReferenceMode'),tool=state.tool[side];if(lab)lab.textContent=tool==='id'?'أداة ID Point: اضغط لقراءة X/Y':tool==='delete'?'أداة الحذف: اضغط على العنصر المراد حذفه':'اختيار النقطة '+(i+1)+' على '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية');}}
function pick(v,clientX,clientY){if(!v.drawing)return;const r=v.canvas.getBoundingClientRect(),screen={x:clientX-r.left,y:clientY-r.top},world=unproject(v,screen),tool=state.tool[v.side];if(tool==='delete'){
  if(v.side!=='target'){status('الحذف متاح على اللوحة غير الموجّهة فقط حتى تظل اللوحة المرجعية الأصلية مرجعًا ثابتًا.',true);return;}
  try{const maxWorld=24/metrics(v).scale,removed=deleteNearestEntityBytes(state.target.bytes,world,maxWorld);state.undoBytes=state.target.bytes.slice();state.undoName=state.target.name;state.target.bytes=removed.bytes;state.target.name=state.target.name.replace(/\.dxf$/i,'')+'_EDITED.dxf';const old=[...state.targetPoints];state.targetPoints=[null,null];state.idPoint.target=null;loadView('target',state.target.bytes,state.target.name);fillReadouts();el('sq110UndoDelete').disabled=false;status('تم حذف عنصر '+removed.deletedType+' من نسخة العمل فقط. استخدم «تراجع عن الحذف» لاسترجاعه. أعد تحديد النقطتين لضمان دقة التوجيه.');return;}catch(e){status(e.message||String(e),true);return;}
 }
 const snap=nearestSnap(v,world,screen);if(!snap){status('لم أجد تقاطعًا أو رأسًا أو خطًا قريبًا. كبّر اللوحة أو اضغط قرب العنصر.',true);return;}
 if(tool==='id'){state.idPoint[v.side]=snap.p;const read=el(v.side==='target'?'sq110TargetId':'sq110ReferenceId');if(read)read.textContent='ID Point: X = '+snap.p.x.toFixed(6)+' | Y = '+snap.p.y.toFixed(6)+' | '+snap.kind;draw(v);status('تمت قراءة النقطة من '+(v.side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+'.');return;}
 const i=state.active[v.side],list=v.side==='target'?state.targetPoints:state.referencePoints;list[i]={x:snap.p.x,y:snap.p.y,kind:snap.kind};state.idPoint[v.side]=null;fillReadouts();draw(v);status('تم تسجيل النقطة '+(i+1)+' في '+(v.side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+' عند X='+snap.p.x.toFixed(6)+' وY='+snap.p.y.toFixed(6)+'. الرقم نفسه سيطابق النقطة '+(i+1)+' في اللوحة الأخرى.');if(i===0)state.active[v.side]=1;updatePickLabels();}
function selectPoint(side,i){state.active[side]=i;state.tool[side]='pick';updatePickLabels();for(const s of ['target','reference'])if(state.views[s])draw(state.views[s]);}
function setTool(side,tool){state.tool[side]=tool;updatePickLabels();status(tool==='id'?'تم تفعيل ID Point على '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+'. اضغط نقطة لقراءة إحداثياتها.':tool==='delete'?'وضع الحذف: اضغط على العنصر في اللوحة غير الموجّهة لحذف ذلك العنصر كاملًا.':'تم إيقاف الأداة الإضافية.');}
function showScreen(which){const t=el('sq110TargetScreen'),r=el('sq110ReferenceScreen');if(t)t.style.display=which==='target'?'block':'none';if(r)r.style.display=which==='reference'?'block':'none';if(which==='reference'&&state.views.reference)draw(state.views.reference);if(which==='target'&&state.views.target)draw(state.views.target);el('sq110Step1').style.opacity=which==='target'?'1':'.65';el('sq110Step2').style.opacity=which==='reference'?'1':'.65';}
async function chooseFile(side,file){try{status('جارٍ قراءة '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+'...');const data=await openCad(file);const view=loadView(side,data.bytes,data.name);if(side==='target'){state.target={bytes:data.bytes,name:data.name};state.targetPoints=[null,null];state.undoBytes=null;el('sq110UndoDelete').disabled=true;}else{state.reference={bytes:data.bytes,name:data.name};state.referencePoints=[null,null];}state.active[side]=0;state.tool[side]='pick';state.idPoint[side]=null;fillReadouts();const info=el(side==='target'?'sq110TargetFileInfo':'sq110ReferenceFileInfo');if(info)info.textContent='الملف: '+file.name+' | العناصر: '+view.drawing.entityCount+' | ملاحظة: جميع بيانات DXF الأصلية محفوظة عند الإخراج؛ المعاينة هنا هندسية.';status('تم فتح '+file.name+'. اختر النقطة 1 ثم 2؛ سيظهر رقم كل نقطة تلقائيًا على الرسم.');}catch(e){status((e.message||String(e))+' لم يتم تغيير ملفك الأصلي.',true);}}
function calculation(){if(!state.target||!state.reference)throw new Error('افتح اللوحة غير الموجّهة واللوحة المرجعية أولًا.');if(!state.targetPoints[0]||!state.targetPoints[1])throw new Error('حدد النقطتين 1 و2 في اللوحة غير الموجّهة.');if(!state.referencePoints[0]||!state.referencePoints[1])throw new Error('حدد النقطتين 1 و2 في اللوحة المرجعية، بالترتيب نفسه.');return solve(state.targetPoints[0],state.targetPoints[1],state.referencePoints[0],state.referencePoints[1]);}
function review(){try{const t=calculation();status('المعاينة جاهزة: النقطة 1 تطابق النقطة 1، والنقطة 2 تطابق النقطة 2. معامل المقياس ×'+t.scale.toFixed(10)+' | الدوران '+t.angleDeg.toFixed(6)+'° | X وY دون تبديل.');return t;}catch(e){status(e.message,true);return null;}}
async function exportTarget(){try{if(!state.target)throw new Error('اختر اللوحة غير الموجّهة أولًا.');const t=review();if(!t)return;const engine=window.__sqOrientTest;if(!engine||typeof engine.transformBytes!=='function')throw new Error('محرك التحويل غير جاهز.');const result=engine.transformBytes(state.target.bytes,t);if(!result.bytes||result.bytes.length<16)throw new Error('المحرك لم ينتج ملف DXF صالحًا.');const name=state.target.name.replace(/\.dxf$/i,'')+'_ORIENTED_TO_REFERENCE.dxf';let downloaded;if(typeof window.safeDownloadFile==='function')downloaded=await window.safeDownloadFile(result.bytes,name,'application/dxf');else downloaded=await fallbackDownload(result.bytes,name);if(downloaded==null||downloaded===false)throw new Error('تعذر تأكيد حفظ الملف أو تم إلغاء الحفظ. لم يتم تغيير اللوحة الأصلية.');status('تم حفظ اللوحة الموجّهة بنجاح. العناصر ذات إحداثيات XY المعدّلة: '+result.transformedCount+' | الحقول المعدّلة: '+result.changedFields+(result.unchangedOpaque?' | عناصر بلا إحداثيات مكشوفة بقيت ببياناتها الأصلية: '+result.unchangedOpaque:'')+'. الملف المرجعي لم يتغير.');}catch(e){status((e.message||String(e))+' لم يتم تغيير الملف الأصلي أو المرجعي.',true);}}
function fallbackDownload(bytes,name){return new Promise(resolve=>{try{const blob=new Blob([bytes],{type:'application/dxf'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);resolve(url);}catch(e){resolve(null);}});}
function undoDelete(){if(!state.undoBytes)return;state.target={bytes:state.undoBytes.slice(),name:state.undoName||state.target.name};state.undoBytes=null;state.undoName=null;loadView('target',state.target.bytes,state.target.name);state.targetPoints=[null,null];fillReadouts();el('sq110UndoDelete').disabled=true;status('تم التراجع عن آخر حذف. أعد تحديد النقطتين 1 و2.');}
function mount(){const overlay=el('sqOriOverlay');if(!overlay)return;const dialog=overlay.querySelector('.sqori-dialog');if(!dialog)return;
 dialog.innerHTML='<button class="sqori-close" type="button" onclick="sqCloseOrientationProject()">✕ إغلاق</button><h2>🧭 توجيه لوحة إلى لوحة مرجعية بالنقطتين</h2><p class="sqori-help">حدد النقطة 1 ثم 2 في اللوحة غير الموجّهة، ثم افتح شاشة اللوحة المرجعية وحدد النقطة 1 ثم 2 بالترتيب نفسه. يُحسب الدوران والمقياس والإزاحة لمطابقة 1 مع 1 و2 مع 2. اللوحة المرجعية لا تتغير، ويُحفظ الناتج في DXF جديد.</p><div style="display:flex;gap:8px;margin:10px 0"><button id="sq110Step1" class="sqori-preview" type="button">1) اللوحة غير الموجّهة</button><button id="sq110Step2" class="sqori-preview" type="button">2) اللوحة المرجعية</button></div><div id="sq110TargetScreen"><h3>اللوحة غير الموجّهة</h3><label>اختر اللوحة (DXF / DWG)<input id="sq110TargetFile" type="file" accept=".dxf,.dwg"></label><p id="sq110TargetFileInfo" class="sqori-help"></p><div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0"><button id="sq110TZoomIn" class="sqori-preview" type="button">تكبير +</button><button id="sq110TZoomOut" class="sqori-preview" type="button">تصغير −</button><button id="sq110TFit" class="sqori-preview" type="button">ملاءمة</button><button id="sq110TId" class="sqori-preview" type="button">ID Point</button><button id="sq110Delete" class="sqori-preview" type="button">حذف عنصر</button><button id="sq110UndoDelete" class="sqori-preview" type="button" disabled>تراجع عن الحذف</button></div><div id="sq110TargetMode" class="sqori-help">اختر النقطة 1 على الرسم</div><canvas id="sq110TargetCanvas" style="display:block;width:100%;height:340px;border:1px solid #42536b;border-radius:10px;touch-action:none;background:#0b1220"></canvas><p id="sq110TargetInfo" class="sqori-help">ستظهر تفاصيل العرض بعد فتح اللوحة.</p><p id="sq110TargetId" class="sqori-help">ID Point: غير مفعل</p><div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0"><button id="sq110TSelect1" class="sqori-preview" type="button">اختيار النقطة 1</button><button id="sq110TSelect2" class="sqori-preview" type="button">اختيار النقطة 2</button><button id="sq110ToReference" class="sqori-run" type="button">التالي: اللوحة المرجعية ←</button></div></div><div id="sq110ReferenceScreen" style="display:none"><h3>اللوحة المرجعية (لن يتم تعديلها)</h3><label>اختر اللوحة المرجعية (DXF / DWG)<input id="sq110ReferenceFile" type="file" accept=".dxf,.dwg"></label><p id="sq110ReferenceFileInfo" class="sqori-help"></p><div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0"><button id="sq110RZoomIn" class="sqori-preview" type="button">تكبير +</button><button id="sq110RZoomOut" class="sqori-preview" type="button">تصغير −</button><button id="sq110RFit" class="sqori-preview" type="button">ملاءمة</button><button id="sq110RId" class="sqori-preview" type="button">ID Point</button></div><div id="sq110ReferenceMode" class="sqori-help">اختر النقطة 1 على الرسم المرجعي</div><canvas id="sq110ReferenceCanvas" style="display:block;width:100%;height:340px;border:1px solid #42536b;border-radius:10px;touch-action:none;background:#0b1220"></canvas><p id="sq110ReferenceInfo" class="sqori-help">سيتم عرض اللوحة المرجعية كما هي من بيانات DXF المتاحة للمعاينة، ولا يُكتب عليها أي تعديل.</p><p id="sq110ReferenceId" class="sqori-help">ID Point: غير مفعل</p><div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0"><button id="sq110RSelect1" class="sqori-preview" type="button">اختيار النقطة 1</button><button id="sq110RSelect2" class="sqori-preview" type="button">اختيار النقطة 2</button><button id="sq110Back" class="sqori-preview" type="button">→ الرجوع للوحة غير الموجّهة</button><button id="sq110Preview" class="sqori-preview" type="button">معاينة المطابقة</button><button id="sq110Export" class="sqori-run" type="button">توجيه وإخراج DXF</button></div></div><h3>إحداثيات النقاط المطابقة (تُنسخ تلقائيًا)</h3><div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:12px"><thead><tr><th>النقطة</th><th>غير الموجّهة X</th><th>غير الموجّهة Y</th><th>المرجعية X</th><th>المرجعية Y</th></tr></thead><tbody><tr><th>1</th><td><input readonly id="sq110T1X" style="width:100%"></td><td><input readonly id="sq110T1Y" style="width:100%"></td><td><input readonly id="sq110R1X" style="width:100%"></td><td><input readonly id="sq110R1Y" style="width:100%"></td></tr><tr><th>2</th><td><input readonly id="sq110T2X" style="width:100%"></td><td><input readonly id="sq110T2Y" style="width:100%"></td><td><input readonly id="sq110R2X" style="width:100%"></td><td><input readonly id="sq110R2Y" style="width:100%"></td></tr></tbody></table></div><p id="sq110StatusPoint1" class="sqori-help">النقطة 1: لم تُحدد بعد</p><p id="sq110StatusPoint2" class="sqori-help">النقطة 2: لم تُحدد بعد</p><p class="sqori-help">OSNAP يلتقط التقاطعات أولًا ثم الرؤوس والنقاط والخطوط. اللمس بإصبع واحد يحرك اللوحة، والإصبعان للتكبير والتصغير. الحذف يمسح الكيان المحدد من نسخة العمل فقط، وله تراجع. التحويل يعمل على إحداثيات XY المكشوفة لكل كيان DXF، بما فيها الأنواع غير المعروفة، ويترك Z وبيانات الطبقات والألوان والنصوص والحقول الأخرى كما هي. العناصر ذات حمولة ثنائية داخلية لا تكشف إحداثياتها لا يمكن إعادة هندستها دون محرك CAD، لذلك تبقى ببياناتها الأصلية ولا تمنع إخراج الملف.</p><div id="sq110Status" class="sqori-status" role="status" aria-live="polite"></div>';
 state.target=null;state.reference=null;state.targetPoints=[null,null];state.referencePoints=[null,null];state.active={target:0,reference:0};state.tool={target:'pick',reference:'pick'};state.views={};state.undoBytes=null;state.undoName=null;state.idPoint={target:null,reference:null};
 el('sq110TargetFile').addEventListener('change',e=>{const f=e.target.files&&e.target.files[0];if(f)chooseFile('target',f);});el('sq110ReferenceFile').addEventListener('change',e=>{const f=e.target.files&&e.target.files[0];if(f)chooseFile('reference',f);});
 el('sq110Step1').addEventListener('click',()=>showScreen('target'));el('sq110Step2').addEventListener('click',()=>showScreen('reference'));el('sq110ToReference').addEventListener('click',()=>{if(!state.targetPoints[0]||!state.targetPoints[1]){status('حدد النقطتين 1 و2 في اللوحة غير الموجّهة قبل الانتقال.',true);return;}showScreen('reference');});el('sq110Back').addEventListener('click',()=>showScreen('target'));
 el('sq110TSelect1').addEventListener('click',()=>selectPoint('target',0));el('sq110TSelect2').addEventListener('click',()=>selectPoint('target',1));el('sq110RSelect1').addEventListener('click',()=>selectPoint('reference',0));el('sq110RSelect2').addEventListener('click',()=>selectPoint('reference',1));
 for(const [side,prefix] of [['target','T'],['reference','R']]){el('sq110'+prefix+'ZoomIn').addEventListener('click',()=>{const v=state.views[side];if(v){v.zoom=Math.min(120,v.zoom*1.5);draw(v);}});el('sq110'+prefix+'ZoomOut').addEventListener('click',()=>{const v=state.views[side];if(v){v.zoom=Math.max(.15,v.zoom/1.5);draw(v);}});el('sq110'+prefix+'Fit').addEventListener('click',()=>{const v=state.views[side];if(v){resetView(v);draw(v);}});el('sq110'+prefix+'Id').addEventListener('click',()=>setTool(side,state.tool[side]==='id'?'pick':'id'));}
 el('sq110Delete').addEventListener('click',()=>setTool('target',state.tool.target==='delete'?'pick':'delete'));el('sq110UndoDelete').addEventListener('click',undoDelete);el('sq110Preview').addEventListener('click',review);el('sq110Export').addEventListener('click',exportTarget);showScreen('target');
}
window.__sqOrientation110API={VERSION,solve,transformBytes:universalTransformBytes,deleteNearestEntityBytes,splitPairs,sectionRecords,recordGeometry,parsePreview};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();
