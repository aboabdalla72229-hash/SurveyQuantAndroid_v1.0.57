'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const html=fs.readFileSync(process.argv[2]||'index.html','utf8');
const start=html.indexOf('function readTextPoints('),end=html.indexOf('\nfunction addCadEntity',start);
assert.ok(start>=0&&end>start,'point parser function not found in patched HTML');
const source=html.slice(start,end);
const context={Number,String,Math};vm.runInNewContext(source+'\nthis.readTextPoints=readTextPoints;',context);const readTextPoints=context.readTextPoints;
const tests=[
 ['1001,576761.4460,858279.3570,0.0000,','CSV',[{id:'1001',e:576761.446,n:858279.357,z:0}]],
 ['Point,Easting,Northing,Elevation\n1001,576761.4460,858279.3570,0.0000','CSV',[{id:'1001',e:576761.446,n:858279.357,z:0}]],
 ['Easting,Northing,Elevation,Point No.\n576761.4460,858279.3570,0.0000,1001','CSV',[{id:'1001',e:576761.446,n:858279.357,z:0}]],
 ['A1 576761.4460 858279.3570 12.5','TXT',[{id:'A1',e:576761.446,n:858279.357,z:12.5}]],
 ['A1;576761.4460;858279.3570;12.5','CSV',[{id:'A1',e:576761.446,n:858279.357,z:12.5}]],
];
for(const [text,format,expected] of tests){const got=readTextPoints(text,format);assert.equal(got.length,expected.length);for(let i=0;i<expected.length;i++){for(const k of ['id','e','n','z'])assert.equal(got[i][k],expected[i][k],`${format} ${k}`);}}
console.log(JSON.stringify({pointRows:tests.length,contract:'ID,Easting,Northing,Elevation',numericIdExcluded:true,axisOrder:'X=Easting,Y=Northing',result:'PASS'},null,2));
