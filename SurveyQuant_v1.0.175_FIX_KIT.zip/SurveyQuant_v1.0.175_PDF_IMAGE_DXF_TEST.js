'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const CAD=require('./SurveyQuant_v1.0.175_CAD_ENGINE.js');
const dxf=CAD.makeRasterUnderlayDxf('PAGE_ORIGINAL_123.jpg',1600,1200,0.5);
const text=new TextDecoder('windows-1252').decode(dxf);
for(const token of ['\r\nIMAGE\r\n','\r\nIMAGEDEF\r\n','PAGE_ORIGINAL_123.jpg','\r\n340\r\n32\r\n','\r\n13\r\n1600\r\n','\r\n23\r\n1200\r\n'])assert.ok(text.includes(token),'missing raster DXF marker '+JSON.stringify(token));
assert.ok(CAD.canvasJpegBytes&&CAD.downloadPairedRasterFile,'paired original-image export helpers missing');
assert.ok(CAD.zipStore,'ZIP helper missing');
if(process.argv[2]){const html=fs.readFileSync(process.argv[2],'utf8'),m=html.match(/<script type=\"application\/octet-stream\" id=\"sq163-pdfjs-worker\">([A-Za-z0-9+/=]+)<\/script>/);assert.ok(m&&Buffer.from(m[1],'base64').length>100000,'matching PDF.js worker is not embedded');}
console.log(JSON.stringify({ok:true,dxfBytes:dxf.length,entity:'IMAGE',definition:'IMAGEDEF',sidecar:'PAGE_ORIGINAL_123.jpg',pixelDimensions:[1600,1200],scale:0.5,visualFidelity:'source page raster, not traced/recreated'},null,2));
