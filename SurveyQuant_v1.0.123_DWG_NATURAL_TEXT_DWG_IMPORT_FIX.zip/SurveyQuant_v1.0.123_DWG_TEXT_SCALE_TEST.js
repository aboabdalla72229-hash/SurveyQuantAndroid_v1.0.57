#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const [manualPath, htmlPath, referencePath] = process.argv.slice(2);
assert(manualPath && htmlPath && referencePath, 'usage: test.js MANUAL_MODULE.js INDEX_PATH.html REFERENCE_MODULE.js');
const manual = fs.readFileSync(manualPath, 'utf8');
const html = fs.readFileSync(htmlPath, 'utf8');
const reference = fs.readFileSync(referencePath, 'utf8');
const helperToken = 'function sqV123TextPixelHeight(';
const newLoop = "for(const t of drawing.texts){const p=toScreen(t.p,m);if(p.x<0||p.x>m.w||p.y<0||p.y>m.h)continue;const textPixels=sqV123TextPixelHeight(t.height,m.scale);if(!Number.isFinite(textPixels)||textPixels<=0)continue;ctx.fillStyle='#e9c46a';ctx.font=textPixels+'px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);}";
function verifyManual(source, label) {
  assert.equal((source.match(/function sqV123TextPixelHeight\(/g) || []).length, 1, label + ': one scale helper');
  assert.equal(source.split(newLoop).length - 1, 1, label + ': exactly one dynamic CAD text loop');
  assert(!source.includes("ctx.font='11px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);"), label + ': hard-coded 11px CAD font remains');
  assert(source.includes('const scale=base*zoom;'), label + ': current board zoom is not included in screen scale');
}
verifyManual(manual, 'manual-points module');
const embedded = html.match(/<script\b[^>]*\bid=["']sq-orientation-manual-points-module["'][^>]*>([\s\S]*?)<\/script\s*>/i);
assert(embedded, 'embedded manual-points script is missing');
verifyManual(embedded[1], 'integrated HTML manual-points module');
assert.equal((html.match(/function sqV123TextPixelHeight\(/g)||[]).length, 1, 'exactly one V123 helper in HTML');
assert(reference.includes('function sqV122NaturalTextPixels(') && reference.includes('size=sqV122NaturalTextPixels(v,t,m,p)'), 'V122 dual-board viewport scale is missing');
assert(html.includes('function universalTransformBytes(input,t)'), 'byte-preserving CAD transform missing');

const helperMatch = manual.match(/function sqV123TextPixelHeight\(height,scale\)\{[^}]*\}/);
assert(helperMatch, 'unable to extract live helper');
const helper = vm.runInNewContext('(' + helperMatch[0].replace('function sqV123TextPixelHeight(height,scale)', 'function(height,scale)') + ')', { Number, Math });
function close(actual, expected, label) { assert(Math.abs(actual-expected) < 1e-10, label + ': expected ' + expected + ', received ' + actual); }
close(helper(2.5, .1), .25, 'natural height at 0.1 screen units per drawing unit');
close(helper(2.5, .4), 1.0, 'four-times zoom must yield four-times text height');
close(helper(2.5, .8), 2.0, 'eight-times zoom must yield eight-times text height vs 0.1');
close(helper(-3, .2), .6, 'negative height uses absolute display height');
close(helper(0, .2), .5, 'missing/zero entity height uses conventional 2.5 drawing units');
close(helper(2.5, 0), 0, 'zero scale must not manufacture a fixed-size font');
console.log('PASS V123: actual old canvas renderer no longer has fixed CAD text size; tested six numeric scaling cases, V122 renderer retained, and byte-preserving transform retained.');
