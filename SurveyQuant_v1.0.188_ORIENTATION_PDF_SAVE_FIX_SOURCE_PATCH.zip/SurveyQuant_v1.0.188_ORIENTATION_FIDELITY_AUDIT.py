from pathlib import Path
import ezdxf, json, math
root=Path(__file__).resolve().parent
src=ezdxf.readfile(root/'V188_ORIENTATION_FIDELITY_FIXTURE.dxf')
out=ezdxf.readfile(root/'V188_ORIENTATION_FIDELITY_OUTPUT.dxf')
ms=src.modelspace(); mo=out.modelspace()
def one(m, typ):
    items=list(m.query(typ))
    assert len(items)==1,(typ,len(items))
    return items[0]
def xy(p): return (round(float(p.x),6),round(float(p.y),6))
def transformed(p): return (round(1100-float(p.y),6),round(1900+float(p.x),6))
# Every tested entity keeps its record type, entity count, layer, and non-geometric labels.
for typ in ('LINE','CIRCLE','ARC','LWPOLYLINE','TEXT','MTEXT','INSERT','HATCH'):
    assert len(list(ms.query(typ)))==len(list(mo.query(typ)))==1,typ
line0,line1=one(ms,'LINE'),one(mo,'LINE')
assert xy(line1.dxf.start)==transformed(line0.dxf.start) and xy(line1.dxf.end)==transformed(line0.dxf.end)
c0,c1=one(ms,'CIRCLE'),one(mo,'CIRCLE');assert xy(c1.dxf.center)==transformed(c0.dxf.center) and abs(c1.dxf.radius-c0.dxf.radius)<1e-9
arc0,arc1=one(ms,'ARC'),one(mo,'ARC');assert xy(arc1.dxf.center)==transformed(arc0.dxf.center) and abs(arc1.dxf.radius-arc0.dxf.radius)<1e-9
assert abs(arc1.dxf.start_angle-90)<1e-7 and abs(arc1.dxf.end_angle-225)<1e-7
pl0,pl1=one(ms,'LWPOLYLINE'),one(mo,'LWPOLYLINE')
assert [tuple(round(float(v),6) for v in p[:2]) for p in pl1.get_points('xy')] == [transformed(type('P',(),{'x':p[0],'y':p[1]})()) for p in pl0.get_points('xy')]
assert [round(float(p[2]),10) for p in pl1.get_points('xyb')]==[round(float(p[2]),10) for p in pl0.get_points('xyb')]
t0,t1=one(ms,'TEXT'),one(mo,'TEXT');assert t0.dxf.text==t1.dxf.text=='AXIS A-A' and xy(t1.dxf.insert)==transformed(t0.dxf.insert) and abs(t1.dxf.rotation-90)<1e-7
m0,m1=one(ms,'MTEXT'),one(mo,'MTEXT');assert m0.text==m1.text=='GRID 01' and xy(m1.dxf.insert)==transformed(m0.dxf.insert)
i0,i1=one(ms,'INSERT'),one(mo,'INSERT');assert i0.dxf.name==i1.dxf.name=='AXIS_MARK' and xy(i1.dxf.insert)==transformed(i0.dxf.insert) and abs(i1.dxf.rotation-100)<1e-7
assert len(i1.attribs)==len(i0.attribs)==1 and i1.attribs[0].dxf.text==i0.attribs[0].dxf.text=='AXIS-01'
h0,h1=one(ms,'HATCH'),one(mo,'HATCH')
verts0=h0.paths.paths[0].vertices;verts1=h1.paths.paths[0].vertices
expected={transformed(type('P',(),{'x':p[0],'y':p[1]})()) for p in verts0}
actual={(round(float(p[0]),6),round(float(p[1]),6)) for p in verts1}
assert actual==expected,(actual,expected)
for layer in ('AXIS_NAME','WALLS','GRID'):
    a=src.layers.get(layer);b=out.layers.get(layer)
    assert (a.dxf.color,a.dxf.lineweight)==(b.dxf.color,b.dxf.lineweight),layer
assert 'AXIS_MARK' in src.blocks and 'AXIS_MARK' in out.blocks
for d in (src,out):
    audit=d.audit();assert not audit.errors and not audit.fixes,(len(audit.errors),len(audit.fixes))
report={'entity_types':['LINE','CIRCLE','ARC','LWPOLYLINE','HATCH','INSERT','ATTRIB','TEXT','MTEXT'],'axis_texts':['AXIS A-A','GRID 01','AXIS-01'],'layers':{'AXIS_NAME':[3,35],'WALLS':[1,50],'GRID':[5,25]},'coordinate_transform':'(x,y) -> (1100-y,1900+x)','entity_counts_preserved':True,'entity_properties_preserved':True,'ezdxf_audit':'0 errors / 0 fixes','result':'PASS'}
(root/'V188_ORIENTATION_FIDELITY_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
