#!/usr/bin/env python3
from pathlib import Path
import argparse, base64, subprocess, sys, tempfile
from playwright.sync_api import sync_playwright

ap=argparse.ArgumentParser()
ap.add_argument('--engine',type=Path,required=True)
ap.add_argument('--output',type=Path,required=True)
ap.add_argument('--browser',default='')
a=ap.parse_args()

# Minimal, distinct source and reference boards. The source points are not equal
# to the corresponding target points before alignment.
def dxf(poly, layer, points, ext):
    pairs=['0','SECTION','2','HEADER','9','$ACADVER','1','AC1009','0','ENDSEC',
           '0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','2',
           '0','LAYER','2','0','70','0','62','7','6','CONTINUOUS',
           '0','LAYER','2',layer,'70','0','62','3','6','CONTINUOUS','0','ENDTAB','0','ENDSEC',
           '0','SECTION','2','ENTITIES','0','POLYLINE','8',layer,'66','1','70','0']
    for x,y in points:
        pairs += ['0','VERTEX','8',layer,'10',str(x),'20',str(y),'30','0','70','0']
    pairs += ['0','SEQEND','8',layer,'0','ENDSEC','0','EOF','']
    return '\r\n'.join(pairs)

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    src=td/'source.dxf'; tgt=td/'target.dxf'
    src.write_text(dxf('','SOURCE',( (100,200),(110,200),(110,210),(100,210) ),(100,110,200,210)),encoding='ascii')
    tgt.write_text(dxf('','TARGET',( (1000,2000),(1000,2020),(980,2020),(980,2000) ),(980,1000,2000,2020)),encoding='ascii')
    cad=a.engine.read_text(encoding='utf-8')
    html=f'''<!doctype html><html><head><meta charset="utf-8"></head><body>
    <div class="container"><div id="homeMenu"><div class="home-menu"></div></div></div>
    <script>
      window.__nativeSaved=null;window.__notified=null;
      window.Android={{saveFile:(filename,mime,base64)=>{{window.__nativeSaved={{filename,mime,base64}}; /* emulate Java void-return bridge */}},notifyDownload:(filename,path,mime)=>{{window.__notified={{filename,path,mime}};}}}};
      window.parseFile=async(file,options={{}})=>({{rawDXFBytes:options.sourceBytes}});
    </script>
    <script>{cad}</script></body></html>'''
    with sync_playwright() as p:
        launch={'headless':True,'args':['--no-sandbox']}
        if a.browser: launch['executable_path']=a.browser
        browser=p.chromium.launch(**launch)
        page=browser.new_page(viewport={'width':412,'height':900})
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content(html,wait_until='domcontentloaded',timeout=30000)
        assert page.evaluate('!!window.SurveyQuantCAD179')
        page.locator('#sq176-home-orientation-project').click()
        page.locator('#sq162-source-file').set_input_files(str(src));page.wait_for_timeout(100)
        page.locator('#sq162-target-file').set_input_files(str(tgt));page.wait_for_timeout(100)
        for i,side,xy in [(0,'source',(100,200)),(1,'source',(110,200)),(2,'target',(1000,2000)),(3,'target',(1000,2020))]:
            page.locator(f'[data-sq-snap="{side}"]').select_option('nearest')
            page.locator(f'#sq162-pick-{i}').click()
            q=page.evaluate('''({side,xy})=>{const c=document.getElementById('sq162-'+side+'-canvas'),p=c._sqMap.pt({x:xy[0],y:xy[1]}),r=c.getBoundingClientRect();return{x:r.left+p.x,y:r.top+p.y}}''',{'side':side,'xy':xy})
            page.mouse.click(q['x'],q['y']);page.wait_for_timeout(50)
        details=page.locator('#sq162-transform-details').inner_text()
        for phrase in ['المصدر 1: X=100 | Y=200','المصدر 2: X=110 | Y=200','المرجع 1: X=1000 | Y=2000','المرجع 2: X=1000 | Y=2020']:
            assert phrase in details,(phrase,details)
        assert 'الدوران المحسوب: 90' in details,details
        # Reloading the reference board must clear every old pick, including source picks.
        tgt2=td/'target-reloaded.dxf'
        tgt2.write_text(dxf('', 'TARGET2', ((2000,3000),(2000,3020),(1980,3020),(1980,3000)), (1980,2000,3000,3020)),encoding='ascii')
        page.locator('#sq162-target-file').set_input_files(str(tgt2));page.wait_for_timeout(150)
        assert page.locator('#sq162-save-oriented').is_disabled(), 'save must be disabled after target reload'
        # New current session: reselect all four points from the current canvases.
        for i,side,xy in [(0,'source',(100,200)),(1,'source',(110,200)),(2,'target',(2000,3000)),(3,'target',(2000,3020))]:
            page.locator(f'[data-sq-snap="{side}"]').select_option('nearest')
            page.locator(f'#sq162-pick-{i}').click()
            q=page.evaluate('''({side,xy})=>{const c=document.getElementById('sq162-'+side+'-canvas'),p=c._sqMap.pt({x:xy[0],y:xy[1]}),r=c.getBoundingClientRect();return{x:r.left+p.x,y:r.top+p.y}}''',{'side':side,'xy':xy})
            page.mouse.click(q['x'],q['y']);page.wait_for_timeout(50)
        details=page.locator('#sq162-transform-details').inner_text()
        for phrase in ['المصدر 1: X=100 | Y=200','المصدر 2: X=110 | Y=200','المرجع 1: X=2000 | Y=3000','المرجع 2: X=2000 | Y=3020']:
            assert phrase in details,(phrase,details)
        assert 'الدوران المحسوب: 90' in details,details
        page.locator('#sq162-oriented-name').fill('Site_Reference_Aligned')
        page.locator('#sq162-do-align').click();page.wait_for_timeout(80)
        assert page.locator('#sq162-save-oriented').is_enabled()
        page.locator('#sq162-save-oriented').click();page.wait_for_timeout(200)
        saved=page.evaluate('({saved:window.__nativeSaved,notified:window.__notified,status:document.getElementById("sq162-align-status").textContent})')
        assert saved['saved'] and saved['notified'],saved
        assert saved['saved']['filename']=='Site_Reference_Aligned.dxf',saved
        raw=base64.b64decode(saved['saved']['base64'])
        assert len(raw)>100 and b'ENTITIES' in raw and b'VERTEX' in raw
        a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_bytes(raw)
        if errors: raise AssertionError('Browser page errors: '+repr(errors))
        print('PASS V179 orientation UI: target reload cleared all four stale picks; new points yielded 90-degree transform; custom name saved through void-return Android bridge mock; bytes='+str(len(raw)))
        print(saved['status'])
        browser.close()
