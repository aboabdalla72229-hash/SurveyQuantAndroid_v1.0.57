'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const html=fs.readFileSync(process.argv[2]||'index.html','utf8');
const m=html.match(/function readTextPoints\([\s\S]*?\n\}/);
assert.ok(m,'readTextPoints not found');
const parse=new Function(m[0]+';return readTextPoints;')();
function one(text,fmt){const p=parse(text,fmt);assert.equal(p.length,1,`expected one point for ${fmt}: ${JSON.stringify(p)}`);return p[0];}
let p=one('1001,576761.4460,858279.3570,12.345','PNT');assert.equal(p.id,'1001');assert.equal(p.e,576761.446);assert.equal(p.n,858279.357);assert.equal(p.z,12.345);
p=one('1002 576762.446 858280.357 13.000','TXT');assert.equal(p.id,'1002');assert.equal(p.e,576762.446);assert.equal(p.n,858280.357);
p=one('Point No,Easting,Northing,Elevation\n1003,576763.446,858281.357,14.5','CSV');assert.equal(p.id,'1003');assert.equal(p.e,576763.446);assert.equal(p.n,858281.357);
p=one('Elevation(Z),Point No.,Easting(X),Northing(Y)\n15.5,1004,576764.446,858282.357','CSV');assert.equal(p.id,'1004');assert.equal(p.e,576764.446);assert.equal(p.n,858282.357);assert.equal(p.z,15.5);
p=one('576765.446,858283.357,16.5','TXT');assert.equal(p.e,576765.446);assert.equal(p.n,858283.357);assert.equal(p.z,16.5);
const multi=parse('1,576761,858279,1\n2,576762,858280,2','PNT');assert.equal(multi.length,2);assert.deepEqual(multi.map(x=>x.id),['1','2']);
console.log(JSON.stringify({ok:true,cases:['numeric point ID excluded from coordinates (PNT)','numeric point ID excluded from coordinates (TXT)','header-based CSV columns','reordered header columns','three-coordinate row without ID','multiple rows'],axisConvention:'X=Easting, Y=Northing'},null,2));
