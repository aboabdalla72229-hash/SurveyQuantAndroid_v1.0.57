#!/usr/bin/env python3
"""Replace the app HTML, preserve the V184 signed Android package/runtime, and bump APK version to 1.0.185."""
from __future__ import annotations
import argparse, copy, struct, zipfile
from pathlib import Path

OLD_NAME = '1.0.184'
NEW_NAME = '1.0.185'
NEW_CODE = 185


def read_len8(data: bytes, pos: int):
    first = data[pos]
    if first & 0x80: return (((first & 0x7F) << 8) | data[pos + 1]), pos + 2
    return first, pos + 1


def read_len16(data: bytes, pos: int):
    first = struct.unpack_from('<H', data, pos)[0]
    if first & 0x8000:
        second = struct.unpack_from('<H', data, pos + 2)[0]
        return (((first & 0x7FFF) << 16) | second), pos + 4
    return first, pos + 2


def read_string_pool(data: bytes, chunk_start: int, chunk_size: int, header_size: int):
    if header_size < 28 or chunk_start + chunk_size > len(data):
        raise ValueError('invalid Android binary XML string pool')
    string_count, _, flags, strings_start, _ = struct.unpack_from('<IIIII', data, chunk_start + 8)
    if string_count > 100000: raise ValueError('unreasonable Android XML string count')
    offsets = chunk_start + header_size; strings_base = chunk_start + strings_start; utf8 = bool(flags & 0x100)
    strings = []; spans = []
    for index in range(string_count):
        rel = struct.unpack_from('<I', data, offsets + index * 4)[0]; p = strings_base + rel
        if utf8:
            _, p = read_len8(data, p); byte_len, p = read_len8(data, p); begin, end = p, p + byte_len
            strings.append(data[begin:end].decode('utf-8', errors='strict')); spans.append((begin, end, True))
        else:
            char_len, p = read_len16(data, p); begin, end = p, p + char_len * 2
            strings.append(data[begin:end].decode('utf-16le', errors='strict')); spans.append((begin, end, False))
    return strings, spans


def patch_manifest(manifest: bytes) -> bytes:
    if len(manifest) < 8 or struct.unpack_from('<H', manifest, 0)[0] != 0x0003:
        raise ValueError('AndroidManifest.xml is not Android binary XML')
    result = bytearray(manifest); pos = struct.unpack_from('<H', result, 2)[0]; total = struct.unpack_from('<I', result, 4)[0]
    if total > len(result) or total < pos: raise ValueError('invalid Android binary XML size')
    strings = None; spans = []; chunks = []
    while pos < total:
        if pos + 8 > total: raise ValueError('truncated Android XML chunk header')
        typ, header_size, chunk_size = struct.unpack_from('<HHI', result, pos)
        if chunk_size < header_size or pos + chunk_size > total: raise ValueError('invalid Android XML chunk bounds')
        chunks.append((pos, typ, header_size, chunk_size))
        if typ == 0x0001: strings, spans = read_string_pool(bytes(result), pos, chunk_size, header_size)
        pos += chunk_size
    if strings is None: raise ValueError('Android XML string pool not found')
    old_indices = [i for i, val in enumerate(strings) if val == OLD_NAME]
    if not old_indices and NEW_NAME not in strings:
        raise ValueError(f'manifest does not contain {OLD_NAME} or {NEW_NAME}')
    for idx in old_indices:
        begin, end, is_utf8 = spans[idx]; encoded = NEW_NAME.encode('utf-8' if is_utf8 else 'utf-16le')
        if len(encoded) != end - begin: raise ValueError('versionName replacement changes string-pool byte length')
        result[begin:end] = encoded; strings[idx] = NEW_NAME
    fields = []
    for chunk_pos, typ, _, chunk_size in chunks:
        if typ != 0x0102 or chunk_size < 36: continue
        node_name_idx = struct.unpack_from('<I', result, chunk_pos + 20)[0]
        if node_name_idx >= len(strings) or strings[node_name_idx] != 'manifest': continue
        attr_start = struct.unpack_from('<H', result, chunk_pos + 24)[0]
        attr_size = struct.unpack_from('<H', result, chunk_pos + 26)[0]
        attr_count = struct.unpack_from('<H', result, chunk_pos + 28)[0]
        if attr_size < 20 or attr_count > 1024: raise ValueError('invalid manifest attribute table')
        first = chunk_pos + 16 + attr_start
        for n in range(attr_count):
            at = first + n * attr_size; name_idx = struct.unpack_from('<I', result, at + 4)[0]
            if name_idx < len(strings) and strings[name_idx] == 'versionCode':
                vsize = struct.unpack_from('<H', result, at + 12)[0]; vtype = result[at + 15]
                if vsize < 8 or vtype not in (0x10, 0x11): raise ValueError('manifest versionCode is not integer')
                fields.append(at + 16)
    if len(fields) != 1: raise ValueError(f'expected exactly one versionCode field, found {len(fields)}')
    struct.pack_into('<I', result, fields[0], NEW_CODE)
    return bytes(result)


def package_apk(apk_in: Path, apk_out: Path, html_in: Path):
    if not apk_in.is_file() or apk_in.stat().st_size < 10_000_000:
        raise ValueError('V184 signed base APK missing or unexpectedly small')
    html_bytes = html_in.read_bytes(); html = html_bytes.decode('utf-8')
    if r"\p{Cntrl}" in html:
        raise ValueError('V185 filename sanitizer contains an invalid non-Unicode control-character regex.')
    required = (
        "onclick=\"openProjectPage('project1Card')\"",
        "onclick=\"openProjectPage('dropFilesCard')\"",
        'function parseDWGDatabase(db,options={}){',
        'window.parseFile = parseFile;',
        'sq-v117-universal-dwg-bridge',
        'mergeRawDxfBoards(target.bytes,source.bytes)',
        'pdfOperatorPathsToCad',
        'pdfTextToCad',
        'rejectIdentityAlignment',
        'id=\"sq163-pdfjs-worker\"',
        'SQ_V178_ORIENTATION_CAPTURE_AND_NATIVE_SAVE',
        'SQ_V179_TWO_BOARD_RESET_PDF_STROKE_AND_OUTPUT_NAMES',
        'SQ_V180_SESSION_ISOLATION_AND_HYBRID_PDF_TRACE',
        'SQ_V183_TRUE_INTERSECTION_AXIS_FIT_PDF_V180_OUTPUT',
        'SQ_V184_SEPARATE_ORIENTED_VIEW_FULL_R2004_PDF_DXF',
        'root.SurveyQuantCAD184 = api;',
        'id="sq162-oriented-canvas"',
        'function viewGeometry(which)',
        'PDF_DXF_R2004_TEMPLATE_B64',
        'AC1018',
        'BLOCK_RECORD',
        'state.views.oriented',
        'root.SurveyQuantCAD183 = api;',
        'resetSession: () => resetSessionImpl()',
        '/* sq185-fresh-board-session-isolation: per-side file token, per-session board provenance, no axis-fit view. */',
        'function resetAllBoardData()',
        'function clearBoardSide(which',
        'function setFitView(which,geom)',
        'sessionId:board?.sessionId??state.sessionId',
        'p.sessionId!==state.sessionId',
        'alignment.sessionId!==state.sessionId',
        'data-sq-zoom=\"fit\" type=\"button\">ملاءمة</button>',
        "if(id==='sqOrientationCard'||id==='sqPdfDxfCard')return;",
        "const allowed=mode==='nearest'?['nearest']:mode==='endpoint'?['endpoint']:mode==='midpoint'?['midpoint']:['intersection'];",
        'state.picks=[null,null,null,null]',
        'while(pos<bytes.length){',
        'function plainCadText(value)',
        'canvasFingerprint',
        'createOrientedDxfBytes(src.bytes,alignment.picks)',
        'if(!out?.bytes?.length||!Number(out.editCount))',
        'const filename=`${baseName}.dxf`;',
        'V183 restores the V180 one-file DXF output',
        'surveyquant:session-background',
        'SURVEYQUANT_V183_TRUE_INTERSECTION_AXIS_FIT_PDF_V180_OUTPUT',
        'SURVEYQUANT_V184_SEPARATE_ORIENTED_VIEW_FULL_R2004_PDF_DXF',
        'sq176-cad-project-host',
        'sq176-home-orientation-project',
        'sq176-home-pdf-project',
        'if(isCad(src)&&isCad(cad))',
        'dxfLines=rawText.split(/\\r?\\n/).map(v=>v.trim())',
        'samplePdfTextColors',
        'delete out._sqPathCache',
        'id="sq162-save-pdf-dxf"',
        'state.pdfResult={bytes:result.bytes.slice()',
        'pickMeta:state.picks.map(p=>({...p}))',
        'for(const frame of out.oleFrames||[])',
    )
    missing = [v for v in required if v not in html]
    if missing: raise ValueError('V185 HTML is missing required app/DWG/CAD/orientation/PDF/session-isolation markers: ' + ', '.join(missing))
    forbidden = (
        'sq155-alignment-core', 'sq155-alignment-command', 'sqOpenOrientationProject',
        'openOrientationProject', 'function solveAlignment', 'sqAlignmentPreviewFromBlocks',
        'SURVEYQUANT_API_BASE', 'sqInitAccess', 'sqAccessGate', 'startKashierPayment',
        'pollKashierStatus', 'openPaymentPage', 'closePaymentPage', 'paymentPage',
        'paymentCard', 'payment-shortcut', 'sqGateSubscribe',
    )
    forbidden = forbidden + ('axisViewBounds', 'fitAxesView', 'احتواء المحاور', 'data-sq-zoom=\"axes\"')
    retained = [v for v in forbidden if v in html]
    if retained: raise ValueError('V185 HTML still contains removed Alignment/payment/axis-fit markers: ' + ', '.join(retained))
    apk_out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(apk_in, 'r') as zin:
        names = [x.filename for x in zin.infolist()]
        if names.count('assets/index.html') != 1 or names.count('AndroidManifest.xml') != 1:
            raise ValueError('APK must contain exactly one assets/index.html and AndroidManifest.xml')
        wasm_js = 'assets/libredwg-writer/wasm/libredwg-web.js'
        wasm_bin = 'assets/libredwg-writer/wasm/libredwg-web.wasm'
        umd = 'assets/libredwg-writer/dist/libredwg-web.js'
        for name in (wasm_js, wasm_bin, umd):
            if names.count(name) != 1: raise ValueError('Base APK missing/duplicates DWG runtime asset: ' + name)
        if len(zin.read(wasm_bin)) < 1_000_000: raise ValueError('Existing LibreDWG WASM runtime is unexpectedly small')
        if len(zin.read(umd)) < 100_000: raise ValueError('Existing LibreDWG UMD loader is unexpectedly small')
        seen = set()
        with zipfile.ZipFile(apk_out, 'w', allowZip64=True) as zout:
            for info in zin.infolist():
                name = info.filename
                if name in seen: raise ValueError('duplicate APK entry: ' + name)
                seen.add(name); upper = name.upper()
                if upper.startswith('META-INF/') and (upper.endswith('.SF') or upper.endswith('.RSA') or upper.endswith('.DSA') or upper.endswith('.EC') or upper.endswith('MANIFEST.MF')):
                    continue
                data = zin.read(name)
                if name == 'assets/index.html': data = html_bytes
                elif name == 'AndroidManifest.xml': data = patch_manifest(data)
                zout.writestr(copy.copy(info), data)
    with zipfile.ZipFile(apk_out, 'r') as check:
        if check.read('assets/index.html') != html_bytes: raise ValueError('APK HTML differs from tested V185 HTML')
        manifest = check.read('AndroidManifest.xml')
        if patch_manifest(manifest) != manifest: raise ValueError('APK manifest is not idempotently V185')
        if len(check.read(wasm_bin)) < 1_000_000: raise ValueError('APK lost its shared DWG runtime')
    print('PASS V185 APK integrity: signed V184 base retained; fresh source/reference sessions, strict board/file/session provenance, transformed preview cache and OLE frame isolation, expanded axis/text capture, retryable explicit PDF native-save flow, AC1018 R2004 DXF structure and LibreDWG runtime assets verified; version bumped to 1.0.185/185. APK remains unsigned for workflow signing.')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--apk-input', type=Path, required=True)
    p.add_argument('--apk-output', type=Path, required=True)
    p.add_argument('--html-to-inject', type=Path, required=True)
    a = p.parse_args()
    package_apk(a.apk_input, a.apk_output, a.html_to_inject)

if __name__ == '__main__': main()
