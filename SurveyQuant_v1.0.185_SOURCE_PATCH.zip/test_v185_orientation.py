from pathlib import Path
from playwright.sync_api import sync_playwright
import shutil, json, base64
import ezdxf, ezdxf.recover

ROOT = Path(__file__).resolve().parent
HTML = (ROOT / 'index.html').read_text(encoding='utf-8')
SOURCE = (ROOT / 'source_v184.dxf').read_bytes()
TARGET = (ROOT / 'target_v184.dxf').read_bytes()
ALT = (ROOT / 'target_reset_v184.dxf').read_bytes()

with sync_playwright() as p:
    chrome = shutil.which('chromium') or shutil.which('chromium-browser')
    opts = {'headless': True, 'args': ['--no-sandbox', '--disable-dev-shm-usage']}
    if chrome:
        opts['executable_path'] = chrome
    browser = p.chromium.launch(**opts)
    page = browser.new_page(viewport={'width': 430, 'height': 900})
    page_errors = []
    page.on('pageerror', lambda e: page_errors.append(str(e)))
    page.set_content(HTML, wait_until='domcontentloaded', timeout=60000)
    page.evaluate("window.__saved={};window.Android={saveFile:(n,m,b)=>{window.__saved[n]={mime:m,base64:b};return 'Downloads/'+n;},notifyDownload:()=>{}}")

    def assert_blank(label):
        values = page.evaluate("""() => ({
          source: document.querySelector('#sq162-source-canvas')._sqMap,
          target: document.querySelector('#sq162-target-canvas')._sqMap,
          oriented: document.querySelector('#sq162-oriented-canvas')._sqMap,
          sourceInfo: document.querySelector('#sq162-source-info').textContent,
          targetInfo: document.querySelector('#sq162-target-info').textContent,
          orientedInfo: document.querySelector('#sq162-oriented-info').textContent,
          name: document.querySelector('#sq162-oriented-name').value,
          details: document.querySelector('#sq162-transform-details').textContent
        })""")
        assert values['source'] is None and values['target'] is None and values['oriented'] is None, (label, values)
        assert 'لم يتم اختيار ملف بعد' in values['sourceInfo'], (label, values['sourceInfo'])
        assert 'لم يتم اختيار ملف بعد' in values['targetInfo'], (label, values['targetInfo'])
        assert values['name'] == '', (label, values['name'])
        return values

    def click_picker(which):
        # Dispatch the UI click handler without opening the operating-system file dialog.
        page.locator(f'#sq162-{which}-file').evaluate("e=>e.dispatchEvent(new MouseEvent('click',{bubbles:true}))")

    def set_file(which, name, content):
        click_picker(which)
        page.locator(f'#sq162-{which}-file').set_input_files({
            'name': name,
            'mimeType': 'application/dxf',
            'buffer': content,
        })
        page.wait_for_function(
            f"document.querySelector('#sq162-{which}-info').textContent.includes('بصمة CAD')",
            timeout=30000,
        )

    def map_data(which):
        return page.locator(f'#sq162-{which}-canvas').evaluate("""c => c._sqMap && ({
          which:c._sqMap.which, sessionId:c._sqMap.sessionId,
          file:c._sqMap.boardFileName, fp:c._sqMap.boardFingerprint,
          cad:c._sqMap.cadFingerprint,
          bounds:[c._sqMap.geom.minX,c._sqMap.geom.minY,c._sqMap.geom.maxX,c._sqMap.geom.maxY]
        })""")

    def pick(slot, canvas_id, xy):
        page.locator(f'#sq162-pick-{slot}').click()
        pos = page.locator(f'#{canvas_id}').evaluate("""(c,xy)=>{
          const m=c._sqMap, p=m.pt({x:xy[0],y:xy[1]}), r=c.getBoundingClientRect();
          return {x:r.left+p.x,y:r.top+p.y};
        }""", xy)
        page.mouse.click(pos['x'], pos['y'])
        page.wait_for_timeout(100)

    # Enter the project and require an empty first session.
    page.locator('#sq176-home-orientation-project').click()
    page.wait_for_timeout(250)
    assert_blank('initial project entry')

    # The first chosen board must populate only its own screen.
    set_file('source', 'source_v184.dxf', SOURCE)
    source_map = map_data('source')
    target_map = map_data('target')
    assert source_map and source_map['bounds'] == [0, 0, 10, 5], source_map
    assert source_map['which'] == 'source' and target_map is None, (source_map, target_map)

    # Same filename, different bytes: the target must use its own file bytes and coordinates.
    set_file('target', 'source_v184.dxf', TARGET)
    target_map = map_data('target')
    source_map = map_data('source')
    assert target_map and target_map['which'] == 'target', target_map
    assert target_map['bounds'] == [90, 100, 100, 120], target_map
    assert source_map and source_map['bounds'] == [0, 0, 10, 5], source_map
    assert target_map['cad'] != source_map['cad'], (source_map, target_map)
    assert target_map['sessionId'] == source_map['sessionId'], (source_map, target_map)

    # Fit UI is now one operation only, and it always uses the full board extents.
    fit_buttons = page.locator('[data-sq-zoom="fit"]')
    assert fit_buttons.count() == 3
    assert all('ملاءمة' in fit_buttons.nth(i).inner_text() for i in range(3))
    assert page.locator('[data-sq-zoom="axes"]').count() == 0
    assert 'احتواء المحاور' not in HTML

    # Pick two actual source coordinates and two actual target coordinates.
    page.locator('[data-sq-snap="source"]').select_option('endpoint')
    page.locator('[data-sq-snap="target"]').select_option('endpoint')
    pick(0, 'sq162-source-canvas', [0, 0])
    pick(1, 'sq162-source-canvas', [10, 0])
    pick(2, 'sq162-target-canvas', [100, 100])
    pick(3, 'sq162-target-canvas', [100, 120])
    details = page.locator('#sq162-transform-details').inner_text()
    assert 'X=0' in details and 'X=10' in details and 'X=100' in details and 'Y=120' in details and 'المرجع 1' in details and 'المرجع 2' in details, details
    assert page.locator('#sq162-do-align').is_enabled()
    page.locator('#sq162-do-align').click()
    page.wait_for_timeout(300)
    oriented = page.locator('#sq162-oriented-canvas').evaluate("c=>c._sqMap&&({which:c._sqMap.which,bounds:[c._sqMap.geom.minX,c._sqMap.geom.minY,c._sqMap.geom.maxX,c._sqMap.geom.maxY]})")
    assert oriented and oriented['which'] == 'oriented' and oriented['bounds'] == [90, 100, 100, 120], oriented
    assert page.locator('#sq162-save-oriented').is_enabled()
    page.locator('#sq162-save-oriented').click()
    page.wait_for_function('Object.keys(window.__saved).length>0', timeout=30000)
    saved = page.evaluate('window.__saved')
    out_name = list(saved)[0]
    out_path = ROOT / 'V185_ORIENTED_RESULT.dxf'
    out_path.write_bytes(base64.b64decode(saved[out_name]['base64']))
    doc, _ = ezdxf.recover.readfile(out_path)
    audit = doc.audit()
    assert doc.dxfversion == 'AC1018' and len(doc.modelspace()) > 0 and not audit.errors and not audit.fixes

    # A new file selection after a complete pair MUST clear both screens before loading the new file.
    click_picker('target')
    blank_between = assert_blank('complete pair replaced')
    page.locator('#sq162-target-file').set_input_files({
        'name': 'source_v184.dxf', 'mimeType': 'application/dxf', 'buffer': ALT
    })
    page.wait_for_function("document.querySelector('#sq162-target-info').textContent.includes('بصمة CAD')", timeout=30000)
    target_only = map_data('target')
    assert target_only and target_only['bounds'] == [500, 600, 510, 610], target_only
    assert map_data('source') is None and map_data('oriented') is None
    assert 'لم يتم اختيار ملف بعد' in page.locator('#sq162-source-info').inner_text()
    assert page.locator('#sq162-pick-0').is_disabled() and page.locator('#sq162-pick-2').is_disabled(), 'reference picks remain locked until source pair is selected'

    # Loading the missing source in the same new session keeps only the just-selected target.
    set_file('source', 'source_v184.dxf', SOURCE)
    source_again = map_data('source')
    target_again = map_data('target')
    assert source_again and source_again['bounds'] == [0, 0, 10, 5], source_again
    assert target_again and target_again['bounds'] == [500, 600, 510, 610], target_again
    assert source_again['sessionId'] == target_again['sessionId']
    assert page.locator('#sq162-pick-0').is_enabled() and page.locator('#sq162-pick-2').is_disabled()

    # Leaving and reopening the project must never restore either file or any picked coordinates.
    page.locator('.project-back').click()
    page.wait_for_timeout(200)
    page.locator('#sq176-home-orientation-project').click()
    page.wait_for_timeout(250)
    reentry = assert_blank('project reopen')

    report = {
      'result': 'PASS V185 clean session isolation, strict board provenance, full-board fit, R2004 oriented DXF',
      'same_filename_different_bytes': {'source_bounds': source_map['bounds'], 'target_bounds': target_map['bounds'], 'different_cad_fingerprints': target_map['cad'] != source_map['cad']},
      'first_pair_session_id': source_map['sessionId'],
      'orientation': {'oriented_bounds': oriented['bounds'], 'saved_file': out_path.name, 'entities': len(doc.modelspace()), 'dxf_version': doc.dxfversion, 'audit_errors': len(audit.errors), 'audit_fixes': len(audit.fixes)},
      'complete_pair_replacement': {'both_screens_cleared_before_new_target': blank_between['source'] is None and blank_between['target'] is None, 'target_only_after_reload': target_only['bounds'], 'source_screen_empty': True},
      'second_pair': {'source_bounds': source_again['bounds'], 'target_bounds': target_again['bounds'], 'session_id': source_again['sessionId']},
      'project_reopen': {'both_canvases_empty': reentry['source'] is None and reentry['target'] is None, 'output_name_empty': reentry['name'] == ''},
      'axis_fit_controls': {'fit_buttons': fit_buttons.count(), 'axis_buttons': 0, 'fit_label': 'ملاءمة'},
      'page_errors': page_errors[:10],
    }
    (ROOT / 'V185_ORIENTATION_TEST_LOG.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    browser.close()
