'use strict';
const assert = require('node:assert/strict');
const CAD = require('./SurveyQuant_v1.0.162_CAD_ENGINE.js');
const close = (a,b,eps=1e-7) => assert.ok(Math.abs(a-b) < eps, `${a} != ${b}`);

// A 10-unit source baseline must align to a 20-unit vertical target baseline:
// 2x scale, +90 degrees, with A mapped exactly to C and B to D.
const transform = CAD.solve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
close(transform.scale,2); close(transform.rotationDegrees,90);
const mappedA = transform.apply({x:0,y:0}), mappedB = transform.apply({x:10,y:0});
close(mappedA.x,100); close(mappedA.y,200); close(mappedB.x,100); close(mappedB.y,220);

const fixture = [
  '0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','0','ENDSEC',
  '0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','2',
  '0','LAYER','5','10','2','0','70','0','62','7','6','CONTINUOUS',
  '0','LAYER','5','11','2','ROADS','70','0','62','1','6','CONTINUOUS','0','ENDTAB','0','ENDSEC',
  '0','SECTION','2','ENTITIES',
  '0','LINE','5','20','100','AcDbEntity','8','ROADS','100','AcDbLine','10','0','20','0','30','0','11','10','21','0','31','0',
  '0','CIRCLE','5','21','8','ROADS','10','1','20','2','30','0','40','3',
  '0','TEXT','5','22','8','ROADS','10','1','20','1','40','2','1','AXIS A',
  '0','ENDSEC','0','EOF',''
].join('\r\n');
const input = new TextEncoder().encode(fixture);
const out = CAD.transformDxfBytes(input,{x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
const text = new TextDecoder('windows-1252').decode(out.bytes);
assert.ok(text.includes('0\r\nLINE\r\n5\r\n20\r\n100\r\nAcDbEntity\r\n8\r\nROADS'), 'entity order, handle and layer must remain');
assert.ok(text.includes('10\r\n100\r\n20\r\n200\r\n30\r\n0\r\n11\r\n100\r\n21\r\n220'), 'line endpoints must be aligned');
assert.ok(text.includes('10\r\n96\r\n20\r\n202\r\n30\r\n0\r\n40\r\n6'), 'circle center transforms and radius scales');
assert.ok(text.includes('1\r\nAXIS A'), 'text content must remain unchanged');
assert.ok(text.includes('2\r\nROADS'), 'layer name remains present');
assert.ok(out.editCount >= 8, 'expected entity coordinates and dimensions to be edited');

const geometry = CAD.readGeometry(input);
assert.ok(geometry.segments.length >= 1, 'preview geometry reads LINE entities');
const picked = CAD.nearestPoint(geometry,{x:4,y:0.1});
close(picked.x,4); close(picked.y,0);
let degenerate = false;
try { CAD.solve({x:1,y:1},{x:1,y:1},{x:0,y:0},{x:2,y:2}); } catch (_) { degenerate = true; }
assert.ok(degenerate, 'coincident control points must be rejected');

const traced = CAD.svgPathToPolylines('M 0 0 L 10 0 L 10 10 Z');
assert.equal(traced.length,1); assert.ok(traced[0].closed); assert.ok(traced[0].points.length >= 4);
const imageDxf = CAD.polylinesToDxf(traced,20,20,1);
assert.ok(new TextDecoder().decode(imageDxf.bytes).includes('POLYLINE'));
console.log('PASS V162: two-point similarity alignment, raw DXF coordinate edits, layer/handle/text retention, snap-preview, degenerate-point protection, and raster-trace DXF output.');
