'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const html=fs.readFileSync(process.argv[2],'utf8');
const tag=id=>{const re=new RegExp(`<script type="application/octet-stream" id="${id}">([\\s\\S]*?)<\\/script>`);const m=html.match(re);assert.ok(m,`payload ${id} exists`);return Buffer.from(m[1].trim(),'base64');};
const bootMatch=html.match(/<script id="sq163-runtime-bootstrap">([\s\S]*?)<\/script>/);
assert.ok(bootMatch,'runtime bootstrap exists');
const embedded={
 'sq163-imagetracer':tag('sq163-imagetracer'),
 'sq163-pdfjs-main':tag('sq163-pdfjs-main'),
 'sq163-pdfjs-worker':tag('sq163-pdfjs-worker'),
 'sq163-cad-engine':tag('sq163-cad-engine'),
};
assert.ok(embedded['sq163-pdfjs-main'].length>100000,'real PDF.js main bundle is embedded');
assert.ok(embedded['sq163-pdfjs-worker'].length>100000,'real PDF.js worker bundle is embedded');
assert.ok(embedded['sq163-imagetracer'].length>10000,'real ImageTracer bundle is embedded');
// Simulate evaluation of each Blob script with tiny globals. The actual npm
// bundles are size-checked above and syntax-checked separately by the workflow.
const payloads={
 'sq163-imagetracer':Buffer.from('window.ImageTracer={imagedataToSVG:function(){return "";}};'),
 'sq163-pdfjs-main':Buffer.from('window.pdfjsLib={GlobalWorkerOptions:{},getDocument:function(){}};'),
 'sq163-pdfjs-worker':Buffer.from('self.onmessage=function(){};'),
 'sq163-cad-engine':Buffer.from('window.SurveyQuantCAD163={mount:function(){}};'),
};
const urlMap=new Map();let seq=0;
const fakeURL={createObjectURL:blob=>{const url=`blob:sq-test-${++seq}`;urlMap.set(url,blob);return url;},revokeObjectURL:url=>urlMap.delete(url)};
const nodes={};for(const [id,bytes] of Object.entries(payloads)){nodes[id]={textContent:bytes.toString('base64'),remove(){delete nodes[id];}};}
const document={
 getElementById:id=>nodes[id]||null,
 createElement:tag=>({tagName:tag,async:true,src:'',onload:null,onerror:null}),
 head:{appendChild(script){(async()=>{try{const blob=urlMap.get(script.src);assert.ok(blob,`blob script ${script.src} exists`);const source=await blob.text();vm.runInContext(source,context);script.onload&&script.onload();}catch(e){script.onerror&&script.onerror(e);}})();}},
 documentElement:{appendChild(){throw new Error('unexpected root append');}},
};
const context={console,document,URL:fakeURL,Blob,atob,Uint8Array,TextDecoder,TextEncoder,Promise,Map,Set,Error,CustomEvent:function(type){this.type=type;},
 addEventListener(){},dispatchEvent(){},};
context.window=context;context.document=document;context.URL=fakeURL;context.addEventListener=()=>{};context.dispatchEvent=()=>{};
vm.createContext(context);
(async()=>{
 vm.runInContext(bootMatch[1],context);
 for(let i=0;i<80&&!context.__sq163RuntimeReady&&!context.__sq163RuntimeError;i++)await new Promise(r=>setTimeout(r,10));
 assert.equal(context.__sq163RuntimeReady,true,`runtime bootstrap error: ${context.__sq163RuntimeError||'not ready'}`);
 assert.ok(context.pdfjsLib&&typeof context.pdfjsLib.getDocument==='function','PDF.js API loaded');
 assert.ok(context.pdfjsLib.GlobalWorkerOptions.workerSrc.startsWith('blob:sq-test-'),'PDF.js workerSrc points to a local embedded worker blob');
 assert.ok(context.SurveyQuantCAD163&&typeof context.SurveyQuantCAD163.mount==='function','CAD engine registered');
 assert.ok(context.ImageTracer&&typeof context.ImageTracer.imagedataToSVG==='function','ImageTracer registered');
 console.log('PASS V163 PDF.js bootstrap: PDF worker payload is decoded locally and GlobalWorkerOptions.workerSrc is set before CAD runtime is marked ready.');
})().catch(e=>{console.error(e);process.exit(1);});
