# حزمة بناء SurveyQuant V163 من أساس V162

## الملفات ومساراتها داخل مستودع GitHub
1. `.github/workflows/build-v163-pdf-fidelity-original-cad-alignment.yml`
2. `build_assets/SurveyQuant_v1.0.163_PATCH_V162.py`
3. `build_assets/SurveyQuant_v1.0.163_CAD_ENGINE_TEST.js`

استخرج ملفات ZIP ثم ارفع الملفات الثلاثة إلى نفس المسارات أعلاه في مستودع:
`aboabdalla72229-hash/SurveyQuantAndroid_v1.0.57`

بعد عمل Commit على فرع `main` سيبدأ Workflow تلقائيًا، أو يمكن تشغيله يدويًا من Actions باسم:
`Build SurveyQuant v1.0.163 PDF Fidelity and Original CAD Alignment`

يستخدم Workflow ملف الأساس من V162 Actions run رقم `40919113310`، ويستخدم أسرار التوقيع الموجودة حاليًا في إعدادات GitHub Actions. لا تغيّر رقم الـRun الافتراضي إلا عند الحاجة.

بعد انتهاء البناء بنجاح، افتح الـRun ثم Artifacts، ونزّل:
`SurveyQuant-v1.0.163-V162-PDF-FIDELITY-ORIGINAL-CAD-ALIGNMENT`

الحزمة تشمل APK موقعًا، Source Patch، وملفات الفحص.

## ملاحظة التحقق
تم إنشاء نسخة APK محلية unsigned واجتازت سلامة ZIP. لم يتم رفع هذه الملفات إلى GitHub أو تشغيل Workflow عن بُعد من داخل هذه الجلسة لأن تكامل GitHub رفض صلاحيات الكتابة (HTTP 403 Resource not accessible by integration). لذلك هذه الحزمة جاهزة لإضافتها للمستودع، لكنها ليست دليلًا على صدور APK موقع من GitHub بالفعل.
