'use strict';
const assert=require('assert'),fs=require('fs'),vm=require('vm');
const [enginePath,manualPath,fixPath]=process.argv.slice(2);
assert(enginePath&&manualPath&&fixPath,'Usage: test.js v106-engine.js v109-manual.js v111-fix.js');
const document={readyState:'loading',addEventListener(){},getElementById(){return null;}};
const window={addEventListener(){},removeEventListener(){}};
const ctx={window,document,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,Blob,URL,Math,Number,String,Map,Set,Array,Object,RegExp,Error,Infinity,Promise,JSON,parseInt,parseFloat};vm.createContext(ctx);
vm.runInContext(fs.readFileSync(enginePath,'utf8'),ctx,{filename:'orientation-engine'});
vm.runInContext(fs.readFileSync(manualPath,'utf8'),ctx,{filename:'manual-orientation-109'});
vm.runInContext(fs.readFileSync(fixPath,'utf8'),ctx,{filename:'dxf-resilience-111'});
const api=window.__sqOrientation111API;assert(api&&api.VERSION==='1.0.111','v111 API failed to initialize');
function dxf(lines){return new TextEncoder().encode(lines.join('\n')+'\n');}
const src=['0','SECTION','2','ENTITIES','0','LINE','8','S','10','0','20','0','11','10','21','0','0','TEXT','8','T','10','5','20','3','40','1','1','KEEP','0','ENDSEC','0','EOF',''];
const bytes=dxf(src);const parsed=api.splitPairs(bytes);assert(parsed.pairs.length>10&&parsed.recoveryCount===0,'clean DXF must parse without recovery');
const del=api.deleteNearestEntityBytes(bytes,{x:5,y:0},0.05),dt=new TextDecoder().decode(del.bytes);assert.strictEqual(del.deletedType,'LINE');assert(!dt.includes('\nS\n')&&dt.includes('KEEP'),'normal delete must remove only selected line');
const map=['0','SECTION','2','BLOCKS','0','BLOCK','8','0','2','TEST_BLOCK','10','0','20','0','0','LINE','8','BL','10','0','20','0','11','10','21','0','0','ENDBLK','8','0','0','ENDSEC','0','SECTION','2','ENTITIES','0','INSERT','8','I','2','TEST_BLOCK','10','100','20','200','41','1','42','1','50','0','0','ENDSEC','0','EOF',''];
const mb=dxf(map);const md=api.deleteNearestEntityBytes(mb,{x:105,y:200},0.15),mt=new TextDecoder().decode(md.bytes);assert.strictEqual(md.deletedType,'INSERT','clicking visible block geometry should select its INSERT instance');assert(!mt.includes('\nINSERT\n')&&mt.includes('TEST_BLOCK')&&mt.includes('BL'),'deleting one block insertion must keep shared block definition');
// Simulate one malformed/unpaired line within a file. The preview should recover at the next DXF entity boundary.
const damaged=dxf(['0','SECTION','2','ENTITIES','0','LINE','8','A','10','0','20','0','11','10','21','0','THIS-IS-NOT-A-GROUP-CODE','bad data','0','LINE','8','B','10','20','20','20','11','30','21','20','0','TEXT','8','T','10','5','20','3','40','1','1','RECOVERED_TEXT','0','ENDSEC','0','EOF','']);
const recovery=api.splitPairs(damaged);assert(recovery.recoveryCount>=1,'malformed file should report a recovered pair alignment');
const originalParse=window.__sqManualOrientation109.parseDrawing;window.__sqManualOrientation109.parseDrawing=()=>{throw new Error('تعذر قراءة بنية DXF عند السطر 1397729.');};
const preview=api.parsePreview(damaged);assert(preview.entityCount>=2,'fallback must enumerate post-recovery entities');assert(preview.segs.length>=2,'fallback preview should draw common entities after parser recovery');assert(preview.texts.some(t=>String(t.text).includes('RECOVERED_TEXT')),'fallback preview should render text entities');assert(preview.previewRecoveryMessage,'reference preview should explain nonfatal recovery');window.__sqManualOrientation109.parseDrawing=originalParse;
const tr=api.solve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});const proxy=dxf(['0','SECTION','2','ENTITIES','0','ACAD_PROXY_ENTITY','8','PXY','10','0','20','0','11','10','21','0','30','9','210','0','220','1','230','0','1000','KEEP_XDATA','0','ENDSEC','0','EOF','']);
const transformed=api.transformBytes(proxy,tr),tt=new TextDecoder().decode(transformed.bytes);assert(tt.includes('KEEP_XDATA')&&tt.includes('30\n9')&&tt.includes('220\n1'),'transform should preserve non-XY bytes');assert(transformed.changedFields>=4,'proxy exposed XY coordinates should be transformed');
const ui=fs.readFileSync(fixPath,'utf8');for(const token of ['sq110TargetCanvas','sq110ReferenceCanvas','sq110Delete','sq110UndoDelete','recoveredPairs','geometryInWorld','window.__sqOrientation111API'])assert(ui.includes(token),'missing integration: '+token);
console.log('PASS v1.0.111: recover malformed DXF for preview; render common entities/text; match/delete visible INSERT instance; ordinary delete; XY transform preserves Z/XData; existing two-board UI retained.');
