#!/usr/bin/env python3
from __future__ import annotations
import argparse,base64,re
from pathlib import Path

META='<meta name="surveyquant-v170" content="sq170-orientation-canvas-zoom-per-board-picks-snap-wasm-binary-pdf-worker-ole-reader">'
SLOT=re.compile(r'(<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">)([A-Za-z0-9+/=\r\n]+)(</script>)',re.I)

def embed_engine(html:str,engine:bytes)->str:
    data=base64.b64encode(engine).decode('ascii')
    out,n=SLOT.subn(lambda m:m.group(1)+data+m.group(3),html,count=1)
    if n!=1:raise ValueError(f'Expected exactly one CAD engine payload slot, found {n}')
    return out

def patch_html(html:str,engine:bytes)->str:
    if 'sq169-orientation-save-block-axis-content-identity-single-dxf-ole' not in html:raise ValueError('V169 baseline is required before applying V170')
    if 'sq170-orientation-canvas-zoom-per-board-picks-snap-wasm-binary-pdf-worker-ole-reader' in html:raise ValueError('V170 is already applied')
    head=re.search(r'<head\b[^>]*>',html,re.I)
    if not head:raise ValueError('HTML head missing')
    html=html[:head.end()]+META+html[head.end():]
    old='<meta content="width=device-width, initial-scale=1.0" name="viewport"/>'
    new='<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport"/>'
    if html.count(old)!=1:raise ValueError('Expected V169 viewport meta exactly once')
    html=html.replace(old,new,1)
    old="""   await sqLoadClassicScriptOnce(SQ_WRITER_WASM_URL,()=>typeof window.createModule==='function');
   await sqLoadClassicScriptOnce(SQ_WRITER_ENGINE_URL,()=>!!(window.SurveyQuantLibreDwg&&window.SurveyQuantLibreDwg.LibreDwg));
   return window.SurveyQuantLibreDwg;
"""
    new="""   await sqLoadClassicScriptOnce(SQ_WRITER_WASM_URL,()=>typeof window.createModule==='function');
   await sqLoadClassicScriptOnce(SQ_WRITER_ENGINE_URL,()=>!!(window.SurveyQuantLibreDwg&&window.SurveyQuantLibreDwg.LibreDwg));
   const mod=window.SurveyQuantLibreDwg,LibreDwg=mod&&(mod.LibreDwg||mod.default?.LibreDwg);
   if(!LibreDwg||typeof LibreDwg.createByWasmInstance!=='function')throw new Error('محرك DWG لا يوفّر إنشاءً مباشرًا من WASM المضمّن.');
   const wasmBinary=window.SQ_DWG_WASM_BINARY;
   if(!(wasmBinary instanceof Uint8Array)||wasmBinary.byteLength<1000000)throw new Error('ملف WASM المضمّن غير صالح.');
   const wasmBase=sqDwgWasmRuntimePath();
   const wasmInstance=await window.createModule({wasmBinary,locateFile:(filename)=>`${wasmBase}/${filename}`});
   mod.__surveyQuantWasmInstance=wasmInstance;
   return mod;
"""
    if html.count(old)!=1:raise ValueError('Main-thread WASM factory initialization point not found uniquely')
    html=html.replace(old,new,1)
    old=""" ' if(!sqEnginePromise){try{if(!payload.wasmBinaryBuffer||payload.wasmBinaryBuffer.byteLength<1000000)throw new Error("بيانات WASM المرسلة إلى عامل DWG غير مكتملة.");self.SQ_DWG_WASM_BINARY=new Uint8Array(payload.wasmBinaryBuffer);importScripts(payload.wasmScriptUrl,payload.engineScriptUrl);const mod=self.SurveyQuantLibreDwg;const LibreDwg=mod&&(mod.LibreDwg||mod.default&&mod.default.LibreDwg);if(!LibreDwg||typeof LibreDwg.create!=="function")throw new Error("واجهة محرك LibreDWG غير موجودة داخل العامل.");sqEnginePromise=LibreDwg.create(payload.wasmBase);}catch(e){sqEngineFatal=true;throw e;}}',
"""
    new=""" ' if(!sqEnginePromise){try{if(!payload.wasmBinaryBuffer||payload.wasmBinaryBuffer.byteLength<1000000)throw new Error("بيانات WASM المرسلة إلى عامل DWG غير مكتملة.");self.SQ_DWG_WASM_BINARY=new Uint8Array(payload.wasmBinaryBuffer);importScripts(payload.wasmScriptUrl,payload.engineScriptUrl);const mod=self.SurveyQuantLibreDwg;const LibreDwg=mod&&(mod.LibreDwg||mod.default&&mod.default.LibreDwg);if(!LibreDwg||typeof LibreDwg.createByWasmInstance!=="function"||typeof self.createModule!=="function")throw new Error("واجهة محرك LibreDWG غير موجودة داخل العامل.");const wasmInstance=await self.createModule({wasmBinary:self.SQ_DWG_WASM_BINARY,locateFile:function(filename){return payload.wasmBase.replace(/\\/+$/,"")+"/"+filename;}});sqEnginePromise=Promise.resolve(LibreDwg.createByWasmInstance(wasmInstance));}catch(e){sqEngineFatal=true;throw e;}}',
"""
    if html.count(old)!=1:raise ValueError('DWG worker WASM initialization point not found uniquely')
    html=html.replace(old,new,1)
    old="""   const mod=await loadDWG(),LibreDwg=mod.LibreDwg||mod.default?.LibreDwg;
   if(!LibreDwg||typeof LibreDwg.create!=='function')throw new Error('محرك DWG لم يُحمّل بالشكل المتوقع');
   lib=await LibreDwg.create(sqDwgWasmRuntimePath());
"""
    new="""   const mod=await loadDWG(),LibreDwg=mod.LibreDwg||mod.default?.LibreDwg;
   if(!LibreDwg||typeof LibreDwg.createByWasmInstance!=='function'||!mod.__surveyQuantWasmInstance)throw new Error('محرك DWG لم يُحمّل باستخدام WASM المضمّن بالشكل المتوقع');
   lib=LibreDwg.createByWasmInstance(mod.__surveyQuantWasmInstance);
"""
    if html.count(old)!=1:raise ValueError('Main-thread LibreDWG instance initialization point not found uniquely')
    html=html.replace(old,new,1)
    old=""" function makePdfWorkerUrl(){var bytes=readPayload('sq163-pdfjs-worker');var url=URL.createObjectURL(new Blob([bytes],{type:'text/javascript'}));window.__sq163PdfWorkerUrl=url;if(window.pdfjsLib&&window.pdfjsLib.GlobalWorkerOptions)window.pdfjsLib.GlobalWorkerOptions.workerSrc=url;else throw new Error('واجهة إعداد عامل PDF.js غير موجودة.');window.addEventListener('pagehide',function(){try{URL.revokeObjectURL(url);}catch(_){}},{once:true});}
 (async function(){
"""
    new=""" function makePdfWorkerUrl(){if(window.__sq163PdfWorkerUrl)return window.__sq163PdfWorkerUrl;var bytes=readPayload('sq163-pdfjs-worker');var url=URL.createObjectURL(new Blob([bytes],{type:'text/javascript'}));window.__sq163PdfWorkerUrl=url;if(window.pdfjsLib&&window.pdfjsLib.GlobalWorkerOptions)window.pdfjsLib.GlobalWorkerOptions.workerSrc=url;else throw new Error('واجهة إعداد عامل PDF.js غير موجودة.');window.addEventListener('pagehide',function(){try{URL.revokeObjectURL(url);}catch(_){}},{once:true});return url;}
 function installGlobalPdfWorkerGuard(){var lib=window.pdfjsLib;if(!lib||!lib.GlobalWorkerOptions||typeof lib.getDocument!=='function')throw new Error('تعذر تثبيت عامل PDF.js العام للمشروعات.');var url=makePdfWorkerUrl();lib.GlobalWorkerOptions.workerSrc=url;if(lib.getDocument.__sqV170WorkerGuard)return;var original=lib.getDocument;var guarded=function(){var current=window.__sq163PdfWorkerUrl||url;lib.GlobalWorkerOptions.workerSrc=current;return original.apply(this,arguments);};Object.defineProperty(guarded,'__sqV170WorkerGuard',{value:true});lib.getDocument=guarded;window.ensureSurveyQuantPdfWorker=function(){var active=window.__sq163PdfWorkerUrl||url;lib.GlobalWorkerOptions.workerSrc=active;return active;};}
 (async function(){
"""
    if html.count(old)!=1:raise ValueError('Global PDF worker URL function not found uniquely')
    html=html.replace(old,new,1)
    old='   makePdfWorkerUrl();\n   if(window.pdfjsLib.GlobalWorkerOptions.workerSrc!==window.__sq163PdfWorkerUrl)'
    new='   installGlobalPdfWorkerGuard();\n   if(window.pdfjsLib.GlobalWorkerOptions.workerSrc!==window.__sq163PdfWorkerUrl)'
    if html.count(old)!=1:raise ValueError('PDF worker guard installation point not found uniquely')
    html=html.replace(old,new,1)
    html=embed_engine(html,engine)
    validate(html,engine)
    return html

def validate(html:str,engine:bytes)->None:
    required_html=('sq169-orientation-save-block-axis-content-identity-single-dxf-ole','sq170-orientation-canvas-zoom-per-board-picks-snap-wasm-binary-pdf-worker-ole-reader','sq168-pdf-access-axis-points-explicit-snap-fix','sq167-dwg-orientation-view-transform','sq169-source-bytes-single-read-file-content-identity','user-scalable=no','wasmBinary,locateFile:','createByWasmInstance(wasmInstance)','installGlobalPdfWorkerGuard')
    for marker in required_html:
        if marker not in html:raise ValueError('V170 HTML missing required marker: '+marker)
    m=SLOT.search(html)
    if not m or base64.b64decode(m.group(2))!=engine:raise ValueError('Embedded V170 CAD engine differs from the checked engine JS')
    text=engine.decode('utf-8')
    required_engine=('SQ_V170_ORIENTATION_VIEWPORT_PER_BOARD_PICK_SNAP_AXES_EXTENTS_AND_PDF_WORKER','function createOrientedDxfBytes','function fileFingerprint','function makeEmbeddedRasterDxf','function parseOle2Frame','data-sq-snap="source"','data-sq-snap="target"','sq162-zoom-slider','geom._sqPathCache','state.picks[first]=null;state.picks[first+1]=null','!main.oleFrames.length','await downloadBytes(out.bytes,filename,\'application/dxf\')')
    for marker in required_engine:
        if marker not in text:raise ValueError('V170 engine missing required behaviour: '+marker)
    if 'user-scalable=no' not in html:raise ValueError('Page-level zoom remains enabled')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--html',type=Path,required=True);ap.add_argument('--engine',type=Path,required=True);ap.add_argument('--check-only',action='store_true');a=ap.parse_args()
    html=a.html.read_text(encoding='utf-8');engine=a.engine.read_bytes()
    if a.check_only:validate(html,engine);print('PASS V170 HTML + exact embedded engine validation');return
    out=patch_html(html,engine);a.html.write_text(out,encoding='utf-8');print(f'PASS V170 patch applied: {a.html} ({len(out):,} HTML chars)')
if __name__=='__main__':main()
