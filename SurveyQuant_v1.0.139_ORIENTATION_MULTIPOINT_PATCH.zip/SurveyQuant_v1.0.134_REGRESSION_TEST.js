'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const vm = require('node:vm');

const htmlPath = process.argv[2];
assert(htmlPath && fs.existsSync(htmlPath), 'usage: node V134_REGRESSION_TEST.js path/to/index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const marker = 'SURVEYQUANT_V134_DWG_LOCAL_ENGINE_EXACT_LAND_QUAD';
assert(html.includes(marker), 'V134 marker missing');
assert(html.includes('id=\"surveyquant-v134-session-reset\"'), 'startup session reset missing');
assert(html.includes('localStorage.clear()'), 'persistent local storage is not cleared on startup/exit');
assert(html.includes('sessionStorage.clear()'), 'session storage is not cleared on startup/exit');
assert(html.includes('indexedDB.deleteDatabase(db.name)'), 'origin-scoped IndexedDB cleanup missing');
assert(html.includes("./libredwg-writer/dist/libredwg-web.js"), 'DWG loader does not use bundled local module');
assert(html.includes("./libredwg-writer/wasm/libredwg-web.js"), 'DWG loader does not use bundled classic WASM script');
assert(html.includes('sqLoadClassicScriptOnce(SQ_WRITER_WASM_URL'), 'classic WASM script is not loaded before the API');
assert(html.includes('window.SurveyQuantLibreDwg'), 'classic IIFE API global is not referenced');
assert(!html.includes('import(SQ_WRITER_ENGINE_URL)'), 'dynamic ESM import must not be used from the Android WebView file origin');
assert(html.includes("LibreDwg.create('./libredwg-writer/wasm')"), 'DWG conversion must set an explicit local WASM sidecar path');
assert(html.includes('./dxf-parser.js'), 'DXF parser must use local bundled JavaScript');
assert(html.includes('./dxf-parser.js'), 'DXF parser is not local/offline');
assert(!/https?:\/\/[^\s"'`<>]+\/libredwg-writer\/dist\/libredwg-web\.js/.test(html), 'remote writer engine URL remains');
assert(!/https?:\/\/cdn\.jsdelivr\.net\/npm\/dxf-parser@[^\s"'`<>]+\/dist\/dxf-parser\.js/.test(html), 'remote DXF parser URL remains');
assert(!/https?:\/\/unpkg\.com\/@mlightcad\/libredwg-web@0\.7\.14\/dist\/libredwg-web\.js/.test(html), 'remote unpkg DWG loader remains');
assert(html.includes('function constructConvexQuadFromSides(sides)'), 'exact quadrilateral constructor missing');
assert(html.includes('if(sides.length===4)validateLandPolygonSideLengths(pts,sides);renderLandArea(m2,method,pts,sides);'), 'exact four-side validation is not on the calculation path');
assert(html.includes("id=\"dropCadFile\""), 'drop-file CAD picker is missing');
assert(html.includes('dropFilesMerge()'), 'projection/merge handler is missing');
assert(/\.dwg/.test(html) && /\.dxf/.test(html), 'DWG or DXF support markers missing');

// Extract the production constructor using a brace-aware scanner and execute it
// directly so the test checks the app's real geometry function, not a duplicate.
function extractFunction(source, signature) {
  const start = source.indexOf(signature);
  assert(start >= 0, `cannot extract production function: ${signature}`);
  const brace = source.indexOf('{', start + signature.length);
  assert(brace >= 0, 'function opening brace missing');
  let depth = 0, quote = null, escape = false, lineComment = false, blockComment = false, template = false;
  for (let i = brace; i < source.length; i++) {
    const c = source[i], n = source[i + 1];
    if (lineComment) { if (c === '\n') lineComment = false; continue; }
    if (blockComment) { if (c === '*' && n === '/') { blockComment = false; i++; } continue; }
    if (quote) {
      if (escape) { escape = false; continue; }
      if (c === '\\') { escape = true; continue; }
      if (c === quote) quote = null;
      continue;
    }
    if (template) {
      if (escape) { escape = false; continue; }
      if (c === '\\') { escape = true; continue; }
      if (c === '`') template = false;
      // No template literal is used within the production geometry constructor.
      continue;
    }
    if (c === '/' && n === '/') { lineComment = true; i++; continue; }
    if (c === '/' && n === '*') { blockComment = true; i++; continue; }
    if (c === '"' || c === "'") { quote = c; continue; }
    if (c === '`') { template = true; continue; }
    if (c === '{') depth++;
    if (c === '}') { depth--; if (depth === 0) return source.slice(start, i + 1); }
  }
  throw new Error(`unterminated function: ${signature}`);
}
const ctor = extractFunction(html, 'function constructConvexQuadFromSides(sides)');
const sandbox = { Math, Number, Array, Number: Number };
vm.createContext(sandbox);
vm.runInContext(ctor + '\nglobalThis.__ctor=constructConvexQuadFromSides;', sandbox);
const construct = sandbox.__ctor;
function distance(p, q) { return Math.hypot(q.x - p.x, q.y - p.y); }
function polygonArea(pts) { let a = 0; for (let i=0;i<pts.length;i++){const p=pts[i],q=pts[(i+1)%pts.length];a += p.x*q.y-q.x*p.y;}return Math.abs(a)/2; }
function assertConvex(pts, label) {
  const turns=[];
  for(let i=0;i<pts.length;i++){
    const p=pts[i],q=pts[(i+1)%pts.length],r=pts[(i+2)%pts.length];
    turns.push((q.x-p.x)*(r.y-q.y)-(q.y-p.y)*(r.x-q.x));
  }
  assert(turns.every(v=>v>1e-8)||turns.every(v=>v< -1e-8), `${label}: quadrilateral is not strictly convex`);
}
const validCases = [
  [5, 2, 2, 2],
  [10, 8, 7, 9],
  [20, 20, 20, 20],
  [12.5, 9.75, 14.25, 10.5],
  [30, 20, 25, 15],
  [100.001, 80.25, 75.5, 95.75],
  [10, 3.4, 3.4, 3.4]
];
for (let i=0;i<18;i++) {
  const h=4+i*0.35, w=8+i*0.7;
  const source=[{x:0,y:0},{x:w,y:0},{x:w+2,y:h+1},{x:1,y:h}];
  const derived=source.map((p,j)=>distance(p,source[(j+1)%4]));
  validCases.push(derived);
}
for (const sides of validCases) {
  const pts = construct(sides);
  assert(pts && pts.length === 4, `could not construct convex quadrilateral: ${sides}`);
  assertConvex(pts, `sides ${sides}`);
  assert(polygonArea(pts) > 1e-6, `zero area for ${sides}`);
  for (let i=0;i<4;i++) {
    const actual=distance(pts[i],pts[(i+1)%4]);
    assert(Math.abs(actual-sides[i]) <= Math.max(1e-5, sides[i]*1e-6), `edge ${i} mismatch for ${sides}: expected ${sides[i]}, got ${actual}`);
  }
}
for (const sides of [[1,2,3,9],[1,1,1,3],[0,2,2,2],[5,1,1,1]]) {
  assert.equal(construct(sides), null, `impossible or degenerate sides were accepted: ${sides}`);
}
console.log(`PASS V134 R3: ordered classic WebView DWG loader + local DXF parser references and ${validCases.length} exact convex-quad cases; 4 impossible-side cases rejected. Separate WASM bytes are validated by the workflow and APK packager.`);


// Verify that the production loader inserts classic scripts in the required order.
async function verifyClassicDwgLoaderRuntime() {
  const start = html.indexOf("const SQ_WRITER_ENGINE_URL=");
  const end = html.indexOf("function vec(v)", start);
  assert(start >= 0 && end > start, 'cannot isolate the production DWG runtime loader');
  const source = html.slice(start, end);
  const calls = [];
  const win = {};
  const doc = {
    baseURI: 'file:///android_asset/index.html',
    querySelectorAll() { return []; },
    createElement(tag) {
      return { tagName: tag, attributes: {}, setAttribute(k,v){this.attributes[k]=v;}, addEventListener(){}, src:'', onload:null, onerror:null };
    },
    head: { appendChild(script) {
      calls.push(script.src);
      if (script.src.includes('/wasm/libredwg-web.js')) win.createModule = function(){ return Promise.resolve({}); };
      else if (script.src.includes('/dist/libredwg-web.js')) win.SurveyQuantLibreDwg = { LibreDwg: { create(){ return Promise.resolve({}); } } };
      else throw new Error('unexpected DWG script path: '+script.src);
      if (script.onload) script.onload();
    } },
    documentElement: { appendChild(script) { this.head?.appendChild(script); } }
  };
  doc.documentElement.head = doc.head;
  const sandbox = {window:win, document:doc, URL, Promise, Array, Error, dwgLibPromise:null};
  vm.createContext(sandbox);
  vm.runInContext(source + '\nglobalThis.__sqLoadDWG=loadDWG;', sandbox);
  const api = await sandbox.__sqLoadDWG();
  assert(api && api.LibreDwg, 'loader did not return the LibreDwg API');
  assert.equal(calls.length, 2, 'exactly two classic scripts should be inserted');
  assert(calls[0].includes('/wasm/libredwg-web.js'), 'classic Emscripten factory must load first');
  assert(calls[1].includes('/dist/libredwg-web.js'), 'high-level IIFE API must load second');
  console.log('PASS V134 R3 WebView loader: classic WASM factory then high-level IIFE API, with no dynamic ESM import.');
}
verifyClassicDwgLoaderRuntime().catch(err => { console.error(err); process.exitCode = 1; });

// Execute the actual embedded storage-reset script against mocked WebView APIs.
async function verifySessionResetRuntime() {
  const match = html.match(/<script id="surveyquant-v134-session-reset">([\s\S]*?)<\/script>/);
  assert(match, 'cannot extract the actual session reset script');
  const calls = { local: 0, session: 0, deleted: [], listeners: {} };
  const win = {
    localStorage: { clear() { calls.local++; } },
    sessionStorage: { clear() { calls.session++; } },
    indexedDB: {
      databases() { return Promise.resolve([{name:'surveyquant-test-db'}, {name:'surveyquant-session-db'}]); },
      deleteDatabase(name) { calls.deleted.push(name); }
    },
    addEventListener(name, fn, opts) { calls.listeners[name] = {fn, opts}; }
  };
  vm.runInNewContext(match[1], { window: win });
  assert.equal(calls.local, 1, 'localStorage must be cleared synchronously at startup');
  assert.equal(calls.session, 1, 'sessionStorage must be cleared synchronously at startup');
  assert(calls.listeners.pagehide && calls.listeners.beforeunload, 'exit cleanup handlers are missing');
  assert.equal(calls.listeners.pagehide.opts.once, true, 'pagehide handler should run once');
  await Promise.resolve();
  assert.deepEqual(calls.deleted.sort(), ['surveyquant-session-db','surveyquant-test-db'], 'IndexedDB databases were not requested for deletion');
  calls.listeners.pagehide.fn();
  calls.listeners.beforeunload.fn();
  assert.equal(calls.local, 3, 'localStorage cleanup must also run at exit');
  assert.equal(calls.session, 3, 'sessionStorage cleanup must also run at exit');
  console.log('PASS V134 session reset: startup storage clear + IndexedDB deletion requests + pagehide/beforeunload cleanup.');
}
verifySessionResetRuntime().catch(err => { console.error(err); process.exitCode = 1; });
