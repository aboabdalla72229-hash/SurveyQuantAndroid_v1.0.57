# SurveyQuant v1.0.80

- Base: v1.0.67 projection flow.
- Projection DXF export no longer edits the reference TABLES/LAYER section.
- Projected entities are written on an existing reference layer, with per-entity color, preserving the reference DXF structure.
- Native DXF validation no longer requires HEADER/TABLES, only a valid ENTITIES section and EOF.
- User supplied photo 1001224145.png is included byte-for-byte as app_background_ahmed.jpg and used as the translucent application background.
- Settings remain session-only.
