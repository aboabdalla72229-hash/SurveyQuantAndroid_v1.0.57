#!/usr/bin/env python3
"""SurveyQuant v1.0.133: ephemeral drawing sessions and frame-coalesced CAD redraw."""
from __future__ import annotations
import argparse
import re
import tempfile
import zipfile
from pathlib import Path

MARKER = "SURVEYQUANT_V133_EPHEMERAL_SESSION_PERFORMANCE"


def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise SystemExit(f"ERROR {label}: expected exactly one anchor, found {count}")
    return source.replace(old, new, 1)


def patch_html(source: str) -> str:
    if MARKER in source:
        raise SystemExit("V133 patch already applied")
    if "SURVEYQUANT_V132_CAD_ORIGINAL_VIEW_STRICT_PRESERVE" not in source:
        raise SystemExit("ERROR: V132 CAD-preservation marker missing; refusing an unknown base")

    # Purge old persisted UI/drawing state before any app script can read it. Keep only the
    # device identifier + entitlement cache needed by the existing activation flow. Payment
    # transaction keys may be used in the current live session, but are purged on next start.
    storage_policy = r'''<script id="sq-v133-ephemeral-storage-policy">
(function(){
  'use strict';
  var keepAtStartup = new Set(['sq_device_id','sq_access_until']);
  var allowedDuringSession = new Set(['sq_device_id','sq_access_until','sq_pending_order','sq_pending_device']);
  try {
    var ls = window.localStorage;
    for (var i = ls.length - 1; i >= 0; i--) {
      var key = ls.key(i);
      if (key && !keepAtStartup.has(key)) { try { ls.removeItem(key); } catch (_) {} }
    }
  } catch (_) {}
  try { window.sessionStorage.clear(); } catch (_) {}
  // Prevent future project, drawing, result, or preference keys from being written to Web Storage.
  // Only activation identifiers and the short-lived payment hand-off may be stored during a session.
  try {
    if (window.Storage && Storage.prototype && !Storage.prototype.__sqV133WriteGuard) {
      var originalSetItem = Storage.prototype.setItem;
      Object.defineProperty(Storage.prototype, '__sqV133WriteGuard', {value:true, configurable:false});
      Storage.prototype.setItem = function(key, value) {
        var name = String(key);
        try {
          if (this === window.sessionStorage) return;
          if (this === window.localStorage && !allowedDuringSession.has(name)) return;
        } catch (_) { return; }
        return originalSetItem.call(this, key, value);
      };
    }
  } catch (_) {}
})();
</script>
<!-- ''' + MARKER + ''' -->
'''
    source = replace_once(source, "<head>", "<head>\n" + storage_policy, "startup storage policy")

    # Output style is per-session, not stored in localStorage.
    old_settings = """const SQ_SETTINGS_KEY='surveyquant.projectOutputSettings.v2';
function sqDefaultSettings(){return{lineColor:'#2463eb',contourColor:'#e5a000',tinColor:'#2878d0',textColor:'#00aaff',textHeight:0.30,pointColor:'#ff3333',pointSize:0.5,pointSymbol:'circleX',pointTextColor:'#00aaff',pointTextSize:0.30,showId:true,showElevation:true};}
function sqReadAllSettings(){try{return JSON.parse(localStorage.getItem(SQ_SETTINGS_KEY)||'{}')||{};}catch(_){return{};}}
function sqSettingsFor(id=activeProjectId){return Object.assign(sqDefaultSettings(),sqReadAllSettings()[id]||{});}
function sqSaveProjectSettings(id){const card=document.getElementById(id);const panel=card&&card.querySelector('.project-output-settings');if(!panel)return;const vals={};panel.querySelectorAll('[data-sq-setting]').forEach(el=>{vals[el.dataset.sqSetting]=el.type==='checkbox'?el.checked:el.value;});const all=sqReadAllSettings();all[id]=Object.assign(sqDefaultSettings(),all[id]||{},vals);try{localStorage.setItem(SQ_SETTINGS_KEY,JSON.stringify(all));}catch(e){console.warn('Could not persist project settings',e);}}"""
    new_settings = """const SQ_V133_SESSION_SETTINGS=Object.create(null);
function sqDefaultSettings(){return{lineColor:'#2463eb',contourColor:'#e5a000',tinColor:'#2878d0',textColor:'#00aaff',textHeight:0.30,pointColor:'#ff3333',pointSize:0.5,pointSymbol:'circleX',pointTextColor:'#00aaff',pointTextSize:0.30,showId:true,showElevation:true};}
function sqReadAllSettings(){return SQ_V133_SESSION_SETTINGS;}
function sqSettingsFor(id=activeProjectId){return Object.assign(sqDefaultSettings(),SQ_V133_SESSION_SETTINGS[id]||{});}
function sqSaveProjectSettings(id){const card=document.getElementById(id);const panel=card&&card.querySelector('.project-output-settings');if(!panel)return;const vals={};panel.querySelectorAll('[data-sq-setting]').forEach(el=>{vals[el.dataset.sqSetting]=el.type==='checkbox'?el.checked:el.value;});SQ_V133_SESSION_SETTINGS[id]=Object.assign(sqDefaultSettings(),SQ_V133_SESSION_SETTINGS[id]||{},vals);}"""
    source = replace_once(source, old_settings, new_settings, "memory-only project output settings")
    source = replace_once(
        source,
        "🎨 إعدادات الإخراج (تُحفظ تلقائيًا لهذا المشروع)",
        "🎨 إعدادات الإخراج (مؤقتة لهذه الجلسة فقط)",
        "ephemeral settings label",
    )

    # Stop saving comparison controls to persistent storage; native HTML defaults are used each launch.
    old_compare = """forEach(elId=>{const el=document.getElementById(elId);if(!el)return;const key='surveyquant.compare.'+elId;try{const saved=localStorage.getItem(key);if(saved!==null)el.value=saved;}catch(_){}const save=()=>{try{localStorage.setItem(key,el.value);}catch(_){}};el.addEventListener('input',save);el.addEventListener('change',save);el.dataset.keepValue='1';});"""
    new_compare = """forEach(elId=>{const el=document.getElementById(elId);if(!el)return;el.dataset.keepValue='1';});"""
    source = replace_once(source, old_compare, new_compare, "comparison preferences memory-only")

    # Coalesce repeated pan/zoom/touch redraws to one draw per animation frame.
    draw_anchor = "function draw(v){if(!v||!v.ctx||!v.drawing)return;"
    draw_prefix = """function draw(v){
 if(!v||!v.ctx||!v.drawing)return;
 if(!v.__sqV133DrawImmediate&&typeof window.requestAnimationFrame==='function'){
  if(v.__sqV133DrawQueued)return;
  v.__sqV133DrawQueued=window.requestAnimationFrame(()=>{v.__sqV133DrawQueued=0;v.__sqV133DrawImmediate=true;try{draw(v);}finally{v.__sqV133DrawImmediate=false;}});
  return;
 }
"""
    source = replace_once(source, draw_anchor, draw_prefix, "frame-coalesced CAD redraw")

    # Clear working models on return from the background, but not while Android's file chooser
    # or the payment hand-off is active. This is a memory reset, not an app reload.
    reset_block = r'''function sqV133ResetTransientSession(){
 if(document.body.classList.contains('payment-mode'))return false;
 try{if(typeof closeProjectPage==='function')closeProjectPage();}catch(_){}
 try{if(typeof window.sqCloseOrientationProject==='function')window.sqCloseOrientationProject();}catch(_){}
 try{
  if(typeof SQ_V133_SESSION_SETTINGS!=='undefined')Object.keys(SQ_V133_SESSION_SETTINGS).forEach(k=>delete SQ_V133_SESSION_SETTINGS[k]);
  if(typeof points!=='undefined')points=[];
  if(typeof triangles!=='undefined')triangles=[];
  if(typeof contourSegments!=='undefined')contourSegments=[];
  if(typeof cleanedPoints!=='undefined')cleanedPoints=[];
  if(typeof cleanedText!=='undefined')cleanedText='';
  if(typeof cleanedCSV!=='undefined')cleanedCSV='';
  if(typeof profileRows!=='undefined')profileRows=[];
  if(typeof profileModel!=='undefined')profileModel=null;
  if(typeof imageDrawingModel!=='undefined')imageDrawingModel=null;
  if(typeof lastFileToDxfModel!=='undefined')lastFileToDxfModel=null;
  if(typeof lastFileToDxfDXF!=='undefined')lastFileToDxfDXF='';
  if(typeof cadModel!=='undefined')cadModel=null;
  if(typeof generatedQuantDXF!=='undefined')generatedQuantDXF='';
  if(typeof quantCompareDXF!=='undefined')quantCompareDXF='';
  if(typeof quantCompareStats!=='undefined')quantCompareStats=null;
  if(typeof quantCompareModel!=='undefined')quantCompareModel=null;
  if(typeof lastQuantStats!=='undefined')lastQuantStats=null;
  if(typeof lastPdfDxf!=='undefined')lastPdfDxf='';
  if(typeof droppedDXF!=='undefined')droppedDXF='';
  if(typeof concreteModel!=='undefined')concreteModel=null;
  if(typeof concreteDXF!=='undefined')concreteDXF='';
  if(typeof concreteVertexCount!=='undefined')concreteVertexCount=0;
  if(typeof landSideCount!=='undefined')landSideCount=4;
  if(typeof imageSideCount!=='undefined')imageSideCount=4;
 }catch(_){}
 document.querySelectorAll('.project-card input,.project-card select,.project-card textarea,#sqOriOverlay input,#sqOriOverlay select,#sqOriOverlay textarea').forEach(el=>{
  try{
   if(el.type==='file'){el.value='';return;}
   if(el.type==='checkbox'||el.type==='radio'){el.checked=!!el.defaultChecked;return;}
   if(el.tagName==='SELECT'){let idx=-1;for(let i=0;i<el.options.length;i++)if(el.options[i].defaultSelected){idx=i;break;}el.selectedIndex=idx>=0?idx:0;return;}
   if(!['button','submit','reset'].includes(el.type))el.value=el.defaultValue||'';
  }catch(_){}
 });
 try{if(typeof renderLandSideRows==='function')renderLandSideRows();if(typeof renderImageSideRows==='function')renderImageSideRows();}catch(_){}
 const defaults=typeof sqDefaultSettings==='function'?sqDefaultSettings():{};
 document.querySelectorAll('.project-card [data-sq-setting]').forEach(el=>{const k=el.dataset.sqSetting;if(el.type==='checkbox')el.checked=!!defaults[k];else if(defaults[k]!==undefined)el.value=defaults[k];});
 document.querySelectorAll('.project-card .results-box,.project-card .cad-panel:not(.project-output-settings),.project-card .info-list[id$="Summary"],.project-card .info-list[id$="Status"]').forEach(el=>{el.style.display='none';});
 try{
  const api=window.__sqOrientation111API,st=api&&api.state;
  if(st){
   Object.values(st.views||{}).forEach(v=>{try{if(v.resizeObserver)v.resizeObserver.disconnect();if(v.resizeHandler)window.removeEventListener('resize',v.resizeHandler);if(v.__sqV133DrawQueued&&typeof window.cancelAnimationFrame==='function')window.cancelAnimationFrame(v.__sqV133DrawQueued);}catch(_){}});
   st.target=null;st.reference=null;st.targetPoints=[null,null];st.referencePoints=[null,null];st.active={target:0,reference:0};st.tool={target:'pick',reference:'pick'};st.snapMode={target:'auto',reference:'auto'};st.views={};st.selectedEntity=null;st.selectedEntities=[];st.undoStack=[];st.redoStack=[];st.idPoint={target:null,reference:null};
   if(typeof api.showScreen==='function')api.showScreen('target');
  }
 }catch(_){}
 ['sq110TargetCanvas','sq110ReferenceCanvas'].forEach(id=>{const c=document.getElementById(id);if(c){try{const x=c.getContext('2d');if(x)x.clearRect(0,0,c.width,c.height);}catch(_){} }});
 ['sq110TargetFileInfo','sq110ReferenceFileInfo','sq110TargetId','sq110ReferenceId','sq110StatusPoint1','sq110StatusPoint2','sq110Status'].forEach(id=>{const n=document.getElementById(id);if(n){n.textContent='';if(id==='sq110Status')n.style.display='none';}});
 return true;
}
(function(){
 var hiddenAt=0,pickerRequestedAt=0,hiddenWasPicker=false;
 function fileInputFrom(node){if(!node||!node.closest)return null;var direct=node.closest('input[type="file"]');if(direct)return direct;var label=node.closest('label');return label&&label.querySelector?label.querySelector('input[type="file"]'):null;}
 document.addEventListener('click',function(e){if(fileInputFrom(e.target))pickerRequestedAt=Date.now();},true);
 document.addEventListener('change',function(e){if(e.target&&e.target.matches&&e.target.matches('input[type="file"]')&&!hiddenAt)pickerRequestedAt=0;},true);
 document.addEventListener('cancel',function(e){if(e.target&&e.target.matches&&e.target.matches('input[type="file"]')&&!hiddenAt)pickerRequestedAt=0;},true);
 document.addEventListener('visibilitychange',function(){
  if(document.visibilityState==='hidden'){hiddenAt=Date.now();hiddenWasPicker=!!pickerRequestedAt&&(hiddenAt-pickerRequestedAt)<30000;return;}
  if(!hiddenAt)return;
  var elapsed=Date.now()-hiddenAt;hiddenAt=0;
  if(hiddenWasPicker){hiddenWasPicker=false;pickerRequestedAt=0;return;}
  pickerRequestedAt=0;
  if(elapsed<750)return;
  if(document.body.classList.contains('payment-mode'))return;
  var pending='';try{pending=localStorage.getItem('sq_pending_order')||'';}catch(_){}
  if(pending){try{localStorage.removeItem('sq_pending_order');localStorage.removeItem('sq_pending_device');}catch(_){}return;}
  try{sqV133ResetTransientSession();}catch(e){console.warn('Session cleanup:',e);}
 });
 window.addEventListener('pagehide',function(){try{sqV133ResetTransientSession();}catch(_){} });
})();
/* ''' + MARKER + ''' */
'''
    source = replace_once(source, "function modelBounds(model){", reset_block + "\nfunction modelBounds(model){", "transient-session reset integration")

    # App-facing version constant; Android package version is updated by the build workflow.
    version_pattern = r'const SQ_APP_VERSION_CODE = 126;'
    if len(re.findall(version_pattern, source)) != 1:
        raise SystemExit("ERROR: expected exactly one V126 in-app version constant")
    source = re.sub(version_pattern, "const SQ_APP_VERSION_CODE = 133;", source, count=1)

    # Final guard: no project settings or compare preferences should be written to Web Storage.
    if "localStorage.setItem(SQ_SETTINGS_KEY" in source or "localStorage.setItem(key,el.value)" in source:
        raise SystemExit("ERROR: persistent drawing/project settings writer remains")
    if source.count(MARKER) < 2:
        raise SystemExit("ERROR: V133 session/performance markers are incomplete")
    return source


def patch_apk(source: Path, output: Path):
    if not source.is_file():
        raise SystemExit(f"APK missing: {source}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix='sq-v133-', suffix='.apk', dir=output.parent, delete=False) as f:
        tmp = Path(f.name)
    changed = 0
    try:
        with zipfile.ZipFile(source, 'r') as zin, zipfile.ZipFile(tmp, 'w') as zout:
            for info in zin.infolist():
                if re.match(r'^META-INF/[^/]+\.(?:SF|RSA|DSA|EC|MF)$', info.filename, re.I):
                    continue
                data = zin.read(info.filename)
                if info.filename == 'assets/index.html':
                    data = patch_html(data.decode('utf-8')).encode('utf-8')
                    changed += 1
                zout.writestr(info, data)
        if changed != 1:
            raise SystemExit(f"Expected exactly one assets/index.html, found {changed}")
        tmp.replace(output)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise
    print(f"PATCHED APK HTML: {source} -> {output}; rebuild or align/re-sign APK before install.")


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--html')
    p.add_argument('--apk')
    p.add_argument('--output')
    a = p.parse_args()
    if a.html:
        f = Path(a.html)
        f.write_text(patch_html(f.read_text(encoding='utf-8')), encoding='utf-8')
        print('V133 ephemeral-session/performance patch applied:', f)
    elif a.apk and a.output:
        patch_apk(Path(a.apk), Path(a.output))
    else:
        p.error('use --html FILE or --apk INPUT --output OUTPUT')

if __name__ == '__main__':
    main()
