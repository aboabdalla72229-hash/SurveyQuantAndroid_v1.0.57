from pathlib import Path
html=Path('index.html').read_text(encoding='utf-8')
checks={
 'orientation_restored_from_v177':'sq176-home-orientation-project' in html and 'sq176-cad-project-host' in html,
 'fresh_start_clears_session_storage':'window.sessionStorage.clear()' in html,
 'fresh_start_clears_board_local_storage':'clearBoardStorage();' in html,
 'fresh_start_removes_indexeddb':'indexedDB.deleteDatabase(db.name)' in html,
 'source_target_pick_provenance':'canvasFingerprint' in html and 'canvasSide' in html,
 'identity_alignment_rejected':'rejectIdentityAlignment' in html,
 'v185_orientation_rewrite_absent':'sq185' not in html.lower() and 'sq185-' not in html.lower(),
 'pdf_lossless_png_pair':'zipStore([{name:dxfName,data:dxfBytes},{name:imageName,data:pngBytes}])' in html,
 'pdf_does_not_trace_pixels':'ImageTracer.imagedataToSVG' not in html[html.find('// V186: restore the complete V177 orientation project'):],
 'pdf_native_save_fallback':'browser-download-requested' in html,
}
for k,v in checks.items(): print(f'{k}: {"PASS" if v else "FAIL"}')
if not all(checks.values()): raise SystemExit(1)
print('RESULT PASS V186 restores V177 orientation source and PDF save flow')
