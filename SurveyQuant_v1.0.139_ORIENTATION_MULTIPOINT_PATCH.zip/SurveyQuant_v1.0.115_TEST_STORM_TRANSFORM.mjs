import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { pathToFileURL } from 'node:url';

const [referencePath, manualPath, faithfulPath, preservePath, dxfDir, outputDir, reportPath] = process.argv.slice(2);
if (![referencePath, manualPath, faithfulPath, preservePath, dxfDir, outputDir, reportPath].every(Boolean)) {
  throw new Error('usage: storm-transform.mjs reference.js manual.js faithful.js preserve.js dxfDir outputDir report.md');
}
await fs.mkdir(outputDir, { recursive: true });
const docListeners = {};
const document = {
  readyState: 'loading',
  addEventListener(n, f) { (docListeners[n] ||= []).push(f); },
  getElementById() { return null; },
  querySelector() { return null; },
  createElement() { return { style: {}, addEventListener() {}, setAttribute() {} }; }
};
const window = {
  devicePixelRatio: 1,
  __sqOrientTest: { transformBytes: null },
  __sqManualOrientation109: null,
  __sqOrientation110API: null,
  __sqOrientation111API: null,
  __sqOrientation112API: null,
  __sqOrientation113API: null
};
const context = {
  window, document, Uint8Array, ArrayBuffer, DataView, TextEncoder, TextDecoder, Blob, URL,
  setTimeout, clearTimeout, Map, Set, Number, String, Math, Error, RegExp, Object, Array,
  Promise, JSON, console, Intl, BigInt, parseInt, parseFloat
};
vm.createContext(context);
for (const file of [manualPath, referencePath, faithfulPath, preservePath]) {
  vm.runInContext(await fs.readFile(file, 'utf8'), context, { filename: file });
}
const api = window.__sqOrientation113API;
const core = window.__sqOrientation111API;
if (!api || !core?.solve || !core?.splitPairs || !core?.sectionRecords) throw new Error('App DXF transform API did not initialize.');

function decodeDxf(bytes) {
  let text = new TextDecoder('latin1').decode(bytes).replace(/^\uFEFF/, '');
  const lines = text.split(/\r\n|\n|\r/);
  if (lines.at(-1) === '') lines.pop();
  if (lines.length < 8 || lines.length % 2) throw new Error(`Invalid code/value pair count: ${lines.length}`);
  const pairs = [];
  for (let i = 0; i < lines.length; i += 2) {
    const t = lines[i].trim();
    if (!/^[+-]?\d+$/.test(t)) throw new Error(`Invalid group code at ${i + 1}: ${t.slice(0,60)}`);
    pairs.push({ code: Number(t), value: lines[i + 1].trim() });
  }
  return pairs;
}
function geomCodes(c) { return (c >= 10 && c <= 18) || (c >= 20 && c <= 28) || [40,41,42,43,44,45,46,48,50,51,52,53].includes(c); }
function sectioned(pairs) {
  let section = '', afterSection = false, headerVariable = '', blockName = '', blockEntity = '', entityType = '';
  return pairs.map((p, i) => {
    const old = section;
    if (p.code === 0 && p.value.toUpperCase() === 'SECTION') { afterSection = true; headerVariable = ''; blockName = ''; blockEntity = ''; entityType = ''; }
    else if (afterSection && p.code === 2) { section = p.value.toUpperCase(); afterSection = false; headerVariable = ''; blockName = ''; blockEntity = ''; entityType = ''; }
    else if (p.code === 0 && p.value.toUpperCase() === 'ENDSEC') { section = ''; afterSection = false; headerVariable = ''; blockName = ''; blockEntity = ''; entityType = ''; }
    else {
      if (section === 'HEADER' && p.code === 9) headerVariable = p.value.toUpperCase();
      if (section === 'ENTITIES' && p.code === 0) entityType = p.value.toUpperCase();
      if (section === 'BLOCKS' && p.code === 0) {
        const type = p.value.toUpperCase();
        if (type === 'BLOCK') { blockEntity = 'BLOCK'; blockName = ''; }
        else if (type === 'ENDBLK') blockEntity = 'ENDBLK';
        else blockEntity = type;
      }
      if (section === 'BLOCKS' && p.code === 2 && blockEntity === 'BLOCK' && !blockName) blockName = p.value.toUpperCase();
    }
    const result = { ...p, section: old || section, headerVariable, blockName, blockEntity, entityType, index: i };
    if (section === 'BLOCKS' && p.code === 0 && p.value.toUpperCase() === 'ENDBLK') { blockEntity = ''; blockName = ''; }
    return result;
  });
}
function referencedDimensionBlocks(pairs) {
  const parsed = sectioned(pairs), names = new Set();
  let currentEntity = '';
  for (const p of parsed) {
    if (p.section !== 'ENTITIES') continue;
    if (p.code === 0) currentEntity = p.value.toUpperCase();
    else if (currentEntity === 'DIMENSION' && p.code === 2 && p.value.trim()) names.add(p.value.trim().toUpperCase());
  }
  return names;
}
const allowedHeaderCodes = {
  '$EXTMIN': [10,20], '$EXTMAX': [10,20], '$LIMMIN': [10,20], '$LIMMAX': [10,20],
  '$PEXTMIN': [10,20], '$PEXTMAX': [10,20], '$VIEWCTR': [10,20], '$INSBASE': [10,20],
  '$SNAPBASE': [10,20], '$UCSORG': [10,20], '$VIEWSIZE': [40]
};
function isAllowedViewHeaderUpdate(p) {
  return p.section === 'HEADER' && Array.isArray(allowedHeaderCodes[p.headerVariable]) && allowedHeaderCodes[p.headerVariable].includes(p.code);
}
function findControlPoints(bytes) {
  const parsed = core.splitPairs(bytes);
  const records = core.sectionRecords(parsed.pairs, 'ENTITIES');
  const pts = [];
  for (const r of records) {
    for (let xc = 10; xc <= 18; xc++) {
      const xs = r.pairs.filter(p => p.code === xc);
      const ys = r.pairs.filter(p => p.code === xc + 10);
      for (let i = 0; i < Math.min(xs.length, ys.length); i++) {
        const x = Number(String(xs[i].value).trim()), y = Number(String(ys[i].value).trim());
        if (!Number.isFinite(x) || !Number.isFinite(y)) continue;
        if (!pts.some(p => Math.hypot(p.x - x, p.y - y) < 1e-7)) pts.push({ x, y, entity: r.type });
      }
    }
    if (pts.length > 24) break;
  }
  for (let i=0;i<pts.length;i++) for(let j=i+1;j<pts.length;j++) if(Math.hypot(pts[i].x-pts[j].x,pts[i].y-pts[j].y)>1e-4) return [pts[i],pts[j]];
  throw new Error('Could not find two distinct exposed XY points in the converted DXF.');
}
function auditNonGeometry(beforeBytes, afterBytes) {
  const beforePairs = decodeDxf(beforeBytes);
  const a = sectioned(beforePairs), b = sectioned(decodeDxf(afterBytes));
  const dimensionBlocks = referencedDimensionBlocks(beforePairs);
  const errors = [];
  if (a.length !== b.length) errors.push(`pair count changed ${a.length} -> ${b.length}`);
  const n = Math.min(a.length, b.length);
  let geometryChanged = 0, nonGeometryChanged = 0;
  for (let i=0; i<n; i++) {
    if (a[i].code !== b[i].code) { errors.push(`group codes/order changed at pair ${i+1}: ${a[i].code} -> ${b[i].code}`); break; }
    if (a[i].value !== b[i].value) {
      if (a[i].section === 'ENTITIES' && b[i].section === 'ENTITIES' && geomCodes(a[i].code)) geometryChanged++;
      else if (a[i].section === 'BLOCKS' && b[i].section === 'BLOCKS' && dimensionBlocks.has(a[i].blockName) && a[i].blockEntity && !['BLOCK','ENDBLK'].includes(a[i].blockEntity) && geomCodes(a[i].code)) geometryChanged++;
      else if (isAllowedViewHeaderUpdate(a[i]) && a[i].headerVariable === b[i].headerVariable) { /* Expected CAD view/extents update. */ }
      else { nonGeometryChanged++; if (errors.length<10) errors.push(`non-geometric value changed at pair ${i+1}, section ${a[i].section}, block ${a[i].blockName}/${a[i].blockEntity}, type ${a[i].entityType}, code ${a[i].code}: ${a[i].value.slice(0,50)} -> ${b[i].value.slice(0,50)}`); }
    }
  }
  const typesA=a.filter(p=>p.code===0&&p.section==='ENTITIES').map(p=>p.value.toUpperCase());
  const typesB=b.filter(p=>p.code===0&&p.section==='ENTITIES').map(p=>p.value.toUpperCase());
  if(JSON.stringify(typesA)!==JSON.stringify(typesB)) errors.push('entity record type sequence changed');
  return { pairsBefore:a.length,pairsAfter:b.length,entitiesBefore:typesA.length,entitiesAfter:typesB.length,geometryValuesChanged:geometryChanged,nonGeometryValuesChanged:nonGeometryChanged,errors };
}
const names = (await fs.readdir(dxfDir)).filter(n=>n.toLowerCase().endsWith('.dxf')).sort();
if(names.length!==2) throw new Error(`Expected 2 converted STORM DXFs, found ${names.length}`);
const rows=[]; let fail=false;
for (let i=0;i<names.length;i++) {
  const name=names[i], source=await fs.readFile(path.join(dxfDir,name));
  try {
    const bytes=new Uint8Array(source.buffer,source.byteOffset,source.byteLength).slice();
    const [p1,p2]=findControlPoints(bytes);
    const d=Math.hypot(p2.x-p1.x,p2.y-p1.y),a=Math.atan2(p2.y-p1.y,p2.x-p1.x)+Math.PI/8;
    const ref1={x:p1.x+123.456,y:p1.y-67.89};
    const ref2={x:ref1.x+d*Math.cos(a),y:ref1.y+d*Math.sin(a)};
    const t=core.solve(p1,p2,ref1,ref2);
    const result=api.transformBytes(bytes,t);
    const outBytes=result?.bytes instanceof Uint8Array?result.bytes:new Uint8Array(result?.bytes||[]);
    if(outBytes.length<100) throw new Error('App transform returned empty/too-small DXF');
    const audit=auditNonGeometry(bytes,outBytes);
    if(audit.pairsBefore!==audit.pairsAfter) throw new Error('DXF group/value pair count changed after orientation');
    if(audit.entitiesBefore!==audit.entitiesAfter) throw new Error('DXF entity count changed after orientation');
    if(audit.nonGeometryValuesChanged) throw new Error(`Detected ${audit.nonGeometryValuesChanged} non-geometric value changes: ${audit.errors.join('; ')}`);
    if(audit.geometryValuesChanged<1) throw new Error('The transform did not change any geometric coordinate/size/angle value');
    const outName=name.replace(/\.dxf$/i,'')+'_ORIENTATION_ENGINE_TEST.dxf';
    await fs.writeFile(path.join(outputDir,outName),outBytes);
    rows.push({input:name,output:outName,result:'PASS',controlPoints:[p1,p2],geometryValuesChanged:audit.geometryValuesChanged,entities:audit.entitiesBefore,pairs:audit.pairsBefore,nonGeometryValuesChanged:0});
  } catch(e) { fail=true; rows.push({input:name,result:'FAIL',error:e?.stack||String(e)}); }
}
const section='\n\n# STORM real-DXF orientation-engine test\n\nThis second regression test runs the app’s actual v111/v113 byte-preserving transform engine against both converted user-provided STORM boards using a known non-zero rotation and translation. It verifies that group-pair count and entity type sequence remain unchanged and that non-geometric pair values stay unchanged. Test transformation outputs are marked `ORIENTATION_ENGINE_TEST` and must not be used as the final site alignment because the points are generated for regression testing.\n\n'+rows.map((r,i)=>`## Board ${i+1}: ${r.input}\n\n- Result: ${r.result}\n${r.output?`- Test output: ${r.output}\n- Entity records: ${r.entities}\n- Group/value pairs: ${r.pairs}\n- Geometric values changed: ${r.geometryValuesChanged}\n- Non-geometric values changed: ${r.nonGeometryValuesChanged}\n`:''}${r.error?`- Error:\n\n\`\`\`\n${r.error}\n\`\`\`\n`:''}`).join('\n');
await fs.appendFile(reportPath,section,'utf8');
console.log(section);
if(fail) process.exit(1);
