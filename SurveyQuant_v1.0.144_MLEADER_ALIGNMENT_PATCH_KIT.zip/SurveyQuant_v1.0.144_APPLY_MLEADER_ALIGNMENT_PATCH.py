#!/usr/bin/env python3
"""Patch SurveyQuant V143 orientation to transform DXF MLEADER/MULTILEADER records."""
from __future__ import annotations
import argparse, hashlib, re
from pathlib import Path

BOARD_ID = 'sq-orientation-reference-board-module'

def script_pattern(sid: str):
    return re.compile(r'(<script\b(?=[^>]*\bid=["\']'+re.escape(sid)+r'["\'])[^>]*>)([\s\S]*?)(</script\s*>)', re.I)

def get_body(html: str, sid: str) -> str:
    found=list(script_pattern(sid).finditer(html))
    if len(found)!=1: raise ValueError(f'Expected exactly one script {sid}, found {len(found)}')
    return found[0].group(2)

def put_body(html: str, sid: str, body: str) -> str:
    found=list(script_pattern(sid).finditer(html))
    if len(found)!=1: raise ValueError(f'Expected exactly one script {sid}, found {len(found)}')
    m=found[0]
    return html[:m.start(2)]+body+html[m.end(2):]

def replace_once(src: str, old: str, new: str, label: str) -> str:
    n=src.count(old)
    if n!=1: raise ValueError(f'{label}: expected one exact anchor, found {n}')
    return src.replace(old,new,1)

HELPER = r''' function transformMLeaderRecord(rec,change,numeric,t,writeRaw){
  // MLEADER is structured data, not an opaque proxy. Interpret its nested DXF markers
  // so point groups, direction vectors, text/block placement and style dimensions are
  // transformed according to their actual meaning.
  const p=rec.pairs, buckets=new Map();
  let inContext=false,inLeader=false,inLine=false,hasBlock=false,exposed=false;
  const angle=t.angleDeg*Math.PI/180,cs=Math.cos(angle),sn=Math.sin(angle);
  const textScalePairs=[],anglePairs=[],inlineTextPairs=[],contextBlockRotationPairs=[],topLevelBlockRotationPairs=[];
  function bucket(base,mode){const key=base+'|'+mode;if(!buckets.has(key))buckets.set(key,{base,mode,x:[],y:[],z:[]});return buckets.get(key);}
  function component(code){
   if(code>=10&&code<=18)return {base:code,axis:'x'};
   if(code>=20&&code<=28)return {base:code-10,axis:'y'};
   if(code>=30&&code<=38)return {base:code-20,axis:'z'};
   if(code>=110&&code<=112)return {base:code,axis:'x'};
   if(code>=120&&code<=122)return {base:code-10,axis:'y'};
   if(code>=130&&code<=132)return {base:code-20,axis:'z'};
   return null;
  }
  function modeFor(base){
   if(base===10)return inContext?'point':(hasBlock?'scale':null); // top-level 10/20/30 is BLOCK scale vector only for block content; leave text-MLeader scale vector untouched
   if(base===11)return inLine?'point':'vector'; // leader-line breaks are points; node dogleg/text normals are directions
   if(base===12)return 'point'; // text location or leader break point
   if(base===13)return inLeader?'point':'vector'; // leader-node break vs MText direction
   if(base===14)return 'vector'; // block content normal
   if(base===15)return 'point'; // block content position
   if(base===16)return 'scale'; // block content scale vector
   if(base===110)return 'point'; // MLeader plane origin
   if(base===111||base===112)return 'vector'; // MLeader plane axes
   return null;
  }
  function setValue(pair,value){
   if(!pair||!Number.isFinite(value))return;
   const old=numeric(pair.value);if(old===null)return;
   if(Math.abs(value-old)<=Math.max(1e-10,Math.abs(old)*1e-13))return;
   change(pair,value);
  }
  function addScalar(pair,mode){if(mode==='scale'||mode==='angle'||mode==='text')textScalePairs.push({pair,mode});}
  for(let i=0;i<p.length;i++){
   const q=p[i],code=q.code,value=String(q.value??'').trim(),upper=value.toUpperCase();
   if(code===300&&upper==='CONTEXT_DATA{'){inContext=true;inLeader=false;inLine=false;continue;}
   if(code===301&&upper==='}'){inContext=false;inLeader=false;inLine=false;continue;}
   if(code===302&&upper==='LEADER{'){inLeader=true;inLine=false;continue;}
   if(code===303&&upper==='}'){inLeader=false;inLine=false;continue;}
   if(code===304&&upper==='LEADER_LINE{'){inLine=true;continue;}
   if(code===305&&upper==='}'){inLine=false;continue;}
   if(inContext&&code===296&&Number(q.value)===1)hasBlock=true;
   if(code===46&&inContext)contextBlockRotationPairs.push(q);
   const co=component(code);
   if(co){
    const mode=modeFor(co.base);
    if(mode){bucket(co.base,mode)[co.axis].push(q);if(co.axis!=='z')exposed=true;}
   }
   // Width/height/dogleg/arrow sizes scale with the uniform similarity factor.
   if([40,41,44,140,145,142,143,144].includes(code))addScalar(q,'scale');
   else if(code===42){if(inContext)addScalar(q,'angle');else addScalar(q,'scale');}
   else if(code===43){if(inContext)addScalar(q,'scale');else if(hasBlock)topLevelBlockRotationPairs.push(q);} // top-level block rotation mirrors the transformed context block rotation
   else if(code===45&&!inContext)addScalar(q,'scale');
   else if(code===46)addScalar(q,'angle');
   // MLeader MTEXT inline absolute text heights need the same scale; relative heights (x) remain relative.
   if(code===304&&upper!=='LEADER_LINE{')inlineTextPairs.push(q);
  }
  for(const b of buckets.values()){
   const n=Math.min(b.x.length,b.y.length);
   for(let i=0;i<n;i++){
    const x=numeric(b.x[i].value),y=numeric(b.y[i].value);if(x===null||y===null)continue;
    let q;
    if(b.mode==='point')q=t.point(x,y);
    else if(b.mode==='vector')q={x:cs*x-sn*y,y:sn*x+cs*y};
    else q={x:x*t.scale,y:y*t.scale};
    setValue(b.x[i],q.x);setValue(b.y[i],q.y);
   }
   if(b.mode==='scale')for(const z of b.z){const value=numeric(z.value);if(value!==null)setValue(z,value*t.scale);}
  }
  for(const item of textScalePairs){
   const n=numeric(item.pair.value);if(n===null)continue;
   const result=item.mode==='scale'?n*t.scale:n+angle;
   setValue(item.pair,result);
  }
  // AcDbMLeader's top-level block_rotation is a redundant copy of the context block rotation.
  // Copy the fully transformed context value instead of adding the angle to the old redundant field.
  if(hasBlock&&contextBlockRotationPairs.length&&topLevelBlockRotationPairs.length){
   const originalBlockRotation=numeric(contextBlockRotationPairs[0].value);
   const blockRotation=originalBlockRotation===null?null:originalBlockRotation+angle;
   if(blockRotation!==null)for(const q of topLevelBlockRotationPairs)setValue(q,blockRotation);
  }
  // Preserve MText formatting while scaling absolute inline \Hheight; commands.
  for(const q of inlineTextPairs){
   const raw=String(q.value??'');
   const scaled=raw.replace(/\\H([+-]?(?:\d+(?:\.\d*)?|\.\d+));/g,(all,num)=>'\\H'+String(Number(num)*t.scale)+';');
   if(scaled!==raw)writeRaw(q,scaled);
  }
  // A block-content MLeader stores a 4x4 transform as sixteen repeated group-47 values.
  // ezdxf's DXF convention stores the transposed matrix; compose its transform with ours.
  const matrixPairs=p.filter(q=>q.code===47);
  if(matrixPairs.length){
   if(matrixPairs.length!==16)throw new Error('كائن MLEADER يحتوي على مصفوفة تحويل داخلية غير مكتملة. لم يتم إنشاء ملف؛ أعد حفظ اللوحة بصيغة DXF من برنامج CAD.');
   const raw=matrixPairs.map(q=>numeric(q.value));
   if(raw.some(v=>v===null))throw new Error('مصفوفة تحويل MLEADER تحتوي على قيم غير رقمية. لم يتم إنشاء ملف.');
   const B=Array.from({length:4},(_,r)=>Array.from({length:4},(_,c)=>raw[c*4+r]));
   const M=[[t.scale*cs,t.scale*sn,0,0],[-t.scale*sn,t.scale*cs,0,0],[0,0,t.scale,0],[t.tx,t.ty,0,1]];
   const C=Array.from({length:4},(_,r)=>Array.from({length:4},(_,c)=>B[r].reduce((sum,v,k)=>sum+v*M[k][c],0)));
   const out=[];for(let r=0;r<4;r++)for(let c=0;c<4;c++)out.push(C[c][r]);
   matrixPairs.forEach((q,i)=>setValue(q,out[i]));
  }
  return exposed;
 }
'''

def patch_html(html: str) -> str:
    if html.count('const SQ_APP_VERSION_CODE = 143;') != 1:
        raise ValueError('Expected exactly one V143 app version constant')
    html=html.replace('const SQ_APP_VERSION_CODE = 143;','const SQ_APP_VERSION_CODE = 144;',1)
    # Keep the fresh-session lifecycle guard but tag it with the new app version.
    html=html.replace('surveyquant-v143-fresh-board-session','surveyquant-v144-fresh-board-session')
    body=get_body(html,BOARD_ID)
    body=replace_once(body,"const exact2DTypes=new Set(['LINE','POINT','CIRCLE','ARC','LWPOLYLINE','POLYLINE','TEXT','MTEXT','ATTRIB','ATTDEF','INSERT','SOLID','TRACE','3DFACE','SPLINE','ELLIPSE','RAY','XLINE','LEADER','HATCH','DIMENSION','IMAGE']);",
        "const exact2DTypes=new Set(['LINE','POINT','CIRCLE','ARC','LWPOLYLINE','POLYLINE','TEXT','MTEXT','ATTRIB','ATTDEF','INSERT','SOLID','TRACE','3DFACE','SPLINE','ELLIPSE','RAY','XLINE','LEADER','HATCH','DIMENSION','IMAGE','MLEADER','MULTILEADER']);",
        'allow native MLEADER transform')
    body=replace_once(body,"const opaqueTypeNames=new Set(['ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH','SURFACE','HELIX','MLEADER','MLINE','TABLE','WIPEOUT','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY','TOLERANCE','SHAPE','VIEWPORT']);",
        "const opaqueTypeNames=new Set(['ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH','SURFACE','HELIX','MULTILEADER','MLINE','TABLE','WIPEOUT','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY','TOLERANCE','SHAPE','VIEWPORT']);",
        'remove MLEADER from opaque types')
    # Add dedicated substructure-aware transformer right before transformRecord.
    body=replace_once(body,' function transformRecord(rec, countForEntity=true){',HELPER+'\n function transformRecord(rec, countForEntity=true){','insert MLEADER transform')
    old=r'''  for(let xc=10;xc<=18;xc++){
   // IMAGE clipping coordinates (codes 13+) live in pixel space, not drawing XY.
   if(rec.type==='IMAGE'&&xc>12)continue;
   let mode='point';
   if((rec.type==='MTEXT'||rec.type==='ELLIPSE'||rec.type==='RAY'||rec.type==='XLINE')&&xc===11)mode='vector';
   if(rec.type==='IMAGE'&&(xc===11||xc===12))mode='vector';
   if(rec.type==='SPLINE'&&(xc===12||xc===13))mode='vector';
   xy(xc,xc+10,mode);
  }
  if(rec.type==='HATCH'){xy(43,44,'point');xy(45,46,'vector');}'''
    new=r'''  if(rec.type==='MLEADER'||rec.type==='MULTILEADER'){
   if(transformMLeaderRecord(rec,change,numeric,t,(pair,value)=>{edits.set(pair.index,{pair,value});entityChanged=true;}))exposed=true;
  }else{
   for(let xc=10;xc<=18;xc++){
    // IMAGE clipping coordinates (codes 13+) live in pixel space, not drawing XY.
    if(rec.type==='IMAGE'&&xc>12)continue;
    let mode='point';
    if((rec.type==='MTEXT'||rec.type==='ELLIPSE'||rec.type==='RAY'||rec.type==='XLINE')&&xc===11)mode='vector';
    if(rec.type==='IMAGE'&&(xc===11||xc===12))mode='vector';
    if(rec.type==='SPLINE'&&(xc===12||xc===13))mode='vector';
    xy(xc,xc+10,mode);
   }
  }
  if(rec.type==='HATCH'){xy(43,44,'point');xy(45,46,'vector');}'''
    body=replace_once(body,old,new,'route MLEADER through dedicated transform')
    html=put_body(html,BOARD_ID,body)
    html=html.replace('3DSOLID','3DSOLID')
    # Update the user-facing safety note: MLEADER is now supported, while remaining opaque types still fail closed.
    old='حماية التطابق الكامل: لا يتم التصدير إذا احتوت اللوحة على كائنات Proxy أو Solids أو MLINE/MLEADER/TABLE أو كيانات في OCS غير قياسي، لأن نقل إحداثياتها الظاهرة فقط يترك هندستها الداخلية في مكانها ويشوّه اللوحة. في هذه الحالة لن يُنشأ ملف جزئي.'
    new='حماية التطابق الكامل: تتم معالجة MLEADER/MULTILEADER من بياناته الداخلية بما يشمل نقاط القادة والنص والاتجاهات والمقياس. لا يتم التصدير إذا احتوت اللوحة على كائنات Proxy أو Solids أو MLINE/TABLE أو كيانات في OCS غير قياسي لا يمكن تحويل هندستها الداخلية بالكامل. في هذه الحالة لن يُنشأ ملف جزئي أو مشوّه.'
    if html.count(old)!=1: raise ValueError('Expected one orientation safety help note, found '+str(html.count(old)))
    html=html.replace(old,new,1)
    # Validate no forbidden old guard references and all required new hooks are present.
    if html.count('const SQ_APP_VERSION_CODE = 144;')!=1: raise ValueError('V144 version constant mismatch')
    if 'surveyquant-v144-fresh-board-session' not in html: raise ValueError('V144 fresh session tag missing')
    b=get_body(html,BOARD_ID)
    for token in ['function transformMLeaderRecord',"if(rec.type==='MLEADER'||rec.type==='MULTILEADER')",'const exact2DTypes=new Set']:
        if token not in b: raise ValueError('Required MLEADER hook absent: '+token)
    return html

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-html',type=Path,required=True)
    ap.add_argument('--output-html',type=Path,required=True)
    ap.add_argument('--report',type=Path)
    args=ap.parse_args()
    html=patch_html(args.input_html.read_text(encoding='utf-8'))
    args.output_html.parent.mkdir(parents=True,exist_ok=True)
    args.output_html.write_text(html,encoding='utf-8',newline='')
    if args.report:
      args.report.write_text('# V144 MLEADER alignment report\n\n- Native MLEADER/MULTILEADER is accepted by the complete-entity preflight.\n- Point coordinates, leader branches, break points, dogleg vectors and lengths, text direction/location, plane axes, block placement/scale, scalar dimensions and the 4x4 block transformation matrix are transformed. Block content scales in X/Y/Z; drawing elevations remain unchanged.\n- Text, layers, handles, style references and custom data are not rewritten.\n- Unsupported proxy/solid/table/MLINE and non-default OCS types remain fail-closed.\n- Version code updated to 144.\n\nAutomated tests cover text MLEADER, block matrix composition, nested leader vertices, break points, vector rotation, scaled values, XData and preservation of entity counts.\n',encoding='utf-8')
    print('PASS V144: MLEADER transform installed; version 144; HTML length '+str(len(html)))
if __name__=='__main__': main()
