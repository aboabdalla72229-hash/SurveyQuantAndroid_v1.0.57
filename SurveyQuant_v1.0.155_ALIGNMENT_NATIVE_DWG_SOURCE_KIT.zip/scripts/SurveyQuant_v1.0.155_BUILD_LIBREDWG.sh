#!/usr/bin/env bash
set -euo pipefail
WORK_DIR="${1:?usage: build-v155-libredwg.sh WORK_DIR APP_SOURCE_DIR}"
APP_SOURCE_DIR="${2:?usage: build-v155-libredwg.sh WORK_DIR APP_SOURCE_DIR}"
REPO="$WORK_DIR/libredwg-web-v0.8.2"
rm -rf "$REPO"
git clone --depth 1 --branch v0.8.2 --recurse-submodules https://github.com/mlightcad/libredwg-web.git "$REPO"
cd "$REPO"
chmod +x ./autogen.sh
./autogen.sh
cd bindings/javascript
export CFLAGS='-O2 -DNDEBUG'
export CXXFLAGS='-O2 -DNDEBUG'
export EMCC_CFLAGS='-O2'
corepack enable
corepack prepare pnpm@9.12.3 --activate
python3 - <<'PY'
import json, pathlib, re
p=pathlib.Path('package.json'); data=json.loads(p.read_text())
# Keep ARCALIGNEDTEXT generated in the optimized build instead of leaving its schema-specific
# handlers behind the source tree's debug-only dynamic dispatch.
cls_path=pathlib.Path('../../src/classes.inc'); cls=cls_path.read_text()
line_re=re.compile(r'^\s*(?:DEBUGGING_CLASS|UNSTABLE_CLASS|UNSTABLE_ENTITY|DEBUGGING_ENTITY)\s*\(ACTION,\s*ARCALIGNEDTEXT\).*$',re.M)
new='  STABLE_CLASS        (ACTION, ARCALIGNEDTEXT) // SurveyQuant v155: generated ARCALIGNEDTEXT handler'
if new not in cls:
    matches=list(line_re.finditer(cls))
    if len(matches)!=1:
        raise SystemExit(f'Expected one ARCALIGNEDTEXT dispatch entry, found {len(matches)}; refusing unsupported source patch.')
    cls=cls[:matches[0].start()]+new+cls[matches[0].end():]
    cls_path.write_text(cls)
if cls.count(new)!=1:
    raise SystemExit('ARCALIGNEDTEXT stable dispatch patch did not verify exactly once.')
# If the entity schema is inside DEBUG_CLASSES/IS_FREE in a tag, hoist only this schema out.
spec_path=pathlib.Path('../../src/dwg2.spec'); spec=spec_path.read_text()
marker='DWG_ENTITY (ARCALIGNEDTEXT)'; ix=spec.find(marker)
if ix<0 or spec.find(marker,ix+1)>=0: raise SystemExit('Expected one ARCALIGNEDTEXT schema in src/dwg2.spec.')
stack=[]
for line in spec[:ix].splitlines():
    st=line.strip()
    if re.match(r'^#\s*(if|ifdef|ifndef)\b',st): stack.append(st)
    elif re.match(r'^#\s*endif\b',st):
        if stack: stack.pop()
if any('DEBUG_CLASSES' in g or 'IS_FREE' in g for g in stack):
    start=spec.rfind('#if defined (DEBUG_CLASSES) || defined (IS_FREE)',0,ix)
    end_marker='DWG_ENTITY_END'
    end=spec.find(end_marker,ix)
    if start<0 or end<0: raise SystemExit('Unable to safely locate debug-guarded ARCALIGNEDTEXT block.')
    close=spec.find('#endif',end)
    if close<0: raise SystemExit('Unable to close ARCALIGNEDTEXT debug guard.')
    block=spec[ix: end+len(end_marker)]
    spec=spec[:start]+spec[start:ix].splitlines()[0]+'\n#endif\n\n'+block+'\n\n'+spec[close+len('#endif'):]
    spec_path.write_text(spec)
# Patch only reproducible configure/link flags needed by the browser/WASM runtime.
for key in ('build:prepare','build:obj','build:wasm'):
    cmd=data['scripts'][key]
    if key=='build:prepare':
        if '--disable-write' not in cmd: raise SystemExit('Expected upstream --disable-write flag missing.')
        cmd=cmd.replace(' --disable-write','',1)
        cmd=cmd.replace(' --enable-debug','',1)
        cmd=cmd.replace(' --disable-dxf','',1)
        if '--enable-dxf' not in cmd: cmd += ' --enable-dxf'
    elif key=='build:obj':
        if 'emmake make' not in cmd: raise SystemExit('Expected upstream make command missing.')
        cmd=cmd.replace('emmake make','emmake make -C src',1)
    else:
        # First link an ES module; Vite bundles this exact runtime into dist/libredwg-web.js.
        if ' -s EXPORT_ES6=0' in cmd: cmd=cmd.replace(' -s EXPORT_ES6=0',' -s EXPORT_ES6=1',1)
        if ' --emit-tsd libredwg-web.d.ts' not in cmd: raise SystemExit('Expected --emit-tsd flag missing from upstream build.')
        cmd=cmd.replace(' --emit-tsd libredwg-web.d.ts','',1)
        if ' -O2' not in cmd and ' -Os' not in cmd: cmd += ' -O2'
        cmd += " && printf '%s\\n' 'declare const createModule: (options?: Record<string, unknown>) => Promise<any>;' 'export default createModule;' > libredwg-web.d.ts"
    data['scripts'][key]=cmd
p.write_text(json.dumps(data,indent=2)+'\n')
print('PASS: v0.8.2 browser-WASM configuration updated; ARCALIGNEDTEXT generated handler dispatched normally.')
PY
pnpm install --frozen-lockfile
pnpm build:prepare
pnpm build:obj
pnpm build:wasm
pnpm copy
# Build the typed JavaScript wrapper against the newly generated ESM loader.
pnpm build
node --check wasm/libredwg-web.js
node --check dist/libredwg-web.js
node --input-type=module - <<'JS'
import fs from 'node:fs';
const js=fs.readFileSync('wasm/libredwg-web.js','utf8');
const wasm=fs.readFileSync('wasm/libredwg-web.wasm');
await WebAssembly.compile(wasm);
for(const name of ['dwg_write_dxf','dwg_read_file','dwg_free']) if(!wasm.includes(Buffer.from(name,'ascii'))) throw new Error('WASM is missing binding '+name);
if(!js.includes('createModule')) throw new Error('WASM loader missing createModule factory');
console.log('PASS: compiled v0.8.2 loader/WASM, bytes='+wasm.length);
JS
if [[ ! -f "$APP_SOURCE_DIR/SurveyQuant_v1.0.155_DWG_CORPUS_TEST.mjs" ]]; then echo 'ERROR: SurveyQuant DWG corpus test missing from source patch.'; exit 1; fi
cp "$APP_SOURCE_DIR/SurveyQuant_v1.0.155_DWG_CORPUS_TEST.mjs" test/surveyquant-dwg-corpus.test.mjs
node --test test/surveyquant-dwg-corpus.test.mjs
# Link a second classic-script loader for Android WebView's window.createModule bootstrap.
python3 - <<'PY2'
import json,pathlib
p=pathlib.Path('package.json'); d=json.loads(p.read_text()); k='build:wasm'; c=d['scripts'][k]
if ' -s EXPORT_ES6=1' not in c: raise SystemExit('ES module loader flag missing before classic re-link.')
d['scripts'][k]=c.replace(' -s EXPORT_ES6=1',' -s EXPORT_ES6=0',1); p.write_text(json.dumps(d,indent=2)+'\n')
PY2
pnpm build:wasm
pnpm copy
mkdir -p "$APP_SOURCE_DIR/libredwg-writer/wasm" "$APP_SOURCE_DIR/libredwg-writer/dist"
cp wasm/libredwg-web.js "$APP_SOURCE_DIR/libredwg-writer/wasm/libredwg-web.js"
cp wasm/libredwg-web.wasm "$APP_SOURCE_DIR/libredwg-writer/wasm/libredwg-web.wasm"
# Keep the tested V154 browser UMD wrapper because the HTML loader expects
# window.SurveyQuantLibreDwg. It already exports the stable dwg_read_data and
# dwg_write_dxf APIs and is compatible with the matching Embind entry points.
# Do not copy the ESM/Vite dist output here: it expects the ESM WASM loader, while
# Android WebView loads the classic script factory below.
LEGACY_WRAPPER="$APP_SOURCE_DIR/libredwg-writer/dist/libredwg-web.js"
test -s "$LEGACY_WRAPPER" || { echo 'ERROR: expected V154 UMD wrapper missing.'; exit 1; }
for api in SurveyQuantLibreDwg dwg_read_data dwg_write_dxf; do
  grep -q "$api" "$LEGACY_WRAPPER" || { echo "ERROR: V154 UMD wrapper missing API token $api"; exit 1; }
done
cat > "$APP_SOURCE_DIR/libredwg-writer/BUILD_CONFIGURATION_V155.txt" <<'TXT'
SurveyQuant v1.0.155 native DWG reader + Alignment browser runtime
Upstream: mlightcad/libredwg-web v0.8.2 (upstream tag published 2026-10-22).
The build enables DXF output and removes upstream --disable-write, uses classic script WASM factory for Android WebView, and uses the source-generated ARCALIGNEDTEXT handler. The previously validated V154 UMD JavaScript wrapper is deliberately retained because the application loads window.SurveyQuantLibreDwg via a classic script; Vite's new ESM dist wrapper would be incompatible with that loading contract.
Release gate: six real DWG fixtures from LibreDWG's checked-in test corpus (AC1015, AC1018, AC1021, AC1024, AC1027, AC1032) must each pass direct database reading, layer/entity checks, DWG-to-DXF conversion and DXF EOF/section validation before APK packaging. This verifies supported regression fixtures, not every customer's DWG or byte-identical DWG round-tripping.
Alignment export mutates original group-code records from the temporary DXF stream instead of redrawing/reconstructing entities. BLOCK definitions receive the global linear transform; INSERT anchors receive the affine translation, while INSERT-local scale/rotation remain unchanged to prevent double-transforming block labels and axes. Unsupported opaque entities fail closed rather than exporting a knowingly incomplete drawing.
TXT
printf 'PASS v155: rebuilt native DWG WASM runtime and passed six-version DWG reader/writer integration tests.\n'
