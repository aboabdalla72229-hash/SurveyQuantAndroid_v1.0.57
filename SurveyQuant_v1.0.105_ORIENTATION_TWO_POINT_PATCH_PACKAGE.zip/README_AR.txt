حزمة مشروع توجيه اللوح بنقطتين - SurveyQuant v1.0.105

المحتويات:
1) SurveyQuant_v1.0.105_ORIENTATION_TWO_POINT_MODULE.js
   وحدة الواجهة والحساب والتحويل النصي لعناصر DXF ثنائية الأبعاد.
2) SurveyQuant_v1.0.105_ORIENTATION_TWO_POINT_TEST.js
   اختبار للزاوية والمقياس وتطابق النقطتين، والتحقق من عدم إتلاف النصوص ورفض عناصر CAD غير المدعومة.
3) .github/workflows/build-v105-orientation-two-point.yml
   Workflow يستخدم مصدر Android الأصلي v1.0.93 مع HTML الإصدار 104، ثم يضيف المشروع دون استبدال وظائف التطبيق الأخرى، ويرفع APK وحزمة المصدر كـ Artifact.

خطوات الاستخدام على GitHub:
1) ارفع ملف SurveyQuant_v1.0.105_ORIENTATION_TWO_POINT_PATCH_PACKAGE.zip إلى جذر المستودع:
   aboabdalla72229-hash/SurveyQuantAndroid_v1.0.57
2) ارفع ملف build-v105-orientation-two-point.yml إلى المسار:
   .github/workflows/build-v105-orientation-two-point.yml
3) افتح Actions واختر Build SurveyQuant v1.0.105 - Two Point CAD Orientation ثم Run workflow عند الحاجة.
4) افتح نتيجة التشغيل الناجح ونزّل Artifact باسم SurveyQuant-v1.0.105-ORIENTATION-TWO-POINT.

مهم بخصوص الحفاظ على CAD:
- التوجيه في هذه الحزمة يدعم DXF النصي وعناصر 2D القياسية المحددة داخل الوحدة.
- اللوحة المرجعية والملف الأصلي لا يتم تعديلهما؛ المخرج نسخة DXF جديدة.
- إذا احتوى الملف على عناصر تحتاج محرك CAD أصليًا (مثل DIMENSION أو ACAD_PROXY_ENTITY أو عناصر Civil 3D مخصصة)، يتوقف التصدير بدل إنتاج لوحة ناقصة.
- محرك LibreDWG الموجود حاليًا في التطبيق مدمج للقراءة فقط؛ لا تدّعي هذه الحزمة كتابة DWG الأصلي أو الحفاظ الكامل على كائنات Civil 3D. يلزم دعم كتابة DWG من SDK مناسب قبل تفعيل ذلك بأمان.
