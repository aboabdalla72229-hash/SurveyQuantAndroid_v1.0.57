#!/usr/bin/env python3
"""Fix Android WebView DWG WASM loading by preloading the binary and transferring it to the worker."""
from __future__ import annotations
import argparse, base64
from pathlib import Path

MARKER = "sq162-wasm-binary"
HELPER = r'''<script type="application/octet-stream" id="sq162-wasm-binary">__SQ_WASM_BASE64__</script>
<script id="sq162-wasm-helper">
(function(g){
  g.sq162GetBundledDwgWasmBinary=function(){
    if(g.__sq162DwgWasmBinary instanceof Uint8Array && g.__sq162DwgWasmBinary.byteLength) return g.__sq162DwgWasmBinary;
    var node=document.getElementById('sq162-wasm-binary');
    if(!node) throw new Error('ملف محرك DWG المضمّن غير موجود داخل التطبيق.');
    var base64=(node.textContent||'').trim();
    if(!base64) throw new Error('بيانات محرك DWG المضمّنة فارغة.');
    var raw=atob(base64),bytes=new Uint8Array(raw.length);
    for(var i=0;i<raw.length;i++) bytes[i]=raw.charCodeAt(i);
    g.__sq162DwgWasmBinary=bytes;
    node.textContent='';
    if(node.parentNode) node.parentNode.removeChild(node);
    return bytes;
  };
})(window);
</script>'''


def replace_once(src: str, old: str, new: str, label: str) -> str:
    n = src.count(old)
    if n != 1:
        raise ValueError(f"{label}: expected exactly one match, found {n}")
    return src.replace(old, new, 1)


def validate(html: str, loader: str, wasm_size: int | None = None) -> None:
    html_required = {
        "embedded WASM resource": 'id="sq162-wasm-binary"',
        "lazy decode helper": "sq162GetBundledDwgWasmBinary",
        "worker binary transfer guard": "sqDwgWorkerWasmSent",
        "worker receives binary before importScripts": "self.SQ_DWG_WASM_BINARY=new Uint8Array(payload.wasmBinaryBuffer)",
        "DWG main-thread fallback preloads binary": "window.SQ_DWG_WASM_BINARY=sq162GetBundledDwgWasmBinary()",
        "raw reference path still exists": "rawOnly:true,conversionOnly:true",
        "V160 memory optimization retained": "function sqScanProjectionDxf(rawBytes){",
        "V161 projection path retained": "sqV161RawReferenceOnly",
    }
    for label, marker in html_required.items():
        if marker not in html:
            raise ValueError(f"Validation failed: {label} marker missing ({marker})")
    if html.count('id="sq162-wasm-binary"') != 1:
        raise ValueError("The embedded WASM binary tag must occur exactly once")
    if "__SQ_WASM_BASE64__" in html:
        raise ValueError("Unexpanded WASM base64 placeholder remains")
    loader_required = {
        "runtime accepts an injected binary": 'Module["wasmBinary"]=self.SQ_DWG_WASM_BINARY',
        "standard WASM fallback remains available": "function getBinaryPromise(binaryFile)",
    }
    for label, marker in loader_required.items():
        if marker not in loader:
            raise ValueError(f"Validation failed: {label} marker missing ({marker})")
    if wasm_size is not None and wasm_size < 1_000_000:
        raise ValueError(f"LibreDWG WASM too small ({wasm_size} bytes)")


def patch(html: str, loader: str, wasm: bytes) -> tuple[str, str]:
    if MARKER in html or "sq162GetBundledDwgWasmBinary" in html:
        raise ValueError("V162 WASM fix already appears to be installed; refusing duplicate insertion")
    if "sqDwgWorkerWasmSent" in html:
        raise ValueError("Worker WASM transfer marker exists without embedded resource; refusing partial patch")
    if "var Module=moduleArg;var readyPromiseResolve" not in loader:
        raise ValueError("Expected LibreDWG Emscripten runtime initialization marker is missing")

    # Use the exact binary shipped with the APK. The inert script tag is decoded only
    # on first DWG access, then removed from the DOM to release the 8.5 MB base64 text.
    payload = base64.b64encode(wasm).decode("ascii")
    block = HELPER.replace("__SQ_WASM_BASE64__", payload)
    close_body = list(__import__('re').finditer(r"</body\s*>", html, __import__('re').I))
    if close_body:
        m = close_body[-1]
        html = html[:m.start()] + "\n" + block + "\n" + html[m.start():]
    else:
        html += "\n" + block + "\n"

    html = replace_once(html,
        "let sqDwgWorkerRequestId = 0;\nconst sqDwgWorkerPending = new Map();",
        "let sqDwgWorkerRequestId = 0;\nlet sqDwgWorkerWasmSent = false;\nconst sqDwgWorkerPending = new Map();",
        "worker WASM transfer state")
    html = replace_once(html,
        "' if(!sqEnginePromise){try{importScripts(payload.wasmScriptUrl,payload.engineScriptUrl);",
        "' if(!sqEnginePromise){try{if(payload.wasmBinaryBuffer)self.SQ_DWG_WASM_BINARY=new Uint8Array(payload.wasmBinaryBuffer);importScripts(payload.wasmScriptUrl,payload.engineScriptUrl);",
        "worker injects binary before loading Emscripten runtime")
    html = replace_once(html,
        "if(worker&&sqDwgWorker===worker)sqDwgWorker=null;",
        "if(worker&&sqDwgWorker===worker){sqDwgWorker=null;sqDwgWorkerWasmSent=false;}",
        "reset transfer state when worker is disposed")
    html = replace_once(html,
        "dwgLibPromise=(async()=>{\n   await sqLoadClassicScriptOnce(SQ_WRITER_WASM_URL,()=>typeof window.createModule==='function');",
        "dwgLibPromise=(async()=>{\n   window.SQ_DWG_WASM_BINARY=sq162GetBundledDwgWasmBinary();\n   await sqLoadClassicScriptOnce(SQ_WRITER_WASM_URL,()=>typeof window.createModule==='function');",
        "main thread loads embedded binary before runtime initialization")

    old_post = """try{worker.postMessage({requestId:requestId,buffer:buffer,wasmScriptUrl:new URL(SQ_WRITER_WASM_URL,document.baseURI).href,engineScriptUrl:new URL(SQ_WRITER_ENGINE_URL,document.baseURI).href,wasmBase:sqDwgWasmRuntimePath(),skipDxfIfNativeModel:!!options.skipDxfIfNativeModel,retainRawDWG:options.retainRawDWG!==false,conversionOnly:!!options.conversionOnly,projectionSource:!!options.projectionSource},[buffer]);}
  catch(_){clearTimeout(timer);sqDwgWorkerPending.delete(requestId);resolve(null);}"""
    new_post = """const payload={requestId:requestId,buffer:buffer,wasmScriptUrl:new URL(SQ_WRITER_WASM_URL,document.baseURI).href,engineScriptUrl:new URL(SQ_WRITER_ENGINE_URL,document.baseURI).href,wasmBase:sqDwgWasmRuntimePath(),skipDxfIfNativeModel:!!options.skipDxfIfNativeModel,retainRawDWG:options.retainRawDWG!==false,conversionOnly:!!options.conversionOnly,projectionSource:!!options.projectionSource};
  const transfers=[buffer];
  if(!sqDwgWorkerWasmSent){const shared=sq162GetBundledDwgWasmBinary();const wasmBuffer=shared.buffer.slice(shared.byteOffset,shared.byteOffset+shared.byteLength);payload.wasmBinaryBuffer=wasmBuffer;transfers.push(wasmBuffer);sqDwgWorkerWasmSent=true;}
  try{worker.postMessage(payload,transfers);}
  catch(_){if(payload.wasmBinaryBuffer)sqDwgWorkerWasmSent=false;clearTimeout(timer);sqDwgWorkerPending.delete(requestId);resolve(null);}"""
    html = replace_once(html, old_post, new_post, "transfer embedded WASM only on first worker request")

    # Emscripten will receive Module.wasmBinary directly, so it never tries to fetch
    # file:///android_asset/.../libredwg-web.wasm from a blob worker.
    loader = replace_once(loader,
        "var Module=moduleArg;var readyPromiseResolve",
        'var Module=moduleArg||{};if(!Module["wasmBinary"]&&typeof self!=="undefined"&&self.SQ_DWG_WASM_BINARY)Module["wasmBinary"]=self.SQ_DWG_WASM_BINARY;var readyPromiseResolve',
        "Emscripten injected WASM binary")
    validate(html, loader, len(wasm))
    return html, loader


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--html", required=True, type=Path)
    p.add_argument("--wasm-loader", required=True, type=Path)
    p.add_argument("--wasm", required=True, type=Path)
    p.add_argument("--check-only", action="store_true")
    a = p.parse_args()
    html = a.html.read_text(encoding="utf-8")
    loader = a.wasm_loader.read_text(encoding="utf-8")
    if a.check_only:
        validate(html, loader, a.wasm.stat().st_size)
        print("PASS V162 WASM fix: embedded binary, one-time worker transfer, and Emscripten wasmBinary injection verified")
        return
    if not a.wasm.is_file() or a.wasm.stat().st_size < 1_000_000:
        raise SystemExit(f"LibreDWG WASM file missing or too small: {a.wasm}")
    patched_html, patched_loader = patch(html, loader, a.wasm.read_bytes())
    a.html.write_text(patched_html, encoding="utf-8")
    a.wasm_loader.write_text(patched_loader, encoding="utf-8")
    print(f"PASS V162 WASM fix: embedded {a.wasm.stat().st_size:,} bytes in {a.html} and patched {a.wasm_loader}")

if __name__ == "__main__":
    main()
