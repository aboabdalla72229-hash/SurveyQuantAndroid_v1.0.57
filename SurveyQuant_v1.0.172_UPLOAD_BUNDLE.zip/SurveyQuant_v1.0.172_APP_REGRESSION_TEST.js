#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const htmlFile=process.argv[2],engineFile=process.argv[3];
if(!htmlFile||!engineFile)throw new Error('Usage: node V172_APP_REGRESSION_TEST.js <patched-index.html> <engine.js>');
const html=fs.readFileSync(htmlFile,'utf8'),engine=fs.readFileSync(engineFile,'utf8');
const embedded=html.match(/<script\s+type="application\/octet-stream"\s+id="sq163-cad-engine">([A-Za-z0-9+\/=\r\n]+)<\/script>/i);
assert.ok(embedded,'embedded CAD engine missing');
assert.equal(Buffer.from(embedded[1].replace(/\s/g,''),'base64').toString('utf8'),engine,'embedded engine differs from tested V172 engine');
const menu=html.match(/<div class="home-menu">([\s\S]*?)<\/div>/i);assert.ok(menu,'home project grid missing');
const buttons=[...menu[1].matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/gi)];
assert.equal(buttons.length,10,'home must contain exactly ten STATIC buttons');
const ids=buttons.map(x=>(x[1].match(/\bid="([^"]+)"/)||[])[1]||'');
for(const id of ['project1Card','profileCard','roadCard','pipeCard','landAreaCard','fileToDxfCard','cleanFilesCard','dropFilesCard']){
 assert.ok(html.includes(`id="${id}"`),'Existing project card disappeared: '+id);
 assert.ok(menu[1].includes(`openProjectPage('${id}')`),'Existing home-menu shortcut disappeared: '+id);
}
assert.ok(ids.includes('sq172-home-orientation-project'),'Orientation project is not a static menu button');
assert.ok(ids.includes('sq172-home-pdf-project'),'PDF project is not a static menu button');
assert.ok(menu[1].includes("sq172OpenCadProject('align')"),'Orientation button is not linked to align tab');
assert.ok(menu[1].includes("sq172OpenCadProject('raster')"),'PDF button is not linked to raster tab');
assert.ok(html.includes('display:block!important;visibility:visible!important;opacity:1!important'),'Explicit visibility CSS missing');
assert.ok(html.includes('window.sq172OpenCadProject=function(tabName)'),'Static button handler missing');
assert.ok(html.includes("window.addEventListener('surveyquant-cad-ready',onReady,{once:true})"),'Runtime-ready fallback missing');
for(const marker of ['sq170-orientation-canvas-zoom-per-board-picks-snap-wasm-binary-pdf-worker-ole-reader','sq172-static-visible-home-project-shortcuts-pdf-image-pair','sq163-pdfjs-worker','sq162-wasm-binary','sq164-cad-output-axis-fix','sqDownloadNameDialog','sq166-readonly-source-and-exact-pdf-raster','sq167-dwg-orientation-view-transform','sq168-pdf-access-axis-points-explicit-snap-fix','sq169-orientation-save-block-axis-content-identity-single-dxf-ole','user-scalable=no','installGlobalPdfWorkerGuard','createByWasmInstance'])assert.ok(html.includes(marker),'Missing HTML marker: '+marker);
for(const marker of ['function makeRasterUnderlayDxf','function downloadPairedRasterFile','const jpegBytes=await canvasJpegBytes(canvas,0.96)',"await downloadPairedRasterFile(jpegBytes,imageName,'image/jpeg')","await downloadPairedRasterFile(dxfBytes,dxfName,'application/dxf')",'IMAGE/IMAGEDEF القياسي بدل OLE2FRAME'])assert.ok(engine.includes(marker),'Missing V171 PDF pair behavior: '+marker);
assert.ok(engine.includes("'0','IMAGE'")&&engine.includes("'0','IMAGEDEF'"),'standard raster image entities are missing');
assert.ok(!engine.includes('makeEmbeddedRasterDxf(jpegTiles,canvas.width,canvas.height,factor)'),'PDF exporter still writes OLE2FRAME instead of IMAGE/IMAGEDEF');
console.log(JSON.stringify({ok:true,staticHomeButtons:10,existingProjectShortcuts:8,newProjectShortcuts:['توجيه اللوحات','تحويل PDF إلى DXF'],pdfExport:'standard IMAGE + IMAGEDEF + paired JPG sidecar',saveOrder:'JPG sidecar first, DXF second'},null,2));
