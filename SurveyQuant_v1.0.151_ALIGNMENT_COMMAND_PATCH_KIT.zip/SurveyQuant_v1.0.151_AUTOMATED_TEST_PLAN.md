# V151 ALIGNMENT test plan

## Automated checks wired into the release workflow
1. Python compilation for the HTML patcher and APK packager.
2. `node --check` for all new and inherited JavaScript tests.
3. The V151 command integration test: one version code, one new module, removal of the old menu/card at runtime, use of the shared DWG/DXF reader, output-transform API, session reset, and absence of browser persistence APIs.
4. Production two-point solver tests using negative source coordinates, map-scale conversion, rotation, and survey-sized coordinates. Both chosen points must map to their matching reference coordinates within the solver's numerical tolerance.
5. V150 regression suite: SPLINE curve sampling, session reset and stale async load protection, shared DWG reader, and WCS/OCS/INSERT preview transforms.
6. V130 regression test for the shared DWG reader and faithful DXF entity-byte preservation.
7. Syntax check of every inline JavaScript block in the final HTML.
8. APK asset injection, preservation of bundled LibreDWG WASM, manifest version 1.0.151/code 151, zipalign and cryptographic signature verification.

## Not claimed
No supplied real project DWG/DXF was available in this request. Therefore these tests cannot establish exact rendering of every custom Civil 3D/Proxy object. Manual inspection of the exported DXF in a full CAD engine is required before production surveying use.
