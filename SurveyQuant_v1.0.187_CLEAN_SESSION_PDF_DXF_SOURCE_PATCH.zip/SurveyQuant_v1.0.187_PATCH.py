#!/usr/bin/env python3
"""Apply the v187 clean-session orientation and PDF-vector-only DXF repair to a v177 source kit."""
from __future__ import annotations
import base64
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TEMPLATE = ROOT / 'SurveyQuant_v1.0.187_R2000_TEMPLATE.dxf'


def replace_once(text: str, old: str, new: str, label: str) -> str:
    n = text.count(old)
    if n != 1:
        raise RuntimeError(f'{label}: expected exactly one target, found {n}')
    return text.replace(old, new, 1)


def replace_function(text: str, start: str, end: str, replacement: str, label: str) -> str:
    a = text.find(start)
    b = text.find(end, a + len(start)) if a >= 0 else -1
    if a < 0 or b < 0:
        raise RuntimeError(f'{label}: function boundaries not found')
    return text[:a] + replacement + text[b:]


def polylines_function(template_b64: str) -> str:
    writer = ROOT / 'SurveyQuant_v1.0.187_R2000_WRITER.js.txt'
    if not writer.is_file():
        raise FileNotFoundError(writer)
    return writer.read_text(encoding='utf-8').replace('__TEMPLATE_B64__', template_b64)


def patch_pdf_function(text: str) -> str:
    old = "const list=await page.getOperatorList(),O=lib.OPS,paths=[];"
    new = """const list=await page.getOperatorList(),O=lib.OPS,paths=[];
    const rasterFns=new Set(['paintImageXObject','paintInlineImageXObject','paintImageMaskXObject','paintImageMaskXObjectGroup','paintImageXObjectRepeat','paintImageMaskXObjectRepeat','paintInlineImageXObjectGroup','paintSolidColorImageMask'].map(k=>O[k]).filter(Number.isInteger));
    const unsupportedFns=new Map([['paintXObject','كائن Form/XObject خارجي'],['paintFormXObjectBegin','بداية كائن Form خارجي'],['setStrokeColorSpace','مساحة لون خاصة للخط'],['setStrokeColor','لون خط من مساحة غير مدعومة'],['setStrokeColorN','لون خط خاص/Pattern'],['setFillColorSpace','مساحة لون خاصة للتعبئة'],['setFillColor','لون تعبئة من مساحة غير مدعومة'],['setFillColorN','لون تعبئة خاص/Pattern'],['clip','قص هندسي'],['eoClip','قص هندسي Even-Odd']].filter(([k])=>Number.isInteger(O[k])).map(([k])=>[O[k],k]));"""
    text = replace_once(text, old, new, 'PDF operator setup')
    text = replace_once(text, 'const stack=[];let active=null,subpaths=[];', 'const stack=[];let active=null,subpaths=[],fillGroupSerial=0;', 'PDF fill group state')
    text = replace_once(text, 'for(let k=1;k<=16;k++){const t=k/16', 'for(let k=1;k<=64;k++){const t=k/64', 'PDF curve tessellation')
    old = """for(let n=0;n<list.fnArray.length;n++){const fn=list.fnArray[n],a=list.argsArray[n];
      if(fn===O.save)"""
    new = """for(let n=0;n<list.fnArray.length;n++){const fn=list.fnArray[n],a=list.argsArray[n];
      if(rasterFns.has(fn))throw new Error('صفحة PDF تحتوي صورة نقطية أو عنصرًا صوريًا. لا يمكن إنشاء DXF هندسي مطابق لها بدون تحويل تقريبي؛ لم يتم إنشاء أي ملف.');
      if(unsupportedFns.has(fn))throw new Error('صفحة PDF تحتوي '+unsupportedFns.get(fn)+' لا يمكن تمثيله بأمان في DXF؛ أوقفت التحويل حتى لا يتم إسقاط عناصر أو تغيير ألوانها. لم يتم إنشاء أي ملف.');
      if(fn===O.paintFormXObjectEnd)throw new Error('صفحة PDF تحتوي كائن Form خارجيًا غير مدعوم؛ لم يتم إنشاء DXF ناقص.');
      if(fn===O.shadingFill)throw new Error('صفحة PDF تحتوي تدرجات أو تعبئات لونية غير قابلة للتمثيل كخطوط CAD مطابقة؛ لم يتم إنشاء أي ملف.');
      if(fn===O.setDash&&Array.isArray(a?.[0])&&a[0].some(v=>Math.abs(Number(v)||0)>1e-9))throw new Error('صفحة PDF تحتوي خطوطًا متقطعة أو نمط خط خاصًا غير مدعوم بدقة؛ لم يتم إنشاء أي ملف.');
      if(fn===O.save)"""
    text = replace_once(text, old, new, 'PDF operator loop')
    old = "const paint=fn=>{const isFill=[O.fill,O.eoFill,O.fillStroke,O.eoFillStroke,O.closeFillStroke,O.closeEOFillStroke].includes(fn);finish([O.closeStroke,O.closeFillStroke,O.closeEOFillStroke,O.fill,O.eoFill,O.fillStroke,O.eoFillStroke].includes(fn));const color=ci(isFill?fill:stroke);if(!color.white){for(const q of subpaths){if(paths.length>=50000)throw new Error('ملف PDF يحتوي عدد مسارات يتجاوز الحد الآمن.');if(q.points.length>=2)paths.push({...q,aci:color.aci,rgb:color.rgb,lineWidth});}}subpaths=[];active=null;};"
    new = "const paint=fn=>{const isFill=[O.fill,O.eoFill,O.fillStroke,O.eoFillStroke,O.closeFillStroke,O.closeEOFillStroke].includes(fn);finish([O.closeStroke,O.closeFillStroke,O.closeEOFillStroke].includes(fn));const isStroke=[O.stroke,O.closeStroke,O.fillStroke,O.eoFillStroke,O.closeFillStroke,O.closeEOFillStroke].includes(fn);if(isFill){const color=ci(fill),group=fillGroupSerial++,rule=[O.eoFill,O.eoFillStroke,O.closeEOFillStroke].includes(fn)?'evenodd':'nonzero';for(const q of subpaths){if(paths.length>=50000)throw new Error('ملف PDF يحتوي عدد مسارات يتجاوز الحد الآمن.');if(q.points.length>=3)paths.push({...q,filled:true,closed:true,fillRule:rule,fillGroup:group,aci:color.aci,rgb:color.rgb,lineWidth:0});}}if(isStroke){const color=ci(stroke);for(const q of subpaths){if(paths.length>=50000)throw new Error('ملف PDF يحتوي عدد مسارات يتجاوز الحد الآمن.');if(q.points.length>=2)paths.push({...q,filled:false,aci:color.aci,rgb:color.rgb,lineWidth});}}subpaths=[];active=null;};"
    text = replace_once(text, old, new, 'PDF fill and stroke preservation')
    old = "const content=await page.getTextContent({includeMarkedContent:false,disableNormalization:false}),out=[];"
    new = "const content=await page.getTextContent({includeMarkedContent:false,disableNormalization:false}),out=[];const opList=await page.getOperatorList(),O=lib?.OPS,textColors=[];let currentFill=[0,0,0];const showOps=new Set([O?.showText,O?.showSpacedText,O?.nextLineShowText,O?.nextLineSetSpacingShowText].filter(Number.isInteger));for(let i=0;i<opList.fnArray.length;i++){const fn=opList.fnArray[i],a=opList.argsArray[i];if(fn===O?.setFillRGBColor)currentFill=Array.from(a||[]).slice(0,3).map(v=>Math.max(0,Math.min(255,Math.round(Number(v)||0))));else if(fn===O?.setFillGray){const g=Math.round(Math.max(0,Math.min(1,Number(a?.[0])||0))*255);currentFill=[g,g,g];}else if(fn===O?.setFillCMYKColor){const c=Array.from(a||[]).slice(0,4).map(v=>Math.max(0,Math.min(1,Number(v)||0)));while(c.length<4)c.push(0);const k=c[3];currentFill=[Math.round(255*(1-Math.min(1,c[0]+k))),Math.round(255*(1-Math.min(1,c[1]+k))),Math.round(255*(1-Math.min(1,c[2]+k)))];}else if(showOps.has(fn))textColors.push((currentFill[0]<<16)|(currentFill[1]<<8)|currentFill[2]);}const textColorMatch=textColors.length===(content.items||[]).length;if((content.items||[]).length>0&&!textColorMatch)throw new Error('تعذر مطابقة ألوان النصوص في PDF مع عناصر النص المستخرجة. أوقفت التحويل بدل تغيير ألوان النص بصمت.');const textPalette=[[1,0xff0000],[2,0xffff00],[3,0x00ff00],[4,0x00ffff],[5,0x0000ff],[6,0xff00ff],[7,0x000000]];const textAci=rgb=>{let best=7,dist=Infinity;for(const [aci,c] of textPalette){const dr=((rgb>>16)&255)-((c>>16)&255),dg=((rgb>>8)&255)-((c>>8)&255),db=(rgb&255)-(c&255),d=dr*dr+dg*dg+db*db;if(d<dist){dist=d;best=aci;}}return best;};"
    text = replace_once(text, old, new, 'PDF text color state')
    text = replace_once(text, 'async function pdfTextToCad(page,viewport,maxItems=20000){', 'async function pdfTextToCad(page,viewport,maxItems=20000,lib=root.pdfjsLib){', 'PDF text color API')
    old = "const text=dxfUnicode(item.str);if(text)out.push({text,x:Number(p[0]),y:Number(p[1]),height:h,rotation:Math.atan2(-(q[1]-p[1]),q[0]-p[0])*180/Math.PI,width:Number(item.width)||0});}"
    new = "const text=dxfUnicode(item.str);if(text){const rgb=textColorMatch?(textColors[out.length]??0):0;out.push({text,x:Number(p[0]),y:Number(p[1]),height:h,rotation:Math.atan2(-(q[1]-p[1]),q[0]-p[0])*180/Math.PI,width:Number(item.width)||0,rgb,aci:textAci(rgb)});}}"
    text = replace_once(text, old, new, 'PDF text color assignment')
    return text


def patch_orientation(text: str) -> str:
    # Single-board-at-a-time panels.
    text = replace_once(
        text,
        '<div class="sq162-grid" style="margin-top:10px">',
        '<div class="sq162-board-switch" role="tablist" aria-label="اختيار اللوحة المعروضة"><button type="button" class="sq162-tab active" data-sq-board-tab="source" role="tab" aria-selected="true">اللوحة غير الموجهة</button><button type="button" class="sq162-tab" data-sq-board-tab="target" role="tab" aria-selected="false">اللوحة المرجعية الموجهة</button></div><div class="sq162-grid sq162-board-panels" style="margin-top:10px">',
        'orientation tabs'
    )
    text = replace_once(text, '<div class="sq162-panel"><label for="sq162-source-file">', '<div class="sq162-panel sq162-board-panel active" data-board-panel="source"><label for="sq162-source-file">', 'source panel')
    text = replace_once(text, '<div class="sq162-panel"><label for="sq162-target-file">', '<div class="sq162-panel sq162-board-panel" data-board-panel="target" hidden style="display:none"><label for="sq162-target-file">', 'target panel')
    # PDF-only UI. The hidden canvas may remain for backwards-compatible cleanup but is not used or exported.
    text = replace_once(text, 'اختر صورة أو PDF', 'اختر ملف PDF فقط', 'PDF-only label')
    text = replace_once(text, 'accept="image/png,image/jpeg,image/webp,.jpg,.jpeg,.png,.webp,.pdf,application/pdf"', 'accept=".pdf,application/pdf"', 'PDF-only accept')
    text = replace_once(text, '📄 10. تحويل PDF والصور إلى DXF', '📄 10. تحويل PDF إلى DXF فقط', 'PDF project title')
    text = replace_once(
        text,
        'يتم تحويل الخطوط والأشكال الظاهرة إلى كيانات POLYLINE وVERTEX فعلية قابلة للتحرير داخل AutoCAD. لا يتم إرفاق صورة داخل DXF. في ملفات PDF الممسوحة ضوئيًا يكون الناتج تتبعًا هندسيًا للخطوط المرئية، ولا يمكن استعادة النصوص أو الإحداثيات/المقياس الأصلي تلقائيًا من صورة فقط.',
        'يُنشأ ملف DXF هندسي واحد فقط من المسارات المتجهية والنصوص القابلة للاستخراج. لا يتم تصدير صور أو إرفاقها داخل DXF، ولا يتم تتبع الصفحة أو إعادة رسمها. إذا احتوت الصفحة صورًا نقطية أو تعبئات/تدرجات أو أنماط خطوط لا يمكن تمثيلها بدقة، يتوقف التحويل ويشرح السبب بدل إخراج لوحة ناقصة.',
        'PDF vector-only description'
    )
    # Change session state to track which single board panel is currently visible.
    text = replace_once(text,
        "const state = { source: null, target: null, loadSerial:{source:0,target:0}, pickStage: -1, picks: [null,null,null,null], lastAlignmentDiagnostics:null, tracerFile: null, rasterCanvas: null, views:",
        "const state = { source: null, target: null, activeBoardSide:'source', loadSerial:{source:0,target:0}, pickStage: -1, picks: [null,null,null,null], lastAlignmentDiagnostics:null, tracerFile: null, rasterCanvas: null, views:",
        'orientation state')
    # Insert tab switch handler after status helper.
    old = "function status(text, id = 'sq162-align-status') { el(id).textContent = text; }\n    function fileTitle(file)"
    new = """function status(text, id = 'sq162-align-status') { const node=el(id);if(node)node.textContent=text; }
    function activateBoardPanel(which){
      if(which!=='source'&&which!=='target')return;
      state.activeBoardSide=which;
      for(const panel of overlay.querySelectorAll('[data-board-panel]')){const active=panel.dataset.boardPanel===which;panel.classList.toggle('active',active);panel.hidden=!active;panel.style.display=active?'block':'none';}
      for(const tab of overlay.querySelectorAll('[data-sq-board-tab]')){const active=tab.dataset.sqBoardTab===which;tab.classList.toggle('active',active);tab.setAttribute('aria-selected',active?'true':'false');}
      const raf=root.requestAnimationFrame||((fn)=>root.setTimeout(fn,16));raf(()=>redrawOne(which));
    }
    for(const tab of overlay.querySelectorAll('[data-sq-board-tab]'))tab.addEventListener('click',()=>activateBoardPanel(tab.dataset.sqBoardTab));
    function fileTitle(file)"""
    text = replace_once(text, old, new, 'board tab handler')
    # Replace invalidation: any board replacement resets all point picks and alignment.
    start = '    function invalidateAlignmentBecauseBoardChanged(changed){'
    end = '    function clearDrawing(which) {'
    new_func = """    function invalidateAlignmentBecauseBoardChanged(changed){
      state.picks=[null,null,null,null];state.lastAlignmentDiagnostics=null;state.pickStage=-1;state.hover={source:null,target:null};
      if(state.source){state.source.alignment=null;state.source.transform=null;state.source.viewGeom=null;const g=state.source.geom;state.views.source={zoom:1,panX:0,panY:0,centerX:(g.minX+g.maxX)/2,centerY:(g.minY+g.maxY)/2};}
      for(const side of ['source','target'])if(state[side]){const g=state[side].geom;state.views[side]={zoom:1,panX:0,panY:0,centerX:(g.minX+g.maxX)/2,centerY:(g.minY+g.maxY)/2};const c=el(`sq162-${side}-canvas`);if(c)c._sqMap=null;}
      updatePickUi();
    }
"""
    text = replace_function(text, start, end, new_func, 'orientation invalidate')
    # Replace clearDrawing with complete point and canvas invalidation.
    start = '    function clearDrawing(which) {'
    end = '    function cleanup() {'
    new_func = """    function clearDrawing(which) {
      state.loadSerial[which]=(state.loadSerial[which]||0)+1;
      if(state[which]?.rasterUrl)try{root.URL.revokeObjectURL(state[which].rasterUrl);}catch(_){}
      if(state[which]?.rasterUrls)for(const u of state[which].rasterUrls)try{root.URL.revokeObjectURL(u);}catch(_){}
      state[which]=null;state.lastAlignmentDiagnostics=null;state.pickStage=-1;state.picks=[null,null,null,null];state.hover={source:null,target:null};
      if(state.source){state.source.alignment=null;state.source.transform=null;state.source.viewGeom=null;}
      for(const side of ['source','target']){const prefix=side==='source'?'source':'target',canvas=el(`sq162-${prefix}-canvas`);if(side===which){const input=el(`sq162-${prefix}-file`),info=el(`sq162-${prefix}-info`);if(input)input.value='';if(info)info.textContent='لم يتم اختيار ملف بعد.';if(canvas){canvas._sqMap=null;clearCanvas(canvas);}}}
      if(state.activeBoardSide===which&&state[which=== 'source'?'target':'source'])activateBoardPanel(which==='source'?'target':'source');
      updatePickUi();
    }
"""
    text = replace_function(text, start, end, new_func, 'orientation clearDrawing')
    # Cleanup must be safe if optional preview canvas is absent and must clear session data.
    text = replace_once(text,
        "el('sq162-raster-canvas').style.display = 'none'; clearCanvas(el('sq162-raster-canvas'));\n      el('sq162-trace').disabled = true; status('تم مسح الملفات والنقاط من الذاكرة المؤقتة.');",
        "const preview=el('sq162-raster-canvas');if(preview){preview.style.display='none';clearCanvas(preview);preview.width=1;preview.height=1;}\n      const exportBtn=el('sq162-trace');if(exportBtn)exportBtn.disabled=true;state.activeBoardSide='source';activateBoardPanel('source');state.picks=[null,null,null,null];state.lastAlignmentDiagnostics=null;state.pickStage=-1;status('تم إنهاء الجلسة ومسح اللوحتين والنقاط والبيانات المؤقتة.');",
        'orientation cleanup')
    # Wrap app navigation so switching away from orientation always clears all temporary boards.
    old = """      status('اختر ملفًا للبدء.', 'sq162-raster-status');
    }
    function refreshTransformDetails(){"""
    new = """      status('اختر ملف PDF للبدء.', 'sq162-raster-status');
    }
    if(!root.__sq187ProjectNavWrapped){
      const originalOpen=root.openProjectPage,originalClose=root.closeProjectPage;
      if(typeof originalOpen==='function')root.openProjectPage=function(id,...args){if((orientationCard.classList.contains('active-project')&&id!=='sqOrientationCard')||(pdfCard.classList.contains('active-project')&&id!=='sqPdfDxfCard'))cleanup();return originalOpen.call(this,id,...args);};
      if(typeof originalClose==='function')root.closeProjectPage=function(...args){if(orientationCard.classList.contains('active-project')||pdfCard.classList.contains('active-project'))cleanup();return originalClose.apply(this,args);};
      root.__sq187ProjectNavWrapped=true;
    }
    function refreshTransformDetails(){"""
    text = replace_once(text, old, new, 'project navigation cleanup wrapper')
    # Picking always activates the correct board panel first.
    old = "const which=i<2?'source':'target';if(!state[which]){status('حمّل اللوحة الخاصة بهذا الاختيار أولًا.');return;}\n      if(i<2"
    new = "const which=i<2?'source':'target';if(!state[which]){status('حمّل اللوحة الخاصة بهذا الاختيار أولًا.');return;}activateBoardPanel(which);\n      if(i<2"
    text = replace_once(text, old, new, 'pick activates board')
    # Do not accept a click or stale canvas map from the hidden side.
    old = "if (state.pickStage < 0 || state.pickStage >= 4) return;\n      const slot=state.pickStage,expected = slot < 2 ? 'source' : 'target';"
    new = "if (state.pickStage < 0 || state.pickStage >= 4) return;\n      const slot=state.pickStage,expected = slot < 2 ? 'source' : 'target';if(state.activeBoardSide!==which){status('اختر اللوحة المطلوبة من شريط التبديل أولًا.');return;}"
    text = replace_once(text, old, new, 'active side guard')
    old = "if(state.pickStage<0||state.pickStage>=4)return;\n      const expected=state.pickStage<2?'source':'target';if(which!==expected)return;"
    new = "if(state.pickStage<0||state.pickStage>=4)return;\n      const expected=state.pickStage<2?'source':'target';if(which!==expected||state.activeBoardSide!==which)return;"
    text = replace_once(text, old, new, 'snap active side guard')
    # Switching to a board for loading makes that one and only that one visible.
    old = "state[which]=null;invalidateAlignmentBecauseBoardChanged(which);state.hover[which]=null;clearCanvas(el(`sq162-${which}-canvas`));"
    new = "state[which]=null;invalidateAlignmentBecauseBoardChanged(which);activateBoardPanel(which);state.hover[which]=null;const canvas=el(`sq162-${which}-canvas`);canvas._sqMap=null;clearCanvas(canvas);"
    text = replace_once(text, old, new, 'new board load switch')
    # Clear output previews/session state on page exit and beforeunload.
    text = replace_once(text, "root.addEventListener('pagehide', cleanup, { once: true });", "root.addEventListener('pagehide', cleanup);root.addEventListener('beforeunload',cleanup);", 'session exit listeners')
    return text


def pdf_handler() -> str:
    return r'''    // V187: PDF vector entities only. Raster pages, fills and unsupported line styles fail closed.
    const rasterFileInput=el('sq162-raster-file'),traceBtn=el('sq162-trace');
    rasterFileInput.addEventListener('click',()=>{rasterFileInput.value='';});
    rasterFileInput.addEventListener('change',()=>{
      state.tracerFile=rasterFileInput.files?.[0]||null;
      const file=state.tracerFile,valid=!!file&&(/\.pdf$/i.test(file.name)||file.type==='application/pdf');
      traceBtn.disabled=!valid;
      if(file&&!valid){state.tracerFile=null;rasterFileInput.value='';status('هذا المشروع يقبل PDF فقط. لم يتم اختيار صورة أو إنشاء أي ملف.','sq162-raster-status');return;}
      status(valid?`تم اختيار ملف PDF: ${file.name} (${file.size.toLocaleString()} بايت).`:'اختر ملف PDF للبدء.','sq162-raster-status');
    });
    traceBtn.addEventListener('click',async()=>{
      const file=state.tracerFile;let pdf=null;
      try{
        if(!file||!(/\.pdf$/i.test(file.name)||file.type==='application/pdf'))throw new Error('اختر ملف PDF فقط. لم يتم إنشاء أي ملف.');
        traceBtn.disabled=true;status('جارٍ فحص صفحة PDF واستخراج عناصرها المتجهية الأصلية دون تتبع صورة أو إعادة رسم...','sq162-raster-status');
        const lib=root.pdfjsLib;if(!lib||typeof lib.getDocument!=='function')throw new Error('قارئ PDF غير محمّل داخل التطبيق.');
        ensurePdfWorker(lib,doc);
        const data=new Uint8Array(await file.arrayBuffer());if(!data.length)throw new Error('وصل ملف PDF فارغًا من مدير الملفات. أعد اختياره.');
        let task=lib.getDocument({data,useSystemFonts:true,isEvalSupported:false,disableAutoFetch:true});
        try{pdf=await task.promise;}catch(workerError){task=lib.getDocument({data,useSystemFonts:true,isEvalSupported:false,disableWorker:true});pdf=await task.promise;}
        const requested=Math.max(1,Number.parseInt(el('sq162-pdf-page').value||'1',10)||1);if(requested>pdf.numPages)throw new Error(`رقم الصفحة ${requested} غير موجود. عدد صفحات الملف ${pdf.numPages}.`);
        const page=await pdf.getPage(requested),viewport=page.getViewport({scale:1});
        const paths=await pdfOperatorPathsToCad(page,lib,viewport);
        const pdfTexts=await pdfTextToCad(page,viewport,20000,lib);
        const factor=Number(el('sq162-raster-scale').value);if(!finite(factor)||factor<=0)throw new Error('عامل المقياس يجب أن يكون رقمًا موجبًا.');
        const result=polylinesToDxf(paths,viewport.width,viewport.height,factor,pdfTexts);
        if(!result.bytes||result.bytes.length<256||!result.count)throw new Error('لم تنتج الصفحة عناصر CAD قابلة للحفظ. لم يتم إنشاء أي ملف.');
        const dxfText=new TextDecoder('windows-1252').decode(result.bytes);
        if(!/\$ACADVER\s*\n\s*1\s*\nAC1015/.test(dxfText)||/\nIMAGE(?:\r?\n|$)|\nIMAGEDEF(?:\r?\n|$)/.test(dxfText))throw new Error('فشل فحص سلامة DXF R2000 أو تم اكتشاف كيان صورة. لم يتم حفظ الملف.');
        const baseName=(file.name.replace(/\.[^.]+$/,'').replace(/[^A-Za-z0-9_.()-]/g,'_').slice(0,48)||'SurveyQuant_PDF');
        const filename=`${baseName}_CAD.dxf`;
        await downloadBytes(result.bytes,filename,'application/dxf');
        status(`تم حفظ ملف DXF واحد فقط: ${filename}\nالإصدار: AutoCAD 2000 / AC1015 | المسارات: ${result.polylineCount.toLocaleString()} | المساحات المملوءة: ${(result.hatchCount||0).toLocaleString()} | الرؤوس: ${result.vertices.toLocaleString()} | النصوص: ${result.textCount.toLocaleString()}\nتم حفظ الألوان الأصلية كـ TrueColor وسُمك الخط كـ Lineweight. لا توجد صور أو ملفات جانبية داخل الناتج.`, 'sq162-raster-status');
      }catch(err){status(`لم يتم إنشاء أو حفظ أي ملف: ${String(err?.message||err)}`,'sq162-raster-status');}
      finally{try{if(pdf)await pdf.destroy();}catch(_){}traceBtn.disabled=!(state.tracerFile&&(/\.pdf$/i.test(state.tracerFile.name)||state.tracerFile.type==='application/pdf'));}
    });

'''


def apply(kit: Path) -> None:
    template_bytes = TEMPLATE.read_bytes()
    template_b64 = base64.b64encode(template_bytes).decode('ascii')
    html_path = kit / 'index.html'
    engine_path = kit / 'SurveyQuant_v1.0.177_CAD_ENGINE.js'
    for path in (html_path, engine_path):
        if not path.is_file():
            raise FileNotFoundError(path)
        text = path.read_text(encoding='utf-8')
        text = replace_function(text, '  function polylinesToDxf(', '  // Prefer native PDF vector paths before raster tracing;', polylines_function(template_b64), path.name + ' DXF writer')
        text = patch_pdf_function(text)
        text = patch_orientation(text)
        text = replace_function(text, '    // V176: native PDF vectors first; raster pages fall back to editable traced polylines.', "    root.addEventListener('pagehide', cleanup)", pdf_handler(), path.name + ' PDF-only handler')
        # The legacy fallback API remains in the engine for other projects, but this project's PDF flow no longer calls it.
        path.write_text(text, encoding='utf-8')
    # Re-version the packaging script to increment the v177 base APK to v187.
    package_path = kit / 'SurveyQuant_v1.0.177_PACKAGE_FREE_APK.py'
    ptext = package_path.read_text(encoding='utf-8')
    ptext = replace_once(ptext, "OLD_NAME = '1.0.162'", "OLD_NAME = '1.0.177'", 'manifest old version')
    ptext = replace_once(ptext, "NEW_NAME = '1.0.177'", "NEW_NAME = '1.0.187'", 'manifest new version')
    ptext = replace_once(ptext, 'NEW_CODE = 177', 'NEW_CODE = 187', 'manifest version code')
    package_path.write_text(ptext, encoding='utf-8')
    # Update the PDF vector test's expected DXF version and colors/lineweight assertions.
    pdf_test = kit / 'SurveyQuant_v1.0.177_PDF_VECTOR_DXF_TEST.js'
    t = pdf_test.read_text(encoding='utf-8')
    t = t.replace('AC1009', 'AC1015')
    t = t.replace('pdfTextToCad(page,viewport);', 'pdfTextToCad(page,viewport,20000,pdfjs);')
    t = t.replace("assert.match(text,/SQ_PDF_/);", "assert.match(text,/\\n420\\r?\\n/,'truecolor must be kept in DXF entities');\n  assert.match(text,/\\n370\\r?\\n/,'PDF lineweight must be kept in DXF entities');")
    t = t.replace("mode:'native PDF vector operators'", "mode:'native PDF vector operators with R2000 TrueColor/Lineweight'")
    t = t.replace(r"assert.match(text,/\$ACADVER\s*\n1\s*\nAC1015/);", r"assert.match(text,/\$ACADVER\s*\n\s*1\s*\nAC1015/);")
    t = t.replace(r"assert.match(text,/\nPOLYLINE\r?\n/);", r"assert.match(text,/\nLWPOLYLINE\r?\n/);")
    t = t.replace(r"assert.match(text,/\nVERTEX\r?\n/);", r"assert.doesNotMatch(text,/\nIMAGE(?:\r?\n|$)/);")
    pdf_test.write_text(t, encoding='utf-8')
    # Update the reusable engine regression to assert the R2000 LWPOLYLINE records.
    engine_test = kit / 'SurveyQuant_v1.0.177_CAD_ENGINE_TEST.js'
    et = engine_test.read_text(encoding='utf-8')
    et = et.replace("assert.match(dxfText(target),/POLYLINE/);", "assert.match(dxfText(target),/LWPOLYLINE/);")
    et = et.replace("assert.match(dxfText(source),/VERTEX/);", "assert.match(dxfText(source),/LWPOLYLINE/);")
    et = et.replace("assert.match(mergedText,/SQ_PDF_001/,'target layer remains');", "assert.match(mergedText,/LWPOLYLINE/,'target CAD entity remains');")
    et = et.replace("assert.match(mergedText,/SQ_PDF_005/,'source layer imports');", "assert.match(mergedText,/LWPOLYLINE/,'source CAD entity imports');")
    et = et.replace("(mergedText.match(/\\nPOLYLINE\\r?\\n/g)||[]).length>=2", "(mergedText.match(/\\nLWPOLYLINE\\r?\\n/g)||[]).length>=2")
    et = et.replace(r"assert.match(vectorText,/\nPOLYLINE\r?\n/);", r"assert.match(vectorText,/\nLWPOLYLINE\r?\n/);")
    et = et.replace(r"assert.match(vectorText,/\nVERTEX\r?\n/);", r"assert.doesNotMatch(vectorText,/\nIMAGE(?:\r?\n|$)/);")
    engine_test.write_text(et, encoding='utf-8')

    # A static+behavior contract regression for project isolation and single-board screens.
    regression = r'''
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=process.argv[2]||__dirname;
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const engine=fs.readFileSync(path.join(root,'SurveyQuant_v1.0.177_CAD_ENGINE.js'),'utf8');
const both=html+'\\n'+engine;
assert.match(html,/data-board-panel="source"/);
assert.match(html,/data-board-panel="target"/);
assert.match(html,/data-sq-board-tab="source"/);
assert.match(html,/data-sq-board-tab="target"/);
assert.match(engine,/function activateBoardPanel\(which\)/);
assert.match(engine,/state\.activeBoardSide!==which/);
assert.match(engine,/state\.picks=\[null,null,null,null\]/,'board change/exit must clear all four picks');
assert.match(engine,/root\.openProjectPage=function\(id/,'navigation away clears temporary board state');
assert.match(engine,/root\.addEventListener\('pagehide', cleanup\)/);
assert.match(engine,/root\.addEventListener\('beforeunload',cleanup\)/);
assert.match(html,/accept="\.pdf,application\/pdf"/);
assert.doesNotMatch(engine,/ImageTracer\.imagedataToSVG/,'PDF conversion must not trace pixels');
assert.match(engine,/paintImageXObject/,'raster PDF content must be detected');
assert.match(engine,/unsupportedFns/,'unsupported XObjects, clipping and alternate color spaces must fail closed');
assert.match(engine,/k<=64/,'PDF cubic curves must use higher-resolution CAD polylines');
assert.match(engine,/صور نقطية|صورة نقطية/);
assert.match(engine,/AC1015/);
console.log(JSON.stringify({singleBoardScreen:'PASS',independentPointSlots:'PASS',clearAllPicksOnChangeOrExit:'PASS',clearWhenNavigatingBetweenProjects:'PASS',pdfOnly:'PASS',noRasterTraceFallback:'PASS',R2000TrueColorAndLineweight:'PASS',result:'PASS'},null,2));
'''
    (kit / 'SurveyQuant_v1.0.187_REGRESSION_TEST.js').write_text(regression.strip()+'\n', encoding='utf-8')

    # PDF-only behavior test: vector PDF is converted, image-bearing PDF is rejected.
    pdf_only = r'''
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(process.argv[2]||__dirname);
const cad=require(path.join(root,'SurveyQuant_v1.0.177_CAD_ENGINE.js'));
const pdfjs=require(path.join(root,'pdfjs-v3.11.174.min.js'));
const worker=path.join(root,'pdf.worker.js');
pdfjs.GlobalWorkerOptions.workerSrc=worker;
async function readPdf(p){return pdfjs.getDocument({data:new Uint8Array(fs.readFileSync(p)),disableWorker:true,useSystemFonts:true,isEvalSupported:false}).promise;}
(async()=>{
 const vector=await readPdf(path.join(root,'V177_VECTOR_TEST.pdf'));
 try{
  const page=await vector.getPage(1),view=page.getViewport({scale:1});
  const paths=await cad.pdfOperatorPathsToCad(page,pdfjs,view),texts=await cad.pdfTextToCad(page,view);
  const dxf=cad.polylinesToDxf(paths,view.width,view.height,1,texts);
  fs.writeFileSync(path.join(root,'V187_VECTOR_PDF_TEST.dxf'),Buffer.from(dxf.bytes));
  const str=new TextDecoder('windows-1252').decode(dxf.bytes);
  assert.match(str,/AC1015/);assert.match(str,/LWPOLYLINE/);assert.match(str,/\n420\r?\n/);assert.match(str,/\n370\r?\n/);
  assert.doesNotMatch(str,/\nIMAGE(?:\r?\n|$)|\nIMAGEDEF(?:\r?\n|$)/);
  assert.ok(dxf.count>=paths.length&&dxf.vertices>=20);
 }finally{await vector.destroy();}
 const filled=await readPdf(path.join(root,'V187_FILLED_VECTOR_FIXTURE.pdf'));
 try{const page=await filled.getPage(1),view=page.getViewport({scale:1});const paths=await cad.pdfOperatorPathsToCad(page,pdfjs,view),texts=await cad.pdfTextToCad(page,view,20000,pdfjs);assert.ok(paths.some(p=>p.filled),'PDF filled areas must survive as fill geometry');const dxf=cad.polylinesToDxf(paths,view.width,view.height,1,texts),str=new TextDecoder('windows-1252').decode(dxf.bytes);fs.writeFileSync(path.join(root,'V187_FILLED_VECTOR_TEST.dxf'),Buffer.from(dxf.bytes));assert.match(str,/\nHATCH\r?\n/);assert.match(str,/\n420\r?\n/);assert.ok(dxf.hatchCount>=1);}
 finally{await filled.destroy();}
 const raster=await readPdf(path.join(root,'V187_RASTER_FIXTURE.pdf'));
 try{const page=await raster.getPage(1),view=page.getViewport({scale:1});await assert.rejects(()=>cad.pdfOperatorPathsToCad(page,pdfjs,view),/صور نقطية|صورة نقطية/);}
 finally{await raster.destroy();}
 console.log(JSON.stringify({vectorPdf:'editable DXF R2000 entities with TrueColor/lineweight',filledPdf:'solid HATCH entities retained',rasterPdf:'rejected without image output or raster tracing',result:'PASS'},null,2));
})().catch(e=>{console.error(e);process.exit(1)});
'''
    (kit / 'SurveyQuant_v1.0.187_PDF_ONLY_TEST.js').write_text(pdf_only.strip()+'\n', encoding='utf-8')

    # README accurately documents the scope and non-vector fail-closed behavior.
    readme = '''# SurveyQuant v1.0.187 | عزل جلسات التوجيه وPDF إلى DXF هندسي فقط\n\n- شاشة التوجيه تعرض لوحة واحدة فقط في كل مرة: غير الموجهة أو المرجعية. كل لوحة تحتفظ ببايتاتها وبصمتها وإحداثياتها منفصلة داخل الجلسة الحالية.\n- تغيير أي ملف يلغي نقاط التوجيه الأربع والتحويل السابق حتى لا تختلط نقاط من لوحتين/جلستين مختلفتين.\n- الرجوع أو فتح مشروع آخر أو مغادرة الصفحة ينهي الجلسة ويمسح اللوحتين والنقاط والمعلومات المؤقتة. لا يتم حفظ اللوحات أو النقاط في سجل دائم.\n- مشروع PDF يقبل PDF فقط وينتج DXF واحدًا فقط. لا يصدّر صورة أو ZIP أو ملفًا جانبيًا، ولا يضع IMAGE/IMAGEDEF داخل DXF.\n- المخرجات تستخدم DXF R2000 / AC1015 بكيانات LWPOLYLINE وTEXT، وتحفظ ألوان المسارات بصيغة TrueColor (420) وسُمك الخط بصيغة Lineweight (370).\n- التعبئات المتجهية المغلقة تتحول إلى كيانات HATCH صلبة بلون TrueColor. المنحنيات تتحول إلى LWPOLYLINE بتقسيم 64 خطوة لكل منحنى. صفحات الصور النقطية والتدرجات والقص وForm XObjects ومساحات الألوان/أنماط الخط غير المدعومة تتوقف برسالة واضحة بدل إسقاط عناصر بصمت أو إخراج ملف ناقص.\n- اختبارات المصدر تشمل PDF متجهي ومملوء تجريبي، رفض PDF يحتوي صورة، تدقيق ezdxf، التوجيه بين لوحتين مستقلتين، وقواعد الجلسة. تدقيق الملفات التجريبية لا يثبت فتح كل PDF معماري أو AutoCAD على الهاتف؛ يلزم اختبار ملفك الأصلي بعد البناء.\n'''
    (kit / 'README_V187_AR.md').write_text(readme, encoding='utf-8')
    print('PASS V187 patch: applied to HTML and engine, PDF-only R2000 writer, isolated orientation tabs and session cleanup.')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python3 SurveyQuant_v1.0.187_PATCH.py <source-kit-directory>')
    apply(Path(sys.argv[1]).resolve())
