#!/usr/bin/env python3
"""Run V148 regression suites against the V150 HTML with only version/UI expectations rebased."""
from __future__ import annotations
import argparse, pathlib, re, subprocess, sys

TESTS = [
    'SurveyQuant_v1.0.148_REGRESSION_TEST.js',
    'SurveyQuant_v1.0.148_STABILITY_TEST.js',
    'SurveyQuant_v1.0.148_ORIENTATION_PRECISION_TEST.js',
    'SurveyQuant_v1.0.148_ALIGNMENT_SAFETY_TEST.js',
    'SurveyQuant_v1.0.148_MLEADER_ALIGNMENT_TEST.js',
    'SurveyQuant_v1.0.148_3D_OCS_AXIS_TEST.js',
    'SurveyQuant_v1.0.148_ALIGNMENT_DXF_DWG_REGRESSION_TEST.js',
    'SurveyQuant_v1.0.130_DWG_AXIS_MULTISELECT_TEST.js',
]

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-dir',type=pathlib.Path,required=True)
    ap.add_argument('--html',type=pathlib.Path,required=True)
    ap.add_argument('--reference-html',type=pathlib.Path,required=True)
    ap.add_argument('--test-dir',type=pathlib.Path,required=True)
    args=ap.parse_args()
    for p in (args.html,args.reference_html):
        if not p.is_file() or not p.stat().st_size: raise SystemExit(f'ERROR: required HTML missing or empty: {p}')
    args.test_dir.mkdir(parents=True,exist_ok=True)
    for name in TESTS:
        src=args.source_dir/name
        if not src.is_file() or not src.stat().st_size:
            raise SystemExit(f'ERROR: regression test missing from V148 base source: {src}')
        body=src.read_text(encoding='utf-8')
        body=body.replace('const SQ_APP_VERSION_CODE = 148;','const SQ_APP_VERSION_CODE = 150;')
        body=body.replace('surveyquant-v148-fresh-board-session','surveyquant-v150-fresh-board-session')
        body=body.replace('height:44vh;min-height:250px;max-height:500px','height:34vh;min-height:200px;max-height:360px')
        body=body.replace("assert(html.includes('خطأ النقطتين '), 'two-point result must show numeric fit error');", "assert(html.includes('P1 بعد التحويل=') && html.includes('P2 بعد التحويل='), 'two-point result must show transformed source points and mapping diagnostics');")
        body=body.replace("console.log('PASS V148: viewport is smaller; both canvas limits are 44vh/250-500px.');", "console.log('PASS V150: both orientation canvases use 34vh and 200-360px limits.');")
        out=args.test_dir/name
        out.write_text(body,encoding='utf-8')
        subprocess.run(['node','--check',str(out)],check=True)
        cmd=['node',str(out),str(args.html)]
        if name=='SurveyQuant_v1.0.148_ORIENTATION_PRECISION_TEST.js': cmd.append(str(args.reference_html))
        print(f'=== RUN {name} ===',flush=True)
        subprocess.run(cmd,check=True)
    print(f'PASS V150 regression runner: {len(TESTS)} legacy suites plus their JavaScript syntax checks passed.',flush=True)
    return 0
if __name__=='__main__':
    try: raise SystemExit(main())
    except subprocess.CalledProcessError as e: raise SystemExit(e.returncode or 1)
