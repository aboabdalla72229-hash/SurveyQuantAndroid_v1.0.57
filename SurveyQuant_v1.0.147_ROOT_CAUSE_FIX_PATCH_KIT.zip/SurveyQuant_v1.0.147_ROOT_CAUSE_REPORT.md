# V147 root-cause report

## 1) Orientation streaks

The prior transform treated all coordinate groups inside HATCH as if they represented world-space points. DXF HATCH is heterogeneous: the header elevation/origin, edge-path endpoints, ellipse major-axis vectors, spline fit/control/tangent data, seed points, and hatch-pattern base/offset values do not share a single semantic. Translating the header or pattern vectors as global points, or transforming a line start but not its end, creates visible long diagonal streaks. V147 branches on edge type, transforms both ends and applicable geometric data, keeps vectors translation-free, and transforms the pattern/seed data under their own rules.

The prior world-vector transform rotated X/Y but applied scale only to Z. V147 scales the rotated X/Y values as well.

## 2) Concrete boundary not found

When the primary DXF parser failed, the fallback represented some polyline geometry as rendered segments and discarded the source polyline's closed flag and vertex sequence. Concrete boundary selection then saw no closed Polyline. V147 preserves closed raw `LWPOLYLINE`/`POLYLINE` records, can recover a simple closed loop from connected LINE edges on the selected layer, normalizes layer names, and deduplicates identical outlines.

Some limits are caused by CAD structure rather than UI: an outline may be defined inside an `INSERT` block. V147 resolves readable closed polylines in blocks through base point, insert position, rotation, XY scale and layer inheritance.

## 3) Validation strategy

The test suite includes a mixed-edge HATCH byte-transform fixture, a 24000-entity DXF, a concrete rectangle assembled from four LINEs, a rotated/scaled INSERT-block rectangle, nested axis labels, ordinary 3D/OCS, the old V130 DWG/orientation suite, and a MULTILEADER oracle comparison with ezdxf 1.4.4.

## Scope

These results validate the source logic against explicit fixtures. They do not prove the exact drawing in the screenshots is correct because the original DWG/DXF was not attached, and they do not prove a signed production APK exists until the GitHub Actions build completes.
