from pathlib import Path
from playwright.sync_api import sync_playwright
import shutil, json, base64
import ezdxf, ezdxf.recover

ROOT = Path(__file__).resolve().parent
HTML = (ROOT / 'index.html').read_text(encoding='utf-8')
SOURCE = (ROOT / 'source_v184.dxf').read_bytes()
TARGET = (ROOT / 'target_v184.dxf').read_bytes()
ALT = (ROOT / 'target_reset_v184.dxf').read_bytes()

with sync_playwright() as p:
    chrome = shutil.which('chromium') or shutil.which('chromium-browser')
    opts = {'headless': True, 'args': ['--no-sandbox', '--disable-dev-shm-usage']}
    if chrome:
        opts['executable_path'] = chrome
    browser = p.chromium.launch(**opts)
    page = browser.new_page(viewport={'width': 430, 'height': 900})
    page_errors = []
    page.on('pageerror', lambda e: page_errors.append(str(e)))
    page.set_content(HTML, wait_until='domcontentloaded', timeout=60000)
    page.evaluate("window.__saved={};window.Android={saveFile:(n,m,b)=>{window.__saved[n]={mime:m,base64:b};return 'Downloads/'+n;},notifyDownload:()=>{}}")

    def assert_blank(label):
        values = page.evaluate("""() => ({
          source: document.querySelector('#sq162-source-canvas')._sqMap,
          target: document.querySelector('#sq162-target-canvas')._sqMap,
          oriented: document.querySelector('#sq162-oriented-canvas')._sqMap,
          sourceInfo: document.querySelector('#sq162-source-info').textContent,
          targetInfo: document.querySelector('#sq162-target-info').textContent,
          orientedInfo: document.querySelector('#sq162-oriented-info').textContent,
          name: document.querySelector('#sq162-oriented-name').value,
          details: document.querySelector('#sq162-transform-details').textContent
        })""")
        assert values['source'] is None and values['target'] is None and values['oriented'] is None, (label, values)
        assert 'لم يتم اختيار ملف بعد' in values['sourceInfo'], (label, values['sourceInfo'])
        assert 'لم يتم اختيار ملف بعد' in values['targetInfo'], (label, values['targetInfo'])
        assert values['name'] == '', (label, values['name'])
        return values

    def click_picker(which):
        # Dispatch the UI click handler without opening the operating-system file dialog.
        page.locator(f'#sq162-{which}-file').evaluate("e=>e.dispatchEvent(new MouseEvent('click',{bubbles:true}))")

    def set_file(which, name, content):
        click_picker(which)
        page.locator(f'#sq162-{which}-file').set_input_files({
            'name': name,
            'mimeType': 'application/dxf',
            'buffer': content,
        })
        page.wait_for_function(
            f"document.querySelector('#sq162-{which}-info').textContent.includes('بصمة CAD')",
            timeout=30000,
        )

    def map_data(which):
        return page.locator(f'#sq162-{which}-canvas').evaluate("""c => c._sqMap && ({
          which:c._sqMap.which, sessionId:c._sqMap.sessionId,
          file:c._sqMap.boardFileName, fp:c._sqMap.boardFingerprint,
          cad:c._sqMap.cadFingerprint,
          bounds:[c._sqMap.geom.minX,c._sqMap.geom.minY,c._sqMap.geom.maxX,c._sqMap.geom.maxY]
        })""")

    def pick(slot, canvas_id, xy):
        page.locator(f'#sq162-pick-{slot}').click()
        pos = page.locator(f'#{canvas_id}').evaluate("""(c,xy)=>{
          const m=c._sqMap, p=m.pt({x:xy[0],y:xy[1]}), r=c.getBoundingClientRect();
          return {x:r.left+p.x,y:r.top+p.y};
        }""", xy)
        page.mouse.click(pos['x'], pos['y'])
        page.wait_for_timeout(100)

    # Enter the project and require an empty first session.
    page.locator('#sq176-home-orientation-project').click()
    page.wait_for_timeout(250)
    assert_blank('initial project entry')

    # The first chosen board must populate only its own screen.
    set_file('source', 'source_v184.dxf', SOURCE)
    source_map = map_data('source')
    target_map = map_data('target')
    assert source_map and source_map['bounds'] == [0, 0, 10, 5], source_map
    assert source_map['which'] == 'source' and target_map is None, (source_map, target_map)

    # Same filename, different bytes: the target must use its own file bytes and coordinates.
    set_file('target', 'source_v184.dxf', TARGET)
    target_map = map_data('target')
    source_map = map_data('source')
    assert target_map and target_map['which'] == 'target', target_map
    assert target_map['bounds'] == [90, 100, 100, 120], target_map
    assert source_map and source_map['bounds'] == [0, 0, 10, 5], source_map
    assert target_map['cad'] != source_map['cad'], (source_map, target_map)
    assert target_map['sessionId'] == source_map['sessionId'], (source_map, target_map)

    # Fit UI is now one operation only, and it always uses the full board extents.
    fit_buttons = page.locator('[data-sq-zoom="fit"]')
    assert fit_buttons.count() == 3
    assert all('ملاءمة' in fit_buttons.nth(i).inner_text() for i in range(3))
    assert page.locator('[data-sq-zoom="axes"]').count() == 0
    assert 'احتواء المحاور' not in HTML

    # Pick two actual source coordinates and two actual target coordinates.
    page.locator('[data-sq-snap="source"]').select_option('endpoint')
    page.locator('[data-sq-snap="target"]').select_option('endpoint')
    pick(0, 'sq162-source-canvas', [0, 0])
    pick(1, 'sq162-source-canvas', [10, 0])
    pick(2, 'sq162-target-canvas', [100, 100])
    pick(3, 'sq162-target-canvas', [100, 120])
    details = page.locator('#sq162-transform-details').inner_text()
    assert 'X=0' in details and 'X=10' in details and 'X=100' in details and 'Y=120' in details and 'المرجع 1' in details and 'المرجع 2' in details, details
    assert 'التقاط الشاشة=' in details and 'Snap=endpoint/endpoint' in details, details
    assert page.locator('#sq162-do-align').is_enabled()
    page.locator('#sq162-do-align').click()
    page.wait_for_timeout(300)
    oriented = page.locator('#sq162-oriented-canvas').evaluate("c=>c._sqMap&&({which:c._sqMap.which,bounds:[c._sqMap.geom.minX,c._sqMap.geom.minY,c._sqMap.geom.maxX,c._sqMap.geom.maxY],segmentCount:c._sqMap.geom.segments.length,texts:c._sqMap.geom.texts.map(t=>t.text),cache:c._sqMap.geom._sqPathCache})")
    assert oriented and oriented['which'] == 'oriented' and oriented['bounds'] == [90, 100, 100, 120], oriented
    cache_identity = page.evaluate("() => { const s=document.querySelector('#sq162-source-canvas')._sqMap.geom._sqPathCache, o=document.querySelector('#sq162-oriented-canvas')._sqMap.geom._sqPathCache; return {sameArray:s===o,samePath:!!(s&&o&&s[0]&&o[0]&&s[0].path===o[0].path),sourceSegments:document.querySelector('#sq162-source-canvas')._sqMap.geom.segments.length,orientedSegments:document.querySelector('#sq162-oriented-canvas')._sqMap.geom.segments.length}; }")
    assert not cache_identity['sameArray'] and not cache_identity['samePath'], cache_identity
    assert oriented['segmentCount'] == cache_identity['sourceSegments'] == cache_identity['orientedSegments'], cache_identity
    transformed_text_check = page.evaluate("() => {const api=window.SurveyQuantCAD184,s=document.querySelector('#sq162-source-canvas')._sqMap.geom,o=document.querySelector('#sq162-oriented-canvas')._sqMap.geom,t=api.solve({x:0,y:0},{x:10,y:0},{x:100,y:100},{x:100,y:120});return {source:s.texts.length,oriented:o.texts.length,pairs:s.texts.slice(0,10).map((v,i)=>({expected:t.apply(v.position),actual:o.texts[i]?.position})).filter(v=>v.actual)};}")
    assert transformed_text_check['source'] == transformed_text_check['oriented'], transformed_text_check
    for pair in transformed_text_check['pairs']:
        assert abs(pair['expected']['x']-pair['actual']['x'])<1e-8 and abs(pair['expected']['y']-pair['actual']['y'])<1e-8, pair
    # Verify orientation transforms every OLE-frame corner and leaves the original geometry untouched.
    frame_check = page.evaluate("() => { const api=window.SurveyQuantCAD184, g={segments:[{a:{x:0,y:0},b:{x:10,y:0}}],points:[],texts:[{position:{x:0,y:0},text:'A',height:1}],curves:[],oleFrames:[{left:0,right:10,bottom:0,top:5}],minX:0,minY:0,maxX:10,maxY:5};const t=api.solve({x:0,y:0},{x:10,y:0},{x:100,y:100},{x:100,y:120});const out=api.transformGeometryView(g,t);return {sourceHasCache:!!g._sqPathCache,corners:out.oleFrames[0].corners,bounds:[out.minX,out.minY,out.maxX,out.maxY]}; }")
    assert len(frame_check['corners']) == 4 and frame_check['bounds'] == [90,100,100,120], frame_check
    assert page.locator('#sq162-save-oriented').is_enabled()
    page.locator('#sq162-save-oriented').click()
    page.wait_for_function('Object.keys(window.__saved).length>0', timeout=30000)
    saved = page.evaluate('window.__saved')
    out_name = list(saved)[0]
    out_path = ROOT / 'V185_ORIENTED_RESULT.dxf'
    out_path.write_bytes(base64.b64decode(saved[out_name]['base64']))
    doc, _ = ezdxf.recover.readfile(out_path)
    audit = doc.audit()
    assert doc.dxfversion == 'AC1018' and len(doc.modelspace()) > 0 and not audit.errors and not audit.fixes

    # A new file selection after a complete pair MUST clear both screens before loading the new file.
    click_picker('target')
    blank_between = assert_blank('complete pair replaced')
    page.locator('#sq162-target-file').set_input_files({
        'name': 'source_v184.dxf', 'mimeType': 'application/dxf', 'buffer': ALT
    })
    page.wait_for_function("document.querySelector('#sq162-target-info').textContent.includes('بصمة CAD')", timeout=30000)
    target_only = map_data('target')
    assert target_only and target_only['bounds'] == [500, 600, 510, 610], target_only
    assert map_data('source') is None and map_data('oriented') is None
    assert 'لم يتم اختيار ملف بعد' in page.locator('#sq162-source-info').inner_text()
    assert page.locator('#sq162-pick-0').is_disabled() and page.locator('#sq162-pick-2').is_disabled(), 'reference picks remain locked until source pair is selected'

    # Loading the missing source in the same new session keeps only the just-selected target.
    set_file('source', 'source_v184.dxf', SOURCE)
    source_again = map_data('source')
    target_again = map_data('target')
    assert source_again and source_again['bounds'] == [0, 0, 10, 5], source_again
    assert target_again and target_again['bounds'] == [500, 600, 510, 610], target_again
    assert source_again['sessionId'] == target_again['sessionId']
    assert page.locator('#sq162-pick-0').is_enabled() and page.locator('#sq162-pick-2').is_disabled()

    # Leaving and reopening the project must never restore either file or any picked coordinates.
    page.locator('.project-back').click()
    page.wait_for_timeout(200)
    page.locator('#sq176-home-orientation-project').click()
    page.wait_for_timeout(250)
    reentry = assert_blank('project reopen')

    # Dedicated axis-label fixture: ensure short labels and layer-based axis names
    # survive parsing and the orientation-view transform (not merely DXF saving).
    axis_doc = ezdxf.new('R2000')
    axis_doc.layers.new('AXIS', dxfattribs={'color': 3})
    axis_msp = axis_doc.modelspace()
    axis_msp.add_line((0, 0), (20, 0), dxfattribs={'layer': 'AXIS'})
    axis_msp.add_line((0, 0), (0, 20), dxfattribs={'layer': 'AXIS'})
    axis_msp.add_xline((10, 0), (0, 1), dxfattribs={'layer': 'AXIS'})
    axis_msp.add_text('A-A', dxfattribs={'insert': (2, 1), 'height': 1.2, 'layer': 'AXIS'})
    axis_msp.add_text('B-B', dxfattribs={'insert': (1, 18), 'height': 1.2, 'layer': 'AXIS'})
    axis_msp.add_text('1', dxfattribs={'insert': (10, 1), 'height': 1.2, 'layer': 'AXIS'})
    axis_msp.add_text(r'GRID\U+0031', dxfattribs={'insert': (15, 10), 'height': 1.2, 'layer': 'AXIS'})
    axis_file = ROOT / 'V185_AXIS_LABEL_FIXTURE.dxf'
    axis_doc.saveas(axis_file)
    set_file('source', axis_file.name, axis_file.read_bytes())
    axis_view = page.locator('#sq162-source-canvas').evaluate("c=>({texts:c._sqMap.geom.texts.map(t=>t.text),construction:c._sqMap.geom.segments.filter(s=>s.isConstruction).length,cache:!!c._sqMap.geom._sqPathCache})")
    assert {'A-A','B-B','1','GRID1'}.issubset(set(axis_view['texts'])), axis_view
    capped_parse = page.locator('#sq162-source-file').evaluate("async input=>{const api=window.SurveyQuantCAD184,b=new Uint8Array(await input.files[0].arrayBuffer()),g=api.readGeometry(b,1);return {texts:g.texts.map(t=>t.text),segments:g.segments.length};}")
    assert {'A-A','B-B','1','GRID1'}.issubset(set(capped_parse['texts'])), capped_parse
    assert axis_view['construction'] >= 1, axis_view
    transformed_axes = page.evaluate("""() => {const api=window.SurveyQuantCAD184,g=document.querySelector('#sq162-source-canvas')._sqMap.geom,t=api.solve({x:0,y:0},{x:20,y:0},{x:100,y:200},{x:100,y:240}),o=api.transformGeometryView(g,t);return {source:g.texts.map(v=>v.text),output:o.texts.map(v=>v.text),sourceConstruction:g.segments.filter(v=>v.isConstruction).map(v=>v.a),outputConstruction:o.segments.filter(v=>v.isConstruction).map(v=>v.a)};}""")
    assert transformed_axes['source'] == transformed_axes['output'] and len(transformed_axes['outputConstruction']) >= 1, transformed_axes
    assert transformed_axes['outputConstruction'][0] != transformed_axes['sourceConstruction'][0], transformed_axes

    report = {
      'result': 'PASS V185 clean session isolation, strict board provenance, full-board fit, R2004 oriented DXF',
      'same_filename_different_bytes': {'source_bounds': source_map['bounds'], 'target_bounds': target_map['bounds'], 'different_cad_fingerprints': target_map['cad'] != source_map['cad']},
      'first_pair_session_id': source_map['sessionId'],
      'orientation': {'oriented_bounds': oriented['bounds'], 'path_cache_isolated': not cache_identity['sameArray'] and not cache_identity['samePath'], 'OLE_frame_corners_transformed': len(frame_check['corners']) == 4, 'text_positions_transformed': transformed_text_check['source'], 'saved_file': out_path.name, 'entities': len(doc.modelspace()), 'dxf_version': doc.dxfversion, 'audit_errors': len(audit.errors), 'audit_fixes': len(audit.fixes)},
      'complete_pair_replacement': {'both_screens_cleared_before_new_target': blank_between['source'] is None and blank_between['target'] is None, 'target_only_after_reload': target_only['bounds'], 'source_screen_empty': True},
      'second_pair': {'source_bounds': source_again['bounds'], 'target_bounds': target_again['bounds'], 'session_id': source_again['sessionId']},
      'project_reopen': {'both_canvases_empty': reentry['source'] is None and reentry['target'] is None, 'output_name_empty': reentry['name'] == ''},
      'axis_fit_controls': {'fit_buttons': fit_buttons.count(), 'axis_buttons': 0, 'fit_label': 'ملاءمة'},
      'axis_labels': {'parsed': axis_view['texts'], 'parser_continued_after_one_segment_cap': capped_parse['texts'], 'construction_entities': axis_view['construction'], 'names_transformed': True},
      'page_errors': page_errors[:10],
    }
    (ROOT / 'V185_ORIENTATION_TEST_LOG.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    browser.close()
