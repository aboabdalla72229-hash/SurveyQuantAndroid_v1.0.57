# SurveyQuant V1.0.199 - Single Canvas / Orientation / Point Data Addendum

## Build identity
- Deliverable version: **1.0.199** (APK versionName 1.0.199, versionCode 199).
- Compatibility baseline: the known V1.0.177 implementation path, built from V162 artifact run `40919113310`, then applying the V176 and V177 fix-kit stages before this addendum.
- This package is named V199. The JavaScript module and integration/test script filenames retain their `v1.0.177` names because the module targets the V177 CAD API and its integration markers are intentionally stable.

## Included functions
- Separate one-canvas orientation project (source and reference boards).
- Point data export helpers (CSV, TXT, SDR, Excel, PDF, annotation DXF).
- Select single CAD entity, select by window, select similar, delete selected in the current editing session, and restore deleted entities.
- No localStorage persistence for project/session state.

## Important limitations
- Delete/restore is currently an in-session editing/display operation. This addendum does **not** claim permanent removal of deleted source entities from the exported DXF. The DXF export is deliberately blocked when unsupported deleted-entity state exists rather than silently outputting the unmodified board.
- This is a source patch package, not a built APK. GitHub Actions must successfully complete the build and signing workflow.
- Automated synthetic checks are not a substitute for testing the exact DWG/DXF/PDF files and the resulting APK on the Android handset.
- The addendum does not guarantee complete rendering of every custom CAD entity, nor exact ToUnicode/color/lineweight reconstruction for every PDF.
