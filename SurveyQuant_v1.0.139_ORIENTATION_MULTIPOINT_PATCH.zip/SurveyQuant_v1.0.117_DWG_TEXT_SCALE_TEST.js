'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const [modulePath, htmlPath, bridgePath] = process.argv.slice(2);
assert(modulePath && htmlPath && bridgePath,
  'usage: node test.js REFERENCE_MODULE INDEX_PATH DWG_BRIDGE');

const moduleText = fs.readFileSync(modulePath, 'utf8');
const html = fs.readFileSync(htmlPath, 'utf8');
const bridge = fs.readFileSync(bridgePath, 'utf8');
const formula = 'size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale*Math.max(0.001,Number(v.zoom)||1))';
const oldFixedFormula = 'size=Math.max(5.5,Math.min(15,Math.abs(Number(t.height)||2.5)*m.scale));';

assert(moduleText.includes(formula), 'reference renderer is missing proportional text scaling tied to board zoom');
assert(html.includes(formula), 'integrated app HTML is missing proportional text scaling tied to board zoom');
assert(!moduleText.includes(oldFixedFormula), 'old fixed 5.5-15px font clamp remains in renderer');
assert(!html.includes(oldFixedFormula), 'old fixed 5.5-15px font clamp remains in HTML');
assert(moduleText.includes('function universalTransformBytes(input,t)'), 'byte-preserving CAD transform missing from reference module');
assert(html.includes('function universalTransformBytes(input,t)'), 'byte-preserving CAD transform missing from integrated HTML');
assert(html.includes('id="sq-v117-universal-dwg-bridge"'), 'V117 DWG bridge is not embedded');
assert.equal((html.match(/id="sq-v117-universal-dwg-bridge"/g) || []).length, 1,
  'integrated HTML must have exactly one V117 bridge');

for (const token of [
  'window.sqOriConvertTargetToDxf', 'ACCEPT_TYPES', 'MutationObserver',
  'convertList', 'new DataTransfer()',
]) assert(bridge.includes(token), 'DWG bridge missing: ' + token);
assert.equal(bridge.split('/\\.dwg$/i').length - 1, 4, 'expected four valid .dwg matchers');
assert(!bridge.includes('\\\\.dwg'), 'bad double-escaped DWG matcher remains');

const setter = moduleText.match(/function setZoom\(side,value\)\{[^}]*\}/);
assert(setter, 'board zoom setter not found');
assert(!/v\.bytes\s*=|v\.drawing\.[\w$]+\s*=/.test(setter[0]),
  'preview zoom must not mutate the original DXF bytes or CAD entity model');
console.log('PASS V117: proportional CAD text scale, no fixed-font clamp, DWG acceptance, converter bridge, and zoom-preservation guards.');
