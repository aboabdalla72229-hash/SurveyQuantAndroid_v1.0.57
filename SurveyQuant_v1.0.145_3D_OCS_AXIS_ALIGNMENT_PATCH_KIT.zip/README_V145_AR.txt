SurveyQuant V1.0.145 - 3D / OCS / Axis Label Alignment

What changed
- Ordinary 3D DXF coordinates and non-default OCS entities no longer trigger the generic OCS export veto.
- Coordinates for supported OCS entities are transformed OCS -> WCS -> aligned WCS -> new OCS basis, and extrusion normals/angle metadata follow the new basis.
- The same uniform scale is applied to XYZ about the lowest recovered WCS Z plane; the lowest plane stays anchored and all-zero 2D drawings remain at Z=0.
- Restores concise axis-bubble names (TEXT/MTEXT/ATTRIB/ATTDEF), including labels inside INSERT blocks, in orientation preview.
- The orientation screen's outdated warning was updated; it no longer says ordinary non-default OCS prevents export.
- Layers, handles and XData on supported DXF entities are preserved by byte-range patching except transformed coordinate values and necessary inserted Z values.

Automatic tests included
- Two-point transformation and V130 orientation/DWG regression.
- 3D LINE, nonzero Z, tilted OCS CIRCLE/TEXT, LWPOLYLINE elevation, and nested axis-label preview.
- MULTILEADER MText/block geometry, leader lines, vectors, matrix, layers and XData.
- Real MULTILEADER transform checked against ezdxf 1.4.4 reference.
- Inline JavaScript syntax and Android APK HTML/manifest packaging against the real V144 APK artifact.

Build on GitHub
1. Upload build-v145-3d-ocs-axis-alignment.yml to .github/workflows/.
2. Upload SurveyQuant_v1.0.145_3D_OCS_AXIS_ALIGNMENT_PATCH_KIT.zip to the repository root.
3. Open GitHub Actions and run "Build SurveyQuant v1.0.145 - 3D OCS + Axis Labels". Default input run IDs refer to the successful V144 and V130 artifacts.
4. On a successful run, download artifact SurveyQuant-v1.0.145-3D-OCS-AXIS-ALIGNMENT.

Important scope
Two XY point pairs specify rotation about WCS Z, translation, and uniform scale. They do not define an independent vertical datum or 3D tilt. Opaque ACAD_PROXY/Civil 3D/Solids whose actual geometry is not exposed in DXF are still guarded instead of silently creating a partial/corrupt file; those require a native CAD writer. This build has not been published by GitHub from this chat, and the full app must be tried with the actual customer DWG before production use.
