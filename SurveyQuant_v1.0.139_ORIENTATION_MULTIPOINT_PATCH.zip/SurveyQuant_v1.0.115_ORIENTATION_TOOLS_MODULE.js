/* SurveyQuant v1.0.115: additional OSNAP modes, enlarged zoom, and labelled-axis matching. */
(function(){
 'use strict';
 const el=id=>document.getElementById(id);
 function tell(s,bad=false){const n=el('sq110Status');if(n){n.textContent=s;n.style.display='block';n.style.color=bad?'#fecaca':'#d1fae5';n.style.borderColor=bad?'#b91c1c':'#15803d';}}
 async function readAxes(){
  const api=window.__sqOrientation111API,match=window.__sqOriAxisAutoTest;
  const tf=el('sq110TargetFile')?.files?.[0],rf=el('sq110ReferenceFile')?.files?.[0];
  if(!api?.state||!tf||!rf){tell('اختر اللوحة غير الموجهة واللوحة المرجعية أولًا، ثم اضغط قراءة المحاور.',true);return;}
  if(typeof window.parseFile!=='function'||typeof match?.matchIntersections!=='function'){tell('قارئ المحاور غير جاهز. استخدم OSNAP اليدوي من خيارات الالتقاط.',true);return;}
  try{
   tell('جارٍ قراءة المحاور وتسميات التقاطعات في اللوحتين…');
   const [targetModel,referenceModel]=await Promise.all([window.parseFile(tf),window.parseFile(rf)]);
   const found=match.matchIntersections(referenceModel,targetModel);
   if(!found.best){tell('لم أجد تقاطعين مشتركيْن بالمسميات تلقائيًا. اختر وضع «تقاطع فقط» واضغط التقاطعين يدويًا، أو استخدم ID Point. المكتشف: '+found.src.intersections.size+' في الهدف و'+found.ref.intersections.size+' في المرجع.',true);return;}
   const a=found.best.first,b=found.best.second;
   api.state.targetPoints=[{x:a.source.x,y:a.source.y,kind:'تقاطع محور تلقائي '+a.key},{x:b.source.x,y:b.source.y,kind:'تقاطع محور تلقائي '+b.key}];
   api.state.referencePoints=[{x:a.reference.x,y:a.reference.y,kind:'تقاطع محور تلقائي '+a.key},{x:b.reference.x,y:b.reference.y,kind:'تقاطع محور تلقائي '+b.key}];
   api.state.active={target:0,reference:0};api.fillReadouts();
   if(api.state.views.target)api.draw(api.state.views.target);if(api.state.views.reference)api.draw(api.state.views.reference);
   tell('تمت مطابقة التقاطعين تلقائيًا: '+a.key+' و'+b.key+'. راجع النقطتين 1 و2 ثم اضغط توجيه وإخراج.');
  }catch(e){tell('تعذر التحليل التلقائي: '+(e?.message||String(e))+'. ما زال بإمكانك استخدام التقاطعات اليدوية وID Point.',true);}
 }
 function install(){
  const api=window.__sqOrientation111API;if(!api?.state)return;
  const step=el('sq110Step1');if(!step||el('sq110ReadAxesBtn'))return;
  const bar=step.parentElement;if(!bar)return;
  const b=document.createElement('button');b.id='sq110ReadAxesBtn';b.type='button';b.className='sqori-run';b.textContent='🧭 قراءة محاور اللوحتين تلقائيًا';b.style.cssText='display:block;width:100%;margin:8px 0';b.addEventListener('click',readAxes);bar.insertAdjacentElement('afterend',b);
 }
 window.__sqOrientation115Tools={VERSION:'1.0.115',readAxes,install};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
})();
