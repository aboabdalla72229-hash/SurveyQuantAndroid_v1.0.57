'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const htmlPath = process.argv[2];
assert(htmlPath, 'Usage: node SurveyQuant_v1.0.144_ALIGNMENT_SAFETY_TEST.js <V144-index.html>');
const html = fs.readFileSync(htmlPath, 'utf8');
function scriptBody(text, id) {
  const re = new RegExp(`<script\\b(?=[^>]*\\bid=["']${id}["'])[^>]*>([\\s\\S]*?)<\\/script\\s*>`, 'ig');
  const hits = [...text.matchAll(re)];
  assert.equal(hits.length, 1, `exactly one script ${id} must exist`);
  return hits[0][1];
}
const boardBody = scriptBody(html, 'sq-orientation-reference-board-module');
const manualBody = scriptBody(html, 'sq-orientation-manual-points-module');
assert(html.includes('alignmentPreview={source:sv.drawing,transform:t}'), 'review should paint a real transformed source-board overlay');
assert(html.includes('const isPaper=rec=>rec.pairs.some(p=>p.code===67&&Number(p.value)===1)||rec.pairs.some(p=>p.code===410&&String(p.value||\'\').trim().toUpperCase()!==\'MODEL\');'), 'writer should use group 67 and layout group 410 to distinguish paper/model space');
assert(html.includes('const isPaperRec=rec=>'), 'preview should use the same space filter as writer');
assert(html.includes('validateAlignmentBounds'), 'full-board extent/negative-coordinate guard should be active');

const window = { __sqOrientTest: {} };
const document = {
  readyState: 'loading', addEventListener() {}, getElementById() { return null; },
  querySelector() { return null; }, querySelectorAll() { return []; },
  createElement() { return { style: {}, appendChild() {}, remove() {}, click() {} }; },
  head: { appendChild() {} }, body: { appendChild() {}, classList: { add() {}, remove() {} } }
};
const context = { window, document, console, Uint8Array, ArrayBuffer, Map, Set, Math, Number, String, Object,
  RegExp, Error, Promise, Blob: global.Blob, URL: global.URL, TextEncoder, TextDecoder,
  performance: { now: () => 0 }, setTimeout, clearTimeout };
window.window = window; window.document = document;
vm.createContext(context);
vm.runInContext(boardBody, context, { timeout: 5000 });
const api = window.__sqOrientation110API;
assert(api && typeof api.validateAlignmentBounds === 'function', 'deterministic alignment safety API must load');

const manualWindow = { __sqOrientTest: {} };
const manualContext = { window: manualWindow, document, console, Uint8Array, ArrayBuffer, Map, Set, Math, Number, String, Object,
  RegExp, Error, Promise, Blob: global.Blob, URL: global.URL, TextEncoder, TextDecoder,
  performance: { now: () => 0 }, setTimeout, clearTimeout };
manualWindow.window = manualWindow; manualWindow.document = document;
vm.createContext(manualContext);
vm.runInContext(manualBody, manualContext, { timeout: 5000 });
assert(manualWindow.__sqManualOrientation109?.parseDrawing, 'model/paper-aware parser must load');
window.__sqManualOrientation109 = manualWindow.__sqManualOrientation109;

// A valid local transformation should map the full bounds into the reference bounds.
const transform = api.solve({ x: 0, y: 0 }, { x: 100, y: 0 }, { x: 1000, y: 2000 }, { x: 1000, y: 2100 });
const fit = api.validateAlignmentBounds(
  { minX: 0, minY: 0, maxX: 100, maxY: 100 },
  { minX: 900, minY: 1900, maxX: 1100, maxY: 2200 },
  transform
);
assert(fit.overlapRatio > 0.1, 'good full-board alignment should report overlap');
assert(Number.isFinite(fit.relativeExtent), 'good alignment should return a finite extent ratio');

// Survey-sized Easting/Northing values must retain sub-millimetre fit accuracy, and a valid
// translation from a large source origin to a smaller reference origin must not be rejected.
const surveyA={x:576761.4460,y:858279.3570},surveyB={x:576771.4460,y:858279.3570};
const surveyRefA={x:1040.960000,y:1098.298000},surveyRefB={x:1040.960000,y:1110.798000};
const surveyTransform=api.solve(surveyA,surveyB,surveyRefA,surveyRefB);
for(const [source,reference] of [[surveyA,surveyRefA],[surveyB,surveyRefB]]){
  const q=surveyTransform.point(source.x,source.y);
  assert(Math.hypot(q.x-reference.x,q.y-reference.y)<1e-7,'survey coordinate magnitude must not introduce material two-point fit error');
}
const surveyFit=api.validateAlignmentBounds(
  {minX:576750,minY:858250,maxX:576800,maxY:858300},
  {minX:1000,minY:1050,maxX:1080,maxY:1160},
  surveyTransform
);
assert(surveyFit.overlapRatio>0.1,'valid source and reference boards can have very different origins while still aligning correctly');

// Same size but wildly wrong translation must fail, even when the two selected points alone are mathematically exact.
const remote = api.solve({ x: 0, y: 0 }, { x: 100, y: 0 }, { x: -5000, y: -5000 }, { x: -4900, y: -5000 });
assert.throws(() => api.validateAlignmentBounds(
  { minX: 0, minY: 0, maxX: 100, maxY: 100 },
  { minX: 0, minY: 0, maxX: 100, maxY: 100 },
  remote
), /بعيدًا|سالبة/, 'mismatched whole-board placement should be stopped before export');

// The canvas preview and output transformer must select Model Space consistently even if paper layouts have huge coordinates.
const spacesDxf = `0\nSECTION\n2\nHEADER\n9\n$EXTMIN\n10\n0\n20\n0\n30\n0\n9\n$EXTMAX\n10\n21000\n20\n21000\n30\n0\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n0\nLINE\n5\nM1\n8\nMODEL_ROAD\n410\nModel\n10\n10\n20\n10\n11\n20\n21\n10\n0\nLINE\n5\nP1\n8\nPAPER_FLAG
67\n1\n410\nLayout1
10\n9000\n20\n9000\n11\n9100\n21\n9000\n0\nLINE\n5\nP2
8
PAPER_LAYOUT_ONLY
410
Layout2
10
20000
20
20000
11
20100
21
20000
0\nENDSEC\n0\nEOF\n`;
const bytes = new TextEncoder().encode(spacesDxf);
const preview = api.parsePreview(bytes);
assert(preview.bounds.maxX < 100 && preview.bounds.maxY < 100, 'preview bounds must exclude paper-space geometry when Model Space is present');
const out = api.transformBytes(bytes, api.solve({ x: 10, y: 10 }, { x: 20, y: 10 }, { x: 100, y: 200 }, { x: 100, y: 210 }));
const outPairs = api.splitPairs(out.bytes).pairs;
const outRecords = api.sectionRecords(outPairs, 'ENTITIES');
const getNum = (r, code) => Number(r.pairs.find(p => p.code === code)?.value);
const modelLine = outRecords.find(r => r.type === 'LINE' && r.pairs.some(p => p.code === 5 && p.value === 'M1'));
const paperFlag = outRecords.find(r => r.type === 'LINE' && r.pairs.some(p => p.code === 5 && p.value === 'P1'));
const paperLayout = outRecords.find(r => r.type === 'LINE' && r.pairs.some(p => p.code === 5 && p.value === 'P2'));
assert(modelLine && Math.abs(getNum(modelLine,10)-100)<1e-7 && Math.abs(getNum(modelLine,20)-200)<1e-7, 'Model Space geometry should be aligned');
assert(paperFlag && getNum(paperFlag,10)===9000 && getNum(paperFlag,20)===9000, 'paper-space entities marked by group 67 must not be transformed along with Model Space');
assert(paperLayout && getNum(paperLayout,10)===20000 && getNum(paperLayout,20)===20000, 'paper-space entities marked only by layout group 410 must remain untouched');
assert(out.entitiesBefore === out.entitiesAfter, 'alignment must not drop ENTITIES records');
console.log('PASS V145 safety: exact fit and far-offset rejection; Model/Paper space consistent across preview/output (groups 67/410); opaque proxy guard retained and ordinary OCS now transforms; alignment overlay preflight exists.');
