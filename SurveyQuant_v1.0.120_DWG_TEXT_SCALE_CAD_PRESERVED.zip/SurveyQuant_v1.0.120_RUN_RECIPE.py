#!/usr/bin/env python3
"""Execute the reviewed historical V119 build run-steps as a V120 build recipe.

The surrounding V120 workflow supplies the same pinned toolchain actions. This
adapter deliberately loads the historic builder from Git history, applies
strict version/patch-kit changes in memory, and executes each original `run:`
step separately so GITHUB_ENV semantics remain close to native Actions steps.
"""
from pathlib import Path
import os
import re
import shlex
import subprocess
import sys

BASE_SHA = "c79f7f090ef26e131a86fcfc08c40a999cda62ce"
BASE_PATH = ".github/workflows/prepare-v119-dwg-compatibility.yml"


def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise SystemExit(f"ERROR: {label}: expected one anchor, found {count}.")
    return source.replace(old, new, 1)


def transformed_builder() -> str:
    raw = subprocess.check_output(
        ["git", "show", f"{BASE_SHA}:{BASE_PATH}"],
        cwd=os.environ["GITHUB_WORKSPACE"], text=True, encoding="utf-8"
    )
    source = raw.replace("v119", "v120").replace("V119", "V120").replace("1.0.119", "1.0.120")
    source = re.sub(r"\b119\b", "120", source)
    source = replace_once(
        source,
        '      - ".github/workflows/prepare-v120-dwg-compatibility.yml"',
        '      - ".github/workflows/build-v120-dwg-text-scale.yml"',
        "workflow path"
    )
    source = replace_once(
        source,
        '      - "SurveyQuant_v1.0.115_ORIENTATION_FINAL_PATCH_PACKAGE.zip"\n',
        '      - "SurveyQuant_v1.0.115_ORIENTATION_FINAL_PATCH_PACKAGE.zip"\n'
        '      - "SurveyQuant_v1.0.120_DWG_TEXT_SCALE_CAD_PRESERVED.zip"\n',
        "V120 ZIP push trigger"
    )
    source = replace_once(
        source,
        '          unzip -q "$PATCH_ARCHIVE" -d "$PATCH_DIR"\n',
        '          unzip -q "$PATCH_ARCHIVE" -d "$PATCH_DIR"\n'
        '          V120_ARCHIVE="SurveyQuant_v1.0.120_DWG_TEXT_SCALE_CAD_PRESERVED.zip"\n'
        '          test -s "$V120_ARCHIVE" || { echo "ERROR: V120 patch ZIP is missing from the repository root."; exit 1; }\n'
        '          V120_PATCH_DIR="$RUNNER_TEMP/sq-v120-package"\n'
        '          mkdir -p "$V120_PATCH_DIR"\n'
        '          unzip -q "$V120_ARCHIVE" -d "$V120_PATCH_DIR"\n'
        '          V120_PATCHER="$V120_PATCH_DIR/SurveyQuant_v1.0.120_APPLY_PATCH.py"\n'
        '          V120_TEST="$V120_PATCH_DIR/SurveyQuant_v1.0.120_DWG_TEXT_SCALE_TEST.js"\n'
        '          test -s "$V120_PATCHER" && test -s "$V120_TEST" || { echo "ERROR: V120 patcher/test missing from ZIP."; exit 1; }\n'
        '          echo "V120_PATCHER=$V120_PATCHER" >> "$GITHUB_ENV"\n'
        '          echo "V120_TEST=$V120_TEST" >> "$GITHUB_ENV"\n',
        "extract V120 patch ZIP"
    )
    source = replace_once(
        source,
        '          node --check "$RUNNER_TEMP/sq-v120-dwg-bridge.js"\n',
        '          python3 "$V120_PATCHER" "$REFERENCE_MODULE" "$INDEX_PATH" "$RUNNER_TEMP/sq-v120-dwg-bridge.js"\n'
        '          node --check "$RUNNER_TEMP/sq-v120-dwg-bridge.js"\n'
        '          node "$V120_TEST" "$REFERENCE_MODULE" "$INDEX_PATH" "$RUNNER_TEMP/sq-v120-dwg-bridge.js"\n',
        "execute V120 patcher and regression check"
    )
    source = replace_once(
        source,
        ", 'size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale)', 'height:42dvh;min-height:250px;max-height:420px'",
        ", 'size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale*Math.max(0.001,Number(v.zoom)||1))', 'height:42dvh;min-height:250px;max-height:420px'",
        "final V120 scale assertion"
    )
    required = [
        "name: Build SurveyQuant v1.0.120", "gradle --no-daemon clean assembleRelease --stacktrace",
        "actions/upload-artifact@v4", "SurveyQuant_v1.0.120_DWG_TEXT_SCALE_CAD_PRESERVED.apk",
        'python3 "$V120_PATCHER"', "function universalTransformBytes(input,t)"
    ]
    missing = [token for token in required if token not in source]
    if missing:
        raise SystemExit("ERROR: transformed build recipe failed validation: " + ", ".join(missing))
    return source


def resolve_expressions(value: str, shell_script: bool = False) -> str:
    pattern = re.compile(r"\$\{\{\s*(.*?)\s*\}\}")
    def replacement(match: re.Match) -> str:
        expr = match.group(1).strip()
        if expr == "runner.temp":
            return os.environ.get("RUNNER_TEMP", "/tmp")
        if expr == "github.run_id":
            return os.environ.get("GITHUB_RUN_ID", "0")
        if expr == "github.token":
            return "$GH_TOKEN" if shell_script else os.environ.get("GH_TOKEN", "")
        if expr.startswith("secrets."):
            key = expr.split(".", 1)[1]
            return "$" + key if shell_script else os.environ.get(key, "")
        if expr.startswith("env."):
            key = expr.split(".", 1)[1]
            return "$" + key if shell_script else os.environ.get(key, "")
        raise SystemExit(f"ERROR: unhandled Actions expression in historical run step: ${{{{ {expr} }}}}")
    return pattern.sub(replacement, value)


def load_github_env() -> None:
    path = os.environ.get("GITHUB_ENV")
    if not path or not Path(path).exists():
        return
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if "=" in line and not line.startswith("<<"):
            key, value = line.split("=", 1)
            if key and "\n" not in key:
                os.environ[key] = value


def load_github_path() -> None:
    path = os.environ.get("GITHUB_PATH")
    if not path or not Path(path).exists():
        return
    entries = [x for x in Path(path).read_text(encoding="utf-8").splitlines() if x]
    current = os.environ.get("PATH", "").split(os.pathsep)
    for entry in reversed(entries):
        if entry not in current:
            current.insert(0, entry)
    os.environ["PATH"] = os.pathsep.join(current)


def main() -> int:
    try:
        import yaml
    except ImportError:
        raise SystemExit("ERROR: PyYAML is required. Install python3-yaml before running this recipe.")
    source = transformed_builder()
    data = yaml.safe_load(source)
    steps = data.get("jobs", {}).get("build", {}).get("steps", [])
    run_steps = [step for step in steps if isinstance(step, dict) and isinstance(step.get("run"), str)]
    if len(run_steps) < 12:
        raise SystemExit(f"ERROR: historical build recipe appears incomplete ({len(run_steps)} run steps).")

    print(f"V120: validated the V119 historical build recipe; executing {len(run_steps)} shell steps.", flush=True)
    for idx, step in enumerate(run_steps, 1):
        name = str(step.get("name", f"historical run step {idx}"))
        raw_script = resolve_expressions(step["run"], shell_script=True)
        step_env = os.environ.copy()
        for key, raw_value in (step.get("env") or {}).items():
            if not isinstance(raw_value, str):
                step_env[key] = str(raw_value)
                continue
            value = raw_value.strip()
            match = re.fullmatch(r"\$\{\{\s*secrets\.([A-Za-z_][A-Za-z0-9_]*)\s*\}\}", value)
            if match:
                step_env[key] = step_env.get(match.group(1), "")
            else:
                step_env[key] = resolve_expressions(raw_value, shell_script=False)
        workdir = step.get("working-directory")
        if workdir:
            workdir = os.path.expandvars(resolve_expressions(str(workdir), shell_script=False))
            cwd = Path(workdir)
            if not cwd.is_absolute():
                cwd = Path(os.environ["GITHUB_WORKSPACE"]) / cwd
        else:
            cwd = Path(os.environ["GITHUB_WORKSPACE"])
        print(f"::group::V120 recipe step {idx}/{len(run_steps)}: {name}", flush=True)
        result = subprocess.run(
            ["bash", "--noprofile", "--norc", "-e", "-o", "pipefail", "-c", raw_script],
            cwd=str(cwd), env=step_env, check=False
        )
        print("::endgroup::", flush=True)
        if result.returncode:
            print(f"ERROR: historical step failed ({result.returncode}): {name}", file=sys.stderr, flush=True)
            return result.returncode
        load_github_env()
        load_github_path()
    print("PASS: all historical shell steps completed. Check uploaded artifacts for APK and diagnostics.", flush=True)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
