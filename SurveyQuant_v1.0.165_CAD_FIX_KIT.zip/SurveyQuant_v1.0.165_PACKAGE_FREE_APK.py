#!/usr/bin/env python3
"""Package SurveyQuant v1.0.165 with V164 native save and tested V165 CAD engine."""
from __future__ import annotations
import argparse, copy, struct, zipfile
from pathlib import Path

OLD_NAME = '1.0.164'
NEW_NAME = '1.0.165'
NEW_CODE = 165


def read_len8(data: bytes, pos: int):
    first=data[pos]
    if first & 0x80:return (((first&0x7F)<<8)|data[pos+1]),pos+2
    return first,pos+1

def read_len16(data: bytes, pos: int):
    first=struct.unpack_from('<H',data,pos)[0]
    if first&0x8000:
        second=struct.unpack_from('<H',data,pos+2)[0]
        return (((first&0x7FFF)<<16)|second),pos+4
    return first,pos+2

def read_string_pool(data: bytes, start: int, size: int, header: int):
    if header<28 or start+size>len(data):raise ValueError('invalid Android binary XML string pool')
    count,_,flags,strings_start,_=struct.unpack_from('<IIIII',data,start+8)
    if count>100000:raise ValueError('unreasonable Android XML string count')
    offsets=start+header;base=start+strings_start;utf8=bool(flags&0x100);strings=[];spans=[]
    for i in range(count):
        rel=struct.unpack_from('<I',data,offsets+i*4)[0];p=base+rel
        if utf8:
            _,p=read_len8(data,p);n,p=read_len8(data,p);end=p+n
            strings.append(data[p:end].decode('utf-8'));spans.append((p,end,True))
        else:
            n,p=read_len16(data,p);end=p+n*2
            strings.append(data[p:end].decode('utf-16le'));spans.append((p,end,False))
    return strings,spans

def patch_manifest(data: bytes)->bytes:
    if len(data)<8 or struct.unpack_from('<H',data,0)[0]!=3:raise ValueError('AndroidManifest.xml is not binary XML')
    out=bytearray(data);pos=struct.unpack_from('<H',out,2)[0];total=struct.unpack_from('<I',out,4)[0]
    if total>len(out) or total<pos:raise ValueError('invalid binary XML size')
    strings=None;spans=[];chunks=[]
    while pos<total:
        if pos+8>total:raise ValueError('truncated Android XML chunk')
        typ,hs,cs=struct.unpack_from('<HHI',out,pos)
        if cs<hs or pos+cs>total:raise ValueError('invalid Android XML chunk bounds')
        chunks.append((pos,typ,hs,cs))
        if typ==1:strings,spans=read_string_pool(bytes(out),pos,cs,hs)
        pos+=cs
    if strings is None:raise ValueError('Android XML string pool not found')
    for i,value in enumerate(strings):
        if value==OLD_NAME:
            a,b,is8=spans[i];encoded=NEW_NAME.encode('utf-8' if is8 else 'utf-16le')
            if len(encoded)!=b-a:raise ValueError('versionName replacement changes string-pool byte length')
            out[a:b]=encoded;strings[i]=NEW_NAME
    if NEW_NAME not in strings:raise ValueError(f'manifest contains neither {OLD_NAME} nor {NEW_NAME}')
    version_fields=[]
    for cp,typ,_,cs in chunks:
        if typ!=0x0102 or cs<36:continue
        nameidx=struct.unpack_from('<I',out,cp+20)[0]
        if nameidx>=len(strings) or strings[nameidx]!='manifest':continue
        attr_start=struct.unpack_from('<H',out,cp+24)[0];attr_size=struct.unpack_from('<H',out,cp+26)[0];count=struct.unpack_from('<H',out,cp+28)[0]
        if attr_size<20 or count>1024:raise ValueError('invalid manifest attribute table')
        first=cp+16+attr_start
        for n in range(count):
            at=first+n*attr_size;idx=struct.unpack_from('<I',out,at+4)[0]
            if idx<len(strings) and strings[idx]=='versionCode':
                size=struct.unpack_from('<H',out,at+12)[0];typv=out[at+15]
                if size<8 or typv not in (0x10,0x11):raise ValueError('manifest versionCode is not integer')
                version_fields.append(at+16)
    if len(version_fields)!=1:raise ValueError(f'expected exactly one versionCode field, found {len(version_fields)}')
    struct.pack_into('<I',out,version_fields[0],NEW_CODE)
    return bytes(out)

def package_apk(apk_in:Path,apk_out:Path,html_in:Path,loader_in:Path):
    if not loader_in.is_file():raise ValueError('Patched LibreDWG WASM loader is missing')
    loader_bytes=loader_in.read_bytes()
    if b'Module["wasmBinary"]=self.SQ_DWG_WASM_BINARY' not in loader_bytes:raise ValueError('Provided LibreDWG loader is not patched for embedded WASM')
    if not apk_in.is_file() or apk_in.stat().st_size<10_000_000:raise ValueError('V161 base APK missing or unexpectedly small')
    html_bytes=html_in.read_bytes();html=html_bytes.decode('utf-8')
    required=(
      'onclick="openProjectPage(\'project1Card\')"','onclick="openProjectPage(\'dropFilesCard\')"',
      'function parseDWGDatabase(db,options={}){','window.parseFile = parseFile;','sq-v117-universal-dwg-bridge','function calculateRoad',
      'sq162-wasm-binary','sq162GetBundledDwgWasmBinary','sqDwgWorkerWasmSent','sq163RawCadOverlayMerge',
      'engine.mergeRawDxfBoards(targetBytes,sourceBytes)','sq163-runtime-bootstrap','sq163-pdfjs-worker',
      'GlobalWorkerOptions.workerSrc=url','sq163-imagetracer','sq163-cad-engine','sq164-cad-output-axis-fix','sqDownloadNameDialog','sq165-native-curves-exact-snap-raster-fix')
    missing=[v for v in required if v not in html]
    if missing:raise ValueError('V165 HTML missing required app/runtime markers: '+', '.join(missing))
    forbidden=('sq155-alignment-core','sq155-alignment-command','sqOpenOrientationProject','openOrientationProject',
      'function solveAlignment','sqAlignmentPreviewFromBlocks','SURVEYQUANT_API_BASE','sqInitAccess','sqAccessGate',
      'startKashierPayment','pollKashierStatus','openPaymentPage','closePaymentPage','paymentPage','paymentCard',
      'payment-shortcut','sqGateSubscribe')
    present=[v for v in forbidden if v in html]
    if present:raise ValueError('Old orientation/payment code remains: '+', '.join(present))
    apk_out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(apk_in,'r') as zin:
        names=[x.filename for x in zin.infolist()]
        if names.count('assets/index.html')!=1 or names.count('AndroidManifest.xml')!=1:raise ValueError('APK must contain exactly one app HTML and manifest')
        wasm_js='assets/libredwg-writer/wasm/libredwg-web.js';wasm_bin='assets/libredwg-writer/wasm/libredwg-web.wasm';umd='assets/libredwg-writer/dist/libredwg-web.js'
        for n in (wasm_js,wasm_bin,umd):
            if names.count(n)!=1:raise ValueError('Base APK missing/duplicates DWG runtime asset: '+n)
        if len(zin.read(wasm_bin))<1_000_000 or len(zin.read(umd))<100_000:raise ValueError('Base DWG runtime asset unexpectedly small')
        seen=set()
        with zipfile.ZipFile(apk_out,'w',allowZip64=True) as zout:
            for info in zin.infolist():
                name=info.filename
                if name in seen:raise ValueError('duplicate APK entry: '+name)
                seen.add(name);upper=name.upper()
                if upper.startswith('META-INF/') and (upper.endswith('.SF') or upper.endswith('.RSA') or upper.endswith('.DSA') or upper.endswith('.EC') or upper.endswith('MANIFEST.MF')):continue
                content=zin.read(name)
                if name=='assets/index.html':content=html_bytes
                elif name=='AndroidManifest.xml':content=patch_manifest(content)
                elif name==wasm_js:content=loader_bytes
                zout.writestr(copy.copy(info),content)
    with zipfile.ZipFile(apk_out,'r') as check:
        if check.read('assets/index.html')!=html_bytes:raise ValueError('APK HTML differs from tested V165 HTML')
        if check.read(wasm_js)!=loader_bytes:raise ValueError('APK runtime loader differs from tested V162 binary-injection loader')
        if len(check.read(wasm_bin))<1_000_000:raise ValueError('APK lost shared DWG WASM')
        if b'id="sq163-pdfjs-worker"' not in check.read('assets/index.html'):raise ValueError('APK lost embedded PDF.js worker')
    print('PASS V165 APK integrity: free app, V164 named Android save + notification, raw-record CAD transform, native ARC/SPLINE/ELLIPSE preview, exact intersection snap, PDF/ImageTracer and LibreDWG bundled. APK remains unsigned for workflow signing.')

def main():
    p=argparse.ArgumentParser();p.add_argument('--apk-input',type=Path,required=True);p.add_argument('--apk-output',type=Path,required=True);p.add_argument('--html-to-inject',type=Path,required=True);p.add_argument('--wasm-loader',type=Path,required=True);a=p.parse_args();package_apk(a.apk_input,a.apk_output,a.html_to_inject,a.wasm_loader)
if __name__=='__main__':main()
