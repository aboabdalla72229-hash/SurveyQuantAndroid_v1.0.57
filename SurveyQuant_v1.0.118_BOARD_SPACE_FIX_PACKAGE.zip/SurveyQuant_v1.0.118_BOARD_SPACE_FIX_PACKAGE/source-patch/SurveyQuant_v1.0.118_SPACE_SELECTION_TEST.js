'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const [enginePath,manualPath,referencePath,stormDirectory]=process.argv.slice(2);
assert(enginePath&&manualPath&&referencePath,'Usage: test.js v106.js v109.js v111.js');
const document={readyState:'loading',addEventListener(){},getElementById(){return null;}};
const window={addEventListener(){},removeEventListener(){},__sqOrientTest:{transformBytes:null}};
const ctx={window,document,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,DataView,Blob,URL,Math,Number,String,Map,Set,Array,Object,RegExp,Error,Infinity,Promise,JSON,parseInt,parseFloat,setTimeout,clearTimeout,console};
vm.createContext(ctx);
for(const path of [enginePath,manualPath,referencePath])vm.runInContext(fs.readFileSync(path,'utf8'),ctx,{filename:path});
const manual=window.__sqManualOrientation109;
const core=window.__sqOrientation111API;
assert(manual&&typeof manual.selectDrawingSpace==='function','shared drawing-space selector missing');
assert(core&&typeof core.parsePreview==='function','DXF preview API missing');
const enc=new TextEncoder(),dec=new TextDecoder();
function dxf(spacePairs){
 const p=['0','SECTION','2','ENTITIES'];
 for(const e of spacePairs)p.push(...e);
 p.push('0','ENDSEC','0','EOF');
 return enc.encode(p.join('\r\n')+'\r\n');
}
const mixed=dxf([
 ['0','LINE','8','PLAN','67','0','10','0','20','0','11','10','21','0'],
 ['0','LINE','8','PLAN','67','0','10','0','20','0','11','0','21','10'],
 ['0','TEXT','8','LABELS','67','0','10','5','20','4','40','1','1','MODEL_BOARD_DETAIL'],
 ['0','LINE','8','LAYOUT_BORDER','67','1','410','Layout1','10','1000','20','1000','11','1100','21','1000'],
 ['0','LINE','8','LAYOUT_BORDER','67','1','410','Layout1','10','1000','20','1000','11','1000','21','1100'],
 ['0','TEXT','8','PAPER_LABEL','67','1','410','Layout1','10','1020','20','1020','40','2','1','PAPERSPACE_TITLEBLOCK']
]);
const parsed=manual.parseDrawing(mixed);
assert.equal(parsed.spaceMode,'MODEL_SPACE','preview must use model space when it contains drawing geometry');
assert.equal(parsed.segs.length,2,'preview must not add Layout1 linework');
assert(parsed.texts.some(t=>t.text.includes('MODEL_BOARD_DETAIL')),'model annotation should remain visible');
assert(!parsed.texts.some(t=>t.text.includes('PAPERSPACE_TITLEBLOCK')),'paper-space title block must not contaminate model preview');
assert.equal(parsed.bounds.minX,0);assert.equal(parsed.bounds.maxX,10);assert.equal(parsed.bounds.minY,0);assert.equal(parsed.bounds.maxY,10);
const preview=core.parsePreview(mixed);
assert.equal(preview.spaceMode,'MODEL_SPACE');assert.equal(preview.segs.length,2);assert.equal(preview.bounds.maxX,10);
const t={scale:1,angleDeg:0,tx:100,ty:200,point:(x,y)=>({x:x+100,y:y+200}),vector:(x,y)=>({x,y})};
const output=core.transformBytes(mixed,t);
assert(output.bytes&&output.bytes.length>0,'transform output missing');
const outText=dec.decode(output.bytes);
assert(outText.includes('MODEL_BOARD_DETAIL')&&outText.includes('PAPERSPACE_TITLEBLOCK'),'all non-selected space data must be preserved');
function entRecords(text){const lines=text.split(/\r?\n/).map(s=>s.trim());let section='',active=null;const out=[];for(let i=0;i+1<lines.length;i+=2){const code=Number(lines[i]),value=lines[i+1];if(code===0&&value==='SECTION'){section=lines[i+3]||'';i+=2;continue;}if(code===0&&value==='ENDSEC'){section='';active=null;continue;}if(section!=='ENTITIES')continue;if(code===0){if(active)out.push(active);active={type:value,pairs:[]};}else if(active)active.pairs.push({code,value});}if(active)out.push(active);return out;}
const outRecords=entRecords(outText);const modelLine=outRecords.find(e=>e.type==='LINE'&&e.pairs.some(p=>p.code===8&&p.value==='PLAN'));
assert(modelLine,'model line should remain');
const mx=Number(modelLine.pairs.find(p=>p.code===10).value),my=Number(modelLine.pairs.find(p=>p.code===20).value);
assert.equal(mx,100);assert.equal(my,200,'selected model geometry should be translated');
const paperLine=outRecords.find(e=>e.type==='LINE'&&e.pairs.some(p=>p.code===8&&p.value==='LAYOUT_BORDER'));
assert(paperLine,'paper-space geometry should be retained');
assert.equal(Number(paperLine.pairs.find(p=>p.code===10).value),1000,'non-selected layout geometry must not be transformed');
assert.equal(Number(paperLine.pairs.find(p=>p.code===20).value),1000);
const paperOnly=dxf([
 ['0','LINE','8','PAPER_PLAN','67','1','410','Layout1','10','40','20','50','11','50','21','50'],
 ['0','TEXT','8','PAPER_TEXT','67','1','410','Layout1','10','45','20','55','40','1','1','FALLBACK_LAYOUT']
]);
const paperParsed=manual.parseDrawing(paperOnly);
assert.equal(paperParsed.spaceMode,'PAPER_SPACE','paper-space-only drawings must fall back to the best layout');
assert.equal(paperParsed.segs.length,1);assert.equal(paperParsed.bounds.minX,40);assert(paperParsed.texts.some(t=>t.text.includes('FALLBACK_LAYOUT')));
const paperOutput=core.transformBytes(paperOnly,t);
assert.equal(paperOutput.paperSpaceFallback,true,'paper-space fallback should be reported');
const paperOutputText=dec.decode(paperOutput.bytes);assert(paperOutputText.includes('FALLBACK_LAYOUT'));
assert(paperOutputText.includes('140')&&paperOutputText.includes('250'),'paper-space fallback geometry should be transformed');
// A valid saved CAD viewport should win over a few far-away annotation/block artifacts,
// while the full geometry and full bounds remain untouched in memory and in the DXF.
function headerDxf(entities){
 const lines=['0','SECTION','2','HEADER','9','$EXTMIN','10','0','20','0','30','0','9','$EXTMAX','10','10','20','10','30','0','9','$VIEWCTR','10','5','20','5','9','$VIEWSIZE','40','10','0','ENDSEC','0','SECTION','2','ENTITIES'];
 for(const e of entities)lines.push(...e);lines.push('0','ENDSEC','0','EOF');return enc.encode(lines.join('\r\n')+'\r\n');
}
const dense=[];for(let i=0;i<25;i++){const y=(i%5)*2,x=Math.floor(i/5)*2;dense.push(['0','LINE','8','BOARD','10',String(x),'20',String(y),'11',String(x+1),'21',String(y+1)]);}
dense.push(['0','POINT','8','FAR_ANNOTATION','10','999999','20','5','30','0']);
const withOutlier=headerDxf(dense),fitDrawing=manual.parseDrawing(withOutlier);
assert(fitDrawing.bounds.maxX>999000,'full geometry bounds must still include a remote INSERT/annotation');
assert(fitDrawing.fitBounds.maxX<11,'initial viewport should fit the saved main-board extents, not remote outliers');
assert.equal(fitDrawing.fitBoundsBasis,'DXF_HEADER_EXTENTS','the valid source CAD view extents should be preferred');
assert(fitDrawing.anchors.some(p=>p.x>999000),'outlier geometry stays present; only the viewport excludes it');
const fitTransform={...t,viewBounds:fitDrawing.fitBounds};
const fitOutput=dec.decode(core.transformBytes(withOutlier,fitTransform).bytes);
const headerVar=(txt,name)=>{const p=txt.split(/\r?\n/).map(x=>x.trim());const ix=p.findIndex((v,i)=>v==='9'&&p[i+1]===name);assert(ix>=0,'header '+name+' exists');const out={};for(let i=ix+2;i<p.length&&p[i]!=='9'&&p[i]!=='0';i+=2)out[p[i]]=Number(p[i+1]);return out;};
const fitCtr=headerVar(fitOutput,'$VIEWCTR'),fitSize=headerVar(fitOutput,'$VIEWSIZE'),fullMax=headerVar(fitOutput,'$EXTMAX');
assert(Math.abs(fitCtr['10']-105)<1e-7&&Math.abs(fitCtr['20']-205)<1e-7,'export opens centered on the selected main-board view');
assert(Math.abs(fitSize['40']-((fitDrawing.fitBounds.maxY-fitDrawing.fitBounds.minY)*1.12))<1e-7,'export uses the focused main-board fit window rather than the outlier-sized window');
assert.equal(fullMax['10'],110,'saved header fit extents transform around the main board');
assert(fitOutput.includes('FAR_ANNOTATION')&&fitOutput.includes('1000099'),'far-away CAD geometry is preserved in exported DXF even when the initial view is focused');
if(stormDirectory&&fs.existsSync(stormDirectory)){
 for(const file of fs.readdirSync(stormDirectory).filter(f=>/^STORM_[12]_converted\.dxf$/.test(f))){
  const bytes=new Uint8Array(fs.readFileSync(require('node:path').join(stormDirectory,file)));
  const real=manual.parseDrawing(bytes);
  assert.equal(real.spaceMode,'MODEL_SPACE',file+' should default to Model Space when model drawing entities exist');
  assert(real.segs.length>0,file+' should render board linework');
  assert(real.bounds.maxX>real.bounds.minX&&real.bounds.maxY>real.bounds.minY,file+' should retain nonzero full selected-space bounds');
  assert(real.modelEntityCount>0,file+' should select model-space entities');
  assert.equal(real.fitBoundsBasis,'DXF_HEADER_EXTENTS',file+' should prefer the original valid CAD viewport for initial fit');
  assert(real.bounds.maxX-real.bounds.minX>(real.fitBounds.maxX-real.fitBounds.minX)*5,file+' full bounds should remain distinct from focused fit bounds');
  assert(real.anchors.length>1000,file+' should retain detailed geometry anchors despite viewport fit');
  const preview=core.parsePreview(bytes);
  assert.equal(preview.spaceMode,'MODEL_SPACE',file+' preview must remain in Model Space');
  assert.equal(preview.fitBoundsBasis,'DXF_HEADER_EXTENTS',file+' supplemental preview must use the same canonical fit');
  assert(preview.segs.length>1000,file+' should retain many rendered details');
  assert(preview.bounds.maxX-preview.bounds.minX>(preview.fitBounds.maxX-preview.fitBounds.minX)*5,file+' full preview bounds should not be rewritten to hide geometry');
  console.log('PASS real STORM preview '+file+': model entities='+real.modelEntityCount+', layout entities='+real.paperEntityCount+', rendered segments='+preview.segs.length+', focused viewport='+preview.fitBoundsBasis);
 }
}
console.log('PASS v118 regression: selected drawing space, CAD header viewport fit, full entity preservation, focused exported view, mixed Model/Paper Space, and Paper Space fallback.');
