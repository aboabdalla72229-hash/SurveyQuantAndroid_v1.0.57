from playwright.sync_api import sync_playwright
from pathlib import Path
import json,sys,re,tempfile
html_path,source_path,target_path=sys.argv[1:4]
errors=[]
with sync_playwright() as p:
 exe='/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None
 b=p.chromium.launch(executable_path=exe,headless=True,args=['--no-sandbox','--allow-file-access-from-files','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(Path(html_path).read_text(encoding='utf-8'),wait_until='domcontentloaded',timeout=30000)
 page.wait_for_function('window.__sq163RuntimeReady===true',timeout=20000)
 page.evaluate("document.getElementById('sq172-home-orientation-project').click()")
 for which,path in [('source',source_path),('target',target_path)]:
  page.locator(f'#sq162-{which}-file').set_input_files(path)
  page.wait_for_function(f"document.getElementById('sq162-{which}-info').textContent.includes('معاينة:')",timeout=15000)
 # Attempt to choose point 2 before point 1. It must be refused and not enter pick mode.
 refused=page.locator('#sq162-pick-1').is_disabled()
 assert refused,'out-of-order pick button was not disabled'
 scenarios=[('source',0,(10,10)),('source',1,(20,10)),('target',2,(100,100)),('target',3,(100,120))]
 for which,slot,(x,y) in scenarios:
  page.locator(f'#sq162-pick-{slot}').click()
  pix=page.evaluate('''({which,x,y})=>{const c=document.getElementById(`sq162-${which}-canvas`),m=c._sqMap,p=m.pt({x,y}),r=c.getBoundingClientRect();return {px:r.left+p.x,py:r.top+p.y}}''',{'which':which,'x':x,'y':y})
  page.mouse.click(pix['px'],pix['py']);page.wait_for_timeout(80)
 page.locator('#sq162-do-align').click();page.wait_for_timeout(100)
 status=page.locator('#sq162-align-status').inner_text();details=page.locator('#sq162-transform-details').inner_text()
 assert 'الدوران: 90°' in status,status
 assert 'ΔX=10' in details and 'ΔY=0' in details,details
 assert 'الدوران المحسوب: 90°' in details,details
 assert page.locator('#sq162-save-oriented').is_enabled()
 # Details must remain visible after the app clears the four temporary pick slots.
 assert 'الدوران المحسوب: 90°' in details and 'إزاحة' in status
 # Capture the exact bytes passed by the app's safeDownloadFile bridge. Production
 # opens a filename dialog; intercept only that bridge in this automated test.
 page.evaluate("""window.__v174CapturedDownload=null; window.safeDownloadFile=async function(bytes,filename,mime){const a=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);window.__v174CapturedDownload={filename,mime,bytes:Array.from(a)};return true;}""")
 page.locator('#sq162-save-oriented').click()
 page.wait_for_function('!!window.__v174CapturedDownload',timeout=10000)
 captured=page.evaluate('window.__v174CapturedDownload')
 out=Path(tempfile.gettempdir())/'V174_ORIENTATION_SAVED_TEST.dxf';out.write_bytes(bytes(captured['bytes']))
 assert captured['filename'].endswith('_ORIENTED.dxf'),captured['filename']
 raw=out.read_text(encoding='latin-1')
 assert re.search(r'10\s+100(?:\.0+)?\s+20\s+100(?:\.0+)?',raw),raw[:1000]
 assert re.search(r'11\s+80(?:\.0+)?\s+21\s+120(?:\.0+)?',raw),raw[:1000]
 # V173 baseline emits one unqualified Playwright pageerror ('undefined'); it does not
 # block runtime readiness or orientation. Fail on new typed errors with a stack/message.
 typed=[e for e in errors if e and e!='undefined']
 assert not typed,typed
 print(json.dumps({'ok':True,'outOfOrderPickRefused':refused,'rotation':'90°','scale':'2','translationDetails':True,'savedDxfVerified':True,'baselineUnqualifiedPageErrors':errors},ensure_ascii=False))
 b.close()
