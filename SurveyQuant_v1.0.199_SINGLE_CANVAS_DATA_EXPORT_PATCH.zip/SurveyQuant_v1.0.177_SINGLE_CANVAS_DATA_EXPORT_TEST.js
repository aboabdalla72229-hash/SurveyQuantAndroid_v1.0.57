'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');

function crc32(buf){let c=0xffffffff;for(const b of buf){c^=b;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;}
function zipStore(entries){
 const locals=[],centrals=[];let offset=0;
 const u16=n=>{const b=Buffer.alloc(2);b.writeUInt16LE(n);return b;};
 const u32=n=>{const b=Buffer.alloc(4);b.writeUInt32LE(n>>>0);return b;};
 for(const e of entries){const name=Buffer.from(e.name,'utf8'),data=Buffer.from(e.data),crc=crc32(data);
  const local=Buffer.concat([u32(0x04034b50),u16(20),u16(0x0800),u16(0),u16(0),u16(33),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),name,data]);
  const central=Buffer.concat([u32(0x02014b50),u16(20),u16(20),u16(0x0800),u16(0),u16(0),u16(33),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),name]);
  locals.push(local);centrals.push(central);offset+=local.length;
 }
 const localBytes=Buffer.concat(locals),centralBytes=Buffer.concat(centrals);
 return new Uint8Array(Buffer.concat([localBytes,centralBytes,u32(0x06054b50),u16(0),u16(0),u16(entries.length),u16(entries.length),u32(centralBytes.length),u32(localBytes.length),u16(0)]));
}
const jpegPath=path.join(__dirname,'V177_TEST_PIXEL.jpg');
assert.ok(fs.existsSync(jpegPath),'valid JPEG fixture must be present');
const jpeg=fs.readFileSync(jpegPath),drawnTexts=[];
const fakeContext={fillRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fillText(t){drawnTexts.push(String(t));}};
const fakeDocument={readyState:'loading',addEventListener(){},getElementById(){return null;},createElement(tag){if(tag!=='canvas')throw new Error('Unexpected element '+tag);return{width:0,height:0,getContext(){return fakeContext;},toDataURL(){return 'data:image/jpeg;base64,'+jpeg.toString('base64');}};}};
const window={document:fakeDocument,SurveyQuantCAD162:{zipStore},setInterval,clearInterval,addEventListener(){},atob:global.atob};
const context={window,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,Math,Number,String,Map,Set,Promise,console,atob:global.atob};
vm.createContext(context);
const modulePath=process.argv[2]||path.join(__dirname,'SurveyQuant_v1.0.177_SINGLE_CANVAS_DATA_EXPORT_MODULE.js');
vm.runInContext(fs.readFileSync(modulePath,'utf8'),context,{filename:modulePath});
const core=window.SurveyQuantV177AddendumCore;
assert.ok(core,'pure addendum helpers must be exposed for tests');
const samples=[
 {id:'P0001',easting:576761.446,northing:858279.357,elevation:12.345},
 {id:'P0002',easting:576765.125,northing:858284.875,elevation:13.25}
];
const picks=[{x:10,y:20},{x:110,y:20},{x:1000,y:2000},{x:1000,y:2200}];
const kept=core.syntheticPicks(picks,true),rigid=core.alignment(picks,true);
assert.equal(rigid.scale,1,'preserve-scale selection must produce a unit scale');
assert.ok(Math.abs(rigid.rotationDegrees-90)<1e-9,'preserve-scale must rotate to reference bearing');
assert.ok(Math.abs(rigid.apply({x:10,y:20}).x-1000)<1e-8&&Math.abs(rigid.apply({x:10,y:20}).y-2000)<1e-8,'first reference point must map exactly');
assert.ok(Math.abs(rigid.secondResidual-100)<1e-8,'second-point residual must report the mismatch without silently scaling');
const scaled=core.alignment(picks,false);
assert.equal(scaled.scale,2,'scale-enabled mode must derive scale from point distances');
const csv=core.csvText(samples),txt=core.txtText(samples),sdr=core.sdrText(samples);
assert.match(csv,/"ID","Easting","Northing","Elevation"/);
assert.match(csv,/576761\.446/);assert.match(csv,/858279\.357/);
assert.match(txt,/P0001\t576761\.446\t858279\.357\t12\.345/);
assert.match(sdr,/08TP,P0001,576761\.446,858279\.357,12\.345/);
const xlsx=core.makeXlsx(samples);assert.ok(xlsx instanceof Uint8Array&&xlsx.length>100,'Excel generator must return ZIP bytes');
const pdf=core.makePdf(samples);assert.ok(pdf instanceof Uint8Array&&pdf.length>100,'point-list PDF must return bytes');assert.ok(drawnTexts.includes('مكتب فني مساحة | كشف النقاط'),'Arabic report title must be drawn by the PDF canvas');
const geom={segments:[{a:{x:0,y:0},b:{x:10,y:0},color:'#f00'}],curves:[{points:[{x:0,y:2},{x:10,y:2}]}],texts:[{position:{x:5,y:5},text:'TEST'}]};
const entities=core.entityList(geom);assert.equal(entities.length,3,'line, curve and text entities must be individually selectable');
assert.equal(core.entityDistance({x:5,y:1},{kind:'segments',index:0,item:geom.segments[0]}),1,'line hit-testing distance must be accurate');
assert.equal(core.entityDistance({x:5,y:4},{kind:'texts',index:0,item:geom.texts[0]}),1,'text hit-testing distance must be accurate');
assert.equal(core.entityKey(entities[1]),'curves:0','entity identity must remain stable by type and index');
const dxf=core.annotationDxf(samples);const dxfText=new TextDecoder().decode(dxf);
assert.match(dxfText,/\$ACADVER\n1\nAC1009/);assert.match(dxfText,/SURVEY_POINTS/);assert.match(dxfText,/SURVEY_LABELS/);assert.match(dxfText,/576761\.446/);
const outDir=process.argv[3]||__dirname;fs.mkdirSync(outDir,{recursive:true});
fs.writeFileSync(path.join(outDir,'V177_TEST_POINTS.xlsx'),Buffer.from(xlsx));
fs.writeFileSync(path.join(outDir,'V177_TEST_POINTS.pdf'),Buffer.from(pdf));
fs.writeFileSync(path.join(outDir,'V177_TEST_POINTS_ANNOTATION.dxf'),Buffer.from(dxf));
console.log(JSON.stringify({
 preserveScale:{scale:rigid.scale,rotationDegrees:rigid.rotationDegrees,firstPointMapped:true,secondPointResidual:rigid.secondResidual},
 scaleFromPairs:{scale:scaled.scale},
 pointExports:{csvRows:samples.length,txtRows:samples.length,sdrRows:samples.length,xlsxBytes:xlsx.length,pdfBytes:pdf.length,pdfRenderedTexts:drawnTexts.length,dxfBytes:dxf.length},
 entitySelection:{entities:entities.length,lineHitDistance:1,textHitDistance:1,stableKey:core.entityKey(entities[1])},axisOrder:'X=Easting,Y=Northing',result:'PASS'
},null,2));
