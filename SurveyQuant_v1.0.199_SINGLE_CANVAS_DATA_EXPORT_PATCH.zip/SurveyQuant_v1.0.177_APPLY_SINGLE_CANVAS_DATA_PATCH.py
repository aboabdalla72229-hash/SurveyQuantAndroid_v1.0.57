#!/usr/bin/env python3
"""Safely inject the V177 single-canvas and point-data addendum into index.html."""
from __future__ import annotations

import argparse
import os
import re
import sys
import tempfile
from pathlib import Path

PATCH_MARKER = "<!-- SURVEYQUANT_V177_SINGLE_CANVAS_DATA_EXPORT_INTEGRATED -->"
MODULE_MARKER = "/* SURVEYQUANT_V177_SINGLE_CANVAS_DATA_EXPORT_ADDENDUM */"
SCRIPT_ID = 'id="sq177-single-canvas-data-export"'


def validate_base(html: str) -> None:
    missing = []
    for token, label in [
        ("SurveyQuantCAD162", "V177 CAD engine API"),
        ("parseFile", "V177 shared parser"),
        ("safeDownloadFile", "Android save bridge"),
        ('id="homeMenu"', "home menu"),
        ("</body>", "closing body tag"),
    ]:
        if token not in html:
            missing.append(label)
    if missing:
        raise SystemExit("ERROR: base index.html is not the V177-patched source; missing " + ", ".join(missing))


def inject(html_path: Path, module_path: Path, check_only: bool = False) -> None:
    html = html_path.read_text(encoding="utf-8")
    module = module_path.read_text(encoding="utf-8")
    if MODULE_MARKER not in module:
        raise SystemExit("ERROR: addendum module marker missing")
    if re.search(r"</script\s*>", module, flags=re.I):
        raise SystemExit("ERROR: module contains a closing script tag and cannot be safely inlined")

    if PATCH_MARKER in html:
        if SCRIPT_ID not in html:
            raise SystemExit("ERROR: addendum marker exists but inline script is missing")
        if check_only:
            print("PASS V177 addendum integration check-only")
            return
        raise SystemExit("ERROR: addendum already integrated; refusing duplicate injection")

    validate_base(html)
    if SCRIPT_ID in html:
        raise SystemExit("ERROR: addendum script ID already exists without integration marker")

    close = list(re.finditer(r"</body\s*>", html, flags=re.I))
    if len(close) != 1:
        raise SystemExit(f"ERROR: expected one closing body tag, found {len(close)}")
    pos = close[0].start()
    injected = (
        html[:pos]
        + "\n<script id=\"sq177-single-canvas-data-export\">\n"
        + module
        + "\n</script>\n"
        + PATCH_MARKER
        + "\n"
        + html[pos:]
    )

    # Check the resulting inline module syntax before touching the source file.
    match = re.search(
        r'<script\s+id="sq177-single-canvas-data-export">\s*([\s\S]*?)\s*</script>',
        injected,
        flags=re.I,
    )
    if not match or MODULE_MARKER not in match.group(1):
        raise SystemExit("ERROR: resulting inline script could not be verified")

    html_path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=html_path.name + ".", suffix=".tmp", dir=str(html_path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
            stream.write(injected)
            stream.flush()
            os.fsync(stream.fileno())
        Path(temp_name).replace(html_path)
    except Exception:
        try:
            Path(temp_name).unlink(missing_ok=True)
        finally:
            raise

    print(f"PASS V177 addendum injected: {len(injected):,} HTML characters")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--html", type=Path, required=True)
    parser.add_argument("--module", type=Path, required=True)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    if not args.html.is_file() or not args.module.is_file():
        raise SystemExit("ERROR: HTML or addendum module file not found")
    inject(args.html, args.module, args.check_only)


if __name__ == "__main__":
    main()
