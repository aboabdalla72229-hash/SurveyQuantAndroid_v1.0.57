from pathlib import Path
import re, sys

root=Path(sys.argv[1])
html_path=root/'index.html'
html=html_path.read_text(encoding='utf-8')

# Extract the exact embedded V178/V179 CAD engine from the APK's index.html.
pat=r'(<script\s+id=["\']sq176-cad-engine["\']\s*>)([\s\S]*?)(</script\s*>)'
hits=list(re.finditer(pat,html,re.I))
if len(hits)!=1:
    raise SystemExit(f'Expected exactly one embedded CAD engine, got {len(hits)}')
m=hits[0]
engine=m.group(2)

def rep_engine(old,new,label):
    global engine
    n=engine.count(old)
    if n!=1:
        raise SystemExit(f'{label}: expected one engine match, got {n}')
    engine=engine.replace(old,new,1)

# 1) A true session reset: never carry loaded files, pick slots, diagnostics, or canvas maps
# from a previously opened project screen.
old_state="const state = { source: null, target: null, loadSerial:{source:0,target:0}, pickStage: -1, picks: [null,null,null,null], lastAlignmentDiagnostics:null, tracerFile: null, rasterCanvas: null, views: {source:{zoom:1,panX:0,panY:0,centerX:null,centerY:null},target:{zoom:1,panX:0,panY:0,centerX:null,centerY:null}}, snapModes:{source:'intersection',target:'intersection'}, hover:{source:null,target:null} };"
new_state="const state = { source: null, target: null, loadSerial:{source:0,target:0}, sessionId:0, pickStage: -1, picks: [null,null,null,null], lastAlignmentDiagnostics:null, tracerFile: null, rasterCanvas: null, views: {source:{zoom:1,panX:0,panY:0,centerX:null,centerY:null},target:{zoom:1,panX:0,panY:0,centerX:null,centerY:null}}, snapModes:{source:'intersection',target:'intersection'}, hover:{source:null,target:null} };"
rep_engine(old_state,new_state,'session state')

# Make clearDrawing invalidate the pick maps and all old point diagnostics.
old_clear="""    function clearDrawing(which) {
      state.loadSerial[which]=(state.loadSerial[which]||0)+1;
      if(state[which]?.rasterUrl)try{root.URL.revokeObjectURL(state[which].rasterUrl);}catch(_){}if(state[which]?.rasterUrls)for(const u of state[which].rasterUrls)try{root.URL.revokeObjectURL(u);}catch(_){}
      state[which] = null;state.lastAlignmentDiagnostics=null; if(which==='target'&&state.source){state.source.alignment=null;state.source.transform=null;state.source.viewGeom=null;} state.hover[which]=null; state.views[which]={zoom:1,panX:0,panY:0,centerX:null,centerY:null};
      const first=which==='source'?0:2;state.picks[first]=null;state.picks[first+1]=null;
      const prefix = which === 'source' ? 'source' : 'target';
      el(`sq162-${prefix}-file`).value = ''; el(`sq162-${prefix}-info`).textContent = 'لم يتم اختيار ملف بعد.';
      clearCanvas(el(`sq162-${prefix}-canvas`));
      state.picks = [null,null,null,null]; state.pickStage = -1; updatePickUi();
    }
"""
new_clear="""    function clearDrawing(which) {
      state.loadSerial[which]=(state.loadSerial[which]||0)+1;
      state.sessionId++;
      if(state[which]?.rasterUrl)try{root.URL.revokeObjectURL(state[which].rasterUrl);}catch(_){}
      if(state[which]?.rasterUrls)for(const u of state[which].rasterUrls)try{root.URL.revokeObjectURL(u);}catch(_){}
      state[which] = null;
      state.picks=[null,null,null,null];state.lastAlignmentDiagnostics=null;state.pickStage=-1;state.hover={source:null,target:null};
      if(state.source){state.source.alignment=null;state.source.transform=null;state.source.viewGeom=null;}
      for(const side of ['source','target']){
        state.views[side]={zoom:1,panX:0,panY:0,centerX:null,centerY:null};
        const c=el(`sq162-${side}-canvas`);if(c){c._sqMap=null;clearCanvas(c);}
        const input=el(`sq162-${side}-file`);if(side===which&&input)input.value='';
        const info=el(`sq162-${side}-info`);if(side===which&&info)info.textContent='لم يتم اختيار ملف بعد.';
      }
      const name=el('sq162-oriented-name');if(name)name.value='';
      updatePickUi();redrawAll();
    }
"""
rep_engine(old_clear,new_clear,'clearDrawing session invalidation')

# Clean every time the project is opened, not only when a project-back element happens to be clicked.
old_button="b.addEventListener('click',()=>{if(typeof root.openProjectPage==='function')root.openProjectPage(cardId);else{doc.body.classList.add('project-mode');orientationCard.classList.toggle('active-project',cardId==='sqOrientationCard');pdfCard.classList.toggle('active-project',cardId==='sqPdfDxfCard');}});"
new_button="b.addEventListener('click',()=>{cleanup();if(typeof root.openProjectPage==='function')root.openProjectPage(cardId);else{doc.body.classList.add('project-mode');orientationCard.classList.toggle('active-project',cardId==='sqOrientationCard');pdfCard.classList.toggle('active-project',cardId==='sqPdfDxfCard');}});"
rep_engine(old_button,new_button,'project open clears previous session')

# Make the old alignment diagnostic visible only while it belongs to the exact two currently loaded boards.
old_display="""      const livePicked=state.picks.every(Boolean);
      const saved=state.lastAlignmentDiagnostics;
      const displayPicks=livePicked?state.picks:(saved?[saved.sourceA,saved.sourceB,saved.targetA,saved.targetB]:state.picks);
"""
new_display="""      const livePicked=state.picks.every(Boolean);
      const saved=state.lastAlignmentDiagnostics;
      const savedCurrent=!!(saved&&state.source&&state.target&&saved.sourceFingerprint===state.source.fingerprint&&saved.targetFingerprint===state.target.fingerprint&&saved.sourceCadFingerprint===state.source.cadFingerprint&&saved.targetCadFingerprint===state.target.cadFingerprint);
      const displayPicks=livePicked?state.picks:(savedCurrent?[saved.sourceA,saved.sourceB,saved.targetA,saved.targetB]:state.picks);
"""
rep_engine(old_display,new_display,'diagnostic board provenance')
old_d="const d=livePicked?alignmentDiagnostics(state.picks):saved;"
new_d="const d=livePicked?alignmentDiagnostics(state.picks):(savedCurrent?saved:null);"
rep_engine(old_d,new_d,'diagnostic display guard')
old_saved_msg="if(saved&&!livePicked)lines.push('تم اعتماد هذا التحويل. أُبقيت بياناته ظاهرة حتى إعادة اختيار النقاط أو تحميل لوحة أخرى.');"
new_saved_msg="if(savedCurrent&&!livePicked)lines.push('تم اعتماد هذا التحويل للملفين الحاليين فقط. ستُمسح بياناته عند تغيير أي ملف أو إعادة فتح المشروع.');"
rep_engine(old_saved_msg,new_saved_msg,'saved diagnostic message')

# On tapping a file input, clear that board and invalidate the whole transform BEFORE Android's picker opens.
old_picker="input.addEventListener('click',()=>{input.value='';});"
new_picker="input.addEventListener('click',()=>{clearDrawing(which);input.value='';status('تم إبطال نقاط التوجيه والنتيجة السابقة قبل اختيار الملف الجديد.');});"
rep_engine(old_picker,new_picker,'clear old board before Android file picker')

# Store the source/target fingerprints together with last diagnostics, not a detached stale value.
old_align="state.lastAlignmentDiagnostics=alignmentDiagnostics(picked);"
new_align="state.lastAlignmentDiagnostics={...alignmentDiagnostics(picked),sourceFingerprint:state.source.fingerprint,targetFingerprint:state.target.fingerprint,sourceCadFingerprint:state.source.cadFingerprint,targetCadFingerprint:state.target.cadFingerprint};"
rep_engine(old_align,new_align,'diagnostics provenance stamp')

# When a project screen is cleaned up, also clear the PDF selection and its proposed filename.
old_cleanup="""      el('sq162-raster-file').value = ''; el('sq162-pdf-page').value = '1'; el('sq162-raster-scale').value = '1';
      el('sq162-raster-canvas').style.display = 'none'; clearCanvas(el('sq162-raster-canvas'));
      el('sq162-trace').disabled = true; status('تم مسح الملفات والنقاط من الذاكرة المؤقتة.');
"""
new_cleanup="""      el('sq162-raster-file').value = ''; el('sq162-pdf-page').value = '1'; el('sq162-raster-scale').value = '1';
      const pdfName=el('sq162-pdf-output-name');if(pdfName)pdfName.value='';
      el('sq162-raster-canvas').style.display = 'none'; clearCanvas(el('sq162-raster-canvas'));
      el('sq162-trace').disabled = true; status('تم مسح ملفات اللوحات وبياناتها المؤقتة واسم ملف PDF السابق.');
"""
rep_engine(old_cleanup,new_cleanup,'PDF state cleanup')

# Validate the user-selected output name before expensive PDF rendering or tracing starts.
old_pdf_name_start="const file = state.tracerFile; let pdf = null, canvas = null, directVectorPaths = null, pdfViewport = null;\n      try {\n        if (!file) throw new Error('اختر ملف PDF أو صورة أولًا.');\n        traceBtn.disabled = true; status('جارٍ قراءة الصفحة ثم استخراج المسارات الهندسية القابلة للتحرير...', 'sq162-raster-status');"
new_pdf_name_start="const file = state.tracerFile; let pdf = null, canvas = null, directVectorPaths = null, pdfViewport = null;\n      try {\n        if (!file) throw new Error('اختر ملف PDF أو صورة أولًا.');\n        const requestedOutputName=String(el('sq162-pdf-output-name')?.value||'').trim();if(!requestedOutputName)throw new Error('اكتب اسم اللوحة في خانة «اسم اللوحة الناتجة قبل الحفظ» أولًا.');\n        traceBtn.disabled = true; status('جارٍ قراءة الصفحة ثم استخراج المسارات الهندسية القابلة للتحرير...', 'sq162-raster-status');"
rep_engine(old_pdf_name_start,new_pdf_name_start,'validate PDF output name before processing')

# 2) PDF hybrid pipeline. Native vector CAD and native text are retained, while the rendered
# page is always traced for image-only/mixed regions. Native vector ink/text is masked from
# the raster copy first, avoiding a full-page duplicate of the vector layer.
old_paint="""if(color){for(const q of subpaths){if(paths.length>=50000)throw new Error('ملف PDF يحتوي عدد مسارات يتجاوز الحد الآمن.');if(q.points.length>=2)paths.push({...q,aci:color.aci,rgb:color.rgb,lineWidth,paintMode:strokes?'stroke':(fills?'fill':'unknown')});}}subpaths=[];active=null;};"""
new_paint="""if(color){for(const q of subpaths){if(paths.length>=50000)throw new Error('ملف PDF يحتوي عدد مسارات يتجاوز الحد الآمن.');if(q.points.length>=2)paths.push({...q,aci:color.aci,rgb:color.rgb,lineWidth,paintMode:strokes?'stroke':(fills?'fill':'unknown'),hasStroke:!!(strokes&&!strokeColor.white),hasFill:!!(fills&&!fillColor.white)});}}subpaths=[];active=null;};"""
rep_engine(old_paint,new_paint,'PDF path paint metadata')

old_pdf_block="""        let paths=[],result=null,outputMode='تتبع خطوط الصفحة',pdfTexts=[];
        if(directVectorPaths?.length){paths=directVectorPaths;pdfTexts=await pdfTextToCad(await pdf.getPage(Math.max(1,Math.min(pdf.numPages,Number.parseInt(el('sq162-pdf-page').value||'1',10)||1))),pdfViewport);result=polylinesToDxf(paths,pdfViewport.width,pdfViewport.height,factor,pdfTexts);outputMode='استخراج متجهات PDF الأصلية ونصوصها';}
        else{
          if(!root.ImageTracer||typeof root.ImageTracer.imagedataToSVG!=='function')throw new Error('لم يحتوِ PDF على مسارات متجهة، ومحرك تتبع الصفحات الممسوحة غير موجود.');
          const imageData=ctx.getImageData(0,0,canvas.width,canvas.height);
          const svg=root.ImageTracer.imagedataToSVG(imageData,{colorsampling:0,numberofcolors:8,colorquantcycles:3,ltres:0.65,qtres:0.65,pathomit:2,roundcoords:2,scale:1,viewbox:true,strokewidth:0});
          if(typeof svg!=='string'||!svg.includes('<svg'))throw new Error('لم ينتج محرك التتبع رسمًا متجهيًا من الصفحة.');
          paths=svgPathsToCad(svg,canvas.width,canvas.height,12);result=polylinesToDxf(paths,canvas.width,canvas.height,factor);
        }
        if(!result.bytes||result.bytes.length<100||!result.count)throw new Error('لم يتم استخراج خطوط CAD كافية للحفظ. جرّب PDF أو صورة أوضح.');
"""
new_pdf_block="""        let paths=[],result=null,outputMode='تتبع خطوط الصفحة',pdfTexts=[];
        if(pdf){
          const sx=canvas.width/Math.max(1,pdfViewport.width),sy=canvas.height/Math.max(1,pdfViewport.height),avgScale=(sx+sy)/2;
          const pageNumber=Math.max(1,Math.min(pdf.numPages,Number.parseInt(el('sq162-pdf-page').value||'1',10)||1));
          const page=await pdf.getPage(pageNumber);
          const vectorBase=Array.isArray(directVectorPaths)?directVectorPaths:[];
          const vectorPaths=vectorBase.map(p=>({...p,points:(p.points||[]).map(q=>({x:Number(q.x)*sx,y:Number(q.y)*sy})),lineWidth:Math.max(.5,Number(p.lineWidth||1)*avgScale)}));
          const textBase=await pdfTextToCad(page,pdfViewport);
          pdfTexts=textBase.map(t=>({...t,x:t.x*sx,y:t.y*sy,width:t.width*sx,height:t.height*avgScale}));

          // Work on a copy of the rendered page: remove only native vectors/text from the
          // tracing pass, then re-add their original CAD geometry below.
          const traceCanvas=doc.createElement('canvas');traceCanvas.width=canvas.width;traceCanvas.height=canvas.height;
          const traceCtx=traceCanvas.getContext('2d',{willReadFrequently:true});if(!traceCtx)throw new Error('تعذر إنشاء طبقة تتبع PDF المختلطة.');
          traceCtx.fillStyle='#ffffff';traceCtx.fillRect(0,0,traceCanvas.width,traceCanvas.height);traceCtx.drawImage(canvas,0,0);
          if(vectorPaths.length){
            traceCtx.save();traceCtx.strokeStyle='#ffffff';traceCtx.fillStyle='#ffffff';traceCtx.lineCap='round';traceCtx.lineJoin='round';
            for(const p of vectorPaths){const pts=p.points||[];if(pts.length<2)continue;traceCtx.beginPath();traceCtx.moveTo(pts[0].x,pts[0].y);for(let k=1;k<pts.length;k++)traceCtx.lineTo(pts[k].x,pts[k].y);
              if(p.closed&&p.hasFill)traceCtx.fill();
              if(p.hasStroke||!p.hasFill){traceCtx.lineWidth=Math.max(4,Number(p.lineWidth||1)+4);traceCtx.stroke();}
            }
            traceCtx.restore();
          }
          if(pdfTexts.length){
            traceCtx.save();traceCtx.fillStyle='#ffffff';
            for(const t of pdfTexts){const theta=(Number(t.rotation)||0)*Math.PI/180,w=Math.max(2,Number(t.width)||Number(t.height)||2),h=Math.max(2,Number(t.height)||2),dx=w*Math.cos(theta),dy=-w*Math.sin(theta),nx=h*Math.sin(theta),ny=-h*Math.cos(theta),xs=[t.x,t.x+dx,t.x+nx,t.x+dx+nx],ys=[t.y,t.y+dy,t.y+ny,t.y+dy+ny],pad=Math.max(2,avgScale*1.5),x0=Math.min(...xs)-pad,y0=Math.min(...ys)-pad,x1=Math.max(...xs)+pad,y1=Math.max(...ys)+pad;traceCtx.fillRect(x0,y0,x1-x0,y1-y0);}
            traceCtx.restore();
          }
          let rasterPaths=[];
          if(!root.ImageTracer||typeof root.ImageTracer.imagedataToSVG!=='function'){
            if(!vectorPaths.length&&!pdfTexts.length)throw new Error('قارئ PDF لم يستخرج عناصر CAD، ومحرك تتبع الصفحات غير موجود.');
          }else{
            const imageData=traceCtx.getImageData(0,0,traceCanvas.width,traceCanvas.height);
            const svg=root.ImageTracer.imagedataToSVG(imageData,{colorsampling:0,numberofcolors:8,colorquantcycles:3,ltres:0.65,qtres:0.65,pathomit:2,roundcoords:2,scale:1,viewbox:true,strokewidth:0});
            if(typeof svg!=='string'||!svg.includes('<svg'))throw new Error('لم ينتج محرك التتبع رسمًا متجهيًا من الصفحة.');
            try{rasterPaths=svgPathsToCad(svg,traceCanvas.width,traceCanvas.height,12);}catch(traceError){if(!vectorPaths.length&&!pdfTexts.length)throw traceError;rasterPaths=[];}
          }
          paths=vectorPaths.concat(rasterPaths);
          outputMode=`PDF مختلط: متجهات أصلية ${vectorPaths.length} + مسارات Raster متتبعة ${rasterPaths.length} + نصوص ${pdfTexts.length}`;
          result=polylinesToDxf(paths,canvas.width,canvas.height,factor,pdfTexts);
        }else{
          if(!root.ImageTracer||typeof root.ImageTracer.imagedataToSVG!=='function')throw new Error('محرك تتبع الصور غير محمّل داخل التطبيق.');
          const imageData=ctx.getImageData(0,0,canvas.width,canvas.height);
          const svg=root.ImageTracer.imagedataToSVG(imageData,{colorsampling:0,numberofcolors:8,colorquantcycles:3,ltres:0.65,qtres:0.65,pathomit:2,roundcoords:2,scale:1,viewbox:true,strokewidth:0});
          if(typeof svg!=='string'||!svg.includes('<svg'))throw new Error('لم ينتج محرك التتبع رسمًا متجهيًا من الصورة.');
          paths=svgPathsToCad(svg,canvas.width,canvas.height,12);result=polylinesToDxf(paths,canvas.width,canvas.height,factor,[]);
        }
        if(!result.bytes||result.bytes.length<100||(!result.count&&!result.textCount))throw new Error('لم يتم استخراج أي هندسة أو نصوص CAD قابلة للحفظ من الصفحة.');
"""
rep_engine(old_pdf_block,new_pdf_block,'PDF mixed vector and raster pipeline')

# Require an explicit name at the moment of export. The field gets a useful proposed name
# when a PDF is selected, but blanking it is an intentional validation error.
old_name="const baseName=safeOutputBase(el('sq162-pdf-output-name')?.value,file.name.replace(/\\.[^.]+$/,''));\n        const filename=`${baseName}.dxf`;"
new_name="const baseName=safeOutputBase(requestedOutputName,'');\n        const filename=`${baseName}.dxf`;"
rep_engine(old_name,new_name,'explicit PDF output name')

# Cancel a previous PDF selection as soon as the picker opens so the old PDF cannot be exported by mistake.
old_pdf_picker="rasterFileInput.addEventListener('change', () => { state.tracerFile = rasterFileInput.files[0] || null; traceBtn.disabled = !state.tracerFile; const nameInput=el('sq162-pdf-output-name');if(nameInput&&state.tracerFile)nameInput.value=safeOutputBase(state.tracerFile.name.replace(/\\.[^.]+$/,''),'SurveyQuant_PDF'); status(state.tracerFile ? `تم اختيار ${state.tracerFile.name} (${state.tracerFile.size.toLocaleString()} بايت).` : 'اختر ملفًا للبدء.', 'sq162-raster-status'); });"
new_pdf_picker="rasterFileInput.addEventListener('click',()=>{state.tracerFile=null;traceBtn.disabled=true;const n=el('sq162-pdf-output-name');if(n)n.value='';rasterCanvas.style.display='none';clearCanvas(rasterCanvas);status('تم إلغاء اختيار PDF السابق. اختر الملف الجديد.', 'sq162-raster-status');});\n    rasterFileInput.addEventListener('change', () => { state.tracerFile = rasterFileInput.files[0] || null; traceBtn.disabled = !state.tracerFile; const nameInput=el('sq162-pdf-output-name');if(nameInput&&state.tracerFile)nameInput.value=safeOutputBase(state.tracerFile.name.replace(/\\.[^.]+$/,''),'SurveyQuant_PDF'); status(state.tracerFile ? `تم اختيار ${state.tracerFile.name} (${state.tracerFile.size.toLocaleString()} بايت). اكتب أو عدّل اسم DXF قبل الضغط على استخراج وحفظ.` : 'اختر ملفًا للبدء.', 'sq162-raster-status'); });"
rep_engine(old_pdf_picker,new_pdf_picker,'PDF picker invalidates previous file')

# Add unambiguous version marker to the engine and exported API.
rep_engine("const SQ_V179_TWO_BOARD_RESET_PDF_STROKE_AND_OUTPUT_NAMES = true;",
           "const SQ_V179_TWO_BOARD_RESET_PDF_STROKE_AND_OUTPUT_NAMES = true;\n  const SQ_V180_SESSION_ISOLATION_AND_HYBRID_PDF_TRACE = true;",
           'V180 engine marker')
rep_engine("root.SurveyQuantCAD178 = api; root.SurveyQuantCAD179 = api;",
           "root.SurveyQuantCAD178 = api; root.SurveyQuantCAD179 = api; root.SurveyQuantCAD180 = api;",
           'V180 API marker')

# Replace embedded script body and append a build marker.
html=html[:m.start(2)]+engine+html[m.end(2):]
html += '\n<!-- SURVEYQUANT_V180_SESSION_ISOLATION_AND_HYBRID_PDF_TRACE -->\n'
html_path.write_text(html,encoding='utf-8')

# Save the standalone engine snapshot and adapt the verified V179 APK packager to version 180.
engine_path=root/'SurveyQuant_v1.0.180_CAD_ENGINE.js'
engine_path.write_text(engine,encoding='utf-8')
base_pack=root/'SurveyQuant_v1.0.179_PACKAGE_FREE_APK.py'
pack=root/'SurveyQuant_v1.0.180_PACKAGE_FREE_APK.py'
ps=base_pack.read_text(encoding='utf-8')
ps=ps.replace("OLD_NAME = '1.0.162'","OLD_NAME = '1.0.179'")
ps=ps.replace("NEW_NAME = '1.0.179'","NEW_NAME = '1.0.180'").replace('NEW_CODE = 179','NEW_CODE = 180')
old_mark="'SURVEYQUANT_V179_TWO_BOARD_RESET_PDF_WALL_SAVE_NAME'"
# The packager already checks V179 baseline markers. Keep them and add actual V180 runtime guards.
needle="'SURVEYQUANT_V179_TWO_BOARD_RESET_PDF_WALL_SAVE_NAME'"
if needle not in ps:
    # inspect and add after a known marker in the verification tuple
    needle="'SQ_V179_TWO_BOARD_RESET_PDF_STROKE_AND_OUTPUT_NAMES'"
if needle not in ps:
    raise SystemExit('Cannot find V179 packager marker list')
ps=ps.replace(needle,needle+",\n        'SQ_V180_SESSION_ISOLATION_AND_HYBRID_PDF_TRACE',\n        'state.sessionId++',\n        'savedCurrent',\n        'rasterPaths=svgPathsToCad',\n        'PDF مختلط:',\n        'اكتب اسم اللوحة في خانة',\n        'SurveyQuantCAD180'")
ps=ps.replace('version bumped to 1.0.179/179','version bumped to 1.0.180/180')
pack.write_text(ps,encoding='utf-8')

# Basic static postconditions and JS syntax-safe inline marker checks.
assert 'state.sessionId++' in engine
assert "clearDrawing(which);input.value=''" in engine
assert 'savedCurrent' in engine
assert 'PDF مختلط:' in engine
assert "اكتب اسم اللوحة في خانة" in engine
assert 'SURVEYQUANT_V180_SESSION_ISOLATION_AND_HYBRID_PDF_TRACE' in html
print('PASS: V180 patch applied to APK index.html and standalone CAD engine.')
print('index bytes:',html_path.stat().st_size,'engine bytes:',engine_path.stat().st_size)
