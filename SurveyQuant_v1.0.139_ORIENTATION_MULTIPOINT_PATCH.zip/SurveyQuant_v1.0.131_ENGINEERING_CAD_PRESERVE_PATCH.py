#!/usr/bin/env python3
"""SurveyQuant v1.0.131 engineering CAD preservation and layer quantity fix."""
from __future__ import annotations
import argparse
import re
import tempfile
import zipfile
from pathlib import Path


def replace_once(s: str, old: str, new: str, label: str) -> str:
    n = s.count(old)
    if n != 1:
        raise SystemExit(f'ERROR {label}: expected one exact match, found {n}')
    return s.replace(old, new, 1)


def replace_function(s: str, name: str, next_name: str, new_function: str) -> str:
    start_token = name
    start = s.find(start_token)
    if start < 0:
        raise SystemExit(f'ERROR: function not found: {name}')
    # The caller supplies the next top-level function marker, so only one complete function is replaced.
    end = s.find(next_name, start + len(start_token))
    if end < 0:
        raise SystemExit(f'ERROR: boundary not found after {name}: {next_name}')
    return s[:start] + new_function.rstrip() + '\n' + s[end:]


def patch_html(s: str) -> str:
    if 'SURVEYQUANT_V131_ENGINEERING_CAD_PRESERVE' in s:
        raise SystemExit('V131 patch already applied')

    # 1) Remove the unreliable lowest closed/perimeter contour as a design-level method.
    option_pattern = re.compile(r'\s*<option value="auto_low">[^<]*</option>')
    s, n = option_pattern.subn('', s)
    if n != 3:
        raise SystemExit(f'ERROR: expected exactly 3 auto_low options to remove, found {n}')

    # 2) Make single-surface quantities use the complete valid TIN and a deliberate design level.
    load_fn = r'''async function loadAndAnalyze(){
 try{
  const f=document.getElementById('quantFileInput').files[0];if(!f)return alert('اختر الملف أولاً');
  const model=await parseFile(f);cadModel=model;layerUI(model,'cadLayers');
  let pts=(model.points||[]).slice();const picks=selectedLayers();
  if((model.source==='DXF'||model.source==='DWG')&&pts.length<3){
    const derived=surfacePointsFromModel(model);pts=derived.map(p=>({id:p.id,e:p.e,n:p.n,z:p.z,layer:p.layer||'0'}));
  }
  if(model.source==='DXF'||model.source==='DWG')pts=pts.filter(p=>picks.has(p.layer)||!picks.size);
  if(pts.length<3)throw new Error('عدد نقاط المناسيب بعد اختيار Layers أقل من 3. اختر Layer النقاط الصحيحة.');
  points=pts;const raw=delaunay(points);
  const boundaryLayers=[...(model.polylines||[]).filter(p=>p.closed&&p.vertices.length>=3&&p.layer&&picks.has(p.layer))].map(p=>p.vertices.map(v=>({x:v.x,y:v.y})));
  const me=parseFloat(document.getElementById('maxEdge').value)||0;triangles=raw.filter(t=>triangleAllowed(t,boundaryLayers,me));
  if(!triangles.length)throw new Error('لم يتم تكوين TIN صالح. تحقق من النقاط أو Boundary/Max Edge.');
  const zs=points.map(p=>Number(p.z)).filter(Number.isFinite);if(zs.length<3)throw new Error('نقاط المناسيب لا تحتوي على ثلاث قيم Z رقمية صالحة على الأقل.');
  const min=Math.min(...zs),max=Math.max(...zs),avg=zs.reduce((a,b)=>a+b,0)/zs.length;
  const lt=document.getElementById('levelType').value;let target=avg;
  if(lt==='min')target=min;else if(lt==='max')target=max;
  else if(lt==='manual'){target=parseFloat(document.getElementById('targetLevel').value);if(!Number.isFinite(target))throw new Error('أدخل منسوب التصميم اليدوي.');}
  else if(lt!=='avg')throw new Error('طريقة الحصر المحددة غير مدعومة. اختر المتوسط أو أقل/أعلى منسوب أو منسوبًا يدويًا.');
  const ci=Math.max(.01,parseFloat(document.getElementById('contourInterval').value)||1),lo=Math.ceil((min+1e-10)/ci)*ci,hi=Math.floor((max-1e-10)/ci)*ci;
  contourSegments=[];for(let z=lo;z<=hi+1e-8;z+=ci){for(const t of triangles){const seg=contourForTriangle(t,z);if(seg)contourSegments.push({...seg,z});}}
  let hArea=0,sArea=0,cut=0,fill=0;
  for(const t of triangles){
   const tri=[t.a,t.b,t.c],ha=Math.abs(orient(tri[0],tri[1],tri[2]))/2;if(ha<EPS)continue;hArea+=ha;
   const v1={x:tri[1].x-tri[0].x,y:tri[1].y-tri[0].y,z:tri[1].z-tri[0].z},v2={x:tri[2].x-tri[0].x,y:tri[2].y-tri[0].y,z:tri[2].z-tri[0].z};
   const cx=v1.y*v2.z-v1.z*v2.y,cy=v1.z*v2.x-v1.x*v2.z,cz=v1.x*v2.y-v1.y*v2.x;sArea+=Math.sqrt(cx*cx+cy*cy+cz*cz)/2;
   cut+=volumePart(clipByZ(tri,target,true),target);fill+=volumePart(clipByZ(tri,target,false),target);
  }
  if(hArea<=EPS)throw new Error('المساحة الأفقية للسطح تساوي صفرًا؛ راجع إحداثيات النقاط وحدود الـ TIN.');
  const stats={points:points.length,tris:triangles.length,min,max,target,hArea,sArea,cut,fill};lastQuantStats=stats;
  document.getElementById('statsBox').innerHTML=`النقاط: <b>${stats.points}</b> | المثلثات: <b>${stats.tris}</b> | الكنتور: <b>${contourSegments.length}</b><br>أقل منسوب: <b>${stats.min.toFixed(3)}</b> | أعلى: <b>${stats.max.toFixed(3)}</b> | التصميم: <b>${stats.target.toFixed(3)}</b><br>المساحة الأفقية: <b>${stats.hArea.toFixed(3)} م²</b> | مساحة السطح 3D: <b>${stats.sArea.toFixed(3)} م²</b>`;
  document.getElementById('cutVolume').textContent='الحفر Cut: '+cut.toFixed(3)+' م³';document.getElementById('fillVolume').textContent='الردم Fill: '+fill.toFixed(3)+' م³';document.getElementById('quantResults').style.display='block';document.getElementById('quantExportTools').style.display='grid';
  try{generatedQuantDXF=buildDXF(cadModel,triangles,contourSegments,stats);}catch(boardErr){console.warn('Quant board fallback:',boardErr);const fallback=[];const ps=getPointStyleSettings();for(const p of points)addPointDetailEntities(fallback,p,ps);for(const t of triangles)fallback.push({type:'3DFACE',layer:'TIN_SURFACE',vertices:[t.a,t.b,t.c,t.c]});for(const q of contourSegments)fallback.push({type:'LINE',layer:q.layer||'CONTOURS',color:q.color||hexToCadAci(sqSettingsFor().contourColor),a:{x:q.a.x,y:q.a.y,z:q.z},b:{x:q.b.x,y:q.b.y,z:q.z}});generatedQuantDXF=buildR12FromEntities(fallback);}
  if(!validateGeneratedDXF(generatedQuantDXF))throw new Error('تم الحساب، لكن ملف اللوحة الناتج غير صالح.');
 }catch(e){console.error(e);alert('تعذر إنشاء لوحة حساب الكميات: '+(e?.message||e));}
}'''
    s = replace_function(s, 'async function loadAndAnalyze(){', 'function validateGeneratedDXF(content){', load_fn)

    # 3) Remove the unreliable auto-low calculation from comparison helpers.
    resolve_fn = r'''function resolveComparisonTarget(points,mode,inputId,interval){
 const zs=points.map(p=>Number(p.z)).filter(Number.isFinite);if(!zs.length)throw new Error('لا توجد مناسيب كافية لحساب سطح الطبقة.');
 const m=String(mode||'avg');if(m==='min')return Math.min(...zs);if(m==='max')return Math.max(...zs);
 if(m==='manual'){const v=Number(document.getElementById(inputId)?.value);if(!Number.isFinite(v))throw new Error('أدخل المنسوب اليدوي للطبقة.');return v;}
 if(m==='auto_low')throw new Error('تم حذف الحصر باستخدام أقل خط كنتور محيطي لأنه قد ينتج كمية غير دقيقة. اختر المتوسط أو أقل/أعلى منسوب أو منسوبًا يدويًا.');
 if(m!=='avg')throw new Error('طريقة تحديد المنسوب غير صالحة.');
 return zs.reduce((a,b)=>a+b,0)/zs.length;
}'''
    s = replace_function(s, 'function resolveComparisonTarget(points,mode,inputId,interval){', 'function quantityAgainstLevel(', resolve_fn)

    standalone_fn = r'''function calculateStandaloneSurfaceStats(model,typeId,targetId){
 const pts=surfacePointsFromModel(model);
 if(pts.length<3)throw new Error('كل طبقة يجب أن تحتوي على 3 نقاط مناسيب على الأقل للحصر المستقل.');
 const tris=delaunay(pts);if(!tris.length)throw new Error('تعذر تكوين TIN للحصر المستقل لإحدى الطبقتين.');
 const zs=pts.map(p=>Number(p.z)).filter(Number.isFinite);if(zs.length<3)throw new Error('إحدى الطبقتين لا تحتوي على ثلاث مناسيب رقمية صالحة على الأقل.');
 const min=Math.min(...zs),max=Math.max(...zs),avg=zs.reduce((a,b)=>a+b,0)/zs.length;
 const typeEl=document.getElementById(typeId),targetEl=document.getElementById(targetId),lt=typeEl?.value||'avg';let target=avg;
 if(lt==='min')target=min;else if(lt==='max')target=max;
 else if(lt==='manual'){target=Number.parseFloat(targetEl?.value);if(!Number.isFinite(target))throw new Error('أدخل المنسوب اليدوي لكل طبقة على حدة.');}
 else if(lt==='auto_low')throw new Error('تم حذف الحصر باستخدام أقل خط كنتور محيطي لأنه قد ينتج كمية غير دقيقة. اختر المتوسط أو أقل/أعلى منسوب أو منسوبًا يدويًا.');
 else if(lt!=='avg')throw new Error('طريقة تحديد منسوب الطبقة غير صالحة.');
 let hArea=0,sArea=0,cut=0,fill=0,usedTris=0;
 for(const t of tris){
  const tri=[t.a,t.b,t.c],ha=Math.abs(orient(tri[0],tri[1],tri[2]))/2;if(ha<EPS)continue;hArea+=ha;
  const v1={x:tri[1].x-tri[0].x,y:tri[1].y-tri[0].y,z:tri[1].z-tri[0].z},v2={x:tri[2].x-tri[0].x,y:tri[2].y-tri[0].y,z:tri[2].z-tri[0].z};
  const cx=v1.y*v2.z-v1.z*v2.y,cy=v1.z*v2.x-v1.x*v2.z,cz=v1.x*v2.y-v1.y*v2.x;sArea+=Math.sqrt(cx*cx+cy*cy+cz*cz)/2;
  cut+=volumePart(clipByZ(tri,target,true),target);fill+=volumePart(clipByZ(tri,target,false),target);usedTris++;
 }
 if(!usedTris||hArea<=EPS)throw new Error('لا توجد مساحة أفقية قابلة للحصر في الطبقة المحددة.');
 return{points:pts.length,tris:tris.length,usedTris,min,max,avg,target,levelType:lt,hArea,sArea,cut,fill,net:fill-cut};
}'''
    s = replace_function(s, 'function calculateStandaloneSurfaceStats(model,typeId,targetId){', 'function attachComparisonQuantities(', standalone_fn)

    compare_fn = r'''function compareSurfaceVolumes(a,b){
 const before=surfacePointsFromModel(a),after=surfacePointsFromModel(b);
 if(before.length<3||after.length<3)throw new Error('كل طبقة يجب أن تحتوي على 3 نقاط مناسيب على الأقل.');
 const bt=delaunay(before),at=delaunay(after);if(!bt.length||!at.length)throw new Error('تعذر تكوين سطح مثلثي لإحدى الطبقتين.');
 const hullA=surfaceHull(a),hullB=surfaceHull(b);
 if(hullA.length<3||hullB.length<3)throw new Error('حدود إحدى الطبقتين غير كافية للمقارنة.');
 return sqCompareSurfaceTriangles(hullA,hullB,bt,at,before,after);
}'''
    s = replace_function(s, 'function compareSurfaceVolumes(a,b){', 'function compareSurfaceVolumesWithHulls(', compare_fn)

    # 4) Ensure the comparison report visibly lists separate full-layer quantities before the shared-area comparison.
    s = replace_once(s,
        "const qa=st.standaloneBefore,qb=st.standaloneAfter,methodName={avg:'متوسط المناسيب',min:'أقل منسوب',max:'أعلى منسوب',auto_low:'أقل خط كنتور محيطي',manual:'منسوب يدوي'};",
        "const qa=st.standaloneBefore,qb=st.standaloneAfter,methodName={avg:'متوسط المناسيب',min:'أقل منسوب',max:'أعلى منسوب',manual:'منسوب يدوي'};",
        'comparison label methods')
    s = replace_once(s,
        "const fmtLayer=(title,q)=>`<b>${title}</b><br>طريقة الحصر: <b>${escapeHtml(methodName[q.levelType]||q.levelType)}</b> | منسوب الحصر: <b>${q.target.toFixed(3)} م</b><br>المساحة الأفقية: <b>${q.hArea.toFixed(3)} م²</b> | مساحة السطح 3D: <b>${q.sArea.toFixed(3)} م²</b><br>الحفر: <b>${q.cut.toFixed(3)} م³</b> | الردم: <b>${q.fill.toFixed(3)} م³</b> | صافي حصر الطبقة: <b>${q.net.toFixed(3)} م³</b>`;",
        "const fmtLayer=(title,q)=>`<b>${title}</b><br>النقاط: <b>${q.points}</b> | مثلثات TIN: <b>${q.tris}</b><br>طريقة الحصر المستقل: <b>${escapeHtml(methodName[q.levelType]||q.levelType)}</b> | منسوب الحصر: <b>${q.target.toFixed(3)} م</b><br>المساحة الأفقية الكاملة: <b>${q.hArea.toFixed(3)} م²</b> | مساحة السطح 3D: <b>${q.sArea.toFixed(3)} م²</b><br>الحفر: <b>${q.cut.toFixed(3)} م³</b> | الردم: <b>${q.fill.toFixed(3)} م³</b> | صافي حصر الطبقة: <b>${q.net.toFixed(3)} م³</b>`;",
        'independent layer quantity detail')
    s = replace_once(s,
        "document.getElementById('quantCompareSummary').innerHTML=fmtLayer('حصر الطبقة الأولى مستقلًا',qa)+'<hr>'+fmtLayer('حصر الطبقة الثانية مستقلًا',qb)+`<hr><b>المقارنة الفعلية بين الطبقتين على المساحة المشتركة</b><br>",
        "document.getElementById('quantCompareSummary').innerHTML='<b>أولًا: حصر كل طبقة كاملة بصورة مستقلة</b><br>يُحسب حجم الطبقة الأولى وحجم الطبقة الثانية كلٌّ على حدة، ثم تُعرض المقارنة الفعلية بينهما على المساحة المشتركة.'+'<hr>'+fmtLayer('حصر الطبقة الأولى مستقلًا',qa)+'<hr>'+fmtLayer('حصر الطبقة الثانية مستقلًا',qb)+`<hr><b>ثانيًا: المقارنة الفعلية بين الطبقتين على المساحة المشتركة</b><br>",
        'independent then shared comparison report')

    # 5) CAD output: when a source DXF (including the converter's DXF from DWG) exists, use its bytes as the base.
    old_quant = r'''async function downloadQuantDXF(){
 if(!generatedQuantDXF)return alert('اعمل المعالجة أولاً');
 try{
   if(!validateGeneratedDXF(generatedQuantDXF)) generatedQuantDXF=buildDXF(cadModel,triangles,contourSegments,lastQuantStats||{points:points.length,tris:triangles.length,min:0,max:0,target:0,hArea:0,sArea:0,cut:0,fill:0});
   if(!validateGeneratedDXF(generatedQuantDXF)) throw new Error('ملف DXF الهندسي لم يجتز فحص البنية.');
   try{await safeDownloadFile(generatedQuantDXF,'SurveyQuant_PRO_Surface.dxf','application/dxf',false);}
   catch(first){
     const fallback=[];for(const p of points||[])fallback.push({type:'POINT',layer:'SURVEY_POINTS',position:{x:p.e,y:p.n,z:p.z}});for(const t of triangles||[])fallback.push({type:'3DFACE',layer:'TIN_SURFACE',vertices:[t.a,t.b,t.c]});for(const q of contourSegments||[])fallback.push({type:'LINE',layer:'CONTOURS',a:{x:q.a.x,y:q.a.y,z:q.z},b:{x:q.b.x,y:q.b.y,z:q.z}});const r12=buildR12FromEntities(fallback);if(!validateGeneratedDXF(r12))throw first;await safeDownloadFile(r12,'SurveyQuant_PRO_Surface_R12.dxf','application/dxf',false);
   }
 }catch(e){console.error(e);alert('تعذر إنشاء/حفظ ملف DXF: '+(e?.message||e));}
}'''
    new_quant = r'''async function downloadQuantDXF(){
 if(!generatedQuantDXF)return alert('اعمل المعالجة أولاً');
 try{
   if(cadModel?.rawDXFBytes instanceof Uint8Array){
    const board=buildQuantBoardModel(cadModel,triangles,contourSegments,lastQuantStats||{points:points.length,tris:triangles.length,min:0,max:0,target:0,hArea:0,sArea:0,cut:0,fill:0});
    // Keep every source entity untouched; only add computed TIN/contour/table entities. Original points and closed boundaries are already in the source.
    const skip=new Set(['SURVEY_POINTS','POINT_STYLE','POINT_LABELS','POINT_IDS','POINT_ELEVATIONS','BOUNDARY']);
    const additions=board.entities.filter(e=>!skip.has(String(e.layer||'').toUpperCase()));
    const output=mergeProjectionDxfPreservingReference(cadModel.rawDXFBytes,additions);
    const issue=inspectPreservedReferenceDXF(new TextDecoder('windows-1252').decode(output));if(issue)throw new Error(issue+' تم إيقاف التصدير لحماية اللوحة الأصلية.');
    await safeDownloadFile(output,'SurveyQuant_PRO_Surface_CAD_PRESERVED.dxf','application/dxf',false);return;
   }
   if(!validateGeneratedDXF(generatedQuantDXF)) generatedQuantDXF=buildDXF(cadModel,triangles,contourSegments,lastQuantStats||{points:points.length,tris:triangles.length,min:0,max:0,target:0,hArea:0,sArea:0,cut:0,fill:0});
   if(!validateGeneratedDXF(generatedQuantDXF)) throw new Error('ملف DXF الهندسي لم يجتز فحص البنية.');
   try{await safeDownloadFile(generatedQuantDXF,'SurveyQuant_PRO_Surface.dxf','application/dxf',false);}
   catch(first){
     const fallback=[];for(const p of points||[])fallback.push({type:'POINT',layer:'SURVEY_POINTS',position:{x:p.e,y:p.n,z:p.z}});for(const t of triangles||[])fallback.push({type:'3DFACE',layer:'TIN_SURFACE',vertices:[t.a,t.b,t.c,t.c]});for(const q of contourSegments||[])fallback.push({type:'LINE',layer:'CONTOURS',a:{x:q.a.x,y:q.a.y,z:q.z},b:{x:q.b.x,y:q.b.y,z:q.z}});const r12=buildR12FromEntities(fallback);if(!validateGeneratedDXF(r12))throw first;await safeDownloadFile(r12,'SurveyQuant_PRO_Surface_R12.dxf','application/dxf',false);
   }
 }catch(e){console.error(e);alert('تعذر إنشاء/حفظ ملف DXF: '+(e?.message||e));}
}'''
    s = replace_once(s, old_quant, new_quant, 'quant output raw CAD overlay')

    # Profile export should preserve the converted DXF stream regardless of whether the input was DXF or DWG.
    s = replace_once(s,
        "if(String(model?.source||'').toUpperCase()==='DXF'&&model.rawDXFBytes instanceof Uint8Array){\n  const output=mergeProjectionDxfPreservingReference(model.rawDXFBytes,additions);",
        "if(model?.rawDXFBytes instanceof Uint8Array){\n  const output=mergeProjectionDxfPreservingReference(model.rawDXFBytes,additions);",
        'profile native base for DXF and converted DWG')
    s = replace_once(s,
        "if(String(model?.source||'').toUpperCase()==='DXF'&&content instanceof Uint8Array){\n  const issue=inspectPreservedReferenceDXF(new TextDecoder('windows-1252').decode(content));",
        "if(model?.rawDXFBytes instanceof Uint8Array&&content instanceof Uint8Array){\n  const issue=inspectPreservedReferenceDXF(new TextDecoder('windows-1252').decode(content));",
        'profile output preservation validation')

    # Imported-DWG projection must use converted raw DXF bytes as the reference, not serialize parsed entities.
    s = replace_once(s,
        "if(String(targetModel.source).toUpperCase()==='DXF'&&targetModel.rawDXFBytes instanceof Uint8Array){\n    droppedDXF=mergeProjectionDxfPreservingReference(targetModel.rawDXFBytes,additions);",
        "if(targetModel.rawDXFBytes instanceof Uint8Array){\n    droppedDXF=mergeProjectionDxfPreservingReference(targetModel.rawDXFBytes,additions);",
        'DWG projection preserves converter output instead of redrawing')
    s = replace_once(s,
        "${String(targetModel.source).toUpperCase()==='DXF'?'تم الحفاظ على بايتات وعناصر وخصائص اللوحة المرجعية الأصلية كما هي؛ أُضيفت العناصر الجديدة فقط دون إعادة رسم عناصر المرجع.':'المرجع DWG وتم تحويله إلى DXF؛ قد لا يمكن الحفاظ على كل بيانات DWG غير المدعومة عند التحويل.'}",
        "${String(targetModel.source).toUpperCase()==='DXF'?'تم الحفاظ على بايتات وعناصر وخصائص اللوحة المرجعية الأصلية كما هي؛ أُضيفت العناصر الجديدة فقط دون إعادة رسم عناصر المرجع.':'تم استخدام بايتات DXF الناتجة مباشرة من تحويل DWG كأساس وإضافة العناصر فوقها دون إعادة رسم الكيانات المقروءة؛ لا يمكن لملف DXF الناتج أن يكون نسخة ثنائية مطابقة لملف DWG الأصلي، وقد تبقى قيود التحويل على الكيانات الخاصة.'}",
        'projection preservation status text')

    # Profile DXF button must use the byte-preserving merge path, not export a reconstructed model.
    s = replace_once(s,
        "function exportProfileDrawing(k){return exportModelDrawing(profileExportModel(),'مكتب فني مساحة - Levels','SurveyQuant_Levels_Drawing',k)}",
        "function exportProfileDrawing(k){if(k==='dxf')return downloadProfileDXF();return exportModelDrawing(profileExportModel(),'مكتب فني مساحة - Levels','SurveyQuant_Levels_Drawing',k)}",
        'profile export dispatch')

    # Generic CAD export passes through the untouched DXF bytes for DXF, or for the converter's DXF representation of DWG.
    old_export = """async function exportModelDrawing(model,title,base,kind){
 if(!model||!(model.entities||[]).length)return alert('اقرأ اللوحة أو أنشئ النتائج أولاً.');
 let result;
 if(kind==='dxf') result=await safeDownloadFile(buildR12FromEntities(model.entities),base+'.dxf','application/dxf',false);
 else { const c=renderModelCanvas(model,title),d=c.toDataURL('image/jpeg',.84); if(kind==='jpg') result=await safeDownloadFile(dataUrlBytes(d),base+'.jpg','image/jpeg',false); else if(kind==='pdf') result=await safeDownloadFile(pdfFromJpeg(d,c.width,c.height),base+'.pdf','application/pdf',false); else return; }
 return result;
}"""
    new_export = """async function exportModelDrawing(model,title,base,kind){
 if(!model)return alert('اقرأ اللوحة أو أنشئ النتائج أولاً.');
 if(kind==='dxf'&&model.rawDXFBytes instanceof Uint8Array){return safeDownloadFile(model.rawDXFBytes.slice(),base+'.dxf','application/dxf',false);}
 if(!(model.entities||[]).length)return alert('اقرأ اللوحة أو أنشئ النتائج أولاً.');
 let result;
 if(kind==='dxf') result=await safeDownloadFile(buildR12FromEntities(model.entities),base+'.dxf','application/dxf',false);
 else { const c=renderModelCanvas(model,title),d=c.toDataURL('image/jpeg',.84); if(kind==='jpg') result=await safeDownloadFile(dataUrlBytes(d),base+'.jpg','image/jpeg',false); else if(kind==='pdf') result=await safeDownloadFile(pdfFromJpeg(d,c.width,c.height),base+'.pdf','application/pdf',false); else return; }
 return result;
}"""
    s = replace_once(s, old_export, new_export, 'generic export raw CAD bytes')

    # 6) Stop drawing the same composite entities a second time in the orientation preview.
    old_preview = r'''function parsePreview(bytes){
 const api=window.__sqManualOrientation109;let base=null,primaryError=null;try{base=api.parseDrawing(bytes);}catch(e){primaryError=e;}
 const parsed=splitPairs(bytes),all=sectionRecords(parsed.pairs,'ENTITIES'),blocks=blockDefinitions(parsed.pairs),usedFallback=!base;const parsedLayers=layerDefinitions(parsed.pairs);
 if(!base)base={segs:[],anchors:[],texts:[],bounds:{minX:Infinity,minY:Infinity,maxX:-Infinity,maxY:-Infinity},entityCount:all.length,unsupported:0};if(!base.segs)base.segs=[];if(!base.anchors)base.anchors=[];if(!base.texts)base.texts=[];base.layers=base.layers||parsedLayers;
 const extraTypes=new Set(['DIMENSION','ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH','SURFACE','HATCH','MLEADER','MLINE','TABLE','IMAGE','WIPEOUT','HELIX','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY']);
 const addGeometry=g=>{base.anchors.push(...g.pts);base.segs.push(...g.segments);base.texts.push(...g.texts);};
 for(const rec of all){if(usedFallback){addGeometry(geometryInWorld(rec,blocks));if(extraTypes.has(rec.type))base.unsupported=(base.unsupported||0)+1;continue;}if(!extraTypes.has(rec.type))continue;const g=geometryInWorld(rec,blocks);if(!g.pts.length&&!g.segments.length&&!g.texts.length)continue;addGeometry(g);base.unsupported=(base.unsupported||0)+1;}
 if(!all.length)throw new Error(primaryError?.message||'لم يتم العثور على كيانات قابلة للقراءة في قسم ENTITIES داخل DXF.');const pts=[];for(const seg of base.segs)pts.push(seg.a,seg.b);for(const p of base.anchors)pts.push(p);for(const tx of base.texts)if(tx.p)pts.push(tx.p);
 if(pts.length){let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;for(const p of pts){minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);}if(maxX-minX<1e-9){minX-=.5;maxX+=.5;}if(maxY-minY<1e-9){minY-=.5;maxY+=.5;}base.bounds={minX,minY,maxX,maxY};}
 else{base.bounds={minX:0,minY:0,maxX:1,maxY:1};base.previewWarning='تعذر رسم بعض أنواع العناصر هندسيًا في المعاينة؛ بيانات DXF الأصلية محفوظة. جرّب حفظ نسخة DXF نصية من برنامج CAD لعرض العناصر.';}
 base.entityCount=Math.max(base.entityCount||0,all.length);base.originalEntityRecords=all.length;base.recoveredPairs=parsed.recoveryCount||0;base.previewRecoveryMessage=base.recoveredPairs?'تمت استعادة المعاينة بعد تجاوز '+base.recoveredPairs+' موضعًا تالفًا في تسلسل المجموعة.':null;return base;
}'''
    new_preview = r'''function parsePreview(bytes){
 const api=window.__sqManualOrientation109;let base=null,primaryError=null;try{base=api.parseDrawing(bytes);}catch(e){primaryError=e;}
 const parsed=splitPairs(bytes),all=sectionRecords(parsed.pairs,'ENTITIES'),blocks=blockDefinitions(parsed.pairs),usedFallback=!base;const parsedLayers=layerDefinitions(parsed.pairs);
 if(!base)base={segs:[],anchors:[],texts:[],bounds:{minX:Infinity,minY:Infinity,maxX:-Infinity,maxY:-Infinity},entityCount:all.length,unsupported:0};if(!base.segs)base.segs=[];if(!base.anchors)base.anchors=[];if(!base.texts)base.texts=[];base.layers=base.layers||parsedLayers;
 const extraTypes=new Set(['DIMENSION','ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH','SURFACE','HATCH','MLEADER','MLINE','TABLE','IMAGE','WIPEOUT','HELIX','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY']);
 // The primary drawing parser already expands supported INSERT/text/curve geometry. Re-expanding records here duplicates complex lines and makes the board look exploded.
 const fallbackPreviewTypes=new Set(['LINE','POINT','LWPOLYLINE','POLYLINE','CIRCLE','ARC','TEXT','MTEXT','ATTRIB','ATTDEF']);
 if(usedFallback){for(const rec of all){if(extraTypes.has(rec.type))base.unsupported=(base.unsupported||0)+1;if(!fallbackPreviewTypes.has(rec.type))continue;const g=geometryInWorld(rec,blocks);base.anchors.push(...g.pts);base.segs.push(...g.segments);base.texts.push(...g.texts);}}
 else{for(const rec of all)if(extraTypes.has(rec.type))base.unsupported=(base.unsupported||0)+1;}
 if(!all.length)throw new Error(primaryError?.message||'لم يتم العثور على كيانات قابلة للقراءة في قسم ENTITIES داخل DXF.');const pts=[];for(const seg of base.segs)pts.push(seg.a,seg.b);for(const p of base.anchors)pts.push(p);for(const tx of base.texts)if(tx.p)pts.push(tx.p);
 if(pts.length){let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;for(const p of pts){minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);}if(maxX-minX<1e-9){minX-=.5;maxX+=.5;}if(maxY-minY<1e-9){minY-=.5;maxY+=.5;}base.bounds={minX,minY,maxX,maxY};}
 else{base.bounds={minX:0,minY:0,maxX:1,maxY:1};base.previewWarning='تعذر رسم بعض أنواع العناصر هندسيًا في المعاينة؛ بيانات DXF الأصلية محفوظة. تم الاحتفاظ بالنصوص والكيانات المدعومة دون إعادة توليد محتوى الملف.';}
 if(base.unsupported)base.previewWarning='بعض عناصر CAD المركبة أو الخاصة لم تُوسّع مرة ثانية في المعاينة منعًا لتضاعف الخطوط؛ ستظل سجلاتها الأصلية محفوظة في ملف DXF الناتج.';
 base.entityCount=Math.max(base.entityCount||0,all.length);base.originalEntityRecords=all.length;base.recoveredPairs=parsed.recoveryCount||0;base.previewRecoveryMessage=base.recoveredPairs?'تمت استعادة المعاينة بعد تجاوز '+base.recoveredPairs+' موضعًا تالفًا في تسلسل المجموعة.':null;return base;
}'''
    s = replace_once(s, old_preview, new_preview, 'orientation composite geometry single-pass')

    # Allow export and tests to identify this exact release patch.
    s = replace_once(s, "const methods={avg:'متوسط المناسيب',min:'أقل منسوب',max:'أعلى منسوب',auto_low:'أقل خط كنتور محيطي',manual:'منسوب يدوي'};", "const methods={avg:'متوسط المناسيب',min:'أقل منسوب',max:'أعلى منسوب',manual:'منسوب يدوي'};", 'comparison board method labels')
    close = s.rfind('</script>')
    if close < 0: raise SystemExit('ERROR: no closing script tag for patch marker')
    marker = '/* SURVEYQUANT_V131_ENGINEERING_CAD_PRESERVE */\n'
    s = s[:close] + marker + s[close:]
    return s


def patch_apk(source: Path, output: Path):
    if not source.is_file(): raise SystemExit(f'APK missing: {source}')
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix='sq-v131-', suffix='.apk', dir=output.parent, delete=False) as f:
        tmp = Path(f.name)
    changed = 0
    try:
        with zipfile.ZipFile(source, 'r') as zi, zipfile.ZipFile(tmp, 'w') as zo:
            for info in zi.infolist():
                if re.match(r'^META-INF/[^/]+\.(?:SF|RSA|DSA|EC|MF)$', info.filename, re.I):
                    continue
                data = zi.read(info.filename)
                if info.filename == 'assets/index.html':
                    data = patch_html(data.decode('utf-8')).encode('utf-8')
                    changed += 1
                zo.writestr(info, data)
        if changed != 1: raise SystemExit(f'Expected exactly one assets/index.html, found {changed}')
        tmp.replace(output)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise
    print(f'PATCHED APK HTML: {source} -> {output}; align and re-sign APK.')


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--html', type=Path)
    p.add_argument('--apk', type=Path)
    p.add_argument('--output', type=Path)
    a=p.parse_args()
    if a.html and not a.apk and not a.output:
        src=a.html.read_text(encoding='utf-8');out=patch_html(src);a.html.write_text(out,encoding='utf-8',newline='');print(f'PATCHED HTML {a.html}: {len(src)} -> {len(out)} chars')
    elif a.apk and a.output and not a.html: patch_apk(a.apk,a.output)
    else: p.error('use --html PATH or --apk SOURCE.apk --output OUTPUT.apk')

if __name__=='__main__': main()
