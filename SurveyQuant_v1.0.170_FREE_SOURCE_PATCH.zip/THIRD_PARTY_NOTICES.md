# Third-party software notices

This package bundles the following third-party components in the APK. Their licenses remain applicable to those components.

## LibreDWG

The application reuses the LibreDWG WASM/runtime already present in the V161 base APK. LibreDWG is distributed under GNU GPL version 3 or, at your option, any later version. Project and license information: https://www.gnu.org/software/libredwg/ . The V163 changes embed the existing WASM binary and correct how it is passed to the Emscripten worker; they do not replace the upstream library license.

## ImageTracer

- npm package: `imagetracerjs`
- version: `1.2.6`
- license: Unlicense (public-domain dedication)
- project: https://github.com/jankovicsandras/imagetracerjs
- package license and version information: https://www.npmjs.com/package/imagetracerjs

## Mozilla PDF.js

- npm package: `pdfjs-dist`
- version: `3.11.174`
- license: Apache License 2.0
- project: https://github.com/mozilla/pdf.js
- package: https://www.npmjs.com/package/pdfjs-dist

The app calls PDF.js with `isEvalSupported: false` as a mitigation for CVE-2024-4367 in versions up to 4.1.392. Do not remove this setting. Mozilla's advisory describes `isEvalSupported: false` as a workaround and identifies 4.2.67 as the patched release: https://github.com/mozilla/pdf.js/security/advisories/GHSA-wgrm-67xf-hhpq

The Workflow also copies the license files from the exact npm packages into the source patch when available.
