'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(process.argv[2]||__dirname);
const cad=require(path.join(root,'SurveyQuant_v1.0.177_CAD_ENGINE.js'));
const src=fs.readFileSync(path.join(root,'V188_ORIENTATION_FIDELITY_FIXTURE.dxf'));
const a={x:100,y:100},b={x:200,y:100},c={x:1000,y:2000},d={x:1000,y:2100};
const result=cad.createOrientedDxfBytes(new Uint8Array(src),[a,b,c,d]);
assert.ok(result.bytes.length>src.length*.8,'oriented DXF unexpectedly lost raw content');
const out=Buffer.from(result.bytes);
fs.writeFileSync(path.join(root,'V188_ORIENTATION_FIDELITY_OUTPUT.dxf'),out);
const before=src.toString('latin1'),after=out.toString('latin1');
for(const token of ['AXIS A-A','GRID 01','AXIS_MARK','AXIS-01','AXIS_NAME','WALLS','GRID','CIRCLE','ARC','LWPOLYLINE','HATCH','INSERT','ATTRIB','MTEXT','TEXT']){
  assert.ok(before.includes(token),`fixture missing ${token}`);
  assert.ok(after.includes(token),`transformed source lost ${token}`);
}
assert.match(after,/\nEOF\r?\n$/);
assert.equal((after.match(/\nCIRCLE\r?\n/g)||[]).length,(before.match(/\nCIRCLE\r?\n/g)||[]).length);
assert.equal((after.match(/\nARC\r?\n/g)||[]).length,(before.match(/\nARC\r?\n/g)||[]).length);
assert.equal((after.match(/\nHATCH\r?\n/g)||[]).length,(before.match(/\nHATCH\r?\n/g)||[]).length);
assert.equal((after.match(/\nINSERT\r?\n/g)||[]).length,(before.match(/\nINSERT\r?\n/g)||[]).length);
assert.ok(Math.abs(result.rotationDegrees-90)<1e-8);
console.log(JSON.stringify({rotationDegrees:result.rotationDegrees,scale:result.scale,rawBytes:src.length,outputBytes:out.length,retained:['LINE','CIRCLE','ARC','LWPOLYLINE','HATCH','INSERT','ATTRIB','TEXT','MTEXT','axis names','layer names','block name'],result:'PASS'},null,2));
