# SurveyQuant v1.0.153 Alignment Zoom / OSNAP / CAD Record Preservation Report

- Zoom limit raised from 10,000 to 100,000,000, with 2.5× and 5× buttons, mouse-wheel zoom anchored at pointer, and pinch zoom.
- Intersection OSNAP can be toggled on/off. When on, a nearby true segment intersection wins over nearest-on-segment snapping.
- Added tested finite-segment intersection math (parallel and non-crossing segments rejected).
- Alignment export continues transforming coordinate/scalar values directly in original DXF group-code records instead of reconstructing/re-drawing entities; layer tables, entity handles, XData and text strings are regression-tested as retained.
- The visual canvas remains a picking preview, not a CAD editor/render engine. Actual DWG input is converted to DXF by the bundled reader; output stays DXF because no native DWG writer is packaged.
- Automated JS syntax and unit checks must pass in workflow. Real project DWG/DXF and device QA remains required.
