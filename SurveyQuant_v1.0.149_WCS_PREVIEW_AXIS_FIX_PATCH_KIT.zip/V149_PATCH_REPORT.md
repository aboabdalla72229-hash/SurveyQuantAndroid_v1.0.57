# V149 WCS Preview / Axis Root Cause Fix

- V148 source hash was preserved as input; active dual-board orientation module patched.
- WCS/OCS basis conversion now happens before point snapping, bounds, and canvas projection.
- INSERT placement transforms include the extrusion normal and nested block coordinates.
- Axis text extraction reads OCS points into WCS and maps text direction through nested inserts.
- Non-canonical OCS files use the corrected WCS preview path before the legacy parser can supply raw local XY.
- Dual-board screen height reduced to 38vh (220-420px).
- APK version code/name updated to 149/1.0.149.

- Source SHA-256: `f7bd7964b1e52c1ecc47e84efb021faa7e55cb065b470e28e77b937fc7abbb04`
