from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from reportlab.pdfgen import canvas as pdfcanvas
from reportlab.lib.pagesizes import A4
import ezdxf, math
root=Path(__file__).resolve().parent
# CAD fixtures for the exact real HTML module/UI.
def make_dxf(path,layer,pts,extra_offset=0):
 d=ezdxf.new('R12');m=d.modelspace();d.layers.new(layer,dxfattribs={'color':3})
 m.add_polyline2d(pts,dxfattribs={'layer':layer})
 m.add_line(pts[0],pts[1],dxfattribs={'layer':layer})
 d.saveas(path)
make_dxf(root/'source_A.dxf','SOURCE_A',[(100,200),(110,200),(110,210),(100,210),(100,200)])
make_dxf(root/'source_B.dxf','SOURCE_B',[(300,500),(310,500),(310,510),(300,510),(300,500)])
(root/'alt').mkdir(exist_ok=True)
make_dxf(root/'alt'/'source_A.dxf','SOURCE_REPLACED',[(300,500),(310,500),(310,510),(300,510),(300,500)])
make_dxf(root/'target_A.dxf','TARGET_A',[(1000,2000),(1000,2020),(980,2020),(980,2000),(1000,2000)])
make_dxf(root/'target_B.dxf','TARGET_B',[(2000,3000),(2000,3020),(1980,3020),(1980,3000),(2000,3000)])
# Architectural raster plan: white field, black walls/columns, and a few openings.
W,H=1800,1300
im=Image.new('RGB',(W,H),'white');dr=ImageDraw.Draw(im)
line=(0,0,0)
# External wall shell and partitions.
dr.rectangle((90,80,1710,1210),outline=line,width=10)
dr.line((700,80,700,1210),fill=line,width=9)
dr.line((90,600,1710,600),fill=line,width=9)
dr.line((1200,600,1200,1210),fill=line,width=9)
dr.line((700,380,1200,380),fill=line,width=9)
# Door openings / openings as white cuts, small interior returns.
dr.line((700,400,700,510),fill='white',width=22)
dr.line((1190,600,1320,600),fill='white',width=22)
dr.line((280,600,410,600),fill='white',width=22)
# Structural columns, black outlines with white fill.
for cx,cy in [(160,150),(650,150),(1150,150),(1650,150),(160,550),(650,550),(1150,550),(1650,550),(160,1160),(650,1160),(1150,1160),(1650,1160)]:
 dr.rectangle((cx-28,cy-28,cx+28,cy+28),outline=line,fill='white',width=8)
# Some internal stair/shaft/fixtures represented by CAD-like detail lines.
for k in range(7):
 y=700+k*48;dr.line((1320,y,1630,y),fill=line,width=5)
dr.rectangle((800,700,1080,1030),outline=line,width=8)
dr.line((800,865,1080,865),fill=line,width=5)
# Raster notes.
try: font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',32)
except: font=None
dr.text((850,150),'RASTER WALL / COLUMN PLAN',fill=line,font=font)
image_path=root/'architectural_raster.png';im.save(image_path,dpi=(300,300))
# Mixed PDF: raster drawing + native vector dimensions/labels.
pdf_path=root/'V180_MIXED_ARCHITECTURAL_TEST.pdf'
c=pdfcanvas.Canvas(str(pdf_path),pagesize=A4)
page_w,page_h=A4
# place raster at useful scale
c.drawImage(str(image_path),40,250,width=515,height=500,mask='auto')
# genuine native PDF vector content not part of raster plan
c.setStrokeColorRGB(0,0,0);c.setLineWidth(1.3)
c.line(70,210,520,210);c.line(70,203,70,217);c.line(520,203,520,217)
c.line(70,230,70,245);c.line(520,230,520,245)
c.setFillColorRGB(0,0,0);c.setFont('Helvetica',11)
c.drawString(255,218,'4500')
c.drawString(160,120,'C-LEVEL OFFICE - VECTOR LABEL')
c.drawString(70,100,'GRID A / DIMENSION LINE / MIXED PDF TEST')
c.showPage();c.save()
print('created',pdf_path,pdf_path.stat().st_size)
# Raster-only PDF: same architectural raster, without native vector operators/text.
raster_only=root/'V180_RASTER_ONLY_TEST.pdf'
c=pdfcanvas.Canvas(str(raster_only),pagesize=A4)
c.drawImage(str(image_path),40,250,width=515,height=500,mask='auto');c.showPage();c.save()
# Vector-only PDF: CAD-like rectangle walls/columns and native annotations.
vector_only=root/'V180_VECTOR_ONLY_TEST.pdf'
c=pdfcanvas.Canvas(str(vector_only),pagesize=A4)
c.setStrokeColorRGB(0,0,0);c.setFillColorRGB(1,1,1);c.setLineWidth(2)
for x,y,w,h in [(80,600,400,15),(80,400,15,215),(465,400,15,215),(80,400,400,15),(250,500,40,40)]: c.rect(x,y,w,h,stroke=1,fill=1)
c.setFillColorRGB(0,0,0);c.setFont('Helvetica',12);c.drawString(200,680,'VECTOR ONLY OFFICE');c.drawString(90,370,'VECTOR DIMENSION 4000');c.showPage();c.save()
print('created',raster_only,raster_only.stat().st_size)
print('created',vector_only,vector_only.stat().st_size)
