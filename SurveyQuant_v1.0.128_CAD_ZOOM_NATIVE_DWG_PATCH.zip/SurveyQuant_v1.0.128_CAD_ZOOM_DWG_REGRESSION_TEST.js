#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const html = fs.readFileSync(process.argv[2] || '', 'utf8');
const active = 'fitTextSize=Math.min(10,Math.max(6,Math.abs(Number(t.height)||2.5)*m.base*0.8)),size=Math.max(1.15,fitTextSize/Math.sqrt(Math.max(1,Number(v.zoom)||1)))';
const fallback = "ctx.fillStyle='#e9c46a';const fitTextSize=Math.min(10,Math.max(6,Math.abs(Number(t.height)||2.5)*(m.scale/Math.max(0.001,zoom))*0.8));ctx.font=(Math.max(1.15,fitTextSize/Math.sqrt(Math.max(1,zoom))))+'px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);";
assert.equal(html.split(active).length-1, 1, 'active renderer formula must be present exactly once');
assert.equal(html.split(fallback).length-1, 1, 'fallback renderer formula must be present exactly once');
assert(html.includes('v.zoom=Math.max(.1584893,Math.min(100000,Number(value)||1))'), 'zoom button/slider ceiling must be 100000');
assert(html.includes('v.zoom=Math.max(.15,Math.min(100000,v.pinch.zoom*distance/v.pinch.distance))'), 'pinch zoom ceiling must be 100000');
assert(html.includes('v.zoom=Math.max(.15,Math.min(100000,v.zoom*(e.deltaY<0?1.2:1/1.2)))'), 'wheel zoom ceiling must be 100000');
assert.equal((html.match(/max="5" step="0\.01" value="0" aria-label="تكبير اللوحة حتى 100000 مرة"/g)||[]).length, 2, 'both zoom sliders must reach 100000x');
assert(html.includes('scale:base*v.zoom'), 'geometry zoom calculation must stay intact');
assert(html.includes('function metrics(v){') && html.includes('function setZoom(side,value){const v=state.views[side];if(!v)return;'), 'viewport metrics and anchored zoom setter must remain');
assert(html.includes("if(ext==='dwg')") && html.includes('lib.dwg_read_data(bytes,Types.DWG)'), 'native DWG reader must remain active for project import');
assert(html.includes("mode: 'native-dwg-pass-through'"), 'native pass-through bridge must be active');
const bridge = html.match(/<script id="sq-v117-universal-dwg-bridge">([\s\S]*?)<\/script>/i)?.[1] || '';
assert(bridge, 'universal DWG type bridge must remain embedded');
assert(!/addEventListener\(['"]change['"]/.test(bridge), 'bridge must not intercept native file-change events');
assert(!/addEventListener\(['"]drop['"]/.test(bridge), 'bridge must not replace drag/drop files');
assert(!bridge.includes('new DataTransfer()') && !bridge.includes('input.__sqV117DwgBusy'), 'global DXF replacement mechanism must be absent');
assert(html.includes('convertTargetToDxf:sqOriConvertTargetToDxf'), 'orientation-specific temporary DWG conversion must remain');
assert(html.includes('function universalTransformBytes(input,t)'), 'byte-preserving transform must remain');
function size(height, base, zoom) {
  const fit = Math.min(10, Math.max(6, Math.abs(Number(height)||2.5) * base * 0.8));
  return Math.max(1.15, fit / Math.sqrt(Math.max(1, Number(zoom)||1)));
}
const sizes = [1, 4, 16, 64].map(z => size(2.5, 0.1, z));
assert(sizes[0] >= 6 && sizes[0] <= 10, `fit font should be readable 6-10px: ${sizes}`);
assert(sizes[0] > sizes[1] && sizes[1] > sizes[2] && sizes[2] > sizes[3], `text must shrink gradually as zoom grows: ${sizes}`);
assert(sizes.every(x => x >= 1.15), `text must not collapse to V127's almost invisible 0.1px: ${sizes}`);
console.log('PASS V128: readable CAD text shrinks gradually; zoom reaches 100000x; board geometry and anchor math are unchanged; global DWG-to-DXF interception is removed while project-native DWG parsing and orientation-local conversion remain.');
