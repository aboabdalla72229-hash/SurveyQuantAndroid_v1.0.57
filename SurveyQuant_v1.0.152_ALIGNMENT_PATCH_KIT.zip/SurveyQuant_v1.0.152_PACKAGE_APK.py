#!/usr/bin/env python3
"""Inject the tested V148 HTML into the successful V146 APK and patch AndroidManifest.xml."""
from __future__ import annotations
import argparse, copy, struct, zipfile
from pathlib import Path

OLD_NAME='1.0.150'
NEW_NAME='1.0.152'
NEW_CODE=152

def read_len8(data: bytes, pos: int):
    first=data[pos]
    if first & 0x80: return (((first & 0x7F)<<8)|data[pos+1]),pos+2
    return first,pos+1

def read_len16(data: bytes, pos: int):
    first=struct.unpack_from('<H',data,pos)[0]
    if first & 0x8000:
        second=struct.unpack_from('<H',data,pos+2)[0]
        return (((first & 0x7FFF)<<16)|second),pos+4
    return first,pos+2

def read_string_pool(data: bytes, chunk_start: int, chunk_size: int, header_size: int):
    if header_size<28 or chunk_start+chunk_size>len(data): raise ValueError('invalid Android binary XML string pool')
    string_count,_,flags,strings_start,_=struct.unpack_from('<IIIII',data,chunk_start+8)
    if string_count>100000: raise ValueError('unreasonable Android XML string count')
    offsets=chunk_start+header_size; strings_base=chunk_start+strings_start; utf8=bool(flags&0x100)
    strings=[]; spans=[]
    for index in range(string_count):
        rel=struct.unpack_from('<I',data,offsets+index*4)[0]; p=strings_base+rel
        if utf8:
            _,p=read_len8(data,p); byte_len,p=read_len8(data,p); begin,end=p,p+byte_len
            strings.append(data[begin:end].decode('utf-8',errors='strict')); spans.append((begin,end,True))
        else:
            char_len,p=read_len16(data,p); begin,end=p,p+char_len*2
            strings.append(data[begin:end].decode('utf-16le',errors='strict')); spans.append((begin,end,False))
    return strings,spans

def patch_manifest(manifest: bytes) -> bytes:
    if len(manifest)<8 or struct.unpack_from('<H',manifest,0)[0]!=0x0003: raise ValueError('AndroidManifest.xml is not Android binary XML')
    result=bytearray(manifest); pos=struct.unpack_from('<H',result,2)[0]; total=struct.unpack_from('<I',result,4)[0]
    if total>len(result) or total<pos: raise ValueError('invalid Android binary XML size')
    strings=None;spans=[];chunks=[]
    while pos<total:
        if pos+8>total: raise ValueError('truncated Android XML chunk header')
        typ,header_size,chunk_size=struct.unpack_from('<HHI',result,pos)
        if chunk_size<header_size or pos+chunk_size>total: raise ValueError('invalid Android XML chunk bounds')
        chunks.append((pos,typ,header_size,chunk_size))
        if typ==0x0001: strings,spans=read_string_pool(bytes(result),pos,chunk_size,header_size)
        pos+=chunk_size
    if strings is None: raise ValueError('Android XML string pool not found')
    names=[i for i,v in enumerate(strings) if v==OLD_NAME]
    if not names and NEW_NAME not in strings: raise ValueError(f'manifest does not contain {OLD_NAME} or {NEW_NAME}')
    for idx in names:
        begin,end,is_utf8=spans[idx]; encoded=NEW_NAME.encode('utf-8' if is_utf8 else 'utf-16le')
        if len(encoded)!=end-begin: raise ValueError('versionName replacement changes string-pool byte length')
        result[begin:end]=encoded; strings[idx]=NEW_NAME
    fields=[]
    for chunk_pos,typ,_,chunk_size in chunks:
        if typ!=0x0102 or chunk_size<36: continue
        node_name_idx=struct.unpack_from('<I',result,chunk_pos+20)[0]
        if node_name_idx>=len(strings) or strings[node_name_idx]!='manifest': continue
        attr_start=struct.unpack_from('<H',result,chunk_pos+24)[0]; attr_size=struct.unpack_from('<H',result,chunk_pos+26)[0]; attr_count=struct.unpack_from('<H',result,chunk_pos+28)[0]
        if attr_size<20 or attr_count>1024: raise ValueError('invalid manifest attribute table')
        first=chunk_pos+16+attr_start
        for n in range(attr_count):
            at=first+n*attr_size; name_idx=struct.unpack_from('<I',result,at+4)[0]
            if name_idx<len(strings) and strings[name_idx]=='versionCode':
                vsize=struct.unpack_from('<H',result,at+12)[0]; vtype=result[at+15]
                if vsize<8 or vtype not in (0x10,0x11): raise ValueError('manifest versionCode is not integer')
                fields.append(at+16)
    if len(fields)!=1: raise ValueError(f'expected exactly one versionCode field, found {len(fields)}')
    struct.pack_into('<I',result,fields[0],NEW_CODE)
    return bytes(result)

def package_apk(apk_in: Path,apk_out: Path,html_in: Path):
    if not apk_in.is_file() or apk_in.stat().st_size==0: raise ValueError('V148 base APK missing or empty')
    html_bytes=html_in.read_bytes(); html=html_bytes.decode('utf-8')
    requirements = [
        'const SQ_APP_VERSION_CODE = 152;',
        'id="sq152-alignment-core"',
        'id="sq152-alignment-command"',
        'function solveAlignment',
        'function transformDxfBytes',
        'window.parseFile = parseFile;',
        'await LibreDwg.create(sqDwgWasmRuntimePath())',
        'sq152Overlay',
        'window.__sqAlignment152',
        'surveyquant-v152-fresh-alignment-session',
    ]
    missing=[x for x in requirements if x not in html]
    if missing: raise ValueError('tested V150 HTML is missing required guards: '+', '.join(missing))
    apk_out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(apk_in,'r') as zin:
        names=[x.filename for x in zin.infolist()]
        if names.count('assets/index.html')!=1 or names.count('AndroidManifest.xml')!=1: raise ValueError('APK must contain one assets/index.html and manifest')
        seen=set()
        with zipfile.ZipFile(apk_out,'w',allowZip64=True) as zout:
            for info in zin.infolist():
                name=info.filename
                if name in seen: raise ValueError('duplicate APK entry: '+name)
                seen.add(name); upper=name.upper()
                if upper.startswith('META-INF/') and (upper.endswith('.SF') or upper.endswith('.RSA') or upper.endswith('.DSA') or upper.endswith('.EC') or upper.endswith('MANIFEST.MF')): continue
                data=zin.read(name)
                if name=='assets/index.html': data=html_bytes
                elif name=='AndroidManifest.xml': data=patch_manifest(data)
                zout.writestr(copy.copy(info),data)
    with zipfile.ZipFile(apk_out,'r') as check:
        if check.read('assets/index.html')!=html_bytes: raise ValueError('APK HTML differs from tested V152 HTML')
        if 'assets/libredwg-writer/wasm/libredwg-web.wasm' not in check.namelist(): raise ValueError('APK lost the local DWG WASM engine')
        if patch_manifest(check.read('AndroidManifest.xml'))!=check.read('AndroidManifest.xml'): raise ValueError('APK manifest not V152')
    print('PASS V152 APK package: standalone Alignment command injected, legacy orientation modules removed, DWG WASM retained, versionName 1.0.152/versionCode 152 set; APK must be signed after packaging.')

def main():
    p=argparse.ArgumentParser(); p.add_argument('--apk-input',type=Path,required=True); p.add_argument('--apk-output',type=Path,required=True); p.add_argument('--html-to-inject',type=Path,required=True); a=p.parse_args(); package_apk(a.apk_input,a.apk_output,a.html_to_inject)
if __name__=='__main__': main()
