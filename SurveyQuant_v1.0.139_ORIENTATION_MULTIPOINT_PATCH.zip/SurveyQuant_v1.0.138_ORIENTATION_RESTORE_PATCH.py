#!/usr/bin/env python3
"""V138: detect CAD-board inputs across existing and dynamically-created projects.

Patches only the shared V117/V126 DWG picker gate in HTML, or the same asset in an APK.
The gate expands accepted file types and leaves selected DWG files to the app's existing
native project handler. It neither rewrites the source DWG nor redraws/replaces entities.
The orientation project's independent temporary conversion behavior remains untouched.
"""
from __future__ import annotations

import argparse
import copy
import re
import struct
import sys
import zipfile
from pathlib import Path

BRIDGE_ID = "sq-v117-universal-dwg-bridge"
MARKER = "SQ_V138_UNIVERSAL_CAD_INPUT_GATE"
TARGET_APP_VERSION_CODE = 138
TARGET_APP_VERSION_NAME = "1.0.138"
OLD_APP_VERSION_NAME = "1.0.136"

NEW_FUNCTION = r'''  function isCadInput(input) {
    /* SQ_V138_UNIVERSAL_CAD_INPUT_GATE
       Detect CAD-board inputs from file type, control identity, and nearby project labels.
       This includes file controls created after startup by separate project screens. */
    if (!input || String(input.tagName || '').toLowerCase() !== 'input' ||
        String(input.type || '').toLowerCase() !== 'file') return false;

    var id = String(input.id || '');
    var name = String(input.name || '');
    if (NON_CAD_DATA_IDS.has(id)) return false;
    if (CAD_INPUT_IDS.has(id)) return true;

    var accept = String(input.accept || '').split(',').map(function (item) {
      return item.trim().toLowerCase();
    }).filter(Boolean);
    var explicitCad = accept.some(function (item) {
      return item === '.dwg' || item === '.dxf' ||
        item === 'application/dwg' || item === 'application/x-dwg' ||
        item === 'application/dxf' || item === 'application/x-dxf' ||
        item === 'application/acad' || item === 'application/x-acad' ||
        item === 'image/vnd.dwg';
    });
    if (explicitCad) return true;

    var hints = [id, name, input.title || '', input.placeholder || ''];
    if (typeof input.getAttribute === 'function') {
      ['aria-label', 'data-project', 'data-role', 'data-import-kind', 'title', 'placeholder'].forEach(function (key) {
        var value = input.getAttribute(key);
        if (value) hints.push(value);
      });
    }
    try {
      Array.prototype.slice.call(input.labels || []).forEach(function (label) {
        if (label && label.textContent) hints.push(label.textContent);
      });
    } catch (_) {}
    try {
      var node = input.parentElement;
      for (var depth = 0; node && depth < 4; depth++, node = node.parentElement) {
        if (node.textContent) hints.push(String(node.textContent).slice(0, 320));
        if (node.tagName && String(node.tagName).toLowerCase() === 'body') break;
      }
    } catch (_) {}

    var context = hints.join(' ').toLowerCase().replace(/\s+/g, ' ');
    var mediaOrPointType = accept.some(function (item) {
      return /^(?:\.sdr|\.pnt|\.pt|\.csv|\.txt|\.dat|\.pdf|\.png|\.jpe?g|\.webp|\.bmp|\.gif|\.heic|\.tiff?|\.xlsx?|\.ods|\.json|\.kml|\.kmz|\.gpx|text\/plain|text\/csv|application\/pdf|image\/)/i.test(item);
    });
    var hasGenericType = accept.some(function (item) {
      return item === '*/*' || item === 'application/octet-stream';
    });
    var pointOrMediaHint = /(?:\b(?:point[\s_-]*list|point[\s_-]*file|survey[\s_-]*points|file[\s_-]*to[\s_-]*dxf|clean[\s_-]*files|clean[\s_-]*points|image|photo|picture|raster|pdf|spreadsheet|excel)\b)|(?:قائمة\s*نقاط|نقاط\s*(?:المساحة|الرفع|الإحداثيات)|ملف\s*نقاط|تنظيف\s*الملفات|صورة|صور|ملف\s*PDF)/i.test(context);
    if (pointOrMediaHint || (mediaOrPointType && !hasGenericType)) return false;

    var strongCadHint = /(?:\b(?:cad|dwg|dxf|drawing|board|blueprint|plan|projection|overlay|merge|orientation|section|concrete|quantity|grading|reference[\s_-]*board|target[\s_-]*board|source[\s_-]*board|import[\s_-]*drawing)\b)|(?:لوح|لوحة|رسم|اسقاط|إسقاط|توجيه|دمج|حصر|خرسانة|كميات|قطاع|القطاع|مرجع\s*اللوح|لوحة\s*المرجع|لوحة\s*الهدف|لوحة\s*المصدر)/i.test(context);
    if (strongCadHint) return true;

    /* Generic */
    return false;
  }'''


def restore_orientation_features(html: str) -> str:
    result = html
    def one(old: str, new: str, label: str, allow_existing: bool = False) -> None:
        nonlocal result
        if allow_existing and result.count(new) == 1 and old not in result:
            return
        count = result.count(old)
        if count != 1:
            raise SystemExit(f"ERROR V138 orientation: {label}: expected one source match, got {count}.")
        result = result.replace(old, new, 1)

    # Export the original raw DXF parser from the app's private IIFE for the axis-reader module.
    parser_api = 'window.sqExtractDxfAxisEntities = sqExtractDxfAxisEntities;'
    if parser_api not in result:
        one('window.__sqOrientTest = {solve:sqOriSolve, transformBytes:sqOriTransformBytes};',
            parser_api + '\nwindow.__sqOrientTest = {solve:sqOriSolve, transformBytes:sqOriTransformBytes};',
            'expose original DXF raw parser')

    # Restore mathematically valid scale range without arbitrary 1e-9..1e9 cutoffs.
    one("if (dRef < 1e-9 || dSrc < 1e-9) throw new Error('النقطتان في كل لوحة يجب أن تكونا مختلفتين.');",
        "if (!(dRef > 0) || !(dSrc > 0) || !Number.isFinite(dRef) || !Number.isFinite(dSrc)) throw new Error('النقطتان في كل لوحة يجب أن تكونا مختلفتين وصالحتين حسابيًا.');",
        'legacy distance guard')
    one("  if (!Number.isFinite(scale) || scale < 1e-9 || scale > 1e9) {\n    throw new Error('معامل المقياس غير منطقي. راجع وحدات وإحداثيات النقطتين.');\n  }",
        "  if (!Number.isFinite(scale) || scale <= 0) {\n    throw new Error('تعذر حساب معامل مقياس موجب وصالح من النقطتين.');\n  }",
        'legacy scale guard')
    one("if(dS<1e-8||dR<1e-8)throw new Error('النقطتان 1 و2 في كل لوحة يجب أن تكونا مختلفتين.');",
        "if(!(dS>0)||!(dR>0)||!Number.isFinite(dS)||!Number.isFinite(dR))throw new Error('النقطتان 1 و2 في كل لوحة يجب أن تكونا مختلفتين وصالحتين حسابيًا.');",
        'active board-pair distance guard')
    one("if(!Number.isFinite(scale)||scale<1e-9||scale>1e9)throw new Error('المقياس المحسوب غير منطقي. تحقق من ترتيب النقاط ووحدات اللوحتين.');",
        "if(!Number.isFinite(scale)||scale<=0)throw new Error('تعذر حساب مقياس موجب وصالح من النقطتين المتناظرتين.');",
        'active board-pair scale guard')

    # Text renders at actual drawing height times current viewport scale and zoom.
    one("const fitTextSize=Math.min(10,Math.max(6,Math.abs(Number(t.height)||2.5)*(m.scale/Math.max(0.001,zoom))*0.8));ctx.font=(Math.max(1.15,fitTextSize/Math.sqrt(Math.max(1,zoom))))+'px sans-serif';",
        "const textScreenHeight=Math.abs(Number(t.height)||2.5)*m.scale*0.8;ctx.font=(Math.max(0.75,Math.min(96,textScreenHeight)))+'px sans-serif';",
        'legacy text screen scale')
    one("const st=styleOf(v,t),fitTextSize=Math.min(10,Math.max(6,Math.abs(Number(t.height)||2.5)*m.base*0.8)),size=Math.max(1.15,fitTextSize/Math.sqrt(Math.max(1,Number(v.zoom)||1)));",
        "const st=styleOf(v,t),size=Math.max(0.75,Math.min(96,Math.abs(Number(t.height)||2.5)*m.scale*0.8));",
        'active orientation text screen scale')
    old_canvas='height:230px;min-height:230px;max-height:230px'
    if result.count(old_canvas) != 2:
        raise SystemExit(f"ERROR V138 orientation: expected two fixed 230px canvases, got {result.count(old_canvas)}.")
    result=result.replace(old_canvas,'height:430px;min-height:320px;max-height:520px')

    # Keep XLINE/RAY from inflating geometry bounds to a fixed 100000-unit extent; include them in axis detection.
    one('const segments=[],labels=[],seenSeg=new Set();',
        'const segments=[],labels=[],infiniteLines=[],seenSeg=new Set();',
        'collect infinite-axis geometry')
    old_entity = "else if(type==='XLINE'||type==='RAY'){\n      const a=e.basePoint||e.position, v=e.directionVector;\n      if(a&&v){const k=type==='RAY'?100000:100000;pushSeg({x:a.x-v.x*k,y:a.y-v.y*k},{x:a.x+v.x*k,y:a.y+v.y*k},layer,type);}\n    }"
    new_entity = "else if(type==='XLINE'||type==='RAY'){\n      const a=e.basePoint||e.position, v=e.directionVector;\n      if(a&&v&&[a.x,a.y,v.x,v.y].every(q=>Number.isFinite(Number(q)))&&Math.hypot(Number(v.x),Number(v.y))>1e-12)infiniteLines.push({basePoint:{x:Number(a.x),y:Number(a.y)},directionVector:{x:Number(v.x),y:Number(v.y)},layer,type});\n    }"
    one(old_entity,new_entity,'capture XLINE/RAY from parsed entities')
    old_raw = "else if(type==='XLINE'||type==='RAY'){\n          const a=e.basePoint,v=e.directionVector;\n          if(a&&v)pushSeg({x:a.x-v.x*100000,y:a.y-v.y*100000},{x:a.x+v.x*100000,y:a.y+v.y*100000},layer,type);\n        }"
    new_raw = "else if(type==='XLINE'||type==='RAY'){\n          const a=e.basePoint,v=e.directionVector;\n          if(a&&v&&[a.x,a.y,v.x,v.y].every(q=>Number.isFinite(Number(q)))&&Math.hypot(Number(v.x),Number(v.y))>1e-12)infiniteLines.push({basePoint:{x:Number(a.x),y:Number(a.y)},directionVector:{x:Number(v.x),y:Number(v.y)},layer,type});\n        }"
    one(old_raw,new_raw,'capture raw XLINE/RAY from CAD records')
    infinite_block = """  // Extend infinite axes to this board's geometry bounds, not a hard-coded 100000-unit extent.\n  if(infiniteLines.length){\n    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity,maxTextHeight=0;\n    const see=p=>{if(!p)return;const x=Number(p.x),y=Number(p.y);if(!Number.isFinite(x)||!Number.isFinite(y))return;minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);};\n    for(const seg of segments){see(seg.a);see(seg.b);}\n    for(const label of labels){see(label);maxTextHeight=Math.max(maxTextHeight,Number(label.height)||0);}\n    const boundsDiag=Math.hypot(maxX-minX,maxY-minY);\n    const extent=Math.max(Number.isFinite(boundsDiag)&&boundsDiag>0?boundsDiag*2:1000,maxTextHeight*20,1);\n    for(const item of infiniteLines){const p=item.basePoint,v=item.directionVector,mag=Math.hypot(v.x,v.y);if(!(mag>1e-12))continue;const dx=v.x/mag*extent,dy=v.y/mag*extent;if(item.type==='RAY')pushSeg(p,{x:p.x+dx,y:p.y+dy},item.layer,'RAY');else pushSeg({x:p.x-dx,y:p.y-dy},{x:p.x+dx,y:p.y+dy},item.layer,'XLINE');}\n  }\n"""
    one('  // Remove duplicate text anchors (normal parser + raw record fallback).',
        infinite_block+'  // Remove duplicate text anchors (normal parser + raw record fallback).',
        'extend infinite axes using board-relative length')

    # Common grid bubble labels (AS, Z1, AXIS12, Arabic-Indic digits) are valid axis names.
    label_re = re.compile(r"function sqOriLabelText\(entity\) \{[\s\S]*?\n\}")
    labels=list(label_re.finditer(result))
    if len(labels)!=1:
        raise SystemExit(f"ERROR V138 orientation: expected one axis label normalizer, got {len(labels)}.")
    label_function = r'''function sqOriLabelText(entity) {
  let t=String(entity && (entity.text??entity.string??entity.value??entity.content??entity.textString??'')||'');
  try { t=t.normalize('NFKC'); } catch (_) {}
  t=t.replace(/\\P/gi,' ').replace(/\{[^;]*;/g,' ').replace(/[{}]/g,' ').replace(/%%[dpc]/gi,' ').trim();
  t=t.replace(/[٠-٩]/g,ch=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(ch)));
  if(!t || t.length>16) return '';
  t=t.replace(/[\s._-]+/g,'').toUpperCase();
  // Permit engineering grid names such as AS, Z1, AXIS12, 1A; exclude notes and dimensions.
  if(t.length>12) return '';
  return /^[A-Z\u0600-\u06FF]{1,8}\d{0,4}$/.test(t) || /^\d{1,4}[A-Z\u0600-\u06FF]{1,6}$/.test(t) ? t : '';
}'''
    m=labels[0]
    result=result[:m.start()]+label_function+result[m.end():]
    one('const minLength=Math.max(diag*0.075,medianHeight*4,1e-7);',
        'const minLength=Math.max(diag*0.02,medianHeight*3,1e-7);',
        'axis candidate line threshold')
    one(".filter(l=>l.len>=minLength&&l.type!=='RAY'&&l.type!=='XLINE');",
        ".filter(l=>l.len>=minLength);",
        'include XLINE/RAY as intersection candidates')
    old_label_assignment = """      const endDistance=Math.min(Math.hypot(t.x-line.a.x,t.y-line.a.y),Math.hypot(t.x-line.b.x,t.y-line.b.y));\n      if(perp>tol||endDistance>Math.max(tol,line.len*0.16))continue;\n      const beyond=(u < -1e-4 || u > 1.0001);\n      const nearEnd=Math.min(Math.abs(u),Math.abs(1-u));\n      const score=perp/tol+endDistance/tol+(beyond?0:1.5+nearEnd*3);\n"""
    new_label_assignment = """      const endDistance=Math.min(Math.hypot(t.x-line.a.x,t.y-line.a.y),Math.hypot(t.x-line.b.x,t.y-line.b.y));\n      const infinite=line.type==='XLINE'||line.type==='RAY';\n      if(perp>tol||(!infinite&&endDistance>Math.max(tol,line.len*0.16)))continue;\n      if(line.type==='RAY'&&u<0)continue;\n      const beyond=(u < -1e-4 || u > 1.0001);\n      const nearEnd=Math.min(Math.abs(u),Math.abs(1-u));\n      const score=perp/tol+(infinite?Math.min(0.9,Math.abs(u-(line.type==='RAY'?0.75:0.5))*0.25):endDistance/tol+(beyond?0:1.5+nearEnd*3));\n"""
    one(old_label_assignment,new_label_assignment,'attach grid bubble labels to infinite axes')
    one('if(d<Math.PI*70/180||d>Math.PI*110/180)continue;',
        'if(d<Math.PI*20/180||d>Math.PI*160/180)continue;',
        'axis-family skew angle allowance')

    # The previous installer attached to a legacy dialog whose HTML is replaced by the live two-board UI.
    step2='id="sq110Step2" class="sqori-preview" type="button">2) اللوحة المرجعية</button></div><div id="sq110TargetScreen">'
    step2new='id="sq110Step2" class="sqori-preview" type="button">2) اللوحة المرجعية</button><button id="sq110ReadAxesBtn" class="sqori-preview" type="button">🧭 قراءة المحاور تلقائيًا</button></div><div id="sq110TargetScreen">'
    one(step2,step2new,'active orientation auto-axis button')

    axis_function = r'''function readAxesForOrientation(){
 try{
  if(!state.target||!state.reference)throw new Error('اختر وافتح اللوحة غير الموجّهة واللوحة المرجعية أولًا.');
  const axisAPI=window.__sqOriAxisAutoTest;
  if(!axisAPI||typeof axisAPI.matchIntersections!=='function')throw new Error('قارئ المحاور غير متصل بواجهة التوجيه. أغلق المشروع وافتحه مرة أخرى بعد التحديث.');
  if(typeof window.sqExtractDxfAxisEntities!=='function')throw new Error('قارئ سجلات DXF الخام غير متصل، لذلك لا يمكن فحص محاور اللوحتين.');
  const decode=bytes=>new TextDecoder('windows-1252',{fatal:false}).decode(bytes);
  const sourceModel={source:'DXF',entities:[],rawDXF:decode(state.target.bytes)};
  const referenceModel={source:'DXF',entities:[],rawDXF:decode(state.reference.bytes)};
  const matched=axisAPI.matchIntersections(referenceModel,sourceModel);
  if(!matched.best||!matched.matches||matched.matches.length<2){
   const rs=matched.ref||{},ss=matched.src||{};
   throw new Error('لم أجد تقاطعين مشتركين مسمّيين بين اللوحتين. التقاطعات المرجعية: '+(rs.intersections?.size||0)+'، غير الموجهة: '+(ss.intersections?.size||0)+'، التطابقات: '+(matched.matches?.length||0)+'. راجع أسماء المحاور قرب نهايات الشبكة، أو اختر نقطتين يدويًا باستخدام OSNAP/ID Point.');
  }
  const a=matched.best.first,b=matched.best.second;
  state.targetPoints=[a.source,b.source].map((p,i)=>({x:p.x,y:p.y,kind:'تقاطع محور آلي '+(i+1)+' '+(i===0?a.key:b.key)}));
  state.referencePoints=[a.reference,b.reference].map((p,i)=>({x:p.x,y:p.y,kind:'تقاطع محور مرجعي '+(i+1)+' '+(i===0?a.key:b.key)}));
  state.axisMatches=matched.matches.map(m=>({key:m.key,source:{x:m.source.x,y:m.source.y},reference:{x:m.reference.x,y:m.reference.y}}));
  state.active.target=0;state.active.reference=0;state.idPoint={target:null,reference:null};
  fillReadouts();if(state.views.target)draw(state.views.target);if(state.views.reference)draw(state.views.reference);
  const t=calculation();
  const errors=state.axisMatches.map(m=>{const q=t.point(m.source.x,m.source.y);return {key:m.key,value:Math.hypot(q.x-m.reference.x,q.y-m.reference.y)};});
  const rms=Math.sqrt(errors.reduce((sum,e)=>sum+e.value*e.value,0)/Math.max(1,errors.length));
  const max=errors.reduce((best,e)=>Math.max(best,e.value),0);
  showScreen('target');
  status('تمت قراءة المحاور آليًا: '+matched.matches.length+' تقاطعًا مشتركًا. أفضل نقطتين: '+a.key+' و'+b.key+'. معامل المقياس ×'+t.scale.toPrecision(10)+' | الدوران '+t.angleDeg.toFixed(8)+'° | الإزاحة X '+t.tx.toPrecision(12)+' ، Y '+t.ty.toPrecision(12)+' | انحراف تقاطعات الفحص RMS '+rms.toPrecision(8)+'، وأقصى انحراف '+max.toPrecision(8)+' بوحدات الرسم. راجع القيم ثم اضغط «توجيه وإخراج».',false);
  return {matched,t,rms,max};
 }catch(e){status((e&&e.message)?e.message:String(e),true);return null;}
}'''
    calc_anchor="function calculation(){if(!state.target||!state.reference)throw new Error('افتح اللوحة غير الموجّهة واللوحة المرجعية أولًا.');"
    one(calc_anchor,axis_function+'\n'+calc_anchor,'inject active axis-intersection reader')

    one("const state={target:null,reference:null,targetPoints:[null,null],referencePoints:[null,null],active:{target:0,reference:0},tool:{target:'pick',reference:'pick'},snapMode:{target:'auto',reference:'auto'},views:{},selectedEntity:null,selectedEntities:[],undoStack:[],redoStack:[],idPoint:{target:null,reference:null},bound:false};",
        "const state={target:null,reference:null,targetPoints:[null,null],referencePoints:[null,null],axisMatches:[],active:{target:0,reference:0},tool:{target:'pick',reference:'pick'},snapMode:{target:'auto',reference:'auto'},views:{},selectedEntity:null,selectedEntities:[],undoStack:[],redoStack:[],idPoint:{target:null,reference:null},bound:false};",
        'store axis residual observations')
    one("if(side==='target'){state.target={bytes:data.bytes,name:data.name};state.targetPoints=[null,null];state.selectedEntity=null;state.selectedEntities=[];state.undoStack=[];state.redoStack=[];updateDeleteHistoryButtons();draw(view);}else{state.reference={bytes:data.bytes,name:data.name};state.referencePoints=[null,null];}",
        "if(side==='target'){state.target={bytes:data.bytes,name:data.name};state.targetPoints=[null,null];state.axisMatches=[];state.selectedEntity=null;state.selectedEntities=[];state.undoStack=[];state.redoStack=[];updateDeleteHistoryButtons();draw(view);}else{state.reference={bytes:data.bytes,name:data.name};state.referencePoints=[null,null];state.axisMatches=[];}",
        'clear axis diagnostics when replacing boards')
    one("const i=state.active[v.side],list=v.side==='target'?state.targetPoints:state.referencePoints;list[i]={x:snap.p.x,y:snap.p.y,kind:snap.kind};",
        "const i=state.active[v.side],list=v.side==='target'?state.targetPoints:state.referencePoints;state.axisMatches=[];list[i]={x:snap.p.x,y:snap.p.y,kind:snap.kind};",
        'clear stale diagnostics on manual snap')
    one("pts[i]={...(pts[i]||{}),x,y,kind:'إحداثيات معدلة يدويًا'};const v=state.views[side];",
        "state.axisMatches=[];pts[i]={...(pts[i]||{}),x,y,kind:'إحداثيات معدلة يدويًا'};const v=state.views[side];",
        'clear stale diagnostics on manual coordinate edits')
    old_review="function review(){try{const t=calculation();status('المعاينة جاهزة: النقطة 1 تطابق النقطة 1، والنقطة 2 تطابق النقطة 2. معامل المقياس ×'+t.scale.toFixed(10)+' | الدوران '+t.angleDeg.toFixed(6)+'° | X وY دون تبديل.');return t;}catch(e){status(e.message,true);return null;}}"
    new_review="function review(){try{const t=calculation();let diagnostic='';if(Array.isArray(state.axisMatches)&&state.axisMatches.length>=2){const errs=state.axisMatches.map(m=>{const q=t.point(m.source.x,m.source.y);return Math.hypot(q.x-m.reference.x,q.y-m.reference.y);});const rms=Math.sqrt(errs.reduce((s,e)=>s+e*e,0)/errs.length),mx=Math.max(...errs);diagnostic=' | تقاطعات الفحص '+errs.length+' | RMS '+rms.toPrecision(8)+' | أقصى انحراف '+mx.toPrecision(8);}status('المعاينة جاهزة: النقطة 1 تطابق النقطة 1، والنقطة 2 تطابق النقطة 2. معامل المقياس ×'+t.scale.toPrecision(12)+' | الدوران '+t.angleDeg.toFixed(8)+'° | الإزاحة X '+t.tx.toPrecision(12)+' ، Y '+t.ty.toPrecision(12)+' | X=Easting وY=Northing دون تبديل.'+diagnostic);return t;}catch(e){status(e.message,true);return null;}}"
    one(old_review,new_review,'report shift, rotation, scale and residuals')
    one("el('sq110Preview').addEventListener('click',review);el('sq110Export').addEventListener('click',exportTarget);showScreen('target');",
        "el('sq110ReadAxesBtn').addEventListener('click',readAxesForOrientation);el('sq110Preview').addEventListener('click',review);el('sq110Export').addEventListener('click',exportTarget);showScreen('target');",
        'bind auto-axis button to active project')

    checks={
      'global raw DXF extraction API':'window.sqExtractDxfAxisEntities = sqExtractDxfAxisEntities;' in result,
      'active axis control':'id="sq110ReadAxesBtn"' in result,
      'active axis handler':'el(\'sq110ReadAxesBtn\').addEventListener(\'click\',readAxesForOrientation)' in result,
      'auto axis finder':'function readAxesForOrientation()' in result,
      'arbitrary scale caps removed':'scale<1e-9||scale>1e9' not in result and 'scale < 1e-9 || scale > 1e9' not in result,
      'text scaling follows canvas':'Math.abs(Number(t.height)||2.5)*m.scale*0.8' in result,
      'two larger viewports':result.count('height:430px;min-height:320px;max-height:520px')==2,
      'translation/rotation/scale report':"الإزاحة X" in result and "t.tx.toPrecision(12)" in result and "t.ty.toPrecision(12)" in result,
    }
    failed=[k for k,v in checks.items() if not v]
    if failed: raise SystemExit('ERROR V138 orientation postconditions failed: '+', '.join(failed))
    return result

def replace_bridge_function(html: str) -> str:
    tag = re.compile(
        r'(<script\s+id=["\']' + re.escape(BRIDGE_ID) + r'["\']\s*>)([\s\S]*?)(</script\s*>)',
        re.I,
    )
    matches = list(tag.finditer(html))
    if len(matches) != 1:
        raise SystemExit(f"ERROR V138: expected one embedded {BRIDGE_ID} script; found {len(matches)}.")
    match = matches[0]
    bridge = match.group(2)
    function_re = re.compile(
        r"(?m)^  function isCadInput\(input\) \{[\s\S]*?^  \}\n[ \t]*\n?  function addAcceptedTypes",
        re.M,
    )
    found = list(function_re.finditer(bridge))
    if len(found) != 1:
        raise SystemExit(f"ERROR V138: expected one isCadInput function; found {len(found)}. Apply V126 first.")
    replacement = NEW_FUNCTION + "\n\n  function addAcceptedTypes"
    patched_bridge = function_re.sub(lambda _m: replacement, bridge, count=1)
    if patched_bridge.count(MARKER) != 1:
        raise SystemExit("ERROR V138: universal CAD input marker was not inserted exactly once.")
    if "var CAD_INPUT_IDS = new Set([" not in patched_bridge or \
       "var NON_CAD_DATA_IDS = new Set(['fileToDxfInput', 'cleanFilesInput']);" not in patched_bridge:
        raise SystemExit("ERROR V138: V126 file input allow/deny lists changed unexpectedly.")
    if "if (!isCadInput(input)) return;" not in patched_bridge:
        raise SystemExit("ERROR V138: shared accepted-types handler no longer uses isCadInput.")
    result = html[:match.start(2)] + "\n" + patched_bridge.rstrip() + "\n" + html[match.end(2):]
    if result.count(MARKER) != 1 or result.count('id="' + BRIDGE_ID + '"') != 1:
        raise SystemExit("ERROR V138: final HTML has missing or duplicate bridge code.")

    # Android file-origin WebView can fail when Emscripten fetches a relative WASM URL.
    # Resolve from document.baseURI so file:///android_asset/... reaches Emscripten's XHR branch.
    wasm_helper = r'''function sqDwgWasmRuntimePath() {
try {
  return new URL('./libredwg-writer/wasm/', document.baseURI).href.replace(/\/$/, '');
} catch (_) {
  return './libredwg-writer/wasm';
}
}'''
    if "function sqDwgWasmRuntimePath()" not in result:
        wasm_anchor = "const SQ_WRITER_WASM_URL='./libredwg-writer/wasm/libredwg-web.js';"
        if result.count(wasm_anchor) != 1:
            raise SystemExit("ERROR V138: could not locate unique local DWG WASM loader anchor.")
        result = result.replace(wasm_anchor, wasm_anchor + "\n" + wasm_helper, 1)
    relative_create = "LibreDwg.create('./libredwg-writer/wasm')"
    fixed_create = "LibreDwg.create(sqDwgWasmRuntimePath())"
    relative_count = result.count(relative_create)
    fixed_count = result.count(fixed_create)
    if relative_count + fixed_count != 2 or relative_count not in (0, 2):
        raise SystemExit(f"ERROR V138: expected two DWG entry points using old or fixed WASM path; old={relative_count}, fixed={fixed_count}.")
    if relative_count:
        result = result.replace(relative_create, fixed_create)
    if result.count(fixed_create) != 2:
        raise SystemExit("ERROR V138: both DWG entry points must use corrected WASM path.")
    if "new URL('./libredwg-writer/wasm/', document.baseURI)" not in result:
        raise SystemExit("ERROR V138: absolute WASM runtime URL is missing.")

    # Keep app-side update checks aligned with the APK's Android package version.
    version_re = re.compile(r"(?m)(const\s+SQ_APP_VERSION_CODE\s*=\s*)(126|135|136|137|138)(\s*;)")
    version_matches = list(version_re.finditer(result))
    if len(version_matches) != 1:
        raise SystemExit(f"ERROR V138: expected one SQ_APP_VERSION_CODE value (126/135/136/137/138); found {len(version_matches)}.")
    version_match = version_matches[0]
    result = result[:version_match.start()] + version_match.group(1) + "138" + version_match.group(3) + result[version_match.end():]
    result = restore_orientation_features(result)
    if "function universalTransformBytes(input,t)" not in result or "dwg_write_dxf(bytes.buffer)" not in result:
        raise SystemExit("ERROR V138: byte-preserving CAD transform or existing DWG writer is missing.")
    return result


WASM_PROMISE_OLD = b"return new Promise((reject,resolve)=>{var xhr=new XMLHttpRequest;"
WASM_PROMISE_FIXED = b"return new Promise((resolve,reject)=>{var xhr=new XMLHttpRequest;"


def patch_wasm_loader(data: bytes) -> bytes:
    old_count = data.count(WASM_PROMISE_OLD)
    fixed_count = data.count(WASM_PROMISE_FIXED)
    if old_count == 1 and fixed_count == 0:
        data = data.replace(WASM_PROMISE_OLD, WASM_PROMISE_FIXED, 1)
    elif old_count == 0 and fixed_count == 1:
        pass
    else:
        raise SystemExit(f"ERROR V138: expected exactly one reversed file:// WASM Promise callback; old={old_count}, fixed={fixed_count}.")
    if WASM_PROMISE_OLD in data or data.count(WASM_PROMISE_FIXED) != 1:
        raise SystemExit("ERROR V138: incorrect file:// WASM Promise argument order remains.")
    if b"xhr.onload=()=>{if(xhr.status==200||xhr.status==0&&xhr.response){resolve(xhr.response)}reject(xhr.status)};xhr.onerror=reject" not in data:
        raise SystemExit("ERROR V138: Emscripten file:// XHR response handler changed unexpectedly.")
    return data


def patch_html(path: Path) -> None:
    original = path.read_text(encoding="utf-8")
    updated = replace_bridge_function(original)
    path.write_text(updated, encoding="utf-8")
    wasm_path = path.parent / "libredwg-writer" / "wasm" / "libredwg-web.js"
    if not wasm_path.is_file():
        raise SystemExit("ERROR V138: source patch is missing libredwg-writer/wasm/libredwg-web.js.")
    wasm_path.write_bytes(patch_wasm_loader(wasm_path.read_bytes()))
    print("PASS V138: universal CAD picker and existing orientation/project behavior preserved.")
    print("PASS V138: Emscripten file:// WASM XHR Promise arguments corrected to resolve,reject.")


def _read_len8(data: bytes, pos: int) -> tuple[int, int]:
    first = data[pos]
    if first & 0x80:
        return (((first & 0x7F) << 8) | data[pos + 1]), pos + 2
    return first, pos + 1


def _read_len16(data: bytes, pos: int) -> tuple[int, int]:
    first = struct.unpack_from("<H", data, pos)[0]
    if first & 0x8000:
        second = struct.unpack_from("<H", data, pos + 2)[0]
        return (((first & 0x7FFF) << 16) | second), pos + 4
    return first, pos + 2


def _string_pool(data: bytes, chunk_start: int, chunk_size: int, header_size: int) -> tuple[list[str], list[tuple[int, int, bool]]]:
    if header_size < 28 or chunk_start + chunk_size > len(data):
        raise ValueError("invalid Android binary XML string pool")
    string_count, _style_count, flags, strings_start, _styles_start = struct.unpack_from("<IIIII", data, chunk_start + 8)
    if string_count > 100_000:
        raise ValueError("unreasonable Android XML string count")
    offsets_start = chunk_start + header_size
    strings_base = chunk_start + strings_start
    utf8 = bool(flags & 0x100)
    strings: list[str] = []
    spans: list[tuple[int, int, bool]] = []
    for index in range(string_count):
        rel = struct.unpack_from("<I", data, offsets_start + index * 4)[0]
        p = strings_base + rel
        if utf8:
            _u16_len, p = _read_len8(data, p)
            byte_len, p = _read_len8(data, p)
            begin = p
            end = begin + byte_len
            strings.append(data[begin:end].decode("utf-8", errors="strict"))
            spans.append((begin, end, True))
        else:
            char_len, p = _read_len16(data, p)
            begin = p
            end = begin + char_len * 2
            strings.append(data[begin:end].decode("utf-16le", errors="strict"))
            spans.append((begin, end, False))
    return strings, spans


def patch_binary_manifest(manifest: bytes, version_code: int = TARGET_APP_VERSION_CODE,
                          version_name: str = TARGET_APP_VERSION_NAME) -> bytes:
    if len(manifest) < 8 or struct.unpack_from("<H", manifest, 0)[0] != 0x0003:
        raise ValueError("AndroidManifest.xml is not Android binary XML")
    result = bytearray(manifest)
    pos = struct.unpack_from("<H", result, 2)[0]
    total_size = struct.unpack_from("<I", result, 4)[0]
    if total_size > len(result) or total_size < pos:
        raise ValueError("invalid Android binary XML size")
    strings: list[str] | None = None
    spans: list[tuple[int, int, bool]] = []
    pool_info: tuple[int, int, int] | None = None
    chunks = []
    while pos < total_size:
        if pos + 8 > total_size:
            raise ValueError("truncated Android XML chunk header")
        chunk_type, header_size, chunk_size = struct.unpack_from("<HHI", result, pos)
        if chunk_size < header_size or pos + chunk_size > total_size:
            raise ValueError("invalid Android XML chunk bounds")
        chunks.append((pos, chunk_type, header_size, chunk_size))
        if chunk_type == 0x0001:
            strings, spans = _string_pool(bytes(result), pos, chunk_size, header_size)
            pool_info = (pos, chunk_size, header_size)
        pos += chunk_size
    if strings is None or pool_info is None:
        raise ValueError("Android XML string pool not found")

    # versionName string is same length (1.0.126 -> 1.0.136), so pool offsets stay valid.
    old_names = [i for i, value in enumerate(strings) if value == OLD_APP_VERSION_NAME]
    if not old_names and version_name not in strings:
        raise ValueError(f"Android manifest string pool has neither {OLD_APP_VERSION_NAME!r} nor {version_name!r}")
    for idx in old_names:
        begin, end, is_utf8 = spans[idx]
        encoded = version_name.encode("utf-8") if is_utf8 else version_name.encode("utf-16le")
        if len(encoded) != end - begin:
            raise ValueError("versionName replacement changes string-pool byte length")
        result[begin:end] = encoded
        strings[idx] = version_name

    # Locate the manifest root's android:versionCode typed value and replace its integer.
    version_fields = []
    for chunk_pos, chunk_type, header_size, chunk_size in chunks:
        if chunk_type != 0x0102 or chunk_size < 36:
            continue
        node_name_idx = struct.unpack_from("<I", result, chunk_pos + 20)[0]
        if node_name_idx >= len(strings) or strings[node_name_idx] != "manifest":
            continue
        attr_start = struct.unpack_from("<H", result, chunk_pos + 24)[0]
        attr_size = struct.unpack_from("<H", result, chunk_pos + 26)[0]
        attr_count = struct.unpack_from("<H", result, chunk_pos + 28)[0]
        if attr_size < 20 or attr_count > 1024:
            raise ValueError("invalid manifest attribute table")
        first_attr = chunk_pos + 16 + attr_start
        for n in range(attr_count):
            at = first_attr + n * attr_size
            name_idx = struct.unpack_from("<I", result, at + 4)[0]
            if name_idx >= len(strings) or strings[name_idx] != "versionCode":
                continue
            value_size = struct.unpack_from("<H", result, at + 12)[0]
            value_type = result[at + 15]
            if value_size < 8 or value_type not in (0x10, 0x11):
                raise ValueError("manifest versionCode is not a typed integer")
            version_fields.append(at + 16)
    if len(version_fields) != 1:
        raise ValueError(f"expected exactly one manifest versionCode field, found {len(version_fields)}")
    struct.pack_into("<I", result, version_fields[0], version_code)
    return bytes(result)


def patch_apk(input_apk: Path, output_apk: Path) -> None:
    if not input_apk.is_file() or input_apk.stat().st_size == 0:
        raise SystemExit("ERROR V138: input APK is missing or empty.")
    if input_apk.resolve() == output_apk.resolve():
        raise SystemExit("ERROR V138: output APK must differ from input APK.")
    output_apk.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(input_apk, "r") as zin:
        names = [info.filename for info in zin.infolist()]
        if names.count("assets/index.html") != 1:
            raise SystemExit("ERROR V138: input APK must contain exactly one assets/index.html.")
        if names.count("AndroidManifest.xml") != 1:
            raise SystemExit("ERROR V138: input APK must contain exactly one AndroidManifest.xml.")
        seen = set()
        with zipfile.ZipFile(output_apk, "w", allowZip64=True) as zout:
            for info in zin.infolist():
                name = info.filename
                if name in seen:
                    raise SystemExit("ERROR V138: duplicate APK ZIP entry: " + name)
                seen.add(name)
                upper = name.upper()
                if upper.startswith("META-INF/") and (
                    upper.endswith(".SF") or upper.endswith(".RSA") or upper.endswith(".DSA") or
                    upper.endswith(".EC") or upper.endswith("MANIFEST.MF")
                ):
                    continue
                data = zin.read(name)
                if name == "assets/index.html":
                    html = data.decode("utf-8")
                    data = replace_bridge_function(html).encode("utf-8")
                elif name == "assets/libredwg-writer/wasm/libredwg-web.js":
                    data = patch_wasm_loader(data)
                elif name == "AndroidManifest.xml":
                    data = patch_binary_manifest(data)
                clone = copy.copy(info)
                # The destination zip must not retain the old APK's data descriptors or signatures.
                zout.writestr(clone, data)
    with zipfile.ZipFile(output_apk, "r") as check:
        html = check.read("assets/index.html").decode("utf-8")
        manifest = check.read("AndroidManifest.xml")
        if html.count(MARKER) != 1:
            raise SystemExit("ERROR V138: APK output is missing the V138 HTML gate.")
        patch_binary_manifest(manifest)  # validates the resulting manifest can be safely updated again
        if "assets/libredwg-writer/wasm/libredwg-web.wasm" not in check.namelist():
            raise SystemExit("ERROR V138: APK output lost the local DWG WebAssembly engine.")
        wasm_js = check.read("assets/libredwg-writer/wasm/libredwg-web.js")
        if WASM_PROMISE_OLD in wasm_js or wasm_js.count(WASM_PROMISE_FIXED) != 1:
            raise SystemExit("ERROR V138: APK output lacks the corrected file:// WASM loader.")
    print("PASS V138: shared DWG picker gate patched in APK assets; package version raised to 1.0.138/138.")
    print("PASS V138: source DWG is not written over; app's local DWG/DXF engine and all unrelated assets are retained.")


def _make_axml_test_fixture() -> bytes:
    """Build a small valid-enough binary XML manifest for the self-test."""
    strings = ["manifest", "versionCode", "versionName", OLD_APP_VERSION_NAME]
    enc_strings = []
    offsets = []
    for s in strings:
        raw = s.encode("utf-8")
        encoded = bytes([len(s), len(raw)]) + raw + b"\0"
        offsets.append(sum(len(item) for item in enc_strings))
        enc_strings.append(encoded)
    data_strings = b"".join(enc_strings)
    pool_header_size = 28
    offsets_bytes = b"".join(struct.pack("<I", off) for off in offsets)
    strings_start = pool_header_size + len(offsets_bytes)
    pool_size = strings_start + len(data_strings)
    pool = struct.pack("<HHI", 0x0001, pool_header_size, pool_size)
    pool += struct.pack("<IIIII", len(strings), 0, 0x100, strings_start, 0)
    pool += offsets_bytes + data_strings

    # Attributes follow the ResXMLTree_attrExt (20 bytes). Each attribute is 20 bytes.
    node_header = struct.pack("<HHIII", 0x0102, 16, 16 + 20 + 40, 1, 0xFFFFFFFF)
    attr_ext = struct.pack("<IIHHHHHH", 0xFFFFFFFF, 0, 20, 20, 2, 0, 0, 0)
    # Namespace, name index, rawValue index, typedValue.size, res0, type, data.
    attr_code = struct.pack("<IIIHBBI", 0xFFFFFFFF, 1, 0xFFFFFFFF, 8, 0, 0x10, 126)
    attr_name = struct.pack("<IIIHBBI", 0xFFFFFFFF, 2, 3, 8, 0, 0x03, 3)
    start_element = node_header + attr_ext + attr_code + attr_name
    end_element = struct.pack("<HHIIIII", 0x0103, 16, 24, 1, 0xFFFFFFFF, 0xFFFFFFFF, 0)  # element name index 0
    size = 8 + len(pool) + len(start_element) + len(end_element)
    xml_header = struct.pack("<HHI", 0x0003, 8, size)
    return xml_header + pool + start_element + end_element


def self_test() -> None:
    wasm_fixture = b"prefix " + WASM_PROMISE_OLD + b'xhr.onload=()=>{if(xhr.status==200||xhr.status==0&&xhr.response){resolve(xhr.response)}reject(xhr.status)};xhr.onerror=reject;xhr.send(null)}) tail'
    wasm_fixed = patch_wasm_loader(wasm_fixture)
    if WASM_PROMISE_OLD in wasm_fixed or WASM_PROMISE_FIXED not in wasm_fixed:
        raise SystemExit("FAIL V138 self-test: WASM file:// Promise argument order was not corrected.")
    if patch_wasm_loader(wasm_fixed) != wasm_fixed:
        raise SystemExit("FAIL V138 self-test: WASM patch is not idempotent.")
    fixture = _make_axml_test_fixture()
    result = patch_binary_manifest(fixture)
    again = patch_binary_manifest(result)
    if len(fixture) != len(result) or len(result) != len(again):
        raise SystemExit("FAIL V138 self-test: manifest patch changed binary XML length")
    # Root versionCode is the final typed data word in the first attribute.
    chunks = []
    pos = 8
    while pos < len(result):
        typ, hdr, size = struct.unpack_from("<HHI", result, pos)
        chunks.append((pos, typ, hdr, size))
        pos += size
    strings_chunk = next(p for p, typ, _, _ in chunks if typ == 0x0001)
    strings, _spans = _string_pool(result, strings_chunk, struct.unpack_from("<I", result, strings_chunk + 4)[0], 28)
    if TARGET_APP_VERSION_NAME not in strings:
        raise SystemExit("FAIL V138 self-test: versionName was not updated")
    code_chunk = next(p for p, typ, _, _ in chunks if typ == 0x0102)
    attr_start = struct.unpack_from("<H", result, code_chunk + 24)[0]
    attr0 = code_chunk + 16 + attr_start
    actual = struct.unpack_from("<I", result, attr0 + 16)[0]
    if actual != TARGET_APP_VERSION_CODE:
        raise SystemExit(f"FAIL V138 self-test: versionCode={actual}, expected {TARGET_APP_VERSION_CODE}")
    print("PASS V138 self-test: file:// WASM Promise and binary Android manifest version updates passed.")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--html", type=Path)
    parser.add_argument("--apk", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    if args.html and not args.apk and not args.output:
        patch_html(args.html)
        return 0
    if args.apk and args.output and not args.html:
        patch_apk(args.apk, args.output)
        return 0
    parser.error("use --html FILE, --apk INPUT.apk --output OUTPUT.apk, or --self-test")
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
