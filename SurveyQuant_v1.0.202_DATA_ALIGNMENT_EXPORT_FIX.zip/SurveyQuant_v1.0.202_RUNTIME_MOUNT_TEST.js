'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const patchDir=path.dirname(process.argv[2]||__filename);
const modulePath=process.argv[2]||path.join(patchDir,'SurveyQuant_v1.0.177_SINGLE_CANVAS_DATA_EXPORT_MODULE.js');
const cadPath=process.argv[3];
assert.ok(cadPath&&fs.existsSync(cadPath),'V177 CAD engine path required');
const cad=require(cadPath);
class FakeElement{
 constructor(tag,registry){this.tagName=String(tag).toUpperCase();this.registry=registry;this.children=[];this.dataset={};this.listeners={};this.style={};this.classList={add(){},remove(){},toggle(){},contains(){return false;}};this._id='';this.className='';this.textContent='';this.innerHTML='';this.type='';this.disabled=false;}
 set id(v){this._id=String(v);if(this._id)this.registry.set(this._id,this);}get id(){return this._id;}
 appendChild(c){this.children.push(c);c.parentNode=this;if(c.id)this.registry.set(c.id,c);return c;}
 addEventListener(n,f){(this.listeners[n]||=[]).push(f);}removeEventListener(){}querySelectorAll(){return[];}
 getContext(){return{clearRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fillText(){},save(){},restore(){},setLineDash(){},strokeRect(){},fillRect(){},arc(){},setTransform(){},translate(){},rotate(){},drawImage(){}};}
}
const registry=new Map(),doc={readyState:'complete',head:new FakeElement('head',registry),body:new FakeElement('body',registry),listeners:{},createElement(t){return new FakeElement(t,registry);},getElementById(id){return registry.get(String(id))||null;},querySelector(q){if(q==='.container')return container;if(q==='#homeMenu .home-menu')return menu;return null;},querySelectorAll(){return[];},addEventListener(n,f){(this.listeners[n]||=[]).push(f);}};
const container=new FakeElement('div',registry);container.className='container';const home=new FakeElement('div',registry);home.id='homeMenu';const menu=new FakeElement('div',registry);menu.className='home-menu';home.appendChild(menu);container.appendChild(home);const script=new FakeElement('script',registry);script.id='sq177-single-canvas-data-export';
const window={document:doc,SurveyQuantCAD177:cad,parseFile:async()=>({}),safeDownloadFile:async()=>({ok:true}),URL:{revokeObjectURL(){},createObjectURL(){return'blob:test';}},setInterval,clearInterval,addEventListener(){},atob:global.atob,Blob:global.Blob,Image:function Image(){}};
const context={window,document:doc,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,DataView,Blob:global.Blob,Math,Number,String,Map,Set,Promise,Date,RegExp,Error,JSON,console,setInterval,clearInterval,isFinite,parseFloat,parseInt};
vm.createContext(context);vm.runInContext(fs.readFileSync(modulePath,'utf8'),context,{filename:modulePath});
assert.equal(doc.getElementById('sq177-single-canvas-data-export'),script);
const buttonIds=menu.children.map(x=>x.id),cardIds=container.children.map(x=>x.id);
assert.ok(buttonIds.includes('sq177-home-orientation'));assert.ok(buttonIds.includes('sq177-home-data-export'));
assert.ok(cardIds.includes('sq177OrientationCard'));assert.ok(cardIds.includes('sq177DataExportCard'));
assert.ok(doc.getElementById('sq177-single-canvas-data-export-style'));
assert.ok(window.SurveyQuantV177Addendum&&window.SurveyQuantV177AddendumCore);
const ori=container.children.find(x=>x.id==='sq177OrientationCard').innerHTML;
const data=container.children.find(x=>x.id==='sq177DataExportCard').innerHTML;
assert.ok(ori.indexOf('id="sq177-ori-target"')<ori.indexOf('id="sq177-ori-source"'),'reference file picker must be first');
for(const id of ['sq177-ori-view-target','sq177-ori-view-source','sq177-ori-align-start'])assert.ok(ori.includes(`id="${id}"`),`missing ${id}`);
assert.match(ori,/نقطة 1 في غير الموجهة، نقطة 1 المناظرة في الموجهة، نقطة 2 في غير الموجهة، نقطة 2 المناظرة في الموجهة/);
assert.doesNotMatch(ori,/اللوحتين تظهران|بجوار المرجع|sideBySideOffset/);
assert.match(data,/id="sq177-data-save-board-dxf"/);
assert.match(data,/data-export-point="sdr"/);assert.match(data,/data-export-point="bnt"/);assert.match(data,/data-export-point="xlsx"/);assert.match(data,/data-export-point="pdf"/);assert.match(data,/data-export-point="csv"/);
assert.doesNotMatch(data,/data-export="dxf"/);
assert.match(data,/الترقيم يبدأ 1، 2، 3/);
assert.match(data,/شكل العلامة وحجمها ولونها/);
assert.ok(window.SurveyQuantV177AddendumCore.alignmentStage);
assert.equal(JSON.stringify([0,1,2,3].map(i=>window.SurveyQuantV177AddendumCore.alignmentStage(i))),JSON.stringify([
 {side:'source',slot:0},{side:'target',slot:2},{side:'source',slot:1},{side:'target',slot:3}
]));
assert.deepEqual([1,2,3,4].map(window.SurveyQuantV177AddendumCore.pointIdForSequence),['1','2','3','4']);
assert.ok(window.SurveyQuantV177Addendum.exportBoardDxf&&window.SurveyQuantV177Addendum.exportData);
assert.match(doc.head.children[0].textContent,/touch-action:none/);
console.log(JSON.stringify({result:'PASS',menuButtons:buttonIds,mountedCards:cardIds,orientationControls:['reference-view-toggle','source-view-toggle','source1-reference1-source2-reference2-alignment'],oneCanvas:true,dataSaveChoices:['board DXF with point annotations','points only SDR/BNT/Excel/PDF/CSV/TXT'],numericPointIDs:true,gestureControl:true},null,2));
