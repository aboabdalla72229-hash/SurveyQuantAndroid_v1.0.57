(function () {
'use strict';
const VERSION = '1.0.109';
let fileBytes = null, fileName = '', drawing = null, view = null, canvas = null, ctx = null;
let points = [null, null], activePoint = 0, zoom = 1, panX = 0, panY = 0, drag = null, didDrag = false;
const activePointers = new Map();
let gestureMode = '', pinchState = null, suppressTap = false, idProbe = null, activeTool = 'p1', lastIdPoint = null;
const el = id => document.getElementById(id);
function num(pairs, code, occurrence=0, fallback=0) { const p=pairs.filter(x=>x.code===code)[occurrence]; if(!p)return fallback; const n=Number(p.value); return Number.isFinite(n)?n:fallback; }
function vals(pairs, code) { return pairs.filter(x=>x.code===code).map(p=>Number(p.value)).filter(Number.isFinite); }
function str(pairs, code, fallback='') { const p=pairs.find(x=>x.code===code);return p?String(p.value).trim():fallback; }
function byteText(bytes) { let out='',step=0x4000; for(let i=0;i<bytes.length;i+=step)out+=String.fromCharCode.apply(null,bytes.subarray(i,Math.min(bytes.length,i+step))); return out; }
function parsePairs(raw) {
 const lines=raw.replace(/^\uFEFF/,'').split(/\r\n|\n|\r/); while(lines.length&&lines[lines.length-1]==='')lines.pop();
 if(lines.length<8||lines.length%2!==0)throw new Error('ملف DXF النصي غير مكتمل أو ثنائي. احفظ نسخة DXF نصية ASCII من برنامج CAD ثم أعد المحاولة.');
 const pairs=[];for(let i=0;i<lines.length;i+=2){const code=Number(String(lines[i]).trim());if(!Number.isInteger(code))throw new Error('تعذر قراءة بنية DXF عند السطر '+(i+1)+'.');pairs.push({code,value:String(lines[i+1]??'').trim()});}return pairs;
}
function sectionsFromPairs(pairs) {
 const sections=Object.create(null);let section='',active=null;
 const flush=()=>{if(active){(sections[section]||(sections[section]=[])).push(active);active=null;}};
 for(let i=0;i<pairs.length;i++){
  const p=pairs[i];
  if(p.code===0&&p.value.toUpperCase()==='SECTION'){flush();section=String(pairs[i+1]?.value||'').toUpperCase();i++;continue;}
  if(p.code===0&&p.value.toUpperCase()==='ENDSEC'){flush();section='';continue;}
  if(!section)continue;
  if(p.code===0){flush();active={type:p.value.toUpperCase(),pairs:[p]};}
  else if(active)active.pairs.push(p);
 }
 flush();if(!sections.ENTITIES)throw new Error('لم يتم العثور على قسم ENTITIES داخل DXF.');return sections;
}
function makeMatrix(a=1,b=0,c=0,d=1,tx=0,ty=0){return {a,b,c,d,tx,ty};}
function applyMatrix(m,p){return {x:m.a*p.x+m.b*p.y+m.tx,y:m.c*p.x+m.d*p.y+m.ty};}
function compose(parent,local){return makeMatrix(parent.a*local.a+parent.b*local.c,parent.a*local.b+parent.b*local.d,parent.c*local.a+parent.d*local.c,parent.c*local.b+parent.d*local.d,parent.a*local.tx+parent.b*local.ty+parent.tx,parent.c*local.tx+parent.d*local.ty+parent.ty);}
function pairPoint(pairs,xcode,idx=0){const xs=vals(pairs,xcode),ys=vals(pairs,xcode+10);return idx<xs.length&&idx<ys.length?{x:xs[idx],y:ys[idx]}:null;}
function textValue(pairs){let s=pairs.filter(p=>p.code===1||p.code===3).map(p=>p.value).join('');return s.replace(/\\P/g,' ').replace(/\{[^;]*;/g,' ').replace(/[{}]/g,' ').trim().slice(0,32);}
function parseDrawing(bytes) {
 const pairs=parsePairs(byteText(bytes)),sections=sectionsFromPairs(pairs),blocks=Object.create(null);
 const br=sections.BLOCKS||[];for(let i=0;i<br.length;i++)if(br[i].type==='BLOCK'){
  const name=str(br[i].pairs,2,'').toUpperCase(),base=pairPoint(br[i].pairs,10)||{x:0,y:0};const content=[];let j=i+1;
  for(;j<br.length&&br[j].type!=='ENDBLK';j++)content.push(br[j]);blocks[name]={name,base,entities:content};i=j;
 }
 const segs=[],anchors=[],texts=[];let unsupported=0,entityCount=0;
 const addPoint=p=>{if(p&&Number.isFinite(p.x)&&Number.isFinite(p.y)){anchors.push(p);return p;}return null;};
 const addSeg=(a,b)=>{if(!a||!b)return;if(Math.hypot(b.x-a.x,b.y-a.y)>1e-10){segs.push({a,b});addPoint(a);addPoint(b);}};
 function localGeometry(e,mat){const t=e.type,p=e.pairs,layer=str(p,8,'0');entityCount++;
  if(t==='INSERT'){
   const name=str(p,2,'').toUpperCase(),block=blocks[name];if(!block)return;
   const ip=pairPoint(p,10)||{x:0,y:0},sx=num(p,41,0,1)||1,sy=num(p,42,0,1)||1,ang=num(p,50)*Math.PI/180,c=Math.cos(ang),s=Math.sin(ang);
   let local=makeMatrix(c*sx,-s*sy,s*sx,c*sy,ip.x-c*sx*block.base.x+s*sy*block.base.y,ip.y-s*sx*block.base.x-c*sy*block.base.y);
   const composed=compose(mat,local);expand(block.entities,composed,1,new Set([name]));return;
  }
  const mapped=p=>applyMatrix(mat,p);
  if(t==='LINE'){addSeg(mapped(pairPoint(p,10)),mapped(pairPoint(p,11)));return;}
  if(t==='POINT'){addPoint(mapped(pairPoint(p,10)));return;}
  if(t==='LWPOLYLINE'){
   const xs=vals(p,10),ys=vals(p,20),pts=xs.slice(0,Math.min(xs.length,ys.length)).map((x,i)=>mapped({x,y:ys[i]}));
   for(let i=1;i<pts.length;i++)addSeg(pts[i-1],pts[i]);if((num(p,70)&1)&&pts.length>2)addSeg(pts[pts.length-1],pts[0]);return;
  }
  if(t==='POLYLINE')return;
  if(t==='CIRCLE'||t==='ARC'){
   const c=pairPoint(p,10),r=num(p,40,0,0);if(!c||r<=0)return;let start=t==='ARC'?num(p,50)*Math.PI/180:0,end=t==='ARC'?num(p,51)*Math.PI/180:2*Math.PI;
   while(end<=start)end+=2*Math.PI;const arc=Math.min(2*Math.PI,end-start),n=Math.max(20,Math.ceil(arc*32));let prev=null;
   for(let i=0;i<=n;i++){const ang=start+arc*i/n,cur=mapped({x:c.x+r*Math.cos(ang),y:c.y+r*Math.sin(ang)});if(prev)addSeg(prev,cur);prev=cur;}return;
  }
  if(t==='3DFACE'||t==='SOLID'||t==='TRACE'){
   const pts=[];for(let c=10;c<=13;c++){const q=pairPoint(p,c);if(q)pts.push(mapped(q));}for(let i=1;i<pts.length;i++)addSeg(pts[i-1],pts[i]);if(pts.length>2)addSeg(pts[pts.length-1],pts[0]);return;
  }
  if(t==='SPLINE'||t==='LEADER'){
   const xs=[];for(const code of [10,11,12,13]){const xv=vals(p,code),yv=vals(p,code+10);for(let i=0;i<Math.min(xv.length,yv.length);i++)xs.push(mapped({x:xv[i],y:yv[i]}));}for(let i=1;i<xs.length;i++)addSeg(xs[i-1],xs[i]);return;
  }
  if(t==='TEXT'||t==='MTEXT'||t==='ATTRIB'||t==='ATTDEF'){
   const pos=mapped(pairPoint(p,10));if(pos){addPoint(pos);const label=textValue(p);if(label)texts.push({p:pos,text:label,layer});}return;
  }
  if(t==='ELLIPSE'){
   const c=pairPoint(p,10),major=pairPoint(p,11);if(!c||!major)return;const ratio=num(p,40,0,1),rx=Math.hypot(major.x,major.y),base=Math.atan2(major.y,major.x),start=num(p,41,0,0),end=num(p,42,0,2*Math.PI);let delta=end-start;if(delta<=0)delta+=2*Math.PI;let prev=null;for(let i=0;i<=48;i++){const a=start+delta*i/48;const q=mapped({x:c.x+rx*Math.cos(a)*Math.cos(base)-rx*ratio*Math.sin(a)*Math.sin(base),y:c.y+rx*Math.cos(a)*Math.sin(base)+rx*ratio*Math.sin(a)*Math.cos(base)});if(prev)addSeg(prev,q);prev=q;}return;
  }
  if(t==='DIMENSION'||t==='ACAD_PROXY_ENTITY'||t==='ACAD_PROXY_OBJECT'||t==='3DSOLID'||t==='BODY'||t==='REGION'||t==='MESH'||t==='SURFACE'||t==='IMAGE'||t==='WIPEOUT'||t==='HATCH'||t==='MLEADER'||t==='MLINE'||t==='TABLE')unsupported++;
 }
 function expand(list,mat,depth=0,visited=new Set()){
  if(depth>6)return;
  for(let i=0;i<list.length;i++){
   const e=list[i];if(e.type==='POLYLINE'){
    const p=e.pairs,vs=[];let j=i+1;for(;j<list.length&&list[j].type!=='SEQEND';j++){if(list[j].type==='VERTEX'){const pt=pairPoint(list[j].pairs,10);if(pt)vs.push(applyMatrix(mat,pt));}}for(let k=1;k<vs.length;k++)addSeg(vs[k-1],vs[k]);if((num(p,70)&1)&&vs.length>2)addSeg(vs[vs.length-1],vs[0]);i=j;entityCount++;continue;
   }
   if(e.type==='VERTEX'||e.type==='SEQEND'||e.type==='ENDBLK'||e.type==='BLOCK')continue;
   if(e.type==='INSERT'){const n=str(e.pairs,2,'').toUpperCase();if(visited.has(n))continue;const b=blocks[n];if(b){const ip=pairPoint(e.pairs,10)||{x:0,y:0},sx=num(e.pairs,41,0,1)||1,sy=num(e.pairs,42,0,1)||1,a=num(e.pairs,50)*Math.PI/180,c=Math.cos(a),s=Math.sin(a);const lm=makeMatrix(c*sx,-s*sy,s*sx,c*sy,ip.x-c*sx*b.base.x+s*sy*b.base.y,ip.y-s*sx*b.base.x-c*sy*b.base.y);const nv=new Set(visited);nv.add(n);expand(b.entities,compose(mat,lm),depth+1,nv);entityCount++;}else entityCount++;continue;}
   localGeometry(e,mat);
  }
 }
 expand(sections.ENTITIES,makeMatrix());
 if(!segs.length&&!anchors.length)throw new Error('لم أجد خطوطًا أو نقاطًا قابلة للعرض في اللوحة. جرّب حفظها DXF مع إظهار عناصر الرسم، وليس كمرجع خارجي فقط.');
 let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;for(const p of anchors){minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);}if(!Number.isFinite(minX)){minX=0;minY=0;maxX=1;maxY=1;}if(maxX-minX<1e-9){minX-=.5;maxX+=.5;}if(maxY-minY<1e-9){minY-=.5;maxY+=.5;}
 return {segs,anchors,texts,bounds:{minX,minY,maxX,maxY},entityCount,unsupported};
}
function solve(ref1,ref2,src1,src2){
 const vals4=[ref1.x,ref1.y,ref2.x,ref2.y,src1.x,src1.y,src2.x,src2.y];if(!vals4.every(Number.isFinite))throw new Error('أدخل الإحداثيات الحقيقية للنقطتين.');
 const dr=Math.hypot(ref2.x-ref1.x,ref2.y-ref1.y),ds=Math.hypot(src2.x-src1.x,src2.y-src1.y);if(dr<1e-8||ds<1e-8)throw new Error('النقطتان المختارتان يجب أن تكونا مختلفتين وبمسافة واضحة.');
 const angle=Math.atan2(ref2.y-ref1.y,ref2.x-ref1.x)-Math.atan2(src2.y-src1.y,src2.x-src1.x),scale=dr/ds;if(!Number.isFinite(scale)||scale<1e-8||scale>1e8)throw new Error('معامل المقياس غير منطقي. تأكد من اختيار النقطتين بالترتيب الصحيح ووحدات القياس.');const c=Math.cos(angle),s=Math.sin(angle),tx=ref1.x-scale*(c*src1.x-s*src1.y),ty=ref1.y-scale*(s*src1.x+c*src1.y);
 return {scale,angle,angleDeg:angle*180/Math.PI,c,s,tx,ty,ref1,ref2,src1,src2,point:(x,y)=>({x:scale*(c*x-s*y)+tx,y:scale*(s*x+c*y)+ty}),vector:(x,y)=>({x:scale*(c*x-s*y),y:scale*(s*x+c*y)})};
}
function setupView(){if(!canvas)return;const rect=canvas.getBoundingClientRect(),dpr=Math.max(1,window.devicePixelRatio||1);canvas.width=Math.max(1,Math.round(rect.width*dpr));canvas.height=Math.max(1,Math.round(rect.height*dpr));ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);draw();}
function metrics(){const w=canvas.clientWidth,h=canvas.clientHeight,b=drawing.bounds,pad=22,base=Math.min((w-pad*2)/(b.maxX-b.minX),(h-pad*2)/(b.maxY-b.minY));const scale=base*zoom;return {w,h,scale,cx:(b.minX+b.maxX)/2,cy:(b.minY+b.maxY)/2,pad};}
function toScreen(p,m){return {x:m.w/2+(p.x-m.cx)*m.scale+panX,y:m.h/2-(p.y-m.cy)*m.scale+panY};}
function toWorld(p,m){return {x:m.cx+(p.x-m.w/2-panX)/m.scale,y:m.cy-(p.y-m.h/2-panY)/m.scale};}
function draw(){
 if(!canvas||!ctx||!drawing)return;
 const m=metrics();ctx.clearRect(0,0,m.w,m.h);ctx.fillStyle='#0b1220';ctx.fillRect(0,0,m.w,m.h);ctx.lineWidth=1;ctx.strokeStyle='#90a4ba';ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();
 for(const seg of drawing.segs){const a=toScreen(seg.a,m),b=toScreen(seg.b,m);if((a.x<-1000&&b.x<-1000)||(a.x>m.w+1000&&b.x>m.w+1000)||(a.y<-1000&&b.y<-1000)||(a.y>m.h+1000&&b.y>m.h+1000))continue;ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);}ctx.stroke();
 for(const t of drawing.texts){const p=toScreen(t.p,m);if(p.x<0||p.x>m.w||p.y<0||p.y>m.h)continue;ctx.fillStyle='#e9c46a';ctx.font='11px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);}
 if(idProbe){const p=toScreen(idProbe.source,m);ctx.strokeStyle='#f4a261';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(p.x-11,p.y);ctx.lineTo(p.x+11,p.y);ctx.moveTo(p.x,p.y-11);ctx.lineTo(p.x,p.y+11);ctx.stroke();ctx.fillStyle='#f4a261';ctx.font='bold 12px sans-serif';ctx.fillText('ID',p.x+12,p.y-10);}
 for(let i=0;i<points.length;i++){if(!points[i])continue;const p=toScreen(points[i].source,m);ctx.beginPath();ctx.fillStyle=i===0?'#31d0aa':'#ff6b6b';ctx.strokeStyle='#08111e';ctx.lineWidth=2;ctx.arc(p.x,p.y,7,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle='#fff';ctx.font='bold 12px sans-serif';ctx.fillText('P'+(i+1),p.x+9,p.y-8);}
 const extent=el('sq108Extent');if(extent)extent.textContent='العناصر المعروضة: '+drawing.entityCount+' | المقاطع: '+drawing.segs.length+' | التكبير ×'+zoom.toFixed(2)+' | التقاط التقاطعات: يعمل تلقائيًا';
}
function message(s,bad=false){const b=el('sq108Status');if(!b)return;b.style.display='block';b.style.color=bad?'#fecaca':'#d1fae5';b.style.borderColor=bad?'#b91c1c':'#15803d';b.textContent=s;}
function pointRead(index){const sx=points[index]?.source;if(!sx)throw new Error('حدد موضع النقطة '+(index+1)+' على الرسم أولًا بالنقر على اللوحة.');const x=Number(el('sq108P'+(index+1)+'X').value),y=Number(el('sq108P'+(index+1)+'Y').value);if(!el('sq108P'+(index+1)+'X').value.trim()||!el('sq108P'+(index+1)+'Y').value.trim()||!Number.isFinite(x)||!Number.isFinite(y))throw new Error('أدخل الإحداثيين الحقيقيين X وY للنقطة '+(index+1)+'.');return {source:sx,known:{x,y}};}
function clampZoom(z){return Math.max(0.2,Math.min(100,Number.isFinite(z)?z:1));}
function pointSegmentDistance(point,a,b){const dx=b.x-a.x,dy=b.y-a.y,dd=dx*dx+dy*dy;let t=dd>1e-18?((point.x-a.x)*dx+(point.y-a.y)*dy)/dd:0;t=Math.max(0,Math.min(1,t));return Math.hypot(point.x-(a.x+t*dx),point.y-(a.y+t*dy));}
function segmentIntersection(first,second){
 const p=first.a,q=second.a,rx=first.b.x-first.a.x,ry=first.b.y-first.a.y,sx=second.b.x-second.a.x,sy=second.b.y-second.a.y;
 const den=rx*sy-ry*sx,scale=Math.hypot(rx,ry)*Math.hypot(sx,sy);if(Math.abs(den)<=Math.max(1e-12,scale*1e-10))return null;
 const qpx=q.x-p.x,qpy=q.y-p.y,t=(qpx*sy-qpy*sx)/den,u=(qpx*ry-qpy*rx)/den,eps=1e-9;if(t < -eps||t > 1+eps||u < -eps||u > 1+eps)return null;
 const tc=Math.max(0,Math.min(1,t));return {x:p.x+tc*rx,y:p.y+tc*ry,t,u};
}
function findNearestIntersection(segments,cursorScreen,project,maxDistance=22){
 const candidates=[];for(const seg of segments){const a=project(seg.a),b=project(seg.b),dist=pointSegmentDistance(cursorScreen,a,b);if(dist<=maxDistance)candidates.push({seg,dist});}
 if(candidates.length<2)return null;candidates.sort((a,b)=>a.dist-b.dist);if(candidates.length>64)candidates.length=64;
 let best=null;for(let i=0;i<candidates.length;i++)for(let j=i+1;j<candidates.length;j++){
  const p=segmentIntersection(candidates[i].seg,candidates[j].seg);if(!p)continue;const sp=project(p),dist=Math.hypot(sp.x-cursorScreen.x,sp.y-cursorScreen.y);if(dist<=maxDistance&&(!best||dist<best.dist))best={point:{x:p.x,y:p.y},dist,kind:'تقاطع تلقائي (OSNAP)'};
 }return best;
}
function nearestOnDrawing(world){
 const m=metrics(),cursor=toScreen(world,m),crossing=findNearestIntersection(drawing.segs,cursor,p=>toScreen(p,m),22);if(crossing)return {p:crossing.point,dist:crossing.dist,kind:crossing.kind};
 let best=null;function test(p,kind){const b=toScreen(p,m),dist=Math.hypot(cursor.x-b.x,cursor.y-b.y);if(!best||dist<best.dist)best={p,dist,kind};}
 for(const p of drawing.anchors)test(p,'نقطة/رأس');for(const seg of drawing.segs){const a=seg.a,b=seg.b,dx=b.x-a.x,dy=b.y-a.y,d=dx*dx+dy*dy;if(d<1e-18)continue;let t=((world.x-a.x)*dx+(world.y-a.y)*dy)/d;t=Math.max(0,Math.min(1,t));test({x:a.x+t*dx,y:a.y+t*dy},'أقرب موضع على خط');}
 return best&&best.dist<=22?best:null;
}
function toolModeText(){const mode=activeTool==='id'?'ID Point: اضغط على الرسم لقراءة إحداثيات X/Y':('اختيار '+(activePoint+1)+': اضغط على الرسم ثم أدخل الإحداثيات الحقيقية');const modeEl=el('sq109ToolMode');if(modeEl)modeEl.textContent=mode;const idBtn=el('sq109IdPoint');if(idBtn){idBtn.style.outline=activeTool==='id'?'2px solid #31d0aa':'none';idBtn.setAttribute('aria-pressed',activeTool==='id'?'true':'false');}}
function chooseAt(clientX,clientY){
 if(!drawing||!canvas)return;const r=canvas.getBoundingClientRect(),screen={x:clientX-r.left,y:clientY-r.top},world=toWorld(screen,metrics()),snap=nearestOnDrawing(world);
 if(!snap){message('لم أجد تقاطعًا أو نقطة أو خطًا ضمن نطاق الالتقاط. كبّر الرسم أو حرّكه ثم حاول مرة أخرى.',true);return;}
 if(activeTool==='id'){
  idProbe={source:snap.p,kind:snap.kind};lastIdPoint=snap.p;const readout=el('sq109IdReadout');if(readout)readout.textContent='ID Point | X = '+snap.p.x.toFixed(6)+' | Y = '+snap.p.y.toFixed(6)+' | الالتقاط: '+snap.kind;const copy=el('sq109CopyId');if(copy)copy.disabled=false;draw();message('ID Point: X = '+snap.p.x.toFixed(6)+' , Y = '+snap.p.y.toFixed(6)+' ('+snap.kind+'). هذه إحداثيات النقطة داخل اللوحة قبل التوجيه.');return;
 }
 const index=activeTool==='p2'?1:0,old=points[index];if(old&&Math.hypot(old.source.x-snap.p.x,old.source.y-snap.p.y)>1e-8){el('sq108P'+(index+1)+'X').value='';el('sq108P'+(index+1)+'Y').value='';}
 points[index]={source:snap.p,known:null};el('sq108Picked'+(index+1)).textContent='X='+snap.p.x.toFixed(6)+' | Y='+snap.p.y.toFixed(6)+' ('+snap.kind+')';idProbe=null;draw();message('تم التقاط النقطة '+(index+1)+' بواسطة '+snap.kind+'. أدخل إحداثييها الحقيقيين X وY.');
 if(index===0){activePoint=1;activeTool='p2';}else{activePoint=1;activeTool='p2';}selectActive();
}
function selectActive(){const a=el('sq108Pick1'),b=el('sq108Pick2');if(!a||!b)return;if(activeTool!=='id')activeTool=activePoint===0?'p1':'p2';a.style.outline=activeTool==='p1'?'2px solid #31d0aa':'none';b.style.outline=activeTool==='p2'?'2px solid #ff6b6b':'none';el('sq108PickTarget').textContent=activeTool==='id'?'وضع ID Point: اضغط على الرسم لعرض إحداثيات النقطة':('اضغط الرسم لتحديد موضع النقطة '+(activePoint+1));toolModeText();}
function zoomTransformAt(state,screen,nextZoom){const oldScale=state.baseScale*state.zoom;if(!(oldScale>0))throw new Error('مقياس العرض غير صالح.');const world={x:state.cx+(screen.x-state.w/2-state.panX)/oldScale,y:state.cy-(screen.y-state.h/2-state.panY)/oldScale},z=clampZoom(nextZoom),scale=state.baseScale*z;return {zoom:z,panX:screen.x-state.w/2-(world.x-state.cx)*scale,panY:screen.y-state.h/2+(world.y-state.cy)*scale,anchorWorld:world};}
function zoomAtPoint(nextZoom,screen){if(!drawing||!canvas)return;const m=metrics(),state={w:m.w,h:m.h,cx:m.cx,cy:m.cy,baseScale:m.scale/zoom,zoom,panX,panY},res=zoomTransformAt(state,screen,nextZoom);zoom=res.zoom;panX=res.panX;panY=res.panY;draw();}
function pinchZoom(startZoom,startDistance,currentDistance){return clampZoom(startZoom*Math.max(1,currentDistance)/Math.max(1,startDistance));}
function canvasLocal(x,y){const r=canvas.getBoundingClientRect();return {x:x-r.left,y:y-r.top};}
function bindCanvas(){
 canvas=el('sq108Canvas');if(!canvas)return;
 canvas.addEventListener('pointerdown',e=>{if(!drawing)return;e.preventDefault?.();activePointers.set(e.pointerId,{x:e.clientX,y:e.clientY});try{canvas.setPointerCapture?.(e.pointerId);}catch(_){}
  if(activePointers.size>=2){suppressTap=true;const pair=Array.from(activePointers.values()).slice(0,2),center={x:(pair[0].x+pair[1].x)/2,y:(pair[0].y+pair[1].y)/2},local=canvasLocal(center.x,center.y),m=metrics();pinchState={distance:Math.max(1,Math.hypot(pair[0].x-pair[1].x,pair[0].y-pair[1].y)),zoom,world:toWorld(local,m)};gestureMode='pinch';drag=null;didDrag=true;
  }else{gestureMode='panOrTap';drag={pointerId:e.pointerId,x:e.clientX,y:e.clientY,px:panX,py:panY};didDrag=false;suppressTap=false;}
 });
 canvas.addEventListener('pointermove',e=>{if(!activePointers.has(e.pointerId))return;activePointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(gestureMode==='pinch'&&activePointers.size>=2&&pinchState){const pair=Array.from(activePointers.values()).slice(0,2),center={x:(pair[0].x+pair[1].x)/2,y:(pair[0].y+pair[1].y)/2},distance=Math.hypot(pair[0].x-pair[1].x,pair[0].y-pair[1].y),local=canvasLocal(center.x,center.y);zoom=pinchZoom(pinchState.zoom,pinchState.distance,distance);const m=metrics();panX=local.x-m.w/2-(pinchState.world.x-m.cx)*m.scale;panY=local.y-m.h/2+(pinchState.world.y-m.cy)*m.scale;didDrag=true;draw();return;}
  if(gestureMode==='panOrTap'&&drag&&drag.pointerId===e.pointerId){if(Math.hypot(e.clientX-drag.x,e.clientY-drag.y)>5)didDrag=true;if(didDrag){panX=drag.px+(e.clientX-drag.x);panY=drag.py+(e.clientY-drag.y);draw();}}
 });
 canvas.addEventListener('pointerup',e=>{const wasPinch=gestureMode==='pinch'||activePointers.size>1,wasTap=!wasPinch&&gestureMode==='panOrTap'&&drag&&drag.pointerId===e.pointerId&&!didDrag&&!suppressTap;activePointers.delete(e.pointerId);try{canvas.releasePointerCapture?.(e.pointerId);}catch(_){}
  if(wasPinch){suppressTap=true;pinchState=null;if(activePointers.size===1){const entry=Array.from(activePointers.entries())[0];gestureMode='panOrTap';drag={pointerId:entry[0],x:entry[1].x,y:entry[1].y,px:panX,py:panY};didDrag=true;}else{gestureMode='';drag=null;didDrag=true;}return;}
  if(wasTap)chooseAt(e.clientX,e.clientY);drag=null;gestureMode='';didDrag=false;suppressTap=false;
 });
 canvas.addEventListener('pointercancel',e=>{activePointers.delete(e.pointerId);if(activePointers.size<2){pinchState=null;gestureMode='';drag=null;didDrag=true;suppressTap=true;}});
 canvas.addEventListener('wheel',e=>{e.preventDefault();const p=canvasLocal(e.clientX,e.clientY);zoomAtPoint(zoom*(e.deltaY<0?1.2:1/1.2),p);},{passive:false});
}
async function copyIdPoint(){if(!lastIdPoint){message('استخدم أداة ID Point واختر نقطة أولًا.',true);return;}const value=lastIdPoint.x.toFixed(6)+', '+lastIdPoint.y.toFixed(6);try{if(navigator.clipboard&&navigator.clipboard.writeText)await navigator.clipboard.writeText(value);else{const box=document.createElement('textarea');box.value=value;box.setAttribute('readonly','');box.style.position='fixed';box.style.opacity='0';document.body.appendChild(box);box.select();const ok=document.execCommand('copy');box.remove();if(!ok)throw new Error('copy unavailable');}message('تم نسخ الإحداثيين: '+value);}catch(_){message('الإحداثيات: '+value+' . يمكنك تحديد النص ونسخه يدويًا.');}}
async function readFile(){
 const f=el('sq108File').files?.[0];if(!f)return;
 try{
  const ext=f.name.toLowerCase().split('.').pop();let bytes,name=f.name;
  if(ext==='dwg'){
   if(!window.__sqOriAxisAutoTest?.convertTargetToDxf)throw new Error('تحويل DWG غير مهيأ في هذه النسخة. احفظ نسخة DXF من CAD ثم افتحها.');
   message('جارٍ تحويل نسخة مؤقتة من DWG إلى DXF للمعاينة...',false);const cv=await window.__sqOriAxisAutoTest.convertTargetToDxf(f);bytes=cv.bytes;name=cv.name;
  }else if(ext==='dxf'){bytes=new Uint8Array(await f.arrayBuffer());}else throw new Error('اختر ملف DXF أو DWG فقط.');
  const model=parseDrawing(bytes);fileBytes=bytes;fileName=name;drawing=model;points=[null,null];activePoint=0;activeTool='p1';idProbe=null;lastIdPoint=null;zoom=1;panX=0;panY=0;activePointers.clear();gestureMode='';pinchState=null;suppressTap=false;drag=null;didDrag=false;
  ['sq108P1X','sq108P1Y','sq108P2X','sq108P2Y'].forEach(id=>{el(id).value='';});
  el('sq108Picked1').textContent='لم يتم التحديد';el('sq108Picked2').textContent='لم يتم التحديد';
  el('sq109CopyId').disabled=true;el('sq109IdReadout').textContent='ID Point: اضغط الأداة ثم اختر نقطة لعرض إحداثياتها المحلية.';el('sq109IdPoint').textContent='📍 ID Point | قراءة إحداثيات نقطة';el('sq109IdPoint').setAttribute('aria-pressed','false');
  el('sq108CanvasWrap').style.display='block';el('sq108PointControls').style.display='grid';el('sq108OutputActions').style.display='flex';setupView();selectActive();
  message('تم فتح '+f.name+' للمعاينة. استخدم التكبير بالإصبعين أو أزرار +/−. اختر نقطتي التوجيه مع التقاط التقاطعات تلقائيًا، أو استخدم ID Point لقراءة X/Y.');
 }catch(e){fileBytes=null;drawing=null;message(e.message||String(e),true);}
}
function calcPreview(){try{const p1=pointRead(0),p2=pointRead(1),t=solve(p1.known,p2.known,p1.source,p2.source);const q1=t.point(p1.source.x,p1.source.y),q2=t.point(p2.source.x,p2.source.y);const err=Math.max(Math.hypot(q1.x-p1.known.x,q1.y-p1.known.y),Math.hypot(q2.x-p2.known.x,q2.y-p2.known.y));message('الحساب جاهز. معامل المقياس: '+t.scale.toFixed(10)+' | الدوران: '+t.angleDeg.toFixed(6)+'° | خطأ النقطتين: '+err.toExponential(2)+'. المحور X يبقى X وY يبقى Y.');return t;}catch(e){message(e.message||String(e),true);return null;}}
async function execute(){try{if(!fileBytes||!drawing)throw new Error('اختر لوحة DXF أو DWG وافتح معاينتها أولًا.');const t=calcPreview();if(!t)return;const orient=window.__sqOrientTest;if(!orient||typeof orient.transformBytes!=='function')throw new Error('محرك تحويل عناصر DXF غير جاهز. لم يتم إنشاء ملف.');const result=orient.transformBytes(fileBytes,t);if(!result.bytes||result.bytes.length<20)throw new Error('ناتج التحويل فارغ. لم يتم حفظ الملف.');const out=(typeof window.safeDownloadFile==='function')?await window.safeDownloadFile(result.bytes,fileName.replace(/\.[^.]+$/,'')+'_ORIENTED.dxf','application/dxf'):await fallbackDownload(result.bytes,fileName);if(out==null){message('لم يتم حفظ الملف لأن عملية اختيار اسم الملف أُلغيت. اللوحة الأصلية لم تتغير.',true);return;}message('تم توجيه اللوحة وإخراج نسخة جديدة بنجاح. العناصر المعالجة: '+result.transformedCount+' | الحقول الهندسية المعدلة: '+result.changedFields+'. تم حفظ الملف في مجلد التنزيلات بواسطة آلية التطبيق، والملف الأصلي لم يتغير.');}catch(e){message((e?.message||String(e))+' لم يتم تعديل الملف الأصلي.',true);}}
async function fallbackDownload(bytes,name){const blob=new Blob([bytes],{type:'application/dxf'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name.replace(/\.[^.]+$/,'')+'_ORIENTED.dxf';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);return url;}
function mount(){const overlay=el('sqOriOverlay');if(!overlay)return;const dialog=overlay.querySelector('.sqori-dialog');if(!dialog)return;dialog.innerHTML='<button class="sqori-close" type="button" onclick="sqCloseOrientationProject()">✕ إغلاق</button><h2 id="sqOriTitle">🧭 توجيه اللوح بالنقطتين وOSNAP وID Point</h2><p class="sqori-help">الطريقة الجديدة: اختر اللوحة، ثم اضغط موضع النقطة الأولى على الرسم وأدخل إحداثياتها الصحيحة X وY. كرر للنقطة الثانية. البرنامج يحسب الدوران والمقياس والإزاحة ويخرج ملف DXF جديدًا. X=Easting وY=Northing دون تبديل.</p><label>اللوحة المراد توجيهها (DXF أو DWG)<input id="sq108File" type="file" accept=".dxf,.dwg"></label><div id="sq108CanvasWrap" style="display:none;margin-top:10px"><div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:8px 0"><button type="button" class="sqori-preview" id="sq108ZoomIn">تكبير +</button><button type="button" class="sqori-preview" id="sq108ZoomOut">تصغير −</button><button type="button" class="sqori-preview" id="sq108ZoomFit">ملاءمة اللوحة</button><button type="button" class="sqori-preview" id="sq109IdPoint" aria-pressed="false">📍 ID Point | قراءة إحداثيات نقطة</button><button type="button" class="sqori-preview" id="sq109CopyId" disabled>نسخ X,Y</button><span id="sq108Extent" class="sqori-help"></span></div><p id="sq108PickTarget" class="sqori-help">اضغط الرسم لتحديد موضع النقطة 1</p><canvas id="sq108Canvas" style="display:block;width:100%;height:430px;border:1px solid #42536b;border-radius:10px;touch-action:none;background:#0b1220"></canvas><p class="sqori-help">تحكم بالإصبعين للتكبير والتصغير (Pinch)، وبإصبع واحد لسحب اللوحة. عند اختيار نقطة يلتقط البرنامج التقاطعات تلقائيًا أولًا (OSNAP)، ثم الرؤوس والنقاط، ثم أقرب موضع على خط. أداة ID Point تقرأ X/Y لموضع تختاره دون تغيير نقاط التوجيه.</p><p id="sq109ToolMode" class="sqori-help">وضع الاختيار: النقطة 1</p><p id="sq109IdReadout" class="sqori-help">ID Point: اضغط الأداة ثم اختر نقطة لعرض إحداثياتها المحلية.</p></div><div id="sq108PointControls" style="display:none;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px"><section class="sqori-group"><button type="button" class="sqori-preview" id="sq108Pick1">اختيار موضع النقطة 1</button><h3>النقطة 1</h3><p class="sqori-help" id="sq108Picked1">لم يتم التحديد</p><label>الإحداثي الحقيقي X<input id="sq108P1X" type="number" step="any" inputmode="decimal" placeholder="Easting / X"></label><label>الإحداثي الحقيقي Y<input id="sq108P1Y" type="number" step="any" inputmode="decimal" placeholder="Northing / Y"></label></section><section class="sqori-group"><button type="button" class="sqori-preview" id="sq108Pick2">اختيار موضع النقطة 2</button><h3>النقطة 2</h3><p class="sqori-help" id="sq108Picked2">لم يتم التحديد</p><label>الإحداثي الحقيقي X<input id="sq108P2X" type="number" step="any" inputmode="decimal" placeholder="Easting / X"></label><label>الإحداثي الحقيقي Y<input id="sq108P2Y" type="number" step="any" inputmode="decimal" placeholder="Northing / Y"></label></section></div><div id="sq108OutputActions" style="display:none;gap:8px;flex-wrap:wrap;margin-top:12px"><button class="sqori-preview" type="button" id="sq108Preview">معاينة الحساب</button><button class="sqori-run" type="button" id="sq108Run">توجيه وإخراج DXF</button></div><div class="sqori-help" style="margin-top:10px">مهم: لا تحتاج إلى ملف مرجعي ثانٍ أو تسميات محاور. تختار نقطتين من اللوحة وتدخل الإحداثيات المستهدفة لهما. إذا كانت اللوحة تحتوي على عناصر CAD لا يستطيع المحرك تحويلها بأمان، سيعرض السبب بدل حفظ ملف ناقص. الملف الأصلي لا يُستبدل.</div><div id="sq108Status" class="sqori-status" role="status" aria-live="polite"></div>';
 canvas=null;ctx=null;fileBytes=null;fileName='';drawing=null;points=[null,null];zoom=1;panX=panY=0;activePoint=0;activeTool='p1';idProbe=null;lastIdPoint=null;activePointers.clear();gestureMode='';pinchState=null;suppressTap=false;drag=null;didDrag=false;
 el('sq108File').addEventListener('change',readFile);bindCanvas();el('sq108Pick1').addEventListener('click',()=>{activePoint=0;activeTool='p1';selectActive();});el('sq108Pick2').addEventListener('click',()=>{activePoint=1;activeTool='p2';selectActive();});el('sq108ZoomIn').addEventListener('click',()=>zoomAtPoint(zoom*1.5,{x:canvas.clientWidth/2,y:canvas.clientHeight/2}));el('sq108ZoomOut').addEventListener('click',()=>zoomAtPoint(zoom/1.5,{x:canvas.clientWidth/2,y:canvas.clientHeight/2}));el('sq108ZoomFit').addEventListener('click',()=>{zoom=1;panX=panY=0;idProbe=null;draw();});el('sq109IdPoint').addEventListener('click',()=>{activeTool=activeTool==='id'?(activePoint===0?'p1':'p2'):'id';toolModeText();el('sq109IdPoint').textContent=activeTool==='id'?'📍 ID Point مفعل، اضغط على الرسم':'📍 ID Point | قراءة إحداثيات نقطة';message(activeTool==='id'?'أداة ID Point مفعلة. اضغط أي نقطة أو تقاطع لقراءة إحداثييها دون تغيير نقاط التوجيه.':'تم الرجوع إلى اختيار نقاط التوجيه.');selectActive();});el('sq109CopyId').addEventListener('click',copyIdPoint);el('sq108Preview').addEventListener('click',calcPreview);el('sq108Run').addEventListener('click',execute);window.addEventListener('resize',()=>{if(drawing)setupView();});
}
window.__sqManualOrientation109={parseDrawing,solve,segmentIntersection,findNearestIntersection,zoomTransformAt,pinchZoom,clampZoom,nearestOnDrawing:()=>drawing?nearestOnDrawing({x:(drawing.bounds.minX+drawing.bounds.maxX)/2,y:(drawing.bounds.minY+drawing.bounds.maxY)/2}):null,VERSION};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();
