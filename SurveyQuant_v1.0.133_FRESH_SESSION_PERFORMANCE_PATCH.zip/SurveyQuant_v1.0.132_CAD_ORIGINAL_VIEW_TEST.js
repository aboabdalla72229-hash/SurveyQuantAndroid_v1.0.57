'use strict';
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const file = process.argv[2];
if (!file || !fs.existsSync(file)) throw new Error('Usage: node sq-v132-cad-original-view-test.js index.html');
const html = fs.readFileSync(file, 'utf8');
function region(start, end) {
  const a = html.indexOf(start); assert(a >= 0, `missing: ${start}`);
  const b = html.indexOf(end, a + start.length); assert(b > a, `missing boundary: ${end}`);
  return html.slice(a, b);
}
assert(html.includes('SURVEYQUANT_V132_CAD_ORIGINAL_VIEW_STRICT_PRESERVE'), 'V132 marker missing');
const recovery = region('MANUAL.parseDrawing = function parseDrawingWithRecovery(input) {', '  // Existing renderer covers standard survey entities');
assert(!recovery.includes('addUnrenderedEntities(model, working)'), 'synthetic geometry must not be injected into the CAD preview');
assert(html.includes("dialog.style.maxHeight='94dvh'"), 'orientation modal must use a large viewport');
assert(html.includes("dialog.style.width='min(99vw,1120px)'"), 'orientation modal width must be enlarged');
assert((html.match(/height:58dvh;min-height:400px;max-height:640px/g) || []).length >= 2, 'both CAD canvases must be enlarged');
const draw = region('function draw(v){', 'function setupCanvas(v){');
assert(draw.includes('Math.abs(Number(t.height)||2.5)*m.scale'), 'CAD text size must follow the actual drawing zoom');
assert(!draw.includes('fitTextSize/Math.sqrt'), 'CAD text must not shrink when zooming in');
assert(!draw.includes("String(t.text||'').slice(0,250)"), 'CAD text must not be truncated after 250 characters');
const projection = region('async function dropFilesMerge(){', 'function downloadDroppedDXF()');
assert(projection.includes('sqV132CadEntitySnapshot(referenceBytes)'), 'projection must snapshot the source board');
assert(projection.includes('sqV132AssertReferencePreserved(referenceBytes,droppedDXF)'), 'projection must verify preservation of original reference entities');
assert(!projection.includes('buildR12FromEntities(entities'), 'projection must not reconstruct the reference from partial parsed entities');
assert(projection.includes('throw new Error(\'تعذر الحصول على ملف DXF المرجعي الكامل.'), 'missing source bytes must fail safely rather than export only points');
const snapStart = html.indexOf('function sqV132CadEntitySnapshot(bytes){');
const snapEnd = html.indexOf('async function dropFilesMerge(){', snapStart);
assert(snapStart >= 0 && snapEnd > snapStart, 'V132 preservation helpers missing');
const helperSource = html.slice(snapStart, html.indexOf('async function dropFilesMerge(){', snapStart));
const pairsSource = region('function sqDxfPairsWithOffsets(text){', 'function sqFindDxfLayerTable(pairs){');
const sectionTableSource = region('function sqFindDxfSection(pairs,name){', 'function sqFindDxfTable(pairs,tableName,rowName){');
const context = {
  Uint8Array, TextDecoder,
  sqDxfPairsWithOffsets: null,
  sqFindDxfSection: null,
  sectionRecords: function(pairs, name) {
    let i = -1, end = -1;
    for (let k=0;k+1<pairs.length;k++) if (pairs[k].code==='0' && pairs[k].value.toUpperCase()==='SECTION' && pairs[k+1].code==='2' && pairs[k+1].value.toUpperCase()===name.toUpperCase()) { i=k+2; break; }
    if (i<0) return [];
    for(let k=i;k<pairs.length;k++) if(pairs[k].code==='0'&&pairs[k].value.toUpperCase()==='ENDSEC'){end=k;break;}
    if(end<0)return [];
    const out=[];let start=-1;
    for(let k=i;k<end;k++) if(pairs[k].code==='0') { if(start>=0)out.push({type:pairs[start].value.toUpperCase(),pairs:pairs.slice(start,k)});start=k; }
    if(start>=0)out.push({type:pairs[start].value.toUpperCase(),pairs:pairs.slice(start,end)});
    return out;
  }
};
vm.createContext(context);
vm.runInContext(pairsSource.replace(/^function sqDxfPairsWithOffsets/, 'function sqDxfPairsWithOffsets'), context);
vm.runInContext(sectionTableSource, context);
vm.runInContext(helperSource, context);
const base = '0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1027\n0\nENDSEC\n0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLAYER\n70\n1\n0\nLAYER\n2\n0\n70\n0\n62\n7\n0\nENDTAB\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n0\nLINE\n8\nROAD\n10\n0\n20\n0\n11\n10\n21\n10\n0\nTEXT\n8\nAXIS_LABELS\n10\n5\n20\n5\n1\nAXIS A-1 - FULL LABEL\n0\nENDSEC\n0\nEOF\n';
const sourceBytes = new TextEncoder().encode(base);
const entEnd = base.indexOf('0\nENDSEC\n', base.indexOf('2\nENTITIES') + 10);
const mergedText = base.slice(0, entEnd) + '0\nPOINT\n8\nSURVEY_POINTS\n10\n2\n20\n3\n30\n0\n' + base.slice(entEnd);
const mergedBytes = new TextEncoder().encode(mergedText);
const good = context.sqV132AssertReferencePreserved(sourceBytes, mergedBytes);
assert.strictEqual(good.before.entityCount, 2, 'source reference entities must be counted');
assert.strictEqual(good.after.entityCount, 3, 'projected point should add one entity while keeping reference entities');
assert(good.before.body.length > 0, 'reference section body must not be empty');
assert.throws(() => context.sqV132AssertReferencePreserved(sourceBytes, new TextEncoder().encode(base.replace(/0\nLINE\n8\nROAD[\s\S]*?0\nENDSEC\n(?=0\nEOF)/, '0\nPOINT\n8\nSURVEY_POINTS\n10\n2\n20\n3\n30\n0\n0\nENDSEC\n'))), /فقد|تغيّر|preserv|كيانات|Layer/i, 'reference loss must stop export');
console.log('PASS: V132 no synthetic preview geometry, enlarged CAD canvases, true CAD text zoom, complete text strings, and byte-preserved reference projection with fail-safe loss detection.');
