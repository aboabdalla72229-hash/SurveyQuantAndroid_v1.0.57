'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const html=fs.readFileSync(process.argv[2]||'index.html','utf8');
const start=html.indexOf('async function parseFile(file,options={}){');
const end=html.indexOf('\n// Shared, tested DWG/DXF reader used by the app CAD-capable projects.',start);
assert(start>=0&&end>start,'parseFile function not found');
const code=html.slice(start,end)+'\nwindow.parseFile = parseFile;';
const ctx={window:{},TextDecoder,Uint8Array,ArrayBuffer,Map,Number,String,Error,console};
vm.createContext(ctx);vm.runInContext(code,ctx);
(async()=>{
  const expected=Uint8Array.from([48,10,83,69,67,84,73,79,78,10,50,10,69,78,84,73,84,73,69,83,10,48,10,69,79,70,10]);
  let reads=0;
  const fakeZeroSize={name:'picked-board.dxf',size:0,arrayBuffer:async()=>{reads++;throw new Error('unexpected second file read');}};
  const a=await ctx.window.parseFile(fakeZeroSize,{rawOnly:true,sourceBytes:expected});
  assert.equal(reads,0,'parser re-read Android document instead of using selected bytes');
  assert.equal(a.rawDXFBytes.length,expected.length);
  assert.deepEqual(Array.from(a.rawDXFBytes),Array.from(expected));
  let fallbackReads=0;
  const fallback={name:'fallback.dxf',size:0,arrayBuffer:async()=>{fallbackReads++;return expected.buffer.slice(0);}};
  const b=await ctx.window.parseFile(fallback,{rawOnly:true});
  assert.equal(fallbackReads,1,'fallback file should be read exactly once');
  assert.deepEqual(Array.from(b.rawDXFBytes),Array.from(expected));
  const view=new Uint8Array([99,...expected,88]).subarray(1,-1);
  const c=await ctx.window.parseFile(fakeZeroSize,{rawOnly:true,sourceBytes:view});
  assert.deepEqual(Array.from(c.rawDXFBytes),Array.from(expected),'typed-array byteOffset/byteLength not preserved');
  assert(html.includes('const supplied=options.sourceBytes;let buffer;'),'DWG worker does not receive sourceBytes');
  assert(html.includes('state.picks[slot]={x:px,y:py'), 'orientation pick assignment was not replaced with explicit coordinate capture');
  assert(html.includes('boardFingerprint:board.fingerprint,cadFingerprint:board.cadFingerprint'), 'orientation picks do not record file and CAD identity');
  assert(html.includes("boardFileName:String(board.file?.name||'')"), 'orientation pick does not record board filename');
  assert(html.includes('map.boardFingerprint!==board.fingerprint'),'canvas stale-map guard missing');
  assert(html.includes('p.canvasFingerprint!==board.fingerprint'),'orientation does not validate pick-to-canvas provenance');
  assert(html.includes('p.cadFingerprint!==board.cadFingerprint'),'orientation does not validate CAD-output provenance');
  assert(html.includes('SQ_V178_ORIENTATION_CAPTURE_AND_NATIVE_SAVE'),'V178 orientation/save marker missing');
  assert(html.includes('native.saveFile(filename,mime,base64)'),'native direct save route missing');
  assert(html.includes('return result??`Downloads/SurveyQuant/${filename}`'),'Java void-return save is not accepted');
  assert(html.includes('if(!out?.bytes?.length||!Number(out.editCount))'),'save does not require a nonempty edited DXF');
  console.log(JSON.stringify({
    sourceBytesUsedWithoutSecondRead:true,
    unreliableFileSizeZeroAccepted:true,
    fallbackReadCount:fallbackReads,
    typedArraySlicePreserved:true,
    workerReceivesSelectedBytes:true,
    orientationPickProvenance:true,
    staleCanvasMapRejected:true,
    result:'PASS'
  },null,2));
})().catch(e=>{console.error(e);process.exit(1);});
