# SurveyQuant v1.0.155: إعادة بناء Alignment وقراءة DWG

## الملفات
- `SurveyQuant_v1.0.155_ALIGNMENT_NATIVE_DWG.html`: واجهة التطبيق المعدلة؛ مشروع Alignment مستقل بدل وحدات التوجيه القديمة.
- `scripts/SurveyQuant_v1.0.155_ALIGNMENT_CORE.js`: حساب التحويل ثنائي النقطة ومعالجة DXF من سجلات group-code الأصلية.
- `scripts/SurveyQuant_v1.0.155_ALIGNMENT_COMMAND.js`: واجهة Alignment والالتقاط والتكبير والمعاينة.
- `scripts/SurveyQuant_v1.0.155_ALIGNMENT_TEST.js`: اختبارات التحويل، المحاور داخل الـBLOCK، الطبقات والـHandles وXData وحالات الرفض الآمن.
- `scripts/SurveyQuant_v1.0.155_BUILD_LIBREDWG.sh`: بناء LibreDWG-Web v0.8.2 من المصدر مع DXF writer، واختبار DWG حقيقي من ستة أجيال.
- `scripts/SurveyQuant_v1.0.155_DWG_CORPUS_TEST.mjs`: اختبار ملفات DWG الفعلية الموجودة في مجموعة اختبارات LibreDWG لإصدارات AC1015 وAC1018 وAC1021 وAC1024 وAC1027 وAC1032.
- `scripts/SurveyQuant_v1.0.155_PACKAGE_APK.py`: إدخال HTML وWASM إلى APK وإعادة ضبط رقم الإصدار، مع الاحتفاظ بواجهة UMD الحالية التي يعتمد عليها Android WebView.
- `build-v155-alignment-native-dwg.yml`: GitHub Actions workflow لبناء APK موقّع والحزمة الكاملة.

## مبدأ الحفاظ على اللوحة
أمر Alignment يطبق Scale + Rotate + Translate اعتمادًا على نقطتين من لوحة المصدر ونقطتين من اللوحة المرجعية. لا يستخدم هندسة المعاينة لإنشاء الملف الخارج. يتعامل مع سجلات DXF الأصلية الناتجة عن التحويل ويعدّل الحقول الهندسية المعروفة فقط. إذا صادف عنصرًا داخليًا/ثنائيًا لا يستطيع تحويله بأمان، يوقف التصدير بدل إسقاطه أو رسم بديل له.

**تنبيه مهم:** DWG يقرأ مباشرة لعرض بيانات CAD والتقاط المحاور، لكن التطبيق لا يملك كاتب DWG أصليًا، لذلك الملف الناتج عن Alignment عند إدخال DWG يكون DXF بعد تحويل مؤقت باستخدام LibreDWG. لا يصح الادعاء بأن بيانات DWG الخاصة أو الكتل الثنائية ستبقى مطابقة بايتًا ببايت. كما أن اختبارات مجموعة LibreDWG لا تحل محل تجربة ملف DWG المتعثر نفسه.

## إصلاح فشل البناء عند `dwg2.spec:5072`

السبب كان رقعة مصدر تستبدل مساحة كبيرة قبل `ARCALIGNEDTEXT` وتبحث عن أول `#endif` بعد الكيان، وهذا قد يحذف تعريفات أخرى ويخلّ بتوازن شروط المعالج المسبق. النسخة المصححة لا تعيد كتابة نطاق المصدر: تتحقق أولًا من توازن التوجيهات، ثم تغلق شرط `DEBUG_CLASSES/IS_FREE` قبل `ARCALIGNEDTEXT` مباشرة وتعيد فتحه بعد `DWG_ENTITY_END`. يظل باقي الملف كما هو، وتفشل الرقعة مبكرًا إذا تغير تركيب المصدر upstream بصورة غير متوقعة. اختبار regression ينفّذ كود الرقعة نفسه على fixture مصغّر ويتأكد من بقاء التعريفات المجاورة.

هذا تحقق من سلامة تعديل المصدر فقط، وليس ادعاءً بأن مكتبة WASM أو APK بُنيت بنجاح؛ يجب أن ينجح بناء GitHub Actions واختبارات ملفات DWG الفعلية أولًا.

## طريقة تشغيل البناء على GitHub
أداة GitHub المتاحة لهذه الجلسة رفضت الكتابة إلى المستودع برسالة `403 Resource not accessible by integration`، لذلك لم أرفع هذه الملفات إلى الريبو ولم أبدأ تشغيل CI من داخله. لتشغيل البناء:

1. ارفع هذا الملف `SurveyQuant_v1.0.155_ALIGNMENT_NATIVE_DWG_SOURCE_KIT.zip` إلى جذر مستودع `aboabdalla72229-hash/SurveyQuantAndroid_v1.0.57`، بدون فكّه.
2. ارفع ملف الـworkflow المرفق باسم `build-v155-alignment-native-dwg.yml` إلى المسار `.github/workflows/build-v155-alignment-native-dwg.yml`.
3. عند إضافة الـworkflow إلى الفرع `main`، يبدأ البناء تلقائيًا. أو افتح Actions وشغّل `Build SurveyQuant v1.0.155 Native DWG Alignment` يدويًا، مع ترك `source_run_id` على `40284521021`.
4. لا يُرفع APK إلا بعد نجاح بناء WASM والاختبارات الستة للـDWG واختبارات Alignment والتحقق من التوقيع.

يستخدم البناء أسرار التوقيع الحالية: `SURVEYQUANT_KEYSTORE_BASE64` و`SURVEYQUANT_KEYSTORE_PASSWORD` و`SURVEYQUANT_KEY_ALIAS` و`SURVEYQUANT_KEY_PASSWORD`. يجب أن تظل موجودة في إعدادات المستودع.
