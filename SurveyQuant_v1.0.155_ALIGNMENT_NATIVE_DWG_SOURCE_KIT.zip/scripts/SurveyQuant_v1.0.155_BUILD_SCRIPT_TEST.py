#!/usr/bin/env python3
"""Static safety gate for the V155 LibreDWG builder."""
from pathlib import Path
import sys
p = Path(__file__).with_name('SurveyQuant_v1.0.155_BUILD_LIBREDWG.sh')
s = p.read_text(encoding='utf-8')
checks = {
    'pinned upstream release': 'v0.8.2' in s,
    'writer enabled (upstream disable removed)': "cmd=cmd.replace(' --disable-write','',1)" in s,
    'DXF support enabled': '--enable-dxf' in s,
    'real DWG corpus test executed': 'node --test test/surveyquant-dwg-corpus.test.mjs' in s,
    'six regression generations': 'SurveyQuant_v1.0.155_DWG_CORPUS_TEST.mjs' in s,
    'fresh compiled WASM copied': 'libredwg-web.wasm' in s and 'libredwg-web.js' in s,
    'classic UMD wrapper retained': 'LEGACY_WRAPPER' in s and 'SurveyQuantLibreDwg' in s,
    'classic webview loader generated': "c.replace(' -s EXPORT_ES6=1',' -s EXPORT_ES6=0',1)" in s,
    'fails if corpus tests absent': "ERROR: SurveyQuant DWG corpus test missing" in s,
}
for label, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ': ' + label)
if not all(checks.values()): sys.exit(1)
