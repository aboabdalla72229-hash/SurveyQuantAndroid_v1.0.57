#!/usr/bin/env python3
from __future__ import annotations
import argparse, io, json, struct
from pathlib import Path
import ezdxf
from PIL import Image

EXPECTED_PAGE=(3200,2264)

def pairs(data: bytes):
    text=data.decode('latin1').replace('\r\n','\n').replace('\r','\n').split('\n')
    out=[]
    for i in range(0,len(text)-1,2):
        try: code=int(text[i].strip())
        except Exception: continue
        out.append((code,text[i+1].strip()))
    return out

def inspect(path:Path):
    raw=path.read_bytes(); ps=pairs(raw)
    entities=[]; current=None
    for code,value in ps:
        if code==0:
            if current is not None: entities.append(current)
            current={'type':value.upper(),'fields':[]}
        elif current is not None: current['fields'].append((code,value))
    if current is not None: entities.append(current)
    frames=[e for e in entities if e['type']=='OLE2FRAME']
    assert len(frames)==4, f'Expected four tiled OLE2FRAME objects, got {len(frames)}'
    rects=[]; total_jpeg=0; total_ole=0; sizes=[]
    for frame in frames:
        f=frame['fields']; vals=lambda c:[v for k,v in f if k==c]
        assert vals(70) and int(vals(70)[0])==2, 'OLE2FRAME version group 70 should be 2'
        assert vals(71) and int(vals(71)[0])==3, 'Object must be represented as a static OLE picture (71=3)'
        assert vals(72) and int(vals(72)[0])==0, 'OLE2FRAME must be in model space'
        assert vals(1) and vals(1)[0]=='OLE', 'OLE terminator group 1 missing'
        assert vals(3) and vals(3)[0]=='Paintbrush Picture', f'group 3 OLE class label mismatch: {vals(3)}'
        assert vals(90), 'OLE binary data length group 90 missing'
        assert all(len(v)<=254 for v in vals(310)), 'Each DXF binary group 310 chunk must not exceed 127 bytes'
        binary=b''.join(bytes.fromhex(v) for v in vals(310))
        assert len(binary)==int(vals(90)[0]), f'Group 90 size {vals(90)[0]} != group 310 bytes {len(binary)}'
        total_ole+=len(binary)
        version,format_id,name_len=struct.unpack_from('<III',binary,0)
        assert version==0x501, f'Unexpected OLE version: {version:#x}'
        assert format_id==5, f'Expected PresentationObject FormatID=5, got {format_id}'
        name=binary[12:12+name_len]
        assert name==b'DIB\0', f'Expected DIB class name, got {name!r}'
        pos=12+name_len
        himetric_w=struct.unpack_from('<I',binary,pos)[0]; himetric_h=struct.unpack_from('<i',binary,pos+4)[0]
        dib_size=struct.unpack_from('<I',binary,pos+8)[0]; pos+=12
        dib=binary[pos:]
        assert himetric_w>0 and himetric_h<0, 'DIB presentation extents must have positive width and negative height'
        assert len(dib)==dib_size, 'DIB payload size field mismatch'
        header_size,width,height,planes,bits,compression,image_size,xppm,yppm,used,important=struct.unpack_from('<IiiHHIIiiII',dib,0)
        assert header_size==40 and planes==1 and width>0 and height>0, 'Invalid BITMAPINFOHEADER geometry'
        assert width<=1600 and height<=1200, f'OLE tile too large for Autodesk recommended range: {width}x{height}'
        assert compression==4, f'Expected BI_JPEG compression=4, got {compression}'
        assert image_size==len(dib)-40, 'BI_JPEG image size must equal embedded JPEG byte count'
        jpg=dib[40:]
        assert jpg[:2]==b'\xff\xd8' and jpg[-2:]==b'\xff\xd9', 'JPEG start/end markers missing'
        with Image.open(io.BytesIO(jpg)) as im: im.verify()
        with Image.open(io.BytesIO(jpg)) as im: assert im.size==(width,height), f'JPEG size {im.size} does not match DIB {width}x{height}'
        total_jpeg+=len(jpg);sizes.append([width,height])
        x0=float(vals(10)[0]);y_top=float(vals(20)[0]);x1=float(vals(11)[0]);y_bottom=float(vals(21)[0])
        assert abs((x1-x0)-width)<1e-6 and abs((y_top-y_bottom)-height)<1e-6, 'OLE frame geometry does not match tile pixel size at factor 1'
        rects.append((x0,y_bottom,x1,y_top))
    # Four axis-aligned tiles must cover the complete PDF raster once, without overlap.
    for i,a in enumerate(rects):
        for b in rects[i+1:]:
            overlap_x=max(0,min(a[2],b[2])-max(a[0],b[0]))
            overlap_y=max(0,min(a[3],b[3])-max(a[1],b[1]))
            assert overlap_x*overlap_y==0, 'OLE tiles overlap'
    minx=min(r[0] for r in rects);miny=min(r[1] for r in rects);maxx=max(r[2] for r in rects);maxy=max(r[3] for r in rects)
    area=sum((r[2]-r[0])*(r[3]-r[1]) for r in rects)
    assert (minx,miny,maxx,maxy)==(0.0,0.0,float(EXPECTED_PAGE[0]),float(EXPECTED_PAGE[1])), 'Tiled OLE bounds do not match PDF raster page'
    assert area==EXPECTED_PAGE[0]*EXPECTED_PAGE[1], 'Tiled OLE entities leave a gap in the page'
    doc=ezdxf.readfile(path);audit=doc.audit()
    assert len(audit.errors)==0, f'ezdxf audit errors: {len(audit.errors)}'
    assert len(audit.fixes)==0, f'ezdxf audit fixes: {len(audit.fixes)}'
    model_types=[e.dxftype() for e in doc.modelspace()]
    assert model_types==['OLE2FRAME']*4, f'Unexpected modelspace entities: {model_types}'
    assert not any(t in ('IMAGE','IMAGEDEF','IMAGEDEF_REACTOR') for t in model_types), 'External image reference is not allowed'
    assert b'PK\x03\x04' not in raw, 'DXF must not be a ZIP archive'
    return {'status':'PASS','dxf_bytes':len(raw),'ole_frames':len(frames),'ole_bytes':total_ole,'jpeg_bytes':total_jpeg,
            'page_width':EXPECTED_PAGE[0],'page_height':EXPECTED_PAGE[1],'tile_dimensions':sizes,
            'modelspace_entities':model_types,'ezdxf_audit_errors':0,'ezdxf_audit_fixes':0,'single_file_no_external_image':True}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('dxf',type=Path);ap.add_argument('--report',type=Path);a=ap.parse_args()
    result=inspect(a.dxf);text=json.dumps(result,ensure_ascii=False,indent=2);print(text)
    if a.report:a.report.write_text(text+'\n',encoding='utf-8')
