(function(){
'use strict';
function sqOriPointOf(entity) {
  const p=entity && (entity.position||entity.startPoint||entity.insertionPoint||entity.point||entity);
  const x=Number(p && p.x), y=Number(p && p.y);
  return Number.isFinite(x)&&Number.isFinite(y)?{x,y}:null;
}
function sqOriLabelText(entity) {
  let t=String(entity && (entity.text??entity.string??entity.value??entity.content??entity.textString??'')||'');
  t=t.replace(/\\P/gi,' ').replace(/\{[^;]*;/g,' ').replace(/[{}]/g,' ').replace(/%%[dpc]/gi,' ').trim();
  if(!t || t.length>8 || /[.,]/.test(t)) return '';
  t=t.replace(/\s+/g,'').toUpperCase();
  // Grid-bubble labels only. Exclude dimensions and long notes.
  return /^[A-Z\u0600-\u06FF]{1,3}\d{0,3}$/.test(t) || /^\d{1,3}[A-Z\u0600-\u06FF]{0,2}$/.test(t) ? t : '';
}
function sqOriModelGeometry(model) {
  const segments=[],labels=[],seenSeg=new Set();
  const pushSeg=(a,b,layer,type)=>{
    if(!a||!b) return;
    const ax=Number(a.x),ay=Number(a.y),bx=Number(b.x),by=Number(b.y);
    if(![ax,ay,bx,by].every(Number.isFinite)||Math.hypot(bx-ax,by-ay)<1e-8)return;
    const u=[ax,ay],v=[bx,by];
    const one=u[0]<v[0]||(u[0]===v[0]&&u[1]<=v[1]);
    const key=(one?u.concat(v):v.concat(u)).map(n=>Number(n).toFixed(5)).join('|')+'|'+String(layer||'0');
    if(seenSeg.has(key))return;seenSeg.add(key);
    segments.push({a:{x:ax,y:ay},b:{x:bx,y:by},layer:String(layer||'0'),type:type||'LINE'});
  };
  const rows=Array.isArray(model&&model.entities)?model.entities:[];
  for(const e of rows){
    const type=String(e&&e.type||'').toUpperCase(),layer=e&&e.layer||'0';
    if(['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(type)){
      const at=sqOriPointOf(e),label=sqOriLabelText(e);
      if(at&&label)labels.push({x:at.x,y:at.y,label,height:Math.abs(Number(e.height||e.textHeight)||0),layer});
    }
    if(type==='LINE')pushSeg(e.a||e.start||e.vertices?.[0],e.b||e.end||e.vertices?.[1],layer,type);
    else if(type==='LWPOLYLINE'||type==='POLYLINE'){
      const vs=Array.isArray(e.vertices)?e.vertices:[];
      for(let i=0;i<vs.length-1;i++)pushSeg(vs[i],vs[i+1],layer,type);
      if((e.closed===true||e.closed===1||e.isClosed===true)&&vs.length>2)pushSeg(vs[vs.length-1],vs[0],layer,type);
    } else if(type==='XLINE'||type==='RAY'){
      const a=e.basePoint||e.position, v=e.directionVector;
      if(a&&v){const k=type==='RAY'?100000:100000;pushSeg({x:a.x-v.x*k,y:a.y-v.y*k},{x:a.x+v.x*k,y:a.y+v.y*k},layer,type);}
    }
    for(const at of (e&&(e.attribs||e.attributes)||[])){
      const point=sqOriPointOf(at),label=sqOriLabelText(at);
      if(point&&label)labels.push({x:point.x,y:point.y,label,height:Math.abs(Number(at.height||at.textHeight)||0),layer:at.layer||layer});
    }
  }
  // The app's baseline parser also exposes a raw-DXF fallback that expands inserted
  // blocks and sees XLINE/RAY records the common parser may skip.
  try{
    const raw=(model&&model.rawDXF)||'';
    if(raw&&typeof window.sqExtractDxfAxisEntities==='function'){
      for(const e of window.sqExtractDxfAxisEntities(raw)){
        const type=String(e.type||'').toUpperCase(),layer=e.layer||'0';
        if(['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(type)){
          const point=sqOriPointOf(e),label=sqOriLabelText(e);
          if(point&&label)labels.push({x:point.x,y:point.y,label,height:Math.abs(Number(e.height)||0),layer});
        }
        if(type==='LINE')pushSeg(e.a,e.b,layer,type);
        else if(type==='XLINE'||type==='RAY'){
          const a=e.basePoint,v=e.directionVector;
          if(a&&v)pushSeg({x:a.x-v.x*100000,y:a.y-v.y*100000},{x:a.x+v.x*100000,y:a.y+v.y*100000},layer,type);
        }
      }
    }
  }catch(_){}
  // Remove duplicate text anchors (normal parser + raw record fallback).
  const labelMap=new Map();
  for(const l of labels){const key=l.label+'|'+l.x.toFixed(4)+'|'+l.y.toFixed(4);if(!labelMap.has(key))labelMap.set(key,l);}
  labels.splice(0,labels.length,...labelMap.values());
  return {segments,labels};
}
function sqOriAngleDiff(a,b){let d=Math.abs(a-b)%Math.PI;return Math.min(d,Math.PI-d);}
function sqOriIntersect(a,b){
  const rx=a.b.x-a.a.x,ry=a.b.y-a.a.y,sx=b.b.x-b.a.x,sy=b.b.y-b.a.y;
  const den=rx*sy-ry*sx;if(Math.abs(den)<1e-9)return null;
  const qx=b.a.x-a.a.x,qy=b.a.y-a.a.y,t=(qx*sy-qy*sx)/den;
  const x=a.a.x+t*rx,y=a.a.y+t*ry;
  return Number.isFinite(x)&&Number.isFinite(y)?{x,y}:null;
}
function sqOriDetectIntersections(model) {
  const g=sqOriModelGeometry(model),lines=g.segments;
  if(lines.length<2||g.labels.length<2)return {intersections:new Map(),lineCount:lines.length,labelCount:g.labels.length,families:[0,0]};
  let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
  const seePoint=p=>{minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);};
  for(const l of lines){seePoint(l.a);seePoint(l.b);}
  for(const l of g.labels)seePoint(l);
  const diag=Math.hypot(maxX-minX,maxY-minY);
  const medianHeight=(()=>{const h=g.labels.map(x=>x.height).filter(x=>x>0).sort((a,b)=>a-b);return h.length?h[Math.floor(h.length/2)]:0;})();
  const minLength=Math.max(diag*0.075,medianHeight*4,1e-7);
  const cand=lines.map(l=>({...l,len:Math.hypot(l.b.x-l.a.x,l.b.y-l.a.y),angle:Math.atan2(l.b.y-l.a.y,l.b.x-l.a.x)})).filter(l=>l.len>=minLength&&l.type!=='RAY'&&l.type!=='XLINE');
  if(cand.length<2)return {intersections:new Map(),lineCount:cand.length,labelCount:g.labels.length,families:[0,0]};
  // Precompute each candidate's family score once. The previous nested filtering
  // recalculated every family inside every pair (cubic cost) and could stall on
  // real site drawings containing thousands of CAD line entities.
  const normAngles=cand.map(l=>((l.angle%Math.PI)+Math.PI)%Math.PI);
  const familyScores=cand.map((_,i)=>{let score=0;for(let j=0;j<cand.length;j++)if(sqOriAngleDiff(normAngles[i],normAngles[j])<=Math.PI*12/180)score+=cand[j].len;return score;});
  let best=null;
  for(let i=0;i<cand.length;i++)for(let j=i+1;j<cand.length;j++){
    const a=normAngles[i],b=normAngles[j],d=sqOriAngleDiff(a,b);
    if(d<Math.PI*70/180||d>Math.PI*110/180)continue;
    const score=familyScores[i]+familyScores[j];
    if(!best||score>best.score)best={a,b,score};
  }
  if(!best)return {intersections:new Map(),lineCount:cand.length,labelCount:g.labels.length,families:[0,0]};
  const famA=cand.filter(l=>sqOriAngleDiff(((l.angle%Math.PI)+Math.PI)%Math.PI,best.a)<=Math.PI*12/180);
  const famB=cand.filter(l=>sqOriAngleDiff(((l.angle%Math.PI)+Math.PI)%Math.PI,best.b)<=Math.PI*12/180);
  const tol=Math.max(diag*0.025,medianHeight*3,1e-5);
  const taggedA=famA.map(l=>({...l,labels:[]})),taggedB=famB.map(l=>({...l,labels:[]}));
  // A bubble label is assigned to only one line family. At a grid corner its
  // insertion point may be near both lines; prefer labels just beyond a line end.
  for(const t of g.labels){
    let best=null;
    for(const [family,tagged] of [['A',taggedA],['B',taggedB]])for(const line of tagged){
      const vx=line.b.x-line.a.x,vy=line.b.y-line.a.y,den=line.len*line.len;
      const wx=t.x-line.a.x,wy=t.y-line.a.y,u=(wx*vx+wy*vy)/den;
      if(u < -tol/line.len || u > 1+tol/line.len)continue;
      const perp=Math.abs(vx*wy-vy*wx)/line.len;
      const endDistance=Math.min(Math.hypot(t.x-line.a.x,t.y-line.a.y),Math.hypot(t.x-line.b.x,t.y-line.b.y));
      if(perp>tol||endDistance>Math.max(tol,line.len*0.16))continue;
      const beyond=(u < -1e-4 || u > 1.0001);
      const nearEnd=Math.min(Math.abs(u),Math.abs(1-u));
      const score=perp/tol+endDistance/tol+(beyond?0:1.5+nearEnd*3);
      if(!best||score<best.score)best={family,line,score};
    }
    if(best&&best.score<4.5&&!best.line.labels.includes(t.label))best.line.labels.push(t.label);
  }
  const out=new Map();
  for(const a of taggedA)for(const b of taggedB){
    const p=sqOriIntersect(a,b);if(!p)continue;
    for(const la of a.labels)for(const lb of b.labels){if(la===lb)continue;const key=[la,lb].sort().join('|');
      const prev=out.get(key);if(!prev||prev.score>0)out.set(key,{x:p.x,y:p.y,labels:[la,lb],score:0});
    }
  }
  return {intersections:out,lineCount:cand.length,labelCount:g.labels.length,families:[taggedA.length,taggedB.length]};
}
function sqOriMatchIntersections(refModel,sourceModel) {
  const ref=sqOriDetectIntersections(refModel),src=sqOriDetectIntersections(sourceModel),matches=[];
  for(const [key,p] of src.intersections){const q=ref.intersections.get(key);if(q)matches.push({key,source:{x:p.x,y:p.y},reference:{x:q.x,y:q.y}});}
  if(matches.length>=2){
    let best=null;
    for(let i=0;i<matches.length;i++)for(let j=i+1;j<matches.length;j++){
      const d=Math.hypot(matches[i].source.x-matches[j].source.x,matches[i].source.y-matches[j].source.y);
      if(!best||d>best.distance)best={first:matches[i],second:matches[j],distance:d};
    }
    if(best&&best.distance>1e-8)return {ref,src,matches,best};
  }
  return {ref,src,matches,best:null};
}
async function sqOriLoadCadModel(file) {
  if(!file)throw new Error('اختر اللوحتين أولًا.');
  if(typeof window.parseFile!=='function')throw new Error('قارئ ملفات CAD في التطبيق غير متاح. أغلق المشروع وأعد فتحه.');
  return await window.parseFile(file);
}
async function sqOriReadAxes() {
  try {
    const refFile=document.getElementById('sqOriReferenceFile').files[0];
    const sourceFile=document.getElementById('sqOriTargetFile').files[0];
    if(!refFile||!sourceFile)throw new Error('اختر اللوحة المرجعية واللوحة المطلوب توجيهها قبل قراءة المحاور.');
    sqAxisMessage('جارٍ قراءة عناصر CAD ومحاور اللوحتين...',false);
    const [refModel,sourceModel]=await Promise.all([sqOriLoadCadModel(refFile),sqOriLoadCadModel(sourceFile)]);
    const result=sqOriMatchIntersections(refModel,sourceModel);
    if(!result.best){
      throw new Error('قرأت اللوحتين لكن لم أجد تقاطعين مشتركين لمحورين مُسمّيين بوضوح. المرجع: '+result.ref.intersections.size+' تقاطعًا، اللوحة غير الموجهة: '+result.src.intersections.size+' تقاطعًا، التسميات المقروءة: '+result.ref.labelCount+'/'+result.src.labelCount+'. تأكد من وجود تسميات محاور مثل A/B و1/2 قرب نهايات خطوط الشبكة، أو أدخل إحداثيات النقطتين يدويًا.');
    }
    const a=result.best.first,b=result.best.second;
    for(const [prefix,p] of [['sqOriR1',a.reference],['sqOriS1',a.source],['sqOriR2',b.reference],['sqOriS2',b.source]]){
      document.getElementById(prefix+'X').value=String(p.x);
      document.getElementById(prefix+'Y').value=String(p.y);
    }
    sqAxisMessage('تمت قراءة اللوحتين بنجاح. تم اكتشاف '+result.ref.intersections.size+' تقاطعًا في المرجع و'+result.src.intersections.size+' في اللوحة غير الموجهة، وتطابق '+result.matches.length+' تقاطعًا بالمسميات. تم اختيار أبعد نقطتين مشتركتين: '+a.key+' و'+b.key+'. راجع الإحداثيات ثم اضغط «توجيه وإخراج».',false);
  } catch(e){sqAxisMessage((e&&e.message)?e.message:String(e),true);}
}
async function sqOriConvertTargetToDxf(targetFile, loaderOverride) {
  const ext=String(targetFile&&targetFile.name||'').toLowerCase().split('.').pop();
  const bytes=new Uint8Array(await targetFile.arrayBuffer());
  if(ext==='dxf')return {bytes,name:targetFile.name};
  if(ext!=='dwg')throw new Error('اللوحة المطلوب توجيهها يجب أن تكون DXF أو DWG.');
  const loader=loaderOverride||(typeof window.loadDWG==='function'?window.loadDWG:null);
  if(!loader)throw new Error('محرك تحويل DWG إلى DXF غير متاح داخل التطبيق.');
  const mod=await loader();
  const LibreDwg=mod&& (mod.LibreDwg||mod.default?.LibreDwg);
  if(!LibreDwg||typeof LibreDwg.create!=='function')throw new Error('تعذر تحميل محرك LibreDWG.');
  const lib=await LibreDwg.create();
  if(typeof lib.dwg_write_dxf!=='function')throw new Error('إصدار محرك DWG الحالي لا يدعم تصدير DXF. احفظ اللوحة بصيغة DXF من CAD ثم أعد المحاولة.');
  const converted=lib.dwg_write_dxf(bytes.buffer);
  if(!converted||!converted.length)throw new Error('فشل تحويل اللوحة DWG إلى DXF. الملف الأصلي لم يتغير.');
  const out=converted instanceof Uint8Array?converted:new Uint8Array(converted);
  return {bytes:out,name:targetFile.name.replace(/\.dwg$/i,'.dxf')};
}


function sqAxisMessage(message,bad){
 const box=document.getElementById('sqOriStatus');if(!box)return;
 box.style.display='block';box.style.color=bad?'#ffc6c6':'#d1fae5';box.style.borderColor=bad?'#b91c1c':'#15803d';box.textContent=message;
}
function sqOriAxisInstall(){
 const actions=document.querySelector('.sqori-actions'),overlay=document.getElementById('sqOriOverlay');
 if(!actions||!overlay)return;
 // Update the older v106 wording and suppress its stale DWG warning so the UI
 // matches the new temporary-copy conversion hook below.
 const targetInput=document.getElementById('sqOriTargetFile');
 if(targetInput){
  const label=targetInput.parentNode;
  if(label&&label.firstChild&&label.firstChild.nodeType===3)label.firstChild.textContent='اللوحة المطلوب توجيهها (DWG / DXF)';
  if(!targetInput.dataset.sqAxisChangeHook){
   targetInput.dataset.sqAxisChangeHook='1';
   targetInput.addEventListener('change',function(event){
    const f=this.files&&this.files[0];
    if(f&&/\.dwg$/i.test(f.name)){
     event.stopImmediatePropagation();
     sqAxisMessage('تم اختيار DWG. سيقرأ البرنامج اللوحة المرجعية والهدف، وعند الإخراج سيحاول تحويل نسخة مؤقتة إلى DXF دون الكتابة فوق الملف الأصلي. قد لا تنتقل كائنات Civil 3D أو العناصر الوكيلة بالكامل.',false);
    }
   },true);
  }
 }
 const notices=overlay.querySelectorAll('.sqori-help');
 if(notices.length>1)notices[1].textContent='عند اختيار DWG كلوحة هدف، يحاول البرنامج تحويل نسخة مؤقتة إلى DXF ثم توجيهها. التحويل قد لا يحافظ على كل كائنات Civil 3D أو الكائنات الوكيلة؛ اختبر الناتج على نسخة. الملف المرجعي والملف الأصلي لا يتم استبدالهما.';
 if(!document.getElementById('sqOriReadAxesBtn')){
  const b=document.createElement('button');b.type='button';b.id='sqOriReadAxesBtn';b.className='sqori-preview';b.textContent='🧭 قراءة محاور اللوحتين تلقائيًا';
  b.addEventListener('click',sqOriReadAxes);actions.insertBefore(b,actions.firstChild);
 }
 // The existing orientation engine edits text-DXF bytes. Convert a selected DWG
 // copy to DXF before its original click handler runs, while leaving the source intact.
 const run=document.getElementById('sqOriRunBtn'),target=document.getElementById('sqOriTargetFile');
 if(run&&target&&!run.dataset.sqAxisConvertHook){
  run.dataset.sqAxisConvertHook='1';let allowOriginalClick=false,busy=false;
  run.addEventListener('click',async function(event){
   if(allowOriginalClick){allowOriginalClick=false;return;}
   const file=target.files&&target.files[0];if(!file||!/\.dwg$/i.test(file.name)||busy)return;
   event.preventDefault();event.stopImmediatePropagation();busy=true;
   try{
    const converted=await sqOriConvertTargetToDxf(file);
    if(typeof File!=='function'||typeof DataTransfer!=='function')throw new Error('هذا الجهاز لا يسمح باستبدال اختيار DWG مؤقتًا. احفظ نسخة DXF من اللوحة ثم أعد المحاولة.');
    const f=new File([converted.bytes],converted.name,{type:'application/dxf'}),dt=new DataTransfer();dt.items.add(f);target.files=dt.files;
    allowOriginalClick=true;run.click();
   }catch(e){sqAxisMessage((e&&e.message)?e.message:String(e),true);}
   finally{busy=false;}
  },true);
 }
}
window.__sqOriAxisAutoTest={detectIntersections:sqOriDetectIntersections,matchIntersections:sqOriMatchIntersections,convertTargetToDxf:sqOriConvertTargetToDxf};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',sqOriAxisInstall,{once:true});else sqOriAxisInstall();

})();
