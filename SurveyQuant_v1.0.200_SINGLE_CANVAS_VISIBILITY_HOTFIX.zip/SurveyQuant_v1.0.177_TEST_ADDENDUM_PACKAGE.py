#!/usr/bin/env python3
"""Structural/syntax test for the injected V177 addendum."""
from __future__ import annotations
import argparse
import re
import subprocess
import tempfile
from pathlib import Path

MARKER = "<!-- SURVEYQUANT_V177_SINGLE_CANVAS_DATA_EXPORT_INTEGRATED -->"
SCRIPT_ID = 'id="sq177-single-canvas-data-export"'
MODULE_MARKER = "/* SURVEYQUANT_V177_SINGLE_CANVAS_DATA_EXPORT_ADDENDUM */"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--html", type=Path, required=True)
    ap.add_argument("--module", type=Path, required=True)
    ns = ap.parse_args()
    html = ns.html.read_text(encoding="utf-8")
    module = ns.module.read_text(encoding="utf-8")
    assert MARKER in html, "integration marker missing"
    assert html.count(MARKER) == 1, "duplicate integration marker"
    assert html.count(SCRIPT_ID) == 1, "missing or duplicate inline script"
    assert MODULE_MARKER in module, "source module marker missing"
    assert "card.id='sq177OrientationCard'" in module
    assert "card.id='sq177DataExportCard'" in module
    assert "const MOUNT_STYLE_ID=MODULE_ID+'-style'" in module, "mount sentinel must be distinct from the script element ID"
    assert "getElementById(MOUNT_STYLE_ID)" in module, "mount guard must check the style sentinel, not the inline script ID"
    assert "getElementById(MODULE_ID)" not in module, "regression: module must not treat its own script element as already mounted"
    assert "const CAD=()=>root.SurveyQuantCAD177||root.SurveyQuantCAD176||root.SurveyQuantCAD162;" in module, "addendum must bind to the V177 CAD engine export"
    assert "mergeRawDxfBoards" in module
    assert "createOrientedDxfBytes" in module
    for token in ["تحديد عنصر", "تحديد نافذة", "تحديد مشابه", "حذف المحدد", "استعادة المحذوف", "function deleteSelected", "function selectWindow", "function selectSimilar"]:
        assert token in module, f"missing CAD selection/delete capability: {token}"
    assert "kind==='dxf'&&d.deleted.length" in module, "DXF export must refuse to claim deleted entities were saved when raw-record deletion is unsupported"
    assert not re.search(r"localStorage\s*\.", module), "session persistence is not allowed"
    assert re.search(r"</script>\s*" + re.escape(MARKER), html), "addendum is not placed before the integration marker"
    match = re.search(r'<script\s+id="sq177-single-canvas-data-export">([\s\S]*?)</script>', html, re.I)
    assert match, "inline addendum script not found"
    with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8") as f:
        f.write(match.group(1))
        f.flush()
        r = subprocess.run(["node", "--check", f.name], capture_output=True, text=True)
        if r.returncode:
            raise SystemExit(r.stderr or "node --check failed")
    print("PASS addendum integration: one inline script, stable project IDs, entity/window/similar selection and delete/restore controls, no localStorage, JavaScript syntax valid")

if __name__ == "__main__":
    main()
