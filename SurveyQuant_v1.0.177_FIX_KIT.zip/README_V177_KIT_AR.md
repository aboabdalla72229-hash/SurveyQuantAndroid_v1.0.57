# حزمة إصلاح SurveyQuant V177

1) ارفع هذا الملف بالاسم SurveyQuant_v1.0.177_FIX_KIT.zip إلى جذر مستودع GitHub.
2) ارفع ملف build-v177-v162-filebytes-orientation-pdf-fix.yml إلى:
   .github/workflows/build-v177-v162-filebytes-orientation-pdf-fix.yml
3) افتح Actions وشغّل workflow: Build SurveyQuant v1.0.177 V162 File Bytes, Orientation and PDF DXF Fix.
4) اترك source_run_id = 40919113310 لاستخدام V162 الناجحة.
5) يحتاج توقيع APK إلى أسرار GitHub الأربعة الموجودة بالمستودع.

الحزمة تحتوي على ملفات المرحلة الوسيطة V176 لأنها تُطبق فقط فوق ملفات V162 النظيفة، ثم تصحيح V177. لا ترفع SOURCE_PATCH_PREBUILD بدل FIX_KIT.

اختبارات محلية شغّلت على مصدر V162 مستخرج حديثًا: point parser، Android file.size=0، fingerprint/اختيار نقاط التوجيه، ملفات لوحتين مختلفتين، merge للـBLOCK/INSERT/LAYER، PDF vector، ezdxf audit/save/reopen، WASM، JavaScript/Python syntax، وتغليف APK غير موقع.

ملفات DWG/PDF الأصلية التي فشلت على الهاتف غير متاحة في هذه المحادثة؛ يجب اختبارها بعد تثبيت APK الموقع.
