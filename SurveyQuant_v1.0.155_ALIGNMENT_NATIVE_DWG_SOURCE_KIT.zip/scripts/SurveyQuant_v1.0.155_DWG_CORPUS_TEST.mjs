import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import { Dwg_File_Type, LibreDwg } from '../dist/libredwg-web.js';

const here = dirname(fileURLToPath(import.meta.url));
const packageRoot = join(here, '..');
const repoRoot = join(packageRoot, '..', '..');
const wasmDir = join(packageRoot, 'wasm');
const fixtures = [
  ['2000/Line.dwg', 'AC1015'],
  ['2004/Line.dwg', 'AC1018'],
  ['2007/Line.dwg', 'AC1021'],
  ['2010/Line.dwg', 'AC1024'],
  ['2013/Line.dwg', 'AC1027'],
  ['2018/Line.dwg', 'AC1032'],
];

test('SurveyQuant: read native DWG database and convert the same raw file to DXF across six DWG generations', async t => {
  const lib = await LibreDwg.create(wasmDir);
  for (const [relative, expectedHeader] of fixtures) {
    await t.test(relative, () => {
      const path = join(repoRoot, 'test', 'test-data', relative);
      const bytes = readFileSync(path);
      assert.equal(bytes.subarray(0, 6).toString('ascii'), expectedHeader, 'fixture DWG version signature');
      const ptr = lib.dwg_read_data(bytes, Dwg_File_Type.DWG);
      assert.ok(ptr, `native DWG read returned a pointer for ${relative}`);
      let database;
      try {
        const version = lib.dwg_get_version_type(ptr);
        assert.equal(version.hdr, expectedHeader);
        database = lib.convert(ptr);
        assert.ok(database && database.tables, 'native DWG database includes CAD tables');
        assert.ok(Array.isArray(database.entities) && database.entities.length > 0, 'native parser retained drawing entities');
        const layers = database.tables?.LAYER?.entries || database.tables?.layers?.entries || [];
        assert.ok(layers.length > 0, 'native parser retained layer records');
      } finally {
        lib.dwg_free(ptr);
      }
      const dxf = lib.dwg_write_dxf(bytes);
      assert.ok(dxf instanceof Uint8Array && dxf.length > 128, 'DWG-to-DXF conversion returned bytes');
      const raw = Buffer.from(dxf).toString('latin1');
      assert.match(raw, /SECTION/i, 'converted file contains a DXF section');
      assert.match(raw, /EOF\s*$/i, 'converted DXF terminates cleanly');
      assert.match(raw, /LAYER/i, 'converted DXF retains a layer table');
    });
  }
});
