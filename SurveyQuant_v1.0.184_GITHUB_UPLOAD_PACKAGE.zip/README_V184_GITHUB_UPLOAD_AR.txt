خطوتان لتشغيل بناء SurveyQuant v1.0.184

1) ارفع الملف SurveyQuant_v1.0.184_FIX_BUNDLE.zip إلى جذر المستودع:
aboabdalla72229-hash/SurveyQuantAndroid_v1.0.57

2) ارفع ملف build-v184-separated-orientation-r2004.yml إلى المسار:
.github/workflows/build-v184-separated-orientation-r2004.yml

بعد وجود الملفين في main، أضف/ارفع حزمة الإصلاح إلى الجذر ليعمل Workflow تلقائياً. عند نجاح جميع اختبارات DXF والتوجيه وPDF وتوفر أسرار التوقيع، سيظهر Artifact باسم:
SurveyQuant-v1.0.184-FREE-SEPARATE-ORIENTATION-R2004-PDF-DXF

المتطلبات الموجودة من بناء V183:
- SurveyQuant_v1.0.183_FIX_KIT.zip في جذر المستودع.
- GitHub Actions run 41614253243 يحتفظ بملف APK V183 الأساسي.
- Secrets: SURVEYQUANT_KEYSTORE_BASE64 وSURVEYQUANT_KEYSTORE_PASSWORD وSURVEYQUANT_KEY_ALIAS وSURVEYQUANT_KEY_PASSWORD.

لا تستبدل ملفات المصدر يدوياً ولا تحذف أي مشروع آخر. الـ Workflow يبني من V183 ثم يطبق إصلاحات V184 ويحتفظ بمحرك LibreDWG الحالي.
