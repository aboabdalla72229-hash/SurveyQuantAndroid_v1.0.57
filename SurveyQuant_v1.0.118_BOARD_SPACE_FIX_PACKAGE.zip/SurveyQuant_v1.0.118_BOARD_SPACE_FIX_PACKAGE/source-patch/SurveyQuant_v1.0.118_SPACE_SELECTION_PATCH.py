from pathlib import Path
import re, sys
manual_path, reference_path, index_path = map(Path, sys.argv[1:4])
manual = manual_path.read_text(encoding='utf-8')
reference = reference_path.read_text(encoding='utf-8')

def once(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f'ERROR: expected one {label} anchor; found {n}')
    return text.replace(old, new, 1)

helpers = r'''
function entitySpace(rec){
 const pairs=rec&&Array.isArray(rec.pairs)?rec.pairs:[];
 const flag=pairs.find(p=>p.code===67);
 if(flag&&Number(flag.value)===1)return 'PAPER_SPACE';
 const layout=pairs.find(p=>p.code===410);
 if(layout){const name=String(layout.value||'').trim().toUpperCase();if(name&&name!=='MODEL'&&name!=='*MODEL_SPACE'&&name!=='MODEL_SPACE')return 'PAPER_SPACE';}
 return 'MODEL_SPACE';
}
function hasDrawingCoordinates(rec){
 const type=String(rec&&rec.type||'').toUpperCase();
 if(!type||['VIEWPORT','SEQEND','ENDBLK','BLOCK','ENDSEC','ENDTAB','VERTEX','DICTIONARY','XRECORD'].includes(type))return false;
 const pairs=rec.pairs||[];
 const isNumeric=code=>pairs.some(p=>p.code===code&&Number.isFinite(Number(p.value)));
 for(let x=10;x<=18;x++)if(isNumeric(x)&&isNumeric(x+10))return true;
 if(['HATCH','DIMENSION','INSERT','POINT','IMAGE','WIPEOUT'].includes(type))return isNumeric(10)&&isNumeric(20);
 return false;
}
function spaceWeight(rec){
 if(!hasDrawingCoordinates(rec))return 0;
 const type=String(rec.type||'').toUpperCase();
 if(['LWPOLYLINE','POLYLINE','SPLINE','HATCH','INSERT','MLINE','3DFACE','SOLID','TRACE'].includes(type))return 3;
 if(['LINE','CIRCLE','ARC','ELLIPSE','DIMENSION','IMAGE','WIPEOUT'].includes(type))return 2;
 if(['TEXT','MTEXT','ATTRIB','ATTDEF','POINT','LEADER','MLEADER'].includes(type))return 1;
 return 1;
}
function selectDrawingSpace(entities){
 const all=Array.isArray(entities)?entities:[];
 const model=all.filter(e=>entitySpace(e)==='MODEL_SPACE');
 const paper=all.filter(e=>entitySpace(e)==='PAPER_SPACE');
 const modelScore=model.reduce((n,e)=>n+spaceWeight(e),0);
 const modelGeometry=model.filter(e=>spaceWeight(e)>0).length;
 if(modelGeometry>0)return {entities:model,spaceMode:'MODEL_SPACE',modelCount:model.length,paperCount:paper.length,layoutName:'Model'};
 if(!paper.length)return {entities:modelGeometry?model:[],spaceMode:'MODEL_SPACE',modelCount:model.length,paperCount:0,layoutName:'Model'};
 // Do not combine multiple layouts. Choose the single paper layout containing the
 // most actual geometry, excluding viewport boundary entities from the score.
 const layouts=new Map();
 for(const rec of paper){const lp=(rec.pairs||[]).find(p=>p.code===410);const layoutName=lp?String(lp.value||'').trim():'*PAPERSPACE';if(!layouts.has(layoutName))layouts.set(layoutName,[]);layouts.get(layoutName).push(rec);}
 let bestName='',bestEntities=[],bestScore=-1;
 for(const [name,items] of layouts){const score=items.reduce((n,e)=>n+spaceWeight(e),0);if(score>bestScore){bestName=name;bestEntities=items;bestScore=score;}}
 // If no code 410 values were present, all Paper Space entities form one legacy layout.
 if(layouts.size===1&&bestScore===0)bestEntities=paper;
 return {entities:bestEntities,spaceMode:'PAPER_SPACE',modelCount:model.length,paperCount:paper.length,layoutName:bestName||'*PAPERSPACE'};
}
// Keep full entity bounds for data fidelity but focus the initial view on the dominant drawing cluster.
// This viewport-only calculation never deletes or moves an entity.
function headerBoundsFromPairs(pairs){
 const read=name=>{const all=Array.isArray(pairs)?pairs:[],i=all.findIndex(p=>p.code===9&&String(p.value||'').trim().toUpperCase()===name);if(i<0)return null;let x=null,y=null;for(let j=i+1;j<all.length&&all[j].code!==9&&all[j].code!==0;j++){if(all[j].code===10&&x===null)x=Number(all[j].value);if(all[j].code===20&&y===null)y=Number(all[j].value);}return Number.isFinite(x)&&Number.isFinite(y)?{x,y}:null;};
 const lo=read('$EXTMIN'),hi=read('$EXTMAX');if(!lo||!hi||!(hi.x>lo.x)||!(hi.y>lo.y))return null;return {minX:lo.x,minY:lo.y,maxX:hi.x,maxY:hi.y};
}
function fitBoundsForPoints(points,fullBounds,headerBounds=null){
 const source=(Array.isArray(points)?points:[]).filter(p=>p&&Number.isFinite(Number(p.x))&&Number.isFinite(Number(p.y)));
 const full=fullBounds||{minX:0,minY:0,maxX:1,maxY:1};
 // Trust the original CAD header's saved extents only when it contains almost all
 // parsed geometry. A small number of block/annotation artifacts must not shrink
 // the whole board to a line, but all source entities remain present in the DXF.
 if(headerBounds&&source.length>=20&&[headerBounds.minX,headerBounds.minY,headerBounds.maxX,headerBounds.maxY].every(Number.isFinite)&&headerBounds.maxX>headerBounds.minX&&headerBounds.maxY>headerBounds.minY){
  const wx=(headerBounds.maxX-headerBounds.minX)*.01,wy=(headerBounds.maxY-headerBounds.minY)*.01;let inside=0,xLow=0,xHigh=0,yLow=0,yHigh=0;
  for(const p of source){const x=Number(p.x),y=Number(p.y);if(x<headerBounds.minX-wx)xLow++;if(x>headerBounds.maxX+wx)xHigh++;if(y<headerBounds.minY-wy)yLow++;if(y>headerBounds.maxY+wy)yHigh++;if(x>=headerBounds.minX-wx&&x<=headerBounds.maxX+wx&&y>=headerBounds.minY-wy&&y<=headerBounds.maxY+wy)inside++;}
  if(inside/source.length>=.98){const px=(headerBounds.maxX-headerBounds.minX)*.02,py=(headerBounds.maxY-headerBounds.minY)*.02;return {bounds:{minX:headerBounds.minX-px,minY:headerBounds.minY-py,maxX:headerBounds.maxX+px,maxY:headerBounds.maxY+py},excluded:{xLow,xHigh,yLow,yHigh},basis:'DXF_HEADER_EXTENTS',insideRatio:inside/source.length};}
 }
 function trimAxis(values,lowKey,highKey){
  const a=values.filter(Number.isFinite).sort((x,y)=>x-y);if(a.length<20)return {low:full[lowKey],high:full[highKey],lowRemoved:0,highRemoved:0};
  const span=a[a.length-1]-a[0];if(!(span>1e-9))return {low:full[lowKey],high:full[highKey],lowRemoved:0,highRemoved:0};
  const tailLimit=Math.max(3,Math.floor(a.length*.01));let best=null;
  for(let i=1;i<=tailLimit&&i<a.length/2;i++){const gap=a[i]-a[i-1],rest=a[a.length-1]-a[i];if(gap>Math.max(span*.1,rest*4)&&(!best||gap>best.gap))best={gap,side:'low',index:i,cut:a[i]};}
  for(let i=Math.max(1,a.length-tailLimit);i<a.length;i++){const gap=a[i]-a[i-1],rest=a[i-1]-a[0];if(gap>Math.max(span*.1,rest*4)&&(!best||gap>best.gap))best={gap,side:'high',index:i,cut:a[i-1]};}
  let low=full[lowKey],high=full[highKey],lowRemoved=0,highRemoved=0;
  if(best&&best.side==='low'){low=best.cut;lowRemoved=best.index;}
  if(best&&best.side==='high'){high=best.cut;highRemoved=a.length-best.index;}
  const remaining=Math.max(1e-9,high-low),pad=remaining*.02;
  return {low:low-pad,high:high+pad,lowRemoved,highRemoved};
 }
 const x=trimAxis(source.map(p=>Number(p.x)),'minX','maxX'),y=trimAxis(source.map(p=>Number(p.y)),'minY','maxY');
 const b={minX:x.low,minY:y.low,maxX:x.high,maxY:y.high};
 if(!(b.maxX>b.minX)||!(b.maxY>b.minY))return {bounds:{...full},excluded:{xLow:0,xHigh:0,yLow:0,yHigh:0}};
 return {bounds:b,excluded:{xLow:x.lowRemoved,xHigh:x.highRemoved,yLow:y.lowRemoved,yHigh:y.highRemoved}};
}
'''
manual = once(manual,
"flush();if(!sections.ENTITIES)throw new Error('لم يتم العثور على قسم ENTITIES داخل DXF.');return sections;\n}",
"flush();if(!sections.ENTITIES)throw new Error('لم يتم العثور على قسم ENTITIES داخل DXF.');return sections;\n}\n"+helpers,
"shared model/paper-space selector")
manual = once(manual,
" expand(sections.ENTITIES,makeMatrix());",
" const spaceSelection=selectDrawingSpace(sections.ENTITIES);\n expand(spaceSelection.entities,makeMatrix());",
"use one selected drawing space for preview")
manual = once(manual,
"return {segs,anchors,texts,fills,layers,bounds:{minX,minY,maxX,maxY},entityCount,unsupported,sourceFormat:'DXF'};",
"const bounds={minX,minY,maxX,maxY},fit=fitBoundsForPoints(anchors,bounds,headerBoundsFromPairs(pairs));return {segs,anchors,texts,fills,layers,bounds,fitBounds:fit.bounds,fitOutliersExcluded:fit.excluded,fitBoundsBasis:fit.basis||'ROBUST_GEOMETRY',entityCount,unsupported,sourceFormat:'DXF',spaceMode:spaceSelection.spaceMode,spaceLayout:spaceSelection.layoutName,modelEntityCount:spaceSelection.modelCount,paperEntityCount:spaceSelection.paperCount};",
"expose preview space info")
manual = once(manual,
"window.__sqManualOrientation109={parseDrawing,solve,segmentIntersection,findNearestIntersection,zoomTransformAt,pinchZoom,clampZoom,nearestOnDrawing:()=>drawing?nearestOnDrawing({x:(drawing.bounds.minX+drawing.bounds.maxX)/2,y:(drawing.bounds.minY+drawing.bounds.maxY)/2}):null,VERSION};",
"window.__sqManualOrientation109={parseDrawing,selectDrawingSpace,headerBoundsFromPairs,fitBoundsForPoints,solve,segmentIntersection,findNearestIntersection,zoomTransformAt,pinchZoom,clampZoom,nearestOnDrawing:()=>drawing?nearestOnDrawing({x:(drawing.bounds.minX+drawing.bounds.maxX)/2,y:(drawing.bounds.minY+drawing.bounds.maxY)/2}):null,VERSION};",
"expose shared selector API")

# The byte-preserving transformer must target the same space the preview chose.
old = """ const isPaper=rec=>rec.pairs.some(p=>p.code===67&&Number(p.value)===1);
 const hasXY=rec=>{const codes=new Set(rec.pairs.map(p=>p.code));for(let x=10;x<=18;x++)if(codes.has(x)&&codes.has(x+10))return true;return rec.type==='POINT'||rec.type==='INSERT'||rec.type==='HATCH'||rec.type==='DIMENSION';};
 const model=all.filter(r=>!isPaper(r)),paper=all.filter(isPaper);
 const modelHasGeometry=model.some(hasXY),paperFallback=!modelHasGeometry&&paper.some(hasXY);
 const records=modelHasGeometry?model:(paperFallback?paper:[]);
 if(!records.length)throw new Error('لم أجد كيانات هندسية قابلة للتحويل في Model Space أو Paper Space. قد تكون اللوحة مرجعًا خارجيًا أو محتوى CAD خاصًا لا يكشف إحداثياته. لم يتم حفظ إسقاط فارغ.');
 const dimBlockNames=new Set(all.filter(r=>r.type==='DIMENSION').map(r=>recordString(r,2).toUpperCase()).filter(Boolean));"""
new = """ const selector=window.__sqManualOrientation109&&window.__sqManualOrientation109.selectDrawingSpace;
 const selectedSpace=typeof selector==='function'?selector(all):null;
 const isPaper=rec=>rec.pairs.some(p=>p.code===67&&Number(p.value)===1);
 const hasXY=rec=>{const codes=new Set(rec.pairs.map(p=>p.code));for(let x=10;x<=18;x++)if(codes.has(x)&&codes.has(x+10))return true;return rec.type==='POINT'||rec.type==='INSERT'||rec.type==='HATCH'||rec.type==='DIMENSION';};
 const model=all.filter(r=>!isPaper(r)),paper=all.filter(isPaper);
 const modelHasGeometry=model.some(hasXY),legacyPaperFallback=!modelHasGeometry&&paper.some(hasXY);
 const records=selectedSpace?selectedSpace.entities:(modelHasGeometry?model:(legacyPaperFallback?paper:[]));
 const paperFallback=selectedSpace?selectedSpace.spaceMode==='PAPER_SPACE':legacyPaperFallback;
 if(!records.length)throw new Error('لم أجد كيانات هندسية قابلة للتحويل في Model Space أو في صفحة Layout بديلة. لم يتم حفظ ملف ناقص.');
 const dimBlockNames=new Set(records.filter(r=>r.type==='DIMENSION').map(r=>recordString(r,2).toUpperCase()).filter(Boolean));"""
reference = once(reference, old, new, "transformer shared space choice")

# Preview supplemental entities must come from the exact same chosen space.
old = "const parsed=splitPairs(bytes),all=sectionRecords(parsed.pairs,'ENTITIES'),blocks=blockDefinitions(parsed.pairs),usedFallback=!base;const parsedLayers=layerDefinitions(parsed.pairs);"
new = "const parsed=splitPairs(bytes),allRecords=sectionRecords(parsed.pairs,'ENTITIES'),selector=api.selectDrawingSpace,selection=typeof selector==='function'?selector(allRecords):{entities:allRecords,spaceMode:'MODEL_SPACE',layoutName:'Model',modelCount:allRecords.length,paperCount:0},all=selection.entities,blocks=blockDefinitions(parsed.pairs),usedFallback=!base;const parsedLayers=layerDefinitions(parsed.pairs);"
reference = once(reference, old, new, "preview shared space choice")
reference = once(reference,
"base.entityCount=Math.max(base.entityCount||0,all.length);base.originalEntityRecords=all.length;base.recoveredPairs=parsed.recoveryCount||0;",
"base.entityCount=Math.max(base.entityCount||0,all.length);base.originalEntityRecords=all.length;base.spaceMode=base.spaceMode||selection.spaceMode;base.spaceLayout=base.spaceLayout||selection.layoutName;base.modelEntityCount=selection.modelCount;base.paperEntityCount=selection.paperCount;base.recoveredPairs=parsed.recoveryCount||0;",
"preview active space metadata")
reference = once(reference,
"if(count)count.textContent='كيانات: '+v.drawing.entityCount+' | مقاطع: '+(v.drawing.segs||[]).length+' | طبقات: '+Object.keys(v.drawing.layers||{}).length+' | تكبير داخل اللوحة ×'+v.zoom.toFixed(2)+(v.drawing.unsupported?' | عناصر CAD خاصة: '+v.drawing.unsupported:'');",
"if(count)count.textContent='مساحة العرض: '+(v.drawing.spaceMode==='PAPER_SPACE'?'Layout '+(v.drawing.spaceLayout||''):'Model Space')+' | كيانات: '+v.drawing.entityCount+' | مقاطع: '+(v.drawing.segs||[]).length+' | طبقات: '+Object.keys(v.drawing.layers||{}).length+' | الإطار: '+(v.fitMode==='all'?'كل العناصر':'اللوحة الأساسية')+' | تكبير داخل اللوحة ×'+v.zoom.toFixed(2)+(v.drawing.unsupported?' | عناصر CAD خاصة: '+v.drawing.unsupported:'');",
"show active drawing space in readout")
reference = once(reference,
" return {bytes:output,transformedCount:transformedEntities,changedEntityCount,changedFields:ordered.length,unchangedOpaque,coordinateEntities,entitiesBefore:all.length,entitiesAfter:outRecords.length,layersPreserved:true,dimensionBlocksTransformed:dimensionBlockEntities.length,paperSpaceFallback:paperFallback};",
" return {bytes:output,transformedCount:transformedEntities,changedEntityCount,changedFields:ordered.length,unchangedOpaque,coordinateEntities,entitiesBefore:all.length,entitiesAfter:outRecords.length,layersPreserved:true,dimensionBlocksTransformed:dimensionBlockEntities.length,paperSpaceFallback:paperFallback,spaceMode:selectedSpace?selectedSpace.spaceMode:(paperFallback?'PAPER_SPACE':'MODEL_SPACE'),spaceLayout:selectedSpace?selectedSpace.layoutName:'Model'};",
"include chosen space in export result")
reference = once(reference,
"if(info)info.textContent='الملف: '+file.name+' | العناصر: '+view.drawing.entityCount+' | ملاحظة: جميع بيانات DXF الأصلية محفوظة عند الإخراج؛ المعاينة هنا هندسية.';status('تم فتح '+file.name+'. اختر النقطة 1 ثم 2؛ سيظهر رقم كل نقطة تلقائيًا على الرسم.'+(view.drawing.previewRecoveryMessage?' '+view.drawing.previewRecoveryMessage:''));",
"if(info)info.textContent='الملف: '+file.name+' | مساحة العرض: '+(view.drawing.spaceMode==='PAPER_SPACE'?'Layout '+(view.drawing.spaceLayout||''):'Model Space')+' | العناصر: '+view.drawing.entityCount+' | ملاحظة: بيانات DXF الأصلية محفوظة عند الإخراج؛ المعاينة هندسية.';status('تم فتح '+file.name+' في '+(view.drawing.spaceMode==='PAPER_SPACE'?'Layout '+(view.drawing.spaceLayout||''):'Model Space')+'. اختر النقطة 1 ثم 2؛ سيظهر رقم كل نقطة تلقائيًا على الرسم.'+(view.drawing.previewRecoveryMessage?' '+view.drawing.previewRecoveryMessage:''));",
"show chosen space when loading board")
# Open exported DXF around the chosen fit bounds while preserving true full extents.
reference = once(reference,
" const viewSize=headerVars.get('$VIEWSIZE')?.find(p=>p.code===40);if(viewSize){const n=numeric(viewSize.value);if(n!==null&&n>0)writeHeader(viewSize,n*t.scale);}\n if(!identity&&geometryChangedFields===0)",
" const viewSize=headerVars.get('$VIEWSIZE')?.find(p=>p.code===40);if(viewSize){const n=numeric(viewSize.value);if(n!==null&&n>0)writeHeader(viewSize,n*t.scale);}\n if(t.viewBounds&&['minX','minY','maxX','maxY'].every(k=>Number.isFinite(t.viewBounds[k]))){const b=t.viewBounds,corners=[t.point(b.minX,b.minY),t.point(b.minX,b.maxY),t.point(b.maxX,b.minY),t.point(b.maxX,b.maxY)],xs=corners.map(p=>p.x),ys=corners.map(p=>p.y),cx=(Math.min(...xs)+Math.max(...xs))/2,cy=(Math.min(...ys)+Math.max(...ys))/2,height=Math.max(1e-6,(Math.max(...ys)-Math.min(...ys))*1.12),center=headerPoint('$VIEWCTR');if(center){writeHeader(center.x,cx);writeHeader(center.y,cy);}if(viewSize)writeHeader(viewSize,height);}\n if(!identity&&geometryChangedFields===0)",
"save initial viewport around main board")

reference = once(reference,
"const t=review();if(!t)return;const engine=window.__sqOrientTest;",
"const t=review();if(!t)return;const activeView=state.views.target&&state.views.target.drawing;if(activeView)t.viewBounds=activeView.fitBounds||activeView.bounds;const engine=window.__sqOrientTest;",
"pass fit bounds to DXF export")

# Offer a detailed main-board fit and a separate full-extents view without deleting anything.
reference = once(reference,
'<button id="sq110TFit" class="sqori-preview" type="button">ملاءمة</button>',
'<button id="sq110TFit" class="sqori-preview" type="button">ملاءمة اللوحة</button><button id="sq110TFitAll" class="sqori-preview" type="button">عرض كل العناصر</button>',
"target fit controls")
reference = once(reference,
'<button id="sq110RFit" class="sqori-preview" type="button">ملاءمة</button>',
'<button id="sq110RFit" class="sqori-preview" type="button">ملاءمة اللوحة</button><button id="sq110RFitAll" class="sqori-preview" type="button">عرض كل العناصر</button>',
"reference fit controls")
reference = once(reference,
"el('sq110'+prefix+'Fit').addEventListener('click',()=>{const v=state.views[side];if(v){resetView(v);setZoom(side,1);}});",
"el('sq110'+prefix+'Fit').addEventListener('click',()=>{const v=state.views[side];if(v)fitView(v,'main');});el('sq110'+prefix+'FitAll').addEventListener('click',()=>{const v=state.views[side];if(v)fitView(v,'all');});",
"main-fit and full-extents actions")

# After supplementing the primary parser with CAD-specific elements, recompute both full and fit extents.
reference = once(reference,
"if(pts.length){let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;for(const p of pts){minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);}if(maxX-minX<1e-9){minX-=.5;maxX+=.5;}if(maxY-minY<1e-9){minY-=.5;maxY+=.5;}base.bounds={minX,minY,maxX,maxY};}\n else{base.bounds={minX:0,minY:0,maxX:1,maxY:1};base.previewWarning='تعذر رسم بعض أنواع العناصر هندسيًا في المعاينة؛ بيانات DXF الأصلية محفوظة. جرّب حفظ نسخة DXF نصية من برنامج CAD لعرض العناصر.';}",
"if(pts.length){let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;for(const p of pts){minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);}if(maxX-minX<1e-9){minX-=.5;maxX+=.5;}if(maxY-minY<1e-9){minY-=.5;maxY+=.5;}base.bounds={minX,minY,maxX,maxY};const fit=typeof api.fitBoundsForPoints==='function'?api.fitBoundsForPoints(pts,base.bounds,typeof api.headerBoundsFromPairs==='function'?api.headerBoundsFromPairs(parsed.pairs):null):{bounds:base.bounds,excluded:{xLow:0,xHigh:0,yLow:0,yHigh:0}};base.fitBounds=fit.bounds;base.fitOutliersExcluded=fit.excluded;base.fitBoundsBasis=fit.basis||'ROBUST_GEOMETRY';}\n else{base.bounds={minX:0,minY:0,maxX:1,maxY:1};base.fitBounds=base.bounds;base.fitOutliersExcluded={xLow:0,xHigh:0,yLow:0,yHigh:0};base.previewWarning='تعذر رسم بعض أنواع العناصر هندسيًا في المعاينة؛ بيانات DXF الأصلية محفوظة. جرّب حفظ نسخة DXF نصية من برنامج CAD لعرض العناصر.';}",
"focus initial view on dominant board without dropping elements")

# Add robust fit-to-board after loading a board: reset pan and fit the selected-space bounds.
reference = once(reference,
"state.views[side]=viewer;setupCanvas(viewer);buildLayerPanel(viewer);return viewer;}",
"state.views[side]=viewer;setupCanvas(viewer);buildLayerPanel(viewer);fitView(viewer,'main');return viewer;}",
"fit full selected board after load")
reference = once(reference,
"function metrics(v){const w=v.canvas.clientWidth||v.canvas.width||300,h=v.canvas.clientHeight||v.canvas.height||320,b=v.drawing.bounds,pad=18,base=Math.max(1e-12,Math.min((w-pad*2)/Math.max(1e-9,b.maxX-b.minX),(h-pad*2)/Math.max(1e-9,b.maxY-b.minY)));return {w,h,cx:(b.minX+b.maxX)/2,cy:(b.minY+b.maxY)/2,base,scale:base*v.zoom};}",
"function metrics(v){const w=v.canvas.clientWidth||v.canvas.width||300,h=v.canvas.clientHeight||v.canvas.height||320,b=v.fitMode==='all'?v.drawing.bounds:(v.drawing.fitBounds||v.drawing.bounds),pad=18,base=Math.max(1e-12,Math.min((w-pad*2)/Math.max(1e-9,b.maxX-b.minX),(h-pad*2)/Math.max(1e-9,b.maxY-b.minY)));return {w,h,cx:(b.minX+b.maxX)/2,cy:(b.minY+b.maxY)/2,base,scale:base*v.zoom};}\nfunction fitView(v,mode='main'){if(!v||!v.drawing||!v.canvas)return;v.fitMode=mode==='all'?'all':'main';v.zoom=1;v.panX=0;v.panY=0;draw(v);}",
"add fit-selected-space helper")

manual_path.write_text(manual,encoding='utf-8')
reference_path.write_text(reference,encoding='utf-8')
html=index_path.read_text(encoding='utf-8')
def replace_script(html, marker, body, label):
    if html.count(marker)!=1: raise SystemExit(f'ERROR: expected one {label} script marker, found {html.count(marker)}')
    start=html.index(marker)+len(marker)
    end=html.find('</script>',start)
    if end<0: raise SystemExit(f'ERROR: closing script marker missing for {label}')
    return html[:start]+'\n'+body+'\n'+html[end:]
html=replace_script(html,'<script id="sq-orientation-manual-points-module">',manual,'manual drawing parser')
html=replace_script(html,'<script id="sq-orientation-reference-board-module">',reference,'reference board/parser')
index_path.write_text(html,encoding='utf-8')
print('PATCH_OK: shared Model Space/Layout selector added to parser, preview extras, transform, HTML integration, and fit-on-load.')
