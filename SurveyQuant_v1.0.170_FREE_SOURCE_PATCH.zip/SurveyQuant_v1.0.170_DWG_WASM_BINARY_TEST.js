'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const [loaderPath,wasmPath,umdPath,dwgPath]=process.argv.slice(2);
if(!loaderPath||!wasmPath||!umdPath)throw new Error('Usage: node V170_DWG_WASM_BINARY_TEST.js <wasm-loader.js> <wasm-binary.wasm> <umd-engine.js> [sample.dwg]');
global.self=global;global.require=require;global.__dirname=require('node:path').dirname(loaderPath);global.__filename=loaderPath;
vm.runInThisContext(fs.readFileSync(loaderPath,'utf8'),{filename:loaderPath});
vm.runInThisContext(fs.readFileSync(umdPath,'utf8'),{filename:umdPath});
(async()=>{
 const wasmBinary=new Uint8Array(fs.readFileSync(wasmPath));assert.ok(wasmBinary.byteLength>1_000_000);
 const instance=await global.createModule({wasmBinary,locateFile:()=>wasmPath});
 const api=global.SurveyQuantLibreDwg;assert.ok(api?.LibreDwg?.createByWasmInstance);
 const lib=api.LibreDwg.createByWasmInstance(instance);
 assert.equal(typeof lib.dwg_write_dxf,'function');assert.equal(typeof lib.dwg_read_data,'function');
 let optional=null;
 if(dwgPath){const raw=new Uint8Array(fs.readFileSync(dwgPath));assert.match(new TextDecoder('latin1').decode(raw.slice(0,6)),/^AC10/);const converted=lib.dwg_write_dxf(raw.buffer);const bytes=converted instanceof Uint8Array?converted:new Uint8Array(converted);const head=new TextDecoder('latin1').decode(bytes.slice(0,256));const tail=new TextDecoder('latin1').decode(bytes.slice(-100));assert.match(head,/SECTION/);assert.match(tail,/EOF\s*$/);optional={dwgBytes:raw.length,dxfBytes:bytes.length};}
 console.log(JSON.stringify({ok:true,wasmBytes:wasmBinary.length,wasmFactory:'createModule({wasmBinary})',libreDwgInstance:'createByWasmInstance',exports:{dwg_write_dxf:typeof lib.dwg_write_dxf,dwg_read_data:typeof lib.dwg_read_data},optional},null,2));
})().catch(e=>{console.error(e);process.exit(1)});
