'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const htmlPath = process.argv[2];
assert(htmlPath, 'usage: node SurveyQuant_v1.0.127_TEXT_ZOOM_REGRESSION_TEST.js index.html');
const html = fs.readFileSync(htmlPath, 'utf8');

const activeFormula = 'fitTextSize=Math.min(4.5,Math.abs(Number(t.height)||2.5)*m.base*0.35),size=Math.max(0.1,fitTextSize/Math.max(1,Number(v.zoom)||1))';
const fallbackFormula = "ctx.fillStyle='#e9c46a';const fitTextSize=Math.min(4.5,Math.abs(Number(t.height)||2.5)*(m.scale/Math.max(0.001,zoom))*0.35);ctx.font=(Math.max(0.1,fitTextSize/Math.max(1,zoom)))+'px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);";
const oldFormula = 'size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale*Math.max(0.001,Number(v.zoom)||1))';
const oldFixedText = "ctx.fillStyle='#e9c46a';ctx.font='11px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);";
assert.equal(html.split(activeFormula).length - 1, 1, 'active renderer must have the corrected inverse-zoom text formula exactly once');
assert.equal(html.split(fallbackFormula).length - 1, 1, 'legacy preview renderer must not use a fixed 11px font');
assert(!html.includes(oldFormula), 'old zoom-squared text-size formula must be removed');
assert(!html.includes(oldFixedText), 'fixed 11px preview font must be removed');
assert(html.includes('function metrics(v){') && html.includes('scale:base*v.zoom'), 'geometry zoom transform must remain unchanged');
assert(html.includes('function setZoom(side,value){const v=state.views[side];if(!v)return;'), 'existing zoom setter must remain');
assert(html.includes('v.zoom=Math.max(.1584893,Math.min(1000,Number(value)||1))'), 'existing zoom bounds/sensitivity must remain unchanged');
assert(html.includes('function universalTransformBytes(input,t)'), 'byte-preserving CAD transform must remain');
assert(html.includes('dwg_write_dxf(bytes.buffer)'), 'native DWG conversion path must remain');
assert(html.includes('id="sq-v117-universal-dwg-bridge"'), 'all-project DWG bridge must remain embedded');
assert(html.includes('convertTargetToDxf'), 'real DWG converter API must remain available');

// Mirror the same sizing expression and prove that zooming in makes CAD annotations smaller.
const textSize = (height, base, zoom) => Math.max(0.1, Math.min(4.5, Math.abs(Number(height) || 2.5) * base * 0.35) / Math.max(1, Number(zoom) || 1));
const sizes = [1, 2, 4, 8].map(z => textSize(2.5, 3, z));
assert(sizes.every((v, i) => i === 0 || v < sizes[i - 1]), `CAD text must shrink monotonically with zoom-in: ${sizes}`);
assert(sizes[0] <= 4.5, `baseline text must be capped at 4.5px: ${sizes[0]}`);
console.log('PASS V127: CAD text is capped at 4.5px and shrinks with board zoom; geometry zoom behavior, two-board orientation, byte-preserving DXF transform, and universal DWG bridge stay intact.');
