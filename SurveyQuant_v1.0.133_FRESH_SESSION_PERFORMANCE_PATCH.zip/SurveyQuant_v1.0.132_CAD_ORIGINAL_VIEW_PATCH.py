#!/usr/bin/env python3
"""SurveyQuant v1.0.132: CAD preview fidelity, large canvas/true text zoom, strict source-board preservation."""
from __future__ import annotations
import argparse
import re
import tempfile
import zipfile
from pathlib import Path

MARKER = 'SURVEYQUANT_V132_CAD_ORIGINAL_VIEW_STRICT_PRESERVE'

def replace_once(s: str, old: str, new: str, label: str) -> str:
    n = s.count(old)
    if n != 1:
        raise SystemExit(f'ERROR {label}: expected one exact match, found {n}')
    return s.replace(old, new, 1)

def replace_function(s: str, start_token: str, end_token: str, new_body: str, label: str) -> str:
    start = s.find(start_token)
    if start < 0:
        raise SystemExit(f'ERROR {label}: start not found: {start_token}')
    end = s.find(end_token, start + len(start_token))
    if end < 0:
        raise SystemExit(f'ERROR {label}: boundary not found: {end_token}')
    return s[:start] + new_body.rstrip() + '\n' + s[end:]

def patch_html(s: str) -> str:
    if MARKER in s:
        raise SystemExit('V132 patch already applied')
    if 'SURVEYQUANT_V131_ENGINEERING_CAD_PRESERVE' not in s:
        raise SystemExit('V131 source marker missing; refusing to patch an unknown base')

    # Do not inject synthesized geometry from unsupported records into the visual preview.
    old_supplement = """    try { addUnrenderedEntities(model, working); } catch (e) {
      model.previewWarning = (model.previewWarning ? model.previewWarning + ' | ' : '') + 'بعض العناصر الخاصة لم تدخل المعاينة؛ بياناتها تبقى ضمن الملف المصدر: ' + String(e.message || e);
    }"""
    new_supplement = """    // V132: do not synthesize/expand extra geometry into the preview. The original CAD records remain authoritative and untouched; avoiding speculative expansion prevents duplicate or visually foreign entities.
    model.__sqV132NoSyntheticPreviewGeometry = true;"""
    s = replace_once(s, old_supplement, new_supplement, 'disable synthetic preview geometry')

    # Enlarge the orientation window and both drawing canvases on phones and tablets.
    s = replace_once(s, "'.sqori-dialog{max-width:920px;", "'.sqori-dialog{max-width:1120px;", 'wide orientation dialog')
    s = replace_once(s, "dialog.style.maxHeight='86dvh';dialog.style.overflowY='auto';dialog.style.width='min(96vw,760px)';dialog.style.boxSizing='border-box';", "dialog.style.maxHeight='94dvh';dialog.style.overflowY='auto';dialog.style.width='min(99vw,1120px)';dialog.style.boxSizing='border-box';", 'large orientation modal')
    old_canvas_style = 'height:230px;min-height:230px;max-height:230px;border:1px solid #42536b;border-radius:10px;touch-action:none;background:#0b1220;touch-action:none'
    new_canvas_style = 'height:58dvh;min-height:400px;max-height:640px;border:1px solid #42536b;border-radius:10px;touch-action:none;background:#0b1220;touch-action:none'
    if s.count(old_canvas_style) != 2:
        raise SystemExit(f'ERROR large CAD canvas: expected 2 canvases, found {s.count(old_canvas_style)}')
    s = s.replace(old_canvas_style, new_canvas_style)

    # CAD annotation size follows the board zoom linearly; never shrink it as zoom increases.
    s = replace_once(s,
        "const st=styleOf(v,t),fitTextSize=Math.min(10,Math.max(6,Math.abs(Number(t.height)||2.5)*m.base*0.8)),size=Math.max(1.15,fitTextSize/Math.sqrt(Math.max(1,Number(v.zoom)||1)));",
        "const st=styleOf(v,t),size=Math.max(0.5,Math.min(240,Math.abs(Number(t.height)||2.5)*m.scale));",
        'CAD text zoom follows board scale')
    s = replace_once(s,
        "c.fillText(String(t.text||'').slice(0,250),3,-3);",
        "String(t.text||'').replace(/\\\\P/gi,'\\n').replace(/\\\\X/gi,'\\n').split(/\\r?\\n/).forEach((line,i)=>c.fillText(line,3,-3+i*size*1.12));",
        'show complete CAD text')

    # Rework dropped-file projection: require the original/reference DXF bytes and prove its
    # entire original ENTITIES section is a byte-for-byte prefix of the result.
    helper = r'''function sqV132CadEntitySnapshot(bytes){
 if(!(bytes instanceof Uint8Array)||!bytes.length)throw new Error('لا توجد بايتات لوحة CAD المرجعية الأصلية.');
 const text=new TextDecoder('windows-1252').decode(bytes),pairs=sqDxfPairsWithOffsets(text),sec=sqFindDxfSection(pairs,'ENTITIES');
 if(!sec)throw new Error('اللوحة المرجعية لا تحتوي على قسم ENTITIES كامل.');
 const body=text.slice(sec.contentStart,sec.endSec.start),records=sectionRecords(pairs,'ENTITIES');
 if(!records.length)throw new Error('قسم ENTITIES المرجعي فارغ؛ أوقفت التصدير حتى لا تنتج لوحة نقاط فقط.');
 const types=Object.create(null),layers=Object.create(null),texts=[];
 for(const rec of records){types[rec.type]=(types[rec.type]||0)+1;for(const p of rec.pairs){if(p.code===8){const layer=String(p.value||'0');layers[layer]=(layers[layer]||0)+1;}if(p.code==='1'||p.code==='3')texts.push(rec.type+'\u0000'+String(p.value));}}
 return {text,body,records,entityCount:records.length,types,layers,texts};
}
function sqV132AssertReferencePreserved(beforeBytes,afterBytes){
 const before=sqV132CadEntitySnapshot(beforeBytes),after=sqV132CadEntitySnapshot(afterBytes);
 if(!after.body.startsWith(before.body))throw new Error('فشل فحص الحفاظ على اللوحة المرجعية: تغيّر محتوى ENTITIES الأصلي أو أُعيد ترتيبه. أوقفت تنزيل الملف.');
 if(after.entityCount<before.entityCount)throw new Error('فقد ملف الإسقاط بعض كيانات اللوحة المرجعية؛ أوقفت تنزيل الملف بدل إصدار لوحة ناقصة.');
 for(const [type,count] of Object.entries(before.types))if((after.types[type]||0)<count)throw new Error('فقد ملف الإسقاط كيانات مرجعية من النوع '+type+'؛ أوقفت التصدير.');
 for(const [layer,count] of Object.entries(before.layers))if((after.layers[layer]||0)<count)throw new Error('فقد ملف الإسقاط عناصر من Layer '+layer+'؛ أوقفت التصدير.');
 return {before,after};
}
async function dropFilesMerge(){
 const progress=document.getElementById('dropFilesProgress'),results=document.getElementById('dropFilesResults'),summary=document.getElementById('dropFilesSummary');
 try{
  droppedDXF='';if(results)results.style.display='none';
  const src=document.getElementById('dropSurveyFiles').files[0],cad=document.getElementById('dropCadFile').files[0];
  if(!src||!cad)return alert('اختر ملف الإسقاط في الخانة الأولى ولوحة DXF/DWG المرجعية في الخانة الثانية.');
  if(progress){progress.style.display='block';progress.textContent='⏳ جارٍ قراءة ملف النقاط...';}
  await new Promise(r=>setTimeout(r,20));const sourceModel=await parseFile(src);
  if(progress){progress.textContent='⏳ جارٍ قراءة اللوحة المرجعية كاملة...';await new Promise(r=>setTimeout(r,20));}
  const targetModel=await parseFile(cad);
  if(!targetModel||!['DXF','DWG'].includes(String(targetModel.source).toUpperCase()))throw new Error('الخانة الثانية يجب أن تكون لوحة DXF أو DWG.');
  let referenceBytes=targetModel.rawDXFBytes;
  if(!(referenceBytes instanceof Uint8Array)&&/\.dwg$/i.test(cad.name)&&typeof window.__sqOriAxisAutoTest?.convertTargetToDxf==='function'){
   const converted=await window.__sqOriAxisAutoTest.convertTargetToDxf(cad);referenceBytes=converted.bytes instanceof Uint8Array?converted.bytes:new Uint8Array(converted.bytes);targetModel.rawDXFBytes=referenceBytes.slice();
  }
  if(!(referenceBytes instanceof Uint8Array)||!referenceBytes.length)throw new Error('تعذر الحصول على ملف DXF المرجعي الكامل. أوقفت الإسقاط بدل إعادة رسم المرجع من النقاط المقروءة فقط.');
  const referenceBefore=sqV132CadEntitySnapshot(referenceBytes);
  const additions=[];let addedPoints=0,addedCad=0;
  if(Array.isArray(sourceModel.points)&&sourceModel.points.length){const ps=getPointStyleSettings();for(const p of sourceModel.points){addPointDetailEntities(additions,{e:Number(p.e),n:Number(p.n),z:Number(p.z||0),id:p.id||('P'+(addedPoints+1))},ps);addedPoints++;}}
  if(sourceModel.entities?.length){if(!sourceModel.points?.length||sourceModel.source==='DXF'||sourceModel.source==='DWG'){for(const e of sourceModel.entities){additions.push(e);addedCad++;}}}
  if(!additions.length)throw new Error('لم يتم استخراج نقاط أو عناصر جديدة من الملف الأول؛ لم يتغير ملف المرجع.');
  if(progress){progress.textContent='⏳ إضافة المسقط وفحص بقاء اللوحة المرجعية الأصلية...';await new Promise(r=>setTimeout(r,20));}
  droppedDXF=mergeProjectionDxfPreservingReference(referenceBytes,additions);
  const preserved=sqV132AssertReferencePreserved(referenceBytes,droppedDXF);
  const validationIssue=inspectPreservedReferenceDXF(new TextDecoder('windows-1252').decode(droppedDXF));if(validationIssue)throw new Error(validationIssue+' تم إيقاف التصدير لحماية اللوحة المرجعية.');
  if(summary)summary.innerHTML=`تم إسقاط <b>${escapeHtml(src.name)}</b> على <b>${escapeHtml(cad.name)}</b>.<br>كيانات المرجع قبل الإسقاط: <b>${preserved.before.entityCount}</b> | بعد الإسقاط: <b>${preserved.after.entityCount}</b> | النقاط المضافة: <b>${addedPoints}</b> | عناصر CAD مضافة: <b>${addedCad}</b>.<br><span class="muted">تم التحقق من بقاء محتوى ENTITIES المرجعي الأصلي وترتيبه حرفيًا قبل العناصر الجديدة، مع بقاء سجلات الطبقات والنصوص الأصلية. لم تتم إعادة رسم اللوحة المرجعية. DWG يُحوَّل إلى DXF أولًا، لذلك التحويل نفسه يظل محدودًا بما يستطيع LibreDWG فكّه من ملف DWG.</span><br>الإحداثيات ثابتة: X = Easting (E) وY = Northing (N)، دون تبديل.`;
  if(results)results.style.display='block';
 }catch(e){console.error('dropFilesMerge',e);droppedDXF='';if(results)results.style.display='none';alert('تعذر إسقاط الملف مع الحفاظ على اللوحة المرجعية: '+(e?.message||e));}
 finally{if(progress)progress.style.display='none';}
}'''
    s = replace_function(s, 'async function dropFilesMerge(){', 'function downloadDroppedDXF()', helper, 'strict source-preserving projection')

    # Ensure only one projection helper and never fall back to rebuilding the entire reference.
    s = s.replace('/* SURVEYQUANT_V131_ENGINEERING_CAD_PRESERVE */', '/* SURVEYQUANT_V131_ENGINEERING_CAD_PRESERVE */\n/* ' + MARKER + ' */')
    return s

def patch_apk(source: Path, output: Path):
    if not source.is_file():
        raise SystemExit(f'APK missing: {source}')
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix='sq-v132-', suffix='.apk', dir=output.parent, delete=False) as f:
        tmp = Path(f.name)
    changed = 0
    try:
        with zipfile.ZipFile(source, 'r') as zin, zipfile.ZipFile(tmp, 'w') as zout:
            for info in zin.infolist():
                if re.match(r'^META-INF/[^/]+\.(?:SF|RSA|DSA|EC|MF)$', info.filename, re.I):
                    continue
                data = zin.read(info.filename)
                if info.filename == 'assets/index.html':
                    data = patch_html(data.decode('utf-8')).encode('utf-8')
                    changed += 1
                zout.writestr(info, data)
        if changed != 1:
            raise SystemExit(f'Expected exactly one assets/index.html, found {changed}')
        tmp.replace(output)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise
    print(f'PATCHED APK HTML: {source} -> {output}; align and re-sign APK.')

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--html')
    p.add_argument('--apk')
    p.add_argument('--output')
    a = p.parse_args()
    if a.html:
        f=Path(a.html);f.write_text(patch_html(f.read_text(encoding='utf-8')),encoding='utf-8');print('V132 HTML patch applied:',f)
    elif a.apk and a.output:
        patch_apk(Path(a.apk), Path(a.output))
    else: p.error('use --html FILE or --apk INPUT --output OUTPUT')
if __name__=='__main__': main()
