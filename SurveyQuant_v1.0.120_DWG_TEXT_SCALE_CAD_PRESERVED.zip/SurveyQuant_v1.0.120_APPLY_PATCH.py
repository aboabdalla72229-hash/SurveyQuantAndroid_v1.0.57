#!/usr/bin/env python3
"""Fail-closed v1.0.120 CAD text scaling and global DWG file-picker patch."""
from pathlib import Path
import re
import sys

if len(sys.argv) != 4:
    raise SystemExit("usage: SurveyQuant_v1.0.120_APPLY_PATCH.py REFERENCE_MODULE.js INDEX_PATH.html DWG_BRIDGE.js")

module_path, index_path, bridge_path = map(Path, sys.argv[1:])
# The historical builder's preceding step already changes the original
# 5.5..15px formula to this intermediate V119 formula. Accept that exact
# intermediate state (or an already-patched V120 state for safe reruns).
intermediate_formula = "size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale);"
new_formula = "size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale*Math.max(0.001,Number(v.zoom)||1));"

updated = []
for path in (module_path, index_path):
    source = path.read_text(encoding="utf-8")
    intermediate_count = source.count(intermediate_formula)
    already_patched_count = source.count(new_formula)
    if intermediate_count == 1 and already_patched_count == 0:
        source = source.replace(intermediate_formula, new_formula, 1)
    elif intermediate_count == 0 and already_patched_count == 1:
        # Idempotent: don't fail when an earlier attempt applied the patch.
        pass
    else:
        raise SystemExit(
            f"ERROR: {path.name}: expected exactly one V119 text formula or one V120 formula; "
            f"found V119={intermediate_count}, V120={already_patched_count}."
        )
    if "function universalTransformBytes(input,t)" not in source:
        raise SystemExit(f"ERROR: {path.name}: byte-preserving CAD transform is missing; refusing to patch.")
    if intermediate_formula in source or source.count(new_formula) != 1:
        raise SystemExit(f"ERROR: {path.name}: proportional text-scale verification failed.")
    updated.append((path, source))

bridge = bridge_path.read_text(encoding="utf-8")
bad = r"\\.dwg"
good = r"\.dwg"
bad_count = bridge.count(bad)
if bad_count:
    if bad_count != 4:
        raise SystemExit(f"ERROR: expected four escaped DWG matchers, found {bad_count}; refusing blind replacement.")
    bridge = bridge.replace(bad, good)
elif bridge.count(good) != 4:
    raise SystemExit("ERROR: DWG matcher pattern is unexpected; neither four broken nor four corrected matchers found.")

anchor = "var MIME = 'application/dxf';"
if "SQ_DWG_ACCEPT_TYPES" not in bridge:
    if bridge.count(anchor) != 1:
        raise SystemExit("ERROR: DWG file-picker insertion anchor is not unique.")
    addition = r'''            var MIME = 'application/dxf';
            var SQ_DWG_ACCEPT_TYPES = ['.dwg','.dxf','application/dwg','application/x-dwg','application/dxf','application/x-dxf','application/acad','application/x-acad','image/vnd.dwg'];
            function sqExtendDwgInput(input) {
              if (!input || String(input.tagName || '').toLowerCase() !== 'input' || String(input.type || '').toLowerCase() !== 'file') return;
              var current = String(input.accept || '').split(',').map(function(x){return x.trim();}).filter(Boolean);
              SQ_DWG_ACCEPT_TYPES.forEach(function(item) {
                if (!current.some(function(x){return x.toLowerCase() === item.toLowerCase();})) current.push(item);
              });
              input.accept = current.join(',');
            }
            function sqScanDwgInputs(root) {
              if (root && root.nodeType === 1) sqExtendDwgInput(root);
              if (root && typeof root.querySelectorAll === 'function') root.querySelectorAll('input[type="file"]').forEach(sqExtendDwgInput);
            }
            sqScanDwgInputs(document);
            if (typeof MutationObserver === 'function' && document.documentElement) {
              new MutationObserver(function(records) {
                records.forEach(function(record) { (record.addedNodes || []).forEach(sqScanDwgInputs); });
              }).observe(document.documentElement, {childList:true,subtree:true});
            }'''
    bridge = bridge.replace(anchor, addition, 1)
if bridge.count(good) != 4 or "SQ_DWG_ACCEPT_TYPES" not in bridge or "MutationObserver" not in bridge:
    raise SystemExit("ERROR: final DWG bridge checks failed.")

html = updated[1][1]
pattern = re.compile(r'(<script id="sq-v120-universal-dwg-bridge">)[\s\S]*?(</script>)')
html, embedded_count = pattern.subn(lambda m: m.group(1) + "\n" + bridge + "\n" + m.group(2), html)
if embedded_count != 1:
    raise SystemExit(f"ERROR: expected exactly one embedded v120 bridge script, replaced {embedded_count}.")
if "sqOriConvertTargetToDxf" not in html or new_formula not in html:
    raise SystemExit("ERROR: v120 HTML integration verification failed.")

for token, content, label in [
    (new_formula, updated[0][1], "reference module text scale"),
    ("function universalTransformBytes(input,t)", updated[0][1], "reference CAD transform"),
    (new_formula, html, "index HTML text scale"),
    ("SQ_DWG_ACCEPT_TYPES", html, "global DWG file picker"),
    ("MutationObserver", html, "dynamic file inputs"),
]:
    if token not in content:
        raise SystemExit(f"ERROR: final {label} verification failed.")

# Writes happen only after all anchors and resulting content have passed checks.
module_path.write_text(updated[0][1], encoding="utf-8")
index_path.write_text(html, encoding="utf-8")
bridge_path.write_text(bridge, encoding="utf-8")
print("PASS: text size follows CAD height × board fit scale × board zoom.")
print("PASS: DWG/DXF accepted by current and dynamically created file pickers.")
print("PASS: the original byte-preserving CAD transform is still present.")
