#!/usr/bin/env python3
"""Restore the exact V127 orientation script modules into the current V136 base.

Only the orientation module bodies are copied from V127. The current V136 universal
DWG bridge, packaged WASM runtime, and unrelated project modules are retained. A small
fresh-board-session guard clears transient drawing storage and reloads the WebView on
return from the Android background, while preserving device/payment/settings keys.
"""
from __future__ import annotations
import argparse
import hashlib
import re
import struct
import copy
import zipfile
from pathlib import Path

ORIENTATION_SCRIPT_IDS = (
    "sq-orientation-module",
    "sq-orientation-axis-reader-module",
    "sq-orientation-manual-points-module",
    "sq-orientation-reference-board-module",
    "sq-orientation-dxf-faithful-recovery-module",
    "sq-orientation-cad-preserve-module",
    "sq-orientation-v115-tools-module",
)
VERSION_OLD = 136
VERSION_NEW = 140
VERSION_OLD_NAME = "1.0.136"
VERSION_NEW_NAME = "1.0.140"
WASM_PROMISE_OLD = b"return new Promise((reject,resolve)=>{var xhr=new XMLHttpRequest;"
WASM_PROMISE_FIXED = b"return new Promise((resolve,reject)=>{var xhr=new XMLHttpRequest;"

FRESH_SESSION_SCRIPT = r'''<script id="surveyquant-v140-fresh-board-session">
(function(){
  "use strict";
  var hiddenSince = 0;
  var filePickerPending = false;
  var filePickerStartedAt = 0;
  var filePickerResumeExempt = false;
  var reloadQueued = false;

  function clearBoardStorage(){
    var boardKey = /(?:drawing|cad|dxf|dwg|board|orient(?:ation)?|projection|overlay|last[_ .-]?(?:file|board|drawing|project)|recent[_ .-]?(?:file|board|drawing)|imported[_ .-]?file|file[_ .-]?data|canvas[_ .-]?state|entities|geometry)/i;
    try {
      if (window.localStorage) {
        var localKeys = [];
        for (var i = 0; i < window.localStorage.length; i++) {
          var key = window.localStorage.key(i);
          if (key && boardKey.test(key)) localKeys.push(key);
        }
        localKeys.forEach(function(key){ try { window.localStorage.removeItem(key); } catch (_) {} });
      }
    } catch (_) {}
    try { if (window.sessionStorage) window.sessionStorage.clear(); } catch (_) {}
    // SurveyQuant does not need IndexedDB for settings or the payment/device identity.
    // Delete origin databases to prevent a prior CAD drawing cache from surviving.
    try {
      if (window.indexedDB && typeof window.indexedDB.databases === "function") {
        window.indexedDB.databases().then(function(list){
          (list || []).forEach(function(db){
            if (db && db.name) { try { window.indexedDB.deleteDatabase(db.name); } catch (_) {} }
          });
        }).catch(function(){});
      }
    } catch (_) {}
  }
  function isFileInput(node){
    try { return !!(node && (node.matches ? node.matches('input[type="file"]') : String(node.type||'').toLowerCase()==='file')); }
    catch (_) { return false; }
  }
  function fileInputFromEvent(event){
    var node = event && event.target;
    if (isFileInput(node)) return node;
    try { return node && node.closest ? node.closest('input[type="file"]') : null; }
    catch (_) { return null; }
  }
  function clearFilePicker(){ filePickerPending = false; filePickerStartedAt = 0; filePickerResumeExempt = false; }
  function markFilePickerFinished(){ filePickerPending = false; }

  // Initial document load always starts without any persisted CAD drawing/session data.
  clearBoardStorage();
  window.addEventListener("pagehide", clearBoardStorage, {once:true});
  window.addEventListener("beforeunload", clearBoardStorage, {once:true});

  // Android's native chooser briefly hides the WebView. Do not reload while it returns,
  // otherwise the just-selected File object would be discarded before the change handler.
  document.addEventListener("click", function(event){
    var input = fileInputFromEvent(event);
    if (input) { filePickerPending = true; filePickerStartedAt = Date.now(); }
  }, true);
  document.addEventListener("change", function(event){ if (fileInputFromEvent(event)) markFilePickerFinished(); }, true);
  document.addEventListener("cancel", function(event){ if (fileInputFromEvent(event)) markFilePickerFinished(); }, true);
  window.addEventListener("focus", function(){
    if (filePickerPending && Date.now() - filePickerStartedAt > 180000) clearFilePicker();
  });
  function resetOnReturn(awayMs){
    clearBoardStorage();
    if (awayMs < 500) return;
    var pickerAge = filePickerStartedAt ? Date.now() - filePickerStartedAt : Infinity;
    // change/cancel can fire before the visible/focus event; use the recorded picker cycle,
    // not just the current filePickerPending flag, so the selected File is not lost by reload.
    if (pickerAge < 180000 && (filePickerResumeExempt || filePickerPending)) { clearFilePicker(); return; }
    clearFilePicker();
    if (reloadQueued) return;
    reloadQueued = true;
    // Recreate the drawing WebView so no in-memory source/target board survives re-entry.
    try { window.location.reload(); } catch (_) { reloadQueued = false; }
  }
  document.addEventListener("visibilitychange", function(){
    if (document.visibilityState === "hidden") {
      if (filePickerPending) filePickerResumeExempt = true;
      hiddenSince = Date.now();
      clearBoardStorage();
      return;
    }
    if (!hiddenSince) return;
    var awayMs = Date.now() - hiddenSince;
    hiddenSince = 0;
    resetOnReturn(awayMs);
  });
  // Some WebView/Android combinations do not deliver visibilitychange on Activity pause.
  // A file chooser's blur/focus is tracked separately and never causes a reload.
  window.addEventListener("blur", function(){
    if (filePickerPending) { filePickerResumeExempt = true; return; }
    hiddenSince = Date.now();
  });
  window.addEventListener("focus", function(){
    if (hiddenSince && document.visibilityState !== "hidden") {
      var awayMs = Date.now() - hiddenSince;
      hiddenSince = 0;
      resetOnReturn(awayMs);
      return;
    }
    if (filePickerResumeExempt && document.visibilityState !== "hidden") {
      resetOnReturn(filePickerStartedAt ? Date.now() - filePickerStartedAt : 1000);
      return;
    }
    if (filePickerPending && Date.now() - filePickerStartedAt > 180000) clearFilePicker();
  });
})();
</script>'''


def script_pattern(script_id: str) -> re.Pattern[str]:
    return re.compile(
        r'(<script\b(?=[^>]*\bid=["\']' + re.escape(script_id) + r'["\'])[^>]*>)([\s\S]*?)(</script\s*>)',
        re.IGNORECASE,
    )


def get_script(html: str, script_id: str) -> str:
    hits = list(script_pattern(script_id).finditer(html))
    if len(hits) != 1:
        raise ValueError(f"Expected exactly one script id={script_id!r}, found {len(hits)}")
    return hits[0].group(2)


def replace_script(html: str, script_id: str, body: str) -> str:
    pat = script_pattern(script_id)
    hits = list(pat.finditer(html))
    if len(hits) != 1:
        raise ValueError(f"Expected exactly one script id={script_id!r}, found {len(hits)}")
    m = hits[0]
    return html[:m.start(2)] + body + html[m.end(2):]


def apply(source_html: str, reference_html: str) -> tuple[str, dict[str, str]]:
    result = source_html
    reference_hashes: dict[str, str] = {}
    # Copy the complete embedded orientation modules without editing their contents.
    for script_id in ORIENTATION_SCRIPT_IDS:
        reference_body = get_script(reference_html, script_id)
        source_body = get_script(result, script_id)
        result = replace_script(result, script_id, reference_body)
        # byte-for-byte source equality is verified after insertion below
        reference_hashes[script_id] = hashlib.sha256(reference_body.encode("utf-8")).hexdigest()
        if get_script(result, script_id) != source_body and source_body == reference_body:
            raise AssertionError(f"Unexpected change while copying {script_id}")

    # Replace the over-broad V134 reset (it cleared app preferences/payment/device ID too)
    # with a board-only store purge plus a WebView refresh on Android background re-entry.
    old_ids = ["surveyquant-v134-session-reset", "surveyquant-v140-fresh-board-session"]
    existing = []
    for sid in old_ids:
        existing.extend(list(script_pattern(sid).finditer(result)))
    if len(existing) != 1:
        raise ValueError(f"Expected one existing session reset script, found {len(existing)}")
    m = existing[0]
    result = result[:m.start()] + FRESH_SESSION_SCRIPT + result[m.end():]

    old_version = f"const SQ_APP_VERSION_CODE = {VERSION_OLD};"
    new_version = f"const SQ_APP_VERSION_CODE = {VERSION_NEW};"
    if result.count(old_version) != 1:
        raise ValueError(f"Expected exactly one app version constant {VERSION_OLD}, found {result.count(old_version)}")
    result = result.replace(old_version, new_version, 1)

    # Verify exact byte-for-byte restoration and that general DWG support did not change.
    for script_id in ORIENTATION_SCRIPT_IDS:
        if get_script(result, script_id) != get_script(reference_html, script_id):
            raise AssertionError(f"Orientation module {script_id} is not identical to V127")
    if 'id="sq-v117-universal-dwg-bridge"' not in result:
        raise ValueError("Current universal DWG picker bridge is missing")
    if "function sqDwgWasmRuntimePath()" not in result:
        raise ValueError("Current WASM runtime path helper is missing")
    if "const SQ_APP_VERSION_CODE = 140;" not in result:
        raise ValueError("App version code was not updated to 140")
    if 'id="surveyquant-v140-fresh-board-session"' not in result:
        raise ValueError("Fresh-board session guard is missing")
    return result, reference_hashes


def _read_len8(data: bytes, pos: int) -> tuple[int, int]:
    first = data[pos]
    if first & 0x80:
        return (((first & 0x7F) << 8) | data[pos + 1]), pos + 2
    return first, pos + 1


def _read_len16(data: bytes, pos: int) -> tuple[int, int]:
    first = struct.unpack_from("<H", data, pos)[0]
    if first & 0x8000:
        second = struct.unpack_from("<H", data, pos + 2)[0]
        return (((first & 0x7FFF) << 16) | second), pos + 4
    return first, pos + 2


def _string_pool(data: bytes, chunk_start: int, chunk_size: int, header_size: int) -> tuple[list[str], list[tuple[int, int, bool]]]:
    if header_size < 28 or chunk_start + chunk_size > len(data):
        raise ValueError("invalid Android binary XML string pool")
    string_count, _style_count, flags, strings_start, _styles_start = struct.unpack_from("<IIIII", data, chunk_start + 8)
    if string_count > 100_000:
        raise ValueError("unreasonable Android XML string count")
    offsets_start = chunk_start + header_size
    strings_base = chunk_start + strings_start
    utf8 = bool(flags & 0x100)
    strings: list[str] = []
    spans: list[tuple[int, int, bool]] = []
    for index in range(string_count):
        rel = struct.unpack_from("<I", data, offsets_start + index * 4)[0]
        p = strings_base + rel
        if utf8:
            _char_len, p = _read_len8(data, p)
            byte_len, p = _read_len8(data, p)
            begin, end = p, p + byte_len
            strings.append(data[begin:end].decode("utf-8", errors="strict"))
            spans.append((begin, end, True))
        else:
            char_len, p = _read_len16(data, p)
            begin, end = p, p + char_len * 2
            strings.append(data[begin:end].decode("utf-16le", errors="strict"))
            spans.append((begin, end, False))
    return strings, spans


def patch_binary_manifest(manifest: bytes) -> bytes:
    if len(manifest) < 8 or struct.unpack_from("<H", manifest, 0)[0] != 0x0003:
        raise ValueError("AndroidManifest.xml is not Android binary XML")
    result = bytearray(manifest)
    pos = struct.unpack_from("<H", result, 2)[0]
    total_size = struct.unpack_from("<I", result, 4)[0]
    if total_size > len(result) or total_size < pos:
        raise ValueError("invalid Android binary XML size")
    strings = None
    spans = []
    chunks = []
    while pos < total_size:
        if pos + 8 > total_size: raise ValueError("truncated Android XML chunk header")
        chunk_type, header_size, chunk_size = struct.unpack_from("<HHI", result, pos)
        if chunk_size < header_size or pos + chunk_size > total_size: raise ValueError("invalid Android XML chunk bounds")
        chunks.append((pos, chunk_type, header_size, chunk_size))
        if chunk_type == 0x0001:
            strings, spans = _string_pool(bytes(result), pos, chunk_size, header_size)
        pos += chunk_size
    if strings is None: raise ValueError("Android XML string pool not found")
    old_ids = [i for i, v in enumerate(strings) if v == VERSION_OLD_NAME]
    if not old_ids and VERSION_NEW_NAME not in strings:
        raise ValueError(f"manifest does not contain {VERSION_OLD_NAME!r} or {VERSION_NEW_NAME!r}")
    for idx in old_ids:
        begin, end, is_utf8 = spans[idx]
        encoded = VERSION_NEW_NAME.encode("utf-8" if is_utf8 else "utf-16le")
        if len(encoded) != end - begin: raise ValueError("versionName replacement changes Android string-pool byte length")
        result[begin:end] = encoded
        strings[idx] = VERSION_NEW_NAME
    fields=[]
    for chunk_pos, chunk_type, _header_size, chunk_size in chunks:
        if chunk_type != 0x0102 or chunk_size < 36: continue
        node_name_idx = struct.unpack_from("<I", result, chunk_pos + 20)[0]
        if node_name_idx >= len(strings) or strings[node_name_idx] != "manifest": continue
        attr_start = struct.unpack_from("<H", result, chunk_pos + 24)[0]
        attr_size = struct.unpack_from("<H", result, chunk_pos + 26)[0]
        attr_count = struct.unpack_from("<H", result, chunk_pos + 28)[0]
        if attr_size < 20 or attr_count > 1024: raise ValueError("invalid Android manifest attribute table")
        first_attr = chunk_pos + 16 + attr_start
        for n in range(attr_count):
            at = first_attr + n * attr_size
            name_idx = struct.unpack_from("<I", result, at + 4)[0]
            if name_idx < len(strings) and strings[name_idx] == "versionCode":
                value_size = struct.unpack_from("<H", result, at + 12)[0]
                value_type = result[at + 15]
                if value_size < 8 or value_type not in (0x10, 0x11): raise ValueError("manifest versionCode is not typed integer")
                fields.append(at + 16)
    if len(fields) != 1: raise ValueError(f"expected exactly one Android versionCode field, found {len(fields)}")
    struct.pack_into("<I", result, fields[0], VERSION_NEW)
    return bytes(result)


def package_apk(input_apk: Path, output_apk: Path, patched_html: Path) -> None:
    if not input_apk.is_file() or input_apk.stat().st_size == 0: raise ValueError("base APK missing or empty")
    if not patched_html.is_file(): raise ValueError("patched index.html missing")
    html_bytes = patched_html.read_bytes()
    # Fail closed before replacing the APK asset.
    html = html_bytes.decode("utf-8")
    if 'const SQ_APP_VERSION_CODE = 140;' not in html or 'id="surveyquant-v140-fresh-board-session"' not in html:
        raise ValueError("patched HTML does not carry V140 identity/session guard")
    output_apk.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(input_apk, "r") as zin:
        names = [x.filename for x in zin.infolist()]
        if names.count("assets/index.html") != 1 or names.count("AndroidManifest.xml") != 1:
            raise ValueError("base APK does not have unique index.html and AndroidManifest.xml")
        seen = set()
        with zipfile.ZipFile(output_apk, "w", allowZip64=True) as zout:
            for info in zin.infolist():
                name = info.filename
                if name in seen: raise ValueError("duplicate entry in base APK: " + name)
                seen.add(name)
                upper = name.upper()
                if upper.startswith("META-INF/") and (upper.endswith(".SF") or upper.endswith(".RSA") or upper.endswith(".DSA") or upper.endswith(".EC") or upper.endswith("MANIFEST.MF")):
                    continue
                data = zin.read(name)
                if name == "assets/index.html":
                    data = html_bytes
                elif name == "AndroidManifest.xml":
                    data = patch_binary_manifest(data)
                elif name == "assets/libredwg-writer/wasm/libredwg-web.js":
                    # The V136 base already carries the corrected WASM promise order; repair only if stale.
                    if WASM_PROMISE_OLD in data: data = data.replace(WASM_PROMISE_OLD, WASM_PROMISE_FIXED)
                zout.writestr(copy.copy(info), data)
    with zipfile.ZipFile(output_apk, "r") as check:
        if check.read("assets/index.html") != html_bytes: raise ValueError("APK HTML asset differs from the tested restored index.html")
        names = check.namelist()
        if "assets/libredwg-writer/wasm/libredwg-web.wasm" not in names: raise ValueError("APK lost local DWG WebAssembly engine")
        manifest = check.read("AndroidManifest.xml")
        checked = patch_binary_manifest(manifest)
        if checked != manifest: raise ValueError("APK manifest was not updated to V140")
        js = check.read("assets/libredwg-writer/wasm/libredwg-web.js")
        if WASM_PROMISE_OLD in js: raise ValueError("APK retains broken file:// WASM Promise order")
    print("PASS: APK was repacked with the exact tested index.html, versionName 1.0.140, versionCode 140, and current DWG runtime.")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-html", type=Path)
    ap.add_argument("--reference-html", type=Path)
    ap.add_argument("--output-html", type=Path)
    ap.add_argument("--report", type=Path)
    ap.add_argument("--apk-input", type=Path)
    ap.add_argument("--apk-output", type=Path)
    ap.add_argument("--html-to-inject", type=Path)
    args = ap.parse_args()
    if args.source_html and args.reference_html and args.output_html and not args.apk_input:
        source = args.source_html.read_text(encoding="utf-8")
        reference = args.reference_html.read_text(encoding="utf-8")
        patched, hashes = apply(source, reference)
        args.output_html.parent.mkdir(parents=True, exist_ok=True)
        args.output_html.write_text(patched, encoding="utf-8", newline="")
        if args.report:
            lines = ["# SurveyQuant V140 restoration report", "", "Restored embedded orientation modules byte-for-byte from V127.", ""]
            lines += [f"- `{sid}` SHA-256: `{digest}`" for sid, digest in hashes.items()]
            lines += ["", "The V136 universal DWG picker bridge and WASM path helper were retained.",
                      "Board-only storage is cleared on startup and pagehide; returning to the app reloads the WebView unless returning from Android's file chooser.",
                      "Local app preferences and device/payment identity keys are preserved."]
            args.report.write_text("\n".join(lines)+"\n", encoding="utf-8")
        print(f"PASS: transplanted {len(hashes)} exact V127 orientation modules; target app version code {VERSION_NEW}.")
        for sid, digest in hashes.items(): print(f"PASS: {sid} {digest}")
        return
    if args.apk_input and args.apk_output and args.html_to_inject:
        package_apk(args.apk_input, args.apk_output, args.html_to_inject)
        return
    ap.error("use --source-html CURRENT --reference-html V127 --output-html OUTPUT, or --apk-input APK --apk-output APK --html-to-inject HTML")

if __name__ == "__main__":
    main()
