#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
import ezdxf
from PIL import Image

def inspect(dxf_path:Path,jpg_path:Path):
    raw=dxf_path.read_bytes(); doc=ezdxf.readfile(dxf_path); audit=doc.audit()
    if audit.errors: raise SystemExit('DXF audit errors: '+str(len(audit.errors)))
    if audit.fixes: raise SystemExit('DXF audit fixes: '+str(len(audit.fixes)))
    model=list(doc.modelspace())
    if len(model)!=1 or model[0].dxftype()!='IMAGE': raise SystemExit('Expected one standard IMAGE entity, found '+repr([e.dxftype() for e in model]))
    image=model[0]; idef=doc.entitydb.get(image.dxf.image_def_handle)
    if not idef or idef.dxftype()!='IMAGEDEF': raise SystemExit('IMAGE entity is missing IMAGEDEF handle reference')
    stored=idef.dxf.get('filename','')
    # DXF writers may serialize the same relative sidecar path with Windows\\ or POSIX separators.
    # Accept only a same-directory relative filename; keep rejecting absolute paths and subdirectories.
    normalized=stored.replace('\\','/').strip()
    while normalized.startswith('./'):
        normalized=normalized[2:]
    if normalized != jpg_path.name or '/' in normalized or normalized in ('', '.', '..'):
        raise SystemExit(f'IMAGEDEF path mismatch: {stored!r} (expected same-directory {jpg_path.name!r})')
    if not jpg_path.is_file(): raise SystemExit('IMAGE sidecar file missing beside DXF')
    with Image.open(jpg_path) as im:
        im.verify()
    with Image.open(jpg_path) as im:
        if list(im.size)!=[int(idef.dxf.image_size.x),int(idef.dxf.image_size.y)]: raise SystemExit('JPEG dimensions do not match IMAGEDEF pixel dimensions')
        width,height=im.size
    if image.dxf.image_def_handle!=idef.dxf.handle: raise SystemExit('IMAGE->IMAGEDEF handle mismatch')
    reactor=doc.entitydb.get(image.dxf.image_def_reactor_handle)
    if not reactor or reactor.dxftype()!='IMAGEDEF_REACTOR' or reactor.dxf.image_handle!=image.dxf.handle: raise SystemExit('IMAGEDEF_REACTOR link mismatch')
    if 'OLE2FRAME' in raw.decode('latin1','ignore'): raise SystemExit('Old OLE2FRAME object remains in PDF output')
    if not raw.endswith(b'EOF\r\n'): raise SystemExit('DXF EOF terminator missing')
    bb=image.dxf.insert; u=image.dxf.u_pixel; v=image.dxf.v_pixel
    extents=[float(bb.x),float(bb.y),float(bb.x+u.x*width+v.x*height),float(bb.y+u.y*width+v.y*height)]
    return {'status':'PASS','dxf_bytes':len(raw),'modelspace_entities':['IMAGE'],'image_def':idef.dxf.handle,'image_path':stored,'sidecar':jpg_path.name,'pixel_size':[width,height],'drawing_extents':extents,'ezdxf_audit_errors':0,'ezdxf_audit_fixes':0,'external_image_pair_verified':True,'ole_frames':0}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('dxf',type=Path);ap.add_argument('jpg',type=Path);ap.add_argument('--report',type=Path);a=ap.parse_args()
    result=inspect(a.dxf,a.jpg);out=json.dumps(result,ensure_ascii=False,indent=2);print(out)
    if a.report:a.report.write_text(out+'\n',encoding='utf-8')
