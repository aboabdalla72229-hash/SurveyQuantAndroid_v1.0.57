# رفع V181 إلى GitHub من الهاتف

المستودع: `aboabdalla72229-hash/SurveyQuantAndroid_v1.0.57`

1. ارفع `SurveyQuant_v1.0.181_FIX_KIT.zip` في جذر المستودع (Root) واعمل Commit.
2. ارفع ملف الـWorkflow الموجود داخل الحزمة إلى المسار الدقيق `.github/workflows/build-v181-local-frame-ole-pdf-dual-cad.yml` واعمل Commit.
3. بعد ظهور الـWorkflow، افتح Actions وتحقق من تشغيل `Build SurveyQuant v1.0.181 Local Frame + OLE PDF + Dual CAD`.
4. لا تثبّت ملف APK غير موقّع. ملف APK النهائي الموقّع سيظهر كـArtifact فقط بعد نجاح كل الاختبارات والتوقيع.

الـWorkflow يستخدم V180 signed APK من run `41400628957`، ويحتاج أسرار التوقيع الأربعة الموجودة في إعدادات Actions.
