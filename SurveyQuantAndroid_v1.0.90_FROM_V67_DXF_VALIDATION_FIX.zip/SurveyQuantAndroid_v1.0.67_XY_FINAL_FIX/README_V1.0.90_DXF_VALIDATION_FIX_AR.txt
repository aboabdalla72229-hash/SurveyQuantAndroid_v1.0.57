SurveyQuant v1.0.90 - DXF validation hotfix

Source baseline: v67-based code and assets retained from v1.0.89.
Scope: only make the preserved-DXF validation structural and tolerant of BOM/padded group codes / original drawing text values. The original drawing is still kept as raw bytes and additions remain appended by the existing merge function.
No project logic, settings UI, logo, background, or TIN scope changed from v1.0.89.

Important: APK is not claimed as built here. Upload the source ZIP and the separate workflow file to the repository, then run GitHub Actions.
