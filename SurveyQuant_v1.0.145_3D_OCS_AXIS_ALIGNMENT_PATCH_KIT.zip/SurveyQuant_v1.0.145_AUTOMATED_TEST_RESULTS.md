# SurveyQuant V1.0.145 automated test results

Run date: 2026-10-24

PASS - Python syntax: V145 patcher and APK packager compile.
PASS - V130 orientation precision regression compared with the V130 source; exact 2-point mapping, scale/rotation, entity count, layers and XData retained.
PASS - Ordinary non-default OCS circle transforms and its extrusion normal rotates; OCS no longer triggers the generic refusal.
PASS - Opaque ACAD_PROXY_ENTITY is intentionally rejected before any partial DXF output.
PASS - V130 shared DWG path, DXF output integrity, original bytes, INSERT text, selection/deletion/history tests.
PASS - Model/Paper space alignment preflight and exact-fit/far-offset safety tests.
PASS - MLEADER/MULTILEADER MText and block content: leader nodes/break points, vectors, dimensions, rotations, scale, matrix, layers and entity counts.
PASS - 3D WCS LINE endpoints, zero-Z plane anchored, tilted OCS CIRCLE/TEXT WCS round-trip, LWPOLYLINE elevation, axis names in nested INSERT and top-level TEXT.
PASS - Real DXF MULTILEADER output compared with ezdxf 1.4.4 transform oracle (text and block content, placement, scale, rotation, vectors, leader lines, matrix, layer and XData).
PASS - All 10 inline JavaScript blocks parse with Node.js.
PASS - The old UI message saying non-default OCS blocks export is absent; updated 3D/OCS supported message is present.
PASS - Injected tested HTML into an actual V144 APK copy; package layout and local DWG WASM retained; Android manifest changed to versionName 1.0.145 / versionCode 145.

Not run here: GitHub Actions signing/build in the user's repository and field validation against the original full DWG/DXF source. The local APK packaging test is unsigned; the workflow signs it using the repository's existing keystore secrets.
