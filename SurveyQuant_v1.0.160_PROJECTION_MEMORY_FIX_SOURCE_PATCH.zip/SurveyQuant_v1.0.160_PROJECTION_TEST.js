const fs=require('fs'),vm=require('vm');
const html=fs.readFileSync(process.argv[2]||'index.html','utf8');
const preserveOnlyMarkers=[
 "targetModel=await parseFile(cad,{preserveOnly:true,keepRawDwgBytes:false,keepRawDxfBytes:true,keepRawText:false,lightweight:true});",
 "preserveOnly:options.preserveOnly===true",
 "if(options.preserveOnly===true)",
 "if(ext==='dxf'&&options.preserveOnly===true)return"
];
const missingPreserveMarkers=preserveOnlyMarkers.filter(x=>!html.includes(x));
if(missingPreserveMarkers.length)throw new Error('preserve-only reference load optimization is missing: '+missingPreserveMarkers.join(' | '));
const start=html.indexOf('function inspectPreservedReferenceDXF(content){');
const end=html.indexOf('async function downloadQuantDXF(){',start);
if(start<0||end<0)throw new Error('test snippet markers missing');
const context={
  TextDecoder,TextEncoder,Uint8Array,Set,Map,BigInt,Number,String,Math,RegExp,Error,
  safeNum(v){const n=Number(v);return Number.isFinite(n)?String(n):'0';},
  asciiLayerName(s){return String(s||'0').replace(/[^\x20-\x7E]/g,'_');},
  asciiText(s){return String(s||'').replace(/[^\x20-\x7E]/g,'?');},
  entityToR12(e){if(e.type==='LINE'&&e.a&&e.b)return `0\nLINE\n8\n${e.layer||'0'}\n10\n${e.a.x}\n20\n${e.a.y}\n11\n${e.b.x}\n21\n${e.b.y}\n`;return '';},
  console
};
vm.createContext(context);vm.runInContext(html.slice(start,end),context);
function utf8(s){return new TextEncoder().encode(s)}
function text(bytes){return new TextDecoder('windows-1252').decode(bytes)}
const modern=`0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1027\n9\n$HANDSEED\n5\n100\n0\nENDSEC\n0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLAYER\n5\n2\n100\nAcDbSymbolTable\n70\n1\n0\nLAYER\n5\n3\n330\n2\n100\nAcDbSymbolTableRecord\n100\nAcDbLayerTableRecord\n2\nBASE\n70\n0\n62\n7\n6\nCONTINUOUS\n0\nENDTAB\n0\nTABLE\n2\nBLOCK_RECORD\n5\n4\n70\n2\n0\nBLOCK_RECORD\n5\n5\n330\n4\n100\nAcDbSymbolTableRecord\n100\nAcDbBlockTableRecord\n2\n*Model_Space\n70\n0\n0\nBLOCK_RECORD\n5\n7\n330\n4\n100\nAcDbSymbolTableRecord\n100\nAcDbBlockTableRecord\n2\n*Paper_Space\n70\n0\n0\nENDTAB\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n0\nLINE\n5\n20\n330\n6\n100\nAcDbEntity\n8\nBASE\n100\nAcDbLine\n10\n0\n20\n0\n30\n0\n11\n10\n21\n10\n31\n0\n0\nENDSEC\n0\nEOF\n`;
let scan=context.sqScanDxfProjectionText(modern,true);
if(!scan.entityEndSec||!scan.layerTable||!scan.layerTable.endTab||scan.version!=='AC1027'||scan.modelSpaceHandle!=='5'||!scan.layerTable.names.has('BASE'))throw new Error('modern scan did not find required offsets/handles '+JSON.stringify({version:scan.version,owner:scan.modelSpaceHandle,layer:!!scan.layerTable,entities:!!scan.entityEndSec}));
const original=utf8(modern);
const additions=[{type:'POINT',layer:'SURVEY_POINTS',position:{x:11.25,y:22.5,z:3}}];
const out=context.mergeProjectionDxfPreservingReference(original,additions);const outText=text(out);
if(out.length<=original.length)throw new Error('modern output did not append bytes');
if(!outText.includes('2\nSURVEY_POINTS\n')||!outText.includes('0\nPOINT\n')||!outText.includes('10\n11.25\n20\n22.5\n30\n3\n')||!outText.includes('330\n5\n100\nAcDbEntity'))throw new Error('modern output lacks point/layer records');
if(context.inspectPreservedReferenceDXF(out)!=='')throw new Error('modern output failed streaming DXF validation: '+context.inspectPreservedReferenceDXF(out));
if(!outText.includes('0\nLINE\n5\n20\n330\n6\n100\nAcDbEntity\n8\nBASE'))throw new Error('original reference entity not preserved');
const legacy=`0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1009\n0\nENDSEC\n0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLAYER\n70\n1\n0\nLAYER\n2\nBASE\n70\n0\n62\n7\n6\nCONTINUOUS\n0\nENDTAB\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n0\nLINE\n8\nBASE\n10\n0\n20\n0\n11\n1\n21\n1\n0\nENDSEC\n0\nEOF\n`;
const old=utf8(legacy);const oldOut=context.mergeProjectionDxfPreservingReference(old,[{type:'LINE',layer:'NEW_LAYER',a:{x:1,y:2,z:0},b:{x:3,y:4,z:0}}]);
if(!text(oldOut).includes('2\nNEW_LAYER\n')||!text(oldOut).includes('0\nLINE\n8\nNEW_LAYER'))throw new Error('legacy output missing inserted layer/line');
if(context.inspectPreservedReferenceDXF(oldOut)!=='')throw new Error('legacy output failed streaming DXF validation: '+context.inspectPreservedReferenceDXF(oldOut));
const source=utf8('ABCDE');const patch=context.sqApplyByteEdits(source,[{start:1,end:2,insertBytes:utf8('XY')},{start:4,end:4,insertBytes:utf8('!')}]);if(text(patch)!=='AXYCD!E')throw new Error('single-allocation byte patch test failed: '+text(patch));
// Simulate a large text drawing to ensure the scanner walks lines without constructing line/pair arrays.
const entityChunk=Array.from({length:60000},(_,i)=>`0\nLINE\n5\n${(200+i).toString(16)}\n8\nBASE\n10\n${i}\n20\n0\n11\n${i+1}\n21\n1\n`).join('');const large=modern.replace(/0\nENDSEC\n0\nEOF\n$/,'')+entityChunk+'0\nENDSEC\n0\nEOF\n';const t0=Date.now();const ls=context.sqScanDxfProjectionText(large,false);if(!ls.entityEndSec||!ls.hasEOF)throw new Error('large-scanner fixture failed');
const crlfOriginal=utf8(modern.replace(/\n/g,'\r\n')),crlfOut=context.mergeProjectionDxfPreservingReference(crlfOriginal,additions);if(context.inspectPreservedReferenceDXF(crlfOut)!=='')throw new Error('CRLF output failed validation');
console.log(JSON.stringify({syntax:'pass',preserveOnlyReferenceLoad:'pass',modernMerge:'pass',legacyMerge:'pass',byteEdit:'pass',streamingScanner:'pass',crlfMerge:'pass',largeFixtureBytes:large.length,largeScanMs:Date.now()-t0,modernOutputBytes:out.length,legacyOutputBytes:oldOut.length}));
