#!/usr/bin/env python3
"""V143: prevent partial CAD transforms, use consistent model/paper space and add real alignment overlay preview."""
from __future__ import annotations
import argparse, hashlib, re
from pathlib import Path

MANUAL_ID = 'sq-orientation-manual-points-module'
BOARD_ID = 'sq-orientation-reference-board-module'

def pattern(sid: str):
    return re.compile(r'(<script\b(?=[^>]*\bid=["\']'+re.escape(sid)+r'["\'])[^>]*>)([\s\S]*?)(</script\s*>)', re.I)

def get_body(html: str, sid: str) -> str:
    hits=list(pattern(sid).finditer(html))
    if len(hits)!=1: raise ValueError(f'Expected exactly one script {sid}, got {len(hits)}')
    return hits[0].group(2)

def put_body(html: str, sid: str, body: str) -> str:
    hits=list(pattern(sid).finditer(html))
    if len(hits)!=1: raise ValueError(f'Expected exactly one script {sid}, got {len(hits)}')
    m=hits[0]
    return html[:m.start(2)]+body+html[m.end(2):]

def replace_once(src: str, old: str, new: str, label: str) -> str:
    n=src.count(old)
    if n!=1: raise ValueError(f'{label}: expected one exact anchor, found {n}')
    return src.replace(old,new,1)

def patch_manual(body: str) -> str:
    old=' expand(sections.ENTITIES,makeMatrix());'
    new=r''' // Use one coordinate space consistently for both snapping and export. DXF layouts can
 // overlap model coordinates on screen; snapping a paper-space point and then moving only
 // Model Space is a classic source of huge shifts and negative coordinates.
 const rootEntities=sections.ENTITIES||[];
 const entityLayout=e=>{const q=(e.pairs||[]).find(p=>p.code===410);return q?String(q.value||'').trim().toUpperCase():'';};
 const isPaperEntity=e=>(e.pairs||[]).some(p=>p.code===67&&Number(p.value)===1)||(!!entityLayout(e)&&entityLayout(e)!=='MODEL');
 const hasModelGeometry=list=>list.some(e=>{
  if(['VERTEX','SEQEND','ENDBLK','BLOCK'].includes(e.type))return false;
  const p=e.pairs||[],c=new Set(p.map(q=>q.code));
  return (e.type==='POINT'||e.type==='INSERT'||e.type==='HATCH'||e.type==='DIMENSION') ||
    Array.from({length:9},(_,i)=>10+i).some(x=>c.has(x)&&c.has(x+10));
 });
 const modelSpaceEntities=rootEntities.filter(e=>!isPaperEntity(e));
 const paperSpaceEntities=rootEntities.filter(isPaperEntity);
 expand(hasModelGeometry(modelSpaceEntities)?modelSpaceEntities:paperSpaceEntities,makeMatrix());'''
    body=replace_once(body,old,new,'manual preview coordinate-space selection')
    return body

def patch_board(body: str) -> str:
    # Keep preview space selection identical to the writer's Model Space/Paper Space fallback.
    old=" const parsed=splitPairs(bytes),all=sectionRecords(parsed.pairs,'ENTITIES'),blocks=blockDefinitions(parsed.pairs),usedFallback=!base;const parsedLayers=layerDefinitions(parsed.pairs);"
    new=r''' const parsed=splitPairs(bytes),allSpaces=sectionRecords(parsed.pairs,'ENTITIES'),blocks=blockDefinitions(parsed.pairs),usedFallback=!base;const parsedLayers=layerDefinitions(parsed.pairs);
 const isPaperRec=rec=>(rec.pairs||[]).some(p=>p.code===67&&Number(p.value)===1)||(rec.pairs||[]).some(p=>p.code===410&&String(p.value||'').trim().toUpperCase()!=='MODEL');
 const hasWorldXY=rec=>{const codes=new Set((rec.pairs||[]).map(p=>p.code));for(let x=10;x<=18;x++)if(codes.has(x)&&codes.has(x+10))return true;return ['POINT','INSERT','HATCH','DIMENSION'].includes(rec.type);};
 const modelSpaceRecords=allSpaces.filter(r=>!isPaperRec(r)),paperSpaceRecords=allSpaces.filter(isPaperRec);
 const all=modelSpaceRecords.some(hasWorldXY)?modelSpaceRecords:paperSpaceRecords;'''
    body=replace_once(body,old,new,'writer/preview model space agreement')

    old_space=" const isPaper=rec=>rec.pairs.some(p=>p.code===67&&Number(p.value)===1);"
    new_space=" const isPaper=rec=>rec.pairs.some(p=>p.code===67&&Number(p.value)===1)||rec.pairs.some(p=>p.code===410&&String(p.value||'').trim().toUpperCase()!=='MODEL');"
    body=replace_once(body,old_space,new_space,'writer layout-space filtering (67/410)')

    # Add a strict fail-closed preflight. An exposed insertion point is not the entire
    # geometry of a proxy/solid/leader/table, so silently moving that point is not alignment.
    old=" const records=modelHasGeometry?model:(paperFallback?paper:[]);\n if(!records.length)throw new Error('لم أجد كيانات هندسية قابلة للتحويل في Model Space أو Paper Space. قد تكون اللوحة مرجعًا خارجيًا أو محتوى CAD خاصًا لا يكشف إحداثياته. لم يتم حفظ إسقاط فارغ.');\n const dimBlockNames=new Set(all.filter(r=>r.type==='DIMENSION').map(r=>recordString(r,2).toUpperCase()).filter(Boolean));"
    new=r''' const records=modelHasGeometry?model:(paperFallback?paper:[]);
 if(!records.length)throw new Error('لم أجد كيانات هندسية قابلة للتحويل في Model Space أو Paper Space. قد تكون اللوحة مرجعًا خارجيًا أو محتوى CAD خاصًا لا يكشف إحداثياته. لم يتم حفظ إسقاط فارغ.');
 // These are entities whose full appearance/geometry is held in opaque proxy data or
 // local coordinate systems. Transforming only visible group-10/20 points leaves geometry
 // behind and produces a false/partially moved board; reject instead of exporting corruption.
 const exact2DTypes=new Set(['LINE','POINT','CIRCLE','ARC','LWPOLYLINE','POLYLINE','TEXT','MTEXT','ATTRIB','ATTDEF','INSERT','SOLID','TRACE','3DFACE','SPLINE','ELLIPSE','RAY','XLINE','LEADER','HATCH','DIMENSION','IMAGE']);
 const structuralTypes=new Set(['VERTEX','SEQEND']);
 const opaqueTypeNames=new Set(['ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH','SURFACE','HELIX','MLEADER','MLINE','TABLE','WIPEOUT','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY','TOLERANCE','SHAPE','VIEWPORT']);
 const unsafeTypes=records.filter(rec=>!exact2DTypes.has(rec.type)&&!structuralTypes.has(rec.type));
 const hiddenPayload=records.filter(rec=>!exact2DTypes.has(rec.type)&&rec.pairs.some(p=>p.code===310));
 const nonDefaultOcs=records.filter(rec=>{
   const gx=rec.pairs.find(p=>p.code===210),gy=rec.pairs.find(p=>p.code===220),gz=rec.pairs.find(p=>p.code===230);
   if(!gx&&!gy&&!gz)return false;
   const x=gx?Number(gx.value):0,y=gy?Number(gy.value):0,z=gz?Number(gz.value):1;
   return ![x,y,z].every(Number.isFinite)||Math.abs(x)>1e-9||Math.abs(y)>1e-9||Math.abs(z-1)>1e-9;
 });
 if(unsafeTypes.length||hiddenPayload.length){
   const names=Array.from(new Set([...unsafeTypes,...hiddenPayload].map(r=>r.type))).slice(0,10).join(', ');
   throw new Error('تم إيقاف التصدير حفاظًا على تطابق اللوحة كاملة. تحتوي على كائنات CAD لا يمكن تحويل هندستها الداخلية بالكامل عبر DXF النصي ('+names+'). لم يتم إنشاء ملف جزئي أو مشوّه. افتح المصدر في CAD واحفظ/حوّل هذه الكائنات إلى كيانات هندسية عادية قبل التوجيه.');
 }
 if(nonDefaultOcs.length){const names=Array.from(new Set(nonDefaultOcs.map(r=>r.type))).slice(0,8).join(', ');throw new Error('تم إيقاف التصدير لأن هناك كيانات في مستوى إحداثيات محلي/ثلاثي الأبعاد غير قياسي ('+names+'). تحويل XY وحدهما قد يشوّهها. استخدم نسخة 2D مسقطة من CAD ثم أعد التوجيه.');}
 const dimBlockNames=new Set(all.filter(r=>r.type==='DIMENSION').map(r=>recordString(r,2).toUpperCase()).filter(Boolean));'''
    body=replace_once(body,old,new,'fail-closed entity preflight')

    # IMAGE entities use their first point plus two WCS axis vectors; clipping/pixel data must remain local.
    old="  for(let xc=10;xc<=18;xc++){\n   let mode='point';\n   if((rec.type==='MTEXT'||rec.type==='ELLIPSE'||rec.type==='RAY'||rec.type==='XLINE')&&xc===11)mode='vector';\n   if(rec.type==='IMAGE'&&(xc===11||xc===12))mode='vector';\n   if(rec.type==='SPLINE'&&(xc===12||xc===13))mode='vector';\n   xy(xc,xc+10,mode);\n  }"
    new=r'''  for(let xc=10;xc<=18;xc++){
   // IMAGE clipping coordinates (codes 13+) live in pixel space, not drawing XY.
   if(rec.type==='IMAGE'&&xc>12)continue;
   let mode='point';
   if((rec.type==='MTEXT'||rec.type==='ELLIPSE'||rec.type==='RAY'||rec.type==='XLINE')&&xc===11)mode='vector';
   if(rec.type==='IMAGE'&&(xc===11||xc===12))mode='vector';
   if(rec.type==='SPLINE'&&(xc===12||xc===13))mode='vector';
   xy(xc,xc+10,mode);
  }'''
    body=replace_once(body,old,new,'IMAGE local clipping coordinate protection')

    # Replace opaque-entity preview recovery with a dimension-only recovery: other object fields
    # are not guaranteed to be geometry and must not be joined into strange lines.
    old=" const extraTypes=new Set(['DIMENSION','ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH','SURFACE','MLEADER','TABLE','IMAGE','WIPEOUT','HELIX','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY']);"
    new=" const extraTypes=new Set(['DIMENSION']);"
    body=replace_once(body,old,new,'avoid lines from opaque object metadata')

    # Add transformed source overlay to the reference canvas so user can see full-board mismatch
    # before exporting. This overlay is draw-only and never becomes DXF entities.
    anchor='const selectionForDraw=selectedFor(v.side)'
    overlay=r'''const alignPreview=(v.side==='reference'&&v.alignmentPreview)?v.alignmentPreview:null;
 if(alignPreview&&alignPreview.source&&alignPreview.transform){
  const src=alignPreview.source,t=alignPreview.transform,visible=state.views.target&&state.views.target.layerVisibility||{};
  c.save();c.globalAlpha=.92;c.strokeStyle='#42e8ff';c.fillStyle='#42e8ff';c.lineWidth=.85;c.setLineDash([]);c.lineCap='round';c.lineJoin='round';c.beginPath();
  for(const seg of src.segs||[]){const key=String(seg.layer||'0'),layerVis=Object.prototype.hasOwnProperty.call(visible,key)?visible[key]:Object.prototype.hasOwnProperty.call(visible,key.toUpperCase())?visible[key.toUpperCase()]:true;if(!layerVis)continue;const a=project(v,t.point(seg.a.x,seg.a.y),m),b=project(v,t.point(seg.b.x,seg.b.y),m);if(![a.x,a.y,b.x,b.y].every(Number.isFinite))continue;if((a.x<-1200&&b.x<-1200)||(a.x>m.w+1200&&b.x>m.w+1200)||(a.y<-1200&&b.y<-1200)||(a.y>m.h+1200&&b.y>m.h+1200))continue;c.moveTo(a.x,a.y);c.lineTo(b.x,b.y);}
  c.stroke();
  for(const pt of src.anchors||[]){const key=String(pt.layer||'0'),layerVis=Object.prototype.hasOwnProperty.call(visible,key)?visible[key]:Object.prototype.hasOwnProperty.call(visible,key.toUpperCase())?visible[key.toUpperCase()]:true;if(!layerVis)continue;const q=t.point(pt.x,pt.y),p=project(v,q,m);if(p.x<-20||p.x>m.w+20||p.y<-20||p.y>m.h+20)continue;c.beginPath();c.fillStyle='#42e8ff';c.arc(p.x,p.y,2.4,0,Math.PI*2);c.fill();}
  for(const tx of src.texts||[]){const key=String(tx.layer||'0'),layerVis=Object.prototype.hasOwnProperty.call(visible,key)?visible[key]:Object.prototype.hasOwnProperty.call(visible,key.toUpperCase())?visible[key.toUpperCase()]:true;if(!layerVis||!tx.p)continue;const q=t.point(tx.p.x,tx.p.y),p=project(v,q,m);if(p.x<-80||p.x>m.w+80||p.y<-30||p.y>m.h+30)continue;c.save();c.translate(p.x,p.y);c.rotate(-((Number(tx.rotation)||0)+t.angleDeg)*Math.PI/180);c.fillStyle='#42e8ff';c.font=Math.max(1.2,Math.min(11,(Number(tx.height)||2.5)*t.scale*m.base*.8))+'px sans-serif';c.fillText(String(tx.text||'').slice(0,250),3,-3);c.restore();}
  for(let i=0;i<2;i++){const sp=state.targetPoints[i],rp=state.referencePoints[i];if(sp){const q=project(v,t.point(sp.x,sp.y),m);c.beginPath();c.strokeStyle='#42e8ff';c.lineWidth=2;c.arc(q.x,q.y,7,0,Math.PI*2);c.stroke();c.fillStyle='#42e8ff';c.font='bold 12px sans-serif';c.fillText('T'+(i+1),q.x+8,q.y-8);}if(rp){const q=project(v,rp,m);c.beginPath();c.strokeStyle='#fff';c.lineWidth=1.6;c.arc(q.x,q.y,5,0,Math.PI*2);c.stroke();}}
  c.restore();
 }
 const selectionForDraw=selectedFor(v.side)'''
    body=replace_once(body,anchor,overlay,'source-to-reference drawing overlay')

    # Clear stale overlay when either board changes or a new point is picked.
    old=" const snap=nearestSnap(v,world,screen);if(!snap){status('لم أجد تقاطعًا أو رأسًا أو خطًا قريبًا. كبّر اللوحة أو اضغط قرب العنصر.',true);return;}"
    new=" const snap=nearestSnap(v,world,screen);if(!snap){status('لم أجد تقاطعًا أو رأسًا أو خطًا قريبًا. كبّر اللوحة أو اضغط قرب العنصر.',true);return;}if(state.views.reference)state.views.reference.alignmentPreview=null;"
    body=replace_once(body,old,new,'clear stale overlay on point change')

    # Invalidate preview after manual coordinate edits or edits/deletes on either board.
    old_manual="const pts=side==='target'?state.targetPoints:state.referencePoints;pts[i]={...(pts[i]||{}),x,y,kind:'إحداثيات معدلة يدويًا'};const v=state.views[side];if(v)draw(v);"
    new_manual="const pts=side==='target'?state.targetPoints:state.referencePoints;pts[i]={...(pts[i]||{}),x,y,kind:'إحداثيات معدلة يدويًا'};if(state.views.reference)state.views.reference.alignmentPreview=null;const v=state.views[side];if(v)draw(v);"
    body=replace_once(body,old_manual,new_manual,'invalidate overlay after manual coordinate editing')
    for fn in ('deleteSelectedEntity','undoDelete','redoDelete','deleteReferenceEntity','undoReferenceDelete','redoReferenceDelete'):
        marker='function '+fn+'(){'
        if body.count(marker)!=1: raise ValueError('missing or ambiguous '+fn+' entry')
        body=body.replace(marker,marker+'if(state.views.reference)state.views.reference.alignmentPreview=null;',1)

    # Bounds sanity and real preview overlay after the exact two-point fit.
    old="function review(){try{const t=calculation(),pairs=[[state.targetPoints[0],state.referencePoints[0]],[state.targetPoints[1],state.referencePoints[1]]],errors=pairs.map(([s,r])=>{const p=t.point(s.x,s.y);return Math.hypot(p.x-r.x,p.y-r.y);}),tol=Math.max(1e-8,Math.max(...pairs.flatMap(([s,r])=>[Math.abs(s.x),Math.abs(s.y),Math.abs(r.x),Math.abs(r.y)]))*1e-12);if(errors.some(e=>!Number.isFinite(e)||e>tol))throw new Error('فشل فحص التطابق العددي للنقطتين. أعد اختيار النقاط ولا تصدّر هذه المطابقة.');status('المعاينة جاهزة: النقطتان تطابقتا حسابيًا. معامل المقياس ×'+t.scale.toFixed(10)+' | الدوران '+t.angleDeg.toFixed(8)+'° | الإزاحة X='+t.tx.toFixed(6)+' وY='+t.ty.toFixed(6)+' | أقصى خطأ = '+Math.max(...errors).toExponential(3)+' | X وY دون تبديل.');return t;}catch(e){status(e.message,true);return null;}}"
    new=r'''function alignmentBounds(bounds,t){const corners=[{x:bounds.minX,y:bounds.minY},{x:bounds.maxX,y:bounds.minY},{x:bounds.minX,y:bounds.maxY},{x:bounds.maxX,y:bounds.maxY}].map(p=>t.point(p.x,p.y));return {minX:Math.min(...corners.map(p=>p.x)),maxX:Math.max(...corners.map(p=>p.x)),minY:Math.min(...corners.map(p=>p.y)),maxY:Math.max(...corners.map(p=>p.y))};}
function validateAlignmentBounds(sb,rb,t){const ob=alignmentBounds(sb,t),sd=Math.hypot(sb.maxX-sb.minX,sb.maxY-sb.minY),rd=Math.hypot(rb.maxX-rb.minX,rb.maxY-rb.minY),od=Math.hypot(ob.maxX-ob.minX,ob.maxY-ob.minY);if(!(sd>1e-8&&rd>1e-8&&od>1e-8))throw new Error('حدود إحدى اللوحتين غير صالحة. لم يتم التصدير.');const relativeExtent=od/rd;if(!Number.isFinite(relativeExtent)||relativeExtent<0.02||relativeExtent>50)throw new Error('المقياس المحسوب لا يتوافق مع أحجام اللوحتين (نسبة امتداد '+relativeExtent.toPrecision(4)+'). غالبًا تم التقاط نقطة غير متناظرة أو من مساحة مختلفة. أعد اختيار النقطتين نفسيهما بالترتيب الصحيح.');const srcCx=(ob.minX+ob.maxX)/2,srcCy=(ob.minY+ob.maxY)/2,refCx=(rb.minX+rb.maxX)/2,refCy=(rb.minY+rb.maxY)/2,centerGap=Math.hypot(srcCx-refCx,srcCy-refCy),diag=Math.max(rd,od);const ix=Math.max(0,Math.min(ob.maxX,rb.maxX)-Math.max(ob.minX,rb.minX)),iy=Math.max(0,Math.min(ob.maxY,rb.maxY)-Math.max(ob.minY,rb.minY)),overlap=ix*iy,minArea=Math.max(1e-12,Math.min((ob.maxX-ob.minX)*(ob.maxY-ob.minY),(rb.maxX-rb.minX)*(rb.maxY-rb.minY))),overlapRatio=overlap/minArea;if(centerGap>2.0*diag||(overlapRatio<0.01&&centerGap>0.35*diag))throw new Error('النقطتان تتطابقان حسابيًا لكن بقية اللوحة تقع بعيدًا عن اللوحة المرجعية (فجوة المراكز '+centerGap.toFixed(3)+'، والتداخل '+(overlapRatio*100).toFixed(2)+'%). لن أصدر لوحة مزاحة أو بإحداثيات سالبة على نحو غير متوقع. أعد التقاط نقطتين متناظرتين على نفس تقاطعات المحاور.');if(rb.minX>=-1e-8&&rb.minY>=-1e-8&&(ob.minX< -Math.max(1,rd*.05)||ob.minY< -Math.max(1,rd*.05))&&overlapRatio<0.15)throw new Error('نتيجة التحويل تدفع اللوحة إلى قيم سالبة بعيدة عن امتداد المرجع. أُوقف التصدير لحماية الإحداثيات؛ راجع تطابق النقطة 1 مع 1 والنقطة 2 مع 2.');return {ob,overlapRatio,relativeExtent,centerGap};}
function review(){try{
 const t=calculation(),pairs=[[state.targetPoints[0],state.referencePoints[0]],[state.targetPoints[1],state.referencePoints[1]]],errors=pairs.map(([s,r])=>{const p=t.point(s.x,s.y);return Math.hypot(p.x-r.x,p.y-r.y);}),tol=Math.max(1e-8,Math.max(...pairs.flatMap(([s,r])=>[Math.abs(s.x),Math.abs(s.y),Math.abs(r.x),Math.abs(r.y)]))*1e-12);
 if(errors.some(e=>!Number.isFinite(e)||e>tol))throw new Error('فشل فحص التطابق العددي للنقطتين. أعد اختيار النقاط ولا تصدّر هذه المطابقة.');
 const sv=state.views.target,rv=state.views.reference;if(!sv||!rv)throw new Error('تعذر فحص امتداد اللوحتين. افتح اللوحتين مرة أخرى.');
 const sb=sv.drawing.bounds,rb=rv.drawing.bounds,fit=validateAlignmentBounds(sb,rb,t),ob=fit.ob,overlapRatio=fit.overlapRatio;
 rv.alignmentPreview={source:sv.drawing,transform:t};draw(rv);showScreen('reference');
 status('معاينة التراكب جاهزة: المرجع ظاهر بألوانه الأصلية واللوحة المنقولة فوقه باللون السماوي. معامل المقياس ×'+t.scale.toFixed(10)+' | الدوران '+t.angleDeg.toFixed(8)+'° | الإزاحة X='+t.tx.toFixed(6)+' وY='+t.ty.toFixed(6)+' | خطأ النقطتين '+Math.max(...errors).toExponential(3)+' | تداخل امتداد اللوحتين '+(overlapRatio*100).toFixed(2)+'%. خطوط السماوي معاينة فقط وليست إضافات إلى ملف DXF.');
 return t;
 }catch(e){if(state.views.reference){state.views.reference.alignmentPreview=null;draw(state.views.reference);}status(e.message,true);return null;}}'''
    body=replace_once(body,old,new,'full-board alignment validation and overlay preview')

    old_api="window.__sqOrientation110API={VERSION,solve,transformBytes:universalTransformBytes,deleteNearestEntityBytes,findNearestEntityBytes,findEntitiesInWindowBytes,removeSelectedEntityBytes,removeSelectedEntitiesBytes,splitPairs,sectionRecords,recordGeometry,geometryInWorld,blockDefinitions,parsePreview};"
    new_api="window.__sqOrientation110API={VERSION,solve,validateAlignmentBounds,transformBytes:universalTransformBytes,deleteNearestEntityBytes,findNearestEntityBytes,findEntitiesInWindowBytes,removeSelectedEntityBytes,removeSelectedEntitiesBytes,splitPairs,sectionRecords,recordGeometry,geometryInWorld,blockDefinitions,parsePreview};"
    body=replace_once(body,old_api,new_api,'expose deterministic alignment preflight for regression tests')

    # A warning that is honest about DWG translation and that native/proxy CAD cannot be safely moved by textual DXF editing.
    body=body.replace('ملاحظة: جميع بيانات DXF الأصلية محفوظة عند الإخراج؛ المعاينة هنا هندسية.','المعاينة هندسية؛ كائنات CAD الغامضة تُرفض قبل الإخراج بدل تركها في موقعها القديم.')
    body=body.replace('مهم: لا تحتاج إلى ملف مرجعي ثانٍ أو تسميات محاور.','')
    body=body.replace('التحويل يعمل على إحداثيات XY المكشوفة لكل كيان DXF، بما فيها الأنواع غير المعروفة، ويترك Z وبيانات الطبقات والألوان والنصوص والحقول الأخرى كما هي. العناصر ذات حمولة ثنائية داخلية لا تكشف إحداثياتها لا يمكن إعادة هندستها دون محرك CAD، لذلك تبقى ببياناتها الأصلية ولا تمنع إخراج الملف.','حماية التطابق الكامل: لا يتم التصدير إذا احتوت اللوحة على كائنات Proxy أو Solids أو MLINE/MLEADER/TABLE أو كيانات في OCS غير قياسي، لأن نقل إحداثياتها الظاهرة فقط يترك هندستها الداخلية في مكانها ويشوّه اللوحة. في هذه الحالة لن يُنشأ ملف جزئي. عند اختيار DWG، يجري التحويل إلى DXF أولًا؛ الكائنات الخاصة بـ Civil 3D التي لا تتحول إلى هندسة عادية تحتاج محرك CAD أصليًا للحفاظ عليها بالكامل.')
    return body

def apply(html: str) -> tuple[str, dict[str,str]]:
    result=html
    manual=patch_manual(get_body(result,MANUAL_ID));result=put_body(result,MANUAL_ID,manual)
    board=patch_board(get_body(result,BOARD_ID));result=put_body(result,BOARD_ID,board)
    checks={
        'space_filter': 'const modelSpaceEntities=rootEntities.filter' in get_body(result,MANUAL_ID) and "p.code===410&&String(p.value||'').trim().toUpperCase()!=='MODEL" in get_body(result,BOARD_ID) and 'const all=modelSpaceRecords.some(hasWorldXY)?modelSpaceRecords:paperSpaceRecords;' in get_body(result,BOARD_ID),
        'opaque_fail_closed': 'تم إيقاف التصدير حفاظًا على تطابق اللوحة كاملة' in get_body(result,BOARD_ID),
        'extent_sanity': 'النقطتان تتطابقان حسابيًا لكن بقية اللوحة تقع بعيدًا عن اللوحة المرجعية' in get_body(result,BOARD_ID) and 'validateAlignmentBounds' in get_body(result,BOARD_ID),
        'real_overlay': 'alignmentPreview={source:sv.drawing,transform:t}' in get_body(result,BOARD_ID),
        'image_local_clip_preserved': "if(rec.type==='IMAGE'&&xc>12)continue;" in get_body(result,BOARD_ID),
        'no_proxy_preview_lines': "const extraTypes=new Set(['DIMENSION']);" in get_body(result,BOARD_ID),
    }
    if not all(checks.values()):raise ValueError('V143 post-patch checks failed: '+repr(checks))
    return result,checks

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-html',type=Path,required=True)
    ap.add_argument('--output-html',type=Path,required=True)
    ap.add_argument('--report',type=Path)
    a=ap.parse_args()
    src=a.input_html.read_text(encoding='utf-8')
    out,checks=apply(src)
    a.output_html.parent.mkdir(parents=True,exist_ok=True)
    a.output_html.write_text(out,encoding='utf-8',newline='')
    if a.report:
        a.report.write_text('# V143 full-board alignment safety report\n\n'+''.join(f'- {k}: PASS\n' for k,v in checks.items())+'\nUnsafe entities are rejected rather than partially moved. Preview overlay is display-only.\n',encoding='utf-8')
    print('PASS V143 patch application: '+', '.join(k for k,v in checks.items() if v))
if __name__=='__main__':main()
