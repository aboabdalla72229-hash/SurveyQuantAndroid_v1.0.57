#!/usr/bin/env bash
set -euo pipefail
WORK_DIR="${1:?usage: build-v155-libredwg.sh WORK_DIR APP_SOURCE_DIR}"
APP_SOURCE_DIR="${2:?usage: build-v155-libredwg.sh WORK_DIR APP_SOURCE_DIR}"
REPO="$WORK_DIR/libredwg-web-v0.8.2"
rm -rf "$REPO"
git clone --depth 1 --branch v0.8.2 --recurse-submodules https://github.com/mlightcad/libredwg-web.git "$REPO"
cd "$REPO"
chmod +x ./autogen.sh
./autogen.sh
cd bindings/javascript
export CFLAGS='-O2 -DNDEBUG'
export CXXFLAGS='-O2 -DNDEBUG'
export EMCC_CFLAGS='-O2'
corepack enable
corepack prepare pnpm@9.12.3 --activate
python3 - <<'PY'
import json, pathlib, re
p=pathlib.Path('package.json'); data=json.loads(p.read_text())
# Keep ARCALIGNEDTEXT generated in the optimized build instead of leaving its schema-specific
# handlers behind the source tree's debug-only dynamic dispatch.
cls_path=pathlib.Path('../../src/classes.inc'); cls=cls_path.read_text()
line_re=re.compile(r'^\s*(?:DEBUGGING_CLASS|UNSTABLE_CLASS|UNSTABLE_ENTITY|DEBUGGING_ENTITY)\s*\(ACTION,\s*ARCALIGNEDTEXT\).*$',re.M)
new='  STABLE_CLASS        (ACTION, ARCALIGNEDTEXT) // SurveyQuant v155: generated ARCALIGNEDTEXT handler'
if new not in cls:
    matches=list(line_re.finditer(cls))
    if len(matches)!=1:
        raise SystemExit(f'Expected one ARCALIGNEDTEXT dispatch entry, found {len(matches)}; refusing unsupported source patch.')
    cls=cls[:matches[0].start()]+new+cls[matches[0].end():]
    cls_path.write_text(cls)
if cls.count(new)!=1:
    raise SystemExit('ARCALIGNEDTEXT stable dispatch patch did not verify exactly once.')
# Split the upstream DEBUG_CLASSES/IS_FREE guard around ONLY ARCALIGNEDTEXT.
# Do not hoist the entity by replacing a large source range: that can delete other
# schemas and leave the upstream closing #endif unmatched. Verify the original
# preprocessor nesting, then close the guard immediately before this schema and
# reopen it immediately after. This leaves all neighboring schemas untouched.
spec_path=pathlib.Path('../../src/dwg2.spec'); spec=spec_path.read_text()
marker='DWG_ENTITY (ARCALIGNEDTEXT)'; ix=spec.find(marker)
if ix<0 or spec.find(marker,ix+1)>=0: raise SystemExit('Expected one ARCALIGNEDTEXT schema in src/dwg2.spec.')
guard='#if defined (DEBUG_CLASSES) || defined (IS_FREE)'
start=spec.rfind(guard,0,ix)
if start<0: raise SystemExit('Expected DEBUG_CLASSES/IS_FREE guard before ARCALIGNEDTEXT.')
# Fail closed if the upstream source is already unbalanced or a nested guard crosses
# the entity boundary. Match each preprocessor opening directive to its real #endif.
pp_re=re.compile(r'(?m)^[ \t]*#[ \t]*(if|ifdef|ifndef|endif)\b[^\n]*')
pp_stack=[]; pp_pairs={}
for m in pp_re.finditer(spec):
    directive=m.group(1)
    if directive in ('if','ifdef','ifndef'): pp_stack.append(m.start())
    else:
        if not pp_stack: raise SystemExit(f'Unmatched #endif in upstream dwg2.spec at offset {m.start()}.')
        pp_pairs[pp_stack.pop()]=m.start()
if pp_stack: raise SystemExit(f'Unclosed preprocessor guard in upstream dwg2.spec at offsets {pp_stack}.')
close=pp_pairs.get(start)
if close is None or not (start < ix < close): raise SystemExit('Unable to match the outer DEBUG_CLASSES/IS_FREE guard safely.')
def pp_stack_at(stop):
    active=[]
    for m in pp_re.finditer(spec,0,stop):
        if m.group(1) in ('if','ifdef','ifndef'): active.append(m.start())
        else:
            if not active: raise SystemExit(f'Unmatched #endif before offset {stop}.')
            active.pop()
    return active
if pp_stack_at(ix) != [start]:
    raise SystemExit('Nested preprocessor guard crosses ARCALIGNEDTEXT start; refusing to alter source.')
entity_end=spec.find('DWG_ENTITY_END',ix)
if entity_end<0: raise SystemExit('ARCALIGNEDTEXT schema has no DWG_ENTITY_END marker.')
entity_line_end=spec.find('\n',entity_end)
if entity_line_end<0: entity_line_end=len(spec)
else: entity_line_end += 1
if pp_stack_at(entity_line_end) != [start]:
    raise SystemExit('Nested preprocessor guard crosses ARCALIGNEDTEXT end; refusing to alter source.')
line_start=spec.rfind('\n',0,ix)+1
if spec[line_start:ix].strip(): raise SystemExit('Unexpected indentation/layout before ARCALIGNEDTEXT schema.')
# Insert after the entity first, then before its start; all source between remains intact.
resume='\n#if defined (DEBUG_CLASSES) || defined (IS_FREE) /* resume original guarded schemas */\n'
spec=spec[:entity_line_end]+resume+spec[entity_line_end:]
spec=spec[:line_start]+'#endif /* compile ARCALIGNEDTEXT in release builds */\n'+spec[line_start:]
# Validate the complete edited file and assert the schema is now outside that guard.
check_stack=[]
for m in pp_re.finditer(spec):
    if m.group(1) in ('if','ifdef','ifndef'): check_stack.append(m.start())
    else:
        if not check_stack: raise SystemExit(f'Patched dwg2.spec has unmatched #endif at offset {m.start()}.')
        check_stack.pop()
if check_stack: raise SystemExit(f'Patched dwg2.spec has unclosed preprocessor directives at offsets {check_stack}.')
new_ix=spec.find(marker)
if pp_stack_at(new_ix): raise SystemExit('ARCALIGNEDTEXT is not outside the debug-only guard after the patch.')
if spec.count(marker)!=1: raise SystemExit('ARCALIGNEDTEXT schema count changed during guarded split.')
spec_path.write_text(spec)
# Patch only reproducible configure/link flags needed by the browser/WASM runtime.
for key in ('build:prepare','build:obj','build:wasm'):
    cmd=data['scripts'][key]
    if key=='build:prepare':
        if '--disable-write' not in cmd: raise SystemExit('Expected upstream --disable-write flag missing.')
        cmd=cmd.replace(' --disable-write','',1)
        cmd=cmd.replace(' --enable-debug','',1)
        cmd=cmd.replace(' --disable-dxf','',1)
        if '--enable-dxf' not in cmd: cmd += ' --enable-dxf'
    elif key=='build:obj':
        if 'emmake make' not in cmd: raise SystemExit('Expected upstream make command missing.')
        cmd=cmd.replace('emmake make','emmake make -C src',1)
    else:
        # First link an ES module; Vite bundles this exact runtime into dist/libredwg-web.js.
        if ' -s EXPORT_ES6=0' in cmd: cmd=cmd.replace(' -s EXPORT_ES6=0',' -s EXPORT_ES6=1',1)
        if ' --emit-tsd libredwg-web.d.ts' not in cmd: raise SystemExit('Expected --emit-tsd flag missing from upstream build.')
        cmd=cmd.replace(' --emit-tsd libredwg-web.d.ts','',1)
        if ' -O2' not in cmd and ' -Os' not in cmd: cmd += ' -O2'
        # Keep a named MainModule type because src/libredwg.ts imports it by name.
        # The current Emscripten version no longer emits this legacy shape via --emit-tsd.
        cmd += " && printf '%s\\n' 'export interface MainModule { [key: string]: any; }' 'declare const createModule: (options?: Record<string, unknown>) => Promise<MainModule>;' 'export { MainModule };' 'export default createModule;' > libredwg-web.d.ts"
    data['scripts'][key]=cmd
# Upstream source has callbacks whose parameter types are inferred from the generated
# Emscripten module interface. That inference is unavailable with the minimal dynamic
# module surface above, so keep strict checks except noImplicitAny for this generated wrapper.
tsconfig_path=pathlib.Path('tsconfig.json')
tsconfig=json.loads(tsconfig_path.read_text())
opts=tsconfig.setdefault('compilerOptions', {})
opts['noImplicitAny']=False
tsconfig_path.write_text(json.dumps(tsconfig, indent=2)+'\n')
p.write_text(json.dumps(data,indent=2)+'\n')
print('PASS: v0.8.2 browser-WASM configuration updated; ARCALIGNEDTEXT is dispatched and generated TypeScript declarations expose MainModule.')
PY
pnpm install --frozen-lockfile
pnpm build:prepare
pnpm build:obj
pnpm build:wasm
pnpm copy
# Build the typed JavaScript wrapper against the newly generated ESM loader.
pnpm build
node --check wasm/libredwg-web.js
node --check dist/libredwg-web.js
node --input-type=module - <<'JS'
import fs from 'node:fs';
const js=fs.readFileSync('wasm/libredwg-web.js','utf8');
const wasm=fs.readFileSync('wasm/libredwg-web.wasm');
await WebAssembly.compile(wasm);
for(const name of ['dwg_write_dxf','dwg_read_file','dwg_free']) if(!wasm.includes(Buffer.from(name,'ascii'))) throw new Error('WASM is missing binding '+name);
if(!js.includes('createModule')) throw new Error('WASM loader missing createModule factory');
console.log('PASS: compiled v0.8.2 loader/WASM, bytes='+wasm.length);
JS
if [[ ! -f "$APP_SOURCE_DIR/SurveyQuant_v1.0.155_DWG_CORPUS_TEST.mjs" ]]; then echo 'ERROR: SurveyQuant DWG corpus test missing from source patch.'; exit 1; fi
cp "$APP_SOURCE_DIR/SurveyQuant_v1.0.155_DWG_CORPUS_TEST.mjs" test/surveyquant-dwg-corpus.test.mjs
node --test test/surveyquant-dwg-corpus.test.mjs
# Link a second classic-script loader for Android WebView's window.createModule bootstrap.
python3 - <<'PY2'
import json,pathlib
p=pathlib.Path('package.json'); d=json.loads(p.read_text()); k='build:wasm'; c=d['scripts'][k]
if ' -s EXPORT_ES6=1' not in c: raise SystemExit('ES module loader flag missing before classic re-link.')
d['scripts'][k]=c.replace(' -s EXPORT_ES6=1',' -s EXPORT_ES6=0',1); p.write_text(json.dumps(d,indent=2)+'\n')
PY2
pnpm build:wasm
pnpm copy
mkdir -p "$APP_SOURCE_DIR/libredwg-writer/wasm" "$APP_SOURCE_DIR/libredwg-writer/dist"
cp wasm/libredwg-web.js "$APP_SOURCE_DIR/libredwg-writer/wasm/libredwg-web.js"
cp wasm/libredwg-web.wasm "$APP_SOURCE_DIR/libredwg-writer/wasm/libredwg-web.wasm"
# Keep the tested V154 browser UMD wrapper because the HTML loader expects
# window.SurveyQuantLibreDwg. It already exports the stable dwg_read_data and
# dwg_write_dxf APIs and is compatible with the matching Embind entry points.
# Do not copy the ESM/Vite dist output here: it expects the ESM WASM loader, while
# Android WebView loads the classic script factory below.
LEGACY_WRAPPER="$APP_SOURCE_DIR/libredwg-writer/dist/libredwg-web.js"
test -s "$LEGACY_WRAPPER" || { echo 'ERROR: expected V154 UMD wrapper missing.'; exit 1; }
for api in SurveyQuantLibreDwg dwg_read_data dwg_write_dxf; do
  grep -q "$api" "$LEGACY_WRAPPER" || { echo "ERROR: V154 UMD wrapper missing API token $api"; exit 1; }
done
cat > "$APP_SOURCE_DIR/libredwg-writer/BUILD_CONFIGURATION_V155.txt" <<'TXT'
SurveyQuant v1.0.155 native DWG reader + Alignment browser runtime
Upstream: mlightcad/libredwg-web v0.8.2 (upstream tag published 2026-10-22).
The build enables DXF output and removes upstream --disable-write, uses classic script WASM factory for Android WebView, and uses the source-generated ARCALIGNEDTEXT handler. The previously validated V154 UMD JavaScript wrapper is deliberately retained because the application loads window.SurveyQuantLibreDwg via a classic script; Vite's new ESM dist wrapper would be incompatible with that loading contract.
Release gate: six real DWG fixtures from LibreDWG's checked-in test corpus (AC1015, AC1018, AC1021, AC1024, AC1027, AC1032) must each pass direct database reading, layer/entity checks, DWG-to-DXF conversion and DXF EOF/section validation before APK packaging. This verifies supported regression fixtures, not every customer's DWG or byte-identical DWG round-tripping.
Alignment export mutates original group-code records from the temporary DXF stream instead of redrawing/reconstructing entities. BLOCK definitions receive the global linear transform; INSERT anchors receive the affine translation, while INSERT-local scale/rotation remain unchanged to prevent double-transforming block labels and axes. Unsupported opaque entities fail closed rather than exporting a knowingly incomplete drawing.
TXT
printf 'PASS v155: rebuilt native DWG WASM runtime and passed six-version DWG reader/writer integration tests.\n'
