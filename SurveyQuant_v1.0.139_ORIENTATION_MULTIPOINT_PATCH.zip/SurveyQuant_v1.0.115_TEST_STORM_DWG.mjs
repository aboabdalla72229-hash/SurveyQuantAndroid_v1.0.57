import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';

const [packageDir, inputDir, outputDir, reportFile] = process.argv.slice(2);
if (!packageDir || !inputDir || !outputDir || !reportFile) throw new Error('usage: test-storm.mjs packageDir inputDir outputDir reportFile');
await fs.mkdir(outputDir, { recursive: true });
const rows = [];
let failed = false;
const expectedBoards = new Map([
  ['bda1107966cbd4976566bdd58cb7dc473fdd8328c235ff218c75cc424083dcb0', 'AC1032'],
  ['86f09ea8fe7f8259479509a3cbf08b899e118127e2e4b02f8a61219356df2a84', 'AC1024']
]);
function auditDxf(bytes) {
  const text = new TextDecoder('latin1').decode(bytes).replace(/^\uFEFF/, '');
  const lines = text.split(/\r\n|\n|\r/);
  if (lines.at(-1) === '') lines.pop();
  const errors = [];
  if (lines.length % 2 !== 0) errors.push(`number of text rows is odd (${lines.length})`);
  let section = '', entities = 0, coordinatePairs = 0, layerNames = new Set(), textItems = 0, hasEof = false;
  for (let i = 0; i + 1 < lines.length; i += 2) {
    const codeText = lines[i].trim();
    if (!/^[+-]?\d+$/.test(codeText)) { errors.push(`bad group code at line ${i + 1}: ${codeText.slice(0, 40)}`); break; }
    const code = Number(codeText), value = lines[i + 1].trim();
    if (code === 0 && value.toUpperCase() === 'SECTION') { section = ''; if (Number(lines[i + 2]?.trim()) === 2) section = String(lines[i + 3] || '').trim().toUpperCase(); }
    else if (code === 0 && value.toUpperCase() === 'ENDSEC') section = '';
    else if (code === 0 && value.toUpperCase() === 'EOF') hasEof = true;
    else if (section === 'ENTITIES') {
      if (code === 0 && value && value.toUpperCase() !== 'ENDSEC') entities++;
      if ((code >= 10 && code <= 18) || (code >= 20 && code <= 28)) coordinatePairs++;
      if (code === 8 && value) layerNames.add(value);
      if (code === 1 && value) textItems++;
    }
  }
  if (!text.includes('SECTION') || !text.includes('ENTITIES') || !hasEof) errors.push('required DXF SECTION/ENTITIES/EOF markers missing');
  if (entities < 5) errors.push(`only ${entities} entity records were emitted`);
  if (coordinatePairs < 5) errors.push(`only ${coordinatePairs} XY coordinate group records were emitted`);
  return { textBytes: bytes.length, entities, coordinateRecords: coordinatePairs, layers: layerNames.size, textItems, hasEof, errors };
}
try {
  const pkg = await import(pathToFileURL(path.join(packageDir, 'dist', 'libredwg-web.js')).href);
  const LibreDwg = pkg.LibreDwg || pkg.default?.LibreDwg;
  if (!LibreDwg || typeof LibreDwg.create !== 'function') throw new Error('LibreDwg wrapper API unavailable after writer-enabled build');
  const lib = await LibreDwg.create(path.join(packageDir, 'wasm') + path.sep);
  if (typeof lib.dwg_write_dxf !== 'function') throw new Error('wrapper exposes no dwg_write_dxf function');
  const files = (await fs.readdir(inputDir, { withFileTypes: true, recursive: true }))
    .filter(x => x.isFile() && x.name.toLowerCase().endsWith('.dwg'))
    .map(x => path.join(x.parentPath || inputDir, x.name)).sort();
  if (files.length !== 2) throw new Error(`STORM regression input must contain exactly two DWG files, found ${files.length}`);
  for (let i = 0; i < files.length; i++) {
    const filePath = files[i], raw = await fs.readFile(filePath);
    const exact = new Uint8Array(raw.buffer, raw.byteOffset, raw.byteLength).slice();
    const digest = createHash('sha256').update(exact).digest('hex');
    const before = { bytes: exact.byteLength, firstSix: new TextDecoder('latin1').decode(exact.slice(0, 6)), sha256: digest };
    try {
      if (!expectedBoards.has(digest)) throw new Error(`Unexpected DWG content hash: ${digest}; this is not one of the two exact STORM files supplied by the user.`);
      if (before.firstSix !== expectedBoards.get(digest)) throw new Error(`DWG signature ${before.firstSix} does not match expected ${expectedBoards.get(digest)} for this exact input.`);
      // Collect source model-space count where the upstream reader can expose it.
      // This is a report-only diagnostic; a count mismatch must never block the app's DXF export.
      let sourceModelSpaceEntities = null, sourceCountNote = null, dwgPointer = null;
      try {
        if (pkg.Dwg_File_Type && typeof lib.dwg_read_data === 'function' && typeof lib.dwg_getall_entities_in_model_space === 'function') {
          dwgPointer = lib.dwg_read_data(exact.buffer, pkg.Dwg_File_Type.DWG);
          if (dwgPointer) sourceModelSpaceEntities = lib.dwg_getall_entities_in_model_space(dwgPointer).length;
        } else sourceCountNote = 'Upstream model-space count API not exposed in this build.';
      } catch (e) { sourceCountNote = e?.message || String(e); }
      finally { if (dwgPointer) { try { lib.dwg_free(dwgPointer); } catch (_) {} } }
      const produced = lib.dwg_write_dxf(exact.buffer);
      const bytes = produced instanceof Uint8Array ? produced : produced instanceof ArrayBuffer ? new Uint8Array(produced) : ArrayBuffer.isView(produced) ? new Uint8Array(produced.buffer, produced.byteOffset, produced.byteLength) : new Uint8Array(produced || []);
      if (bytes.byteLength < 100) throw new Error(`DXF output too small (${bytes.byteLength} bytes)`);
      const stats = auditDxf(bytes);
      if (stats.errors.length) throw new Error(stats.errors.join('; '));
      const out = path.join(outputDir, `STORM_${i + 1}_converted.dxf`);
      await fs.writeFile(out, bytes);
      rows.push({ input: path.basename(filePath), sourceBytes: before.bytes, signature: before.firstSix, sha256: before.sha256, sourceModelSpaceEntities, sourceCountNote, countDifference: sourceModelSpaceEntities == null ? null : sourceModelSpaceEntities - stats.entities, result: 'PASS', ...stats, output: path.basename(out) });
    } catch (e) {
      failed = true;
      rows.push({ input: path.basename(filePath), sourceBytes: before.bytes, signature: before.firstSix, sha256: before.sha256, result: 'FAIL', error: e?.stack || String(e) });
    }
  }
} catch (e) {
  failed = true;
  rows.push({ input: 'STORM test setup', result: 'FAIL', error: e?.stack || String(e) });
}
const report = [
  '# STORM DWG direct-conversion regression test',
  '',
  'Executed against the writer-enabled LibreDWG-Web build that the APK will use. Passing this test confirms both input drawings convert to text DXF with entity and XY records; it does not certify every proprietary/proxy object or every visual property in every CAD application.',
  '',
  ...rows.map((r, i) => `## Case ${i + 1}\n\n- Input: ${r.input}\n- Result: ${r.result}\n${r.sourceBytes !== undefined ? `- Input size: ${r.sourceBytes} bytes\n- DWG signature: ${r.signature}\n- SHA-256: ${r.sha256}\n` : ''}${r.textBytes !== undefined ? `- Output size: ${r.textBytes} bytes\n- Source model-space entity count (report-only): ${r.sourceModelSpaceEntities ?? 'unavailable'}\n- Converted DXF entity records: ${r.entities}\n- Source minus converted count (report-only): ${r.countDifference ?? 'unavailable'}\n${r.sourceCountNote ? `- Source count diagnostic note: ${r.sourceCountNote}\n` : ''}- XY coordinate records: ${r.coordinateRecords}\n- Layers: ${r.layers}\n- Text payloads: ${r.textItems}\n- EOF present: ${r.hasEof}\n- Output file: ${r.output}\n` : ''}${r.error ? `- Error: \n\n\`\`\`\n${r.error}\n\`\`\`\n` : ''}`),
  '',
  failed ? 'OVERALL: FAIL. No APK should be treated as fixed until this test passes.' : 'OVERALL: PASS for both user-provided STORM DWG inputs.'
].join('\n');
await fs.writeFile(reportFile, report, 'utf8');
console.log(report);
if (failed) process.exit(1);
