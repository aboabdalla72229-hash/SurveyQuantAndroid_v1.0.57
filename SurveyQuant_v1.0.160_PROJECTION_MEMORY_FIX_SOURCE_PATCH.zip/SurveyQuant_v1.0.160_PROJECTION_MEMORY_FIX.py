#!/usr/bin/env python3
"""Fix SurveyQuant V160 projection memory pressure and remove redundant DWG work."""
from pathlib import Path
import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--html',required=True,type=Path)
parser.add_argument('--output',type=Path)
parser.add_argument('--check-only',action='store_true')
args=parser.parse_args()
p=args.html
s=p.read_text(encoding='utf-8')
if args.check_only:
    required=["function sqScanDxfProjectionText(text, collectLayerNames=true){","function sqProjectionBuildEntityRecords(entities,scan,startHandle){","sourceModel=await parseFile(src,{needDxf:false,keepRawDwgBytes:false,keepRawDxfBytes:false,keepRawText:false,lightweight:true});","targetModel=await parseFile(cad,{preserveOnly:true,keepRawDwgBytes:false,keepRawDxfBytes:true,keepRawText:false,lightweight:true});","preserveOnly:options.preserveOnly===true","targetBytes=null;targetModel=null;","function sqApplyByteEdits(source,edits){"]
    missing=[x for x in required if x not in s]
    if missing: raise SystemExit('V160 validation failed, missing: '+', '.join(missing))
    if "const lines=[];let pos=0;" not in s: raise SystemExit('Expected the general-purpose parser used by other projects was unexpectedly altered.')
    print('PASS: V160 preserve-only reference loading, streaming DXF scanner, one-allocation splice, and bounded model retention are present')
    raise SystemExit(0)


def rep(old,new,label):
 global s
 n=s.count(old)
 if n!=1: raise RuntimeError(f'{label}: expected 1 hit, got {n}')
 s=s.replace(old,new,1)

# Remove duplicated full DXF text retention except for the profile tool that explicitly requests it.
rep("function parseDXF(text){\n const parser=new DxfParser();let d=null,parserError=null;\n try{d=parser.parseSync(text);}catch(error){parserError=error;d={entities:[],tables:{layers:{layers:{}}}};}\n const m={source:'DXF',rawDXF:text,entities:[],layers:new Map(),points:[],segments:[],polylines:[],elevTexts:[]};",
"function parseDXF(text, options={}){\n const parser=new DxfParser();let d=null,parserError=null;\n try{d=parser.parseSync(text);}catch(error){parserError=error;d={entities:[],tables:{layers:{layers:{}}}};}\n const m={source:'DXF',entities:[],layers:new Map(),points:[],segments:[],polylines:[],elevTexts:[]};\n if(options.keepRawText===true)m.rawDXF=text;",
"parseDXF raw text retention")

# Worker reads can skip the redundant writer pass when the first projection input only supplies entities.
rep(" ' try{if(typeof lib.dwg_write_dxf!==\"function\")throw new Error(\"محرك LibreDWG لا يحتوي على محول DXF.\");dxfBytes=sqValidateDwgConversion(lib.dwg_write_dxf(sourceBytes.buffer));}catch(e){conversionError=String(e&&e.message||e);}',\n ' if(!nativeModel&&!dxfBytes)throw new Error(\"تعذرت قراءة DWG وتحويله. القارئ: \"+(nativeReadError||\"غير متاح\")+\"؛ المحول: \"+(conversionError||\"غير متاح\"));',\n ' const result={nativeModel: nativeModel,sourceBuffer:sourceBytes.buffer,dxfBuffer:dxfBytes?dxfBytes.buffer:null,nativeReadError:nativeReadError?String(nativeReadError):\"\",conversionError:conversionError?String(conversionError):\"\"};',\n ' const transfers=[sourceBytes.buffer];if(dxfBytes&&dxfBytes.buffer!==sourceBytes.buffer)transfers.push(dxfBytes.buffer);',\n ' self.postMessage({requestId:payload.requestId,ok:true,result:result},transfers);',",
" ' if(payload.needDxf!==false||!nativeModel){try{if(typeof lib.dwg_write_dxf!==\"function\")throw new Error(\"محرك LibreDWG لا يحتوي على محول DXF.\");dxfBytes=sqValidateDwgConversion(lib.dwg_write_dxf(sourceBytes.buffer));}catch(e){conversionError=String(e&&e.message||e);}}',\n ' if(!nativeModel&&!dxfBytes)throw new Error(\"تعذرت قراءة DWG وتحويله. القارئ: \"+(nativeReadError||\"غير متاح\")+\"؛ المحول: \"+(conversionError||\"غير متاح\"));',\n ' const result={nativeModel: nativeModel,sourceBuffer:payload.keepRawDwgBytes===false?null:sourceBytes.buffer,dxfBuffer:dxfBytes?dxfBytes.buffer:null,nativeReadError:nativeReadError?String(nativeReadError):\"\",conversionError:conversionError?String(conversionError):\"\"};',\n ' const transfers=[];if(result.sourceBuffer)transfers.push(result.sourceBuffer);if(dxfBytes&&dxfBytes.buffer!==result.sourceBuffer)transfers.push(dxfBytes.buffer);',\n ' self.postMessage({requestId:payload.requestId,ok:true,result:result},transfers);',",
"worker skip redundant DXF conversion and byte transfer")

# Replace worker parser with option-aware version.
rep("async function sqParseDwgInWorker(file,timeoutMs=90000){\n const worker=await sqEnsureDwgWorker();if(!worker)return null;\n const buffer=await file.arrayBuffer();",
"async function sqParseDwgInWorker(file,timeoutMs=90000,options={}){\n const worker=await sqEnsureDwgWorker();if(!worker)return null;\n const buffer=await file.arrayBuffer();",
"worker reader options")
rep("worker.postMessage({requestId:requestId,buffer:buffer,wasmScriptUrl:new URL(SQ_WRITER_WASM_URL,document.baseURI).href,engineScriptUrl:new URL(SQ_WRITER_ENGINE_URL,document.baseURI).href,wasmBase:sqDwgWasmRuntimePath()},[buffer]);",
"worker.postMessage({requestId:requestId,buffer:buffer,wasmScriptUrl:new URL(SQ_WRITER_WASM_URL,document.baseURI).href,engineScriptUrl:new URL(SQ_WRITER_ENGINE_URL,document.baseURI).href,wasmBase:sqDwgWasmRuntimePath(),needDxf:options.needDxf!==false&&options.keepRawDxfBytes!==false,keepRawDwgBytes:options.keepRawDwgBytes!==false},[buffer]);",
"worker request flags")
rep(" const rawDXFBytes=result.dxfBuffer?new Uint8Array(result.dxfBuffer):null;let model=null;\n if(result.nativeModel)model={...result.nativeModel,layers:new Map(result.nativeModel.layers||[])};\n // Most DWGs already yield native entities. Parse the converted DXF only if the native reader returned none.\n if(!model&&rawDXFBytes){let lastErr=null;for(const encoding of ['utf-8','windows-1252']){try{const candidate=parseDXF(new TextDecoder(encoding,{fatal:false}).decode(rawDXFBytes));if(candidate&&(candidate.entities?.length||candidate.points?.length||candidate.segments?.length||candidate.polylines?.length)){model=candidate;break;}lastErr=new Error('تم تحويل DWG إلى DXF لكن لم يعثر قارئ اللوحة على كيانات قابلة للقراءة.');}catch(e){lastErr=e;}}if(!model)throw lastErr||new Error('تعذر تحليل DXF المحول من DWG.');}\n if(!model)throw new Error('لم ينتج محرك DWG عناصر CAD قابلة للاستخدام.');\n model.source='DWG';model.convertedFromDWG=!!rawDXFBytes;model.sourceName=file.name;model.rawDWGBytes=new Uint8Array(result.sourceBuffer);model.rawDXFBytes=rawDXFBytes;",
" const convertedDXFBytes=result.dxfBuffer?new Uint8Array(result.dxfBuffer):null;const rawDXFBytes=options.keepRawDxfBytes===false?null:convertedDXFBytes;let model=null;\n if(result.nativeModel)model={...result.nativeModel,layers:new Map(result.nativeModel.layers||[])};\n // Most DWGs already yield native entities. Parse converted DXF only as fallback.\n if(!model&&convertedDXFBytes){let lastErr=null;for(const encoding of ['utf-8','windows-1252']){try{const candidate=parseDXF(new TextDecoder(encoding,{fatal:false}).decode(convertedDXFBytes),{keepRawText:options.keepRawText===true});if(candidate&&(candidate.entities?.length||candidate.points?.length||candidate.segments?.length||candidate.polylines?.length)){model=candidate;break;}lastErr=new Error('تم تحويل DWG إلى DXF لكن لم يعثر قارئ اللوحة على كيانات قابلة للقراءة.');}catch(e){lastErr=e;}}if(!model)throw lastErr||new Error('تعذر تحليل DXF المحول من DWG.');}\n if(!model)throw new Error('لم ينتج محرك DWG عناصر CAD قابلة للاستخدام.');\n model.source='DWG';model.convertedFromDWG=!!convertedDXFBytes;model.sourceName=file.name;if(options.keepRawDwgBytes!==false&&result.sourceBuffer)model.rawDWGBytes=new Uint8Array(result.sourceBuffer);if(rawDXFBytes)model.rawDXFBytes=rawDXFBytes;",
"worker model raw retention")
rep(" ' if(typeof lib.dwg_read_data===\"function\"&&typeof lib.convert===\"function\"){let dataPtr=0;",
    " ' if(payload.preserveOnly!==true&&typeof lib.dwg_read_data===\"function\"&&typeof lib.convert===\"function\"){let dataPtr=0;",
    "preserve-only worker skips native database parse")
rep("}}else nativeReadError=\"إصدار محرك LibreDWG لا يدعم قراءة قاعدة DWG الأصلية.\";",
    "}}else if(payload.preserveOnly!==true)nativeReadError=\"إصدار محرك LibreDWG لا يدعم قراءة قاعدة DWG الأصلية.\";",
    "preserve-only worker intentional native skip")
rep(" const convertedDXFBytes=result.dxfBuffer?new Uint8Array(result.dxfBuffer):null;const rawDXFBytes=options.keepRawDxfBytes===false?null:convertedDXFBytes;let model=null;",
    " const convertedDXFBytes=result.dxfBuffer?new Uint8Array(result.dxfBuffer):null;const rawDXFBytes=options.keepRawDxfBytes===false?null:convertedDXFBytes;\n if(options.preserveOnly===true){if(!rawDXFBytes)throw new Error('محرك DWG لم ينتج DXF مرجعيًا صالحًا.');return {source:'DWG',sourceName:file.name,convertedFromDWG:true,entities:[],layers:new Map(),points:[],segments:[],polylines:[],elevTexts:[],rawDXFBytes:rawDXFBytes,rawDWGBytes:null};}\n let model=null;",
    "worker preserve-only raw-DXF return")

# Update shared parser to accept opt-outs and skip extra DWG writer work where safe.
rep("async function parseFile(file){\n const ext=file.name.toLowerCase().split('.').pop();\n if(ext==='dwg'){\n  const workerModel=await sqParseDwgInWorker(file);",
"async function parseFile(file, options={}){\n const ext=file.name.toLowerCase().split('.').pop();\n if(ext==='dwg'){\n  const workerModel=await sqParseDwgInWorker(file,90000,options);",
"parseFile options")
rep("   lib=await LibreDwg.create(sqDwgWasmRuntimePath());\n   // First read the native DWG database.",
    "   lib=await LibreDwg.create(sqDwgWasmRuntimePath());\n   if(options.preserveOnly===true){try{if(typeof lib.dwg_write_dxf!=='function')throw new Error('محرك DWG لا يحتوي على محول DXF');dxfBytes=sqValidateDwgConversion(lib.dwg_write_dxf(fileContent));}catch(e){conversionError=e;}if(!dxfBytes)throw conversionError||new Error('تعذر تحويل لوحة DWG المرجعية.');return {source:'DWG',sourceName:file.name,convertedFromDWG:true,entities:[],layers:new Map(),points:[],segments:[],polylines:[],elevTexts:[],rawDXFBytes:dxfBytes,rawDWGBytes:null};}\n   // First read the native DWG database.",
    "main-thread preserve-only read")
rep("   // Keep a temporary DWG-to-DXF record stream for project tools that consume DXF bytes.\n   // Native database data remains the preferred source for supported CAD geometry and axes.\n   try{\n    if(typeof lib.dwg_write_dxf!=='function')throw new Error('محرك DWG الحالي لا يحتوي على محول DXF');\n    const converted=lib.dwg_write_dxf(fileContent);\n    dxfBytes=sqValidateDwgConversion(converted);\n   }catch(e){conversionError=e;}",
"   // Only build the temporary DXF stream if this caller needs original-record export/preservation.\n   // Reading the first projection input as native entities alone avoids a second full CAD conversion.\n   if(options.needDxf!==false&&options.keepRawDxfBytes!==false){\n    try{\n     if(typeof lib.dwg_write_dxf!=='function')throw new Error('محرك DWG الحالي لا يحتوي على محول DXF');\n     const converted=lib.dwg_write_dxf(fileContent);\n     dxfBytes=sqValidateDwgConversion(converted);\n    }catch(e){conversionError=e;}\n   }else if(!nativeModel){\n    try{const converted=lib.dwg_write_dxf(fileContent);dxfBytes=sqValidateDwgConversion(converted);}catch(e){conversionError=e;}\n   }",
"main parser conditional DXF conversion")
rep("     nativeModel.rawDWGBytes=sourceBytes.slice();nativeModel.rawDXFBytes=null;",
"     if(options.keepRawDwgBytes!==false)nativeModel.rawDWGBytes=sourceBytes;nativeModel.rawDXFBytes=null;",
"avoid DWG byte copy")
rep("   model.rawDWGBytes=sourceBytes.slice();model.rawDXFBytes=dxfBytes.slice();",
"   if(options.keepRawDwgBytes!==false)model.rawDWGBytes=sourceBytes;if(options.keepRawDxfBytes!==false)model.rawDXFBytes=dxfBytes;",
"avoid converted byte copies")
rep(" if(ext==='dxf'){let lastErr=null;for(const enc of ['utf-8','windows-1252']){try{const model=parseDXF(new TextDecoder(enc,{fatal:false}).decode(bytes));model.rawDXFBytes=bytes.slice();return model;}catch(e){lastErr=e;}}throw new Error('ملف DXF غير مقروء: '+(lastErr?.message||''));}",
" if(ext==='dxf'&&options.preserveOnly===true)return {source:'DXF',sourceName:file.name,convertedFromDWG:false,entities:[],layers:new Map(),points:[],segments:[],polylines:[],elevTexts:[],rawDXFBytes:bytes,rawDWGBytes:null};\n if(ext==='dxf'){let lastErr=null;for(const enc of ['utf-8','windows-1252']){try{const model=parseDXF(new TextDecoder(enc,{fatal:false}).decode(bytes),{keepRawText:options.keepRawText===true});if(options.keepRawDxfBytes!==false)model.rawDXFBytes=bytes;return model;}catch(e){lastErr=e;}}throw new Error('ملف DXF غير مقروء: '+(lastErr?.message||''));}",
"DXF parse no duplicate text/bytes")
rep("async function loadProfileCAD(){try{const f=document.getElementById('profileFileInput').files[0];if(!f)return alert('اختر DWG أو DXF أولاً');profileModel=await parseFile(f);",
"async function loadProfileCAD(){try{const f=document.getElementById('profileFileInput').files[0];if(!f)return alert('اختر DWG أو DXF أولاً');profileModel=await parseFile(f,{keepRawText:true});",
"profile keep raw text needed")

# One output allocation for byte-preserving insertions instead of repeatedly copying the entire DWG-derived DXF.
rep("function sqApplyByteEdits(source,edits){let out=source.slice();edits.sort((a,b)=>b.start-a.start);for(const e of edits){const insert=e.insertBytes||new Uint8Array(0);out=sqConcatBytes([out.subarray(0,e.start),insert,out.subarray(e.end)]);}return out;}",
"function sqApplyByteEdits(source,edits){\n const ordered=(edits||[]).slice().sort((a,b)=>a.start-b.start);let total=source.length,readAt=0;\n for(const e of ordered){if(e.start<readAt||e.end<e.start||e.end>source.length)throw new Error('تداخل غير صالح في مواضع تعديل DXF؛ لم يتم تغيير اللوحة الأصلية.');const insert=e.insertBytes||new Uint8Array(0);total+=insert.length-(e.end-e.start);readAt=e.end;}\n const out=new Uint8Array(total);let srcAt=0,dstAt=0;\n for(const e of ordered){out.set(source.subarray(srcAt,e.start),dstAt);dstAt+=e.start-srcAt;const insert=e.insertBytes||new Uint8Array(0);out.set(insert,dstAt);dstAt+=insert.length;srcAt=e.end;}\n out.set(source.subarray(srcAt),dstAt);return out;\n}",
"single allocation projection edits")

# Insert an O(1)-metadata DXF scanner. Unlike sqDxfPairsWithOffsets, this does not allocate an object per DXF group.
scanner = r'''function sqScanDxfProjectionText(text, collectLayerNames=true){
 const result={completedSections:new Set(),entityEndSec:null,layerTable:null,version:'AC1009',modelSpaceHandle:null,handseedPair:null,maxHandle:'0',hasEOF:false};
 let pos=0,pendingSection=false,currentSection='',pendingTable=false,tableStart=0,currentTable='',layerRow=false,blockRow=false,blockName='',pendingAcadVer=false,pendingHandseed=false;
 let layerSawRow=false;
 const validHandle=v=>/^[0-9A-F]+$/i.test(v||'');
 const maxHandle=(a,b)=>{a=String(a||'0').replace(/^0+/, '').toUpperCase()||'0';b=String(b||'0').replace(/^0+/, '').toUpperCase()||'0';return b.length>a.length||b.length===a.length&&b>a?b:a;};
 while(pos<text.length){
  const start=pos,nl=text.indexOf('\n',pos),codeEnd=nl<0?text.length:nl;let codeStop=codeEnd;if(codeStop>start&&text[codeStop-1]==='\r')codeStop--;
  const valueStart=nl<0?text.length:nl+1;if(valueStart>=text.length)break;
  const vnl=text.indexOf('\n',valueStart),vEnd=vnl<0?text.length:vnl;let valueStop=vEnd;if(valueStop>valueStart&&text[valueStop-1]==='\r')valueStop--;
  const code=text.slice(start,codeStop).trim(),value=text.slice(valueStart,valueStop).trim(),end=vnl<0?text.length:vnl+1,p={code,value,start,end,valueStart,valueEnd:valueStop};pos=end;
  const up=value.toUpperCase();
  if(pendingAcadVer){result.version=value||'AC1009';pendingAcadVer=false;}
  if(pendingHandseed){if(code==='5'&&validHandle(value))result.handseedPair=p;pendingHandseed=false;}
  if(code==='9'&&up==='$ACADVER')pendingAcadVer=true;
  if(code==='9'&&up==='$HANDSEED')pendingHandseed=true;
  if(code==='5'||code==='105'){if(validHandle(value))result.maxHandle=maxHandle(result.maxHandle,value);}
  if(code==='0'&&up==='SECTION')pendingSection=true;
  else if(pendingSection){if(code==='2'){currentSection=up;}pendingSection=false;}
  if(code==='0'&&up==='ENDSEC'){if(currentSection){result.completedSections.add(currentSection);if(currentSection==='ENTITIES')result.entityEndSec=p;}currentSection='';}
  if(code==='0'&&up==='EOF')result.hasEOF=true;
  if(code==='0'&&up==='TABLE'){pendingTable=true;tableStart=p.start;}
  else if(pendingTable){
   if(code==='2'){currentTable=up;if(currentTable==='LAYER') {result.layerTable={tableStart,rows:[],names:new Set(),countPair:null,tableHandlePair:null,endTab:null};layerSawRow=false;layerRow=false;} }
   pendingTable=false;
  }
  if(currentTable==='LAYER'&&result.layerTable&&!result.layerTable.endTab){
   const lt=result.layerTable;
   if(code==='0'&&up==='ENDTAB'){lt.endTab=p;currentTable='';layerRow=false;}
   else if(!layerSawRow&&code==='70')lt.countPair=p;
   else if(!layerSawRow&&code==='5')lt.tableHandlePair=p;
   else if(code==='0'&&up==='LAYER'){layerRow=true;layerSawRow=true;}
   else if(code==='0'){layerRow=false;}
   else if(layerRow&&code==='2'){if(collectLayerNames)lt.names.add(value);lt.rows.push(value);layerRow=false;}
  } else if(currentTable==='BLOCK_RECORD'){
   if(code==='0'&&up==='ENDTAB'){currentTable='';blockRow=false;blockName='';}
   else if(code==='0'&&up==='BLOCK_RECORD'){blockRow=true;blockName='';}
   else if(code==='0'){blockRow=false;blockName='';}
   else if(blockRow&&code==='2')blockName=value;
   else if(blockRow&&code==='5'&&blockName.replace(/[\s_-]/g,'').toUpperCase()==='*MODELSPACE'&&validHandle(value))result.modelSpaceHandle=value.toUpperCase();
  }
 }
 if(result.layerTable&&!result.layerTable.endTab)result.layerTable=null;
 return result;
}
function sqProjectionBuildLayerRows(layerFirstEntity,missing,scan){
 let max=BigInt('0x'+(scan.maxHandle||'0')),text='';if(!missing.length)return{text,maxHandle:max};
 const tableHandle=scan.layerTable?.tableHandlePair?.value;if(!tableHandle||! /^[0-9A-F]+$/i.test(tableHandle))throw new Error('تعذر الحفاظ على بنية جدول الطبقات الحديث في DXF المرجعي.');
 for(const name of missing){max+=1n;const handle=max.toString(16).toUpperCase(),e=layerFirstEntity.get(name),color=Number.isFinite(Number(e?.color))?Number(e.color):7;text+=`0\nLAYER\n5\n${handle}\n330\n${tableHandle}\n100\nAcDbSymbolTableRecord\n100\nAcDbLayerTableRecord\n2\n${name}\n70\n0\n62\n${color}\n6\nCONTINUOUS\n`;}
 return{text,maxHandle:max};
}
function sqProjectionBuildEntityRecords(entities,scan,startHandle){
 let max=typeof startHandle==='bigint'?startHandle:BigInt('0x'+(scan.maxHandle||'0'));const owner=scan.modelSpaceHandle;if(!owner&&entities?.length)throw new Error('لوحة DXF المرجعية لا تحتوي على مقبض Model Space صالح؛ أوقفت التصدير لحماية بنية الملف.');
 const z=v=>safeNum(v),nl='\n';let out='';
 const emit=(type,subclass,layer,color,fields)=>{max+=1n;const handle=max.toString(16).toUpperCase();out+=`0${nl}${type}${nl}5${nl}${handle}${nl}330${nl}${owner}${nl}100${nl}AcDbEntity${nl}8${nl}${asciiLayerName(layer)}${nl}`;if(Number.isFinite(Number(color)))out+=`62${nl}${Number(color)}${nl}`;out+=`100${nl}${subclass}${nl}${fields}`;};
 const xyz=(a,code)=>`${code}${nl}${z(a.x)}${nl}${code+10}${nl}${z(a.y)}${nl}${code+20}${nl}${z(a.z)}${nl}`;
 for(const e of entities||[]){const L=e.layer||'0',color=e.color;
  if(e.type==='POINT'&&e.position)emit('POINT','AcDbPoint',L,color,xyz(e.position,10));
  else if(e.type==='LINE'&&e.a&&e.b)emit('LINE','AcDbLine',L,color,xyz(e.a,10)+xyz(e.b,11));
  else if((e.type==='TEXT'||e.type==='MTEXT')&&e.position){const q=e.position;emit('TEXT','AcDbText',L,color,xyz(q,10)+`40${nl}${Math.max(.01,z(e.height)||.35)}${nl}1${nl}${asciiText(e.text)}${nl}50${nl}${z(e.rotation)}${nl}72${nl}0${nl}73${nl}0${nl}`);}
  else if(e.type==='CIRCLE'&&e.center&&Number.isFinite(e.radius)){const q=e.center;emit('CIRCLE','AcDbCircle',L,color,xyz(q,10)+`40${nl}${Math.abs(z(e.radius))}${nl}`);}
  else if(e.type==='ARC'&&e.center&&Number.isFinite(e.radius)){max+=1n;const handle=max.toString(16).toUpperCase(),q=e.center;out+=`0${nl}ARC${nl}5${nl}${handle}${nl}330${nl}${owner}${nl}100${nl}AcDbEntity${nl}8${nl}${asciiLayerName(L)}${nl}`;if(Number.isFinite(Number(color)))out+=`62${nl}${Number(color)}${nl}`;out+=`100${nl}AcDbCircle${nl}${xyz(q,10)}40${nl}${Math.abs(z(e.radius))}${nl}100${nl}AcDbArc${nl}50${nl}${z(e.startAngle)}${nl}51${nl}${z(e.endAngle)}${nl}`;}
  else if((e.type==='XLINE'||e.type==='RAY')&&(e.basePoint||e.startPoint||e.position)&&(e.directionVector||e.unitVector||e.direction)){const base=e.basePoint||e.startPoint||e.position,dir=e.directionVector||e.unitVector||e.direction;if([base.x,base.y,dir.x,dir.y].every(v=>Number.isFinite(Number(v))))emit(e.type,e.type==='RAY'?'AcDbRay':'AcDbXline',L,color,xyz(base,10)+xyz(dir,11));}
  else if(e.type==='3DFACE'&&e.vertices?.length>=3){const v=e.vertices,q=v[3]||v[2];let fields='';for(let i=0;i<4;i++)fields+=xyz(v[i]||q,10+i);emit('3DFACE','AcDbFace',L,color,fields);}
  else if(e.vertices?.length>=2&&['LWPOLYLINE','POLYLINE2D','POLYLINE3D','POLYLINE'].includes(e.type)){for(let i=0;i<e.vertices.length-1;i++)emit('LINE','AcDbLine',L,color,xyz(e.vertices[i],10)+xyz(e.vertices[i],11));if(e.closed)emit('LINE','AcDbLine',L,color,xyz(e.vertices[e.vertices.length-1],10)+xyz(e.vertices[0],11));}
 }
 return{text:out,nextHandseed:(max+1n).toString(16).toUpperCase(),maxHandle:max};
}
'''
rep("// Keep the reference DXF byte-for-byte intact except for adding required layer rows\n// and appending new entities. Do not parse/recreate its original drawing entities.\nfunction mergeProjectionDxfPreservingReference(rawBytes, additions){",
"// Keep the reference DXF byte-for-byte intact except for adding required layer rows\n// and appending new entities. Do not parse/recreate its original drawing entities.\n"+scanner+"\nfunction mergeProjectionDxfPreservingReference(rawBytes, additions){",
"insert streaming DXF scanner")

# Replace merge function up to the following function.
start=s.index('function mergeProjectionDxfPreservingReference(rawBytes, additions){')
end=s.index('async function downloadQuantDXF(){',start)
new_merge=r'''function mergeProjectionDxfPreservingReference(rawBytes, additions){
 if(!(rawBytes instanceof Uint8Array)||!rawBytes.length)throw new Error('لا تتوفر بايتات DXF الأصلية للحفاظ على تفاصيل اللوحة.');
 // Windows-1252 preserves a one-code-unit-to-one-byte offset mapping, including CRLF.
 const decoded=new TextDecoder('windows-1252').decode(rawBytes),originalText=decoded.startsWith('ï»¿')?'   '+decoded.slice(3):decoded;
 const scan=sqScanDxfProjectionText(originalText,true),layerTable=scan.layerTable;
 if(!scan.entityEndSec||!scan.completedSections.has('ENTITIES'))throw new Error('لم يتم العثور على قسم ENTITIES صالح في لوحة DXF المرجعية.');
 if(!layerTable||!layerTable.endTab)throw new Error('لوحة DXF المرجعية لا تحتوي على جدول LAYER صالح؛ أوقفت التصدير لتجنب إعادة رسم اللوحة وتغيير خصائصها.');
 const eol=originalText.includes('\r\n')?'\r\n':'\n',versionNo=parseInt(String(scan.version).replace(/^AC/i,''),10)||1009,modern=versionNo>=1012;
 const existing=layerTable.names||new Set(),layerFirstEntity=new Map();
 for(const e of additions||[]){const n=asciiLayerName(e.layer);if(n&&n!=='0'&&!layerFirstEntity.has(n))layerFirstEntity.set(n,e);}
 const missing=[...layerFirstEntity.keys()].filter(n=>!existing.has(n.toUpperCase()));
 let layerRows='',entityRecords='',handseedValue=null;
 if(modern){
  const layerBuild=sqProjectionBuildLayerRows(layerFirstEntity,missing,scan);layerRows=layerBuild.text;
  const entityBuild=sqProjectionBuildEntityRecords(additions,scan,layerBuild.maxHandle);entityRecords=entityBuild.text;handseedValue=entityBuild.nextHandseed;
 }else{
  for(const name of missing){const e=layerFirstEntity.get(name),c=Number.isFinite(Number(e?.color))?Number(e.color):7;layerRows+=`0\nLAYER\n2\n${name}\n70\n0\n62\n${c}\n6\nCONTINUOUS\n`;}
  entityRecords=(additions||[]).map(entityToR12).filter(Boolean).join('');
 }
 layerRows=layerRows.replace(/\n/g,eol);entityRecords=entityRecords.replace(/\n/g,eol);
 const edits=[];
 if(layerRows){edits.push({start:layerTable.endTab.start,end:layerTable.endTab.start,insertBytes:sqEncodeAscii(layerRows)});if(layerTable.countPair){const count=layerTable.rows.length+missing.length;edits.push({start:layerTable.countPair.valueStart,end:layerTable.countPair.valueEnd,insertBytes:sqEncodeAscii(String(count))});}}
 if(entityRecords)edits.push({start:scan.entityEndSec.start,end:scan.entityEndSec.start,insertBytes:sqEncodeAscii(entityRecords)});
 if(handseedValue&&entityRecords&&scan.handseedPair)edits.push({start:scan.handseedPair.valueStart,end:scan.handseedPair.valueEnd,insertBytes:sqEncodeAscii(handseedValue)});
 if(!edits.length)return rawBytes;
 return sqApplyByteEdits(rawBytes,edits);
}
'''
s=s[:start]+new_merge+s[end:]

# Replace heavy pair-array post-check with the streaming scanner; accept bytes directly to avoid another caller-held copy.
start=s.index('function inspectPreservedReferenceDXF(content){')
end=s.index('function validatePreservedReferenceDXF(content)', start)
new_inspect=r'''function inspectPreservedReferenceDXF(content){
 try{
  const text=content instanceof Uint8Array?new TextDecoder('windows-1252').decode(content):String(content||'');
  const clean=text.replace(/^(?:ï»¿|\uFEFF)/,'');
  const scan=sqScanDxfProjectionText(clean,false);
  for(const name of ['HEADER','TABLES','ENTITIES'])if(!scan.completedSections.has(name))return 'فحص DXF: القسم الأساسي '+name+' غير موجود أو غير مكتمل.';
  if(!scan.layerTable||!scan.layerTable.endTab)return 'فحص DXF: جدول الطبقات LAYER غير مكتمل.';
  if(!scan.hasEOF)return 'فحص DXF: علامة نهاية الملف EOF غير موجودة.';
  return '';
 }catch(e){return 'فحص DXF تعذر بسبب بنية غير مقروءة: '+String(e?.message||e);}
}
'''
s=s[:start]+new_inspect+s[end:]

# Rewrite dropFilesMerge so the source board is parsed without writing a second DXF, raw strings/bytes aren't duplicated,
# and target geometry is released before scanning the potentially large preserved output.
start=s.index('async function dropFilesMerge(){')
end=s.index('function downloadDroppedDXF()',start)
new_drop=r'''async function dropFilesMerge(){
 const progress=document.getElementById('dropFilesProgress'),results=document.getElementById('dropFilesResults'),summary=document.getElementById('dropFilesSummary');
 let sourceModel=null,targetModel=null;
 try{
  droppedDXF='';if(results)results.style.display='none';
  const src=document.getElementById('dropSurveyFiles').files[0],cad=document.getElementById('dropCadFile').files[0];
  if(!src||!cad)return alert('اختر ملف الإسقاط في الخانة الأولى ولوحة DXF/DWG المرجعية في الخانة الثانية.');
  if(progress){progress.style.display='block';progress.textContent='⏳ جاري قراءة الملف الأول...';}
  await new Promise(r=>setTimeout(r,20));
  sourceModel=await parseFile(src,{needDxf:false,keepRawDwgBytes:false,keepRawDxfBytes:false,keepRawText:false});
  if(progress){progress.textContent='⏳ جاري قراءة اللوحة المرجعية...';await new Promise(r=>setTimeout(r,20));}
  targetModel=await parseFile(cad,{keepRawDwgBytes:false,keepRawDxfBytes:true,keepRawText:false});
  if(!targetModel||!['DXF','DWG'].includes(String(targetModel.source).toUpperCase()))throw new Error('الخانة الثانية يجب أن تكون لوحة DXF أو DWG.');
  const targetCount=targetModel.entities?.length||0,targetSource=String(targetModel.source).toUpperCase();
  const additions=[];let addedPoints=0,addedCad=0;
  if(Array.isArray(sourceModel.points)&&sourceModel.points.length){const ps=getPointStyleSettings();for(const p of sourceModel.points){addPointDetailEntities(additions,{e:Number(p.e),n:Number(p.n),z:Number(p.z||0),id:p.id||('P'+(addedPoints+1))},ps);addedPoints++;}}
  if(sourceModel.entities?.length){if(!sourceModel.points?.length||sourceModel.source==='DXF'||sourceModel.source==='DWG'){for(const e of sourceModel.entities){additions.push(e);addedCad++;}}}
  // These entities are now referenced only by additions; release the original source model and its side arrays.
  if(sourceModel){sourceModel.entities=[];sourceModel.points=[];sourceModel.segments=[];sourceModel.polylines=[];sourceModel.elevTexts=[];sourceModel=null;}
  if(!targetCount&&!additions.length)throw new Error('لم يتم العثور على عناصر قابلة للإسقاط.');
  if(progress){progress.textContent='⏳ جاري إضافة العناصر مع الحفاظ على اللوحة الأصلية...';await new Promise(r=>setTimeout(r,20));}
  if(targetModel.rawDXFBytes instanceof Uint8Array){
    const targetBytes=targetModel.rawDXFBytes;
    // The raw records are authoritative: free the duplicated parsed geometry before working on large CAD strings.
    targetModel.entities=[];targetModel.points=[];targetModel.segments=[];targetModel.polylines=[];targetModel.elevTexts=[];targetModel.rawDWGBytes=null;targetModel.rawDXFBytes=null;
    droppedDXF=mergeProjectionDxfPreservingReference(targetBytes,additions);
    targetModel=null;
    const validationIssue=inspectPreservedReferenceDXF(droppedDXF);if(validationIssue)throw new Error(validationIssue+' تم إيقاف التصدير لحماية تفاصيل اللوحة المرجعية.');
  }else{
    const entities=[...(targetModel.entities||[]),...additions];
    droppedDXF=buildR12FromEntities(entities,{preserveEntityColors:true});
    if(!validateGeneratedDXF(droppedDXF))throw new Error('تعذر إنشاء DXF صالح من اللوحة المرجعية.');
    targetModel=null;
  }
  if(summary)summary.innerHTML=`تم إسقاط <b>${escapeHtml(src.name)}</b> على <b>${escapeHtml(cad.name)}</b>.<br>عناصر اللوحة المرجعية: <b>${targetCount}</b> | عناصر الملف الأول: <b>${addedCad}</b> | نقاط مضافة بالتفاصيل: <b>${addedPoints}</b>.<br><span class="muted">${targetSource==='DXF'?'تم الحفاظ على بايتات وعناصر وخصائص اللوحة المرجعية الأصلية كما هي؛ أُضيفت العناصر الجديدة فقط دون إعادة رسم عناصر المرجع.':'تم استخدام بايتات DXF الناتجة مباشرة من تحويل DWG كأساس وإضافة العناصر فوقها دون إعادة رسم الكيانات المقروءة؛ لا يمكن لملف DXF الناتج أن يكون نسخة ثنائية مطابقة لملف DWG الأصلي، وقد تبقى قيود التحويل على الكيانات الخاصة.'}<br>الإحداثيات ثابتة: X = Easting (E) وY = Northing (N)، دون تبديل.</span>`;
  if(results)results.style.display='block';
 }catch(e){console.error('dropFilesMerge',e);alert('تعذر إسقاط الملف على اللوحة: '+(e?.message||e));}
 finally{sourceModel=null;targetModel=null;if(progress)progress.style.display='none';}
}

'''
s=s[:start]+new_drop+s[end:]

# Lightweight source mode skips the large, duplicate line/polyline/label collections not needed by projection.
rep("else if(e.type==='LINE'&&e.vertices?.length>=2){const a=p3(e.vertices[0].x,e.vertices[0].y,e.vertices[0].z),b=p3(e.vertices[1].x,e.vertices[1].y,e.vertices[1].z);addCadEntity(m,'LINE',layer,{a,b});m.segments.push({a,b,layer});}",
"else if(e.type==='LINE'&&e.vertices?.length>=2){const a=p3(e.vertices[0].x,e.vertices[0].y,e.vertices[0].z),b=p3(e.vertices[1].x,e.vertices[1].y,e.vertices[1].z);addCadEntity(m,'LINE',layer,{a,b});if(options.lightweight!==true)m.segments.push({a,b,layer});}",
"lightweight DXF lines")
rep("else if((e.type==='LWPOLYLINE'||e.type==='POLYLINE')&&e.vertices?.length>=2){let vs=e.vertices.map(v=>p3(v.x,v.y,v.z??e.elevation??0));const closed=sqPolylineIsClosed(e,vs);addCadEntity(m,type,layer,{vertices:vs,closed});m.polylines.push({vertices:vs,closed,layer});for(let i=0;i<vs.length-1;i++)m.segments.push({a:vs[i],b:vs[i+1],layer});if(closed)m.segments.push({a:vs.at(-1),b:vs[0],layer});}",
"else if((e.type==='LWPOLYLINE'||e.type==='POLYLINE')&&e.vertices?.length>=2){let vs=e.vertices.map(v=>p3(v.x,v.y,v.z??e.elevation??0));const closed=sqPolylineIsClosed(e,vs);addCadEntity(m,type,layer,{vertices:vs,closed});if(options.lightweight!==true){m.polylines.push({vertices:vs,closed,layer});for(let i=0;i<vs.length-1;i++)m.segments.push({a:vs[i],b:vs[i+1],layer});if(closed)m.segments.push({a:vs.at(-1),b:vs[0],layer});}}",
"lightweight DXF polylines")
# In generic raw-record recovery, the point/line side arrays are unnecessary for the overlay input.
rep("m.segments=recovered.filter(e=>e.type==='LINE'&&e.a&&e.b).map(e=>({a:e.a,b:e.b,layer:e.layer||'0'}));",
"m.segments=options.lightweight===true?[]:recovered.filter(e=>e.type==='LINE'&&e.a&&e.b).map(e=>({a:e.a,b:e.b,layer:e.layer||'0'}));",
"lightweight recover segments")
rep("const rawEntities=sqRawDxfGroupPolylines(sqRawDxfSectionRecords(text,'ENTITIES'));\n   for(const item of rawEntities){",
"const rawEntities=options.lightweight===true?[]:sqRawDxfGroupPolylines(sqRawDxfSectionRecords(text,'ENTITIES'));\n   for(const item of rawEntities){",
"lightweight recovery polylines")
# Tell the DWG worker to return only the geometry needed by a projection overlay.
rep("nativeModel={source:\"DWG\",entities:m.entities,layers:Array.from(m.layers.entries()),points:m.points,segments:m.segments,polylines:m.polylines,elevTexts:m.elevTexts};",
"nativeModel=payload.lightweight===true?{source:\"DWG\",entities:m.entities,layers:Array.from(m.layers.entries()),points:m.points}:{source:\"DWG\",entities:m.entities,layers:Array.from(m.layers.entries()),points:m.points,segments:m.segments,polylines:m.polylines,elevTexts:m.elevTexts};",
"worker lightweight model")
rep("keepRawDwgBytes:options.keepRawDwgBytes!==false},[buffer]);",
"keepRawDwgBytes:options.keepRawDwgBytes!==false,lightweight:options.lightweight===true,preserveOnly:options.preserveOnly===true},[buffer]);",
"worker lightweight and preserveOnly flags")
rep("     nativeModel=parseDWGDatabase(db);\n     nativeModel.nativeDwgDatabase=db;\n     if(!nativeModel.entities.length)",
"     nativeModel=parseDWGDatabase(db);\n     if(options.lightweight===true){nativeModel.segments=[];nativeModel.polylines=[];nativeModel.elevTexts=[];}\n     if(!nativeModel.entities.length)",
"main fallback lightweight + drop database handle")
rep("sourceModel=await parseFile(src,{needDxf:false,keepRawDwgBytes:false,keepRawDxfBytes:false,keepRawText:false});",
"sourceModel=await parseFile(src,{needDxf:false,keepRawDwgBytes:false,keepRawDxfBytes:false,keepRawText:false,lightweight:true});",
"projection source lightweight")
rep("targetModel=await parseFile(cad,{keepRawDwgBytes:false,keepRawDxfBytes:true,keepRawText:false});",
"targetModel=await parseFile(cad,{preserveOnly:true,keepRawDwgBytes:false,keepRawDxfBytes:true,keepRawText:false,lightweight:true});",
"projection target lightweight")
rep("const targetCount=targetModel.entities?.length||0,targetSource=String(targetModel.source).toUpperCase();", "const targetCount=targetModel.entities?.length||'محفوظة مباشرة',targetSource=String(targetModel.source).toUpperCase();", "reference board preserve-only summary")
# Scanner only stores a count for layer rows, not one string per row; layer names are normalized for case-insensitive lookup.
rep("result.layerTable={tableStart,rows:[],names:new Set(),countPair:null,tableHandlePair:null,endTab:null};",
"result.layerTable={tableStart,rowCount:0,names:new Set(),countPair:null,tableHandlePair:null,endTab:null};",
"stream layer metadata")
rep("if(collectLayerNames)lt.names.add(value);lt.rows.push(value);layerRow=false;",
"if(collectLayerNames)lt.names.add(value.toUpperCase());lt.rowCount++;layerRow=false;",
"stream rows count/name normalization")
rep("const count=layerTable.rows.length+missing.length;",
"const count=layerTable.rowCount+missing.length;",
"layer count metadata")


# Fix local byte-lifetime and model-space handle order: group 5 often precedes group 2.
old = '    const targetBytes=targetModel.rawDXFBytes;'
new = '    let targetBytes=targetModel.rawDXFBytes;'
if s.count(old)!=1: raise SystemExit('Expected target byte reference not found exactly once')
s=s.replace(old,new,1)
old = '    droppedDXF=mergeProjectionDxfPreservingReference(targetBytes,additions);\n    targetModel=null;'
new = '    droppedDXF=mergeProjectionDxfPreservingReference(targetBytes,additions);\n    targetBytes=null;targetModel=null;'
if s.count(old)!=1: raise SystemExit('Expected target byte release point not found exactly once')
s=s.replace(old,new,1)
old = "let pos=0,pendingSection=false,currentSection='',pendingTable=false,tableStart=0,currentTable='',layerRow=false,blockRow=false,blockName='',pendingAcadVer=false,pendingHandseed=false;"
new = "let pos=0,pendingSection=false,currentSection='',pendingTable=false,tableStart=0,currentTable='',layerRow=false,blockRow=false,blockName='',blockHandle='',pendingAcadVer=false,pendingHandseed=false;"
if s.count(old)!=1: raise SystemExit('Scanner state declaration marker missing')
s=s.replace(old,new,1)
old = "else if(code==='0'&&up==='BLOCK_RECORD'){blockRow=true;blockName='';}\n   else if(code==='0'){blockRow=false;blockName='';}\n   else if(blockRow&&code==='2')blockName=value;\n   else if(blockRow&&code==='5'&&blockName.replace(/[\\s_-]/g,'').toUpperCase()==='*MODELSPACE'&&validHandle(value))result.modelSpaceHandle=value.toUpperCase();"
new = "else if(code==='0'&&up==='BLOCK_RECORD'){blockRow=true;blockName='';blockHandle='';}\n   else if(code==='0'){blockRow=false;blockName='';blockHandle='';}\n   else if(blockRow&&code==='2'){blockName=value;if(blockName.replace(/[\\s_-]/g,'').toUpperCase()==='*MODELSPACE'&&validHandle(blockHandle))result.modelSpaceHandle=blockHandle.toUpperCase();}\n   else if(blockRow&&code==='5'){blockHandle=value;if(blockName.replace(/[\\s_-]/g,'').toUpperCase()==='*MODELSPACE'&&validHandle(value))result.modelSpaceHandle=value.toUpperCase();}"
if s.count(old)!=1: raise SystemExit('Model-space handle scanner marker missing')
s=s.replace(old,new,1)
target=args.output or p
target.parent.mkdir(parents=True,exist_ok=True)
target.write_text(s,encoding='utf-8')
print(f'PASS: patched shared DWG reader and projection merge in {target}; {len(s)} characters')
