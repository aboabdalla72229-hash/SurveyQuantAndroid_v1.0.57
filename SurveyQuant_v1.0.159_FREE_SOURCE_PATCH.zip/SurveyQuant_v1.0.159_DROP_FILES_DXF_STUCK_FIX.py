#!/usr/bin/env python3
"""Repair SurveyQuant's drop-files flow with isolated, terminable DWG parsing."""
from __future__ import annotations
import argparse
from pathlib import Path

OLD_RESULTS = '<div class="results-box" id="dropFilesResults"><div id="dropFilesSummary" class="info-list"></div><button class="btn-orange" onclick="downloadDroppedDXF()">📐 استخراج DXF المدمج</button></div>'
NEW_RESULTS = '<div class="results-box" id="dropFilesResults" style="display:block"><div id="dropFilesSummary" class="info-list"></div><button id="downloadDroppedDXFButton" class="btn-orange" type="button" onclick="downloadDroppedDXF()" disabled style="opacity:.55;cursor:not-allowed">📐 استخراج لوحة DXF الناتجة (بعد نجاح الإسقاط)</button></div>'

NEW_PROJECTION_FUNCTION = r'''function sqBuildDwgWorkerSource(){
 const helpers=[p3,addCadEntity,textNumber,entityTextValue,sqPolylineIsClosed,vec,sqDwgRows,sqDwgType,sqDwgLayerName,sqDwgBlockRecords,sqDwgModelSpaceEntities,parseDWGDatabase,sqValidateDwgConversion].map(fn=>fn.toString()).join('\n');
 const workerBody=String.raw`
self.onmessage=async function(ev){
 const payload=ev.data||{};let lib=null;const sourceBytes=new Uint8Array(payload.buffer);
 let nativeModel=null,nativeReadError=null,dxfBytes=null,conversionError=null;
 try{
  const dwgSignature=new TextDecoder('latin1').decode(sourceBytes.subarray(0,6));
  if(sourceBytes.length<16)throw new Error('ملف DWG قصير أو تالف.');
  if(!/^(?:AC1004|AC1006|AC1009|AC1012|AC1014|AC1015|AC1018|AC1021|AC1024|AC1027|AC1032)$/.test(dwgSignature))throw new Error('ترويسة DWG غير معروفة أو إصدار غير مدعوم: '+dwgSignature);
  importScripts(payload.wasmScriptUrl,payload.engineScriptUrl);
  const mod=self.SurveyQuantLibreDwg;
  const LibreDwg=mod&&(mod.LibreDwg||mod.default?.LibreDwg);
  if(!LibreDwg||typeof LibreDwg.create!=='function')throw new Error('لم يتم تحميل واجهة محرك LibreDWG داخل عامل القراءة.');
  lib=await LibreDwg.create(payload.wasmBase);
  if(typeof lib.dwg_read_data==='function'&&typeof lib.convert==='function'){
   let dataPtr=0;
   try{
    const fileTypes=mod.Dwg_File_Type||mod.default?.Dwg_File_Type||{};
    dataPtr=lib.dwg_read_data(sourceBytes.buffer,fileTypes.DWG??0);
    if(!dataPtr)throw new Error('لم يُرجع القارئ الأصلي قاعدة DWG صالحة.');
    const db=lib.convert(dataPtr);
    if(!db||!db.tables)throw new Error('قاعدة DWG لا تحتوي على جداول CAD.');
    const m=parseDWGDatabase(db);
    if(!m||!Array.isArray(m.entities)||!m.entities.length)throw new Error('قراءة DWG الأصلية لم تُرجع عناصر CAD قابلة للاستخدام.');
    nativeModel={source:'DWG',entities:m.entities,layers:Array.from(m.layers.entries()),points:m.points,segments:m.segments,polylines:m.polylines,elevTexts:m.elevTexts};
   }catch(e){nativeReadError=String(e?.message||e);nativeModel=null;}
   finally{if(dataPtr&&typeof lib.dwg_free==='function'){try{lib.dwg_free(dataPtr);}catch(_){}}}
  }else nativeReadError='إصدار LibreDWG لا يدعم قراءة قاعدة DWG الأصلية.';
  try{
   if(typeof lib.dwg_write_dxf!=='function')throw new Error('محرك LibreDWG لا يحتوي على محول DXF.');
   dxfBytes=sqValidateDwgConversion(lib.dwg_write_dxf(sourceBytes.buffer));
  }catch(e){conversionError=String(e?.message||e);}
  if(!nativeModel&&!dxfBytes)throw new Error('تعذرت قراءة DWG وتحويله. القارئ: '+(nativeReadError||'غير متاح')+'؛ المحول: '+(conversionError||'غير متاح'));
  const result={nativeModel,sourceBuffer:sourceBytes.buffer,dxfBuffer:dxfBytes?dxfBytes.buffer:null,nativeReadError:nativeReadError?String(nativeReadError):'',conversionError:conversionError?String(conversionError):''};
  const transfers=[sourceBytes.buffer];if(dxfBytes&&dxfBytes.buffer!==sourceBytes.buffer)transfers.push(dxfBytes.buffer);
  self.postMessage({ok:true,result},transfers);
 }catch(e){self.postMessage({ok:false,error:String(e?.message||e||'DWG worker failed')});}
};`;
 return helpers+'\n'+workerBody;
}
async function sqParseDwgProjectionInWorker(file,label,timeoutMs=90000){
 if(typeof Worker!=='function'||typeof Blob!=='function'||!URL.createObjectURL)throw new Error('بيئة Android WebView لا تدعم عامل القراءة المعزول؛ لم نبدأ قراءة DWG على الواجهة الرئيسية. حدّث Android System WebView ثم أعد المحاولة.');
 const buffer=await file.arrayBuffer();
 const wasmScriptUrl=new URL(SQ_WRITER_WASM_URL,document.baseURI).href;
 const engineScriptUrl=new URL(SQ_WRITER_ENGINE_URL,document.baseURI).href;
 const wasmBase=sqDwgWasmRuntimePath();
 const blobUrl=URL.createObjectURL(new Blob([sqBuildDwgWorkerSource()],{type:'text/javascript'}));
 return await new Promise((resolve,reject)=>{
  let settled=false;
  const worker=new Worker(blobUrl);
  const finish=(fn,value)=>{if(settled)return;settled=true;clearTimeout(timer);worker.terminate();URL.revokeObjectURL(blobUrl);fn(value);};
  const timer=setTimeout(()=>finish(reject,new Error('انتهت مهلة قراءة '+label+' بعد '+Math.round(timeoutMs/1000)+' ثانية. تم إيقاف عامل DWG فعليًا حتى لا يظل عالقًا. جرّب لوحة أصغر أو تحقق من سلامة الملف وإصدار DWG.')),timeoutMs);
  worker.onmessage=(event)=>{
   const msg=event.data||{};
   if(!msg.ok)return finish(reject,new Error('تعذرت قراءة '+label+': '+(msg.error||'خطأ غير معروف داخل عامل DWG.')));
   try{
    const r=msg.result||{};let model=null;
    if(r.nativeModel){model={...r.nativeModel,layers:new Map(r.nativeModel.layers||[])};}
    let rawDXFBytes=r.dxfBuffer?new Uint8Array(r.dxfBuffer):null;
    if(!model&&rawDXFBytes){let lastErr=null;for(const enc of ['utf-8','windows-1252']){try{const candidate=parseDXF(new TextDecoder(enc,{fatal:false}).decode(rawDXFBytes));if(candidate&&(candidate.entities?.length||candidate.points?.length||candidate.segments?.length||candidate.polylines?.length)){model=candidate;break;}lastErr=new Error('تم تحويل DWG إلى DXF لكن لم يعثر القارئ على كيانات CAD.');}catch(e){lastErr=e;}}if(!model)throw lastErr||new Error('تعذر تحليل DXF المحول من DWG.');}
    if(!model)throw new Error('لم ينتج محرك DWG عناصر قابلة للاستخدام.');
    model.source='DWG';model.convertedFromDWG=!!rawDXFBytes;model.sourceName=file.name;model.rawDWGBytes=new Uint8Array(r.sourceBuffer);model.rawDXFBytes=rawDXFBytes;
    if(r.nativeReadError)model.nativeDwgReadWarning=String(r.nativeReadError);
    if(r.conversionError)model.dwgConversionError=String(r.conversionError);
    finish(resolve,model);
   }catch(e){finish(reject,e instanceof Error?e:new Error(String(e)));}
  };
  worker.onerror=(event)=>finish(reject,new Error('توقف عامل قراءة '+label+': '+(event.message||'خطأ في تشغيل Worker/WASM.')));
  worker.onmessageerror=()=>finish(reject,new Error('تعذر استلام نتيجة قراءة DWG من العامل المعزول.'));
  worker.postMessage({buffer,wasmScriptUrl,engineScriptUrl,wasmBase},[buffer]);
 });
}
async function sqParseProjectionFileWithTimeout(file,label,timeoutMs=90000){
 const ext=String(file?.name||'').toLowerCase().split('.').pop();
 if(ext==='dwg')return sqParseDwgProjectionInWorker(file,label,timeoutMs);
 let timer=null;
 const readPromise=Promise.resolve().then(()=>parseFile(file));
 const timeoutPromise=new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('تجاوزت قراءة '+label+' مهلة '+Math.round(timeoutMs/1000)+' ثانية.')),timeoutMs);});
 try{return await Promise.race([readPromise,timeoutPromise]);}finally{if(timer!==null)clearTimeout(timer);}
}
async function dropFilesMerge(){
 const progress=document.getElementById('dropFilesProgress');
 const results=document.getElementById('dropFilesResults');
 const summary=document.getElementById('dropFilesSummary');
 const exportButton=document.getElementById('downloadDroppedDXFButton');
 const setProgress=(message)=>{if(progress){progress.style.display='block';progress.textContent=message;}};
 const setExportReady=(ready)=>{if(exportButton){exportButton.disabled=!ready;exportButton.style.opacity=ready?'1':'.55';exportButton.style.cursor=ready?'pointer':'not-allowed';exportButton.textContent=ready?'📐 استخراج لوحة DXF الناتجة':'📐 استخراج لوحة DXF الناتجة (بعد نجاح الإسقاط)';}};
 const src=document.getElementById('dropSurveyFiles')?.files?.[0],cad=document.getElementById('dropCadFile')?.files?.[0];
 droppedDXF='';setExportReady(false);if(results)results.style.display='block';if(summary)summary.textContent='';
 if(!src||!cad){setProgress('⚠️ اختر الملف الأول واللوحة المرجعية قبل بدء الإسقاط.');return alert('اختر الملف المراد إسقاطه في الخانة الأولى واللوحة المرجعية في الخانة الثانية.');}
 try{
  setProgress('⏳ جاري قراءة الملف الأول: '+src.name);
  await new Promise(r=>setTimeout(r,30));
  const sourceModel=await sqParseProjectionFileWithTimeout(src,'الملف الأول');
  if(!sourceModel||!Array.isArray(sourceModel.entities))throw new Error('لم يُرجع الملف الأول عناصر قابلة للإسقاط.');
  setProgress('✅ تمت قراءة الملف الأول. ⏳ جاري قراءة اللوحة المرجعية: '+cad.name);
  await new Promise(r=>setTimeout(r,30));
  const targetModel=await sqParseProjectionFileWithTimeout(cad,'اللوحة المرجعية');
  if(!targetModel||!['DXF','DWG'].includes(String(targetModel.source).toUpperCase()))throw new Error('الخانة الثانية يجب أن تكون لوحة DXF أو DWG.');
  if(!Array.isArray(targetModel.entities)||!targetModel.entities.length)throw new Error('تم فتح الملف المرجعي لكن لم تُقرأ منه عناصر CAD قابلة للاستخدام.');
  const additions=[],entities=[...(targetModel.entities||[])];let addedPoints=0,addedCad=0;
  if(Array.isArray(sourceModel.points)&&sourceModel.points.length){const ps=getPointStyleSettings();for(const p of sourceModel.points){addPointDetailEntities(additions,{e:Number(p.e),n:Number(p.n),z:Number(p.z||0),id:p.id||('P'+(addedPoints+1))},ps);addedPoints++;}}
  if(sourceModel.entities?.length){if(!sourceModel.points?.length||sourceModel.source==='DXF'||sourceModel.source==='DWG'){for(const e of sourceModel.entities){additions.push(e);addedCad++;}}}
  entities.push(...additions);
  if(!entities.length)throw new Error('لم يتم العثور على عناصر قابلة للإسقاط.');
  setProgress('⏳ تمت قراءة اللوحة المرجعية. جاري إعداد ملف DXF مع الحفاظ على العناصر الأصلية...');
  await new Promise(r=>setTimeout(r,20));
  if(targetModel.rawDXFBytes instanceof Uint8Array){
    droppedDXF=mergeProjectionDxfPreservingReference(targetModel.rawDXFBytes,additions);
    const checkText=new TextDecoder('windows-1252').decode(droppedDXF);
    const validationIssue=inspectPreservedReferenceDXF(checkText);if(validationIssue)throw new Error(validationIssue+' تم إيقاف التصدير لحماية تفاصيل اللوحة المرجعية.');
  }else{
    droppedDXF=buildR12FromEntities(entities,{preserveEntityColors:true});
    if(!validateGeneratedDXF(droppedDXF))throw new Error('تعذر إنشاء DXF صالح من اللوحة المرجعية.');
  }
  if(!(droppedDXF instanceof Uint8Array)&&!(typeof droppedDXF==='string'&&droppedDXF.length))throw new Error('لم ينتج عن الإسقاط ملف DXF قابل للتنزيل.');
  if(summary)summary.innerHTML='تم إسقاط <b>'+escapeHtml(src.name)+'</b> على <b>'+escapeHtml(cad.name)+'</b>.<br>عناصر اللوحة المرجعية: <b>'+(targetModel.entities?.length||0)+'</b> | عناصر الملف الأول: <b>'+addedCad+'</b> | نقاط مضافة بالتفاصيل: <b>'+addedPoints+'</b>.<br><span class="muted">'+(String(targetModel.source).toUpperCase()==='DXF'?'تم الحفاظ على بايتات وعناصر وخصائص اللوحة المرجعية الأصلية كما هي؛ أُضيفت العناصر الجديدة فقط دون إعادة رسم عناصر المرجع.':'تم استخدام DXF الناتج من تحويل DWG كأساس للإضافة؛ قد توجد قيود تحويل على بعض الكيانات الخاصة. لا يمكن أن تكون نتيجة DXF نسخة ثنائية مطابقة لملف DWG.')+'<br>الإحداثيات ثابتة: X = Easting (E) وY = Northing (N)، دون تبديل.</span>';
  if(results)results.style.display='block';setExportReady(true);setProgress('✅ اكتمل الإسقاط وتم تجهيز ملف DXF. اضغط زر «استخراج لوحة DXF الناتجة» للحفظ.');
 }catch(e){
  droppedDXF='';setExportReady(false);const message=String(e?.message||e||'خطأ غير معروف');
  if(summary)summary.innerHTML='<b>تعذر تجهيز لوحة DXF.</b><br>'+escapeHtml(message);
  if(results)results.style.display='block';setProgress('❌ فشل الإسقاط: '+message);
  console.error('dropFilesMerge',e);alert('تعذر إسقاط الملف على اللوحة: '+message);
 }
}
'''

OLD_RESET = "card.querySelectorAll('.results-box,.cad-panel:not(.project-output-settings),.info-list[id$=\"Summary\"],.info-list[id$=\"Status\"]').forEach(e=>{if(e.id!=='quantResults')e.style.display='none';});"
NEW_RESET = "card.querySelectorAll('.results-box,.cad-panel:not(.project-output-settings),.info-list[id$=\"Summary\"],.info-list[id$=\"Status\"]').forEach(e=>{if(e.id!=='quantResults'&&e.id!=='dropFilesResults')e.style.display='none';});if(card.id==='dropFilesCard'){const db=document.getElementById('downloadDroppedDXFButton'),rs=document.getElementById('dropFilesResults'),sm=document.getElementById('dropFilesSummary'),pr=document.getElementById('dropFilesProgress');if(rs)rs.style.display='block';if(sm)sm.textContent='';if(pr){pr.style.display='none';pr.textContent='⏳ جاري قراءة اللوحتين ومعالجة الإسقاط...';}if(db){db.disabled=true;db.style.opacity='.55';db.style.cursor='not-allowed';db.textContent='📐 استخراج لوحة DXF الناتجة (بعد نجاح الإسقاط)';}}"


def replace_once(src: str, old: str, new: str, label: str) -> str:
    count = src.count(old)
    if count != 1:
        raise ValueError(f'{label}: expected exactly one match, found {count}')
    return src.replace(old, new, 1)


def validate_html(src: str, patched: bool = False) -> None:
    if patched:
        checks = {
            'always visible results box': 'id="dropFilesResults" style="display:block"',
            'disabled until successful export': 'id="downloadDroppedDXFButton" class="btn-orange" type="button"',
            'DWG parsing runs in Web Worker': 'async function sqParseDwgProjectionInWorker(file,label,timeoutMs=90000)',
            'worker is actively terminated on timeout': 'worker.terminate();URL.revokeObjectURL(blobUrl)',
            'worker timeout is tied to projection reader': "if(ext==='dwg')return sqParseDwgProjectionInWorker(file,label,timeoutMs)",
            'visible failure status': "setProgress('❌ فشل الإسقاط: '+message)",
            'export enabled only after DXF validation': 'setExportReady(true);setProgress(\'✅ اكتمل الإسقاط',
            'project reset preserves export control': "e.id!=='quantResults'&&e.id!=='dropFilesResults'",
        }
        for label, marker in checks.items():
            if marker not in src: raise ValueError(f'Validation failed: {label} missing')
        if 'sqParseProjectionFileWithTimeout(file,label,timeoutMs=90000){\n let timer=null;\n const readPromise=Promise.resolve().then(()=>parseFile(file));' in src:
            raise ValueError('Old timeout-only DWG parser remains')
    else:
        if OLD_RESULTS not in src: raise ValueError('Expected V158 hidden result button is not present')
        if 'async function dropFilesMerge(){' not in src: raise ValueError('Projection function missing')
        if 'function resetProjectInputs(card){' not in src: raise ValueError('Project reset function missing')


def patch_html(src: str) -> str:
    for marker in ('async function dropFilesMerge(){', '\nfunction downloadDroppedDXF(){', 'function resetProjectInputs(card){', OLD_RESULTS):
        if marker not in src: raise ValueError(f'Missing required V158 marker: {marker[:70]}')
    if 'downloadDroppedDXFButton' in src or 'sqParseDwgProjectionInWorker' in src:
        raise ValueError('The drop-files repair already appears to be installed; refusing a duplicate patch.')
    out = replace_once(src, OLD_RESULTS, NEW_RESULTS, 'always-visible DXF export button')
    start = out.index('async function dropFilesMerge(){')
    end = out.index('\nfunction downloadDroppedDXF(){', start)
    out = out[:start] + NEW_PROJECTION_FUNCTION.rstrip() + out[end:]
    out = replace_once(out, OLD_RESET, NEW_RESET, 'drop-files project reset')
    validate_html(out, patched=True)
    return out


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--html', required=True, type=Path)
    p.add_argument('--output', type=Path)
    p.add_argument('--check-only', action='store_true')
    a = p.parse_args()
    src = a.html.read_text(encoding='utf-8')
    if a.check_only:
        validate_html(src, patched=True)
        print('PASS: worker-isolated DWG parsing, actively terminable timeout, visible DXF export control, visible error/success state, and reset behavior validated')
        return
    result = patch_html(src)
    target = a.output or a.html
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(result, encoding='utf-8')
    print(f'PASS: repaired drop-files flow using terminable DWG Web Worker; wrote {target} ({len(result)} characters)')

if __name__ == '__main__': main()
