#!/usr/bin/env python3
"""Patch V163 app with a native filename/save dialog and axis-label-aware CAD preview."""
from __future__ import annotations
import argparse, base64, re
from pathlib import Path

CHOOSER = r'''function chooseDownloadFilename(original){
 return new Promise(resolve=>{
  const doc=document;const old=doc.getElementById('sqDownloadNameDialog');if(old)old.remove();
  const source=String(original||'SurveyQuant_Output.bin');const match=source.match(/\.([a-z0-9]+)$/i),ext=match?'.'+match[1]:'';
  const base=ext?source.slice(0,-ext.length):source;
  const overlay=doc.createElement('div');overlay.id='sqDownloadNameDialog';
  overlay.style.cssText='position:fixed;inset:0;z-index:2147483600;background:rgba(0,0,0,.68);display:flex;align-items:center;justify-content:center;padding:18px;direction:rtl;font-family:system-ui,sans-serif;';
  const panel=doc.createElement('div');panel.style.cssText='width:min(100%,420px);background:#fff;color:#182536;border-radius:18px;padding:20px;box-shadow:0 18px 60px rgba(0,0,0,.4);';
  const title=doc.createElement('div');title.textContent='اسم لوحة الإخراج';title.style.cssText='font-size:20px;font-weight:800;margin-bottom:8px;text-align:right;';
  const note=doc.createElement('div');note.textContent='اكتب اسم الملف قبل الحفظ. سيتم حفظه داخل مجلد Downloads/SurveyQuant.';note.style.cssText='font-size:14px;line-height:1.7;color:#536272;margin-bottom:14px;';
  const label=doc.createElement('label');label.textContent='اسم الملف';label.style.cssText='display:block;font-size:14px;font-weight:700;margin-bottom:6px;';
  const input=doc.createElement('input');input.type='text';input.autocomplete='off';input.spellcheck=false;input.value=base;input.style.cssText='width:100%;box-sizing:border-box;border:2px solid #cbd5df;border-radius:10px;background:#f8fafc;color:#152333;padding:13px;font-size:17px;direction:ltr;text-align:left;';
  const suffix=doc.createElement('div');suffix.textContent=ext||'سيتم تحديد الامتداد تلقائيًا';suffix.style.cssText='font-size:12px;color:#64748b;margin-top:6px;direction:ltr;text-align:left;';
  const actions=doc.createElement('div');actions.style.cssText='display:flex;gap:10px;margin-top:18px;';
  const cancel=doc.createElement('button');cancel.type='button';cancel.textContent='إلغاء';cancel.style.cssText='flex:1;border:0;border-radius:10px;padding:13px;background:#e9eef4;color:#253342;font-weight:800;font-size:15px;';
  const save=doc.createElement('button');save.type='button';save.textContent='حفظ وتنزيل';save.style.cssText='flex:1;border:0;border-radius:10px;padding:13px;background:#1764aa;color:#fff;font-weight:800;font-size:15px;';
  actions.append(cancel,save);panel.append(title,note,label,input,suffix,actions);overlay.appendChild(panel);doc.body.appendChild(overlay);
  let finished=false;
  const finish=value=>{if(finished)return;finished=true;doc.removeEventListener('keydown',onKey);overlay.remove();resolve(value);};
  const sanitize=value=>String(value||'').trim().replace(/[\\/:*?"<>|\u0000-\u001f\u007f]/g,'_');
  const accept=()=>{let name=sanitize(input.value)||sanitize(base)||'SurveyQuant_Output';if(ext&&!name.toLowerCase().endsWith(ext.toLowerCase()))name+=ext;finish(name);};
  const onKey=e=>{if(e.key==='Escape'){e.preventDefault();finish(null);}else if(e.key==='Enter'){e.preventDefault();accept();}};
  cancel.addEventListener('click',()=>finish(null));save.addEventListener('click',accept);overlay.addEventListener('click',e=>{if(e.target===overlay)finish(null);});doc.addEventListener('keydown',onKey);
  setTimeout(()=>{try{input.focus();input.select();}catch(_){ }},30);
 });
}'''


def patch_app(html: str) -> str:
    if 'sq164-cad-output-axis-fix' in html:
        raise ValueError('V164 patch already applied; refusing duplicate injection.')
    for marker in ('sq163-runtime-bootstrap','sq163-pdfjs-worker','sq163-cad-engine','sq163RawCadOverlayMerge','function safeDownloadFile('):
        if marker not in html: raise ValueError(f'Missing V163 app marker: {marker}')
    start=html.find('function chooseDownloadFilename(original){')
    end=html.find('\nasync function safeDownloadFile(',start)
    if start<0 or end<=start: raise ValueError('Could not locate V163 filename chooser.')
    html=html[:start]+CHOOSER+html[end:]
    old="const requestedName=chooseDownloadFilename(filename||'SurveyQuant_Output.bin');"
    if html.count(old)!=1: raise ValueError('Expected exactly one V163 safeDownloadFile filename call.')
    html=html.replace(old,"const requestedName=await chooseDownloadFilename(filename||'SurveyQuant_Output.bin');",1)
    html=html.replace("if(window.Android.notifyDownload) window.Android.notifyDownload(finalName,String(result),mime);", "if(window.Android.notifyDownload){try{window.Android.notifyDownload(finalName,String(result),mime);}catch(notifyError){console.warn('Download notification failed after successful save',notifyError);}}",1)
    html=html.replace("if(String(result).startsWith('ERROR:') && window.Android.startChunkedFile){", "if(/^ERROR(?:[: ]|$)/i.test(String(result)) && window.Android.startChunkedFile){",1)
    html=html.replace("if(String(result).startsWith('ERROR:')) throw new Error(result);", "if(/^ERROR(?:[: ]|$)/i.test(String(result))) throw new Error(result);",1)
    html=html.replace("showDownloadStatus('تم التنزيل: '+finalName,true);return url;", "showDownloadStatus('تم التنزيل: '+finalName+' • راجع مجلد التنزيلات',true);return url;",1)
    meta='<meta name="surveyquant-v164" content="sq164-cad-output-axis-fix">'
    head=re.search(r'<head\b[^>]*>',html,re.I)
    if not head: raise ValueError('HTML head tag not found')
    html=html[:head.end()]+meta+html[head.end():]
    return html


def embed_engine(html: str, engine: bytes) -> str:
    pattern=r'(<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">)([A-Za-z0-9+/=\r\n]+)(</script>)'
    payload=base64.b64encode(engine).decode('ascii')
    html,n=re.subn(pattern,lambda m:m.group(1)+payload+m.group(3),html,count=1,flags=re.I)
    if n!=1: raise ValueError(f'Expected one embedded V163 CAD engine payload, found {n}')
    return html


def validate(html: str, engine: bytes) -> None:
    required=['sq164-cad-output-axis-fix','function chooseDownloadFilename(original){\n return new Promise(resolve=>{',
      'const requestedName=await chooseDownloadFilename(','window.Android.saveFile(finalName,mime,base64)',
      'window.Android.notifyDownload(finalName,String(result),mime)','sq163RawCadOverlayMerge','sq163-pdfjs-worker']
    for marker in required:
        if marker not in html: raise ValueError('V164 HTML validation failed: '+marker)
    if "window.prompt('اكتب اسم اللوحة / الملف المخرج:" in html: raise ValueError('Legacy output prompt remains')
    m=re.search(r'<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">([A-Za-z0-9+/=\r\n]+)</script>',html,re.I)
    if not m: raise ValueError('Embedded CAD engine script is missing')
    if base64.b64decode(m.group(1))!=engine: raise ValueError('Embedded CAD engine bytes do not match the tested V164 engine')
    e=engine.decode('utf-8')
    for marker in ('SQ_V164_AXIS_LABELS_AND_SAVE','root.safeDownloadFile(bytes, filename, mime, false)','for (const label of (geom.texts || []).slice(0, 6000))','block.geometry.texts||[]'):
        if marker not in e: raise ValueError('V164 engine validation failed: '+marker)


def main():
    p=argparse.ArgumentParser();p.add_argument('--html',required=True,type=Path);p.add_argument('--engine',required=True,type=Path);p.add_argument('--check-only',action='store_true');a=p.parse_args()
    html=a.html.read_text(encoding='utf-8');engine=a.engine.read_bytes()
    if a.check_only:
        validate(html,engine);print('PASS V164 patch validation: named native saving, notification, exact engine embed, and axis label preview.');return
    html=embed_engine(patch_app(html),engine);validate(html,engine);a.html.write_text(html,encoding='utf-8')
    print(f'PASS V164 patch applied: {a.html} ({len(html):,} chars; engine {len(engine):,} bytes)')

if __name__=='__main__': main()
