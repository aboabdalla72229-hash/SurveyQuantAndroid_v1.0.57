'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const htmlPath = process.argv[2];
const referencePath = process.argv[3];
assert(htmlPath && referencePath, 'usage: node SurveyQuant_v1.0.140_V127_SESSION_REGRESSION_TEST.js CURRENT_INDEX.HTML V127_INDEX.HTML');
const html = fs.readFileSync(htmlPath, 'utf8');
const reference = fs.readFileSync(referencePath, 'utf8');
const moduleIds = [
  'sq-orientation-module',
  'sq-orientation-axis-reader-module',
  'sq-orientation-manual-points-module',
  'sq-orientation-reference-board-module',
  'sq-orientation-dxf-faithful-recovery-module',
  'sq-orientation-cad-preserve-module',
  'sq-orientation-v115-tools-module'
];
function body(text, id) {
  const re = new RegExp(`(<script\\b(?=[^>]*\\bid=["']${id}["'])[^>]*>)([\\s\\S]*?)(<\\/script\\s*>)`, 'i');
  const m = text.match(re);
  assert(m, `script ${id} missing`);
  assert.equal((text.match(new RegExp(`id=["']${id}["']`, 'g')) || []).length, 1, `script ${id} must be unique`);
  return m[2];
}
for (const id of moduleIds) {
  assert.equal(body(html, id), body(reference, id), `orientation module ${id} must remain byte-for-byte identical to V127`);
}
assert(html.includes('const SQ_APP_VERSION_CODE = 140;'), 'app version must be code 140');
assert(html.includes('id="sq-v117-universal-dwg-bridge"'), 'latest universal DWG bridge must remain embedded');
assert(html.includes('function sqDwgWasmRuntimePath()'), 'latest WASM URL helper must remain embedded');
assert(html.includes('id="surveyquant-v140-fresh-board-session"'), 'fresh-session lifecycle guard must be installed');
assert(!html.includes('id="surveyquant-v134-session-reset"'), 'legacy broad storage reset must be replaced');

function makeHarness({picker = false} = {}) {
  let fakeNow = 0;
  class TestDate extends Date { static now() { return fakeNow; } }
  const advance = ms => { fakeNow += ms; };
  const listeners = Object.create(null);
  const windowListeners = Object.create(null);
  const values = new Map([
    ['surveyquant.projectOutputSettings.v2', '{"project1Card":{"lineColor":"#123456"}}'],
    ['sq_device_id', 'SQ-device-preserved'],
    ['sq_access_until', '2099-01-01T00:00:00.000Z'],
    ['old_dwg_blob', 'previous-drawing-data'],
    ['lastOpenedBoard', 'previous-board-name']
  ]);
  const storage = {
    get length() { return values.size; },
    key(i) { return Array.from(values.keys())[i] ?? null; },
    getItem(k) { return values.has(k) ? values.get(k) : null; },
    setItem(k,v) { values.set(k, String(v)); },
    removeItem(k) { values.delete(k); },
    clear() { values.clear(); }
  };
  const session = {cleared:0, clear(){this.cleared++;}};
  const deletedDbs = [];
  const idb = {databases(){return Promise.resolve([{name:'SurveyQuantCAD'}, {name:'other'}]);},deleteDatabase(name){deletedDbs.push(name);}};
  const doc = {visibilityState:'visible',body:{classList:{contains(){return false;}}},addEventListener(name,fn){(listeners[name] ||= []).push(fn);}};
  const win = {localStorage:storage,sessionStorage:session,indexedDB:idb,location:{reloadCount:0,reload(){this.reloadCount++;}},addEventListener(name,fn){(windowListeners[name] ||= []).push(fn);}};
  const ctx = {window:win,document:doc,Date:TestDate,RegExp,String,Number,Array,Object,Promise,Math,console};
  vm.createContext(ctx);
  vm.runInContext(body(html,'surveyquant-v140-fresh-board-session'),ctx,{filename:'surveyquant-v140-fresh-board-session.js'});
  function fire(name,event={}) { for (const fn of listeners[name]||[]) fn(event); }
  function visibility(state) { doc.visibilityState=state; fire('visibilitychange'); }
  return {listeners,windowListeners,values,storage,session,deletedDbs,doc,win,fire,visibility,advance};
}
(async()=>{
  const normal=makeHarness();
  await Promise.resolve();
  assert.equal(normal.values.has('old_dwg_blob'),false,'board-shaped localStorage values must be removed');
  assert.equal(normal.values.has('lastOpenedBoard'),false,'last opened board state must be removed');
  assert.equal(normal.values.get('surveyquant.projectOutputSettings.v2')?.includes('#123456'),true,'output settings must survive session reset');
  assert.equal(normal.values.get('sq_device_id'),'SQ-device-preserved','device identity must survive session reset');
  assert.equal(normal.values.has('sq_access_until'),true,'access/payment state must survive session reset');
  assert.equal(normal.session.cleared,1,'sessionStorage must be cleared on startup');
  normal.advance(1000); normal.visibility('hidden'); normal.advance(2000); normal.visibility('visible');
  assert.equal(normal.win.location.reloadCount,1,'returning from background must reload WebView to drop in-memory drawings');

  const blurFallback=makeHarness();
  blurFallback.advance(1000);
  for (const fn of blurFallback.windowListeners.blur || []) fn();
  blurFallback.advance(2000);
  for (const fn of blurFallback.windowListeners.focus || []) fn();
  assert.equal(blurFallback.win.location.reloadCount,1,'blur/focus fallback must reload even if visibilitychange is missing');

  const picker=makeHarness({picker:true});
  picker.advance(1000); picker.fire('click',{target:{closest(){return {type:'file',matches(){return true;}};}}});
  picker.advance(100); picker.visibility('hidden');
  // Android can deliver input.change before it reports the WebView as visible again.
  picker.fire('change',{target:{type:'file',matches(){return true;}}});
  picker.advance(800); picker.visibility('visible');
  assert.equal(picker.win.location.reloadCount,0,'file chooser return must not reload even if change fires before visibilitychange');
  picker.advance(100); picker.visibility('hidden'); picker.advance(800); picker.visibility('visible');
  assert.equal(picker.win.location.reloadCount,1,'the next ordinary return must reload a clean WebView');
  console.log('PASS V140: 7 orientation modules are byte-identical to V127.');
  console.log('PASS V140: latest all-project DWG bridge and WASM helper are preserved.');
  console.log('PASS V140: stale drawing cache/session values are cleared while app settings and device/access keys remain.');
  console.log('PASS V140: visibilitychange and blur/focus background re-entry reset in-memory drawings; file chooser return is protected.')
})().catch(e=>{console.error(e);process.exitCode=1;});
