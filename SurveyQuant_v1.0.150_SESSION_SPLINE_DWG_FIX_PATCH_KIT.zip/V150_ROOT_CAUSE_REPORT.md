# SurveyQuant V1.0.150 Root-Cause Report

## Root causes fixed

1. **Selection and preview leakage:** replacing a board did not first clear the canvas and board state. If parsing failed or asynchronous reads completed out of order, an old selection/preview could remain visible. A per-side load serial now invalidates old results; both success and failure paths cannot restore an earlier drawing; prior point picks, selection, undo/redo, ID Point, layer panel and canvas handlers are reset.
2. **Inconsistent DWG reader in Alignment:** orientation had its own conversion hook which did not match the app's main DWG path. The orientation project now routes `.dwg` through the shared `parseFile`/LibreDWG-to-DXF path and validates that real DXF bytes and entities came back.
3. **Bent/fake SPLINE geometry:** the main low-detail CAD preview can connect SPLINE control points as straight chords. The new spline sampler computes the rational B-spline using degree, knots and weights; if knot data are unusable it uses fit points, and if fit points are absent it retains only isolated snap anchors rather than drawing invented segments. Any SPLINE in model space or nested INSERT blocks forces the geometry-aware fallback even when the entity's OCS normal is canonical +Z.
4. **Overlarge phone preview:** orientation canvases use 34vh with 200-360px limits.

## Alignment semantics

The transform is a 2D similarity transform calculated from source point 1/2 and reference point 1/2, with uniform scale, rotation and translation. Both selected source points are checked against their corresponding reference points. It does not force unrelated transformed coordinates to positive values, because clamping them would violate exact alignment. Negative coordinates are legitimate when the reference coordinate system uses them.

## Tests executed locally

- The WCS preview test passed for +Z, -Z and tilted OCS bases; INSERT base point/scale/rotation; and nested axis labels.
- The session/SPLINE/DWG test passed for actual rational spline evaluation, fit-point fallback, absence of fake control chords, negative-source to positive-reference two-point mapping with residual below 1e-8, reset behavior, load failure/async race handling, and the shared DWG parser route.
- All 8 inherited V148/V130 regression suites passed, including HATCH output, 24,000-entity DXF memory stability, axis labels, MLEADER, 3D/OCS, concrete closed outlines and DWG converter bridge checks.
- All 10 inline JavaScript blocks passed `node --check`.
- The patched HTML was injected into a real V149 APK container; the package helper verified versionName 1.0.150/versionCode 150 and that the local DWG WASM assets remain. That local test APK is unsigned.

## Limitations

The original user DWG/DXF was not attached, so the actual field drawing was not replayed. DWG selection was tested through the common reader with a controlled parser stub plus inherited DWG/WASM regression checks. The signed release APK requires the GitHub Actions workflow to run with the repository's signing secrets. No claim is made that every opaque Proxy/Civil 3D object is losslessly convertible through DXF.
