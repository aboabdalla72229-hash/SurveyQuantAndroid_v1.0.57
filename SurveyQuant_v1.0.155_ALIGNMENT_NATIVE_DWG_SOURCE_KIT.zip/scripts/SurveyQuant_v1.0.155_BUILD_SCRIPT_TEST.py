#!/usr/bin/env python3
"""Static and regression checks for the V155 LibreDWG build script."""
from pathlib import Path
import json
import subprocess
import sys
import tempfile

p = Path(__file__).with_name('SurveyQuant_v1.0.155_BUILD_LIBREDWG.sh')
s = p.read_text(encoding='utf-8')
checks = {
    'pinned upstream release': 'v0.8.2' in s,
    'writer enabled (upstream disable removed)': "cmd=cmd.replace(' --disable-write','',1)" in s,
    'DXF support enabled': '--enable-dxf' in s,
    'real DWG corpus test executed': 'node --test test/surveyquant-dwg-corpus.test.mjs' in s,
    'six regression generations': 'SurveyQuant_v1.0.155_DWG_CORPUS_TEST.mjs' in s,
    'fresh compiled WASM copied': 'libredwg-web.wasm' in s and 'libredwg-web.js' in s,
    'classic UMD wrapper retained': 'LEGACY_WRAPPER' in s and 'SurveyQuantLibreDwg' in s,
    'classic webview loader generated': "c.replace(' -s EXPORT_ES6=1',' -s EXPORT_ES6=0',1)" in s,
    'fails if corpus tests absent': "ERROR: SurveyQuant DWG corpus test missing" in s,
    'safe guard split replaces old range deletion': 'Split the upstream DEBUG_CLASSES/IS_FREE guard around ONLY ARCALIGNEDTEXT.' in s and 'spec=spec[:start]+spec[start:ix]' not in s,
    'whole-file preprocessor balance checks exist': 'Patched dwg2.spec has unmatched #endif' in s and 'Patched dwg2.spec has unclosed preprocessor directives' in s,
    'named MainModule declaration fixes TS2614': 'export interface MainModule' in s and 'export { MainModule };' in s,
    'generated wrapper limits only implicit-any checking': "opts['noImplicitAny']=False" in s,
    'tsconfig JSONC comments safely stripped': 'strip_jsonc_comments' in s and 'tsconfig_text=re.sub' in s,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + label)
if not all(checks.values()):
    sys.exit(1)

# Execute the actual embedded patch against an upstream-shaped synthetic fixture.
# This catches accidental deletion of schemas and unbalanced closing directives.
with tempfile.TemporaryDirectory(prefix='sq155-guard-test-') as temp:
    root = Path(temp)
    cwd = root / 'bindings' / 'javascript'
    src = root / 'src'
    cwd.mkdir(parents=True)
    src.mkdir(parents=True)
    package = {
        'scripts': {
            'build:prepare': 'cd ../../build-wasm && emconfigure ../configure --enable-release --enable-debug --disable-write --disable-dxf',
            'build:obj': 'cd ../../build-wasm && emmake make',
            'build:wasm': 'cd ../../build-wasm && emcc -s EXPORT_ES6=0 --emit-tsd libredwg-web.d.ts',
        }
    }
    (cwd / 'package.json').write_text(json.dumps(package), encoding='utf-8')
    (cwd / 'tsconfig.json').write_text('{\n  \"compilerOptions\": {\n    /* Linting */\n    \"strict\": true\n  }\n}\n', encoding='utf-8')
    (src / 'classes.inc').write_text('DEBUGGING_CLASS (ACTION, ARCALIGNEDTEXT)\n', encoding='utf-8')
    fixture = (
        'DWG_ENTITY (PRE_GUARD)\nDWG_ENTITY_END\n\n'
        '#if defined (DEBUG_CLASSES) || defined (IS_FREE)\n'
        'DWG_OBJECT (KEEP_BEFORE)\nDWG_OBJECT_END\n'
        'DWG_ENTITY (ARCALIGNEDTEXT)\nDXF { FIELD_T (text_value, 1); }\nDWG_ENTITY_END\n'
        'DWG_OBJECT (KEEP_AFTER)\nDWG_OBJECT_END\n'
        '#endif /* DEBUG_CLASSES || IS_FREE */\n'
    )
    (src / 'dwg2.spec').write_text(fixture, encoding='utf-8')
    marker = "python3 - <<'PY'\n"
    body_start = s.index(marker) + len(marker)
    body_end = s.index('\nPY\npnpm install --frozen-lockfile', body_start)
    body = s[body_start:body_end]
    run = subprocess.run([sys.executable, '-c', body], cwd=cwd, text=True, capture_output=True)
    if run.returncode:
        print('FAIL: embedded DWG schema patch fixture\n' + run.stdout + run.stderr)
        sys.exit(1)
    patched = (src / 'dwg2.spec').read_text(encoding='utf-8')
    if 'DWG_OBJECT (KEEP_BEFORE)' not in patched or 'DWG_OBJECT (KEEP_AFTER)' not in patched:
        print('FAIL: patched source dropped a neighbouring schema')
        sys.exit(1)
    if patched.count('DWG_ENTITY (ARCALIGNEDTEXT)') != 1:
        print('FAIL: patched source duplicated/lost ARCALIGNEDTEXT')
        sys.exit(1)
    if patched.count('#if defined (DEBUG_CLASSES) || defined (IS_FREE)') != 2 or patched.count('#endif') != 2:
        print('FAIL: patched source guard count is not balanced')
        sys.exit(1)
    if 'DWG_ENTITY_END\n\n#if defined (DEBUG_CLASSES) || defined (IS_FREE)' not in patched:
        print('FAIL: original debug-only schema guard was not resumed after ARCALIGNEDTEXT')
        sys.exit(1)
    package_after=json.loads((cwd / 'package.json').read_text(encoding='utf-8'))
    cmd=package_after['scripts']['build:wasm']
    if 'export interface MainModule' not in cmd or 'export { MainModule }' not in cmd:
        print('FAIL: generated declaration does not export MainModule')
        sys.exit(1)
    tsconfig_after=json.loads((cwd / 'tsconfig.json').read_text(encoding='utf-8'))
    if tsconfig_after['compilerOptions'].get('noImplicitAny') is not False:
        print('FAIL: wrapper implicit-any setting was not patched')
        sys.exit(1)
    print('PASS: embedded schema patch preserves neighboring schemas and balances the conditional guards.')
