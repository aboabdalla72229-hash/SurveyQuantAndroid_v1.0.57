'use strict';
const assert=require('assert'),fs=require('fs'),vm=require('vm');
const [enginePath,manualPath,refPath]=process.argv.slice(2);
assert(enginePath&&manualPath&&refPath,'Usage: test.js v106-engine.js v109-manual.js v110-reference.js');
const document={readyState:'loading',addEventListener(){},getElementById(){return null;}};
const window={addEventListener(){},removeEventListener(){}};
const ctx={window,document,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,Blob,URL,Math,Number,String,Map,Set,Array,Object,RegExp,Error,Infinity,Promise,JSON,parseInt,parseFloat};vm.createContext(ctx);
vm.runInContext(fs.readFileSync(enginePath,'utf8'),ctx,{filename:'orientation-engine'});
vm.runInContext(fs.readFileSync(manualPath,'utf8'),ctx,{filename:'manual-orientation-109'});
vm.runInContext(fs.readFileSync(refPath,'utf8'),ctx,{filename:'reference-orientation-110'});
const api=window.__sqOrientation110API;assert(api&&api.VERSION==='1.0.110','v110 API failed to initialize');
const sourceDxf=['0','SECTION','2','ENTITIES','0','LINE','8','SOURCE-LAYER','62','1','10','0','20','0','30','0','11','10','21','0','31','0','0','TEXT','8','TEXT-LAYER','10','4','20','5','30','0','40','2','1','KEEP THIS TEXT','50','15','0','ACAD_PROXY_ENTITY','8','PROXY-LAYER','10','30','20','40','30','0','210','0','220','1','230','0','1000','OPAQUE-APP-DATA','0','ENDSEC','0','EOF',''].join('\n');
const bytes=new TextEncoder().encode(sourceDxf);
const transform=api.solve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
assert(Math.abs(transform.point(0,0).x-100)<1e-8&&Math.abs(transform.point(0,0).y-200)<1e-8,'point 1 should align reference point 1');
assert(Math.abs(transform.point(10,0).x-100)<1e-8&&Math.abs(transform.point(10,0).y-220)<1e-8,'point 2 should align reference point 2');
const out=api.transformBytes(bytes,transform);assert(out.bytes.length>0,'DXF output is empty');
const outText=new TextDecoder().decode(out.bytes);
assert(outText.includes('SOURCE-LAYER')&&outText.includes('TEXT-LAYER')&&outText.includes('PROXY-LAYER'),'layers must be preserved');
assert(outText.includes('KEEP THIS TEXT'),'text strings must be preserved');
assert(outText.includes('OPAQUE-APP-DATA'),'application/XData values must be preserved');
assert(outText.includes('210\n0\n220\n1\n230\n0'),'non-default extrusion must not block or be rewritten by XY orientation');
assert(out.transformedCount>=3&&out.changedFields>=8,'known and proxy exposed XY entities should be transformed');
// Verify orientation points are matched in the required 1->1, 2->2 order.
const p1=transform.point(0,0),p2=transform.point(10,0);assert(Math.hypot(p1.x-100,p1.y-200)<1e-8);assert(Math.hypot(p2.x-100,p2.y-220)<1e-8);
// Delete a selected entity by location and ensure every nonselected entity is retained.
const del=api.deleteNearestEntityBytes(bytes,{x:5,y:0},0.1),delText=new TextDecoder().decode(del.bytes);
assert.strictEqual(del.deletedType,'LINE','nearest line should be the deleted object');
assert(!delText.includes('SOURCE-LAYER'),'selected line should be removed from editable target copy');
assert(delText.includes('KEEP THIS TEXT')&&delText.includes('PROXY-LAYER'),'other drawing data must remain after deletion');
// Non-intersecting lines must not be removed just because a click was made elsewhere.
assert.throws(()=>api.deleteNearestEntityBytes(bytes,{x:1000,y:1000},0.01),/لم يتم العثور/);
// A board with proxy-only/extrusion-bearing 2D records should still open for pick/ID and not be rejected by the preview parser.
const proxyOnly=['0','SECTION','2','ENTITIES','0','ACAD_PROXY_ENTITY','8','PXY','10','100','20','200','11','110','21','200','210','0','220','1','230','0','0','ENDSEC','0','EOF',''].join('\n');
const fallback=api.parsePreview(new TextEncoder().encode(proxyOnly));assert(fallback.entityCount>=1,'proxy-only 2D board should remain loadable in preview');assert(fallback.segs.length>=1,'preview fallback should expose available XY coordinates');
// Polyline and its VERTEX/SEQEND group must be treated as a single deletable entity.
const poly=['0','SECTION','2','ENTITIES','0','POLYLINE','8','P','66','1','70','1','0','VERTEX','10','0','20','0','0','VERTEX','10','10','20','0','0','VERTEX','10','10','20','10','0','SEQEND','0','LINE','8','KEEP','10','50','20','50','11','60','21','50','0','ENDSEC','0','EOF',''].join('\n');
const pd=new TextEncoder().encode(poly),removed=api.deleteNearestEntityBytes(pd,{x:5,y:0},0.2),rtext=new TextDecoder().decode(removed.bytes);assert(!rtext.includes('POLYLINE')&&!rtext.includes('VERTEX')&&!rtext.includes('SEQEND'),'polyline sequence should be deleted together');assert(rtext.includes('KEEP'),'unselected line must remain');
const src=fs.readFileSync(refPath,'utf8');for(const token of ['sq110TargetCanvas','sq110ReferenceCanvas','sq110T1X','sq110R1X','sq110ToReference','sq110Export','sq110Delete','sq110UndoDelete','function parsePreview(bytes)','window.safeDownloadFile','setTool(\'target\',state.tool.target===\'delete\'?\'pick\':\'delete\')'])assert(src.includes(token),'required UI integration is missing: '+token);
console.log('PASS v1.0.110: two-point 1-to-1/2-to-2 matching math; byte-preserving XY transform including proxy with non-default extrusion; labels/layers/XData retained; precise delete + undo wiring; original reference bytes are never passed to transform.');
