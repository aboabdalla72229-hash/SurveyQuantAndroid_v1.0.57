from pathlib import Path
import json, shutil
import ezdxf
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent
HTML=(ROOT/'index.html').read_text(encoding='utf-8')
SOURCE=(ROOT/'source_v184.dxf').read_bytes()

# Simulate an old page/script leaving the host, style and button IDs behind.
stale = '''<div id="sq176-cad-project-host"><div id="stale-sentinel">OLD SESSION</div></div>
<style id="sq162-cad-style">.stale{display:none}</style>
<button id="sq176-home-orientation-project" type="button">OLD ORIENTATION BUTTON</button>
<button id="sq176-home-pdf-project" type="button">OLD PDF BUTTON</button>\n'''
HTML=HTML.replace('<script id="sq176-cad-engine">', stale+'<script id="sq176-cad-engine">', 1)
assert HTML.count('stale-sentinel')==1

with sync_playwright() as p:
    chrome=shutil.which('chromium') or shutil.which('chromium-browser')
    opts={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
    if chrome:opts['executable_path']=chrome
    browser=p.chromium.launch(**opts)
    page=browser.new_page(viewport={'width':430,'height':900},accept_downloads=True)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(HTML,wait_until='domcontentloaded',timeout=60000)
    page.wait_for_timeout(200)
    # Stale injected host/buttons are discarded and replaced by the current build.
    stale_state=page.evaluate("""()=>({stale:!!document.querySelector('#stale-sentinel'),hostCount:document.querySelectorAll('#sq176-cad-project-host').length,styleCount:document.querySelectorAll('#sq162-cad-style').length,orientation:document.querySelector('#sq176-home-orientation-project')?.textContent,pdf:document.querySelector('#sq176-home-pdf-project')?.textContent})""")
    assert stale_state['stale'] is False and stale_state['hostCount']==1 and stale_state['styleCount']==1,stale_state
    assert 'OLD' not in stale_state['orientation'] and 'OLD' not in stale_state['pdf'],stale_state

    # Session reset must work after stale-host replacement, even for a half-loaded pair.
    page.locator('#sq176-home-orientation-project').click()
    page.locator('#sq162-source-file').set_input_files({'name':'source_v184.dxf','mimeType':'application/dxf','buffer':SOURCE})
    page.wait_for_function("document.querySelector('#sq162-source-info').textContent.includes('بصمة CAD')",timeout=30000)
    page.locator('.project-back').click();page.wait_for_timeout(100)
    page.locator('#sq176-home-orientation-project').click();page.wait_for_timeout(100)
    reopen=page.evaluate("""()=>({source:document.querySelector('#sq162-source-canvas')._sqMap,target:document.querySelector('#sq162-target-canvas')._sqMap,name:document.querySelector('#sq162-oriented-name').value,file:document.querySelector('#sq162-source-file').files.length})""")
    assert reopen=={'source':None,'target':None,'name':'','file':0},reopen

    # Same coordinates are legitimate only for distinct CAD fingerprints; the no-op transform is accepted.
    target_doc=ezdxf.readfile(ROOT/'source_v184.dxf')
    target_doc.modelspace().add_text('TARGET-ONLY-DIFFERENCE',dxfattribs={'insert':(40,40),'height':1})
    target_path=ROOT/'V185_IDENTITY_TARGET_FIXTURE.dxf';target_doc.saveas(target_path)
    assert target_path.read_bytes()!=SOURCE
    def load(which,name,data):
        page.locator(f'#sq162-{which}-file').set_input_files({'name':name,'mimeType':'application/dxf','buffer':data})
        page.wait_for_function(f"document.querySelector('#sq162-{which}-info').textContent.includes('بصمة CAD')",timeout=30000)
    load('source','source_v184.dxf',SOURCE)
    load('target','source_v184.dxf',target_path.read_bytes())
    fingerprints=page.evaluate("""()=>({s:document.querySelector('#sq162-source-canvas')._sqMap.cadFingerprint,t:document.querySelector('#sq162-target-canvas')._sqMap.cadFingerprint})""")
    assert fingerprints['s']!=fingerprints['t'],fingerprints
    page.locator('[data-sq-snap="source"]').select_option('endpoint')
    page.locator('[data-sq-snap="target"]').select_option('endpoint')
    def pick(slot,canvas,xy):
        page.locator(f'#sq162-pick-{slot}').click()
        pt=page.locator(f'#{canvas}').evaluate("""(c,xy)=>{const p=c._sqMap.pt({x:xy[0],y:xy[1]}),r=c.getBoundingClientRect();return{x:r.left+p.x,y:r.top+p.y};}""",xy)
        page.mouse.click(pt['x'],pt['y']);page.wait_for_timeout(80)
    pick(0,'sq162-source-canvas',[0,0]);pick(1,'sq162-source-canvas',[10,0])
    pick(2,'sq162-target-canvas',[0,0]);pick(3,'sq162-target-canvas',[10,0])
    page.locator('#sq162-do-align').click();page.wait_for_timeout(150)
    identity_result=page.evaluate("""()=>({status:document.querySelector('#sq162-align-status').textContent,enabled:!document.querySelector('#sq162-save-oriented').disabled,map:document.querySelector('#sq162-oriented-canvas')._sqMap&&{which:document.querySelector('#sq162-oriented-canvas')._sqMap.which,bounds:[document.querySelector('#sq162-oriented-canvas')._sqMap.geom.minX,document.querySelector('#sq162-oriented-canvas')._sqMap.geom.minY,document.querySelector('#sq162-oriented-canvas')._sqMap.geom.maxX,document.querySelector('#sq162-oriented-canvas')._sqMap.geom.maxY]}})""")
    assert identity_result['enabled'] and identity_result['map']['which']=='oriented',identity_result
    assert 'الدوران: 0' in identity_result['status'] or 'الدوران المحسوب: 0' in page.locator('#sq162-transform-details').inner_text(),identity_result

    # Block definitions: segment cap must not hide INSERT labels/curves, and curves must not be duplicated.
    block_doc=ezdxf.new('R2000')
    block=block_doc.blocks.new(name='AXIS_BLOCK',base_point=(0,0))
    block.add_line((0,0),(5,0))
    block.add_circle((1,2),0.75)
    block.add_text('AX-A',dxfattribs={'insert':(2,3),'height':0.5})
    msp=block_doc.modelspace()
    msp.add_line((0,0),(1,0)) # consume maxSegments=1 in the main drawing before INSERTs
    msp.add_blockref('AXIS_BLOCK',(100,200),dxfattribs={'rotation':90,'xscale':2,'yscale':2})
    msp.add_blockref('AXIS_BLOCK',(200,300),dxfattribs={'rotation':0})
    block_path=ROOT/'V185_BLOCK_LABEL_CURVE_FIXTURE.dxf';block_doc.saveas(block_path)
    parsed=page.evaluate("""async bytes=>{const g=window.SurveyQuantCAD184.readGeometry(new Uint8Array(bytes),1);return {segments:g.segments.length,texts:g.texts.map(t=>({text:t.text,x:t.position.x,y:t.position.y})),curves:g.curves.map(c=>({type:c.type,center:c.center,first:c.points[0]})),stats:g.parserStats};}""",list(block_path.read_bytes()))
    assert parsed['segments']==1,parsed
    assert len(parsed['texts'])==2 and all(t['text']=='AX-A' for t in parsed['texts']),parsed
    assert len(parsed['curves'])==2,parsed
    # Block 1: 2x scale and 90 degrees around the insertion origin => center (96,202).
    assert abs(parsed['curves'][0]['center']['x']-96)<1e-8 and abs(parsed['curves'][0]['center']['y']-202)<1e-8,parsed['curves']
    assert abs(parsed['texts'][0]['x']-94)<1e-8 and abs(parsed['texts'][0]['y']-204)<1e-8,parsed['texts']
    assert parsed['stats']['insertInstances']==2,parsed

    report={'result':'PASS V185 hardening','stale_mount_rebuilt':stale_state,'half_loaded_session_reopen_blank':reopen,'distinct_fingerprint_same_coordinate_identity_alignment_accepted':identity_result,'block_inserts':parsed,'browser_page_errors':errors[:10]}
    (ROOT/'V185_HARDENING_TEST_LOG.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False,indent=2))
    browser.close()
