'use strict';
const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const htmlPath=process.argv[2];
assert(htmlPath,'usage: node SurveyQuant_v1.0.150_SESSION_SPLINE_DWG_TEST.js index.html');
const html=fs.readFileSync(htmlPath,'utf8');
assert(html.includes('const SQ_APP_VERSION_CODE = 150;'),'application must be version 150');
assert(html.includes('id="surveyquant-v150-fresh-board-session"'),'fresh-session guard version mismatch');
assert(html.includes('height:34vh;min-height:200px;max-height:360px'),'mobile viewport should be smaller');
assert(html.includes('window.parseFile = parseFile;'),'common parser must be exposed to the orientation module');
assert(html.includes("const SQ_PREVIEW_OCS_TYPES = new Set(['POINT','CIRCLE','ARC','INSERT','TEXT','MTEXT'"),'MTEXT OCS fallback must be enabled');
assert(html.includes('function prepareSideForReplacement(side)'),'replacing a board must clear prior-side state before parsing');
assert(html.includes('state.loadSerial[side]=token;'),'file-load generation token missing');
assert(html.includes("const needsSplinePreview=[...all,...nestedRecords].some(r=>String(r.type||'').toUpperCase()==='SPLINE');"),'ordinary +Z SPLINE must still force geometry-aware preview, not the generic parser');
assert(html.includes('const needsFallbackPreview=needsWcsPreview||needsSplinePreview;'),'preview fallback decision omits SPLINE entities');
assert(html.includes('base.previewSplineFallback=needsSplinePreview;'),'user-visible preview mode must identify SPLINE fallback');
const activeSplineStart=html.indexOf("if(t==='SPLINE'){",html.indexOf('function recordGeometry(rec){')); const activeSplineEnd=html.indexOf("\n if(t===",activeSplineStart+20); assert(activeSplineStart>=0&&activeSplineEnd>activeSplineStart&&!html.slice(activeSplineStart,activeSplineEnd).includes('const vertices=pairsFor(10,20);chain(vertices,false)'), 'SPLINE must not be rendered as a straight control polygon');
assert(html.includes('const out=model&&model.rawDXFBytes;'),'DWG reader must validate converted DXF bytes');
assert(html.includes('P1 بعد التحويل=') && html.includes('P2 بعد التحويل='),'after-alignment coordinates should be reported for both picked points');

const recGeoStart=html.indexOf('function recordGeometry(rec){');
const recGeoEnd=html.indexOf('function recordString(rec,code,occ=0)',recGeoStart);
assert(recGeoStart>=0 && recGeoEnd>recGeoStart,'could not isolate actual recordGeometry implementation');
const geomSource=html.slice(recGeoStart,recGeoEnd);
const geomHarness=`
function num(v){const n=Number(v);return Number.isFinite(n)?n:null;}
function pairVal(rec,code,occ=0){const p=(rec.pairs||[]).filter(x=>x.code===code)[occ];return p?num(p.value):null;}
function pointAt(rec,xcode,idx=0){const x=pairVal(rec,xcode,idx),y=pairVal(rec,xcode+10,idx);return x===null||y===null?null:{x,y};}
${geomSource}
this.api={recordGeometry};`;
const gc=vm.createContext({Math,Number,String,Object,Array,Set,Map,RegExp,Infinity});
vm.runInContext(geomHarness,gc,{timeout:5000,filename:'v150-record-geometry-harness.js'});
const geom=gc.api.recordGeometry;
const pairs=[];
for(const v of [3])pairs.push({code:71,value:String(v)});
for(const v of [0,0,0,0,1,1,1,1])pairs.push({code:40,value:String(v)});
for(const [x,y] of [[0,0],[1,4],[3,4],[4,0]]){pairs.push({code:10,value:String(x)},{code:20,value:String(y)});}
const spline=geom({type:'SPLINE',pairs});
assert(spline.segments.length>=24,'valid cubic SPLINE should be sampled as an actual curve');
assert(Math.hypot(spline.segments[0].a.x,spline.segments[0].a.y)<1e-8,'clamped SPLINE must start at first endpoint');
const end=spline.segments.at(-1).b;
assert(Math.hypot(end.x-4,end.y)<1e-8,'clamped SPLINE must end at last endpoint');
const ys=spline.segments.flatMap(s=>[s.a.y,s.b.y]);
assert(Math.max(...ys)>2.9 && Math.max(...ys)<3.1,'cubic spline curve should be near y=3 rather than y=4 control chord');
assert(!spline.segments.some(s=>Math.hypot(s.a.x-1,s.a.y-4)<1e-6&&Math.hypot(s.b.x-3,s.b.y-4)<1e-6),'control polygon chord must not be drawn as real geometry');
console.log('PASS V150 geometry: valid rational B-spline rendered as a sampled curve, not control polygon.');
const fitPairs=[{code:71,value:'3'},{code:10,value:'0'},{code:20,value:'0'},{code:10,value:'1'},{code:20,value:'5'},{code:10,value:'2'},{code:20,value:'0'},{code:11,value:'0'},{code:21,value:'0'},{code:11,value:'1'},{code:21,value:'1'},{code:11,value:'2'},{code:21,value:'0'}];
const fit=geom({type:'SPLINE',pairs:fitPairs});
assert.equal(fit.segments.length,2,'without usable knots, spline should use fit points');
assert(Math.max(...fit.segments.flatMap(s=>[s.a.y,s.b.y]))<=1.000001,'fit-point fallback must not connect unrelated control points');
const noCurve=geom({type:'SPLINE',pairs:[{code:10,value:'0'},{code:20,value:'0'},{code:10,value:'1'},{code:20,value:'8'}]});
assert.equal(noCurve.segments.length,0,'missing knot/fit data may expose snap anchors but must not fabricate segments');
console.log('PASS V150 geometry: incomplete SPLINE metadata falls back to fit points or isolated anchors without fake diagonals.');

const solveStart=html.indexOf('function solve(src1,src2,ref1,ref2){');
const solveEnd=html.indexOf('// Replace the prior guard',solveStart);
assert(solveStart>=0&&solveEnd>solveStart,'could not isolate active two-point solver');
const solverSrc=html.slice(solveStart,solveEnd)+'\nthis.solve=solve;';
const sc=vm.createContext({Math,Number,Error});
vm.runInContext(solverSrc,sc,{timeout:5000,filename:'v150-solver-test.js'});
const solved=sc.solve({x:-300,y:-200},{x:-100,y:-200},{x:5000,y:8000},{x:5000,y:8400});
assert.equal(solved.scale,2,'scale should be 2');
assert(Math.abs(solved.angleDeg-90)<1e-10,'rotation should be +90 degrees');
for(const [s,r] of [[{x:-300,y:-200},{x:5000,y:8000}],[{x:-100,y:-200},{x:5000,y:8400}]]){
 const p=solved.point(s.x,s.y);assert(Math.hypot(p.x-r.x,p.y-r.y)<1e-8,'chosen source point must map to its corresponding reference point even from negative source coordinates');
}
console.log('PASS V150 alignment: negative source coordinates map precisely to positive reference coordinates without forced sign changes.');

// Exercise the production reset function against a non-empty state.
const resetStart=html.indexOf('function resetOrientationState(){');
const resetEnd=html.indexOf('\nfunction resetSession(',resetStart);
assert(resetStart>=0&&resetEnd>resetStart,'reset function not found');
const simulatedState={loadSerial:{target:3,reference:8},target:{name:'old-target'},reference:{name:'old-reference'},targetPoints:[{x:1,y:2},{x:3,y:4}],referencePoints:[{x:10,y:20},{x:30,y:40}],active:{target:1,reference:1},tool:{target:'delete',reference:'id'},snapMode:{target:'endpoint',reference:'intersection'},views:{target:{old:true},reference:{old:true}},selectedEntity:{old:true},selectedEntities:[1,2],undoStack:[1],redoStack:[1],referenceSelectedEntity:{old:true},referenceSelectedEntities:[2],referenceUndoStack:[2],referenceRedoStack:[2],idPoint:{target:{x:3,y:4},reference:{x:5,y:6}}};
const rc=vm.createContext({state:simulatedState});
vm.runInContext(html.slice(resetStart,resetEnd)+'\nresetOrientationState();',rc,{timeout:5000});
assert.equal(simulatedState.target,null);assert.equal(simulatedState.reference,null);
assert.equal(JSON.stringify(simulatedState.targetPoints),'[null,null]');assert.equal(JSON.stringify(simulatedState.referencePoints),'[null,null]');
assert.equal(JSON.stringify(simulatedState.views),'{}');assert.equal(JSON.stringify(simulatedState.selectedEntities),'[]');assert.equal(JSON.stringify(simulatedState.undoStack),'[]');assert.equal(JSON.stringify(simulatedState.redoStack),'[]');
assert.equal(simulatedState.loadSerial.target,4);assert.equal(simulatedState.loadSerial.reference,9);
console.log('PASS V150 session: reset drops previous target/reference drawings, points, selection, history, ID points, and invalidates pending loads.');

// Test real openCad with a stubbed canonical parser and also test failure handling.
const openStart=html.indexOf('async function openCad(file){');
const openEnd=html.indexOf('\nfunction resetView(v)',openStart);
assert(openStart>=0&&openEnd>openStart,'openCad function not found');
(async()=>{
 let parseCalls=0;
 const raw=new Uint8Array(128);raw.set([48,10,83,69,67,84,73,79,78]);
 const ctx=vm.createContext({window:{parseFile:async file=>{parseCalls++;assert.equal(file.name,'plant.DWG');return {rawDXFBytes:raw.slice()};}},Uint8Array,ArrayBuffer,Promise,String,Error,bytesOfDxf:async file=>new Uint8Array(await file.arrayBuffer())});
 vm.runInContext(html.slice(openStart,openEnd)+'\nthis.openCad=openCad;',ctx,{timeout:5000});
 const out=await ctx.openCad({name:'plant.DWG'});
 assert.equal(parseCalls,1);assert.equal(out.name,'plant.dxf');assert(out.bytes instanceof Uint8Array);assert.equal(out.bytes.length,128);
 const dxf=new TextEncoder().encode('0\nSECTION\n2\nENTITIES\n0\nENDSEC\n0\nEOF\n');
 const dxfCtx=vm.createContext({window:{},Uint8Array,ArrayBuffer,Promise,String,Error,bytesOfDxf:async file=>new Uint8Array(await file.arrayBuffer())});
 vm.runInContext(html.slice(openStart,openEnd)+'\nthis.openCad=openCad;',dxfCtx,{timeout:5000});
 const dxfOut=await dxfCtx.openCad({name:'clean.dxf',arrayBuffer:async()=>dxf.buffer});
 assert.equal(dxfOut.name,'clean.dxf');assert.equal(dxfOut.bytes.length,dxf.length);
 const failCtx=vm.createContext({window:{parseFile:async()=>{throw new Error('mock conversion failed');}},Uint8Array,ArrayBuffer,Promise,String,Error});
 vm.runInContext(html.slice(openStart,openEnd)+'\nthis.openCad=openCad;',failCtx,{timeout:5000});
 await assert.rejects(()=>failCtx.openCad({name:'bad.dwg'}),/تعذر فتح ملف DWG/);
 // Exercise actual chooseFile/prepareSideForReplacement with mocked browser/file adapters.
 const chooseStart=html.indexOf('function prepareSideForReplacement(side){');
 const chooseEnd=html.indexOf('\nfunction calculation()',chooseStart);
 assert(chooseStart>=0&&chooseEnd>chooseStart,'chooseFile/reset-before-load functions not found');
 const els=Object.create(null),statuses=[];let slowResolve=null,loadCalls=[];
 const initialState={loadSerial:{target:0,reference:0},target:{name:'old-target'},reference:{name:'old-reference'},targetPoints:[{x:1,y:1},{x:2,y:2}],referencePoints:[{x:10,y:10},{x:20,y:20}],active:{target:1,reference:1},tool:{target:'delete',reference:'id'},snapMode:{target:'auto',reference:'auto'},views:{target:{old:true},reference:{old:true}},idPoint:{target:{x:1,y:1},reference:{x:2,y:2}},selectedEntity:{old:true},selectedEntities:[1],undoStack:[1],redoStack:[],referenceSelectedEntity:{old:true},referenceSelectedEntities:[1],referenceUndoStack:[1],referenceRedoStack:[]};
 const chooseCtx=vm.createContext({
  state:initialState,Uint8Array,Promise,Math,Number,String,Error,
  el:id=>(els[id]||(els[id]={value:'',textContent:'',style:{},open:false})),
  clearCanvasRuntime:side=>{initialState.views[side]=null;},
  status:(msg,bad=false)=>statuses.push({msg,bad}),fillReadouts:()=>{},updateDeleteHistoryButtons:()=>{},draw:()=>{},refreshVisibleCadCanvas:()=>{},
  openCad:async file=>{
   assert.equal(initialState[file.sideHint||'target'],null,'old board must be cleared before awaiting file parsing');
   if(file.name==='slow-old.dxf')return await new Promise(resolve=>{slowResolve=resolve;});
   if(file.name==='bad.dwg')throw new Error('mock DWG conversion error');
   const bytes=Uint8Array.from({length:80},(_,i)=>(i+(file.name==='newer.dxf'?3:1))&255);
   return {bytes,name:file.name};
  },
  loadView:(side,bytes,name)=>{const view={side,bytes,name,drawing:{entityCount:3,segs:[],layers:{}},alignmentPreview:null};initialState.views[side]=view;loadCalls.push(name);return view;}
 });
 vm.runInContext(html.slice(chooseStart,chooseEnd)+'\nthis.chooseFile=chooseFile;',chooseCtx,{timeout:5000});
 await chooseCtx.chooseFile('target',{name:'first.dxf'});
 assert.equal(initialState.target.name,'first.dxf');assert.equal(initialState.views.target.name,'first.dxf');
 await chooseCtx.chooseFile('target',{name:'bad.dwg'});
 assert.equal(initialState.target,null,'failed replacement must not keep previous board in state');
 assert.equal(initialState.views.target,null,'failed replacement must not keep previous drawing preview visible');
 assert(statuses.some(x=>x.bad&&/لم يتم استبدالها بنتيجة قديمة|تفريغ هذه الخانة/.test(x.msg)),'failure must explain old board was cleared');
 const slowPromise=chooseCtx.chooseFile('target',{name:'slow-old.dxf'});
 await Promise.resolve();
 const fastPromise=chooseCtx.chooseFile('target',{name:'newer.dxf'});
 await fastPromise;
 assert.equal(initialState.target.name,'newer.dxf');
 assert.equal(typeof slowResolve,'function','slow DWG/DXF fixture should have a resolver');
 slowResolve({bytes:Uint8Array.from({length:80},(_,i)=>(i+11)&255),name:'slow-old.dxf'});
 await slowPromise;
 assert.equal(initialState.target.name,'newer.dxf','a stale async file result must not overwrite the newest board');
 // A failed reference replacement must leave the independent target board untouched.
 await chooseCtx.chooseFile('reference',{name:'bad.dwg'});
 assert.equal(initialState.reference,null);
 assert.equal(initialState.views.reference,null);
 assert.equal(initialState.target.name,'newer.dxf');
 console.log('PASS V150 file lifecycle: stale board cleared before read; failures cannot leave old preview; stale async completion cannot overwrite newer selection; both sides remain independent.');
 console.log('PASS V150 DWG path: .DWG routes through shared parser and validates output bytes; failures are surfaced, not replaced by old canvas.');
})().catch(e=>{console.error(e);process.exitCode=1;});
