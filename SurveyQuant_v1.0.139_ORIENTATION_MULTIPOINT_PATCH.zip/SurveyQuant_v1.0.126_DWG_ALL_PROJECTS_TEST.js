'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const [bridgePath, htmlPath] = process.argv.slice(2);
assert(bridgePath && htmlPath, 'usage: node V126_DWG_ALL_PROJECTS_TEST.js V117_BRIDGE.js INDEX_PATH.html');
const bridge = fs.readFileSync(bridgePath, 'utf8');
const html = fs.readFileSync(htmlPath, 'utf8');

const fixedLookup = 'var apis = [window.__sqOriAxisAutoTest, window.__sqOrientation115Tools, window.__sqOrientation113API, window.__sqOrientation111API];';
assert.equal(bridge.split(fixedLookup).length - 1, 1, 'the actual app DWG converter API must be the first converter candidate');
assert(bridge.includes('convertTargetToDxf'), 'DWG conversion method missing');
assert(bridge.includes('var CAD_INPUT_IDS = new Set(['), 'CAD-specific picker scope missing');
const cadIds = [
  'concreteDxfInput', 'quantBeforeFile', 'quantAfterFile', 'quantFileInput',
  'profileFileInput', 'dropSurveyFiles', 'dropCadFile', 'sqOriReferenceFile',
  'sqOriTargetFile', 'sq108File', 'sq110TargetFile', 'sq110ReferenceFile'
];
for (const id of cadIds) assert(bridge.includes(`'${id}'`), `CAD file picker is not covered: ${id}`);
assert(bridge.includes("var NON_CAD_DATA_IDS = new Set(['fileToDxfInput', 'cleanFilesInput']);"),
  'text-list utilities must remain excluded from automatic CAD conversion');
assert(bridge.includes('function isCadInput(input)'), 'shared CAD-input detection function missing');
assert(bridge.includes('if (!isCadInput(input)) return;'), 'file-change handler must use the CAD-input gate');
assert(bridge.includes('MutationObserver'), 'newly-created project file pickers will not be detected');
assert(bridge.includes('new DataTransfer()') && bridge.includes("input.dispatchEvent(new Event('change', { bubbles: true }))"),
  'converted DXF must be passed back through the original project file-change handler');
assert(bridge.includes("/\\.dwg$/i") && bridge.includes("/\\.dxf$/i"), 'case-insensitive DWG/DXF handling missing');
assert(bridge.includes('window.__sqV117DwgBridgeAPI'), 'V117 bridge API marker missing');
assert(html.includes('id="sq-v117-universal-dwg-bridge"'), 'V117 global bridge tag missing');
const tag = html.match(/<script id="sq-v117-universal-dwg-bridge">([\s\S]*?)<\/script>/i);
assert(tag, 'cannot locate embedded bridge script');
assert.equal(tag[1].trim(), bridge.trim(), 'embedded bridge differs from the tested standalone bridge');
const apiIndex = html.indexOf('window.__sqOriAxisAutoTest');
const bridgeIndex = html.indexOf('<script id="sq-v117-universal-dwg-bridge">');
assert(apiIndex >= 0 && bridgeIndex > apiIndex, 'real DWG converter API must be defined before the universal bridge executes');

// Preserve V117 orientation/CAD behavior. V126 must not touch the orientation implementation or geometry data.
assert(html.includes('function universalTransformBytes(input,t)'), 'byte-preserving CAD transform is missing');
assert(html.includes('dwg_write_dxf(bytes.buffer)'), 'native DWG-to-DXF writer is missing');
assert(html.includes('window.safeDownloadFile(result.bytes') || html.includes('window.safeDownloadFile'),
  'existing safe output/download path is missing');
assert(bridge.includes('if (result && result.ok === false)'), 'DWG converter errors must not be silently swallowed');
console.log('PASS V126 static: all known CAD-board pickers are covered by the app-wide DWG bridge.');
console.log('PASS V126 static: bridge resolves the actual __sqOriAxisAutoTest.convertTargetToDxf export.');
console.log('PASS V126 static: V117 byte-preserving CAD transform and download path remain untouched.');

// Runtime simulation of DOM file pickers, accepted extensions, and the second change event reaching a project parser.
class TestBlob {
  constructor(parts = [], options = {}) {
    this.parts = parts;
    this.type = options.type || '';
    this.size = parts.reduce((n, part) => n + (part && part.byteLength != null ? part.byteLength : Buffer.byteLength(String(part))), 0);
  }
}
class TestFile extends TestBlob {
  constructor(parts, name, options = {}) { super(parts, options); this.name = name; this.lastModified = options.lastModified || 0; }
}
class TestDataTransfer {
  constructor() { this._files = []; this.items = { add: file => this._files.push(file) }; }
  get files() { return this._files.slice(); }
}
class TestEvent {
  constructor(type, options = {}) { this.type = type; this.bubbles = !!options.bubbles; this.defaultPrevented = false; }
  preventDefault() { this.defaultPrevented = true; }
  stopImmediatePropagation() { this.immediateStopped = true; }
}
const knownInputs = [
  ...cadIds.map(id => ({ id, tagName: 'INPUT', type: 'file', accept: id === 'profileFileInput' ? '*/*' : '.dxf', files: [], value: '', projectChangeCount: 0 })),
  { id: 'fileToDxfInput', tagName: 'INPUT', type: 'file', accept: '.sdr,.txt,.csv,.pt,.pnt,text/plain,text/csv,*/*', files: [], value: '', projectChangeCount: 0 },
  { id: 'cleanFilesInput', tagName: 'INPUT', type: 'file', accept: '.sdr,.pnt,.txt,.csv,.dat,text/plain,text/csv,*/*', files: [], value: '', projectChangeCount: 0 }
];
const documentListeners = Object.create(null);
const documentMock = {
  nodeType: 9,
  documentElement: {},
  querySelectorAll(selector) { return selector === 'input[type="file"]' ? knownInputs : []; },
  addEventListener(type, handler) { (documentListeners[type] ||= []).push(handler); }
};
const testBytes = new Uint8Array([0, 10, 13, 255]);
const converterCalls = [];
const testWindow = {
  __sqOriAxisAutoTest: {
    async convertTargetToDxf(file) {
      converterCalls.push(file.name);
      return { ok: true, bytes: testBytes.slice(), name: file.name.replace(/\.dwg$/i, '.dxf') };
    }
  }
};
const testContext = {
  window: testWindow, document: documentMock,
  MutationObserver: class { constructor(callback) { this.callback = callback; } observe() {} },
  File: TestFile, Blob: TestBlob, DataTransfer: TestDataTransfer,
  Event: TestEvent, DragEvent: class extends TestEvent {}, alert() {},
  console: { log() {}, warn() {}, error() {} },
  ArrayBuffer, Uint8Array, Set, Map, Array, String, Number, Object, RegExp, Error, Date, Promise,
  Buffer
};
vm.createContext(testContext);
vm.runInContext(bridge, testContext, { filename: bridgePath });

(async () => {
  // CAD-specific inputs must add DWG/DXF to their selectable types; text/survey utilities must not.
  for (const id of cadIds) {
    const input = knownInputs.find(item => item.id === id);
    assert(input.accept.toLowerCase().includes('.dwg'), `picker ${id} still does not offer DWG`);
    assert(input.accept.toLowerCase().includes('.dxf'), `picker ${id} must continue accepting DXF`);
  }
  for (const id of ['fileToDxfInput', 'cleanFilesInput']) {
    const input = knownInputs.find(item => item.id === id);
    assert(!input.accept.toLowerCase().split(',').includes('.dwg'), `${id} must remain a point-list utility, not a CAD importer`);
  }
  console.log('PASS V126 runtime: all 12 CAD board file controls expose DWG and DXF; survey-only controls remain scoped.');

  const input = knownInputs.find(item => item.id === 'quantBeforeFile');
  const sourceDwg = new TestFile([testBytes], 'Existing-Board.DwG', { type: 'application/octet-stream' });
  input.files = [sourceDwg];
  input.value = 'existing-board.dwg';
  input.dispatchEvent = function (event) {
    event.target = this;
    for (const handler of documentListeners.change || []) handler(event);
    if (!event.defaultPrevented) this.projectChangeCount++;
    return true;
  };
  assert.equal(documentListeners.change.length, 1, 'one global change listener should route the import');
  const originalChange = new TestEvent('change', { bubbles: true });
  originalChange.target = input;
  for (const handler of documentListeners.change) handler(originalChange);
  assert(originalChange.defaultPrevented && originalChange.immediateStopped, 'original DWG event must wait until conversion completes');

  // Await the bridge's asynchronous conversion and synthetic change that project listeners consume.
  for (let i = 0; i < 50 && (input.__sqV117DwgBusy || input.files.some(f => /\.dwg$/i.test(f.name))); i++) {
    await new Promise(resolve => setTimeout(resolve, 0));
  }
  assert.equal(input.files.length, 1, 'project should receive exactly one converted file');
  assert.equal(input.files[0].name, 'Existing-Board.dxf', 'project receives a temporary DXF-compatible File');
  assert.equal(input.projectChangeCount, 1, 'converted file must trigger exactly one project change event');
  assert.equal(sourceDwg.name, 'Existing-Board.DwG', 'source file object name must stay unchanged');
  assert.deepEqual(converterCalls, ['Existing-Board.DwG'], 'application-native converter should be called exactly once');
  assert.deepEqual(Array.from(input.files[0].parts[0]), Array.from(testBytes), 'converter bytes pass through without redrawing geometry');
  console.log('PASS V126 runtime: DWG selected in an existing project control is converted, then delivered once to its normal change handler.');
  console.log('PASS V126 runtime: original DWG object is untouched and the bridge returns converter bytes without redrawing the source.');
})().catch(error => { console.error(error); process.exitCode = 1; });
