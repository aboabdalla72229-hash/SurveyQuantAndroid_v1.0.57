'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

class FakeElement {
  constructor(tag, registry) {
    this.tagName = String(tag).toUpperCase();
    this.registry = registry;
    this.children = [];
    this.dataset = {};
    this.listeners = {};
    this.style = {};
    this.classList = { add(){}, remove(){}, toggle(){}, contains(){ return false; } };
    this._id = '';
    this.className = '';
    this.textContent = '';
    this.innerHTML = '';
    this.type = '';
  }
  set id(value) { this._id = String(value); if (this._id) this.registry.set(this._id, this); }
  get id() { return this._id; }
  appendChild(child) { this.children.push(child); child.parentNode = this; if (child.id) this.registry.set(child.id, child); return child; }
  addEventListener(type, fn) { (this.listeners[type] ||= []).push(fn); }
  removeEventListener() {}
  querySelectorAll() { return []; }
  getContext() { return { clearRect(){}, beginPath(){}, moveTo(){}, lineTo(){}, stroke(){}, fillText(){}, save(){}, restore(){}, setLineDash(){}, strokeRect(){} }; }
}

const registry = new Map();
const doc = {
  readyState: 'complete',
  head: new FakeElement('head', registry),
  body: new FakeElement('body', registry),
  listeners: {},
  createElement(tag) { return new FakeElement(tag, registry); },
  getElementById(id) { return registry.get(String(id)) || null; },
  querySelector(selector) {
    if (selector === '.container') return container;
    if (selector === '#homeMenu .home-menu') return menu;
    return null;
  },
  querySelectorAll() { return []; },
  addEventListener(type, fn) { (this.listeners[type] ||= []).push(fn); }
};
const container = new FakeElement('div', registry); container.className = 'container';
const home = new FakeElement('div', registry); home.id = 'homeMenu';
const menu = new FakeElement('div', registry); menu.className = 'home-menu';
home.appendChild(menu); container.appendChild(home);
const script = new FakeElement('script', registry); script.id = 'sq177-single-canvas-data-export';

const cad = {
  readGeometry(){}, snapPoint(){}, solve(){}, transformGeometryView(){},
  createOrientedDxfBytes(){}, mergeRawDxfBoards(){}, fileFingerprint(){}, zipStore(){}
};
const window = {
  document: doc,
  SurveyQuantCAD177: cad,
  parseFile: async()=>({}),
  safeDownloadFile: async()=>({ok:true}),
  URL: { revokeObjectURL(){}, createObjectURL(){return 'blob:test';} },
  setInterval, clearInterval, addEventListener(){},
  atob: global.atob,
  Blob: global.Blob,
  Image: function Image(){}
};
const context = {
  window, document: doc, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer,
  DataView, Blob: global.Blob, Math, Number, String, Map, Set, Promise,
  Date, RegExp, Error, JSON, console, setInterval, clearInterval,
  isFinite, parseFloat, parseInt
};
vm.createContext(context);
const modulePath = process.argv[2] || path.join(__dirname, 'SurveyQuant_v1.0.177_SINGLE_CANVAS_DATA_EXPORT_MODULE.js');
vm.runInContext(fs.readFileSync(modulePath, 'utf8'), context, { filename: modulePath });

// The script tag and mount guard intentionally share the old MODULE_ID. This test
// proves the guard no longer mistakes the script element for a mounted UI.
assert.equal(doc.getElementById('sq177-single-canvas-data-export'), script, 'inline module script is present');
const buttonIds = menu.children.map(x=>x.id);
const cardIds = container.children.map(x=>x.id);
assert.ok(buttonIds.includes('sq177-home-orientation'), 'orientation menu button must be created');
assert.ok(buttonIds.includes('sq177-home-data-export'), 'data export menu button must be created');
assert.ok(cardIds.includes('sq177OrientationCard'), 'orientation project card must be mounted');
assert.ok(cardIds.includes('sq177DataExportCard'), 'data export project card must be mounted');
assert.ok(doc.getElementById('sq177-single-canvas-data-export-style'), 'independent mount sentinel/style must be inserted');
assert.ok(window.SurveyQuantV177Addendum, 'public addendum API must be published only after mounting');
console.log(JSON.stringify({
  result: 'PASS',
  scriptElementId: script.id,
  mountSentinelId: doc.getElementById('sq177-single-canvas-data-export-style').id,
  menuButtons: buttonIds,
  mountedCards: cardIds,
  orientationVisibleInMenu: true,
  dataExportVisibleInMenu: true
}, null, 2));
