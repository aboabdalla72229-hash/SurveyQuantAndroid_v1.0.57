from pathlib import Path
import json, shutil, base64
from playwright.sync_api import sync_playwright
import ezdxf, ezdxf.recover
root=Path(__file__).resolve().parent
html=(root/'index.html').read_text(encoding='utf-8')
fixtures=[('vector',root/'V180_VECTOR_ONLY_TEST.pdf','V185_Vector',True),('raster',root/'V180_RASTER_ONLY_TEST.pdf','V185_Raster',False),('mixed',root/'V180_MIXED_ARCHITECTURAL_TEST.pdf','V185_Mixed',False)]
with sync_playwright() as p:
 chrome=shutil.which('chromium') or shutil.which('chromium-browser')
 opts={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
 if chrome: opts['executable_path']=chrome
 b=p.chromium.launch(**opts);page=b.new_page(viewport={'width':430,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded',timeout=60000);page.wait_for_timeout(500);page.locator('#sq176-home-pdf-project').click();page.wait_for_timeout(100)
 page.evaluate("""()=>{window.__nativeSavedFiles={};window.__nativeSaveAttempts=0;window.__browserFallbacks=[];window.__cancelledChunks=0;window.__chunkTx=null;const oldClick=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){if(this.download)window.__browserFallbacks.push({name:this.download,href:this.href});return oldClick.call(this);};window.Android={saveFile:()=> 'ERROR: direct save disabled',startChunkedFile:(n,m)=>{window.__nativeSaveAttempts++;window.__chunkTx={name:n,mime:m,parts:[]};return 'mock-token';},appendChunk:(token,part)=>{if(token!=='mock-token'||!window.__chunkTx)return 'ERROR: invalid chunk token';window.__chunkTx.parts.push(part);return 'OK';},finishChunkedFile:(token,n,m)=>{if(token!=='mock-token'||!window.__chunkTx)return 'ERROR: invalid chunk token';const tx=window.__chunkTx;window.__chunkTx=null;if(window.__nativeSaveAttempts===1)return 'ERROR: simulated storage denial';window.__nativeSavedFiles[n]={mime:m,base64:tx.parts.join('')};return 'Downloads/SurveyQuant/'+n;},cancelChunkedFile:()=>{window.__cancelledChunks++;window.__chunkTx=null;},notifyDownload:()=>{}}}""")
 report=[]
 for mode,pdf,name,should_export in fixtures:
  inp=page.locator('#sq162-raster-file');inp.set_input_files(str(pdf));page.wait_for_function("document.querySelector('#sq162-raster-file').files.length===1 && !document.querySelector('#sq162-trace').disabled",timeout=30000)
  page.locator('#sq162-pdf-output-name').fill(name)
  if should_export:
   page.locator('#sq162-trace').click()
   page.wait_for_function("document.querySelector('#sq162-raster-status').innerText.includes('تم تجهيز ملف DXF الناتج')",timeout=60000)
   assert page.locator('#sq162-save-pdf-dxf').is_enabled(),'generated DXF is not retained for saving'
   result=page.evaluate("""()=>({name:window.__nativeSavedFiles?Object.keys(window.__nativeSavedFiles):[],resultBytes:window.__nativeSaveAttempts,stored:!!window.SurveyQuantCAD184})""")
   assert result['name']==[] and result['resultBytes']==0, 'conversion must not claim to save before the explicit save action'
   # First native save is deliberately failed. The generated DXF must remain and the
   # save button must remain available so Android storage can be retried without parsing again.
   page.locator('#sq162-save-pdf-dxf').click()
   page.wait_for_function("document.querySelector('#sq162-raster-status').innerText.includes('تم طلب تنزيل احتياطي')",timeout=30000)
   assert page.locator('#sq162-save-pdf-dxf').is_enabled(),'save fallback discarded result or disabled retry'
   retained=page.evaluate("""()=>({bytes:window.__nativeSaveAttempts,button:!document.querySelector('#sq162-save-pdf-dxf').disabled,fallbacks:window.__browserFallbacks.slice(),cancelled:window.__cancelledChunks,pending:!!window.SurveyQuantCAD184})""")
   assert retained['button'] and retained['bytes']==1 and len(retained['fallbacks'])==1 and retained['cancelled']==1,retained
   assert retained['fallbacks'][0]['name']==f'{name}.dxf',retained
   # Second call succeeds through the Android JavaScript bridge contract.
   page.locator('#sq162-save-pdf-dxf').click()
   page.wait_for_function("Object.keys(window.__nativeSavedFiles).length===1",timeout=30000)
   saved=page.evaluate('window.__nativeSavedFiles')
   out=root/f'V185_{mode.upper()}_R2004.dxf';out.write_bytes(base64.b64decode(next(iter(saved.values()))['base64']))
   txt=out.read_bytes().decode('cp1252',errors='replace')
   assert '\nIMAGE\n' not in txt and '\nIMAGEDEF\n' not in txt and '\nOLE2FRAME\n' not in txt
   doc,_=ezdxf.recover.readfile(out);audit=doc.audit();assert doc.dxfversion=='AC1018' and not audit.errors and not audit.fixes
   m=doc.modelspace();assert len(m.query('LINE'))+len(m.query('LWPOLYLINE'))>0,'PDF native geometry missing';assert len(m.query('TEXT'))>0,'PDF text extraction missing'
   open_result=page.evaluate("(() => { const r=window.SurveyQuantCAD184.polylinesToDxf([{closed:false,points:[{x:0,y:0},{x:10,y:10},{x:20,y:10}]}],100,100,1,[]); return Array.from(r.bytes); })()")
   open_dxf=root/'V185_OPEN_STROKE_LINE_TEST.dxf';open_dxf.write_bytes(bytes(open_result));open_doc,_=ezdxf.recover.readfile(open_dxf);assert len(open_doc.modelspace().query('LINE'))==2,'Open PDF strokes must be native LINE entities'
   report.append({'mode':mode,'result':'PASS vector-native export; Android error triggered browser-download fallback; retry succeeded through mock bridge','lines':len(m.query('LINE')),'closed_polylines':len(m.query('LWPOLYLINE')),'texts':len(m.query('TEXT')),'entities':len(m),'android_bridge_mock_attempts':2,'chunked_save_path':True,'failed_chunk_transaction_cancelled':True,'browser_fallback_requests':1,'save_retry_retained_output':True,'audit_errors':len(audit.errors),'audit_fixes':len(audit.fixes)})
  else:
   page.locator('#sq162-trace').click()
   page.wait_for_function("document.querySelector('#sq162-raster-status').innerText.includes('تحتوي صورًا')",timeout=60000)
   assert page.locator('#sq162-save-pdf-dxf').is_disabled(),'raster/mixed page must not leave a misleading output to save'
   report.append({'mode':mode,'result':'PASS rejected without tracing or save','downloads':0})
 # Backgrounding/leaving the project destroys the pending output and selected file.
 page.evaluate("window.dispatchEvent(new Event('surveyquant:session-background'))")
 page.wait_for_function("document.querySelector('#sq162-save-pdf-dxf').disabled && document.querySelector('#sq162-raster-file').files.length===0 && document.querySelector('#sq162-pdf-output-name').value===''",timeout=30000)
 result={'result':'PASS native vector only; Android save failure requested a browser fallback; retry succeeded through mock bridge; raster/mixed rejected; session exit clears pending PDF output','fixtures':report,'open_stroke_test':'PASS two DXF LINE entities','pdf_session_cleanup':'PASS pending output and file selection cleared','browser_page_errors':errors}
 (root/'V185_PDF_NO_REDRAW_TEST_LOG.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2));b.close()
