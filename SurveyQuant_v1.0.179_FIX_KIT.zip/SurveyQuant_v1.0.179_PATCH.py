#!/usr/bin/env python3
"""V179: clear both-board point provenance on any board reload, fix PDF fill+stroke
and expose explicit user-controlled output names for orientation and PDF DXF saves.
"""
from pathlib import Path
import argparse, re

MARKER='<!-- SURVEYQUANT_V179_TWO_BOARD_RESET_PDF_STROKE_AND_OUTPUT_NAMES -->'

def replace_once(text, old, new, label):
    n=text.count(old)
    if n != 1:
        raise SystemExit(f'{label}: expected exactly one match, found {n}')
    return text.replace(old,new,1)

def patch_engine(engine: str) -> str:
    # Any board replacement invalidates BOTH board point selections. Otherwise the
    # opposite board may silently retain two picks from the previous session.
    engine=replace_once(engine,
        "const first=changed==='source'?0:2;state.picks[first]=null;state.picks[first+1]=null;state.lastAlignmentDiagnostics=null;state.pickStage=-1;state.hover={source:null,target:null};",
        "state.picks=[null,null,null,null];state.lastAlignmentDiagnostics=null;state.pickStage=-1;state.hover={source:null,target:null};",
        'two-board point reset')

    # Use the stroke colour whenever a PDF paint operator strokes a path. For
    # fill+stroke operators, the fill colour must not hide a visible black outline.
    old_paint="""const paint=fn=>{const isFill=[O.fill,O.eoFill,O.fillStroke,O.eoFillStroke,O.closeFillStroke,O.closeEOFillStroke].includes(fn);finish([O.closeStroke,O.closeFillStroke,O.closeEOFillStroke,O.fill,O.eoFill,O.fillStroke,O.eoFillStroke].includes(fn));const color=ci(isFill?fill:stroke);if(!color.white){for(const q of subpaths){if(paths.length>=50000)throw new Error('ملف PDF يحتوي عدد مسارات يتجاوز الحد الآمن.');if(q.points.length>=2)paths.push({...q,aci:color.aci,rgb:color.rgb,lineWidth});}}subpaths=[];active=null;};"""
    new_paint="""const paint=fn=>{const fills=[O.fill,O.eoFill,O.fillStroke,O.eoFillStroke,O.closeFillStroke,O.closeEOFillStroke].includes(fn),strokes=[O.stroke,O.closeStroke,O.fillStroke,O.eoFillStroke,O.closeFillStroke,O.closeEOFillStroke].includes(fn),closes=[O.closeStroke,O.closeFillStroke,O.closeEOFillStroke,O.fill,O.eoFill,O.fillStroke,O.eoFillStroke].includes(fn);finish(closes);const fillColor=ci(fill),strokeColor=ci(stroke),color=strokes&&!strokeColor.white?strokeColor:(fills&&!fillColor.white?fillColor:null);if(color){for(const q of subpaths){if(paths.length>=50000)throw new Error('ملف PDF يحتوي عدد مسارات يتجاوز الحد الآمن.');if(q.points.length>=2)paths.push({...q,aci:color.aci,rgb:color.rgb,lineWidth,paintMode:strokes?'stroke':(fills?'fill':'unknown')});}}subpaths=[];active=null;};"""
    engine=replace_once(engine,old_paint,new_paint,'PDF independent fill/stroke paint')

    # Give the user a visible file name field before saving the oriented drawing.
    engine=replace_once(engine,
        '<div class="sq162-actions" id="sq162-project-actions"><button id="sq162-do-align"',
        '<div class="sq162-panel" style="margin-top:10px"><label for="sq162-oriented-name">اسم اللوحة الناتجة قبل الحفظ</label><input id="sq162-oriented-name" type="text" maxlength="100" autocomplete="off" placeholder="اكتب اسم ملف DXF الناتج"></div><div class="sq162-actions" id="sq162-project-actions"><button id="sq162-do-align"',
        'orientation name input insertion')

    # Add explicit name input to PDF/image-to-DXF project.
    engine=replace_once(engine,
        '<label for="sq162-raster-scale" style="margin-top:9px">عامل المقياس (وحدة رسم لكل وحدة PDF/بكسل)</label><input id="sq162-raster-scale" type="number" min="0.000001" step="any" value="1" class="sq162-scale"><div class="sq162-actions">',
        '<label for="sq162-raster-scale" style="margin-top:9px">عامل المقياس (وحدة رسم لكل وحدة PDF/بكسل)</label><input id="sq162-raster-scale" type="number" min="0.000001" step="any" value="1" class="sq162-scale"><label for="sq162-pdf-output-name" style="margin-top:9px">اسم اللوحة الناتجة قبل الحفظ</label><input id="sq162-pdf-output-name" type="text" maxlength="100" autocomplete="off" placeholder="اكتب اسم ملف DXF الناتج"><div class="sq162-actions">',
        'PDF output name input insertion')

    # Common filename sanitizer, preserving Arabic and other valid Unicode names.
    helper="""    function safeOutputBase(value,fallback){const raw=String(value??'').trim()||String(fallback??'').trim();const clean=raw.replace(/\\.(?:dxf|dwg|pdf)$/i,'').replace(/[<>:\"/\\\\|?*\\u0000-\\u001f]/g,'_').replace(/\\s+/g,'_').replace(/[. ]+$/g,'').slice(0,100);if(!clean||/^\\.+$/.test(clean))throw new Error('اكتب اسمًا صالحًا للوحة قبل الحفظ.');return clean;}\n"""
    engine=replace_once(engine,
        "    function fileTitle(file) { return file && file.name ? file.name : 'drawing'; }\n",
        "    function fileTitle(file) { return file && file.name ? file.name : 'drawing'; }\n"+helper,
        'filename sanitizer helper')

    # Seed the suggested orientation filename only when the source board loads.
    engine=replace_once(engine,
        "state[which] = { file, fingerprint, cadFingerprint, bytes:bytes.slice(), geom, viewGeom:null, transform:null, alignment:null, rasterUrl, rasterUrls };\n      state.views[which]=",
        "state[which] = { file, fingerprint, cadFingerprint, bytes:bytes.slice(), geom, viewGeom:null, transform:null, alignment:null, rasterUrl, rasterUrls };\n      if(which==='source'){const nameInput=el('sq162-oriented-name');if(nameInput)nameInput.value=safeOutputBase(file.name.replace(/\\.[^.]+$/,''),'SurveyQuant')+'_ORIENTED';}\n      state.views[which]=",
        'orientation default filename')

    # The save filename comes from the visible field, not a hidden automatic name.
    engine=replace_once(engine,
        "const base=String(src.file?.name||'SurveyQuant').replace(/\\.[^.]+$/,'').replace(/[^\\w.-]+/g,'_')||'SurveyQuant';\n        const filename=`${base}_ORIENTED.dxf`;",
        "const fallback=String(src.file?.name||'SurveyQuant').replace(/\\.[^.]+$/,'')+'_ORIENTED';\n        const filename=`${safeOutputBase(el('sq162-oriented-name')?.value,fallback)}.dxf`;",
        'orientation chosen filename')

    # Default PDF name on every new file selection. The field stays editable.
    engine=replace_once(engine,
        "rasterFileInput.addEventListener('change', () => { state.tracerFile = rasterFileInput.files[0] || null; traceBtn.disabled = !state.tracerFile; status(state.tracerFile ? `تم اختيار ${state.tracerFile.name} (${state.tracerFile.size.toLocaleString()} بايت).` : 'اختر ملفًا للبدء.', 'sq162-raster-status'); });",
        "rasterFileInput.addEventListener('change', () => { state.tracerFile = rasterFileInput.files[0] || null; traceBtn.disabled = !state.tracerFile; const nameInput=el('sq162-pdf-output-name');if(nameInput&&state.tracerFile)nameInput.value=safeOutputBase(state.tracerFile.name.replace(/\\.[^.]+$/,''),'SurveyQuant_PDF'); status(state.tracerFile ? `تم اختيار ${state.tracerFile.name} (${state.tracerFile.size.toLocaleString()} بايت).` : 'اختر ملفًا للبدء.', 'sq162-raster-status'); });",
        'PDF name default')

    # Never suffix a timestamp silently; honour the name displayed to the user.
    engine=replace_once(engine,
        "const baseName=(file.name.replace(/\\.[^.]+$/,'').replace(/[^A-Za-z0-9_.()-]/g,'_').slice(0,48)||'SurveyQuant_PDF');\n        const suffix=(Math.floor(Date.now()/1000)).toString(36),filename=`${baseName}_VECTOR_${suffix}.dxf`;",
        "const baseName=safeOutputBase(el('sq162-pdf-output-name')?.value,file.name.replace(/\\.[^.]+$/,''));\n        const filename=`${baseName}.dxf`;",
        'PDF chosen filename')

    # Surface identity selections as a hard warning directly beside computed values.
    engine=replace_once(engine,
        "if(Math.abs(d.rotationDegrees)<0.01)lines.push('تنبيه: اتجاه خط المصدر والمرجع متقارب جدًا، لذلك الدوران قريب من الصفر. راجع أن كل نقطة مرجعية تقابل النقطة نفسها في المصدر.');",
        "if(Math.hypot(d.sourceA.x-d.targetA.x,d.sourceA.y-d.targetA.y)<1e-7&&Math.hypot(d.sourceB.x-d.targetB.x,d.sourceB.y-d.targetB.y)<1e-7)lines.push('⛔ تحذير: إحداثيا نقطتي المرجع يطابقان نقطتي المصدر. لن يتم اعتماد توجيه أو تفعيل الحفظ. أعد تحميل اللوحة المرجعية أو اختر النقطتين من ملفها الصحيح.');else if(Math.abs(d.rotationDegrees)<0.01)lines.push('تنبيه: اتجاه خط المصدر والمرجع متقارب جدًا، لذلك الدوران قريب من الصفر. راجع أن كل نقطة مرجعية تقابل النقطة نفسها في المصدر.');",
        'identity diagnostics warning')

    engine=replace_once(engine,
        'const SQ_V178_ORIENTATION_CAPTURE_AND_NATIVE_SAVE = true;',
        'const SQ_V178_ORIENTATION_CAPTURE_AND_NATIVE_SAVE = true;\n  const SQ_V179_TWO_BOARD_RESET_PDF_STROKE_AND_OUTPUT_NAMES = true;',
        'V179 compatibility and feature markers')
    engine=replace_once(engine,
        'root.SurveyQuantCAD178 = api;',
        'root.SurveyQuantCAD178 = api; root.SurveyQuantCAD179 = api;',
        'V179 global API alias')
    if 'SQ_V179_TWO_BOARD_RESET_PDF_STROKE_AND_OUTPUT_NAMES' not in engine:
        raise SystemExit('V179 marker failed in engine')
    return engine

def patch(html_path: Path, engine_path: Path, check=False):
    html=html_path.read_text(encoding='utf-8')
    engine=engine_path.read_text(encoding='utf-8')
    if MARKER in html:
        if check and 'SQ_V179_TWO_BOARD_RESET_PDF_STROKE_AND_OUTPUT_NAMES' in html:
            print('PASS V179 check-only')
            return
        raise SystemExit('V179 patch already exists or is incomplete')
    updated=patch_engine(engine)
    engine_path.write_text(updated,encoding='utf-8')
    pattern=r"(<script\s+id=[\"\']sq176-cad-engine[\"\']\s*>)[\s\S]*?(</script\s*>)"
    # Python regex literal above is intentionally compiled only after the raw source check.
    hits=list(re.finditer(pattern,html,re.I))
    if len(hits)!=1:
        raise SystemExit(f'Expected one embedded CAD engine, found {len(hits)}')
    m=hits[0]
    replacement=m.group(1)+'\n'+updated.replace('</script>','<\\/script>')+'\n'+m.group(2)
    html=html[:m.start()]+replacement+html[m.end():]
    html+='\n'+MARKER+'\n<!-- V179: invalidate all four picks after either board reload; preserve stroked outlines of white-filled PDF walls/columns; ask for explicit output names. -->\n'
    html_path.write_text(html,encoding='utf-8')
    print(f'PASS V179 applied: {len(updated):,} engine characters embedded')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--html',type=Path,required=True);p.add_argument('--engine',type=Path,required=True);p.add_argument('--check-only',action='store_true');a=p.parse_args();patch(a.html,a.engine,a.check_only)
