#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const [modulePath, htmlPath, bridgePath] = process.argv.slice(2);
assert(modulePath && htmlPath && bridgePath, 'usage: test.js REFERENCE_MODULE INDEX_PATH DWG_BRIDGE');
const moduleText = fs.readFileSync(modulePath, 'utf8');
const html = fs.readFileSync(htmlPath, 'utf8');
const bridge = fs.readFileSync(bridgePath, 'utf8');
const call = 'size=sqV122NaturalTextPixels(v,t,m,p)';
for (const [label, source] of [['reference module', moduleText], ['integrated HTML', html]]) {
  assert.equal((source.match(/function sqV122NaturalTextPixels\(/g) || []).length, 1, label + ': one natural-size helper');
  assert.equal((source.match(/size=sqV122NaturalTextPixels\(v,t,m,p\)/g) || []).length, 1, label + ': renderer calls helper exactly once');
  assert(source.includes('function universalTransformBytes(input,t)'), label + ': byte-preserving transform missing');
  assert(!source.includes('size=Math.max(5.5,Math.min(15,'), label + ': fixed 5.5–15 px text clamp remains');
  assert(!source.includes('size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale'), label + ': legacy text formula remains');
}
assert(html.includes('id="sq-v122-universal-dwg-bridge"'), 'V122 DWG bridge is not embedded');
assert.equal((html.match(/id="sq-v122-universal-dwg-bridge"/g)||[]).length,1,'exactly one V122 bridge');
assert(bridge.includes('ACCEPT_TYPES') && bridge.includes('MutationObserver'), 'DWG accept list / dynamic-picker observer missing');
assert(bridge.includes('window.sqOriConvertTargetToDxf'), 'shared LibreDWG converter hook missing');
assert.equal(bridge.split('/\\.dwg$/i').length-1,4,'four correct .dwg matchers');
assert(!bridge.includes('\\\\.dwg'), 'double-escaped DWG matcher remains');
const setter = moduleText.match(/function setZoom\(side,value\)\{[^}]*\}/);
assert(setter && !/v\.bytes\s*=|v\.drawing\.[\w$]+\s*=/.test(setter[0]), 'zoom must not mutate original file bytes/entity model');

// Execute the helper with the same affine screen projection as the renderer. It must be proportional
// to the geometry scale and zoom, including below the old fixed 5.5px minimum.
const fnMatch = moduleText.match(/function sqV122NaturalTextPixels\(v,t,m,p\)\{[\s\S]*?\n\}/);
assert(fnMatch, 'could not extract natural text pixel function');
const context = {
  Math, Number, Object,
  project(v, pt, m) { const factor=m.scale*(Number(v.zoom)||1); return {x:pt.x*factor+(v.panX||0), y:-pt.y*factor+(v.panY||0)}; }
};
const sizeFn = vm.runInNewContext('('+fnMatch[0]+')', context);
function calc(height, scale, zoom) {
  const v={zoom,panX:91,panY:-17}, t={height,p:{x:100,y:200}}, m={scale};
  const p=context.project(v,t.p,m), before=JSON.stringify(t);
  const size=sizeFn(v,t,m,p);
  assert.equal(JSON.stringify(t),before,'text/entity object mutated while measuring size');
  return size;
}
assert(Math.abs(calc(2.5,0.001,1)-0.0025)<1e-10, 'small-scale text must shrink below 5.5 px, not stay fixed');
assert(Math.abs(calc(2.5,0.001,4)-0.01)<1e-10, 'text must scale 4x when view zoom scales 4x');
assert(Math.abs(calc(2.5,0.4,2)-2.0)<1e-10, 'text pixel height must equal its projected CAD height');
assert(Math.abs(calc(-3,0.2,1)-0.6)<1e-10, 'negative mirrored CAD text height must use its absolute physical height');

// Execute the real bridge's conversion API and confirm a DWG becomes a new DXF-named file.
(async()=>{
  const mockDocument={nodeType:9,documentElement:{},querySelectorAll(){return [];},addEventListener(){}};
  class MockMutationObserver { observe(){} }
  const win={sqOriConvertTargetToDxf:async()=>new Uint8Array([65,67,49,48,10])};
  vm.runInNewContext(bridge,{window:win,document:mockDocument,MutationObserver:MockMutationObserver,File,Blob,ArrayBuffer,Uint8Array,Date,Promise,console,Event});
  const original=new File([new Uint8Array([1,2,3])],'storm.DWG',{type:'application/octet-stream'});
  const converted=await win.__sqV122DwgBridgeAPI.convertOne(original);
  assert.equal(converted.name,'storm.dxf','converted filename extension must be DXF');
  assert.equal(converted.type,'application/dxf','converted MIME type must be DXF');
  assert.equal(converted.size,5,'converted DXF bytes must be retained');
  console.log('PASS V122: dynamic projected text size (4 numeric cases), no fixed font clamp, no zoom mutation, DWG bridge conversion, and preservation guards.');
})().catch(e=>{console.error(e);process.exitCode=1;});
