#!/usr/bin/env python3
from __future__ import annotations
import argparse, base64, re
from pathlib import Path

META='<meta name="surveyquant-v169" content="sq169-orientation-save-block-axis-content-identity-single-dxf-ole">'
SLOT=re.compile(r'(<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">)([A-Za-z0-9+/=\r\n]+)(</script>)',re.I)

def embed_engine(html:str, engine:bytes)->str:
    b64=base64.b64encode(engine).decode('ascii')
    result,n=SLOT.subn(lambda m:m.group(1)+b64+m.group(3),html,count=1)
    if n!=1:raise ValueError(f'Expected exactly one embedded CAD engine slot, found {n}')
    return result

def patch_html(html:str,engine:bytes)->str:
    if 'sq168-pdf-access-axis-points-explicit-snap-fix' not in html:raise ValueError('V168 baseline must be present first')
    if 'sq169-orientation-save-block-axis-content-identity-single-dxf-ole' in html:raise ValueError('V169 patch already applied')
    for marker in ('sq167-dwg-orientation-view-transform','sq166-readonly-source-and-exact-pdf-raster','sq164-cad-output-axis-fix','sq163-cad-engine','sq163-pdfjs-worker','sq162-wasm-binary','sq163RawCadOverlayMerge'):
        if marker not in html:raise ValueError('Missing V168 app marker: '+marker)
    head=re.search(r'<head\b[^>]*>',html,re.I)
    if not head:raise ValueError('HTML head not found')
    html=html[:head.end()]+META+html[head.end():]
    # Pass the one byte read from the file picker through DWG worker and DXF parser.
    edits=[
      (' const buffer=await file.arrayBuffer();\n const requestId=++sqDwgWorkerRequestId;',
       ' const supplied=options.sourceBytes;\n const buffer=supplied instanceof Uint8Array ? supplied.buffer.slice(supplied.byteOffset,supplied.byteOffset+supplied.byteLength) : await file.arrayBuffer();\n const requestId=++sqDwgWorkerRequestId;'),
      ('  const sourceBytes=new Uint8Array(await file.arrayBuffer());\n  if(sourceBytes.length < 16)',
       '  const sourceBytes=options.sourceBytes instanceof Uint8Array ? options.sourceBytes.slice() : new Uint8Array(await file.arrayBuffer());\n  if(sourceBytes.length < 16)'),
      (" const bytes=new Uint8Array(await file.arrayBuffer());\n if(ext==='dxf')",
       " const bytes=options.sourceBytes instanceof Uint8Array ? options.sourceBytes.slice() : new Uint8Array(await file.arrayBuffer());\n if(ext==='dxf')")]
    for old,new in edits:
        if html.count(old)!=1:raise ValueError('Expected unique sourceBytes insertion point not found: '+old[:70].replace('\n','\\n'))
        html=html.replace(old,new,1)
    if 'window.parseFile = parseFile;' not in html:raise ValueError('Shared parseFile export missing')
    html=html.replace('window.parseFile = parseFile;','window.parseFile = parseFile; // sq169-source-bytes-single-read-file-content-identity',1)
    html=embed_engine(html,engine)
    validate(html,engine)
    return html

def validate(html:str,engine:bytes)->None:
    for marker in ('sq169-orientation-save-block-axis-content-identity-single-dxf-ole','sq168-pdf-access-axis-points-explicit-snap-fix','sq167-dwg-orientation-view-transform','sq166-readonly-source-and-exact-pdf-raster','sq164-cad-output-axis-fix','sq169-source-bytes-single-read-file-content-identity'):
        if marker not in html:raise ValueError('V169 HTML missing marker: '+marker)
    match=SLOT.search(html)
    if not match or base64.b64decode(match.group(2))!=engine:raise ValueError('Embedded V169 engine is not byte-identical to tested engine')
    text=engine.decode('utf-8')
    required=('SQ_V169_ORIENTATION_DXF_SAVE_AXIS_BLOCKFIX_SAME_NAME_AND_SINGLE_DXF_PDF',
      'function createOrientedDxfBytes','function fileFingerprint','function makeEmbeddedRasterDxf',
      "el('sq162-save-oriented').addEventListener",'state.source.alignment={picks:picked,createdAt:Date.now()}',
      "input.addEventListener('click',()=>{input.value='';})",'loadSerial:{source:0,target:0}',
      'main.construction.push({...ray,origin:o,direction:{x:dx,y:dy}})',
      'تم إخراج ملف DXF واحد فقط','Paintbrush Picture')
    for marker in required:
        if marker not in text:raise ValueError('V169 engine missing required behavior: '+marker)
    if 'يتم تسليم DXF والصورة المرجعية معًا داخل ZIP' in text:raise ValueError('Old PDF ZIP export message remains')
    if 'zipStore([{name:dxfName,data:dxfBytes},{name:imageName,data:pngBytes}])' in text:raise ValueError('Old ZIP PDF export route remains')
    if 'ImageTracer.imagedataToSVG' in text:raise ValueError('PDF image tracing is still active')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--html',type=Path,required=True);ap.add_argument('--engine',type=Path,required=True);ap.add_argument('--check-only',action='store_true');a=ap.parse_args()
    html=a.html.read_text(encoding='utf-8');engine=a.engine.read_bytes()
    if a.check_only:validate(html,engine);print('PASS V169 HTML + embedded engine validation');return
    out=patch_html(html,engine);a.html.write_text(out,encoding='utf-8');print(f'PASS V169 patch applied: {a.html} ({len(out):,} HTML chars)')
if __name__=='__main__':main()
