# SurveyQuant v1.0.162 CAD tools: third-party notices

The optional image/PDF-to-DXF utility embeds these open-source browser libraries locally, so conversion does not require a paid API or external network service after installation:

- **ImageTracerJS**: https://github.com/jankovicsandras/imagetracerjs
  Open-source raster-to-vector tracing library. The build includes the upstream license file when available.
- **PDF.js**: https://github.com/mozilla/pdf.js
  Mozilla's PDF rendering library, distributed under Apache License 2.0. The build includes the upstream license file when available.
- **LibreDWG**: https://www.gnu.org/software/libredwg/
  Existing DWG-to-DXF conversion engine already included in SurveyQuant's shared CAD runtime; its licensing and notices remain as supplied by the existing runtime bundle.

The generated DXF from a raster image or scanned PDF is a vector trace, not recovery of original CAD entities, layers, texts, coordinates, or scale. Validate dimensions against a known measurement before using it for surveying.
