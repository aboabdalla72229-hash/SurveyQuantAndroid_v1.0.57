#!/usr/bin/env python3
"""SurveyQuant v126: layer-aware CAD preview, board-only zoom, and safe geometry transform."""
from pathlib import Path
import re, sys
if len(sys.argv) != 3:
    raise SystemExit('usage: patch-v126-cad.py MANUAL_MODULE.js REFERENCE_MODULE.js')
manual_path, ref_path = map(Path, sys.argv[1:])
manual = manual_path.read_text(encoding='utf-8')
ref = ref_path.read_text(encoding='utf-8')

def sub_once(src, old, new, label):
    n = src.count(old)
    if n != 1:
        raise SystemExit(f'ERROR: expected exactly one anchor for {label}; found {n}')
    return src.replace(old, new, 1)

# 1) Parse DXF layer table and attach each entity's real layer styling to the
# rendered primitives. Geometry stays in its original CAD coordinates.
manual = sub_once(manual,
" const pairs=parsePairs(byteText(bytes)),sections=sectionsFromPairs(pairs),blocks=Object.create(null);",
" const pairs=parsePairs(byteText(bytes)),sections=sectionsFromPairs(pairs),blocks=Object.create(null),layers=Object.create(null);\n for(const lr of (sections.TABLES||[])){if(lr.type!=='LAYER')continue;const lp=lr.pairs||[],name=str(lp,2,'0'),rawAci=num(lp,62,0,7),tc=num(lp,420,0,-1),lw=num(lp,370,0,-1),lt=str(lp,6,'CONTINUOUS').toUpperCase();layers[name.toUpperCase()]={name,aci:Math.abs(rawAci)||7,trueColor:tc>=0?tc:null,lineweight:lw,linetype:lt,off:rawAci<0};}\n const styleFromPairs=p=>{const layer=str(p,8,'0')||'0',ld=layers[layer.toUpperCase()]||{aci:7,trueColor:null,lineweight:-1,linetype:'CONTINUOUS',off:false};const rawAci=num(p,62,0,256),entityTc=num(p,420,0,-1),useLayer=rawAci===256||rawAci===0;return {layer,aci:useLayer?ld.aci:(Math.abs(rawAci)||7),trueColor:entityTc>=0?entityTc:(useLayer?ld.trueColor:null),lineweight:(num(p,370,0,-1)>=0?num(p,370,0,-1):ld.lineweight),linetype:str(p,6,ld.linetype||'CONTINUOUS').toUpperCase(),off:(rawAci<0)||!!ld.off};};",
'layer table and entity style resolver')
manual = sub_once(manual,
" const segs=[],anchors=[],texts=[];let unsupported=0,entityCount=0;\n const addPoint=p=>{if(p&&Number.isFinite(p.x)&&Number.isFinite(p.y)){anchors.push(p);return p;}return null;};\n const addSeg=(a,b)=>{if(!a||!b)return;if(Math.hypot(b.x-a.x,b.y-a.y)>1e-10){segs.push({a,b});addPoint(a);addPoint(b);}};\n function localGeometry(e,mat){const t=e.type,p=e.pairs,layer=str(p,8,'0');entityCount++;",
" const segs=[],anchors=[],texts=[],fills=[];let unsupported=0,entityCount=0,activeStyle={layer:'0',aci:7,trueColor:null,lineweight:-1,linetype:'CONTINUOUS',off:false},activeEntityType='';\n const addPoint=p=>{if(p&&Number.isFinite(p.x)&&Number.isFinite(p.y)){anchors.push({...p,...activeStyle,entityType:activeEntityType,pointEntity:activeEntityType==='POINT'});return p;}return null;};\n const addSeg=(a,b)=>{if(!a||!b)return;if(Math.hypot(b.x-a.x,b.y-a.y)>1e-10){segs.push({a,b,...activeStyle,entityType:activeEntityType});addPoint(a);addPoint(b);}};\n function localGeometry(e,mat){const t=e.type,p=e.pairs,layer=str(p,8,'0');activeStyle=styleFromPairs(p);activeEntityType=t;entityCount++;",
'layer-aware drawing primitives')
manual = sub_once(manual,
"const pos=mapped(pairPoint(p,10));if(pos){addPoint(pos);const label=textValue(p);if(label)texts.push({p:pos,text:label,layer});}return;",
"const pos=mapped(pairPoint(p,10));if(pos){addPoint(pos);const label=textValue(p);if(label)texts.push({p:pos,text:label,...activeStyle,height:num(p,40,0,2.5),rotation:num(p,50,0,0),widthFactor:num(p,41,0,1),entityType:t});}return;",
'CAD text style data')
manual = sub_once(manual,
"   const e=list[i];if(e.type==='POLYLINE'){",
"   const e=list[i];activeStyle=styleFromPairs(e.pairs||[]);activeEntityType=e.type;if(e.type==='POLYLINE'){",
'legacy polyline layer styling')
manual = sub_once(manual,
"function localGeometry(e,mat){const t=e.type,p=e.pairs,layer=str(p,8,'0');activeStyle=styleFromPairs(p);activeEntityType=t;entityCount++;",
"function localGeometry(e,mat,inheritedLayer='0'){const t=e.type,p=e.pairs,rawLayer=str(p,8,'0'),layer=rawLayer==='0'?inheritedLayer:rawLayer,stylePairs=rawLayer==='0'&&layer!=='0'?p.map(q=>q.code===8?{...q,value:layer}:q):p;activeStyle=styleFromPairs(stylePairs);activeEntityType=t;entityCount++;",
'layer-0 child style inheritance')
manual = sub_once(manual,
"function expand(list,mat,depth=0,visited=new Set()){",
"function expand(list,mat,depth=0,visited=new Set(),inheritedLayer='0'){",
'block recursion carries inherited layer')
manual = sub_once(manual,
"const e=list[i];activeStyle=styleFromPairs(e.pairs||[]);activeEntityType=e.type;if(e.type==='POLYLINE'){",
"const e=list[i];const rawLayer=str(e.pairs||[],8,'0'),effectiveLayer=rawLayer==='0'?inheritedLayer:rawLayer,stylePairs=rawLayer==='0'&&effectiveLayer!=='0'?(e.pairs||[]).map(q=>q.code===8?{...q,value:effectiveLayer}:q):(e.pairs||[]);activeStyle=styleFromPairs(stylePairs);activeEntityType=e.type;if(e.type==='POLYLINE'){",
'block insert effective style')
manual = sub_once(manual,
"expand(b.entities,compose(mat,lm),depth+1,nv);",
"const parentLayer=str(e.pairs,8,'0'),childLayer=parentLayer==='0'?inheritedLayer:parentLayer;expand(b.entities,compose(mat,lm),depth+1,nv,childLayer);",
'layer inheritance through nested INSERTs')
manual = sub_once(manual,
"localGeometry(e,mat);",
"localGeometry(e,mat,inheritedLayer);",
'pass inherited layer to leaf entities')

# Improve board preview for common hatch boundaries, multiline entities, and dimension annotation blocks.
manual = sub_once(manual,
"function localGeometry(e,mat,inheritedLayer='0'){",
"""function drawHatchPolylineBoundary(e,mat){
 const p=e.pairs||[],i91=p.findIndex(q=>q.code===91);if(i91<0)return false;
 const pathCount=Math.max(0,Math.min(10000,Number(p[i91].value)||0));let i=i91+1,drawn=false;
 for(let path=0;path<pathCount&&i<p.length;path++){
  while(i<p.length&&p[i].code!==92)i++;if(i>=p.length)break;const flags=Number(p[i++].value)||0;
  let i72=-1,i73=-1,i93=-1;for(let j=i;j<p.length;j++){if(p[j].code===92)break;if(p[j].code===72&&i72<0)i72=j;if(p[j].code===73&&i73<0)i73=j;if(p[j].code===93){i93=j;break;}}
  if(i93<0)break;const isPolyline=!!(flags&2),hasBulge=i72>=0&&Number(p[i72].value)===1,closed=i73>=0&&Number(p[i73].value)===1,count=Math.max(0,Math.min(20000,Number(p[i93].value)||0));i=i93+1;
  if(!isPolyline){while(i<p.length&&p[i].code!==92)i++;continue;}
  const pts=[];for(let n=0;n<count&&i<p.length;n++){while(i<p.length&&p[i].code!==10&&p[i].code!==92)i++;if(i>=p.length||p[i].code!==10)break;const x=Number(p[i++].value);while(i<p.length&&p[i].code!==20&&p[i].code!==92)i++;if(i>=p.length||p[i].code!==20)break;const y=Number(p[i++].value);let bulge=0;if(hasBulge&&i<p.length&&p[i].code===42)bulge=Number(p[i++].value)||0;if(Number.isFinite(x)&&Number.isFinite(y))pts.push({p:{x,y},bulge});}
  if(pts.length>=2){const solid=Number(p.find(q=>q.code===70)?.value)===1;if(solid&&closed&&pts.length>=3)fills.push({points:pts.map(v=>applyMatrix(mat,v.p)),...activeStyle,layer:activeStyle.layer});const total=closed?pts.length:pts.length-1;for(let j=0;j<total;j++){const a=pts[j],b=pts[(j+1)%pts.length];if(Math.abs(a.bulge)<1e-10){addSeg(applyMatrix(mat,a.p),applyMatrix(mat,b.p));continue;}const dx=b.p.x-a.p.x,dy=b.p.y-a.p.y,chord=Math.hypot(dx,dy),bulge=a.bulge;if(chord<1e-10)continue;const theta=4*Math.atan(bulge),offset=chord*(1-bulge*bulge)/(4*bulge),cx=(a.p.x+b.p.x)/2-dy/chord*offset,cy=(a.p.y+b.p.y)/2+dx/chord*offset,r=Math.hypot(a.p.x-cx,a.p.y-cy),start=Math.atan2(a.p.y-cy,a.p.x-cx),steps=Math.max(4,Math.min(128,Math.ceil(Math.abs(theta)*16)));let prev=applyMatrix(mat,a.p);for(let k=1;k<=steps;k++){const ang=start+theta*k/steps,cur=applyMatrix(mat,{x:cx+r*Math.cos(ang),y:cy+r*Math.sin(ang)});addSeg(prev,cur);prev=cur;}}drawn=true;}
 }return drawn;
}
function localGeometry(e,mat,inheritedLayer='0'){""",
'polyline hatch boundary parser')
manual = sub_once(manual,
"  if(t==='POLYLINE')return;",
"  if(t==='POLYLINE')return;\n  if(t==='HATCH'){if(!drawHatchPolylineBoundary(e,mat))unsupported++;return;}\n  if(t==='MLINE'){const xs=vals(p,11),ys=vals(p,21),pts=xs.slice(0,Math.min(xs.length,ys.length)).map((x,i)=>mapped({x,y:ys[i]}));for(let i=1;i<pts.length;i++)addSeg(pts[i-1],pts[i]);if(pts.length<2)unsupported++;return;}",
'HATCH and MLINE preview')
manual = sub_once(manual,
"   if(e.type==='VERTEX'||e.type==='SEQEND'||e.type==='ENDBLK'||e.type==='BLOCK')continue;",
"   if(e.type==='DIMENSION'){const name=str(e.pairs,2,'').toUpperCase(),b=blocks[name];if(b&&!visited.has(name)){const nv=new Set(visited);nv.add(name);expand(b.entities,mat,depth+1,nv,effectiveLayer);}else if(!b){const q=pairPoint(e.pairs,11)||pairPoint(e.pairs,10),label=str(e.pairs,1,'')||String(num(e.pairs,42,0,0));if(q&&label&&label!=='<>')texts.push({p:applyMatrix(mat,q),text:label,...activeStyle,height:num(e.pairs,40,0,2.5),rotation:num(e.pairs,53,0,num(e.pairs,50,0,0)),entityType:'DIMENSION'});else unsupported++;}entityCount++;continue;}\n   if(e.type==='VERTEX'||e.type==='SEQEND'||e.type==='ENDBLK'||e.type==='BLOCK')continue;",
'dimension anonymous-block preview')
manual = sub_once(manual,
" return {segs,anchors,texts,bounds:{minX,minY,maxX,maxY},entityCount,unsupported};",
" return {segs,anchors,texts,fills,layers,bounds:{minX,minY,maxX,maxY},entityCount,unsupported,sourceFormat:'DXF'};",
'layer table exposed to board viewer')

# 2) Replace the transformer with a byte-preserving transform over real geometry
# records. Regular block definitions stay local to their INSERTs; DIMENSION
# anonymous-block geometry is transformed too. Paper space is transformed only
# when the file has no transformable model-space geometry, preventing a silent
# no-op on drawings whose board was saved exclusively in paper space.
start = ref.find('function universalTransformBytes(input,t){')
end = ref.find('\nfunction solve(src1,src2,ref1,ref2){', start)
if start < 0 or end < 0:
    raise SystemExit('ERROR: universalTransformBytes replacement anchors missing')
new_transform = r'''function universalTransformBytes(input,t){
 const parsed=splitPairs(input),bytes=parsed.bytes,pairs=parsed.pairs;
 if(ascii(bytes,0,Math.min(bytes.length,22)).includes('AutoCAD Binary DXF'))throw new Error('هذا DXF ثنائي. احفظه بصيغة DXF نصية ASCII.');
 if(!t||![t.scale,t.angleDeg,t.tx,t.ty].every(Number.isFinite)||typeof t.point!=='function'||typeof t.vector!=='function')throw new Error('معاملات توجيه اللوحة غير مكتملة. لم يتم إنشاء ملف.');
 const all=sectionRecords(pairs,'ENTITIES');
 if(!all.length)throw new Error('ملف DXF لا يحتوي على كيانات في قسم ENTITIES؛ أوقفنا الإسقاط حتى لا يتم تنزيل ملف فارغ.');
 const isPaper=rec=>rec.pairs.some(p=>p.code===67&&Number(p.value)===1);
 const hasXY=rec=>{const codes=new Set(rec.pairs.map(p=>p.code));for(let x=10;x<=18;x++)if(codes.has(x)&&codes.has(x+10))return true;return rec.type==='POINT'||rec.type==='INSERT'||rec.type==='HATCH'||rec.type==='DIMENSION';};
 const model=all.filter(r=>!isPaper(r)),paper=all.filter(isPaper);
 const modelHasGeometry=model.some(hasXY),paperFallback=!modelHasGeometry&&paper.some(hasXY);
 const records=modelHasGeometry?model:(paperFallback?paper:[]);
 if(!records.length)throw new Error('لم أجد كيانات هندسية قابلة للتحويل في Model Space أو Paper Space. قد تكون اللوحة مرجعًا خارجيًا أو محتوى CAD خاصًا لا يكشف إحداثياته. لم يتم حفظ إسقاط فارغ.');
 const dimBlockNames=new Set(all.filter(r=>r.type==='DIMENSION').map(r=>recordString(r,2).toUpperCase()).filter(Boolean));
 const blockRecords=sectionRecords(pairs,'BLOCKS');let activeBlock='',dimensionBlockEntities=[];
 for(const rec of blockRecords){if(rec.type==='BLOCK'){activeBlock=recordString(rec,2).toUpperCase();continue;}if(rec.type==='ENDBLK'){activeBlock='';continue;}if(activeBlock&&dimBlockNames.has(activeBlock))dimensionBlockEntities.push(rec);}
 const edits=new Map();let transformedEntities=0,changedEntityCount=0,unchangedOpaque=0,coordinateEntities=0;
 const numeric=v=>{const n=Number(v);return Number.isFinite(n)?n:null;};
 const format=n=>{if(!Number.isFinite(n))throw new Error('التحويل أنتج إحداثيًا غير صالح.');if(Math.abs(n)<5e-13)n=0;return Number(n.toPrecision(15)).toString();};
 const identity=Math.abs(t.scale-1)<1e-12&&Math.abs(t.angleDeg)<1e-10&&Math.abs(t.tx)<1e-8&&Math.abs(t.ty)<1e-8;
 function transformRecord(rec, countForEntity=true){
  const p=rec.pairs,by=new Map();for(const x of p){if(!by.has(x.code))by.set(x.code,[]);by.get(x.code).push(x);}
  const pairOwner=new Map();if(rec.type==='POLYLINE'){let owner='POLYLINE';for(const item of p){if(item.code===0)owner=String(item.value||'').toUpperCase();pairOwner.set(item.index,owner);}}
  let entityChanged=false,exposed=false;
  const change=(pair,value)=>{if(!pair||!Number.isFinite(value))return;const old=numeric(pair.value);if(old===null)return;if(Math.abs(value-old)<=Math.max(1e-10,Math.abs(old)*1e-13))return;edits.set(pair.index,{pair,value:format(value)});entityChanged=true;};
  function xy(xc,yc,mode='point'){
   const xs=by.get(xc)||[],ys=by.get(yc)||[];
   for(let j=0;j<Math.min(xs.length,ys.length);j++){
    if(rec.type==='POLYLINE'&&xc===10&&pairOwner.get(xs[j].index)!=='VERTEX')continue;
    const x=numeric(xs[j].value),y=numeric(ys[j].value);if(x===null||y===null)continue;exposed=true;
    const q=mode==='vector'?t.vector(x,y):t.point(x,y);change(xs[j],q.x);change(ys[j],q.y);
   }
  }
  for(let xc=10;xc<=18;xc++){
   let mode='point';
   if((rec.type==='MTEXT'||rec.type==='ELLIPSE'||rec.type==='RAY'||rec.type==='XLINE')&&xc===11)mode='vector';
   if(rec.type==='IMAGE'&&(xc===11||xc===12))mode='vector';
   if(rec.type==='SPLINE'&&(xc===12||xc===13))mode='vector';
   xy(xc,xc+10,mode);
  }
  if(rec.type==='HATCH'){xy(43,44,'point');xy(45,46,'vector');}
  // Uniform scale changes geometry-dependent sizes, never layer/color/handle/XData.
  const scaleCodes=[];
  if(['CIRCLE','ARC','TEXT','MTEXT','ATTRIB','ATTDEF'].includes(rec.type))scaleCodes.push(40);
  if(rec.type==='MTEXT')scaleCodes.push(41,44);
  if(rec.type==='INSERT')scaleCodes.push(41,42,43);
  if(rec.type==='HATCH')scaleCodes.push(41);
  if(rec.type==='DIMENSION')scaleCodes.push(42);
  if(by.has(48))scaleCodes.push(48);
  for(const code of new Set(scaleCodes))for(const pair of by.get(code)||[]){const n=numeric(pair.value);if(n!==null&&n!==0)change(pair,n*t.scale);}
  let rotationCodes=[];
  if(['ARC','INSERT','TEXT','ATTRIB','ATTDEF'].includes(rec.type))rotationCodes=[50,...(rec.type==='ARC'?[51]:[])];
  if(rec.type==='MTEXT'&&!(by.has(11)&&by.has(21)))rotationCodes=[50];
  if(rec.type==='HATCH')rotationCodes=[52,53];
  if(rec.type==='DIMENSION')rotationCodes=[50,53];
  for(const code of rotationCodes)for(const pair of by.get(code)||[]){const n=numeric(pair.value);if(n!==null)change(pair,((n+t.angleDeg)%360+360)%360);}
  if(exposed)coordinateEntities++;
  if(entityChanged){if(countForEntity)changedEntityCount++;transformedEntities++;}
  else if(!exposed&&!['SEQEND','VERTEX'].includes(rec.type))unchangedOpaque++;
 }
 const seen=new Set();for(const rec of records){if(!seen.has(rec.start)){transformRecord(rec,true);seen.add(rec.start);}}
 // Anonymous dimension graphics are stored in BLOCKS, not ENTITIES, in many
 // DWG-to-DXF conversions. Transform only blocks referenced by DIMENSIONs so
 // ordinary INSERT block definitions remain local and are never double-moved.
 for(const rec of dimensionBlockEntities){if(!seen.has(rec.start)){transformRecord(rec,false);seen.add(rec.start);}}
 const geometryChangedFields=edits.size;
 // Keep CAD zoom/view state in sync with the transformed coordinates. Leaving
 // $EXTMIN/$EXTMAX/$VIEWCTR at the source coordinates can make a valid projected
 // drawing open outside the saved viewport and appear completely empty.
 const headerVars=new Map();let inHeader=false,headerName='';
 for(let i=0;i<pairs.length;i++){const pair=pairs[i];if(pair.code===0&&String(pair.value).toUpperCase()==='SECTION'){inHeader=String(pairs[i+1]?.value||'').toUpperCase()==='HEADER';headerName='';i++;continue;}if(pair.code===0&&String(pair.value).toUpperCase()==='ENDSEC'){inHeader=false;headerName='';continue;}if(!inHeader)continue;if(pair.code===9){headerName=String(pair.value||'').toUpperCase();if(!headerVars.has(headerName))headerVars.set(headerName,[]);continue;}if(headerName)headerVars.get(headerName).push(pair);}
 const headerPoint=name=>{const list=headerVars.get(name);if(!list)return null;const x=list.find(p=>p.code===10),y=list.find(p=>p.code===20);if(!x||!y)return null;const xx=numeric(x.value),yy=numeric(y.value);return xx===null||yy===null?null:{x,y,xx,yy,list};};
 const writeHeader=(pair,value)=>{if(!pair||!Number.isFinite(value))return;const old=numeric(pair.value);if(old===null)return;if(Math.abs(value-old)<=Math.max(1e-10,Math.abs(old)*1e-13))return;edits.set(pair.index,{pair,value:format(value)});};
 const updateHeaderBounds=(minimum,maximum)=>{const lo=headerPoint(minimum),hi=headerPoint(maximum);if(!lo||!hi)return;const corners=[t.point(lo.xx,lo.yy),t.point(hi.xx,lo.yy),t.point(lo.xx,hi.yy),t.point(hi.xx,hi.yy)];const xs=corners.map(p=>p.x),ys=corners.map(p=>p.y);writeHeader(lo.x,Math.min(...xs));writeHeader(lo.y,Math.min(...ys));writeHeader(hi.x,Math.max(...xs));writeHeader(hi.y,Math.max(...ys));};
 updateHeaderBounds('$EXTMIN','$EXTMAX');updateHeaderBounds('$LIMMIN','$LIMMAX');if(paperFallback)updateHeaderBounds('$PEXTMIN','$PEXTMAX');
 for(const name of ['$VIEWCTR','$INSBASE','$SNAPBASE','$UCSORG']){const pt=headerPoint(name);if(pt){const q=t.point(pt.xx,pt.yy);writeHeader(pt.x,q.x);writeHeader(pt.y,q.y);}}
 const viewSize=headerVars.get('$VIEWSIZE')?.find(p=>p.code===40);if(viewSize){const n=numeric(viewSize.value);if(n!==null&&n>0)writeHeader(viewSize,n*t.scale);}
 if(!identity&&geometryChangedFields===0)throw new Error('لم يتغير أي إحداثي رغم أن التوجيه يتطلب حركة/دوران/مقياس. لم يتم تنزيل الملف حتى لا يبدو الإسقاط ناجحًا وهو لم يحرّك اللوحة. راجع النقطتين المختارتين ومحتوى اللوحة.');
 const ordered=Array.from(edits.values()).sort((a,b)=>a.pair.valueStart-b.pair.valueStart),chunks=[];let cursor=0,total=0;
 for(const item of ordered){chunks.push(bytes.slice(cursor,item.pair.valueStart));const replacement=new TextEncoder().encode(item.value);chunks.push(replacement);total+=item.pair.valueStart-cursor+replacement.length;cursor=item.pair.valueEnd;}
 chunks.push(bytes.slice(cursor));total+=bytes.length-cursor;const output=new Uint8Array(total);let offset=0;for(const chunk of chunks){output.set(chunk,offset);offset+=chunk.length;}
 const outPairs=splitPairs(output).pairs;
 const entitiesSectionIndex=outPairs.findIndex((p,i)=>p.code===0&&String(p.value).toUpperCase()==='SECTION'&&outPairs[i+1]?.code===2&&String(outPairs[i+1]?.value).toUpperCase()==='ENTITIES');
 const outRecords=sectionRecords(outPairs,'ENTITIES');
 const terminalPair=outPairs[outPairs.length-1];
 if(!outPairs.some(p=>p.code===0&&String(p.value).toUpperCase()==='SECTION')||entitiesSectionIndex<0||!outRecords.length||terminalPair?.code!==0||String(terminalPair?.value).toUpperCase()!=='EOF')throw new Error('ناتج الإسقاط لم يجتز فحص SECTION/ENTITIES/EOF؛ لم يتم تنزيل DXF غير مكتمل.');
 if(outRecords.length!==all.length)throw new Error('عدد كيانات ENTITIES تغيّر أثناء الإسقاط ('+all.length+' إلى '+outRecords.length+'). تم إلغاء التصدير حفاظًا على اللوحة كاملة.');
 return {bytes:output,transformedCount:transformedEntities,changedEntityCount,changedFields:ordered.length,unchangedOpaque,coordinateEntities,entitiesBefore:all.length,entitiesAfter:outRecords.length,layersPreserved:true,dimensionBlocksTransformed:dimensionBlockEntities.length,paperSpaceFallback:paperFallback};
}'''
ref = ref[:start] + new_transform + ref[end:]

# Layer information for supplemental / proxy-ish entities in the recovery preview.
old_geo = """ const raw=recordGeometry(rec),mapPoint=p=>parent({x:p.x,y:p.y});empty.pts.push(...raw.pts.map(mapPoint));empty.segments.push(...raw.segments.map(seg=>({a:mapPoint(seg.a),b:mapPoint(seg.b)})));
 if(['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(rec.type)){const p=pointAt(rec,10),txt=rec.pairs.filter(x=>x.code===1||x.code===3).map(x=>x.value).join('');if(p&&txt)empty.texts.push({p:parent(p),text:txt.replace(/\\P/g,' ').replace(/[{}]/g,' ').trim().slice(0,180)});}return empty;}"""
new_geo = """ const raw=recordGeometry(rec),mapPoint=p=>parent({x:p.x,y:p.y}),layer=recordString(rec,8)||'0',aci=pairVal(rec,62),tc=pairVal(rec,420),lw=pairVal(rec,370),lt=recordString(rec,6)||'CONTINUOUS';
 const style={layer,aci,trueColor:tc,lineweight:lw,linetype:lt.toUpperCase(),entityType:rec.type};
 empty.pts.push(...raw.pts.map(p=>({...mapPoint(p),...style,pointEntity:rec.type==='POINT'})));empty.segments.push(...raw.segments.map(seg=>({a:mapPoint(seg.a),b:mapPoint(seg.b),...style})));
 if(['TEXT','MTEXT','ATTRIB','ATTDEF','DIMENSION','MLEADER','LEADER'].includes(rec.type)){const p=pointAt(rec,10)||pointAt(rec,11),txt=rec.pairs.filter(x=>x.code===1||x.code===3).map(x=>x.value).join('');if(p&&txt)empty.texts.push({p:parent(p),text:txt.replace(/\\P/g,' ').replace(/[{}]/g,' ').trim().slice(0,250),...style,height:pairVal(rec,40)||2.5,rotation:pairVal(rec,50)||0});}return empty;}"""
ref = sub_once(ref, old_geo, new_geo, 'style-aware fallback geometry')

# Layer table parsed directly from the DXF pair stream (also works if the main renderer had to recover).
layer_anchor = "function parsePreview(bytes){"
layer_helper = """function layerDefinitions(pairs){const out=Object.create(null);for(const rec of sectionRecords(pairs,'TABLES')){if(rec.type!=='LAYER')continue;const name=recordString(rec,2)||'0',raw=pairVal(rec,62)??7,tc=pairVal(rec,420),lw=pairVal(rec,370)??-1,lt=(recordString(rec,6)||'CONTINUOUS').toUpperCase();out[name.toUpperCase()]={name,aci:Math.abs(raw)||7,trueColor:tc,lineweight:lw,linetype:lt,off:raw<0};}return out;}\nfunction parsePreview(bytes){"""
ref = sub_once(ref, layer_anchor, layer_helper, 'fallback layer table helper')
ref = sub_once(ref,
" const parsed=splitPairs(bytes),all=sectionRecords(parsed.pairs,'ENTITIES'),blocks=blockDefinitions(parsed.pairs),usedFallback=!base;",
" const parsed=splitPairs(bytes),all=sectionRecords(parsed.pairs,'ENTITIES'),blocks=blockDefinitions(parsed.pairs),usedFallback=!base;const parsedLayers=layerDefinitions(parsed.pairs);",
'layer table in board preview')
ref = sub_once(ref,
"if(!base.segs)base.segs=[];if(!base.anchors)base.anchors=[];if(!base.texts)base.texts=[];",
"if(!base.segs)base.segs=[];if(!base.anchors)base.anchors=[];if(!base.texts)base.texts=[];base.layers=base.layers||parsedLayers;",
'layer table attached to preview')

# Replace the complete legacy draw function, including its multiline body.
new_draw = r'''function aciColor(index,trueColor){if(Number.isFinite(trueColor)&&trueColor>=0){const n=trueColor>>>0;return 'rgb('+((n>>16)&255)+','+((n>>8)&255)+','+(n&255)+')';}let a=Math.abs(Number(index)||7);const basic={1:'#ff3b30',2:'#ffec35',3:'#39e75f',4:'#00e5ff',5:'#3675ff',6:'#ff45dc',7:'#f3f6fb',8:'#858b93',9:'#c1c7d0'};if(basic[a])return basic[a];if(a>=250)return ['#333333','#555555','#777777','#aaaaaa','#dddddd','#ffffff'][a-250]||'#e7edf4';a=Math.max(10,Math.min(249,a));const k=a-10,h=Math.floor(k/10)*15,variant=k%10,sat=[100,80,65,50,100,80,65,50,100,60][variant],light=[50,42,50,42,65,58,65,58,30,78][variant];return 'hsl('+h+','+sat+'%,'+light+'%)';}
function styleOf(v,item){const lname=String(item.layer||'0'),layers=v.drawing.layers||{},ld=layers[lname.toUpperCase()]||Object.keys(layers).map(k=>layers[k]).find(x=>String(x.name||'').toUpperCase()===lname.toUpperCase())||{};const tc=Number.isFinite(item.trueColor)?item.trueColor:(Number.isFinite(ld.trueColor)?ld.trueColor:null);const rawAci=Number.isFinite(item.aci)?item.aci:256,aci=(rawAci===0||rawAci===256)?(ld.aci||7):Math.abs(rawAci||7),lw=Number.isFinite(item.lineweight)&&item.lineweight>=0?item.lineweight:(Number(ld.lineweight)||0),lt=String(item.linetype||ld.linetype||'CONTINUOUS').toUpperCase();let dash=[];if(/CENTER|DASHDOT/.test(lt))dash=[8,3,2,3];else if(/HIDDEN|DASHED/.test(lt))dash=[6,3];else if(/DOT/.test(lt))dash=[1,3];return {color:aciColor(aci,tc),width:lw>0?Math.max(.7,Math.min(3.2,.7+lw/40)):.95,dash,key:aciColor(aci,tc)+'|'+(lw>0?lw:0)+'|'+dash.join(',')};}
function layerVisible(v,name){const key=String(name||'0'),state=v.layerVisibility||{},layers=v.drawing.layers||{},ld=layers[key.toUpperCase()]||Object.keys(layers).map(k=>layers[k]).find(x=>String(x.name||'').toUpperCase()===key.toUpperCase());if(Object.prototype.hasOwnProperty.call(state,key))return state[key];if(Object.prototype.hasOwnProperty.call(state,key.toUpperCase()))return state[key.toUpperCase()];return !(ld&&ld.off);}
function buildLayerPanel(v){const host=el(v.side==='target'?'sq110TLayerPanel':'sq110RLayerPanel');if(!host)return;host.innerHTML='';v.layerVisibility=v.layerVisibility||Object.create(null);const defs=v.drawing.layers||{},names=new Map();for(const key of Object.keys(defs))names.set(key.toUpperCase(),defs[key].name||key);for(const item of [...(v.drawing.segs||[]),...(v.drawing.texts||[]),...(v.drawing.anchors||[])]){const n=String(item.layer||'0');if(!names.has(n.toUpperCase()))names.set(n.toUpperCase(),n);}const sorted=Array.from(names.entries()).sort((a,b)=>a[0].localeCompare(b[0]));for(const [key,display] of sorted){const layer=defs[key]||Object.keys(defs).map(k=>defs[k]).find(x=>String(x.name||'').toUpperCase()===key)||{};const label=document.createElement('label'),box=document.createElement('input'),name=document.createElement('span');label.style.cssText='display:flex;align-items:center;gap:5px;min-width:0;font-size:11px;margin:2px;padding:3px 5px;border:1px solid #33445d;border-radius:5px;color:#dce8f7';box.type='checkbox';if(!Object.prototype.hasOwnProperty.call(v.layerVisibility,display))v.layerVisibility[display]=!(layer.off);box.checked=!!v.layerVisibility[display];box.addEventListener('change',()=>{v.layerVisibility[display]=box.checked;draw(v);});name.textContent=display;name.style.cssText='overflow:hidden;text-overflow:ellipsis;white-space:nowrap';label.appendChild(box);label.appendChild(name);host.appendChild(label);}if(!sorted.length){const n=document.createElement('span');n.textContent='لم يُعثر على جدول طبقات واضح؛ ستبقى البيانات الأصلية محفوظة.';host.appendChild(n);}}
function draw(v){if(!v||!v.ctx||!v.drawing)return;const m=metrics(v),c=v.ctx;c.clearRect(0,0,m.w,m.h);c.fillStyle='#0b1220';c.fillRect(0,0,m.w,m.h);if(v.drawing.previewWarning){c.fillStyle='#fbbf24';c.font='12px sans-serif';c.fillText(v.drawing.previewWarning.slice(0,90),8,18);}for(const h of v.drawing.fills||[]){if(!layerVisible(v,h.layer)||!Array.isArray(h.points)||h.points.length<3)continue;const pts=h.points.map(p=>project(v,p,m)).filter(p=>Number.isFinite(p.x)&&Number.isFinite(p.y));if(pts.length<3)continue;c.beginPath();c.moveTo(pts[0].x,pts[0].y);for(let i=1;i<pts.length;i++)c.lineTo(pts[i].x,pts[i].y);if(typeof c.closePath==='function')c.closePath();c.fillStyle=styleOf(v,h).color;c.globalAlpha=.22;c.fill();c.globalAlpha=1;}const groups=new Map();for(const seg of v.drawing.segs||[]){if(!layerVisible(v,seg.layer))continue;const a=project(v,seg.a,m),b=project(v,seg.b,m);if(![a.x,a.y,b.x,b.y].every(Number.isFinite))continue;if((a.x<-1200&&b.x<-1200)||(a.x>m.w+1200&&b.x>m.w+1200)||(a.y<-1200&&b.y<-1200)||(a.y>m.h+1200&&b.y>m.h+1200))continue;const st=styleOf(v,seg);let g=groups.get(st.key);if(!g){g={style:st,segments:[]};groups.set(st.key,g);}g.segments.push([a,b]);}for(const g of groups.values()){c.beginPath();c.strokeStyle=g.style.color;c.lineWidth=g.style.width;c.setLineDash(g.style.dash);c.lineCap='round';c.lineJoin='round';for(const [a,b] of g.segments){c.moveTo(a.x,a.y);c.lineTo(b.x,b.y);}c.stroke();}c.setLineDash([]);for(const p0 of v.drawing.anchors||[]){if(!p0.pointEntity||!layerVisible(v,p0.layer))continue;const p=project(v,p0,m),st=styleOf(v,p0);if(p.x<0||p.x>m.w||p.y<0||p.y>m.h)continue;c.beginPath();c.fillStyle=st.color;c.arc(p.x,p.y,2.2,0,Math.PI*2);c.fill();}for(const t of v.drawing.texts||[]){if(!layerVisible(v,t.layer))continue;const p=project(v,t.p,m);if(p.x<-100||p.x>m.w+100||p.y<-30||p.y>m.h+30)continue;const st=styleOf(v,t),size=Math.max(5.5,Math.min(15,Math.abs(Number(t.height)||2.5)*m.scale));c.save();c.translate(p.x,p.y);c.rotate(-(Number(t.rotation)||0)*Math.PI/180);c.fillStyle=st.color;c.font=size+'px sans-serif';c.fillText(String(t.text||'').slice(0,250),3,-3);c.restore();}const arr=v.side==='target'?state.targetPoints:state.referencePoints;for(let i=0;i<2;i++){const item=arr[i];if(!item)continue;const p=project(v,item,m);c.beginPath();c.fillStyle=i===0?'#2dd4bf':'#fb7185';c.strokeStyle='#fff';c.lineWidth=1.7;c.arc(p.x,p.y,7,0,Math.PI*2);c.fill();c.stroke();c.fillStyle='#fff';c.font='bold 12px sans-serif';c.fillText(String(i+1),p.x+9,p.y-8);}const id=state.idPoint[v.side];if(id){const p=project(v,id,m);c.strokeStyle='#fbbf24';c.lineWidth=2;c.beginPath();c.moveTo(p.x-9,p.y);c.lineTo(p.x+9,p.y);c.moveTo(p.x,p.y-9);c.lineTo(p.x,p.y+9);c.stroke();c.fillStyle='#fbbf24';c.font='bold 11px sans-serif';c.fillText('ID',p.x+10,p.y-10);}const count=el(v.side==='target'?'sq110TargetInfo':'sq110ReferenceInfo');if(count)count.textContent='كيانات: '+v.drawing.entityCount+' | مقاطع: '+(v.drawing.segs||[]).length+' | طبقات: '+Object.keys(v.drawing.layers||{}).length+' | تكبير داخل اللوحة ×'+v.zoom.toFixed(2)+(v.drawing.unsupported?' | عناصر CAD خاصة: '+v.drawing.unsupported:'');}'''
pattern = re.compile(r'function draw\(v\)\{.*?\n\}\nfunction setupCanvas\(v\)', re.S)
ref, draw_count = pattern.subn(lambda m: new_draw + '\nfunction setupCanvas(v)', ref, count=1)
if draw_count != 1: raise SystemExit(f'ERROR: expected to replace one complete draw(v) body; found {draw_count}')

# The supplemental fallback path retains the DXF layer styles too; point snapping respects layer visibility.
ref = sub_once(ref,
"function nearestSnap(v,world,screen){\n const mode=state.snapMode?.[v.side]||'auto',api=window.__sqManualOrientation109,m=metrics(v),segs=v.drawing.segs,projector=p=>project(v,p,m);",
"function nearestSnap(v,world,screen){\n const mode=state.snapMode?.[v.side]||'auto',api=window.__sqManualOrientation109,m=metrics(v),segs=(v.drawing.segs||[]).filter(s=>layerVisible(v,s.layer)),anchors=(v.drawing.anchors||[]).filter(p=>layerVisible(v,p.layer)),projector=p=>project(v,p,m);",
'visible-layer snapping')
ref = sub_once(ref,
"for(const p of v.drawing.anchors)test(p,'رأس/نهاية',42);",
"for(const p of anchors)test(p,'رأس/نهاية',42);",
'hide-layer anchors from OSNAP')

# Use a smaller drawing viewport; fit/zoom affect the CAD transform within this fixed rectangle.
ref = ref.replace('height:520px;min-height:520px;border:1px solid #42536b','height:230px;min-height:230px;max-height:230px;border:1px solid #42536b')
if ref.count('height:230px;min-height:230px;max-height:230px;border:1px solid #42536b') != 2:
    raise SystemExit('ERROR: both board canvases were not reduced to the requested compact size')
# Add collapsed layer selectors below each drawing canvas, not extra screen area until expanded.
ref = sub_once(ref,
'background:#0b1220"></canvas><p id="sq110TargetInfo"',
'background:#0b1220;touch-action:none"></canvas><details id="sq110TLayerDetails" style="margin:4px 0;border:1px solid #33445d;border-radius:6px;padding:5px"><summary style="font-size:12px;cursor:pointer">🎚️ طبقات اللوحة (إظهار/إخفاء)</summary><div id="sq110TLayerPanel" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:2px;max-height:100px;overflow:auto"></div></details><p id="sq110TargetInfo"',
'compact target layer controls')
ref = sub_once(ref,
'background:#0b1220"></canvas><p id="sq110ReferenceInfo"',
'background:#0b1220;touch-action:none"></canvas><details id="sq110RLayerDetails" style="margin:4px 0;border:1px solid #33445d;border-radius:6px;padding:5px"><summary style="font-size:12px;cursor:pointer">🎚️ طبقات اللوحة المرجعية (إظهار/إخفاء)</summary><div id="sq110RLayerPanel" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:2px;max-height:100px;overflow:auto"></div></details><p id="sq110ReferenceInfo"',
'compact reference layer controls')
# Give each view its own layer state and fill the panel after parse / import.
ref = sub_once(ref,
"const viewer={side,bytes,name,drawing,canvas:el(canvasId),ctx:null,zoom:1,panX:0,panY:0,pointerMap:new Map(),mode:'',drag:null,pinch:null,didDrag:false,suppressTap:false};",
"const viewer={side,bytes,name,drawing,canvas:el(canvasId),ctx:null,zoom:1,panX:0,panY:0,pointerMap:new Map(),mode:'',drag:null,pinch:null,didDrag:false,suppressTap:false,layerVisibility:Object.create(null)};",
'per-board layer visibility state')
ref = sub_once(ref,
"state.views[side]=viewer;setupCanvas(viewer);return viewer;}",
"state.views[side]=viewer;setupCanvas(viewer);buildLayerPanel(viewer);return viewer;}",
'build layer controls after board loads')
# prevent WebView/page zoom; pointer and wheel gestures remain scoped to the canvas.
ref = sub_once(ref,
"const overlay=el('sqOriOverlay');if(!overlay)return;const dialog=overlay.querySelector('.sqori-dialog');if(!dialog)return;",
"const overlay=el('sqOriOverlay');if(!overlay)return;const dialog=overlay.querySelector('.sqori-dialog');if(!dialog)return;dialog.style.maxHeight='86dvh';dialog.style.overflowY='auto';dialog.style.width='min(96vw,760px)';dialog.style.boxSizing='border-box';const viewport=document.querySelector('meta[name=\"viewport\"]');if(viewport)viewport.setAttribute('content','width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no');",
'compact orientation dialog and board-only zoom')
# Keep drawing zoom finite and do not change the HTML layout when zooming.
ref = ref.replace('Math.min(5000,', 'Math.min(1000,')
ref = ref.replace('Math.max(.15,Math.min(120,', 'Math.max(.1,Math.min(1000,')
# Zoom slider declared by the previous generation must remain mapped to the same board-only zoom.
ref = ref.replace('max="3.7" step="0.01" value="0" aria-label="تكبير دقيق حتى 5000 مرة"', 'max="3" step="0.01" value="0" aria-label="تكبير اللوحة حتى 1000 مرة"')
ref = ref.replace("v.zoom=Math.max(.1584893,Math.min(5000,Number(value)||1));", "v.zoom=Math.max(.1,Math.min(1000,Number(value)||1));")
ref = ref.replace("v.zoom=Math.max(.15,Math.min(120,v.zoom*(e.deltaY<0?1.2:1/1.2)));", "v.zoom=Math.max(.1,Math.min(1000,v.zoom*(e.deltaY<0?1.2:1/1.2)));\n  const slider=el(v.side==='target'?'sq110TZoomRange':'sq110RZoomRange');if(slider)slider.value=String(Math.log10(v.zoom));")
ref = ref.replace("v.zoom=Math.max(.15,Math.min(120,v.pinch.zoom*distance/v.pinch.distance));", "v.zoom=Math.max(.1,Math.min(1000,v.pinch.zoom*distance/v.pinch.distance));\n  const slider=el(v.side==='target'?'sq110TZoomRange':'sq110RZoomRange');if(slider)slider.value=String(Math.log10(v.zoom));")
# Update UI text and include validation / preserved-layer diagnostics after export.
ref = ref.replace('تكبير حتى 5000 مرة','تكبير اللوحة حتى 1000 مرة')
ref = ref.replace("' | عناصر بلا إحداثيات مكشوفة بقيت ببياناتها الأصلية: '+result.unchangedOpaque", "' | طبقات محفوظة: '+(result.layersPreserved?'نعم':'تحقق مطلوب')+' | كيانات قبل/بعد: '+(result.entitiesBefore||'?')+'/'+(result.entitiesAfter||'?')+(result.paperSpaceFallback?' | تم توجيه محتوى Paper Space لعدم وجود هندسة Model Space':'')+' | عناصر بلا إحداثيات مكشوفة بقيت ببياناتها الأصلية: '+result.unchangedOpaque")
# Version mark.

# Ensure important anchors didn't silently fail.
manual = manual.replace('.trim().slice(0,32);', '.trim().slice(0,250);', 1)

required_manual=['layers=Object.create(null)','trueColor','pointEntity','linetype','fills','drawHatchPolylineBoundary',"e.type==='DIMENSION'",'return {segs,anchors,texts,fills,layers']
missing=[x for x in required_manual if x not in manual]
if missing: raise SystemExit('ERROR: manual parser missing expected layer/style outputs: '+', '.join(missing))
required_ref=['function layerDefinitions(pairs)','function buildLayerPanel(v)','function layerVisible(v,name)','تكبير داخل اللوحة','sq110TLayerPanel','sq110RLayerPanel','dimensionBlockEntities','paperSpaceFallback','geometryChangedFields',"updateHeaderBounds('$EXTMIN','$EXTMAX')","'$VIEWCTR'",'Math.min(1000,','height:230px;min-height:230px;max-height:230px','c.globalAlpha=.22']
missing=[x for x in required_ref if x not in ref]
if missing: raise SystemExit('ERROR: reference display/transform patch missing: '+', '.join(missing))
manual_path.write_text(manual,encoding='utf-8')
ref_path.write_text(ref,encoding='utf-8')
print('PASS v126 patch: layer-aware CAD preview, solid HATCH fills/boundaries, MLINE strokes, dimension blocks, compact 230px board-only zoom, byte-preserving transform and empty-output guard.')
