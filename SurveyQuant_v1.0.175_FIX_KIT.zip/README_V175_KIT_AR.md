# حزمة إصلاح SurveyQuant V175 المبنية على V162

## الملفات
- `SurveyQuant_v1.0.175_PATCH.py`: يطبق إصلاح قارئ النقاط ويستبدل شاشة CAD القديمة بمشروعين مستقلين.
- `SurveyQuant_v1.0.175_CAD_ENGINE.js`: محرك توجيه اللوحات وPDF/IMAGE إلى DXF.
- `SurveyQuant_v1.0.175_PACKAGE_FREE_APK.py`: يجهز APK من APK الأساس V162 ويرفع رقم الإصدار إلى 1.0.175/175.
- اختبارات parser والتوجيه وPDF وبقاء المشاريع.
- `pdfjs-v3.11.174.min.js` و`pdfjs-worker-v3.11.174.min.js`: PDF.js مع الـWorker المطابق، مضمّنان للتشغيل دون تنزيل خارجي.

## الإصلاحات
1. رقم النقطة ID لا يدخل في X/Y/Z. الترتيب الافتراضي بدون Header هو `ID,Easting,Northing,Elevation`، ومع Header تتم قراءة أسماء الأعمدة. المحور X هو Easting والمحور Y هو Northing.
2. مشروع تحويل الملفات إلى DXF يمرر نوع الملف المختار من القائمة إلى قارئ النقاط.
3. مشروع إسقاط الملفات يحتفظ بمسار قراءة المرجع الخام والدمج المحافظ على بايتات DXF الأصلية.
4. مشروع توجيه اللوحات بطاقة مستقلة في قائمة المشاريع، ويحوّل اللوحة غير الموجهة إلى إحداثيات اللوحة المرجعية من نقطتين متطابقتين، مع إنشاء DXF جديد دون الكتابة فوق المصدر.
5. مشروع PDF/الصورة إلى DXF بطاقة مستقلة. الصفحة تُحفظ كصورة JPG مرجعية مرتبطة بكيان IMAGE/IMAGEDEF قياسي في DXF، للحفاظ على ألوان وتفاصيل الصفحة. يجب إبقاء ملف JPG بجانب DXF.

## بناء APK
ارفع `SurveyQuant_v1.0.175_FIX_KIT.zip` إلى جذر المستودع، وارفع ملف workflow إلى:
`.github/workflows/build-v175-v162-regression-repair.yml`
ثم شغّل Workflow يدويًا. القيمة الافتراضية لمصدر V162 هي Run ID `40919113310`.

يحتاج التوقيع إلى أسرار GitHub الأربعة الموجودة بالفعل في المشروع:
`SURVEYQUANT_KEYSTORE_PASSWORD`, `SURVEYQUANT_KEY_ALIAS`, `SURVEYQUANT_KEY_PASSWORD`, `SURVEYQUANT_KEYSTORE_BASE64`.
