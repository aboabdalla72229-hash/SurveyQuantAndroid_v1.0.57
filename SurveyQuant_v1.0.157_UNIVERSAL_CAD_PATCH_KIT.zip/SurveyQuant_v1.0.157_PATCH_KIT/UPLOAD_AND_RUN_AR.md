# طريقة رفع إصلاح SurveyQuant v1.0.157 من الهاتف

ملف APK الموقّع سيُنتجه GitHub Actions بعد رفع الملفين التاليين، باستخدام أسرار التوقيع الموجودة أصلًا في المستودع.

1. افتح المستودع: https://github.com/aboabdalla72229-hash/SurveyQuantAndroid_v1.0.57
2. ارفع `SurveyQuant_v1.0.157_UNIVERSAL_CAD_FIX.py` في جذر المستودع (نفس مستوى `index.html`) ثم اعمل Commit.
3. بعد ذلك افتح مجلد `.github/workflows` وارفع داخله `build-v157-universal-cad.yml` بالمسار الكامل `.github/workflows/build-v157-universal-cad.yml` ثم اعمل Commit. ترتيب الرفع مهم لو لم ترفع الملفين في Commit واحد.
4. من تبويب Actions افتح `Build SurveyQuant v1.0.157 Free Universal CAD`. غالبًا سيبدأ تلقائيًا مع Commit ملف الـworkflow. لو لم يبدأ، اضغط Run workflow واترك `source_run_id` على `40381302174`.
5. بعد نجاح البناء حمّل `SurveyQuant_v1.0.157_FREE_UNIVERSAL_CAD.apk` من Artifact أو صفحة Release `v1.0.157`.

لا تحذف أسرار التوقيع الأربعة. حزمة المصدر وحدها ليست APK قابلًا للتثبيت، ولا تحتوي مفتاح التوقيع.
