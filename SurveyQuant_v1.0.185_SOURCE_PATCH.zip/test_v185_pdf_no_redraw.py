from pathlib import Path
import base64, json, shutil
from playwright.sync_api import sync_playwright
import ezdxf, ezdxf.recover
root=Path(__file__).resolve().parent
html=(root/'index.html').read_text(encoding='utf-8')
fixtures=[('vector',root/'V180_VECTOR_ONLY_TEST.pdf','V185_Vector',True),('raster',root/'V180_RASTER_ONLY_TEST.pdf','V185_Raster',False),('mixed',root/'V180_MIXED_ARCHITECTURAL_TEST.pdf','V185_Mixed',False)]
ANDROID=r"""window.__nativeSavedFiles={};window.__nativeNotifiedFiles=[];window.Android={saveFile:(filename,mime,base64)=>{window.__nativeSavedFiles[filename]={filename,mime,base64};return 'Downloads/SurveyQuant/'+filename;},notifyDownload:(filename,path,mime)=>window.__nativeNotifiedFiles.push({filename,path,mime})};"""
with sync_playwright() as p:
 chrome=shutil.which('chromium') or shutil.which('chromium-browser')
 opts={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
 if chrome: opts['executable_path']=chrome
 b=p.chromium.launch(**opts);page=b.new_page(viewport={'width':430,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded',timeout=60000);page.evaluate(ANDROID);page.wait_for_timeout(250);page.locator('#sq176-home-pdf-project').click();page.wait_for_timeout(100)
 report=[]
 for mode,pdf,name,should_export in fixtures:
  inp=page.locator('#sq162-raster-file');inp.set_input_files(str(pdf));page.wait_for_function("document.querySelector('#sq162-raster-file').files.length===1 && !document.querySelector('#sq162-trace').disabled",timeout=30000)
  page.locator('#sq162-pdf-output-name').fill(name);page.evaluate('window.__nativeSavedFiles={};window.__nativeNotifiedFiles=[];');page.locator('#sq162-trace').click()
  if should_export:
   page.wait_for_function("Object.keys(window.__nativeSavedFiles).length>0",timeout=60000)
   item=page.evaluate('window.__nativeSavedFiles')[name+'.dxf'];raw=base64.b64decode(item['base64']);out=root/f'V185_{mode.upper()}_R2004.dxf';out.write_bytes(raw);txt=raw.decode('cp1252',errors='replace')
   assert '\nIMAGE\n' not in txt and '\nIMAGEDEF\n' not in txt and '\nOLE2FRAME\n' not in txt
   doc,_=ezdxf.recover.readfile(out);audit=doc.audit();assert doc.dxfversion=='AC1018' and not audit.errors and not audit.fixes
   m=doc.modelspace();assert len(m.query('LINE'))>0,'PDF straight strokes must be native LINE entities'
   assert len(m.query('LWPOLYLINE'))+len(m.query('POLYLINE'))>=0
   report.append({'mode':mode,'result':'PASS vector-native export','lines':len(m.query('LINE')),'texts':len(m.query('TEXT')),'entities':len(m)})
  else:
   page.wait_for_function("document.querySelector('#sq162-raster-status').innerText.includes('تحتوي صورًا')",timeout=60000)
   saved=page.evaluate('window.__nativeSavedFiles');assert not saved,(mode,list(saved))
   report.append({'mode':mode,'result':'PASS rejected without tracing','saved_files':0})
 assert not errors,errors
 result={'result':'PASS no raster tracing; vector-only native DXF; raster/mixed rejected rather than approximated','fixtures':report,'browser_page_errors':errors}
 (root/'V185_PDF_NO_REDRAW_TEST_LOG.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2));b.close()
