/* SurveyQuant v1.0.112: robust DXF pair recovery for preview and export.
   Original source and reference files are never mutated. If a text-DXF has a
   broken group-code boundary, the viewer retries on a temporary byte stream
   made from complete original group pairs. Output sanitization occurs only
   after transform and only when recovery was actually necessary. */
(function () {
  'use strict';
  const MANUAL = window.__sqManualOrientation109;
  const CORE = window.__sqOrientation111API;
  if (!MANUAL || typeof MANUAL.parseDrawing !== 'function' ||
      !CORE || typeof CORE.splitPairs !== 'function' || typeof CORE.transformBytes !== 'function') {
    throw new Error('DXF recovery v112 could not connect to the existing drawing/parser modules.');
  }

  const nativeParseDrawing = MANUAL.parseDrawing.bind(MANUAL);
  const nativeTransformBytes = (window.__sqOrientTest && typeof window.__sqOrientTest.transformBytes === 'function')
    ? window.__sqOrientTest.transformBytes.bind(window.__sqOrientTest)
    : CORE.transformBytes.bind(CORE);
  const stats = { previewRecoveries: 0, exportRepairs: 0, lastPreview: null, lastExport: null };
  const textEncoder = new TextEncoder();

  function asBytes(input) {
    if (input instanceof Uint8Array) return input;
    if (input instanceof ArrayBuffer) return new Uint8Array(input);
    if (ArrayBuffer.isView(input)) return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
    return new Uint8Array(input);
  }

  // Reassemble *complete original group pairs only*. Each pair is copied from
  // the exact byte range, preserving its original spelling, value, and newline.
  // Bytes identified by the recovery scanner as an invalid alignment gap are
  // omitted only in the temporary recovered representation / repaired output.
  function reassemblePairs(parsed) {
    const bytes = parsed.bytes;
    if (!parsed.pairs || !parsed.pairs.length) throw new Error('لم يتم العثور على أزواج DXF قابلة للاستعادة.');
    const chunks = [];
    const first = parsed.pairs[0];
    if (first.start > 0) chunks.push(bytes.slice(0, first.start)); // retain UTF-8 BOM / prefix
    for (const pair of parsed.pairs) {
      if (!(pair.start >= 0 && pair.end > pair.start && pair.end <= bytes.length)) continue;
      chunks.push(bytes.slice(pair.start, pair.end));
    }
    let length = 0;
    for (const chunk of chunks) length += chunk.length;
    const output = new Uint8Array(length);
    let offset = 0;
    for (const chunk of chunks) { output.set(chunk, offset); offset += chunk.length; }
    if (output.length < 16) throw new Error('حجم ملف DXF بعد الاستعادة غير كافٍ.');
    return output;
  }

  function validateRecovered(bytes) {
    // Re-parse with the full drawing parser, not the sparse fallback renderer.
    const model = nativeParseDrawing(bytes);
    if (!model || (!model.segs?.length && !model.anchors?.length && !model.texts?.length)) {
      throw new Error('استعيد تسلسل DXF، لكن لم تُكتشف عناصر هندسية قابلة للعرض. لم يتم اعتماد الاستعادة.');
    }
    return model;
  }

  function parseDrawingFaithfully(input) {
    const bytes = asBytes(input);
    // Keep the fast path lean: valid files are read once by the existing full
    // drawing parser. Only invoke recovery scanning after the real parser fails.
    try { return nativeParseDrawing(bytes); }
    catch (originalError) {
      let parsed;
      try { parsed = CORE.splitPairs(bytes); }
      catch (scanError) { throw originalError; }
      if (!(parsed.recoveryCount || 0)) throw originalError;
      const recovered = reassemblePairs(parsed);
      // Release the scan records before the full renderer allocates its model.
      const recoveryInfo = {
        recoveryCount: parsed.recoveryCount,
        skippedPhysicalLines: parsed.recoveredLines || 0,
        completePairs: parsed.pairs.length,
        mode: 'valid-pairs-full-renderer'
      };
      parsed.pairs.length = 0;
      parsed = null;
      const model = validateRecovered(recovered);
      model.__sqDxfRecovery = recoveryInfo;
      stats.previewRecoveries++;
      stats.lastPreview = recoveryInfo;
      return model;
    }
  }

  function transformAndRepair(input, transform) {
    const original = asBytes(input);
    // Existing transform is kept as the coordinate editing engine. It changes
    // exposed XY pairs in the target bytes; it does not touch the reference file.
    const result = nativeTransformBytes(original, transform);
    if (!result || !result.bytes) throw new Error('لم ينتج محرك التوجيه ملف DXF.');

    // Scan only the transformed bytes: when no recovery is needed this means one
    // additional recovery check, avoiding a third large-file scan on valid DXF.
    let after = CORE.splitPairs(asBytes(result.bytes));
    const neededRepair = (after.recoveryCount || 0) > 0;
    if (!neededRepair) return result; // byte-preserving path for valid DXF stays unchanged

    const repaired = reassemblePairs(after);
    const repairedMalformedRows = after.recoveredLines || 0;
    const repairedBoundaries = after.recoveryCount || 0;
    // Drop pair references before the full parser allocates its drawing model.
    after.pairs.length = 0;
    after = null;
    // The repaired byte stream is assembled only from complete group pairs.
    // Validate it with the real drawing parser before offering it for download.
    const verified = validateRecovered(repaired);
    result.bytes = repaired;
    result.repairedMalformedRows = repairedMalformedRows;
    result.repairedBoundaries = repairedBoundaries;
    result.verifiedEntityCount = verified.entityCount || 0;
    stats.exportRepairs++;
    stats.lastExport = {
      repairedMalformedRows: result.repairedMalformedRows,
      repairedBoundaries: result.repairedBoundaries,
      verifiedEntityCount: result.verifiedEntityCount
    };
    return result;
  }

  MANUAL.parseDrawing = parseDrawingFaithfully;
  if (window.__sqOrientTest) window.__sqOrientTest.transformBytes = transformAndRepair;
  CORE.transformBytes = transformAndRepair;
  window.__sqOrientation112API = {
    VERSION: '1.0.112',
    parseDrawing: parseDrawingFaithfully,
    transformBytes: transformAndRepair,
    reassemblePairs,
    stats
  };
})();
