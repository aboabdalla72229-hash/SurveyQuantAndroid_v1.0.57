from pathlib import Path
import re
ROOT=Path(__file__).parent
html_path=ROOT/'index.html'
MULTI_SOLVER = r'''function sqOriSolveMultiple(pairs) {
  const valid=(pairs||[]).filter(m=>m&&m.source&&m.reference&&[m.source.x,m.source.y,m.reference.x,m.reference.y].every(v=>Number.isFinite(Number(v)))).map(m=>({key:String(m.key||''),source:{x:Number(m.source.x),y:Number(m.source.y)},reference:{x:Number(m.reference.x),y:Number(m.reference.y)}}));
  if(valid.length<2)throw new Error('يلزم تقاطعان مشتركان صالحان على الأقل لحساب التوجيه.');
  const extent=points=>{let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;for(const p of points){minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);}return Math.hypot(maxX-minX,maxY-minY);};
  const srcDiag=extent(valid.map(m=>m.source)),refDiag=extent(valid.map(m=>m.reference));
  if(!(srcDiag>0)||!(refDiag>0)||!Number.isFinite(srcDiag)||!Number.isFinite(refDiag))throw new Error('تقاطعات المحاور متطابقة أو غير صالحة هندسيًا؛ لا يمكن حساب المقياس.');
  const nearest=valid.map((m,i)=>{let d=Infinity;for(let j=0;j<valid.length;j++){if(i===j)continue;const q=valid[j].reference;d=Math.min(d,Math.hypot(m.reference.x-q.x,m.reference.y-q.y));}return d;}).filter(d=>Number.isFinite(d)&&d>0).sort((a,b)=>a-b);
  const typicalSpacing=nearest.length?nearest[Math.floor(nearest.length/2)]:refDiag;
  const tolerance=Math.max(1e-7,Math.min(refDiag*1e-7,typicalSpacing*1e-5));
  const fromPair=(m1,m2)=>{
    const p=m1.source,q=m2.source,r=m1.reference,z=m2.reference,dx=q.x-p.x,dy=q.y-p.y,ux=z.x-r.x,uy=z.y-r.y,den=dx*dx+dy*dy;
    if(!(den>Math.max(srcDiag*srcDiag*1e-24,1e-28)))return null;
    const aa=(dx*ux+dy*uy)/den,bb=(dx*uy-dy*ux)/den,scale=Math.hypot(aa,bb);
    if(!(scale>0)||!Number.isFinite(scale)||!Number.isFinite(aa)||!Number.isFinite(bb))return null;
    const angle=Math.atan2(bb,aa),tx=r.x-(aa*p.x-bb*p.y),ty=r.y-(bb*p.x+aa*p.y);
    return {scale,angle,angleDeg:angle*180/Math.PI,c:Math.cos(angle),s:Math.sin(angle),tx,ty,point:(x,y)=>({x:aa*x-bb*y+tx,y:bb*x+aa*y+ty}),vector:(x,y)=>({x:aa*x-bb*y,y:bb*x+aa*y})};
  };
  const sampleCount=Math.min(64,valid.length),sample=[];
  if(valid.length<=sampleCount){for(let i=0;i<valid.length;i++)sample.push(i);}
  else for(let i=0;i<sampleCount;i++)sample.push(Math.round(i*(valid.length-1)/(sampleCount-1)));
  let best=null;
  for(let i=0;i<sample.length;i++)for(let j=i+1;j<sample.length;j++){
    const candidate=fromPair(valid[sample[i]],valid[sample[j]]);if(!candidate)continue;
    const residuals=valid.map(m=>{const q=candidate.point(m.source.x,m.source.y);return Math.hypot(q.x-m.reference.x,q.y-m.reference.y);});
    const inliers=[];let sum=0;for(let k=0;k<residuals.length;k++)if(residuals[k]<=tolerance){inliers.push(k);sum+=residuals[k]*residuals[k];}
    if(!best||inliers.length>best.inliers.length||(inliers.length===best.inliers.length&&sum<best.sum))best={inliers,sum};
  }
  if(!best||best.inliers.length<2)throw new Error('لم تتفق تقاطعات المحاور على تحويل هندسي واحد. راجع تسميات المحاور أو حدد نقطتين يدويًا.');
  const fit=indices=>{
    let mx=0,my=0,mrx=0,mry=0;for(const i of indices){mx+=valid[i].source.x;my+=valid[i].source.y;mrx+=valid[i].reference.x;mry+=valid[i].reference.y;}const n=indices.length;mx/=n;my/=n;mrx/=n;mry/=n;
    let A=0,B=0,D=0;for(const i of indices){const x=valid[i].source.x-mx,y=valid[i].source.y-my,u=valid[i].reference.x-mrx,v=valid[i].reference.y-mry;A+=x*u+y*v;B+=x*v-y*u;D+=x*x+y*y;}
    if(!(D>Math.max(srcDiag*srcDiag*1e-24,1e-28)))throw new Error('النقاط المشتركة لا توفر امتدادًا هندسيًا كافيًا لضبط الدوران والمقياس.');
    const aa=A/D,bb=B/D,scale=Math.hypot(aa,bb);if(!(scale>0)||!Number.isFinite(scale)||!Number.isFinite(aa)||!Number.isFinite(bb))throw new Error('تعذر حساب مقياس موجب وصالح من نقاط المحاور.');
    const angle=Math.atan2(bb,aa),tx=mrx-(aa*mx-bb*my),ty=mry-(bb*mx+aa*my);
    return {scale,angle,angleDeg:angle*180/Math.PI,c:Math.cos(angle),s:Math.sin(angle),tx,ty,point:(x,y)=>({x:aa*x-bb*y+tx,y:bb*x+aa*y+ty}),vector:(x,y)=>({x:aa*x-bb*y,y:bb*x+aa*y})};
  };
  let inliers=best.inliers,transform=null;
  for(let pass=0;pass<4;pass++){
    transform=fit(inliers);const next=[];
    for(let i=0;i<valid.length;i++){const q=transform.point(valid[i].source.x,valid[i].source.y);if(Math.hypot(q.x-valid[i].reference.x,q.y-valid[i].reference.y)<=tolerance)next.push(i);}
    if(next.length<2)break;const same=next.length===inliers.length&&next.every((v,i)=>v===inliers[i]);inliers=next;if(same)break;
  }
  transform=fit(inliers);
  const residuals=valid.map(m=>{const q=transform.point(m.source.x,m.source.y),error=Math.hypot(q.x-m.reference.x,q.y-m.reference.y);return {key:m.key,error,inlier:error<=tolerance};});
  inliers=residuals.map((r,i)=>r.inlier?i:-1).filter(i=>i>=0);
  if(valid.length>=3&&inliers.length<Math.max(3,Math.ceil(valid.length*0.6)))throw new Error('فشل التحقق متعدد النقاط: المتوافق '+inliers.length+' من '+valid.length+' تقاطعًا فقط. لن نصدر تحويلًا غير موثوق؛ صحح تسميات المحاور أو اختر نقطتين متناظرتين يدويًا.');
  if(inliers.length<2)throw new Error('فشل التحقق من تقاطعات المحاور.');
  const good=residuals.filter(r=>r.inlier),squared=good.reduce((sum,r)=>sum+r.error*r.error,0),rms=Math.sqrt(squared/good.length),maxResidual=Math.max(...good.map(r=>r.error));
  return {...transform,inlierCount:inliers.length,matchedCount:valid.length,excludedCount:valid.length-inliers.length,rms,maxResidual,tolerance,residuals};
}'''
solver=MULTI_SOLVER
s=html_path.read_text(encoding='utf-8')
def once(old,new,label):
 global s
 c=s.count(old)
 if c!=1: raise SystemExit(f'{label}: expected one match, got {c}')
 s=s.replace(old,new,1)
old_calc="function calculation(){if(!state.target||!state.reference)throw new Error('افتح اللوحة غير الموجّهة واللوحة المرجعية أولًا.');if(!state.targetPoints[0]||!state.targetPoints[1])throw new Error('حدد النقطتين 1 و2 في اللوحة غير الموجّهة.');if(!state.referencePoints[0]||!state.referencePoints[1])throw new Error('حدد النقطتين 1 و2 في اللوحة المرجعية، بالترتيب نفسه.');return solve(state.targetPoints[0],state.targetPoints[1],state.referencePoints[0],state.referencePoints[1]);}"
new_calc="function calculation(){if(!state.target||!state.reference)throw new Error('افتح اللوحة غير الموجّهة واللوحة المرجعية أولًا.');if(Array.isArray(state.axisMatches)&&state.axisMatches.length>=2)return sqOriSolveMultiple(state.axisMatches);if(!state.targetPoints[0]||!state.targetPoints[1])throw new Error('حدد النقطتين 1 و2 في اللوحة غير الموجّهة.');if(!state.referencePoints[0]||!state.referencePoints[1])throw new Error('حدد النقطتين 1 و2 في اللوحة المرجعية، بالترتيب نفسه.');return solve(state.targetPoints[0],state.targetPoints[1],state.referencePoints[0],state.referencePoints[1]);}"
once(old_calc,solver+'\n'+new_calc,'active calculation')
# Report only residuals that passed the robust fit; rejected matches stay visible in the diagnostics.
pattern=re.compile(r"  const errors=state\.axisMatches\.map\(m=>\{const q=t\.point\(m\.source\.x,m\.source\.y\);return \{key:m\.key,value:Math\.hypot\(q\.x-m\.reference\.x,q\.y-m\.reference\.y\)\};\}\);\n  const rms=.*?\n  const max=.*?\n  showScreen\('target'\);\n  status\('تمت قراءة المحاور آليًا: .*?\n  return \{matched,t,rms,max\};",re.S)
new_status="""  const good=(t.residuals||[]).filter(e=>e.inlier),rms=t.rms??Math.sqrt(good.reduce((sum,e)=>sum+e.error*e.error,0)/Math.max(1,good.length)),max=t.maxResidual??Math.max(0,...good.map(e=>e.error));
  showScreen('target');
  status('تمت قراءة المحاور: '+matched.matches.length+' تقاطعًا. حل متعدد النقاط استخدم '+(t.inlierCount||matched.matches.length)+'/'+(t.matchedCount||matched.matches.length)+' تقاطعًا متوافقًا'+(t.excludedCount?' واستبعد '+t.excludedCount+' مطابقة شاذة':'')+'. معامل المقياس ×'+t.scale.toPrecision(12)+' | الدوران '+t.angleDeg.toFixed(10)+'° | الإزاحة X '+t.tx.toPrecision(12)+' ، Y '+t.ty.toPrecision(12)+' | RMS '+rms.toPrecision(10)+' | أقصى انحراف متوافق '+max.toPrecision(10)+' بوحدات الرسم. راجع نتيجة التحقق قبل الإخراج.',false);
  return {matched,t,rms,max};"""
s,n=pattern.subn(new_status,s,count=1)
if n!=1: raise SystemExit(f'axis status block: expected one match, got {n}')
# The preview must display the same diagnostics as export, not silently claim a two-point-only review.
review_pattern=re.compile(r"function review\(\)\{try\{const t=calculation\(\);.*?\}catch\(e\)\{status\(e\.message,true\);return null;\}\}")
new_review="function review(){try{const t=calculation();let diagnostic='';if(Array.isArray(t.residuals)&&t.residuals.length){const good=t.residuals.filter(e=>e.inlier),rms=t.rms??Math.sqrt(good.reduce((s,e)=>s+e.error*e.error,0)/Math.max(1,good.length)),mx=t.maxResidual??Math.max(0,...good.map(e=>e.error));diagnostic=' | تقاطعات متوافقة '+good.length+'/'+t.residuals.length+' | RMS '+rms.toPrecision(10)+' | أقصى انحراف متوافق '+mx.toPrecision(10)+' | مستبعد '+(t.excludedCount||0);}status('المعاينة جاهزة: معامل المقياس ×'+t.scale.toPrecision(12)+' | الدوران '+t.angleDeg.toFixed(10)+'° | الإزاحة X '+t.tx.toPrecision(12)+' ، Y '+t.ty.toPrecision(12)+' | X=Easting وY=Northing دون تبديل.'+diagnostic);return t;}catch(e){status(e.message,true);return null;}}"
s,n=review_pattern.subn(new_review,s,count=1)
if n!=1: raise SystemExit(f'preview review: expected one match, got {n}')
# The hand-edited point-table values invalidate the automatic fit and fall back to exactly the entered pairs.
if "const pts=side==='target'?state.targetPoints:state.referencePoints;state.axisMatches=[];pts[i]={...(pts[i]||{}),x,y,kind:'إحداثيات معدلة يدويًا'};const v=state.views[side];" not in s:
 once("const pts=side==='target'?state.targetPoints:state.referencePoints;pts[i]={...(pts[i]||{}),x,y,kind:'إحداثيات معدلة يدويًا'};const v=state.views[side];","const pts=side==='target'?state.targetPoints:state.referencePoints;state.axisMatches=[];pts[i]={...(pts[i]||{}),x,y,kind:'إحداثيات معدلة يدويًا'};const v=state.views[side];",'clear cached auto-fit after manual edits')
# XLINE/RAY code 11/21 is a direction vector, not a second endpoint. Do not fabricate a base-to-vector segment for selection/highlighting.
once(" if(t==='LINE'){add(pointAt(rec,10));add(pointAt(rec,11));if(pts.length>=2)segments.push({a:pts[0],b:pts[1]});return {pts,segments};}"," if(t==='XLINE'||t==='RAY'){const base=pointAt(rec,10);if(base)add(base);return {pts,segments};}\n if(t==='LINE'){add(pointAt(rec,10));add(pointAt(rec,11));if(pts.length>=2)segments.push({a:pts[0],b:pts[1]});return {pts,segments};}",'avoid false segment from infinite line direction')
# Postconditions.
for n in ["function sqOriSolveMultiple(pairs)","return sqOriSolveMultiple(state.axisMatches)","state.axisMatches=[];pts[i]={","if(t==='XLINE'||t==='RAY'){const base=pointAt(rec,10)","تقاطعات متوافقة"]:
 if n not in s: raise SystemExit('postcondition failed: '+n)
html_path.write_text(s,encoding='utf-8')
print('PASS V139: active multi-point fit + outlier rejection + RMS report + manual reset + XLINE/RAY entity-picking fix')
print('HTML bytes:',html_path.stat().st_size)
