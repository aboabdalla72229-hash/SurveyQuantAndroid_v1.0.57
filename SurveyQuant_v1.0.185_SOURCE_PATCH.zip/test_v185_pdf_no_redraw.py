from pathlib import Path
import json, shutil
from playwright.sync_api import sync_playwright
import ezdxf, ezdxf.recover
root=Path(__file__).resolve().parent
html=(root/'index.html').read_text(encoding='utf-8')
fixtures=[('vector',root/'V180_VECTOR_ONLY_TEST.pdf','V185_Vector',True),('raster',root/'V180_RASTER_ONLY_TEST.pdf','V185_Raster',False),('mixed',root/'V180_MIXED_ARCHITECTURAL_TEST.pdf','V185_Mixed',False)]
with sync_playwright() as p:
 chrome=shutil.which('chromium') or shutil.which('chromium-browser')
 opts={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
 if chrome: opts['executable_path']=chrome
 b=p.chromium.launch(**opts);page=b.new_page(viewport={'width':430,'height':900},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded',timeout=60000);page.wait_for_timeout(500);page.locator('#sq176-home-pdf-project').click();page.wait_for_timeout(100)
 report=[]
 for mode,pdf,name,should_export in fixtures:
  inp=page.locator('#sq162-raster-file');inp.set_input_files(str(pdf));page.wait_for_function("document.querySelector('#sq162-raster-file').files.length===1 && !document.querySelector('#sq162-trace').disabled",timeout=30000)
  page.locator('#sq162-pdf-output-name').fill(name)
  if should_export:
   with page.expect_download(timeout=60000) as download_info:
    page.locator('#sq162-trace').click()
   download=download_info.value
   page.wait_for_function("document.querySelector('#sq162-raster-status').innerText.includes('تم حفظ ملف DXF واحد')",timeout=30000)
   out=root/f'V185_{mode.upper()}_R2004.dxf';download.save_as(str(out));raw=out.read_bytes();txt=raw.decode('cp1252',errors='replace')
   assert '\nIMAGE\n' not in txt and '\nIMAGEDEF\n' not in txt and '\nOLE2FRAME\n' not in txt
   doc,_=ezdxf.recover.readfile(out);audit=doc.audit();assert doc.dxfversion=='AC1018' and not audit.errors and not audit.fixes
   m=doc.modelspace();assert len(m.query('LINE'))+len(m.query('LWPOLYLINE'))>0,'PDF native geometry missing';assert len(m.query('TEXT'))>0,'PDF text extraction missing'
   open_result=page.evaluate("(() => { const r=window.SurveyQuantCAD184.polylinesToDxf([{closed:false,points:[{x:0,y:0},{x:10,y:10},{x:20,y:10}]}],100,100,1,[]); return Array.from(r.bytes); })()")
   open_dxf=root/'V185_OPEN_STROKE_LINE_TEST.dxf';open_dxf.write_bytes(bytes(open_result));open_doc,_=ezdxf.recover.readfile(open_dxf);assert len(open_doc.modelspace().query('LINE'))==2,'Open PDF strokes must be native LINE entities'
   
   report.append({'mode':mode,'result':'PASS vector-native export','lines':len(m.query('LINE')),'closed_polylines':len(m.query('LWPOLYLINE')),'texts':len(m.query('TEXT')),'entities':len(m)})
  else:
   page.locator('#sq162-trace').click()
   page.wait_for_function("document.querySelector('#sq162-raster-status').innerText.includes('تحتوي صورًا')",timeout=60000)
   report.append({'mode':mode,'result':'PASS rejected without tracing','downloads':0})
 result={'result':'PASS no raster tracing; vector-only native DXF; raster/mixed rejected rather than approximated','fixtures':report,'open_stroke_test':'PASS two DXF LINE entities','browser_page_errors':errors}
 (root/'V185_PDF_NO_REDRAW_TEST_LOG.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2));b.close()
