#!/usr/bin/env python3
"""Repair shared CAD import/quantity paths while preserving original drawing bytes."""
from __future__ import annotations
import argparse
import re
import subprocess
import tempfile
from pathlib import Path


def replace_one(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count == 0 and new in text:
        print(f"PASS already applied: {label}")
        return text
    if count != 1:
        raise SystemExit(f"PATCH ERROR [{label}]: expected exactly one target, got {count}")
    print(f"PATCHED: {label}")
    return text.replace(old, new, 1)


def patch_html(path: Path) -> str:
    source = path.read_text(encoding="utf-8")

    # Keep CAD XLINE/RAY entities in the output path using explicit entity fields.
    writer_start = source.find("function sqBuildModernEntityRecords(")
    writer_end = source.find("function sqApplyByteEdits(", writer_start)
    if writer_start < 0 or writer_end < 0:
        raise SystemExit("PATCH ERROR: modern DXF writer section not found")
    writer = source[writer_start:writer_end]
    bad = "else if((type==='XLINE'||type==='RAY')&&(e.basePoint||e.startPoint||e.position)&&(e.directionVector||e.unitVector||e.direction)){const base=p3((e.basePoint||e.startPoint||e.position).x,(e.basePoint||e.startPoint||e.position).y,(e.basePoint||e.startPoint||e.position).z);const dir=e.directionVector||e.unitVector||e.direction;addCadEntity(m,type,layer,{basePoint:base,directionVector:p3(dir.x,dir.y,dir.z)});}"
    good = "else if((e.type==='XLINE'||e.type==='RAY')&&(e.basePoint||e.startPoint||e.position)&&(e.directionVector||e.unitVector||e.direction)){const base=e.basePoint||e.startPoint||e.position,dir=e.directionVector||e.unitVector||e.direction;emit(e.type,e.type==='XLINE'?'AcDbXline':'AcDbRay',L,color,xyz(base,10)+xyz(dir,11));}"
    writer = replace_one(writer, bad, good, "write XLINE/RAY without undefined variables and preserve CAD record structure")
    source = source[:writer_start] + writer + source[writer_end:]

    # A surface's point set must be derived from actual surface vertices, not infinite lines.
    surface_start = source.find("function surfacePointsFromModel(m){")
    surface_end = source.find("function triArea2(", surface_start)
    if surface_start < 0 or surface_end < 0:
        raise SystemExit("PATCH ERROR: surface point extraction function not found")
    surface = source[surface_start:surface_end]
    bad_surface = "  else if((type==='XLINE'||type==='RAY')&&(e.basePoint||e.startPoint||e.position)&&(e.directionVector||e.unitVector||e.direction)){const base=p3((e.basePoint||e.startPoint||e.position).x,(e.basePoint||e.startPoint||e.position).y,(e.basePoint||e.startPoint||e.position).z);const dir=e.directionVector||e.unitVector||e.direction;addCadEntity(m,type,layer,{basePoint:base,directionVector:p3(dir.x,dir.y,dir.z)});}\n"
    surface = replace_one(surface, bad_surface, "", "ignore XLINE/RAY when extracting surface vertices; fix DWG/DXF surface and layer comparison crash")
    source = source[:surface_start] + surface + source[surface_end:]

    # Avoid cloning full multi-megabyte buffers when the owned byte array can be retained.
    source = replace_one(source,
        "const fileContent=sourceBytes.buffer.slice(sourceBytes.byteOffset,sourceBytes.byteOffset+sourceBytes.byteLength);",
        "const fileContent=(sourceBytes.byteOffset===0&&sourceBytes.byteLength===sourceBytes.buffer.byteLength)?sourceBytes.buffer:sourceBytes.buffer.slice(sourceBytes.byteOffset,sourceBytes.byteOffset+sourceBytes.byteLength);",
        "avoid duplicate DWG source buffer allocation")
    for old, new, label in [
        ("nativeModel.rawDWGBytes=sourceBytes.slice();", "nativeModel.rawDWGBytes=sourceBytes;", "retain owned raw DWG bytes without a second full copy"),
        ("model.rawDWGBytes=sourceBytes.slice();", "model.rawDWGBytes=sourceBytes;", "retain raw DWG bytes without a second full copy"),
        ("model.rawDXFBytes=dxfBytes.slice();", "model.rawDXFBytes=dxfBytes;", "retain converted DXF bytes without a second full copy"),
        ("model.rawDXFBytes=bytes.slice();", "model.rawDXFBytes=bytes;", "retain original DXF bytes without a second full copy"),
    ]:
        source = replace_one(source, old, new, label)

    # The two utilities that previously accepted only point-text files can now
    # also accept one CAD board. CAD is passed through as DXF bytes, never rebuilt.
    source = replace_one(source,
        '<option value="PT">PT</option></select></div><div><label>الملفات</label><input id="fileToDxfInput" type="file" multiple accept=".sdr,.txt,.csv,.pt,.pnt,text/plain,text/csv,*/*"/>',
        '<option value="PT">PT</option><option value="CAD">DXF / DWG (حفظ اللوحة)</option></select></div><div><label>الملفات</label><input id="fileToDxfInput" type="file" multiple accept=".sdr,.txt,.csv,.pt,.pnt,.dxf,.dwg,application/dxf,application/dwg,text/plain,text/csv,*/*"/>',
        "allow DXF/DWG in the Files-to-DXF utility")
    source = replace_one(source,
        '<div class="info-list">اختر نوع الملف من القائمة، ثم أضف ملفًا أو أكثر. يدعم SDR وTXT وCSV وPT/PNT، ويجمع النقاط ويخرج لوحة AutoCAD DXF فيها النقاط وأسماؤها ومناسيبها.</div>',
        '<div class="info-list">يدعم ملفات النقاط SDR/TXT/CSV/PT/PNT المتعددة، كما يدعم ملف CAD واحدًا بصيغة DXF/DWG. عند اختيار لوحة CAD يحتفظ باللوحة كما هي ولا يعيد رسمها؛ وملف DWG يُحوّل إلى سجل DXF مؤقت بحسب ما يدعمه محرك القراءة.</div>',
        "describe CAD pass-through in Files-to-DXF utility")
    source = replace_one(source,
        '<input id="cleanFilesInput" type="file" multiple accept=".sdr,.pnt,.txt,.csv,.dat,text/plain,text/csv,*/*"/>',
        '<input id="cleanFilesInput" type="file" multiple accept=".sdr,.pnt,.txt,.csv,.dat,.dxf,.dwg,application/dxf,application/dwg,text/plain,text/csv,*/*"/>',
        "allow DXF/DWG in file-filter utility")
    source = replace_one(source,
        '<div class="info-list">أضف ملفًا واحدًا أو عدة ملفات SDR/PNT/TXT/CSV. البرنامج يدمج الملفات، يحذف التكرارات، ثم يخرج ملفًا واحدًا بالصيغة التي تختارها.</div>',
        '<div class="info-list">ملفات النقاط SDR/PNT/TXT/CSV يمكن دمجها وحذف التكرارات منها. ويمكن اختيار ملف CAD واحد بصيغة DXF/DWG لحفظه كـDXF دون حذف عناصر أو إعادة رسم اللوحة.</div>',
        "describe CAD-preserving path in file-filter utility")
    source = replace_one(source,
        '<option value="txt">TXT</option></select>',
        '<option value="txt">TXT</option><option value="dxf">DXF (حفظ لوحة CAD)</option></select>',
        "add CAD-preserving DXF output option")
    source = replace_one(source,
        "let landSideCount=4,imageSideCount=4,lastFileToDxfDXF='',lastFileToDxfModel=null,cleanedPoints=[],cleanedText='',cleanedCSV='',imageDrawingModel=null;",
        "let landSideCount=4,imageSideCount=4,lastFileToDxfDXF='',lastFileToDxfModel=null,cleanedPoints=[],cleanedText='',cleanedCSV='',cleanedCadBytes=null,cleanedCadFilename='',imageDrawingModel=null;",
        "keep a dedicated raw-byte slot for CAD pass-through")
    source = replace_one(source,
        "var NON_CAD_DATA_IDS = new Set(['fileToDxfInput', 'cleanFilesInput']);",
        "var NON_CAD_DATA_IDS = new Set();",
        "let all project file inputs accept the shared CAD types")

    def replace_function(text: str, start_marker: str, end_marker: str, replacement: str, label: str) -> str:
        a = text.find(start_marker)
        b = text.find(end_marker, a + len(start_marker))
        if a < 0 or b < 0:
            if replacement in text:
                print(f"PASS already applied: {label}")
                return text
            raise SystemExit(f"PATCH ERROR [{label}]: function boundary missing")
        if replacement in text[a:b]:
            print(f"PASS already applied: {label}")
            return text
        print(f"PATCHED: {label}")
        return text[:a] + replacement + "\n" + text[b:]

    convert_function = r'''async function convertFilesToDxf(){try{const fs=document.getElementById('fileToDxfInput').files;if(!fs.length)return alert('اختر ملفًا أو أكثر.');const cadFiles=[...fs].filter(f=>/\.(?:dxf|dwg)$/i.test(String(f.name||'')));if(cadFiles.length){if(fs.length!==1)throw new Error('للحفاظ على اللوحة الأصلية، اختر ملف CAD واحدًا فقط في كل مرة.');const f=cadFiles[0],model=await parseFile(f);if(!(model.rawDXFBytes instanceof Uint8Array))throw new Error('تعذر إنشاء سجل DXF صالح من الملف؛ لم تتم إعادة رسم اللوحة أو إنشاء ملف بديل.');lastFileToDxfModel=model;lastFileToDxfDXF=model.rawDXFBytes;const isDwg=/\.dwg$/i.test(f.name);document.getElementById('fileToDxfSummary').innerHTML=`تمت قراءة لوحة CAD: <b>${escapeHtml(f.name)}</b>. ${isDwg?'تم تحويل DWG إلى DXF بالكيانات التي يدعمها محرك LibreDWG.':'تم الاحتفاظ ببايتات DXF الأصلية دون إعادة رسم.'} لم يتم إنشاء هندسة تقريبية بديلة.`;document.getElementById('fileToDxfResults').style.display='block';return;}const sets=await parsePointFiles(fs),pts=[],seen=new Set();for(const set of sets)for(const p of set.points){if(!Number.isFinite(p.e)||!Number.isFinite(p.n)||!Number.isFinite(p.z))continue;const k=`${p.id}|${p.e.toFixed(6)}|${p.n.toFixed(6)}|${p.z.toFixed(6)}`;if(!seen.has(k)){seen.add(k);pts.push(p);}}if(!pts.length)throw new Error('لم يتم العثور على نقاط مساحية في الملفات.');const style=document.getElementById('pointStyle').value,size=Number(document.getElementById('pointStyleSize').value)||.5,th=Number(document.getElementById('pointTextSize').value)||.3;const entities=[];for(const p of pts){entities.push(...pointMarkerEntities(p,style,size));entities.push({type:'TEXT',layer:'POINT_LABELS',position:{x:p.e+size*1.2,y:p.n+size*1.2,z:p.z},height:th,text:String(p.id)});entities.push({type:'TEXT',layer:'ELEVATIONS',position:{x:p.e+size*1.2,y:p.n-size*1.2,z:p.z},height:Math.max(.08,th*.75),text:Number(p.z).toFixed(3)});}lastFileToDxfModel={entities,points:pts};lastFileToDxfDXF=buildR12FromEntities(entities);if(!validateGeneratedDXF(lastFileToDxfDXF))throw new Error('تعذر تكوين DXF صالح.');document.getElementById('fileToDxfSummary').innerHTML=`تمت قراءة ${fs.length} ملفًا. وجد البرنامج <b>${pts.length}</b> نقطة. الاستايل: <b>${escapeHtml(style)}</b>، حجم النقطة: <b>${size}</b>، حجم الكتابة: <b>${th}</b>.`;document.getElementById('fileToDxfResults').style.display='block';}catch(e){alert('تعذر تحويل الملفات: '+(e.message||e));}}'''
    source = replace_function(source, "async function convertFilesToDxf(){", "async function downloadFileToDxf(){", convert_function, "route CAD input through the shared byte-preserving reader")

    clean_function = r'''async function cleanSurveyFiles(){try{const fs=document.getElementById('cleanFilesInput').files;if(!fs.length)return alert('اختر ملفًا أو أكثر.');cleanedCadBytes=null;cleanedCadFilename='';const cadFiles=[...fs].filter(f=>/\.(?:dxf|dwg)$/i.test(String(f.name||'')));if(cadFiles.length){if(fs.length!==1)throw new Error('للحفاظ على اللوحة، اختر ملف CAD واحدًا فقط في كل مرة.');const f=cadFiles[0],model=await parseFile(f);if(!(model.rawDXFBytes instanceof Uint8Array))throw new Error('تعذر إنشاء سجل DXF صالح؛ لم يتم حذف عناصر أو إعادة رسم اللوحة.');cleanedCadBytes=model.rawDXFBytes;cleanedCadFilename=String(f.name||'SurveyQuant_CAD').replace(/\.(?:dxf|dwg)$/i,'')+'_CAD_Preserved.dxf';cleanedPoints=[];cleanedText='';cleanedCSV='';document.getElementById('cleanOutputFormat').value='dxf';document.getElementById('cleanFilesSummary').innerHTML=`تمت قراءة لوحة CAD: <b>${escapeHtml(f.name)}</b>. تم تجهيز DXF للحفظ دون حذف عناصر أو تكرارات هندسية أو إعادة رسم اللوحة. ${/\.dwg$/i.test(f.name)?'مصدر DWG حُوّل إلى سجل DXF بواسطة محرك LibreDWG.':'احتُفظ ببايتات DXF الأصلية.'}`;document.getElementById('cleanFilesResults').style.display='block';return;}if(document.getElementById('cleanOutputFormat').value==='dxf')document.getElementById('cleanOutputFormat').value='txt';const sets=await parsePointFiles(fs),map=new Map();let total=0;for(const set of sets){total+=set.points.length;for(const p of set.points){const k=String(p.id||'').trim()+'|'+p.e.toFixed(6)+'|'+p.n.toFixed(6)+'|'+p.z.toFixed(6);if(!map.has(k))map.set(k,p);}}cleanedPoints=[...map.values()];cleanedText=cleanedPoints.map(p=>`${p.id},${p.e.toFixed(6)},${p.n.toFixed(6)},${p.z.toFixed(6)}`).join('\n');cleanedCSV='Point,Easting,Northing,Elevation\n'+cleanedText;document.getElementById('cleanFilesSummary').innerHTML=`تم دمج <b>${fs.length}</b> ملفًا. النقاط الأصلية: <b>${total}</b>، التكرارات المحذوفة: <b>${total-cleanedPoints.length}</b>، المتبقي: <b>${cleanedPoints.length}</b>. اختر صيغة الإخراج ثم اضغط إخراج.`;document.getElementById('cleanFilesResults').style.display='block';}catch(e){alert('تعذر فلترة الملفات: '+(e.message||e));}}'''
    source = replace_function(source, "async function cleanSurveyFiles(){", "function downloadFilteredFiles(){", clean_function, "pass CAD boards through the file-filter project without reconstruction")

    download_function = r'''function downloadFilteredFiles(){const f=document.getElementById('cleanOutputFormat').value;if(f==='dxf'){if(!(cleanedCadBytes instanceof Uint8Array))return alert('صيغة DXF هنا مخصصة لحفظ ملف CAD واحد تم تحميله؛ اختر DWG/DXF أو استخدم صيغة نقاط للملفات النصية.');return safeDownloadFile(cleanedCadBytes,cleanedCadFilename||'SurveyQuant_CAD_Preserved.dxf','application/dxf',false);}if(!cleanedPoints?.length)return alert('نفذ الفلترة أولاً.');let data,name,mime;if(f==='sdr'){data=buildCleanedSDR();name='SurveyQuant_Filtered.sdr';mime='text/plain;charset=utf-8';}else if(f==='pnt'){data=buildCleanedPNT();name='SurveyQuant_Filtered.pnt';mime='text/plain;charset=utf-8';}else if(f==='csv'){data=cleanedCSV;name='SurveyQuant_Filtered.csv';mime='text/csv;charset=utf-8';}else{data=cleanedText;name='SurveyQuant_Filtered.txt';mime='text/plain;charset=utf-8';}return safeDownloadFile(data,name,mime);}'''
    source = replace_function(source, "function downloadFilteredFiles(){", "function downloadCleanedTXT(){", download_function, "retain raw CAD bytes when exporting from the file-filter project")

    if "function parseDWGDatabase(db){" not in source or "window.parseFile = parseFile;" not in source or "sq-v117-universal-dwg-bridge" not in source:
        raise SystemExit("PATCH ERROR: shared DWG/DXF reader or universal CAD file picker bridge is missing")
    path.write_text(source, encoding="utf-8")
    return source


def check_html(path: Path) -> None:
    source = path.read_text(encoding="utf-8")
    start = source.find("function sqBuildModernEntityRecords(")
    end = source.find("function sqApplyByteEdits(", start)
    writer = source[start:end]
    start2 = source.find("function surfacePointsFromModel(m){")
    end2 = source.find("function triArea2(", start2)
    surface = source[start2:end2]
    if not writer or not surface:
        raise SystemExit("CHECK ERROR: required CAD functions are absent")
    if "addCadEntity(m,type,layer" in writer or "(type==='XLINE'||type==='RAY')" in writer:
        raise SystemExit("CHECK ERROR: invalid XLINE/RAY branch remains in modern DXF writer")
    if "(type==='XLINE'||type==='RAY')" in surface or "addCadEntity(m,type,layer" in surface:
        raise SystemExit("CHECK ERROR: non-surface XLINE/RAY branch remains in surface extractor")
    if "const fileContent=(sourceBytes.byteOffset===0" not in source:
        raise SystemExit("CHECK ERROR: DWG buffer allocation optimization is missing")
    if "model.rawDXFBytes=bytes;" not in source or "model.rawDWGBytes=sourceBytes;" not in source:
        raise SystemExit("CHECK ERROR: raw-byte retention optimization is missing")

    for marker in [".dxf,.dwg,application/dxf,application/dwg", "cleanedCadBytes=model.rawDXFBytes", "lastFileToDxfDXF=model.rawDXFBytes", "var NON_CAD_DATA_IDS = new Set();"]:
        if marker not in source:
            raise SystemExit("CHECK ERROR: universal CAD support missing: " + marker)

    # Execute the exact extracted surface helper against mixed CAD entities. A LINE
    # preceding a face/polyline previously threw ReferenceError: type is not defined.
    match = re.search(r"function surfacePointsFromModel\(m\)\{[\s\S]*?\n\}", source)
    if not match:
        raise SystemExit("CHECK ERROR: surface extraction function could not be isolated for regression testing")
    test_js = r'''const assert=require('node:assert/strict');
const surfacePointsFromModel = __SURFACE_FUNCTION__;
const model={points:[],entities:[
 {type:'LINE',layer:'AXIS',a:{x:0,y:0,z:0},b:{x:10,y:0,z:0}},
 {type:'POINT',layer:'P',id:'P1',position:{x:100,y:200,z:5}},
 {type:'3DFACE',layer:'F',vertices:[{x:110,y:210,z:1},{x:120,y:210,z:2},{x:110,y:220,z:3}]},
 {type:'POLYLINE3D',layer:'SURF',vertices:[{x:130,y:230,z:4},{x:140,y:240,z:5}]},
 {type:'XLINE',basePoint:{x:0,y:0,z:0},directionVector:{x:1,y:0,z:0}}
]};
const points=surfacePointsFromModel(model);
assert.equal(points.length,6,'POINT + 3DFACE vertices + 3D polyline vertices should survive; lines are not surface points');
assert.deepEqual(points.map(p=>[p.e,p.n,p.z]),[[100,200,5],[110,210,1],[120,210,2],[110,220,3],[130,230,4],[140,240,5]]);
console.log('PASS V157 mixed-entity surface parser regression: '+points.length+' vertices; LINE/XLINE safely ignored');
'''.replace("__SURFACE_FUNCTION__", match.group(0))
    with tempfile.TemporaryDirectory(prefix="sq-v157-test-") as td:
        test_path = Path(td) / "surface-regression.cjs"
        test_path.write_text(test_js, encoding="utf-8")
        subprocess.run(["node", str(test_path)], check=True)

    def function_slice(start_marker: str, end_marker: str) -> str:
        a = source.find(start_marker)
        b = source.find(end_marker, a + len(start_marker))
        if a < 0 or b < 0:
            raise SystemExit(f"CHECK ERROR: cannot isolate {start_marker}")
        return source[a:b].strip()

    convert_fn = function_slice("async function convertFilesToDxf(){", "async function downloadFileToDxf(){")
    clean_fn = function_slice("async function cleanSurveyFiles(){", "function downloadFilteredFiles(){")
    download_fn = function_slice("function downloadFilteredFiles(){", "function downloadCleanedTXT(){")
    utility_js = r'''const assert=require('node:assert/strict');
const fakeBytes=new Uint8Array([0,1,2,3,255]);
const elements={
 fileToDxfInput:{files:[{name:'preserved-board.dxf'}]},
 fileToDxfSummary:{innerHTML:''}, fileToDxfResults:{style:{display:'none'}},
 cleanFilesInput:{files:[{name:'native-board.dwg'}]}, cleanOutputFormat:{value:'txt'},
 cleanFilesSummary:{innerHTML:''}, cleanFilesResults:{style:{display:'none'}}
};
const document={getElementById:id=>elements[id]};
const parseFile=async f=>({source:/\.dwg$/i.test(f.name)?'DWG':'DXF',rawDXFBytes:fakeBytes,entities:[]});
const escapeHtml=s=>String(s);
const alert=s=>{throw new Error('Unexpected alert: '+s)};
let lastFileToDxfDXF='',lastFileToDxfModel=null,cleanedPoints=[],cleanedText='',cleanedCSV='',cleanedCadBytes=null,cleanedCadFilename='';
let downloaded=null;
async function safeDownloadFile(content,filename,mime){downloaded={content,filename,mime};return 'ok';}
__CONVERT_FN__
__CLEAN_FN__
__DOWNLOAD_FN__
(async()=>{
 await convertFilesToDxf();
 assert.strictEqual(lastFileToDxfDXF,fakeBytes,'DXF utility must retain the source byte array');
 assert.equal(elements.fileToDxfResults.style.display,'block');
 await cleanSurveyFiles();
 assert.strictEqual(cleanedCadBytes,fakeBytes,'file filter must retain DWG-derived DXF bytes');
 assert.equal(elements.cleanOutputFormat.value,'dxf');
 assert.match(cleanedCadFilename,/native-board_CAD_Preserved\.dxf$/);
 await downloadFilteredFiles();
 assert.strictEqual(downloaded.content,fakeBytes,'CAD download must not reconstruct geometry');
 console.log('PASS V157 utility integration: DXF converter + DWG filter pass through the original/converted CAD byte stream');
})().catch(e=>{console.error(e);process.exitCode=1});
'''.replace('__CONVERT_FN__', convert_fn).replace('__CLEAN_FN__', clean_fn).replace('__DOWNLOAD_FN__', download_fn)
    with tempfile.TemporaryDirectory(prefix="sq-v157-cad-utility-test-") as td:
        utility_path = Path(td) / "cad-utility-regression.cjs"
        utility_path.write_text(utility_js, encoding="utf-8")
        subprocess.run(["node", str(utility_path)], check=True)

    # Parse every executable inline script from the packaged HTML with Node.
    blocks = re.findall(r'<script\b([^>]*)>([\s\S]*?)</script\s*>', source, re.I)
    checked = 0
    with tempfile.TemporaryDirectory(prefix="sq-v157-syntax-") as td:
        for idx, (attrs, body) in enumerate(blocks):
            if not body.strip() or re.search(r'type\s*=\s*["\'](?:application/json|application/ld\+json|importmap)["\']', attrs, re.I):
                continue
            p = Path(td) / f"script_{idx}.js"
            p.write_text(body, encoding="utf-8")
            subprocess.run(["node", "--check", str(p)], check=True)
            checked += 1
    if checked < 2:
        raise SystemExit(f"CHECK ERROR: expected at least two executable inline scripts, found {checked}")
    required = ["onclick=\"openProjectPage('project1Card')\"", "onclick=\"openProjectPage('dropFilesCard')\"", "function parseDWGDatabase(db){", "window.parseFile = parseFile;", "sq-v117-universal-dwg-bridge"]
    missing = [x for x in required if x not in source]
    if missing:
        raise SystemExit("CHECK ERROR: required app/CAD markers missing: " + ", ".join(missing))
    forbidden = ["sq155-alignment-core", "sq155-alignment-command", "sqOpenOrientationProject", "startKashierPayment", "openPaymentPage", "payment-shortcut"]
    found = [x for x in forbidden if x in source]
    if found:
        raise SystemExit("CHECK ERROR: removed Alignment/payment module reappeared: " + ", ".join(found))
    print(f"PASS V157 shared CAD checks: {checked} inline JS blocks parse; shared DWG/DXF reader and free-project markers retained; no source redraw introduced")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--html", type=Path, required=True)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    if not args.html.is_file():
        raise SystemExit(f"ERROR: HTML file not found: {args.html}")
    if not args.check_only:
        patch_html(args.html)
    check_html(args.html)

if __name__ == "__main__":
    main()
