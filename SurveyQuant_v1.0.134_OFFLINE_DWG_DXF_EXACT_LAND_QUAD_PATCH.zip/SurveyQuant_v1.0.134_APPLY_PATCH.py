#!/usr/bin/env python3
"""SurveyQuant v1.0.134: package DWG/DXF engines locally and enforce exact land-side geometry."""
from __future__ import annotations
import argparse
import re
import zipfile
from pathlib import Path
from tempfile import NamedTemporaryFile

MARKER = "SURVEYQUANT_V134_DWG_LOCAL_ENGINE_EXACT_LAND_QUAD"
LOCAL_ENGINE_URL = "./libredwg-writer/dist/libredwg-web.js"
LOCAL_DXF_URL = "./dxf-parser.js"

# Four entered lengths are A-B, B-C, C-D, D-A. A diagonal AC is selected
# automatically from the common feasible interval, then both triangles are
# constructed on opposite sides of AC. The best convex candidate is retained.
GEOMETRY_FUNCTIONS = r'''function cyclicPolygonFromSides(sides){
  if(Array.isArray(sides)&&sides.length===4)return constructConvexQuadFromSides(sides);
  const longest=Math.max(...sides),sum=sides.reduce((a,b)=>a+b,0);
  if(sides.length<3||longest>=sum-longest)return null;
  const f=R=>sides.reduce((a,v)=>a+2*Math.asin(Math.min(.999999999,v/(2*R))),0)-2*Math.PI;
  let lo=longest/2+1e-9,hi=Math.max(sum,1)*1000;
  for(let i=0;i<100;i++){const mid=(lo+hi)/2;if(f(mid)>0)lo=mid;else hi=mid;}
  const R=(lo+hi)/2,angs=sides.map(v=>2*Math.asin(Math.min(1,v/(2*R))));
  let t=0,pts=[{x:R,y:0}];
  for(let i=0;i<sides.length-1;i++){t+=angs[i];pts.push({x:R*Math.cos(t),y:R*Math.sin(t)});}
  return pts;
}
function constructConvexQuadFromSides(sides){
  if(!Array.isArray(sides)||sides.length!==4)return null;
  const [a,b,c,d]=sides.map(Number);
  if(![a,b,c,d].every(v=>Number.isFinite(v)&&v>0))return null;
  const low=Math.max(Math.abs(a-b),Math.abs(c-d));
  const high=Math.min(a+b,c+d);
  const span=high-low, scale=Math.max(a,b,c,d,1);
  if(!(span>scale*1e-10))return null;
  let best=null,bestScore=-1;
  for(let i=1;i<1000;i++){
    const q=low+span*i/1000;
    const xb=(a*a+q*q-b*b)/(2*q);
    const xd=(d*d+q*q-c*c)/(2*q);
    const hb2=a*a-xb*xb, hd2=d*d-xd*xd;
    const minH2=scale*scale*1e-14;
    if(hb2<=minH2||hd2<=minH2)continue;
    const pts=[{x:0,y:0},{x:xb,y:Math.sqrt(hb2)},{x:q,y:0},{x:xd,y:-Math.sqrt(hd2)}];
    const turns=[];
    for(let j=0;j<4;j++){
      const p=pts[j],r=pts[(j+1)%4],s=pts[(j+2)%4];
      turns.push((r.x-p.x)*(s.y-r.y)-(r.y-p.y)*(s.x-r.x));
    }
    const eps=scale*scale*1e-10;
    if(!(turns.every(v=>v< -eps)||turns.every(v=>v>eps)))continue;
    const lengths=pts.map((p,j)=>Math.hypot(pts[(j+1)%4].x-p.x,pts[(j+1)%4].y-p.y));
    if(lengths.some((v,j)=>Math.abs(v-sides[j])>Math.max(1e-6,Math.abs(sides[j])*1e-7)))continue;
    const score=Math.min(...turns.map(Math.abs));
    if(score>bestScore){best=pts;bestScore=score;}
  }
  return best;
}
function validateLandPolygonSideLengths(pts,sides){
  if(!Array.isArray(pts)||!Array.isArray(sides)||pts.length!==sides.length)
    throw new Error('تعذر إنشاء حدود هندسية تطابق عدد الأضلاع المدخلة.');
  for(let i=0;i<sides.length;i++){
    const p=pts[i],q=pts[(i+1)%pts.length];
    const actual=Math.hypot(Number(q.x)-Number(p.x),Number(q.y)-Number(p.y));
    const expected=Number(sides[i]);
    if(!Number.isFinite(actual)||Math.abs(actual-expected)>Math.max(1e-5,Math.abs(expected)*1e-6))
      throw new Error('تعذر رسم مضلع مغلق بأطوال الأضلاع المكتوبة بدقة. للأرض الرباعية غيّر الأطوال أو أدخل القطر الصحيح.');
  }
  return true;
}
'''


def patch_html(source: str) -> str:
    if MARKER in source:
        raise SystemExit("ERROR: V134 marker already present; refusing to apply the patch twice.")

    # Replace both historical DWG loaders with the local ESM module. The runtime
    # path is relative to app/src/main/assets/index.html (APK assets/index.html).
    writer_rx = re.compile(r"https?://[^\s\"'`<>]+/libredwg-writer/dist/libredwg-web\.js")
    source, nw = writer_rx.subn(LOCAL_ENGINE_URL, source)
    unpkg_rx = re.compile(r"https?://unpkg\.com/@mlightcad/libredwg-web@0\.7\.14/dist/libredwg-web\.js")
    source, nu = unpkg_rx.subn(LOCAL_ENGINE_URL, source)
    if nw + nu == 0 and LOCAL_ENGINE_URL not in source:
        raise SystemExit("ERROR: no recognized remote LibreDWG loader was found; refusing to ship an unpatched DWG loader.")

    # DXF parsing must also work offline, without the jsDelivr script dependency.
    dxf_rx = re.compile(r"https?://cdn\.jsdelivr\.net/npm/dxf-parser@1\.1\.2/dist/dxf-parser\.js")
    source, nd = dxf_rx.subn(LOCAL_DXF_URL, source)
    if nd == 0 and LOCAL_DXF_URL not in source:
        # Also accept a future version-pinned URL from jsDelivr, but do not accept
        # an HTML page that has no local parser script reference at all.
        generic_dxf_rx = re.compile(r"https?://cdn\.jsdelivr\.net/npm/dxf-parser@[^\s\"'`<>]+/dist/dxf-parser\.js")
        source, nd = generic_dxf_rx.subn(LOCAL_DXF_URL, source)
    if nd == 0 and LOCAL_DXF_URL not in source:
        raise SystemExit("ERROR: no recognized DXF-parser script was found; cannot guarantee offline DXF reading.")

    # Replace the side-only geometry generator as one bounded region, preserving
    # all surrounding project UI and export logic.
    start_token = "function cyclicPolygonFromSides(sides)"
    start = source.find(start_token)
    if start < 0:
        raise SystemExit("ERROR: land-side geometry function was not found.")
    end_token = "function parseLandSideLengths()"
    end = source.find(end_token, start + len(start_token))
    if end < 0:
        raise SystemExit("ERROR: boundary after land-side geometry function was not found.")
    source = source[:start] + GEOMETRY_FUNCTIONS + source[end:]

    calc_start = source.find("function calculateLandArea()")
    if calc_start < 0:
        raise SystemExit("ERROR: calculateLandArea() was not found.")
    render_token = "renderLandArea(m2,method,pts,sides);"
    render_pos = source.find(render_token, calc_start)
    if render_pos < 0:
        raise SystemExit("ERROR: calculateLandArea() render boundary was not found.")
    # Guard the exact generated points before any report/DXF/PDF export can use them.
    source = source[:render_pos] + "if(sides.length===4)validateLandPolygonSideLengths(pts,sides);" + source[render_pos:]

    if "./libredwg-writer/dist/libredwg-web.js" not in source:
        raise SystemExit("ERROR: local DWG module path is missing after patch.")
    if "./dxf-parser.js" not in source:
        raise SystemExit("ERROR: local DXF parser path is missing after patch.")
    if re.search(r"https?://[^\s\"'`<>]+/libredwg-writer/dist/libredwg-web\.js", source):
        raise SystemExit("ERROR: a remote LibreDWG CDN URL remains in the app.")
    if "if(sides.length===4)validateLandPolygonSideLengths(pts,sides);renderLandArea(m2,method,pts,sides);" not in source:
        raise SystemExit("ERROR: exact land-side validation was not inserted before rendering.")

    marker_comment = "<!-- " + MARKER + " -->\n"
    if "</head>" in source:
        source = source.replace("</head>", marker_comment + "</head>", 1)
    else:
        source = marker_comment + source
    return source


def write_html(path: Path) -> None:
    original = path.read_text(encoding="utf-8")
    patched = patch_html(original)
    path.write_text(patched, encoding="utf-8")
    print(f"PASS: patched {path} ({len(original)} -> {len(patched)} chars)")


def patch_apk(input_apk: Path, output_apk: Path, engine_dir: Path, dxf_parser: Path) -> None:
    dist_js = engine_dir / "dist" / "libredwg-web.js"
    wasm_js = engine_dir / "wasm" / "libredwg-web.js"
    wasm_bin = engine_dir / "wasm" / "libredwg-web.wasm"
    if not dist_js.is_file() or dist_js.stat().st_size < 1000:
        raise SystemExit(f"ERROR: local DWG distribution module missing/short: {dist_js}")
    if not wasm_js.is_file() or wasm_js.stat().st_size < 1000:
        raise SystemExit(f"ERROR: local DWG WASM loader missing/short: {wasm_js}")
    if not wasm_bin.is_file() or wasm_bin.stat().st_size < 100_000:
        raise SystemExit(f"ERROR: separate WebAssembly binary missing/too small: {wasm_bin}")
    if wasm_bin.read_bytes()[:4] != b"\x00asm":
        raise SystemExit("ERROR: libredwg-web.wasm does not have the WebAssembly binary signature.")
    if not dxf_parser.is_file() or dxf_parser.stat().st_size < 1000:
        raise SystemExit(f"ERROR: local DXF parser missing/short: {dxf_parser}")

    additions = {
        "assets/libredwg-writer/dist/libredwg-web.js": dist_js.read_bytes(),
        "assets/libredwg-writer/wasm/libredwg-web.js": wasm_js.read_bytes(),
        "assets/libredwg-writer/wasm/libredwg-web.wasm": wasm_bin.read_bytes(),
        "assets/dxf-parser.js": dxf_parser.read_bytes(),
    }
    # Keep the diagnostic build configuration beside the code for traceability.
    conf = engine_dir / "BUILD_CONFIGURATION_V134.txt"
    if conf.is_file():
        additions["assets/libredwg-writer/BUILD_CONFIGURATION_V134.txt"] = conf.read_bytes()

    output_apk.parent.mkdir(parents=True, exist_ok=True)
    seen = set()
    with zipfile.ZipFile(input_apk, "r") as zin, zipfile.ZipFile(output_apk, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zout:
        names = zin.namelist()
        if "assets/index.html" not in names:
            raise SystemExit("ERROR: source APK does not contain assets/index.html.")
        for info in zin.infolist():
            name = info.filename
            if name in additions:
                continue
            # Old v1 signature material cannot remain after repacking; apksigner runs later.
            if name.startswith("META-INF/") and name.upper().endswith((".RSA", ".DSA", ".EC", ".SF", ".MF")):
                continue
            data = zin.read(name)
            if name == "assets/index.html":
                data = patch_html(data.decode("utf-8")).encode("utf-8")
            zout.writestr(info, data)
            seen.add(name)
        for name, data in additions.items():
            if name in seen:
                raise SystemExit(f"ERROR: duplicate APK asset path: {name}")
            zout.writestr(name, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)

    # Reopen the ZIP and fail closed if the embedded dependencies are missing.
    with zipfile.ZipFile(output_apk, "r") as z:
        required = list(additions) + ["assets/index.html"]
        missing = [n for n in required if n not in z.namelist()]
        if missing:
            raise SystemExit("ERROR: APK output is missing assets: " + ", ".join(missing))
        html = z.read("assets/index.html").decode("utf-8")
        if MARKER not in html:
            raise SystemExit("ERROR: output APK HTML lost the V134 marker.")
        wasm_payload = z.read("assets/libredwg-writer/wasm/libredwg-web.wasm")
        if len(wasm_payload) < 100_000 or wasm_payload[:4] != b"\x00asm":
            raise SystemExit("ERROR: separate WASM payload is missing or invalid in APK.")
    print(f"PASS: packaged local DWG/DXF engines and exact land-side geometry into {output_apk}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--html", type=Path, help="Patch a source index.html")
    ap.add_argument("--apk", type=Path, help="Input APK to patch")
    ap.add_argument("--output", type=Path, help="Output APK path")
    ap.add_argument("--engine-dir", type=Path, help="Directory containing dist/ and wasm/")
    ap.add_argument("--dxf-parser", type=Path, help="Path to dxf-parser.js")
    args = ap.parse_args()
    if args.html:
        write_html(args.html)
        return
    if args.apk:
        if not all((args.output, args.engine_dir, args.dxf_parser)):
            ap.error("--apk requires --output, --engine-dir, and --dxf-parser")
        patch_apk(args.apk, args.output, args.engine_dir, args.dxf_parser)
        return
    ap.error("provide --html or --apk")

if __name__ == "__main__":
    main()
