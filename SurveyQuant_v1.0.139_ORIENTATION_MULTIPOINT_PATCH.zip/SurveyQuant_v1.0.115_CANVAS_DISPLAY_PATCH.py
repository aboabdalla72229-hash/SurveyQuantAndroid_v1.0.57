from pathlib import Path
import sys

path = Path(sys.argv[1])
source = path.read_text(encoding='utf-8')

def replace_once(old, new, label):
    global source
    count = source.count(old)
    if count != 1:
        raise SystemExit(f'ERROR: expected exactly one {label} anchor; found {count}.')
    source = source.replace(old, new, 1)

replace_once(
    "const old=state.views[side];if(old&&old.resizeHandler)window.removeEventListener('resize',old.resizeHandler);",
    "const old=state.views[side];if(old&&old.resizeObserver)old.resizeObserver.disconnect();if(old&&old.resizeHandler)window.removeEventListener('resize',old.resizeHandler);",
    'previous canvas observer cleanup',
)
replace_once(
    "function setupCanvas(v){const c=v.canvas;if(!c)return;const resize=()=>{const r=c.getBoundingClientRect(),dpr=Math.max(1,window.devicePixelRatio||1);c.width=Math.max(1,Math.round(r.width*dpr));c.height=Math.max(1,Math.round(r.height*dpr));v.ctx=c.getContext('2d');v.ctx.setTransform(dpr,0,0,dpr,0,0);draw(v);};v.resizeHandler=resize;resize();c.addEventListener('pointerdown',e=>{",
    "function setupCanvas(v){const c=v.canvas;if(!c)return;const resize=()=>{const r=c.getBoundingClientRect();if(!r||r.width<2||r.height<2)return;const dpr=Math.max(1,window.devicePixelRatio||1),width=Math.max(1,Math.round(r.width*dpr)),height=Math.max(1,Math.round(r.height*dpr));if(c.width!==width)c.width=width;if(c.height!==height)c.height=height;v.ctx=c.getContext('2d');if(!v.ctx)return;v.ctx.setTransform(dpr,0,0,dpr,0,0);draw(v);};v.resizeHandler=resize;resize();if(typeof window.ResizeObserver==='function'){v.resizeObserver=new window.ResizeObserver(()=>resize());v.resizeObserver.observe(c);}c.addEventListener('pointerdown',e=>{",
    'zero-size-safe canvas setup and ResizeObserver',
)
replace_once(
    "function showScreen(which){const t=el('sq110TargetScreen'),r=el('sq110ReferenceScreen');if(t)t.style.display=which==='target'?'block':'none';if(r)r.style.display=which==='reference'?'block':'none';if(which==='reference'&&state.views.reference)draw(state.views.reference);if(which==='target'&&state.views.target)draw(state.views.target);el('sq110Step1').style.opacity=which==='target'?'1':'.65';el('sq110Step2').style.opacity=which==='reference'?'1':'.65';}",
    "function refreshVisibleCadCanvas(side){const v=state.views[side];if(!v)return;const refresh=()=>{if(!v.canvas||!v.drawing)return;const r=v.canvas.getBoundingClientRect();if(!r||r.width<2||r.height<2)return;if(typeof v.resizeHandler==='function')v.resizeHandler();else draw(v);};if(typeof window.requestAnimationFrame==='function')window.requestAnimationFrame(()=>window.requestAnimationFrame(refresh));else setTimeout(refresh,80);}function showScreen(which){const t=el('sq110TargetScreen'),r=el('sq110ReferenceScreen');if(t)t.style.display=which==='target'?'block':'none';if(r)r.style.display=which==='reference'?'block':'none';if(which==='reference'&&state.views.reference)draw(state.views.reference);if(which==='target'&&state.views.target)draw(state.views.target);refreshVisibleCadCanvas(which);el('sq110Step1').style.opacity=which==='target'?'1':'.65';el('sq110Step2').style.opacity=which==='reference'?'1':'.65';}",
    'screen-switch canvas refresh',
)
replace_once(
    "const view=loadView(side,data.bytes,data.name);if(side==='target')",
    "const view=loadView(side,data.bytes,data.name);refreshVisibleCadCanvas(side);if(side==='target')",
    'post-import canvas refresh',
)
replace_once(
    'window.__sqOrientation111API=Object.assign(window.__sqOrientation110API,{state,loadView,fillReadouts,draw,calculation,exportTarget,status,showScreen,updatePickLabels,nearestSnap,metrics,project,unproject});',
    'window.__sqOrientation111API=Object.assign(window.__sqOrientation110API,{state,loadView,fillReadouts,draw,calculation,exportTarget,status,showScreen,updatePickLabels,nearestSnap,metrics,project,unproject,refreshVisibleCadCanvas});',
    'canvas display regression hook',
)
required = [
    'if(!r||r.width<2||r.height<2)return;',
    "new window.ResizeObserver(()=>resize())",
    'refreshVisibleCadCanvas(which)',
    'refreshVisibleCadCanvas(side)',
    'unproject,refreshVisibleCadCanvas',
]
missing = [token for token in required if token not in source]
if missing:
    raise SystemExit('ERROR: board display patch verification failed: ' + ', '.join(missing))
path.write_text(source, encoding='utf-8')
print('PASS: board display fix applied (responsive canvas size, safe hidden state, redraw on import/screen switch).')
