#!/usr/bin/env python3
"""Inject the tested V165 native-curve/snap/raster engine into the V164 Android app."""
from __future__ import annotations
import argparse, base64, re
from pathlib import Path

META = '<meta name="surveyquant-v165" content="sq165-native-curves-exact-snap-raster-fix">'


def embed_engine(html: str, engine: bytes) -> str:
    pattern = r'(<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">)([A-Za-z0-9+/=\r\n]+)(</script>)'
    payload = base64.b64encode(engine).decode('ascii')
    html, count = re.subn(pattern, lambda m: m.group(1) + payload + m.group(3), html, count=1, flags=re.I)
    if count != 1:
        raise ValueError(f'Expected exactly one embedded CAD engine slot, found {count}')
    return html


def patch_html(html: str, engine: bytes) -> str:
    if 'sq165-native-curves-exact-snap-raster-fix' in html:
        raise ValueError('V165 patch already applied; refusing duplicate injection')
    for marker in ('sq164-cad-output-axis-fix', 'sq163-cad-engine', 'sq163RawCadOverlayMerge',
                   'sq163-pdfjs-worker', 'sqDownloadNameDialog', 'function safeDownloadFile(',
                   'window.Android.notifyDownload'):
        if marker not in html:
            raise ValueError(f'Missing required V164 save/CAD/PDF marker: {marker}')
    head = re.search(r'<head\b[^>]*>', html, re.I)
    if not head:
        raise ValueError('HTML head tag not found')
    html = html[:head.end()] + META + html[head.end():]
    html = embed_engine(html, engine)
    validate(html, engine)
    return html


def validate(html: str, engine: bytes) -> None:
    for marker in (META, 'sq164-cad-output-axis-fix', 'sqDownloadNameDialog',
                   'const requestedName=await chooseDownloadFilename(',
                   'window.Android.saveFile(finalName,mime,base64)',
                   'window.Android.notifyDownload(finalName,String(result),mime)',
                   'sq163RawCadOverlayMerge', 'sq163-pdfjs-worker', 'sq162-wasm-binary'):
        if marker not in html:
            raise ValueError('V165 app validation failed: ' + marker)
    if "window.prompt('اكتب اسم اللوحة / الملف المخرج:" in html:
        raise ValueError('Legacy output prompt remains')
    m = re.search(r'<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">([A-Za-z0-9+/=\r\n]+)</script>', html, re.I)
    if not m or base64.b64decode(m.group(1)) != engine:
        raise ValueError('Embedded V165 engine does not match the tested engine file')
    text = engine.decode('utf-8')
    for marker in ('SQ_V165_NATIVE_CURVES_RAW_TRANSFORM_SNAP_AND_RASTER_EXPORT',
                   "mode:'raw-dxf-record-transform'", "else if(type==='SPLINE')",
                   'function snapPoint(geometry, point, mode=', 'angleOnArc',
                   "const content=paths.filter(p=>!isFrame(p))",
                   'root.safeDownloadFile(bytes, filename, mime, false)',
                   "if(type==='CIRCLE'||type==='ARC')mul(40)"):
        if marker not in text:
            raise ValueError('V165 engine required behavior is missing: ' + marker)
    if "const content=paths.filter(p=>!isFrame(p))" not in text:
        raise ValueError('Raster exporter no longer excludes the page frame')


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument('--html', required=True, type=Path)
    p.add_argument('--engine', required=True, type=Path)
    p.add_argument('--check-only', action='store_true')
    a = p.parse_args()
    html = a.html.read_text(encoding='utf-8')
    engine = a.engine.read_bytes()
    if a.check_only:
        validate(html, engine)
        print('PASS V165 injection validation: V164 native save/name/notification retained; exact V165 CAD engine embedded.')
        return
    out = patch_html(html, engine)
    a.html.write_text(out, encoding='utf-8')
    print(f'PASS V165 patch applied: {a.html} ({len(out):,} HTML chars; {len(engine):,} engine bytes)')


if __name__ == '__main__':
    main()
