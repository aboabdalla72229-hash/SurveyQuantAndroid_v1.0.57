#!/usr/bin/env python3
"""Remove SurveyQuant's two-board Alignment project and all subscription/payment gates.
Keep shared DWG/DXF parsing/runtime so the remaining projects retain CAD import support.
"""
from __future__ import annotations
import argparse, re
from pathlib import Path


def must_replace(text: str, old: str, new: str, label: str, count: int = 1) -> str:
    actual = text.count(old)
    if actual != count:
        raise ValueError(f"{label}: expected {count} occurrence(s), found {actual}")
    return text.replace(old, new, count)


def patch_html(src: str) -> str:
    original = src
    # Hide/remove payment entry point from the project's main menu.
    src, n = re.subn(r'\n?<button class="menu-btn payment-shortcut" onclick="openPaymentPage\(\)" type="button">[\s\S]*?</button>', '', src, count=1)
    if n != 1:
        raise ValueError(f"payment shortcut: expected one menu button, found {n}")
    src = must_replace(
        src,
        '.menu-btn.payment-shortcut{grid-column:1 / -1;background:#0b7d58;border-color:#57d4c4}',
        '',
        'payment shortcut CSS'
    )
    src = must_replace(
        src,
        'اختر المشروع من الاختصارات. كل مشروع يفتح في صفحة مستقلة، وكل صفحة تجمع أدوات القراءة والحساب والإخراج الخاصة بالمشروع. الملفات المحفوظة تظهر في Downloads/SurveyQuant وإشعارات الهاتف. زر التفعيل والدفع موجود مستقلًا خارج المشاريع.',
        'اختر المشروع من الاختصارات. كل مشروع يفتح في صفحة مستقلة، وكل صفحة تجمع أدوات القراءة والحساب والإخراج الخاصة بالمشروع. الملفات المحفوظة تظهر في Downloads/SurveyQuant وإشعارات الهاتف.',
        'home menu note'
    )

    # Delete the Alignment-only block expansion helper and its sole invocation.
    helper_start = src.find('function sqAlignmentPreviewFromBlocks(model,db){')
    helper_end = src.find('function parseDWGDatabase(db){', helper_start + 1)
    if helper_start < 0 or helper_end < 0:
        raise ValueError('Alignment-only block preview helper boundaries not found')
    src = src[:helper_start] + src[helper_end:]
    call = ' try{sqAlignmentPreviewFromBlocks(m,db);}catch(e){m.alignmentPreviewWarning=String(e?.message||e);}'
    src = must_replace(src, call, '', 'Alignment-only preview invocation')
    src = must_replace(
        src,
        '   // DXF conversion is only a temporary record stream for the alignment export.\n   // The display/axis picker uses the native DWG database when available.',
        '   // Keep a temporary DWG-to-DXF record stream for project tools that consume DXF bytes.\n   // Native database data remains the preferred source for supported CAD geometry and axes.',
        'DWG conversion comment'
    )
    src = must_replace(
        src,
        '// Shared, tested DWG/DXF reader exposed for the two-board orientation screen.',
        '// Shared, tested DWG/DXF reader used by the app CAD-capable projects.',
        'shared reader comment'
    )
    src = must_replace(
        src,
        "  var CAD_INPUT_IDS = new Set([\n    'cadFileInput', 'quantBeforeFile', 'quantAfterFile', 'quantFileInput',\n    'profileFileInput', 'dropSurveyFiles', 'dropCadFile',\n    'sq155SourceFile', 'sq155ReferenceFile'\n  ]);",
        "  var CAD_INPUT_IDS = new Set([\n    'cadFileInput', 'quantBeforeFile', 'quantAfterFile', 'quantFileInput',\n    'profileFileInput', 'dropSurveyFiles', 'dropCadFile'\n  ]);",
        'CAD input list'
    )
    src = must_replace(src, 'Recreate the drawing WebView so no in-memory source/target board survives re-entry.', 'Recreate the drawing WebView so previously opened drawing state does not survive re-entry.', 'session reset comment')
    src = must_replace(
        src,
        '// The normal parseFile(file) path already has a DWG reader; orientation screens use their\n  // own temporary conversion only where the orientation algorithm specifically needs DXF bytes.',
        '// The normal parseFile(file) path already has a DWG reader; project tools use this\n  // temporary conversion only where they specifically need DXF bytes.',
        'shared DWG conversion comment'
    )
    src = must_replace(src, 'merge|orientation|section', 'merge|section', 'CAD input hint')
    src = must_replace(src, '|توجيه|دمج', '|دمج', 'Arabic CAD input hint')

    # Remove the entire server activation/trial/Kashier implementation and startup poll.
    gate_start = src.find("const SURVEYQUANT_API_BASE = '")
    gate_end = src.find('// ===== SurveyQuant v1.0.47 output review =====', gate_start + 1)
    if gate_start < 0 or gate_end < 0:
        raise ValueError('Activation/payment JavaScript section boundaries not found')
    gate_section = src[gate_start:gate_end]
    for token in ('sqInitAccess', 'sqEnsureGate', 'startKashierPayment', 'pollKashierStatus', 'SURVEYQUANT_API_BASE'):
        if token not in gate_section:
            raise ValueError(f'Expected activation marker absent from removed section: {token}')
    src = src[:gate_start] + src[gate_end:]

    # Remove direct payment-page handlers from main script.
    src, n = re.subn(
        r"function openPaymentPage\(\)\{[^\n]*\}\nfunction closePaymentPage\(\)\{[^\n]*\}\n?",
        '', src, count=1
    )
    if n != 1:
        raise ValueError(f'payment-page handlers: expected one block, found {n}')
    src = must_replace(
        src,
        '// If the backend is temporarily unavailable, payment page remains usable and explains the connection state.\n',
        '',
        'payment backend comment'
    )
    src = must_replace(
        src,
        "const page=document.getElementById('paymentPage'),card=document.getElementById('paymentCard');if(page)page.style.display='none';if(card)card.style.display='block';",
        '',
        'payment-page startup DOM code'
    )

    # Remove payment overlay markup, bounded by the Alignment script that immediately followed it.
    pay_start = src.find('<div class="page-overlay" id="paymentPage">')
    align_start = src.find('<script id="sq155-alignment-core">', pay_start + 1)
    if pay_start < 0 or align_start < 0:
        raise ValueError('Payment overlay / following Alignment script boundary not found')
    src = src[:pay_start] + src[align_start:]

    # Delete both executable Alignment modules. This also deletes their dynamically-created project card and overlay.
    for script_id in ('sq155-alignment-core', 'sq155-alignment-command'):
        pattern = rf'<script id="{re.escape(script_id)}">[\s\S]*?</script>'
        src, n = re.subn(pattern, '', src, count=1)
        if n != 1:
            raise ValueError(f'{script_id}: expected exactly one script block, found {n}')

    # Retain the generic first-launch storage reset, but remove the obsolete feature-specific label.
    src = must_replace(src, 'surveyquant-v155-fresh-alignment-session', 'surveyquant-fresh-session-reset', 'session reset script id')
    src = src.replace('payment/device identity', 'settings identity')

    # Guardrails: all access gates and the Alignment UI/engine must be gone from the shipped HTML.
    forbidden = (
        'sq155-alignment-core', 'sq155-alignment-command', 'sqOpenOrientationProject',
        'openOrientationProject', 'sqInitAccess', 'sqAccessGate', 'sqGateSubscribe',
        'startKashierPayment', 'pollKashierStatus', 'openPaymentPage', 'closePaymentPage',
        'paymentPage', 'paymentCard', 'payment-shortcut', 'SURVEYQUANT_API_BASE',
        'sqAlignmentPreviewFromBlocks', 'alignmentPreviewEntities', 'sq155SourceFile',
        'sq155ReferenceFile', 'alignment', 'Alignment', 'orientation', 'Orientation',
        'توجيه', 'Kashier', 'payment', 'subscription', 'تفعيل', 'اشتراك', 'الدفع',
    )
    residual = [word for word in forbidden if word in src]
    if residual:
        raise ValueError('Forbidden UI/code markers remain: ' + ', '.join(residual))

    # Required unaffected features remain present.
    required = (
        "onclick=\"openProjectPage('project1Card')\"",
        "onclick=\"openProjectPage('dropFilesCard')\"",
        'function parseDWGDatabase(db){',
        'window.parseFile = parseFile;',
        'sq-v117-universal-dwg-bridge',
        'function convertFilesToDxf',
        'function calculateRoad',
    )
    missing = [word for word in required if word not in src]
    if missing:
        raise ValueError('A required non-Alignment app feature is missing: ' + ', '.join(missing))
    if src == original:
        raise ValueError('No changes applied')
    return src


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--html', required=True, type=Path, help='Path to the current app index.html')
    p.add_argument('--output', type=Path, help='Output HTML path; defaults to in-place')
    p.add_argument('--check-only', action='store_true', help='Validate that a patched HTML is clean without rewriting it')
    args = p.parse_args()
    source = args.html.read_text(encoding='utf-8')
    if args.check_only:
        forbidden = ('sq155-alignment-core', 'sq155-alignment-command', 'sqInitAccess', 'startKashierPayment', 'paymentPage', 'payment-shortcut', 'sqAlignmentPreviewFromBlocks', 'sq155SourceFile', 'sq155ReferenceFile', 'orientation', 'Alignment', 'Kashier', 'توجيه', 'تفعيل', 'اشتراك', 'الدفع')
        bad = [x for x in forbidden if x in source]
        if bad:
            raise SystemExit('FAIL: forbidden markers: ' + ', '.join(bad))
        print('PASS: no Alignment project or activation/payment gate markers remain')
        return
    result = patch_html(source)
    out = args.output or args.html
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(result, encoding='utf-8')
    print(f'PASS: removed Alignment UI/engine and activation/payment flow; retained shared DWG bridge. Wrote {out} ({len(result)} bytes)')

if __name__ == '__main__':
    main()
