# SurveyQuant V1.0.199 - Corrected Single Canvas / Orientation / Point Data Addendum

## Build identity
- Deliverable APK version: 1.0.199 (versionCode 199).
- Base lineage: V162 source/APK run 40919113310, followed by V176 compatibility and V177 correction stages.
- The addendum module and patcher keep their internal V177 names to preserve the established integration markers and CAD API lineage.

## Corrective change in this package
- The actual V177 CAD engine exports its API as `SurveyQuantCAD177` and `SurveyQuantCAD176`.
- The previous V199 package incorrectly searched for `SurveyQuantCAD162`; that mismatch stopped the build during the addendum injection step.
- This corrected package binds to `SurveyQuantCAD177` first, then `SurveyQuantCAD176`, with `SurveyQuantCAD162` only as a compatibility fallback.
- The appender now validates the actual V177 API export. Its self-test fixture and structural test use the same V177 API name.

## Included functions
- Single-canvas source/reference board orientation.
- Point-data export helpers (CSV, TXT, SDR, XLSX, PDF and annotation DXF).
- Select single CAD entity, window select, select similar, delete selected in current editing session, restore deleted entities.
- No localStorage persistence for project/session state.

## Important limitations
- Delete/restore is an in-session editing/display operation. This package does not claim permanent removal of deleted original DXF entities from the exported file; export is refused for the unsupported delete state.
- This is a source patch ZIP, not an APK. GitHub Actions must complete the build and signing stages.
- Synthetic checks do not replace testing the actual Android APK with the original DWG/DXF/PDF files.
- Full fidelity for all custom CAD entities and every PDF font/color/lineweight encoding is not guaranteed by this addendum.
