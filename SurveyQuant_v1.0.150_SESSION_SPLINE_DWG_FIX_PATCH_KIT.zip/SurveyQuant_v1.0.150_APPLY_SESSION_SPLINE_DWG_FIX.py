#!/usr/bin/env python3
"""V150 repair: reset per-board state, true spline preview, and canonical DWG parsing."""
from __future__ import annotations
import argparse, hashlib, re
from pathlib import Path

OLD_VERSION = 'const SQ_APP_VERSION_CODE = 149;'
NEW_VERSION = 'const SQ_APP_VERSION_CODE = 150;'
ACTIVE_ID = 'sq-orientation-reference-board-module'

def replace_once(s: str, old: str, new: str, label: str) -> str:
    n = s.count(old)
    if n != 1:
        raise ValueError(f'{label}: expected one occurrence, got {n}')
    return s.replace(old, new, 1)

def replace_function(text: str, name: str, replacement: str, next_anchor: str) -> str:
    pattern = re.compile(r'(?ms)^async function ' + re.escape(name) + r'\([^\n]*?\)\{.*?^' + re.escape(next_anchor))
    match = pattern.search(text)
    if not match:
        raise ValueError(f'Cannot locate async function {name} through anchor {next_anchor}')
    # Preserve the next anchor, which pattern consumed.
    suffix = match.group(0)[-len(next_anchor):]
    return text[:match.start()] + replacement + '\n' + suffix + text[match.end():]

def patch(source: str) -> tuple[str, dict]:
    if source.count(OLD_VERSION) != 1:
        raise ValueError('Expected exactly one V149 app version code in source HTML')
    source = source.replace(OLD_VERSION, NEW_VERSION, 1)
    source = replace_once(source,
        'id="surveyquant-v149-fresh-board-session"',
        'id="surveyquant-v150-fresh-board-session"',
        'fresh-session script id')
    source = replace_once(source, 'WCS • V149', 'WCS • V150', 'orientation screen title')
    source = source.replace('height:38vh;min-height:220px;max-height:420px',
                            'height:34vh;min-height:200px;max-height:360px')

    # The DWG file chooser now uses the app's canonical parser (which performs the
    # same LibreDWG conversion as the main app and verifies readable entities).
    parse_anchor = " throw new Error('امتداد غير مدعوم: .'+ext);\n}\nfunction layerUI(model,targetId)"
    source = replace_once(source, parse_anchor,
        " throw new Error('امتداد غير مدعوم: .'+ext);\n}\n// Shared, tested DWG/DXF reader exposed for the two-board orientation screen.\nwindow.parseFile = parseFile;\nfunction layerUI(model,targetId)",
        'canonical main parser export')

    m = re.search(r'(<script\b(?=[^>]*\bid=["\']' + re.escape(ACTIVE_ID) + r'["\'])[^>]*>)([\s\S]*?)(</script\s*>)', source, re.I)
    if not m:
        raise ValueError('active two-board orientation script not found')
    body = m.group(2)

    body = replace_once(body,
        "const SQ_PREVIEW_OCS_TYPES = new Set(['POINT','CIRCLE','ARC','INSERT','TEXT','ATTRIB','ATTDEF','LWPOLYLINE','POLYLINE','SOLID','TRACE','HATCH','SHAPE']);",
        "const SQ_PREVIEW_OCS_TYPES = new Set(['POINT','CIRCLE','ARC','INSERT','TEXT','MTEXT','ATTRIB','ATTDEF','LWPOLYLINE','POLYLINE','SOLID','TRACE','HATCH','SHAPE']);",
        'include MTEXT in OCS WCS fallback')

    # The native parser's generic preview can render SPLINE control vertices as chords.
    # Force the geometry-aware fallback whenever a SPLINE appears in model or nested blocks,
    # even if all extrusion normals are canonical +Z and the file is otherwise small.
    body = replace_once(body,
        "const needsWcsPreview=[...all,...nestedRecords].some(sqPreviewHasNonCanonicalOcs);",
        "const needsWcsPreview=[...all,...nestedRecords].some(sqPreviewHasNonCanonicalOcs);\n const needsSplinePreview=[...all,...nestedRecords].some(r=>String(r.type||'').toUpperCase()==='SPLINE');\n const needsFallbackPreview=needsWcsPreview||needsSplinePreview;",
        'force geometry-aware preview for SPLINE records')
    body = replace_once(body,
        "if(needsWcsPreview)primaryError=new Error('تم تفعيل معاينة WCS لأن اللوحة تحتوي على عناصر OCS بمحاور غير قياسية.');",
        "if(needsFallbackPreview)primaryError=new Error(needsWcsPreview?'تم تفعيل معاينة WCS لأن اللوحة تحتوي على عناصر OCS بمحاور غير قياسية.':'تم تفعيل معاينة المنحنيات الحقيقية لعناصر SPLINE.');",
        'select OCS/SPLINE-aware preview path')
    body = replace_once(body,
        'base.previewLowMemory=bytes.length>MEMORY_SAFE_PREVIEW_BYTES;base.previewWcsFallback=needsWcsPreview;',
        'base.previewLowMemory=bytes.length>MEMORY_SAFE_PREVIEW_BYTES;base.previewWcsFallback=needsWcsPreview;base.previewSplineFallback=needsSplinePreview;',
        'expose preview fallback diagnosis')

    spline_old = r''' if(t==='SPLINE'){
  // Use only control vertices in the preview. Groups 12/13 are tangents, never line endpoints.
  const vertices=pairsFor(10,20);chain(vertices,false);return {pts,segments};
 }'''
    spline_new = r''' if(t==='SPLINE'){
  // Render the actual spline curve, not the control polygon. Group 12/13 are tangents,
  // never points. If knots are incomplete, use fit points; if those are absent, retain
  // control points as isolated OSNAP anchors rather than inventing connecting lines.
  const list=code=>p.filter(q=>q.code===code).map(q=>num(q.value)).filter(q=>q!==null);
  const cx=list(10),cy=list(20),knots=list(40),weights=list(41),degree=Math.max(1,Math.min(10,Math.round(pairVal(rec,71)??3))),count=Math.min(cx.length,cy.length);
  let curve=[];
  if(count>degree&&knots.length===count+degree+1&&knots.every(Number.isFinite)){
   const lo=knots[degree],hi=knots[count];
   if(Number.isFinite(lo)&&Number.isFinite(hi)&&hi>lo){
    const controls=Array.from({length:count},(_,i)=>{const w=weights.length===count&&Number.isFinite(weights[i])&&weights[i]>0?weights[i]:1;return {x:cx[i]*w,y:cy[i]*w,w};});
    const evaluate=tval=>{
     let span=count-1;
     for(let i=degree;i<count;i++){if(tval>=knots[i]&&tval<knots[i+1]){span=i;break;}}
     if(tval>=hi)span=count-1;
     const d=[];for(let j=0;j<=degree;j++){const q=controls[span-degree+j];d[j]={x:q.x,y:q.y,w:q.w};}
     for(let r=1;r<=degree;r++)for(let j=degree;j>=r;j--){const i=span-degree+j,den=knots[i+degree-r+1]-knots[i],a=Math.abs(den)<1e-15?0:(tval-knots[i])/den,aa=Math.max(0,Math.min(1,a)),left=d[j-1],right=d[j];d[j]={x:(1-aa)*left.x+aa*right.x,y:(1-aa)*left.y+aa*right.y,w:(1-aa)*left.w+aa*right.w};}
     const q=d[degree];return Math.abs(q.w)>1e-15?{x:q.x/q.w,y:q.y/q.w}:{x:q.x,y:q.y};
    };
    let samples=0,last=null;
    for(let k=degree;k<count&&samples<4096;k++){
     const a=knots[k],b=knots[k+1];if(!(b>a))continue;
     const steps=Math.max(8,Math.min(64,Math.ceil((b-a)/(hi-lo)*128)));
     for(let j=0;j<=steps&&samples<4096;j++){
      if(last&&j===0)continue;const tv=a+(b-a)*j/steps,q=evaluate(tv);
      if(Number.isFinite(q.x)&&Number.isFinite(q.y)){curve.push(q);last=q;samples++;}
     }
    }
   }
  }
  if(curve.length<2){
   const fx=list(11),fy=list(21);
   if(fx.length>=2&&fy.length>=2){curve=Array.from({length:Math.min(fx.length,fy.length)},(_,i)=>({x:fx[i],y:fy[i]}));}
   else {for(let i=0;i<count;i++)add({x:cx[i],y:cy[i]});return {pts,segments};}
  }
  chain(curve,false);return {pts,segments};
 }'''
    body = replace_once(body, spline_old, spline_new, 'true spline preview')

    # Add per-board load generation; old async file conversions can no longer restore stale state.
    body = replace_once(body,
        "idPoint:{target:null,reference:null},bound:false};",
        "idPoint:{target:null,reference:null},loadSerial:{target:0,reference:0},bound:false};",
        'load generation state')

    open_cad_old = r'''async function openCad(file){if(!file)throw new Error('اختر ملف اللوحة.');const ext=file.name.toLowerCase().split('.').pop();if(ext==='dxf')return {bytes:await bytesOfDxf(file),name:file.name};if(ext==='dwg'){
  const api=window.__sqOriAxisAutoTest;if(!api||typeof api.convertTargetToDxf!=='function')throw new Error('محرك قراءة DWG غير متاح. احفظ اللوحة DXF نصيًا ثم افتحها.');
  const converted=await api.convertTargetToDxf(file);return {bytes:converted.bytes,name:converted.name||file.name.replace(/\.dwg$/i,'.dxf')};
 }throw new Error('الصيغة المدعومة لهذه العملية هي DXF أو DWG الذي يمكن تحويله إلى DXF.');}'''
    open_cad_new = r'''async function openCad(file){
 if(!file)throw new Error('اختر ملف اللوحة.');
 const ext=String(file.name||'').toLowerCase().split('.').pop();
 if(ext==='dxf')return {bytes:await bytesOfDxf(file),name:file.name};
 if(ext==='dwg'){
  // Use the same tested reader as the rest of SurveyQuant. It converts the selected
  // DWG once, verifies the converted DXF has readable CAD entities, and keeps the
  // untouched DWG bytes in its model. Do not silently leave the previous board up.
  if(typeof window.parseFile!=='function')throw new Error('قارئ DWG المشترك لم يُحمّل. أغلق مشروع التوجيه وافتحه مرة أخرى.');
  let model;
  try{model=await window.parseFile(file);}catch(e){throw new Error('تعذر فتح ملف DWG عبر محرك LibreDWG: '+String(e&&e.message||e)+'. تم تفريغ اللوحة السابقة ولم يتم استبدالها بنتيجة قديمة.');}
  const out=model&&model.rawDXFBytes;
  if(!(out instanceof Uint8Array)||out.length<64)throw new Error('حوّل محرك DWG الملف دون إرجاع DXF صالح للمعاينة. لم يتم الإبقاء على أي لوحة قديمة.');
  return {bytes:out.slice(),name:file.name.replace(/\.dwg$/i,'.dxf')};
 }
 throw new Error('الصيغة المدعومة لهذه العملية هي DXF أو DWG الذي يمكن تحويله إلى DXF.');
}'''
    body = replace_once(body, open_cad_old, open_cad_new, 'shared DWG parsing path')

    # Central lifecycle reset helpers are called on both open and close, and when replacing one board.
    reset_helpers = r'''function clearCanvasRuntime(side){
 const v=state.views&&state.views[side];
 if(v){try{if(v.resizeObserver)v.resizeObserver.disconnect();}catch(_){}try{if(v.resizeHandler)window.removeEventListener('resize',v.resizeHandler);}catch(_){}try{if(v.selectionLongPressTimer)clearTimeout(v.selectionLongPressTimer);}catch(_){}try{if(v.pointerMap)v.pointerMap.clear();}catch(_){} }
 const canvasId=side==='target'?'sq110TargetCanvas':'sq110ReferenceCanvas',canvas=el(canvasId);
 if(canvas&&canvas.parentNode){const fresh=canvas.cloneNode(false);canvas.parentNode.replaceChild(fresh,canvas);}
 const layerPanel=el(side==='target'?'sq110TLayerPanel':'sq110RLayerPanel');if(layerPanel)layerPanel.innerHTML='';
 const details=el(side==='target'?'sq110TLayerDetails':'sq110RLayerDetails');if(details)details.open=false;
 if(state.views)state.views[side]=null;
}
function resetOrientationState(){
 state.loadSerial=state.loadSerial||{target:0,reference:0};state.loadSerial.target=(state.loadSerial.target||0)+1;state.loadSerial.reference=(state.loadSerial.reference||0)+1;
 state.target=null;state.reference=null;state.targetPoints=[null,null];state.referencePoints=[null,null];state.active={target:0,reference:0};state.tool={target:'pick',reference:'pick'};state.snapMode={target:'auto',reference:'auto'};state.views={};
 state.selectedEntity=null;state.selectedEntities=[];state.undoStack=[];state.redoStack=[];state.referenceSelectedEntity=null;state.referenceSelectedEntities=[];state.referenceUndoStack=[];state.referenceRedoStack=[];state.idPoint={target:null,reference:null};
}
function resetSession(announce=false){
 clearCanvasRuntime('target');clearCanvasRuntime('reference');resetOrientationState();
 for(const id of ['sq110TargetFile','sq110ReferenceFile']){const n=el(id);if(n)n.value='';}
 for(const id of ['sq110TargetFileInfo','sq110ReferenceFileInfo','sq110TargetInfo','sq110ReferenceInfo','sq110TargetId','sq110ReferenceId']){const n=el(id);if(n)n.textContent='';}
 for(const id of ['sq110T1X','sq110T1Y','sq110T2X','sq110T2Y','sq110R1X','sq110R1Y','sq110R2X','sq110R2Y']){const n=el(id);if(n)n.value='';}
 for(const id of ['sq110StatusPoint1','sq110StatusPoint2']){const n=el(id);if(n)n.textContent='النقطة '+(id.endsWith('1')?'1':'2')+': لم تُحدد بعد';}
 const tMode=el('sq110TargetMode');if(tMode)tMode.textContent='اختر النقطة 1 على الرسم';const rMode=el('sq110ReferenceMode');if(rMode)rMode.textContent='اختر النقطة 1 على الرسم المرجعي';
 fillReadouts();updateDeleteHistoryButtons();showScreen('target');
 if(announce)status('بدأت جلسة توجيه جديدة. تم مسح اللوحتين والنقاط والمعاينة السابقة؛ اختر ملفاتك من جديد.',false);
 else {const s=el('sq110Status');if(s){s.textContent='';s.style.display='none';}}
}
window.sqOpenOrientationProject=function(){resetSession(true);const overlay=el('sqOriOverlay');if(overlay)overlay.style.display='block';showScreen('target');};
window.sqCloseOrientationProject=function(){resetSession(false);const overlay=el('sqOriOverlay');if(overlay)overlay.style.display='none';};
'''
    api_anchor = 'window.__sqOrientation110API={VERSION,solve,validateAlignmentBounds,transformBytes:universalTransformBytes,deleteNearestEntityBytes,findNearestEntityBytes,findEntitiesInWindowBytes,removeSelectedEntityBytes,removeSelectedEntitiesBytes,splitPairs,sectionRecords,recordGeometry,geometryInWorld,blockDefinitions,parsePreview,validateDxfOutputLight,entityTypeSignature};'
    body = replace_once(body, api_anchor, reset_helpers + api_anchor, 'session reset hooks')
    body = replace_once(body,
        'window.__sqOrientation111API=Object.assign(window.__sqOrientation110API,{state,loadView,fillReadouts,draw,calculation,exportTarget,status,showScreen,updatePickLabels,nearestSnap,metrics,project,unproject,refreshVisibleCadCanvas,deleteSelectedEntity,undoDelete,redoDelete,targetSnapshot});',
        'window.__sqOrientation111API=Object.assign(window.__sqOrientation110API,{state,loadView,fillReadouts,draw,calculation,exportTarget,status,showScreen,updatePickLabels,nearestSnap,metrics,project,unproject,refreshVisibleCadCanvas,deleteSelectedEntity,undoDelete,redoDelete,targetSnapshot,resetSession,clearCanvasRuntime,openCad});',
        'export reset and DWG API')

    choose_old = re.search(r'async function chooseFile\(side,file\)\{[\s\S]*?\nfunction calculation\(\)', body)
    if not choose_old:
        raise ValueError('chooseFile function end anchor not found')
    choose_new = r'''function prepareSideForReplacement(side){
 clearCanvasRuntime(side);state[side]=null;
 if(side==='target'){
  state.targetPoints=[null,null];state.selectedEntity=null;state.selectedEntities=[];state.undoStack=[];state.redoStack=[];
 }else{
  state.referencePoints=[null,null];state.referenceSelectedEntity=null;state.referenceSelectedEntities=[];state.referenceUndoStack=[];state.referenceRedoStack=[];
 }
 state.idPoint[side]=null;state.active[side]=0;state.tool[side]='pick';
 const otherView=state.views[side==='target'?'reference':'target'];if(otherView&&otherView.alignmentPreview){otherView.alignmentPreview=null;draw(otherView);}
 const info=el(side==='target'?'sq110TargetFileInfo':'sq110ReferenceFileInfo');if(info)info.textContent='';
 const id=el(side==='target'?'sq110TargetId':'sq110ReferenceId');if(id)id.textContent='ID Point: غير مفعل';
 fillReadouts();updateDeleteHistoryButtons();
}
async function chooseFile(side,file){
 if(!file)return;
 const token=(state.loadSerial[side]||0)+1;state.loadSerial[side]=token;
 prepareSideForReplacement(side);
 status('تم إخلاء اللوحة السابقة من هذه الخانة. جارٍ قراءة '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+'...');
 try{
  const data=await openCad(file);
  if(token!==state.loadSerial[side])return;
  if(!data||!(data.bytes instanceof Uint8Array)||data.bytes.length<64)throw new Error('ملف اللوحة فارغ أو لم ينتج بيانات CAD صالحة.');
  state[side]={bytes:data.bytes.slice(),name:data.name||file.name};
  const view=loadView(side,state[side].bytes,state[side].name);
  if(token!==state.loadSerial[side]){clearCanvasRuntime(side);state[side]=null;return;}
  if(side==='target'){state.selectedEntity=null;state.selectedEntities=[];state.undoStack=[];state.redoStack=[];}
  else{state.referenceSelectedEntity=null;state.referenceSelectedEntities=[];state.referenceUndoStack=[];state.referenceRedoStack=[];}
  state.active[side]=0;state.tool[side]='pick';state.idPoint[side]=null;
  fillReadouts();updateDeleteHistoryButtons();draw(view);refreshVisibleCadCanvas(side);
  const info=el(side==='target'?'sq110TargetFileInfo':'sq110ReferenceFileInfo');
  if(info)info.textContent='الملف: '+file.name+' | عناصر: '+view.drawing.entityCount+' | مقاطع: '+(view.drawing.segs||[]).length+' | طبقات: '+Object.keys(view.drawing.layers||{}).length+' | معاينة: '+(view.drawing.previewWcsFallback?'WCS/OCS':view.drawing.previewSplineFallback?'Spline/CAD':view.drawing.previewLowMemory?'ذاكرة منخفضة':'عادية')+(view.drawing.previewTruncated?' (المعاينة محدودة فقط)':'');
  status('تم فتح '+file.name+'. تم تصفير نقاط هذه اللوحة قبل القراءة. '+(view.drawing.previewWarning||'اختر النقطتين ثم كرر الترتيب نفسه على اللوحة المرجعية.')+(view.drawing.previewRecoveryMessage?' '+view.drawing.previewRecoveryMessage:''),false);
 }catch(e){
  if(token!==state.loadSerial[side])return;
  clearCanvasRuntime(side);state[side]=null;
  const inp=el(side==='target'?'sq110TargetFile':'sq110ReferenceFile');if(inp)inp.value='';
  const info=el(side==='target'?'sq110TargetFileInfo':'sq110ReferenceFileInfo');if(info)info.textContent='';
  const msg='تعذر فتح '+file.name+': '+String(e&&e.message||e)+'. تم تفريغ هذه الخانة حتى لا تظهر نتيجة لوحة سابقة مكان الملف الجديد.';
  fillReadouts();status(msg,true);
 }
}
function calculation()'''
    body = body[:choose_old.start()] + choose_new + body[choose_old.end():]

    # Reset the file input's value so selecting the same filename again still triggers change.
    body = replace_once(body,
        "el('sq110TargetFile').addEventListener('change',e=>{const f=e.target.files&&e.target.files[0];if(f)chooseFile('target',f);});el('sq110ReferenceFile').addEventListener('change',e=>{const f=e.target.files&&e.target.files[0];if(f)chooseFile('reference',f);});",
        "el('sq110TargetFile').addEventListener('change',e=>{const f=e.target.files&&e.target.files[0];e.target.value='';if(f)chooseFile('target',f);});el('sq110ReferenceFile').addEventListener('change',e=>{const f=e.target.files&&e.target.files[0];e.target.value='';if(f)chooseFile('reference',f);});",
        'reselect same file handler')

    # Make picked-coordinate reports explicitly identify WCS/source and target values; do not fabricate positive coordinates.
    body = replace_once(body,
        "status('تم تسجيل النقطة '+(i+1)+' في '+(v.side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+' عند X='+snap.p.x.toFixed(6)+' وY='+snap.p.y.toFixed(6)+'. الرقم نفسه سيطابق النقطة '+(i+1)+' في اللوحة الأخرى.');",
        "status('تم تسجيل النقطة '+(i+1)+' بإحداثيات WCS داخل '+(v.side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+': X='+snap.p.x.toFixed(6)+' وY='+snap.p.y.toFixed(6)+'. إشارة الإحداثي لا تُغيّر صناعيًا؛ بعد الحساب يجب أن تطابق النقطة المحوّلة إحداثيات المرجع.');",
        'explicit WCS coordinate readout')

    # Improve review diagnostic so point mapping can be audited before export.
    old_status = "status('معاينة التراكب جاهزة: المرجع ظاهر بألوانه الأصلية واللوحة المنقولة فوقه باللون السماوي. معامل المقياس ×'+t.scale.toFixed(10)+' | الدوران '+t.angleDeg.toFixed(8)+'° | الإزاحة X='+t.tx.toFixed(6)+' وY='+t.ty.toFixed(6)+' | خطأ النقطتين '+Math.max(...errors).toExponential(3)+' | تداخل امتداد اللوحتين '+(overlapRatio*100).toFixed(2)+'%. خطوط السماوي معاينة فقط وليست إضافات إلى ملف DXF.');"
    new_status = "status('معاينة التراكب جاهزة. معامل المقياس ×'+t.scale.toFixed(10)+' | الدوران '+t.angleDeg.toFixed(8)+'° | الإزاحة X='+t.tx.toFixed(6)+' وY='+t.ty.toFixed(6)+' | خطأ التطابق '+Math.max(...errors).toExponential(3)+' | P1 بعد التحويل=('+t.point(state.targetPoints[0].x,state.targetPoints[0].y).x.toFixed(6)+', '+t.point(state.targetPoints[0].x,state.targetPoints[0].y).y.toFixed(6)+') | P2 بعد التحويل=('+t.point(state.targetPoints[1].x,state.targetPoints[1].y).x.toFixed(6)+', '+t.point(state.targetPoints[1].x,state.targetPoints[1].y).y.toFixed(6)+'). تمت مقارنة النقطتين بإحداثيات WCS للمرجع. القيم السالبة في بقية اللوحة لا تُحوّل إلى موجبة قسرًا لأن ذلك يكسر التطابق.',false);"
    body = replace_once(body, old_status, new_status, 'alignment point diagnostic')

    # Preserve the compact mobile canvas request with a safer 34vh viewport.
    body = body.replace('height:38vh;min-height:220px;max-height:420px', 'height:34vh;min-height:200px;max-height:360px')

    source = source[:m.start(2)] + body + source[m.end(2):]
    # Updating source's lifecycle tag is outside the active script; update it only once above.
    details = {
        'version':150,
        'spline_preview':'rational B-spline sampled; no control-polygon chords when knots missing',
        'session_reset':'open/close and every new file attempt clear relevant in-memory board state',
        'dwg_path':'uses canonical parseFile DWG->DXF parser and checks rawDXFBytes',
        'wcs_coordinate_diagnostic':'point mapping residual and negative coordinates explicitly explained',
        'mobile_canvas':'34vh, 200-360px',
        'sha256':hashlib.sha256(source.encode()).hexdigest(),
    }
    return source, details

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-html',type=Path,required=True)
    ap.add_argument('--output-html',type=Path,required=True)
    ap.add_argument('--report',type=Path,required=True)
    args=ap.parse_args()
    source=args.input_html.read_text(encoding='utf-8')
    output,report=patch(source)
    args.output_html.parent.mkdir(parents=True,exist_ok=True)
    args.output_html.write_text(output,encoding='utf-8',newline='')
    args.report.write_text('# V150 Root Cause Fix\n\n'+ '\n'.join(f'- **{k}**: `{v}`' for k,v in report.items())+'\n',encoding='utf-8')
    print('PASS: V150 patched source; SHA-256 '+report['sha256'])
if __name__=='__main__':main()
