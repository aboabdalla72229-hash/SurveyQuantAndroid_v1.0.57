from pathlib import Path
import os, shutil
import base64
import ezdxf
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent
html_path=root/'index.html' if (root/'index.html').is_file() else root/'source/index.html'
html=html_path.read_text()
source=root/'source_A.dxf'; target=root/'target_A.dxf'; target2=root/'target_B.dxf'; replacement=root/'alt/source_A.dxf'
with sync_playwright() as p:
 browser_bin=os.environ.get('CHROMIUM_BIN') or shutil.which('chromium') or shutil.which('chromium-browser')
 b=p.chromium.launch(executable_path=browser_bin,headless=True,args=['--no-sandbox','--allow-file-access-from-files'])
 page=b.new_page(viewport={'width':430,'height':900})
 errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded',timeout=90000)
 page.evaluate("window.__nativeSaved=null;window.__nativeNotified=null;window.Android={saveFile:(filename,mime,base64)=>{window.__nativeSaved={filename,mime,base64};},notifyDownload:(filename,path,mime)=>{window.__nativeNotified={filename,path,mime};}};")
 page.wait_for_timeout(500)
 page.locator('#sq176-home-orientation-project').click()
 page.locator('#sq162-source-file').set_input_files(str(source));page.wait_for_timeout(700)
 assert 'source_A.dxf' in page.locator('#sq162-source-info').inner_text()
 page.locator('#sq162-target-file').set_input_files(str(target));page.wait_for_timeout(700)
 assert 'target_A.dxf' in page.locator('#sq162-target-info').inner_text()
 def pick(slot,side,xy):
  page.locator(f'#sq162-pick-{slot}').click();page.wait_for_timeout(50)
  px=page.evaluate("""({side,xy})=>{const c=document.getElementById('sq162-'+side+'-canvas'),m=c._sqMap,p=m.pt({x:xy[0],y:xy[1]}),r=c.getBoundingClientRect();return {x:r.left+p.x,y:r.top+p.y};}""",{'side':side,'xy':xy})
  page.mouse.click(px['x'],px['y']);page.wait_for_timeout(70)
 def aligned():
  page.locator('#sq162-do-align').click();page.wait_for_timeout(120)
  status=page.locator('#sq162-align-status').inner_text();assert 'تم توجيه اللوحة' in status,status
  assert not page.locator('#sq162-save-oriented').is_disabled()
 # Original pair A -> A.
 for args in [(0,'source',(100,200)),(1,'source',(110,200)),(2,'target',(1000,2000)),(3,'target',(1000,2020))]:pick(*args)
 aligned()
 # Replace target via actual picker. Its old transform and all four points must disappear.
 with page.expect_file_chooser() as fc: page.locator('#sq162-target-file').click()
 fc.value.set_files(str(target2));page.wait_for_timeout(900)
 details=page.locator('#sq162-transform-details').inner_text()
 assert 'target_B.dxf' in page.locator('#sq162-target-info').inner_text()
 assert 'تم اعتماد هذا التحويل' not in details and 'لم تُحدد بعد' in details
 assert page.locator('#sq162-save-oriented').is_disabled()
 # New target B, new four points.
 for args in [(0,'source',(100,200)),(1,'source',(110,200)),(2,'target',(2000,3000)),(3,'target',(2000,3020))]:pick(*args)
 aligned()
 # Replace source with a different file having the SAME basename. Stale source picks and the
 # previously completed transform must be invalidated before the picker returns.
 with page.expect_file_chooser() as fc: page.locator('#sq162-source-file').click()
 fc.value.set_files(str(replacement));page.wait_for_timeout(900)
 details=page.locator('#sq162-transform-details').inner_text()
 assert 'source_A.dxf' in page.locator('#sq162-source-info').inner_text()
 assert 'تم اعتماد هذا التحويل' not in details and 'لم تُحدد بعد' in details
 assert page.locator('#sq162-save-oriented').is_disabled()
 # Fresh coordinates from replacement source_A and current target_B.
 for args in [(0,'source',(300,500)),(1,'source',(310,500)),(2,'target',(2000,3000)),(3,'target',(2000,3020))]:pick(*args)
 aligned()
 page.locator('#sq162-oriented-name').fill('Aligned_Second_Target')
 page.locator('#sq162-save-oriented').click();page.wait_for_function('window.__nativeSaved!==null',timeout=30000)
 saved=page.evaluate('window.__nativeSaved');assert saved['filename']=='Aligned_Second_Target.dxf',saved['filename']
 assert page.evaluate('window.__nativeNotified.filename')=='Aligned_Second_Target.dxf'
 out=root/'V180_ORIENTATION_UI_OUTPUT.dxf';out.write_bytes(base64.b64decode(saved['base64']))
 doc=ezdxf.readfile(out);pts=[(round(v.dxf.location.x,5),round(v.dxf.location.y,5)) for pl in doc.modelspace().query('POLYLINE') for v in pl.vertices]
 assert (2000.0,3000.0) in pts and (2000.0,3020.0) in pts and (1980.0,3020.0) in pts,pts
 audit=doc.audit();assert not audit.errors and not audit.fixes
 # Re-entering the project must drop both loaded boards and all diagnostics.
 page.evaluate("document.getElementById('sq176-home-orientation-project').click()")
 page.wait_for_timeout(150)
 details=page.locator('#sq162-transform-details').inner_text()
 assert 'لم يتم تحميله' in details and 'تم اعتماد هذا التحويل' not in details,details
 assert page.locator('#sq162-save-oriented').is_disabled()
 print('PASS orientation UI: both target and source reloads cleared all four point slots and previous alignment; same-name/different-bytes source replaced correctly; fresh four points produced 90-degree transform; named Android save and DXF coordinates verified; re-entry cleared session.')
 print('unrelated page-shell errors observed in the unmodified base app:',errors[:10])
 b.close()
