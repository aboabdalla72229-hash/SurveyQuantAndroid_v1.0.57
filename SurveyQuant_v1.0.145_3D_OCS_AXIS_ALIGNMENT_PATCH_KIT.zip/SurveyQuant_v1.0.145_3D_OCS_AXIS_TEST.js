'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const file = process.argv[2];
assert(file, 'Usage: node SurveyQuant_v1.0.145_3D_OCS_AXIS_TEST.js <V144-index.html>');
const html = fs.readFileSync(file, 'utf8');
function body(text,id){
  const re=new RegExp(`<script\\b(?=[^>]*\\bid=["']${id}["'])[^>]*>([\\s\\S]*?)<\\/script\\s*>`,'ig');
  const a=[...text.matchAll(re)]; assert.equal(a.length,1,`one ${id} module must exist`); return a[0][1];
}
assert(html.includes('const SQ_APP_VERSION_CODE = 145;'),'V145 version code must be set');
assert(html.includes('surveyquant-v145-fresh-board-session'),'V145 fresh-board session guard must be tagged');
assert(html.includes('function transformMLeaderRecord'),'MLEADER-specific transform must exist');
const window={__sqOrientTest:{}};
const document={readyState:'loading',addEventListener(){},getElementById(){return null;},querySelector(){return null;},querySelectorAll(){return [];},createElement(){return {style:{},appendChild(){},remove(){},click(){}};},head:{appendChild(){}},body:{appendChild(){},classList:{add(){},remove(){}}}};
const context={window,document,console,Uint8Array,ArrayBuffer,Map,Set,Math,Number,String,Object,RegExp,Error,Promise,Blob:global.Blob,URL:global.URL,TextEncoder,TextDecoder,performance:{now:()=>0},setTimeout,clearTimeout};
window.window=window;window.document=document;vm.createContext(context);
vm.runInContext(body(html,'sq-orientation-reference-board-module'),context,{timeout:5000});
const api=window.__sqOrientation110API;assert(api&&typeof api.transformBytes==='function','orientation transform API should load');
const t=api.solve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
assert.equal(t.scale,2);assert(Math.abs(t.angleDeg-90)<1e-9);
const dxf=`0\nSECTION\n2\nHEADER\n9\n$EXTMIN\n10\n0\n20\n0\n30\n0\n9\n$EXTMAX\n10\n30\n20\n30\n30\n0\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n0\nMULTILEADER\n5\nMLTEXT1\n8\nANNO_TEXT\n100\nAcDbEntity\n100\nAcDbMLeader\n270\n2\n300\nCONTEXT_DATA{\n40\n1\n10\n5\n20\n10\n30\n0\n41\n2\n140\n1\n145\n0.5\n290\n1\n304\nNote \\H2.5; and \\H0.8x;\n11\n0\n21\n0\n31\n1\n340\n1\n12\n7\n22\n10\n32\n0\n13\n1\n23\n0\n33\n0\n42\n0\n43\n10\n44\n2\n45\n1\n170\n1\n90\n7\n171\n1\n172\n1\n91\n0\n141\n1.5\n92\n0\n291\n0\n292\n0\n173\n0\n293\n0\n142\n5\n143\n1\n294\n0\n295\n1\n110\n0\n120\n0\n130\n0\n111\n1\n121\n0\n131\n0\n112\n0\n122\n1\n132\n0\n297\n0\n302\nLEADER{\n290\n1\n291\n1\n10\n5\n20\n10\n30\n0\n11\n1\n21\n0\n31\n0\n12\n6\n22\n10\n32\n0\n13\n7\n23\n10\n33\n0\n90\n0\n40\n2\n304\nLEADER_LINE{\n10\n1\n20\n2\n30\n0\n10\n3\n20\n4\n30\n0\n11\n2\n21\n2\n31\n0\n12\n3\n22\n3\n32\n0\n91\n0\n92\n256\n305\n}\n303\n}\n301\n}\n340\n0\n90\n0\n170\n1\n91\n256\n341\n0\n171\n-2\n290\n1\n291\n1\n41\n2\n342\n0\n42\n1\n172\n2\n343\n0\n173\n1\n95\n1\n174\n1\n175\n2\n92\n256\n292\n0\n344\n0\n93\n0\n10\n1\n20\n1\n30\n1\n43\n0\n176\n0\n293\n0\n294\n0\n178\n0\n179\n1\n45\n1\n0\nMULTILEADER\n5\nMLBLOCK1\n8\nANNO_BLOCK\n100\nAcDbEntity\n100\nAcDbMLeader\n270\n2\n300\nCONTEXT_DATA{\n40\n1\n10\n2\n20\n3\n30\n0\n296\n1\n341\n20\n14\n0\n24\n0\n34\n1\n15\n4\n25\n5\n35\n0\n16\n1\n26\n1\n36\n1\n46\n0\n93\n0\n47\n1\n47\n0\n47\n0\n47\n0\n47\n0\n47\n1\n47\n0\n47\n0\n47\n0\n47\n0\n47\n1\n47\n0\n47\n0\n47\n0\n47\n0\n47\n1\n297\n0\n301\n}\n340\n0\n90\n0\n170\n1\n91\n256\n341\n0\n171\n-2\n290\n1\n291\n1\n41\n2\n342\n0\n42\n1\n172\n1\n343\n0\n173\n1\n95\n1\n174\n1\n175\n2\n92\n256\n292\n0\n344\n20\n93\n0\n10\n1\n20\n1\n30\n1\n43\n0\n176\n0\n293\n0\n294\n0\n178\n0\n179\n1\n45\n1\n0\nENDSEC\n0\nEOF\n`;
const source=new TextEncoder().encode(dxf);const result=api.transformBytes(source,t);assert.equal(result.entitiesBefore,result.entitiesAfter,'both MLEADER records must remain');
const outText=new TextDecoder().decode(result.bytes);assert(outText.includes('Note \\H5; and \\H0.8x;'),'absolute inline text height should scale; relative x-height should remain relative');
const records=api.sectionRecords(api.splitPairs(result.bytes).pairs,'ENTITIES');
const text=records.find(r=>r.type==='MULTILEADER'&&r.pairs.some(p=>p.code===5&&p.value==='MLTEXT1'));
const block=records.find(r=>r.type==='MULTILEADER'&&r.pairs.some(p=>p.code===5&&p.value==='MLBLOCK1'));
assert(text&&block,'both text and block MLeader entities must survive');
const values=(r,c)=>r.pairs.filter(p=>p.code===c).map(p=>Number(p.value));
const first=(r,c,n=0)=>values(r,c)[n];
const afterContext=(r,c)=>{const end=r.pairs.find(p=>p.code===301&&String(p.value).trim()==='}');assert(end,'context closing marker must exist');return r.pairs.filter(p=>p.index>end.index&&p.code===c).map(p=>Number(p.value));};
// Context data appears first; the top-level block scale vector comes after the context closing marker.
assert(Math.abs(afterContext(text,10)[0]-1)<1e-9&&Math.abs(afterContext(text,20)[0]-1)<1e-9,'text-only MULTILEADER must not scale its unused block-scale vector');
assert(Math.abs(afterContext(block,10)[0]-2)<1e-9&&Math.abs(afterContext(block,20)[0]-2)<1e-9,'block-content MULTILEADER top-level scale vector must scale uniformly');
assert(Math.abs(first(text,10,0)-80)<1e-8&&Math.abs(first(text,20,0)-210)<1e-8,'context base point must align through the two-point similarity transform');
assert(Math.abs(first(text,12)-80)<1e-8&&Math.abs(first(text,22)-214)<1e-8,'MText location must move with the board');
assert(Math.abs(first(text,13))<1e-8&&Math.abs(first(text,23)-1)<1e-8,'MText direction must rotate without applying translation or scale to the unit direction');
assert(Math.abs(first(text,11,1))<1e-8&&Math.abs(first(text,21,1)-1)<1e-8,'leader dogleg vector must rotate and stay normalized');
assert(Math.abs(first(text,40,1)-4)<1e-8,'leader dogleg length must scale uniformly');
assert(Math.abs(first(text,41,0)-4)<1e-8,'MLeader context character height must scale');
assert(Math.abs(first(text,140,0)-2)<1e-8,'context arrowhead size must scale');
assert(Math.abs(first(text,145,0)-1)<1e-8,'landing gap must scale');
assert(Math.abs(first(text,43,0)-20)<1e-8,'MText width must scale');
assert(Math.abs(first(text,44,0)-4)<1e-8,'MText height must scale');
assert(Math.abs(first(text,42,0)-Math.PI/2)<1e-8,'MText rotation must use radians and follow board rotation');
assert(Math.abs(afterContext(text,43)[0])<1e-8,'text-only MULTILEADER redundant block-rotation metadata must stay unchanged');
assert(Math.abs(first(block,46,0)-Math.PI/2)<1e-8,'block content rotation must use radians and follow board rotation');
assert(Math.abs(afterContext(block,43)[0]-first(block,46,0))<1e-8,'top-level redundant block rotation must match transformed context block rotation');
assert(Math.abs(first(text,45,0)-1)<1e-8&&Math.abs(first(text,45,1)-2)<1e-8,'MText line spacing stays unchanged while global MLeader scale changes');
// Break start/end points in LEADER_LINE are points, not direction vectors.
assert(Math.abs(first(text,11,2)-96)<1e-8&&Math.abs(first(text,21,2)-204)<1e-8,'leader-line break start point must receive translation, rotation and scale');
assert(Math.abs(first(text,12,1)-80)<1e-8&&Math.abs(first(text,22,1)-212)<1e-8,'leader node break point must receive the same similarity transform');
assert(Math.abs(first(text,12,2)-94)<1e-8&&Math.abs(first(text,22,2)-206)<1e-8,'leader-line break end point must receive the same similarity transform');
assert(outText.includes('ANNO_TEXT')&&outText.includes('ANNO_BLOCK'),'layer names must be preserved');
// Block-content matrix: raw DXF matrix is transposed; composing with rotate+scale+translate updates it.
const matrix=values(block,47);assert.equal(matrix.length,16,'block content must keep all 16 transform matrix values');
const expected=[0,-2,0,100,2,0,0,200,0,0,2,0,0,0,0,1];
for(let i=0;i<16;i++)assert(Math.abs(matrix[i]-expected[i])<1e-8,`MLeader block matrix component ${i} must be composed with transform`);
const blockPoint=values(block,15);assert(Math.abs(blockPoint[0]-90)<1e-8&&Math.abs(values(block,25)[0]-208)<1e-8,'block content insertion point must move');
assert(Math.abs(values(block,16)[0]-2)<1e-8&&Math.abs(values(block,26)[0]-2)<1e-8,'block content scale vector must scale');
assert(outText.includes('ANNO_TEXT')&&outText.includes('ANNO_BLOCK'),'all MLeader layers must remain in output');

const dxf3d=`0
SECTION
2
HEADER
9
$ACADVER
1
AC1027
9
$EXTMIN
10
0
20
0
30
0
9
$EXTMAX
10
30
20
30
30
20
0
ENDSEC
0
SECTION
2
TABLES
0
TABLE
2
LAYER
70
2
0
LAYER
2
AXIS
70
0
62
7
6
CONTINUOUS
0
LAYER
2
LABELS
70
0
62
2
6
CONTINUOUS
0
ENDTAB
0
ENDSEC
0
SECTION
2
ENTITIES
0
LINE
8
AXIS
10
10
20
20
30
10
11
20
21
20
31
20
0
LINE
8
AXIS
10
1
20
1
30
0
11
2
21
2
31
0
0
CIRCLE
8
AXIS
10
3
20
4
30
2
40
5
210
0
220
1
230
0
0
TEXT
8
LABELS
10
2
20
3
30
1
40
2
1
AX1
50
15
210
0
220
1
230
0
0
LWPOLYLINE
8
AXIS
90
2
70
0
38
5
10
0
20
0
10
10
20
0
210
0
220
0
230
1
0
ENDSEC
0
EOF
`;
const b3=new TextEncoder().encode(dxf3d);
const t3=api.solve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
const r3=api.transformBytes(b3,t3);
assert.equal(r3.entitiesBefore,r3.entitiesAfter,'3D/OCS transform must preserve entity count');
const out3=new TextDecoder().decode(r3.bytes);
const rr3=api.sectionRecords(api.splitPairs(r3.bytes).pairs,'ENTITIES');
const rec=(type)=>rr3.find(r=>r.type===type);
const nval=(r,code,occ=0)=>{const p=r.pairs.filter(q=>q.code===code)[occ];return p?Number(p.value):null;};
const line3=rec('LINE'),circle3=rec('CIRCLE'),text3=rec('TEXT'),lw3=rec('LWPOLYLINE');
assert(line3&&circle3&&text3&&lw3,'3D and OCS entities should all remain');
const lines3=rr3.filter(r=>r.type==='LINE');assert.equal(lines3.length,2,'zero-Z WCS geometry must remain present');assert(Math.abs(nval(lines3[1],30))<1e-12&&Math.abs(nval(lines3[1],31))<1e-12,'zero-elevation plane must remain anchored at the Z pivot');
assert(Math.abs(nval(line3,10)-60)<1e-8&&Math.abs(nval(line3,20)-220)<1e-8,'WCS LINE first point XY transformed');
assert(Math.abs(nval(line3,11)-60)<1e-8&&Math.abs(nval(line3,21)-240)<1e-8,'WCS LINE second point XY transformed');
assert(Math.abs(nval(line3,30)-20)<1e-8,'WCS LINE first Z must be scaled uniformly about the lowest Z pivot');
assert(Math.abs(nval(line3,31)-40)<1e-8,'WCS LINE second Z must be scaled uniformly about the lowest Z pivot');
assert(Math.abs(nval(circle3,210)-(-1))<1e-8&&Math.abs(nval(circle3,220))<1e-8&&Math.abs(nval(circle3,230))<1e-8,'tilted OCS normal must rotate with the horizontal alignment');
function cross3(a,b){return{x:a.y*b.z-a.z*b.y,y:a.z*b.x-a.x*b.z,z:a.x*b.y-a.y*b.x};}
function dot3(a,b){return a.x*b.x+a.y*b.y+a.z*b.z;}
function norm3(v){const d=Math.hypot(v.x,v.y,v.z);return{x:v.x/d,y:v.y/d,z:v.z/d};}
function basis3(n0){const n=norm3(n0);let ax;if(Math.abs(n.x)<1/64&&Math.abs(n.y)<1/64)ax=norm3(cross3({x:0,y:1,z:0},n));else ax=norm3(cross3({x:0,y:0,z:1},n));return{x:ax,y:norm3(cross3(n,ax)),z:n};}
function pointOcsWcs(r){const b=basis3({x:nval(r,210)??0,y:nval(r,220)??0,z:nval(r,230)??1});const x=nval(r,10)??0,y=nval(r,20)??0,z=nval(r,30)??0;return{x:b.x.x*x+b.y.x*y+b.z.x*z,y:b.x.y*x+b.y.y*y+b.z.y*z,z:b.x.z*x+b.y.z*y+b.z.z*z};}
const inputRecords=api.sectionRecords(api.splitPairs(b3).pairs,'ENTITIES');
const sourceCircle=inputRecords.find(r=>r.type==='CIRCLE'),sourceText=inputRecords.find(r=>r.type==='TEXT');
const sourceCircleWcs=pointOcsWcs(sourceCircle),sourceTextWcs=pointOcsWcs(sourceText),zPivot=0,expectedCircleWcs={...t3.point(sourceCircleWcs.x,sourceCircleWcs.y),z:zPivot+t3.scale*(sourceCircleWcs.z-zPivot)},expectedTextWcs={...t3.point(sourceTextWcs.x,sourceTextWcs.y),z:zPivot+t3.scale*(sourceTextWcs.z-zPivot)};
const outCircleWcs=pointOcsWcs(circle3),outTextWcs=pointOcsWcs(text3);
for(const [actual,expected,label] of [[outCircleWcs,expectedCircleWcs,'CIRCLE OCS->WCS round trip'],[outTextWcs,expectedTextWcs,'TEXT OCS->WCS round trip']]){

 assert(Math.abs(actual.x-expected.x)<1e-7&&Math.abs(actual.y-expected.y)<1e-7&&Math.abs(actual.z-expected.z)<1e-7,label+' must match the full XYZ similarity transform in WCS');
}
assert(Math.abs(nval(circle3,40)-10)<1e-8,'OCS circle radius must scale');
assert(Math.abs(nval(text3,40)-4)<1e-8,'OCS text height must scale');
assert(out3.includes('AX1')&&out3.includes('AXIS')&&out3.includes('LABELS'),'axis-label text and layers must be retained');
assert(Math.abs(nval(lw3,38)-10)<1e-8,'LWPOLYLINE elevation should scale uniformly above the lowest Z pivot');
// Exercise the actual axis-label extractor and parsePreview fallback using a nested INSERT block.
const htmlMainStart=html.indexOf('function sqRawDxfValue');
const htmlMainEnd=html.indexOf('function sqByteString',htmlMainStart);
assert(htmlMainStart>=0&&htmlMainEnd>htmlMainStart,'raw axis preview extractor should be present');
vm.runInContext(html.slice(htmlMainStart,htmlMainEnd),context,{timeout:5000});
context.sqByteString=bytes=>{let out='';for(const b of bytes)out+=String.fromCharCode(b);return out;};
window.sqExtractDxfAxisEntities=context.sqExtractDxfAxisEntities;
window.__sqManualOrientation109={parseDrawing:()=>({segs:[],anchors:[],texts:[],bounds:{minX:0,minY:0,maxX:1,maxY:1},entityCount:0,layers:{}})};
const axisDxf=`0
SECTION
2
HEADER
9
$DWGCODEPAGE
3
ANSI_1252
0
ENDSEC
0
SECTION
2
BLOCKS
0
BLOCK
8
0
2
AXIS_BUBBLE
70
0
10
0
20
0
30
0
0
TEXT
8
0
10
10
20
20
30
0
40
2.5
1
A1
0
ENDBLK
8
0
0
ENDSEC
0
SECTION
2
ENTITIES
0
INSERT
8
AXES
2
AXIS_BUBBLE
10
300
20
400
30
0
41
1
42
1
43
1
50
0
0
TEXT
8
AXES
10
100
20
200
30
0
40
2.5
1
B2
0
ENDSEC
0
EOF
`;
const axisPreview=api.parsePreview(new TextEncoder().encode(axisDxf));
const labels=axisPreview.texts.filter(t=>['A1','B2'].includes(String(t.text||'').trim().toUpperCase()));
assert(labels.some(t=>String(t.text).trim()==='A1'&&Math.abs(t.p.x-310)<1e-8&&Math.abs(t.p.y-420)<1e-8),'axis bubble name A1 in INSERT block must appear in preview at transformed block position');
assert(labels.some(t=>String(t.text).trim()==='B2'&&Math.abs(t.p.x-100)<1e-8&&Math.abs(t.p.y-200)<1e-8),'top-level axis name B2 must appear in preview');
console.log('PASS V145: 3D LINE Z scaling about the lowest world-Z pivot; zero-Z plane remains anchored.');
console.log('PASS V145: tilted OCS CIRCLE/TEXT round-trip to expected full-XYZ WCS similarity.');
console.log('PASS V145: axis bubble labels in nested INSERT and top-level TEXT restored in the preview.');
console.log('PASS V145: MLEADER preservation and coordinate transform checks.');


