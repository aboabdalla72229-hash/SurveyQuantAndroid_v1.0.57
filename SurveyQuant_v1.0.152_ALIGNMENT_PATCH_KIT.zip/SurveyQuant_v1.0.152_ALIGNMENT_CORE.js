/* SurveyQuant v1.0.152: standalone Alignment math and loss-minimizing DXF transformer.
 * This module deliberately has no dependency on the old orientation project. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.SurveyQuantAlignment152 = api;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : null), function () {
  'use strict';
  const EPS = 1e-10;
  const KNOWN = new Set(['LINE','POINT','CIRCLE','ARC','LWPOLYLINE','POLYLINE','VERTEX','SEQEND','TEXT','MTEXT','ATTRIB','ATTDEF','INSERT','SOLID','TRACE','3DFACE','SPLINE','ELLIPSE','RAY','XLINE','LEADER','HATCH','DIMENSION','IMAGE','MLEADER','MLINE','WIPEOUT','3DSOLID','BODY','REGION','MESH','SURFACE','HELIX','ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','TABLE','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY','VIEWPORT','SHAPE','TOLERANCE']);
  const OCS_TYPES = new Set(['CIRCLE','ARC','LWPOLYLINE','POLYLINE','VERTEX','TEXT','MTEXT','ATTRIB','ATTDEF','INSERT','SOLID','TRACE','LEADER','HATCH','DIMENSION']);
  const OPAQUE = new Set(['3DSOLID','BODY','REGION','MESH','SURFACE','ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY','WIPEOUT','TABLE','MLINE','HELIX']);
  const isFinite3 = p => p && [p.x,p.y,p.z].every(Number.isFinite);
  const v3 = (x=0,y=0,z=0)=>({x:Number(x)||0,y:Number(y)||0,z:Number(z)||0});
  const dot=(a,b)=>a.x*b.x+a.y*b.y+a.z*b.z;
  const cross=(a,b)=>({x:a.y*b.z-a.z*b.y,y:a.z*b.x-a.x*b.z,z:a.x*b.y-a.y*b.x});
  const norm=a=>Math.hypot(a.x,a.y,a.z);
  const unit=a=>{const n=norm(a);if(!Number.isFinite(n)||n<EPS)throw new Error('متجه محور OCS غير صالح؛ أوقف التحويل لحماية هندسة اللوحة.');return{x:a.x/n,y:a.y/n,z:a.z/n};};
  function solveAlignment(source1, source2, reference1, reference2) {
    for (const [label,p] of [['S1',source1],['S2',source2],['R1',reference1],['R2',reference2]]) {
      if (!p || !Number.isFinite(Number(p.x)) || !Number.isFinite(Number(p.y))) throw new Error('إحداثيات نقاط Alignment الأربعة غير مكتملة أو غير رقمية ('+label+').');
    }
    const s1={x:Number(source1.x),y:Number(source1.y)},s2={x:Number(source2.x),y:Number(source2.y)},r1={x:Number(reference1.x),y:Number(reference1.y)},r2={x:Number(reference2.x),y:Number(reference2.y)};
    const ds=Math.hypot(s2.x-s1.x,s2.y-s1.y),dr=Math.hypot(r2.x-r1.x,r2.y-r1.y);
    if (ds<EPS || dr<EPS) throw new Error('لا يمكن استخدام نقطتين متطابقتين في أي من اللوحتين.');
    const angle=Math.atan2(r2.y-r1.y,r2.x-r1.x)-Math.atan2(s2.y-s1.y,s2.x-s1.x);
    const scale=dr/ds;
    if (!Number.isFinite(scale)||scale<=EPS||scale>1e9) throw new Error('المقياس المحسوب غير صالح. راجع وحدات اللوحتين ونقاط المطابقة.');
    const c=Math.cos(angle),s=Math.sin(angle),tx=r1.x-scale*(c*s1.x-s*s1.y),ty=r1.y-scale*(s*s1.x+c*s1.y);
    const point=(x,y,z=0)=>({x:scale*(c*x-s*y)+tx,y:scale*(s*x+c*y)+ty,z:scale*z});
    const vector=(x,y,z=0)=>({x:scale*(c*x-s*y),y:scale*(s*x+c*y),z:scale*z});
    const p2=point(s2.x,s2.y),residual=Math.hypot(p2.x-r2.x,p2.y-r2.y);
    return {scale,angle,angleDeg:angle*180/Math.PI,tx,ty,c,s,point,vector,source1:s1,source2:s2,reference1:r1,reference2:r2,residual};
  }
  function bytesToLatin1(bytes) { let out=''; const step=16384; for(let i=0;i<bytes.length;i+=step){let s='';for(let j=i;j<Math.min(i+step,bytes.length);j++)s+=String.fromCharCode(bytes[j]);out+=s;}return out; }
  function latin1ToBytes(text) { const out=new Uint8Array(text.length);for(let i=0;i<text.length;i++){const n=text.charCodeAt(i);if(n>255)throw new Error('ظهرت محارف غير أحادية البايت في DXF الخام؛ تم إيقاف التصدير لمنع إفساد النصوص.');out[i]=n;}return out; }
  function splitRawLines(text) {
    const lines=[];let start=0;
    for(let i=0;i<text.length;i++)if(text[i]==='\r'||text[i]==='\n'){
      const eol=text[i]==='\r'&&text[i+1]==='\n'?'\r\n':text[i];lines.push({value:text.slice(start,i),eol});if(eol==='\r\n')i++;start=i+1;
    }
    if(start<text.length)lines.push({value:text.slice(start),eol:''});
    return lines;
  }
  function pairIndex(record, code, occurrence=0) { for(let i=0;i<record.length;i++)if(record[i].code===code){if(occurrence===0)return i;occurrence--;}return -1; }
  function allPairIndexes(record, code) { const out=[];for(let i=0;i<record.length;i++)if(record[i].code===code)out.push(i);return out; }
  function getNumber(record,code,def=null,occurrence=0){const i=pairIndex(record,code,occurrence);if(i<0)return def;const v=Number(record[i].value);return Number.isFinite(v)?v:def;}
  function setNumber(record,code,value,occurrence=0,create=false){let i=pairIndex(record,code,occurrence);if(i<0){if(!create)return false;record.push({code,value:String(value),originalIndex:-1,inserted:true});return true;}record[i].value=fmt(value);return true;}
  function fmt(n){if(!Number.isFinite(n))throw new Error('نتج إحداثي غير صالح؛ لم يتم إخراج الملف.');if(Math.abs(n)<5e-10)n=0;return Number(n.toPrecision(13)).toString();}
  function getNormal(record){return unit(v3(getNumber(record,210,0),getNumber(record,220,0),getNumber(record,230,1)));}
  function ocsAxes(n){let ax;if(Math.abs(n.x)<1/64&&Math.abs(n.y)<1/64)ax=unit(cross(v3(0,1,0),n));else ax=unit(cross(v3(0,0,1),n));const ay=unit(cross(n,ax));return{ax,ay,n};}
  function localToWorld(p,axes){return{x:axes.ax.x*p.x+axes.ay.x*p.y+axes.n.x*p.z,y:axes.ax.y*p.x+axes.ay.y*p.y+axes.n.y*p.z,z:axes.ax.z*p.x+axes.ay.z*p.y+axes.n.z*p.z};}
  function worldToLocal(p,axes){return{x:dot(p,axes.ax),y:dot(p,axes.ay),z:dot(p,axes.n)};}
  function pointTransform(p,t){return{x:t.scale*(t.c*p.x-t.s*p.y)+t.tx,y:t.scale*(t.s*p.x+t.c*p.y)+t.ty,z:t.scale*p.z};}
  function vectorTransform(p,t){return{x:t.scale*(t.c*p.x-t.s*p.y),y:t.scale*(t.s*p.x+t.c*p.y),z:t.scale*p.z};}
  function transformNormal(record,t){const n=getNormal(record),nn=unit(v3(t.c*n.x-t.s*n.y,t.s*n.x+t.c*n.y,n.z));if(pairIndex(record,210)>=0){setNumber(record,210,nn.x);setNumber(record,220,nn.y);setNumber(record,230,nn.z);}return{old:ocsAxes(n),next:ocsAxes(nn),n,nn};}
  function transformGroup(record,xcode,mode,t,ocs,elevationCode=null,ensureZ=false){
    const xs=allPairIndexes(record,xcode),ys=allPairIndexes(record,xcode+10),zs=allPairIndexes(record,xcode+20);let changed=0;
    for(let k=0;k<xs.length;k++){
      const xi=xs[k],yi=ys[k];if(yi===undefined)continue;const zi=zs[k]??-1;
      const p=v3(Number(record[xi].value),Number(record[yi].value),zi>=0?Number(record[zi].value):(elevationCode!==null?getNumber(record,elevationCode,0):0));if(!isFinite3(p))throw new Error('إحداثي غير صالح في كيان '+record.type+'.');
      let q;
      if(ocs){const world=localToWorld(p,ocs.old),mapped=mode==='vector'?vectorTransform(world,t):pointTransform(world,t);q=worldToLocal(mapped,ocs.next);}else q=mode==='vector'?vectorTransform(p,t):pointTransform(p,t);
      record[xi].value=fmt(q.x);record[yi].value=fmt(q.y);if(zi>=0)record[zi].value=fmt(q.z);else if(ensureZ&&elevationCode===null&&Math.abs(q.z)>1e-8)record.push({code:xcode+20,value:fmt(q.z),originalIndex:-1,inserted:true});changed++;
      if(elevationCode!==null&&k===0&&pairIndex(record,elevationCode)>=0)setNumber(record,elevationCode,q.z);
    }
    return changed;
  }
  function transformArbitraryPair(record,xcode,ycode,mode,t,ocs){const xs=allPairIndexes(record,xcode),ys=allPairIndexes(record,ycode);for(let k=0;k<Math.min(xs.length,ys.length);k++){const xi=xs[k],yi=ys[k],p={x:Number(record[xi].value),y:Number(record[yi].value),z:0};if(!isFinite3(p))continue;let q;if(ocs){const w=localToWorld(p,ocs.old),m=mode==='vector'?vectorTransform(w,t):pointTransform(w,t);q=worldToLocal(m,ocs.next);}else q=mode==='vector'?vectorTransform(p,t):pointTransform(p,t);record[xi].value=fmt(q.x);record[yi].value=fmt(q.y);}}
  function transformRecord(record,t,counts){
    const type=String(record.type||'').toUpperCase();if(!type||['SECTION','ENDSEC','EOF','TABLE','ENDTAB','BLOCK','ENDBLK','SEQEND'].includes(type))return;
    const coordCodes=record.some(p=>p.code>=10&&p.code<=38);
    if(OPAQUE.has(type)){if(coordCodes||record.some(p=>p.code===310||p.code===1004))throw new Error('الكيان '+type+' يحتوي هندسة CAD داخلية غير مكشوفة في DXF النصي. تم إيقاف Alignment بدل إخراج لوحة ناقصة أو مشوّهة. يلزم تحويل هذا الكيان إلى هندسة قياسية داخل برنامج CAD أولاً.');return;}
    if(!KNOWN.has(type)){if(coordCodes)throw new Error('نوع الكيان '+type+' غير معروف لمحرك Alignment الجديد. تم إيقاف التصدير لحماية خصائصه وهندسته.');return;}
    const ocs=OCS_TYPES.has(type)?transformNormal(record,t):null;let changed=0;
    const g=(code,mode='point',isOcs=!!ocs,ele=null,ensure=false)=>{changed+=transformGroup(record,code,mode,t,isOcs?ocs:null,ele,ensure);};
    switch(type){
      case 'LINE': g(10,'point',false);g(11,'point',false);break;
      case 'POINT': g(10,'point',false);break;
      case 'CIRCLE': case 'ARC': g(10,'point',true);if(pairIndex(record,40)>=0)setNumber(record,40,getNumber(record,40)*t.scale);if(type==='ARC'){for(const code of [50,51])if(pairIndex(record,code)>=0)setNumber(record,code,wrapAngle(transformAngle(getNumber(record,code),ocs,t)));}break;
      case 'LWPOLYLINE': g(10,'point',true,38,true);break;
      case 'POLYLINE': g(10,'point',true);break;
      case 'VERTEX': g(10,'point',true);break;
      case 'TEXT': case 'ATTRIB': case 'ATTDEF': g(10,'point',true);g(11,'point',true);scaleScalar(record,40,t.scale);if(pairIndex(record,50)>=0)setNumber(record,50,wrapAngle(transformAngle(getNumber(record,50),ocs,t)));break;
      case 'MTEXT': g(10,'point',true);g(11,'vector',true);scaleScalar(record,40,t.scale);scaleScalar(record,41,t.scale);if(pairIndex(record,50)>=0)setNumber(record,50,wrapAngle(transformAngle(getNumber(record,50),ocs,t)));break;
      case 'INSERT': g(10,'point',true);for(const code of [41,42,43])if(pairIndex(record,code)>=0)setNumber(record,code,getNumber(record,code,1)*t.scale);if(pairIndex(record,50)>=0)setNumber(record,50,wrapAngle(transformAngle(getNumber(record,50),ocs,t)));break;
      case 'SOLID': case 'TRACE': g(10,'point',true);g(11,'point',true);g(12,'point',true);g(13,'point',true);break;
      case '3DFACE': g(10,'point',false);g(11,'point',false);g(12,'point',false);g(13,'point',false);break;
      case 'SPLINE': for(const code of [10,11])g(code,'point',false);for(const code of [12,13])g(code,'vector',false);break;
      case 'ELLIPSE': g(10,'point',false);g(11,'vector',false);break;
      case 'RAY': case 'XLINE': g(10,'point',false);g(11,'vector',false);break;
      case 'LEADER': g(10,'point',true);if(pairIndex(record,50)>=0)setNumber(record,50,wrapAngle(transformAngle(getNumber(record,50),ocs,t)));break;
      case 'HATCH': g(10,'point',true);transformArbitraryPair(record,43,44,'point',t,ocs);transformArbitraryPair(record,45,46,'vector',t,ocs);scaleScalar(record,41,t.scale);for(const code of [52,53])for(let k=0;k<allPairIndexes(record,code).length;k++)setNumber(record,code,wrapAngle(transformAngle(getNumber(record,code,0,k),ocs,t)),k);break;
      case 'DIMENSION': for(const code of [10,11,12,13,14,15,16,17,18])g(code,'point',true);for(const code of [40,41,42,43,44,45,46])if(pairIndex(record,code)>=0&&[40,41,42,45,46].includes(code))scaleScalar(record,code,t.scale);if(pairIndex(record,50)>=0)setNumber(record,50,wrapAngle(transformAngle(getNumber(record,50),ocs,t)));break;
      case 'IMAGE': g(10,'point',false);g(11,'vector',false);g(12,'vector',false);break;
      case 'MLEADER': for(const code of [10,13,14,15,16,17,18])g(code,'point',true);for(const code of [11,12])g(code,'vector',true);break;
      case 'MLINE': for(const code of [10,11,12])g(code,'point',true);break;
      case 'WIPEOUT': g(10,'point',true);break;
      case '3DSOLID': case 'BODY': case 'REGION': case 'MESH': case 'SURFACE': case 'HELIX': case 'ACAD_PROXY_ENTITY': case 'ACAD_PROXY_OBJECT': case 'TABLE': case 'OLE2FRAME': case 'PDFUNDERLAY': case 'DWFUNDERLAY': case 'DGNUNDERLAY': case 'VIEWPORT': case 'SHAPE': case 'TOLERANCE': break;
    }
    if(changed>0)counts.changedFields+=changed;counts.entities++;counts.types[type]=(counts.types[type]||0)+1;
  }
  function transformAngle(angleDeg,ocs,t){
    const rad=Number(angleDeg)*Math.PI/180,old=ocs?ocs.old:ocsAxes(v3(0,0,1)),next=ocs?ocs.next:ocsAxes(v3(0,0,1));
    const v=localToWorld({x:Math.cos(rad),y:Math.sin(rad),z:0},old),mapped={x:t.c*v.x-t.s*v.y,y:t.s*v.x+t.c*v.y,z:v.z},q=worldToLocal(mapped,next);return Math.atan2(q.y,q.x)*180/Math.PI;
  }
  function wrapAngle(n){n=((n%360)+360)%360;return Math.abs(n)<1e-9?0:n;}
  function scaleScalar(record,code,multiplier){for(let k=0;k<allPairIndexes(record,code).length;k++){const v=getNumber(record,code,null,k);if(v!==null)setNumber(record,code,v*multiplier,k);}}
  function transformDxfBytes(input,transform){
    const bytes=input instanceof Uint8Array?input:new Uint8Array(input);if(bytes.length<30)throw new Error('ملف DXF أقصر من الحجم المتوقع.');
    const t=transform;if(!t||![t.scale,t.c,t.s,t.tx,t.ty].every(Number.isFinite))throw new Error('معاملات Alignment غير مكتملة.');
    const text=bytesToLatin1(bytes),lines=splitRawLines(text);if(lines.length<8||lines.length%2!==0)throw new Error('بنية DXF غير مكتملة: عدد أسطر المجموعة غير زوجي.');
    const pairs=[];for(let i=0;i<lines.length;i+=2){const code=Number(lines[i].value.trim().replace(/^\u00ef\u00bb\u00bf/,''));if(!Number.isInteger(code)||code<0||code>1071)throw new Error('رمز مجموعة DXF غير صالح عند السطر '+(i+1)+'.');pairs.push({code,value:lines[i+1].value,originalIndex:i});}
    const counts={entities:0,changedFields:0,types:Object.create(null)},unsupported=[];let section='',foundEntities=false;
    for(let i=0;i<pairs.length;){const p=pairs[i];if(p.code===0&&p.value.trim().toUpperCase()==='SECTION'){section=String(pairs[i+1]?.value||'').trim().toUpperCase();if(section==='ENTITIES')foundEntities=true;i+=1;continue;}
      if(p.code===0&&p.value.trim().toUpperCase()==='ENDSEC'){section='';i++;continue;}
      if(section!=='ENTITIES'||p.code!==0){i++;continue;}
      const type=p.value.trim().toUpperCase();if(['ENDSEC','EOF'].includes(type)){i++;continue;}const start=i;i++;while(i<pairs.length&&pairs[i].code!==0)i++;const rec=pairs.slice(start,i);rec.type=type;
      try{transformRecord(rec,t,counts);}catch(e){unsupported.push(type);throw e;}
      for(const rp of rec){if(rp.originalIndex>=0)lines[rp.originalIndex+1].value=rp.value;else {const val=String(rp.value);lines.push({value:String(rp.code),eol:'\r\n'},{value:val,eol:'\r\n'});}}
    }
    if(!foundEntities)throw new Error('لم يعثر محرك Alignment على قسم ENTITIES داخل ملف DXF.');
    let out='';for(const line of lines)out+=line.value+line.eol;const outBytes=latin1ToBytes(out);
    const outText=bytesToLatin1(outBytes);if(!/0\s*\r?\nEOF\s*$/i.test(outText.replace(/\r/g,'')))throw new Error('فشل التحقق النهائي من نهاية ملف DXF.');
    return {bytes:outBytes,entitiesTransformed:counts.entities,changedFields:counts.changedFields,types:counts.types};
  }
  return {solveAlignment,transformDxfBytes,bytesToLatin1,latin1ToBytes};
});
