#!/usr/bin/env python3
"""Transplant the V130 orientation engine and harden preview geometry/delete UX for V142."""
from __future__ import annotations
import argparse, hashlib, re, struct, copy, zipfile
from pathlib import Path

MODULE_IDS = (
    "sq-orientation-module",
    "sq-orientation-axis-reader-module",
    "sq-orientation-manual-points-module",
    "sq-orientation-reference-board-module",
    "sq-orientation-dxf-faithful-recovery-module",
    "sq-orientation-cad-preserve-module",
    "sq-orientation-v115-tools-module",
)
OLD_CODE, NEW_CODE = 140, 142
OLD_NAME, NEW_NAME = "1.0.140", "1.0.142"

def script_pattern(script_id: str) -> re.Pattern[str]:
    return re.compile(r'(<script\b(?=[^>]*\bid=["\']'+re.escape(script_id)+r'["\'])[^>]*>)([\s\S]*?)(</script\s*>)', re.I)

def get_script(html: str, script_id: str) -> str:
    hits=list(script_pattern(script_id).finditer(html))
    if len(hits)!=1: raise ValueError(f"Expected one script id={script_id!r}, found {len(hits)}")
    return hits[0].group(2)

def replace_script(html: str, script_id: str, body: str) -> str:
    hits=list(script_pattern(script_id).finditer(html))
    if len(hits)!=1: raise ValueError(f"Expected one script id={script_id!r}, found {len(hits)}")
    m=hits[0]
    return html[:m.start(2)]+body+html[m.end(2):]

def replace_once(text: str, old: str, new: str, label: str) -> str:
    count=text.count(old)
    if count != 1: raise ValueError(f"{label}: expected one exact match, got {count}")
    return text.replace(old,new,1)

RECORD_GEOMETRY = r'''function recordGeometry(rec){
 const t=String(rec.type||'').toUpperCase(),p=rec.pairs||[],pts=[],segments=[];
 const add=q=>{if(q&&Number.isFinite(q.x)&&Number.isFinite(q.y))pts.push({x:q.x,y:q.y});};
 const seg=(a,b)=>{if(a&&b&&Number.isFinite(a.x)&&Number.isFinite(a.y)&&Number.isFinite(b.x)&&Number.isFinite(b.y))segments.push({a:{x:a.x,y:a.y},b:{x:b.x,y:b.y}});};
 const xy=(xc,yc,occ=0)=>pointAt(rec,xc,occ);
 const pairsFor=(xc,yc)=>{const xs=p.filter(x=>x.code===xc),ys=p.filter(x=>x.code===yc),out=[];for(let i=0;i<Math.min(xs.length,ys.length);i++){const x=num(xs[i].value),y=num(ys[i].value);if(x!==null&&y!==null)out.push({x,y});}return out;};
 const chain=(vertices,closed=false)=>{for(const q of vertices)add(q);for(let i=1;i<vertices.length;i++)seg(vertices[i-1],vertices[i]);if(closed&&vertices.length>2)seg(vertices[vertices.length-1],vertices[0]);};
 if(t==='LINE'){const a=xy(10,20),b=xy(11,21);add(a);add(b);seg(a,b);return {pts,segments};}
 if(t==='POINT'){add(xy(10,20));return {pts,segments};}
 if(t==='CIRCLE'||t==='ARC'){
  const c=xy(10,20),r=pairVal(rec,40);if(c&&Number.isFinite(r)&&r>0){let start=t==='ARC'?(pairVal(rec,50)||0)*Math.PI/180:0,end=t==='ARC'?(pairVal(rec,51)||0)*Math.PI/180:2*Math.PI;while(end<=start)end+=2*Math.PI;const n=Math.max(24,Math.min(512,Math.ceil((end-start)*32)));let last=null;for(let i=0;i<=n;i++){const a=start+(end-start)*i/n,q={x:c.x+r*Math.cos(a),y:c.y+r*Math.sin(a)};add(q);if(last)seg(last,q);last=q;}}return {pts,segments};
 }
 if(t==='ELLIPSE'){
  const c=xy(10,20),major=xy(11,21),ratio=pairVal(rec,40);if(c&&major&&ratio>0){const rx=Math.hypot(major.x,major.y),base=Math.atan2(major.y,major.x),start=pairVal(rec,41)||0,end=pairVal(rec,42)??(2*Math.PI);let delta=end-start;while(delta<=0)delta+=2*Math.PI;const n=Math.max(24,Math.min(512,Math.ceil(delta*32)));let last=null;for(let i=0;i<=n;i++){const a=start+delta*i/n,q={x:c.x+rx*Math.cos(a)*Math.cos(base)-rx*ratio*Math.sin(a)*Math.sin(base),y:c.y+rx*Math.cos(a)*Math.sin(base)+rx*ratio*Math.sin(a)*Math.cos(base)};add(q);if(last)seg(last,q);last=q;}}return {pts,segments};
 }
 if(t==='LWPOLYLINE'){
  const raw=pairsFor(10,20),closed=((pairVal(rec,70)||0)&1)!==0,bulges=p.filter(x=>x.code===42);chain(raw,false);
  if(raw.length>1){segments.length=0;for(let i=0;i<(closed?raw.length:raw.length-1);i++){const a=raw[i],b=raw[(i+1)%raw.length],bulge=num(bulges[i]?.value)||0;if(Math.abs(bulge)<1e-12){seg(a,b);continue;}const dx=b.x-a.x,dy=b.y-a.y,chord=Math.hypot(dx,dy);if(chord<1e-12){continue;}const theta=4*Math.atan(bulge),offset=chord*(1-bulge*bulge)/(4*bulge),cx=(a.x+b.x)/2-dy/chord*offset,cy=(a.y+b.y)/2+dx/chord*offset,r=Math.hypot(a.x-cx,a.y-cy),start=Math.atan2(a.y-cy,a.x-cx),steps=Math.max(4,Math.min(96,Math.ceil(Math.abs(theta)*16)));let prev=a;for(let k=1;k<=steps;k++){const an=start+theta*k/steps,q=k===steps?b:{x:cx+r*Math.cos(an),y:cy+r*Math.sin(an)};seg(prev,q);prev=q;}}}
  return {pts,segments};
 }
 if(t==='POLYLINE'){
  // A classic POLYLINE's header group 10/20 is a dummy origin, not a vertex.
  const vertices=[];let inVertex=false,vx=null,vy=null,bulge=0;const flags=pairVal(rec,70)||0,closed=(flags&1)!==0;
  const flush=()=>{if(vx!==null&&vy!==null)vertices.push({x:vx,y:vy,bulge});vx=vy=null;bulge=0;};
  for(const q of p){if(q.code===0){const kind=String(q.value||'').toUpperCase();if(kind==='VERTEX'){if(inVertex)flush();inVertex=true;}else if(kind==='SEQEND'){if(inVertex)flush();inVertex=false;}else if(kind==='POLYLINE'){inVertex=false;}}else if(inVertex){if(q.code===10)vx=num(q.value);else if(q.code===20)vy=num(q.value);else if(q.code===42)bulge=num(q.value)||0;}}
  if(inVertex)flush();chain(vertices,false);if(vertices.length>1){segments.length=0;for(let i=0;i<(closed?vertices.length:vertices.length-1);i++){const a=vertices[i],b=vertices[(i+1)%vertices.length],bb=a.bulge||0;if(Math.abs(bb)<1e-12){seg(a,b);continue;}const dx=b.x-a.x,dy=b.y-a.y,chord=Math.hypot(dx,dy);if(chord<1e-12)continue;const theta=4*Math.atan(bb),off=chord*(1-bb*bb)/(4*bb),cx=(a.x+b.x)/2-dy/chord*off,cy=(a.y+b.y)/2+dx/chord*off,r=Math.hypot(a.x-cx,a.y-cy),start=Math.atan2(a.y-cy,a.x-cx),steps=Math.max(4,Math.min(96,Math.ceil(Math.abs(theta)*16)));let prev=a;for(let k=1;k<=steps;k++){const an=start+theta*k/steps,q=k===steps?b:{x:cx+r*Math.cos(an),y:cy+r*Math.sin(an)};seg(prev,q);prev=q;}}}
  return {pts,segments};
 }
 if(t==='SOLID'||t==='TRACE'||t==='3DFACE'){
  const corners=[];for(let code=10;code<=13;code++){const q=xy(code,code+10);if(q)corners.push(q);}chain(corners,true);return {pts,segments};
 }
 if(t==='LEADER'){
  const vertices=pairsFor(10,20);chain(vertices,false);return {pts,segments};
 }
 if(t==='SPLINE'){
  // Use only control vertices in the preview. Groups 12/13 are tangents, never line endpoints.
  const vertices=pairsFor(10,20);chain(vertices,false);return {pts,segments};
 }
 if(t==='HATCH'){
  // Draw only explicitly recognized polyline boundary paths. Never connect unrelated HATCH XY fields.
  let pathStart=-1;
  for(let i=0;i<p.length;i++)if(p[i].code===92){
   const flags=num(p[i].value)||0,end=(()=>{for(let j=i+1;j<p.length;j++)if(p[j].code===92)return j;return p.length;})();
   if(flags&2){let n=-1,closed=false;for(let j=i+1;j<end;j++){if(p[j].code===73)closed=Number(p[j].value)===1;if(p[j].code===93){n=Math.max(0,Math.min(100000,Number(p[j].value)||0));break;}}
    if(n>=0){const verts=[];for(let j=i+1;j<end&&verts.length<n;j++){if(p[j].code!==10)continue;let y=null;for(let k=j+1;k<end;k++){if(p[k].code===20){y=num(p[k].value);break;}if(p[k].code===10||p[k].code===92)break;}const x=num(p[j].value);if(x!==null&&y!==null)verts.push({x,y});}chain(verts,closed);}
   }
   i=end-1;
  }
  if(!pts.length){for(const q of pairsFor(10,20))add(q);}return {pts,segments};
 }
 // INSERT, TEXT, MTEXT, DIMENSION, MLEADER, MLINE, IMAGE and unknown/special entities
 // are anchor/text/block-driven. Joining their every XY coordinate caused artificial line webs.
 for(let code=10;code<=18;code++)for(const q of pairsFor(code,code+10))add(q);
 return {pts,segments};
}'''


def patch_manual_module(body: str) -> str:
    # Use true vertex records and per-vertex bulges for polylines. A spline's 12/13
    # vectors are endpoint tangents, not vertices: joining them was the source of long stray lines.
    helper = r"""function drawVertexPath(vertices,closed=false){
 const pts=vertices.filter(v=>v&&v.p&&Number.isFinite(v.p.x)&&Number.isFinite(v.p.y));
 if(pts.length<2){if(pts.length)addPoint(pts[0].p);return;}
 for(const v of pts)addPoint(v.p);
 const edgeCount=closed?pts.length:pts.length-1;
 for(let i=0;i<edgeCount;i++){
  const a=pts[i],b=pts[(i+1)%pts.length],bulge=Number(a.bulge)||0;
  if(Math.abs(bulge)<1e-10){addSeg(a.p,b.p);continue;}
  const dx=b.p.x-a.p.x,dy=b.p.y-a.p.y,chord=Math.hypot(dx,dy);if(chord<1e-10)continue;
  const theta=4*Math.atan(bulge),offset=chord*(1-bulge*bulge)/(4*bulge),cx=(a.p.x+b.p.x)/2-dy/chord*offset,cy=(a.p.y+b.p.y)/2+dx/chord*offset,r=Math.hypot(a.p.x-cx,a.p.y-cy),start=Math.atan2(a.p.y-cy,a.p.x-cx),steps=Math.max(4,Math.min(128,Math.ceil(Math.abs(theta)*18)));let prev=a.p;
  for(let k=1;k<=steps;k++){const ang=start+theta*k/steps,cur=k===steps?b.p:{x:cx+r*Math.cos(ang),y:cy+r*Math.sin(ang)};addSeg(prev,cur);prev=cur;}
 }
}
"""
    marker = "function localGeometry(e,mat,inheritedLayer='0'){"
    if body.count(marker) != 1: raise ValueError('manual localGeometry marker missing/ambiguous')
    body = body.replace(marker, helper + marker, 1)

    old_lw = """  if(t==='LWPOLYLINE'){
   const xs=vals(p,10),ys=vals(p,20),pts=xs.slice(0,Math.min(xs.length,ys.length)).map((x,i)=>mapped({x,y:ys[i]}));
   for(let i=1;i<pts.length;i++)addSeg(pts[i-1],pts[i]);if((num(p,70)&1)&&pts.length>2)addSeg(pts[pts.length-1],pts[0]);return;
  }
  if(t==='POLYLINE')return;"""
    new_lw = """  if(t==='LWPOLYLINE'){
   const vertices=[];let current=null;
   for(const q of p){if(q.code===10){if(current&&Number.isFinite(current.x)&&Number.isFinite(current.y))vertices.push({p:mapped(current),bulge:current.bulge||0});current={x:num([q],10,0,NaN),y:NaN,bulge:0};}else if(current&&q.code===20)current.y=num([q],20,0,NaN);else if(current&&q.code===42)current.bulge=Number(q.value)||0;}
   if(current&&Number.isFinite(current.x)&&Number.isFinite(current.y))vertices.push({p:mapped(current),bulge:current.bulge||0});
   drawVertexPath(vertices,!!(num(p,70)&1));return;
  }
  if(t==='POLYLINE')return;"""
    if body.count(old_lw) != 1: raise ValueError('manual LWPOLYLINE snippet missing/ambiguous')
    body = body.replace(old_lw, new_lw, 1)

    old_spline = """  if(t==='SPLINE'||t==='LEADER'){
   const xs=[];for(const code of [10,11,12,13]){const xv=vals(p,code),yv=vals(p,code+10);for(let i=0;i<Math.min(xv.length,yv.length);i++)xs.push(mapped({x:xv[i],y:yv[i]}));}for(let i=1;i<xs.length;i++)addSeg(xs[i-1],xs[i]);return;
  }"""
    new_spline = """  if(t==='SPLINE'){
   // Evaluate the real B-spline from control points + knots. Groups 12/13 are tangent
   // vectors, never positions. When knots are incomplete, fall back to fit points, then controls.
   const cx=vals(p,10),cy=vals(p,20),knots=vals(p,40),weights=vals(p,41),degree=Math.max(1,Math.min(10,Math.round(num(p,71,0,3)))),count=Math.min(cx.length,cy.length),vertices=[];
   if(count>degree&&knots.length===count+degree+1&&knots.every(Number.isFinite)){
    const lo=knots[degree],hi=knots[count];
    if(Number.isFinite(lo)&&Number.isFinite(hi)&&hi>lo){
     const controls=Array.from({length:count},(_,i)=>{const w=weights.length===count&&Number.isFinite(weights[i])&&weights[i]>0?weights[i]:1;return {x:cx[i]*w,y:cy[i]*w,w};});
     const evaluate=tval=>{let span=count-1;for(let i=degree;i<count;i++){if(tval>=knots[i]&&tval<knots[i+1]){span=i;break;}}if(tval>=hi)span=count-1;const d=[];for(let j=0;j<=degree;j++){const q=controls[span-degree+j];d[j]={x:q.x,y:q.y,w:q.w};}for(let r=1;r<=degree;r++)for(let j=degree;j>=r;j--){const i=span-degree+j,den=knots[i+degree-r+1]-knots[i],a=Math.abs(den)<1e-15?0:(tval-knots[i])/den,aa=Math.max(0,Math.min(1,a)),left=d[j-1],right=d[j];d[j]={x:(1-aa)*left.x+aa*right.x,y:(1-aa)*left.y+aa*right.y,w:(1-aa)*left.w+aa*right.w};}const q=d[degree];return Math.abs(q.w)>1e-15?{x:q.x/q.w,y:q.y/q.w}:{x:q.x,y:q.y};};
     let last=null;for(let k=degree;k<count;k++){const a=knots[k],b=knots[k+1];if(!(b>a))continue;const steps=Math.max(8,Math.min(32,Math.ceil((b-a)/(hi-lo)*128)));for(let j=0;j<=steps;j++){if(last&&j===0)continue;const tval=a+(b-a)*j/steps,q=evaluate(tval);if(Number.isFinite(q.x)&&Number.isFinite(q.y)){vertices.push({p:mapped(q),bulge:0});last=q;}}}
    }
   }
   if(vertices.length<2){vertices.length=0;const fx=vals(p,11),fy=vals(p,21),xs=fx.length&&fy.length?fx:cx,ys=fx.length&&fy.length?fy:cy;for(let i=0;i<Math.min(xs.length,ys.length);i++)vertices.push({p:mapped({x:xs[i],y:ys[i]}),bulge:0});}
   drawVertexPath(vertices,false);return;
  }
  if(t==='LEADER'){
   const xs=vals(p,10),ys=vals(p,20),vertices=[];for(let i=0;i<Math.min(xs.length,ys.length);i++)vertices.push({p:mapped({x:xs[i],y:ys[i]}),bulge:0});drawVertexPath(vertices,false);return;
  }"""
    if body.count(old_spline) != 1: raise ValueError('manual SPLINE/LEADER snippet missing/ambiguous')
    body = body.replace(old_spline, new_spline, 1)

    old_poly = """if(e.type==='POLYLINE'){
    const p=e.pairs,vs=[];let j=i+1;for(;j<list.length&&list[j].type!=='SEQEND';j++){if(list[j].type==='VERTEX'){const pt=pairPoint(list[j].pairs,10);if(pt)vs.push(applyMatrix(mat,pt));}}for(let k=1;k<vs.length;k++)addSeg(vs[k-1],vs[k]);if((num(p,70)&1)&&vs.length>2)addSeg(vs[vs.length-1],vs[0]);i=j;entityCount++;continue;
   }"""
    new_poly = """if(e.type==='POLYLINE'){
    const p=e.pairs,vs=[];let j=i+1;for(;j<list.length&&list[j].type!=='SEQEND';j++){if(list[j].type==='VERTEX'){const pt=pairPoint(list[j].pairs,10);if(pt)vs.push({p:applyMatrix(mat,pt),bulge:num(list[j].pairs,42,0,0)});}}drawVertexPath(vs,!!(num(p,70)&1));i=j;entityCount++;continue;
   }"""
    if body.count(old_poly) != 1: raise ValueError('manual classic POLYLINE expansion missing/ambiguous')
    body = body.replace(old_poly, new_poly, 1)
    return body


def patch_reference_module(body: str) -> str:
    # Replace the generic geometry routine that incorrectly connected unrelated group-10..18 points.
    m=re.search(r'function recordGeometry\(rec\)\{[\s\S]*?\n\}\nfunction recordString\(',body)
    if not m: raise ValueError('recordGeometry function could not be isolated')
    body=body[:m.start()]+RECORD_GEOMETRY+'\nfunction recordString('+body[m.end():]

    # Dimensions use their anonymous graphics block whenever one exists; do not draw false spokes
    # between definition points (codes 10/11/12/13) when the block is absent.
    old="const raw=recordGeometry(rec),mapPoint=p=>parent({x:p.x,y:p.y}),layer=recordString(rec,8)||'0',aci=pairVal(rec,62),tc=pairVal(rec,420),lw=pairVal(rec,370),lt=recordString(rec,6)||'CONTINUOUS';"
    new="""if(depth<8&&rec.type==='DIMENSION'){const dimName=recordString(rec,2).toUpperCase(),dimBlock=blocks&&blocks.get(dimName);if(dimBlock&&dimBlock.entities&&dimBlock.entities.length){for(const child of dimBlock.entities)mergeGeometry(empty,geometryInWorld(child,blocks,parent,depth+1));return empty;}}
 const raw=recordGeometry(rec),mapPoint=p=>parent({x:p.x,y:p.y}),layer=recordString(rec,8)||'0',aci=pairVal(rec,62),tc=pairVal(rec,420),lw=pairVal(rec,370),lt=recordString(rec,6)||'CONTINUOUS';"""
    body=replace_once(body,old,new,'dimension block preview')

    # Keep entity selection and delete histories independent per board, so the second/reference
    # screen gains the same editing tools without mutating the other board's transient state.
    body=replace_once(body,
      "selectedEntity:null,selectedEntities:[],undoStack:[],redoStack:[],idPoint:{target:null,reference:null},bound:false};",
      "selectedEntity:null,selectedEntities:[],undoStack:[],redoStack:[],referenceSelectedEntity:null,referenceSelectedEntities:[],referenceUndoStack:[],referenceRedoStack:[],idPoint:{target:null,reference:null},bound:false};",
      'per-board delete state')

    # General selection helpers sit before draw and are reused by rendering/picking/delete actions.
    marker='function draw(v){'
    helpers="""function selectedFor(side){return side==='target'?{entity:state.selectedEntity,entities:state.selectedEntities,bytes:state.target&&state.target.bytes}:{entity:state.referenceSelectedEntity,entities:state.referenceSelectedEntities,bytes:state.reference&&state.reference.bytes};}
// Backward-compatible V130 entity-selection state is generalized per board: state.selectedEntities=list.map(...).
function setSelectedFor(side,entity,entities){if(side==='target'){state.selectedEntity=entity||null;state.selectedEntities=Array.isArray(entities)?entities:[];}else{state.referenceSelectedEntity=entity||null;state.referenceSelectedEntities=Array.isArray(entities)?entities:[];}}
function clearSelectedFor(side){setSelectedFor(side,null,[]);}
function stacksFor(side){return side==='target'?{undo:state.undoStack,redo:state.redoStack}:{undo:state.referenceUndoStack,redo:state.referenceRedoStack};}
"""
    body=replace_once(body,marker,helpers+marker,'selection helper insertion')

    old_selected="const sqSelected=(v.side==='target'&&Array.isArray(state.selectedEntities)&&state.selectedEntities.length&&state.selectedEntities.every(x=>x.sourceBytes===state.target?.bytes))?state.selectedEntities:(v.side==='target'&&state.selectedEntity&&state.selectedEntity.sourceBytes===state.target?.bytes?[state.selectedEntity]:[]);"
    new_selected="const selectionForDraw=selectedFor(v.side),sqSelected=(Array.isArray(selectionForDraw.entities)&&selectionForDraw.entities.length&&selectionForDraw.entities.every(x=>x.sourceBytes===selectionForDraw.bytes))?selectionForDraw.entities:(selectionForDraw.entity&&selectionForDraw.entity.sourceBytes===selectionForDraw.bytes?[selectionForDraw.entity]:[]);"
    body=replace_once(body,old_selected,new_selected,'per-board selection highlighting')
    body=replace_once(body,"if(v.side==='target'&&v.selectionBox){","if(v.selectionBox){",'selection rectangle on both boards')

    # Pointer-up window selection chooses the board attached to the canvas.
    old_box="const list=findEntitiesInWindowBytes(state.target.bytes,{minX:Math.min(a.x,b.x),maxX:Math.max(a.x,b.x),minY:Math.min(a.y,b.y),maxY:Math.max(a.y,b.y)},crossing,v.layerVisibility);state.selectedEntities=list.map(item=>({...item,sourceBytes:state.target.bytes}));state.selectedEntity=state.selectedEntities.at(-1)||null;v.selectionBox=null;draw(v);status('تم تحديد '+list.length+' عنصرًا داخل المستطيل. '+(crossing?'وضع التقاطع: العناصر الملامسة للمستطيل تُحدد.':'وضع النافذة: العناصر الموجودة بالكامل داخل المستطيل تُحدد.')+' اضغط «حذف المحدد» لتنفيذ الحذف الجماعي.');const label=el('sq110TargetMode');if(label)label.textContent='تم تحديد '+list.length+' عنصرًا بالسحب';"
    new_box="const board=state[v.side];if(!board)throw new Error('افتح اللوحة الحالية أولًا.');const list=findEntitiesInWindowBytes(board.bytes,{minX:Math.min(a.x,b.x),maxX:Math.max(a.x,b.x),minY:Math.min(a.y,b.y),maxY:Math.max(a.y,b.y)},crossing,v.layerVisibility),chosen=list.map(item=>({...item,sourceBytes:board.bytes}));setSelectedFor(v.side,chosen.at(-1)||null,chosen);v.selectionBox=null;draw(v);status('تم تحديد '+list.length+' عنصرًا على '+(v.side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+'. '+(crossing?'وضع التقاطع: العناصر الملامسة للمستطيل تُحدد.':'وضع النافذة: العناصر الموجودة بالكامل داخل المستطيل تُحدد.')+' اضغط «حذف المحدد» لتنفيذ الحذف.');const label=el(v.side==='target'?'sq110TargetMode':'sq110ReferenceMode');if(label)label.textContent='تم تحديد '+list.length+' عنصرًا بالسحب';"
    body=replace_once(body,old_box,new_box,'window selection dynamic board')

    old_pick="""if(tool==='selectEntity'||tool==='delete'){
  if(v.side!=='target'){status('اختيار الحذف متاح على اللوحة غير الموجّهة فقط حتى تظل اللوحة المرجعية الأصلية مرجعًا ثابتًا.',true);return;}
  try{const maxWorld=44/Math.max(0.001,metrics(v).scale),found=findNearestEntityBytes(state.target.bytes,world,maxWorld,v.layerVisibility);const chosen={...found,sourceBytes:state.target.bytes};state.selectedEntities=[chosen];state.selectedEntity=chosen;draw(v);const label=el('sq110TargetMode');if(label)label.textContent='تم تحديد '+found.type+' | Layer: '+found.layer+' | اسحب لتحديد مجموعة أو اضغط «حذف المحدد»';status('تم تحديد عنصر '+found.type+' على الطبقة '+found.layer+'. اسحب بإصبع واحد لتحديد عدة عناصر، ثم اضغط «حذف المحدد».');return;}catch(e){status(e.message||String(e),true);return;}
 }"""
    new_pick="""if(tool==='selectEntity'||tool==='delete'){
  try{const board=state[v.side];if(!board)throw new Error('افتح اللوحة الحالية أولًا.');const maxWorld=44/Math.max(0.001,metrics(v).scale),found=findNearestEntityBytes(board.bytes,world,maxWorld,v.layerVisibility),chosen={...found,sourceBytes:board.bytes};setSelectedFor(v.side,chosen,[chosen]);draw(v);const label=el(v.side==='target'?'sq110TargetMode':'sq110ReferenceMode');if(label)label.textContent='تم تحديد '+found.type+' | Layer: '+found.layer+' | اسحب لتحديد مجموعة أو اضغط «حذف المحدد»';status('تم تحديد عنصر '+found.type+' على '+(v.side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+' | Layer: '+found.layer+'. يمكنك تحديد مجموعة ثم الحذف.');return;}catch(e){status(e.message||String(e),true);return;}
 }"""
    body=replace_once(body,old_pick,new_pick,'pick entity on either board')

    old_tool="function setTool(side,tool){state.tool[side]=tool;if(tool!=='selectEntity'){state.selectedEntity=null;state.selectedEntities=[];if(state.views[side]){state.views[side].selectionDrag=null;state.views[side].selectionBox=null;}}updatePickLabels();if(state.views[side])draw(state.views[side]);status(tool==='id'?'تم تفعيل ID Point على '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+'. اضغط نقطة لقراءة إحداثياتها.':tool==='selectEntity'?'تحديد عنصر: اضغط لاختيار عنصر واحد، أو اضغط ضغطة مطوّلة نحو نصف ثانية ثم اسحب لتحديد عدة عناصر بمستطيل. الاتجاه من اليسار إلى اليمين يحدد ما بداخل المستطيل، ومن اليمين إلى اليسار يحدد العناصر الملامسة له.':'تم إيقاف الأداة الإضافية.');}"
    new_tool="function setTool(side,tool){state.tool[side]=tool;if(tool!=='selectEntity'){clearSelectedFor(side);if(state.views[side]){state.views[side].selectionDrag=null;state.views[side].selectionBox=null;}}updatePickLabels();if(state.views[side])draw(state.views[side]);status(tool==='id'?'تم تفعيل ID Point على '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+'. اضغط نقطة لقراءة إحداثياتها.':tool==='selectEntity'?'تحديد عنصر على '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+': اضغط لاختيار عنصر، أو اضغط مطولًا ثم اسحب لتحديد عدة عناصر.':'تم إيقاف الأداة الإضافية.');}"
    body=replace_once(body,old_tool,new_tool,'per-board setTool')

    # Reference loading resets its own transient selection and delete history only.
    old_choose="""}else{state.reference={bytes:data.bytes,name:data.name};state.referencePoints=[null,null];}state.active[side]=0;"""
    new_choose="""}else{state.reference={bytes:data.bytes,name:data.name};state.referencePoints=[null,null];state.referenceSelectedEntity=null;state.referenceSelectedEntities=[];state.referenceUndoStack=[];state.referenceRedoStack=[];updateDeleteHistoryButtons();}state.active[side]=0;"""
    body=replace_once(body,old_choose,new_choose,'reference selection history reset')

    # Generalize delete button state and add reference-side undo/redo.
    old_buttons="function updateDeleteHistoryButtons(){const undo=el('sq110UndoDelete'),redo=el('sq110RedoDelete');if(undo)undo.disabled=!state.undoStack.length;if(redo)redo.disabled=!state.redoStack.length;}"
    new_buttons="function updateDeleteHistoryButtons(){const u=el('sq110UndoDelete'),r=el('sq110RedoDelete'),ru=el('sq110RUndoDelete'),rr=el('sq110RRedoDelete');if(u)u.disabled=!state.undoStack.length;if(r)r.disabled=!state.redoStack.length;if(ru)ru.disabled=!state.referenceUndoStack.length;if(rr)rr.disabled=!state.referenceRedoStack.length;}"
    body=replace_once(body,old_buttons,new_buttons,'four history buttons')

    # Reference board working-copy edit actions. The uploaded reference file is never mutated on disk;
    # deleting only changes the in-memory working copy used by ID/OSNAP and display.
    extras="""function referenceSnapshot(){if(!state.reference)return null;return {bytes:state.reference.bytes.slice(),name:state.reference.name,referencePoints:state.referencePoints.map(p=>p?{...p}:null),idPoint:state.idPoint.reference?{...state.idPoint.reference}:null};}
function restoreReferenceSnapshot(s,msg){if(!s)return;state.reference={bytes:s.bytes.slice(),name:s.name};state.referencePoints=s.referencePoints.map(p=>p?{...p}:null);state.idPoint.reference=s.idPoint?{...s.idPoint}:null;state.referenceSelectedEntity=null;state.referenceSelectedEntities=[];state.tool.reference='pick';loadView('reference',state.reference.bytes,state.reference.name);fillReadouts();updateDeleteHistoryButtons();updatePickLabels();const mode=el('sq110ReferenceMode');if(mode)mode.textContent='اختر النقطة 1 أو 2 على اللوحة المرجعية';status(msg);}
function deleteReferenceEntity(){if(!state.reference){status('افتح اللوحة المرجعية أولًا.',true);return;}const selected=Array.isArray(state.referenceSelectedEntities)&&state.referenceSelectedEntities.length?state.referenceSelectedEntities:(state.referenceSelectedEntity?[state.referenceSelectedEntity]:[]);if(!selected.length||selected.some(x=>x.sourceBytes!==state.reference.bytes)){status('حدد عنصرًا أو مجموعة على اللوحة المرجعية ثم اضغط «حذف المحدد».',true);return;}try{const before=referenceSnapshot(),removed=removeSelectedEntitiesBytes(state.reference.bytes,selected);state.referenceUndoStack.push(before);if(state.referenceUndoStack.length>100)state.referenceUndoStack.shift();state.referenceRedoStack=[];state.reference={bytes:removed.bytes,name:state.reference.name.replace(/(?:_EDITED)*\\.dxf$/i,'_EDITED.dxf')};state.referenceSelectedEntity=null;state.referenceSelectedEntities=[];state.referencePoints=[null,null];state.idPoint.reference=null;state.tool.reference='pick';loadView('reference',state.reference.bytes,state.reference.name);fillReadouts();updateDeleteHistoryButtons();updatePickLabels();status('تم حذف '+removed.deletedCount+' عنصرًا من نسخة العمل للوحة المرجعية فقط. الملف الأصلي على الجهاز لم يتغير. أعد التقاط نقاط المرجع إذا لزم الأمر.');}catch(e){status((e.message||String(e))+' لم يتم حذف أي عنصر.',true);}}
function undoReferenceDelete(){if(!state.referenceUndoStack.length)return;const current=referenceSnapshot(),previous=state.referenceUndoStack.pop();state.referenceRedoStack.push(current);restoreReferenceSnapshot(previous,'تم التراجع عن الحذف على اللوحة المرجعية.');}
function redoReferenceDelete(){if(!state.referenceRedoStack.length)return;const current=referenceSnapshot(),next=state.referenceRedoStack.pop();state.referenceUndoStack.push(current);restoreReferenceSnapshot(next,'تمت إعادة الحذف على اللوحة المرجعية.');}
"""
    body=replace_once(body,"function deleteSelectedEntity(){",extras+"function deleteSelectedEntity(){",'reference delete helper insertion')

    # Add tools to the second/reference screen beside ID Point.
    old_toolbar='<button id="sq110RId" class="sqori-preview" type="button">ID Point</button></div><div id="sq110ReferenceMode"'
    new_toolbar='<button id="sq110RId" class="sqori-preview" type="button">ID Point</button><button id="sq110RSelectEntity" class="sqori-preview" type="button">تحديد عنصر</button><button id="sq110RDelete" class="sqori-preview" type="button">حذف المحدد</button><button id="sq110RUndoDelete" class="sqori-preview" type="button" disabled>تراجع</button><button id="sq110RRedoDelete" class="sqori-preview" type="button" disabled>إعادة</button></div><div id="sq110ReferenceMode"'
    body=replace_once(body,old_toolbar,new_toolbar,'reference toolbar tools')

    # Wire independent reference buttons. Existing target buttons retain their old behavior.
    old_bind="el('sq110SelectEntity').addEventListener('click',()=>setTool('target',state.tool.target==='selectEntity'?'pick':'selectEntity'));el('sq110Delete').addEventListener('click',deleteSelectedEntity);el('sq110UndoDelete').addEventListener('click',undoDelete);el('sq110RedoDelete').addEventListener('click',redoDelete);el('sq110Preview').addEventListener('click',review);"
    new_bind="el('sq110SelectEntity').addEventListener('click',()=>setTool('target',state.tool.target==='selectEntity'?'pick':'selectEntity'));el('sq110Delete').addEventListener('click',deleteSelectedEntity);el('sq110UndoDelete').addEventListener('click',undoDelete);el('sq110RedoDelete').addEventListener('click',redoDelete);el('sq110RSelectEntity').addEventListener('click',()=>setTool('reference',state.tool.reference==='selectEntity'?'pick':'selectEntity'));el('sq110RDelete').addEventListener('click',deleteReferenceEntity);el('sq110RUndoDelete').addEventListener('click',undoReferenceDelete);el('sq110RRedoDelete').addEventListener('click',redoReferenceDelete);el('sq110Preview').addEventListener('click',review);"
    body=replace_once(body,old_bind,new_bind,'reference delete buttons wired')

    # A clean modal reset must clear the additional reference state as well.
    old_reset="state.selectedEntity=null;state.selectedEntities=[];state.undoStack=[];state.redoStack=[];state.idPoint={target:null,reference:null};"
    new_reset="state.selectedEntity=null;state.selectedEntities=[];state.undoStack=[];state.redoStack=[];state.referenceSelectedEntity=null;state.referenceSelectedEntities=[];state.referenceUndoStack=[];state.referenceRedoStack=[];state.idPoint={target:null,reference:null};"
    body=replace_once(body,old_reset,new_reset,'modal reset reference history')

    # Document that CAD preview is native geometry, not synthesized joins between metadata points.
    old_help='سيتم عرض اللوحة المرجعية كما هي من بيانات DXF المتاحة للمعاينة، ولا يُكتب عليها أي تعديل.'
    new_help='تُعرض اللوحة المرجعية من عناصرها الهندسية وطبقاتها وأسمائها المتاحة؛ لا تُنشأ خطوط ربط بين إحداثيات غير مترابطة. أدوات التحديد والحذف هنا تعدّل نسخة العمل داخل شاشة التوجيه فقط، ولا تغيّر الملف الأصلي.'
    body=body.replace(old_help,new_help)
    body=body.replace('height:230px;min-height:230px;max-height:230px;','height:56vh;min-height:360px;max-height:640px;')

    # Exact two-point fit verification before reporting successful matching.
    old_review="function review(){try{const t=calculation();status('المعاينة جاهزة: النقطة 1 تطابق النقطة 1، والنقطة 2 تطابق النقطة 2. معامل المقياس ×'+t.scale.toFixed(10)+' | الدوران '+t.angleDeg.toFixed(6)+'° | X وY دون تبديل.');return t;}catch(e){status(e.message,true);return null;}}"
    new_review="function review(){try{const t=calculation(),pairs=[[state.targetPoints[0],state.referencePoints[0]],[state.targetPoints[1],state.referencePoints[1]]],errors=pairs.map(([s,r])=>{const p=t.point(s.x,s.y);return Math.hypot(p.x-r.x,p.y-r.y);}),tol=Math.max(1e-8,Math.max(...pairs.flatMap(([s,r])=>[Math.abs(s.x),Math.abs(s.y),Math.abs(r.x),Math.abs(r.y)]))*1e-12);if(errors.some(e=>!Number.isFinite(e)||e>tol))throw new Error('فشل فحص التطابق العددي للنقطتين. أعد اختيار النقاط ولا تصدّر هذه المطابقة.');status('المعاينة جاهزة: النقطتان تطابقتا حسابيًا. معامل المقياس ×'+t.scale.toFixed(10)+' | الدوران '+t.angleDeg.toFixed(8)+'° | الإزاحة X='+t.tx.toFixed(6)+' وY='+t.ty.toFixed(6)+' | أقصى خطأ = '+Math.max(...errors).toExponential(3)+' | X وY دون تبديل.');return t;}catch(e){status(e.message,true);return null;}}"
    body=replace_once(body,old_review,new_review,'numerical two-point verification')
    return body


def apply(source_html: str, reference_html: str) -> tuple[str, dict[str,str]]:
    result=source_html
    hashes={}
    for sid in MODULE_IDS:
        ref=get_script(reference_html,sid)
        result=replace_script(result,sid,ref)
        hashes[sid]=hashlib.sha256(ref.encode()).hexdigest()
    manual=patch_manual_module(get_script(result,'sq-orientation-manual-points-module'))
    result=replace_script(result,'sq-orientation-manual-points-module',manual)
    # HATCH and MLINE are already drawn by the manual geometry parser. Drawing them again
    # through the special-object recovery pass duplicated edges and looked like extra lines.
    extra_old="const extraTypes=new Set(['DIMENSION','ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH','SURFACE','HATCH','MLEADER','MLINE','TABLE','IMAGE','WIPEOUT','HELIX','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY']);"
    extra_new="const extraTypes=new Set(['DIMENSION','ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH','SURFACE','MLEADER','TABLE','IMAGE','WIPEOUT','HELIX','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY']);"
    result=replace_once(result,extra_old,extra_new,'remove duplicate HATCH/MLINE preview recovery')
    board=patch_reference_module(get_script(result,'sq-orientation-reference-board-module'))
    result=replace_script(result,'sq-orientation-reference-board-module',board)
    # Keep the no-persistent-board session behavior and roll the guard identity to V142.
    old_guard='id="surveyquant-v140-fresh-board-session"'
    if result.count(old_guard)!=1: raise ValueError('Expected one V140 fresh-board session guard')
    result=result.replace(old_guard,'id="surveyquant-v142-fresh-board-session"',1)
    old_version=f'const SQ_APP_VERSION_CODE = {OLD_CODE};'
    if result.count(old_version)!=1: raise ValueError(f'Expected app version constant {OLD_CODE}, got {result.count(old_version)}')
    result=result.replace(old_version,f'const SQ_APP_VERSION_CODE = {NEW_CODE};',1)
    # Keep global reader / writer and local DWG WebAssembly engine intact.
    for sid in MODULE_IDS:
        if get_script(result,sid) != (patch_reference_module(get_script(reference_html,sid)) if sid=='sq-orientation-reference-board-module' else get_script(reference_html,sid)):
            # For board module, hash-after-patch is validated below; others are byte-identical.
            if sid not in ('sq-orientation-reference-board-module','sq-orientation-manual-points-module'): raise AssertionError(f'Module did not copy exactly: {sid}')
    must = ['id="sq-v117-universal-dwg-bridge"','function sqDwgWasmRuntimePath()','const SQ_APP_VERSION_CODE = 142;','id="surveyquant-v142-fresh-board-session"','id="sq110RDelete"','id="sq110RUndoDelete"','function deleteReferenceEntity()']
    for item in must:
        if item not in result: raise ValueError('required post-patch component missing: '+item)
    return result,hashes

# --- Android binary-manifest version bump: updates only versionCode and same-length versionName. ---
def _len8(data,pos):
    first=data[pos]
    return ((((first&0x7f)<<8)|data[pos+1]),pos+2) if first&0x80 else (first,pos+1)
def _len16(data,pos):
    first=struct.unpack_from('<H',data,pos)[0]
    if first&0x8000:return (((first&0x7fff)<<16)|struct.unpack_from('<H',data,pos+2)[0]),pos+4
    return first,pos+2
def patch_binary_manifest(manifest: bytes) -> bytes:
    if len(manifest)<8 or struct.unpack_from('<H',manifest,0)[0]!=0x0003: raise ValueError('AndroidManifest.xml is not binary XML')
    out=bytearray(manifest);pos=struct.unpack_from('<H',out,2)[0];total=struct.unpack_from('<I',out,4)[0]
    if total>len(out) or total<pos: raise ValueError('invalid binary manifest size')
    strings=None;spans=[];chunks=[]
    while pos<total:
        if pos+8>total: raise ValueError('truncated binary XML')
        typ,hs,cs=struct.unpack_from('<HHI',out,pos)
        if cs<hs or pos+cs>total: raise ValueError('invalid XML chunk bounds')
        chunks.append((pos,typ,hs,cs))
        if typ==1:
            n,_,flags,strings_start,_=struct.unpack_from('<IIIII',out,pos+8);base=pos+strings_start;off=pos+hs;utf8=bool(flags&0x100);strings=[];spans=[]
            if n>100000: raise ValueError('unreasonable string count')
            for i in range(n):
                rel=struct.unpack_from('<I',out,off+i*4)[0];p=base+rel
                if utf8:
                    _,p=_len8(out,p);bl,p=_len8(out,p);a,b=p,p+bl;strings.append(out[a:b].decode('utf-8'));spans.append((a,b,True))
                else:
                    cl,p=_len16(out,p);a,b=p,p+cl*2;strings.append(out[a:b].decode('utf-16le'));spans.append((a,b,False))
        pos+=cs
    if strings is None: raise ValueError('string pool not found')
    old=[i for i,v in enumerate(strings) if v==OLD_NAME]
    if not old and NEW_NAME not in strings: raise ValueError(f'manifest lacks {OLD_NAME} and {NEW_NAME}')
    for i in old:
        a,b,is8=spans[i];enc=NEW_NAME.encode('utf-8' if is8 else 'utf-16le')
        if len(enc)!=b-a: raise ValueError('versionName change would alter string-pool size')
        out[a:b]=enc;strings[i]=NEW_NAME
    found=[]
    for cp,typ,hs,cs in chunks:
        if typ!=0x0102 or cs<36: continue
        nameidx=struct.unpack_from('<I',out,cp+20)[0]
        if nameidx>=len(strings) or strings[nameidx]!='manifest': continue
        ast=struct.unpack_from('<H',out,cp+24)[0];asz=struct.unpack_from('<H',out,cp+26)[0];ac=struct.unpack_from('<H',out,cp+28)[0]
        if asz<20 or ac>1024: raise ValueError('invalid manifest attrs')
        first=cp+16+ast
        for j in range(ac):
            at=first+j*asz;ni=struct.unpack_from('<I',out,at+4)[0]
            if ni<len(strings) and strings[ni]=='versionCode':
                vs=struct.unpack_from('<H',out,at+12)[0];vt=out[at+15]
                if vs<8 or vt not in (0x10,0x11): raise ValueError('versionCode is not typed int')
                found.append(at+16)
    if len(found)!=1: raise ValueError(f'expected one manifest versionCode, found {len(found)}')
    struct.pack_into('<I',out,found[0],NEW_CODE)
    return bytes(out)

def package_apk(input_apk:Path,output_apk:Path,patched_html:Path):
    html_bytes=patched_html.read_bytes();html=html_bytes.decode('utf-8')
    if 'const SQ_APP_VERSION_CODE = 142;' not in html or 'id="surveyquant-v142-fresh-board-session"' not in html: raise ValueError('patched HTML is not V142')
    with zipfile.ZipFile(input_apk,'r') as zin:
        names=[i.filename for i in zin.infolist()]
        if names.count('assets/index.html')!=1 or names.count('AndroidManifest.xml')!=1: raise ValueError('APK missing unique assets/index.html or manifest')
        output_apk.parent.mkdir(parents=True,exist_ok=True);seen=set()
        with zipfile.ZipFile(output_apk,'w',allowZip64=True) as zout:
            for info in zin.infolist():
                n=info.filename
                if n in seen: raise ValueError('duplicate APK entry '+n)
                seen.add(n);up=n.upper()
                if up.startswith('META-INF/') and (up.endswith('.SF') or up.endswith('.RSA') or up.endswith('.DSA') or up.endswith('.EC') or up.endswith('MANIFEST.MF')): continue
                data=zin.read(n)
                if n=='assets/index.html': data=html_bytes
                elif n=='AndroidManifest.xml': data=patch_binary_manifest(data)
                zout.writestr(copy.copy(info),data)
    with zipfile.ZipFile(output_apk,'r') as check:
        if check.read('assets/index.html')!=html_bytes: raise ValueError('APK HTML differs from tested source')
        names=set(check.namelist())
        if 'assets/libredwg-writer/wasm/libredwg-web.wasm' not in names: raise ValueError('local DWG engine was lost')
        if patch_binary_manifest(check.read('AndroidManifest.xml'))!=check.read('AndroidManifest.xml'): raise ValueError('APK version manifest does not verify')
        if 'assets/libredwg-writer/wasm/libredwg-web.js' in names:
            js=check.read('assets/libredwg-writer/wasm/libredwg-web.js')
            if b'return new Promise((reject,resolve)=>{var xhr=new XMLHttpRequest;' in js: raise ValueError('broken WASM Promise resolver order found')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-html',type=Path);ap.add_argument('--reference-html',type=Path);ap.add_argument('--output-html',type=Path);ap.add_argument('--report',type=Path)
    ap.add_argument('--apk-input',type=Path);ap.add_argument('--apk-output',type=Path);ap.add_argument('--html-to-inject',type=Path)
    args=ap.parse_args()
    if args.source_html and args.reference_html and args.output_html and not args.apk_input:
        patched,hashes=apply(args.source_html.read_text(encoding='utf-8'),args.reference_html.read_text(encoding='utf-8'))
        args.output_html.parent.mkdir(parents=True,exist_ok=True);args.output_html.write_text(patched,encoding='utf-8',newline='')
        if args.report:
            lines=['# SurveyQuant V142 orientation patch report','','Transplanted seven orientation modules from V130, with intentional preview fixes in the manual-point and reference-board modules.','']
            lines.extend(f'- `{k}` SHA-256 source: `{v}`' for k,v in hashes.items())
            lines += ['', 'Preview geometry no longer connects unrelated entity coordinate fields. The V140 fresh-board session reset and universal DWG/WASM engine remain present.', 'The DXF entity-byte transformation path remains byte-preserving except numeric geometry/viewport fields intentionally modified for the fitted similarity transform.', 'Reference-board deletions operate on a separate in-memory working copy and support undo/redo; the uploaded original is not changed.']
            args.report.write_text('\n'.join(lines)+'\n',encoding='utf-8')
        print('PASS: V142 HTML patched from V140; V130 orientation engine transplanted; SPLINE/POLYLINE preview and reference delete tools hardened.')
    elif args.apk_input and args.apk_output and args.html_to_inject:
        package_apk(args.apk_input,args.apk_output,args.html_to_inject);print('PASS: V142 HTML injected and binary manifest updated.')
    else: ap.error('provide --source-html --reference-html --output-html [--report], or --apk-input --apk-output --html-to-inject')
if __name__=='__main__': main()
