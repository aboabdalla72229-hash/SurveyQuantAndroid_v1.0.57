#!/usr/bin/env python3
from __future__ import annotations
import argparse, re, tempfile, zipfile
from pathlib import Path

DWG_OLD = "if(ext==='dwg'){const bytes=new Uint8Array(await file.arrayBuffer()),mod=await loadDWG(),LibreDwg=mod.LibreDwg||mod.default?.LibreDwg,Types=mod.Dwg_File_Type||mod.default?.Dwg_File_Type;if(!LibreDwg||!Types)throw new Error('محرك DWG لم يُحمّل بالشكل المتوقع');const lib=await LibreDwg.create(),raw=lib.dwg_read_data(bytes,Types.DWG),converted=lib.convertEx?lib.convertEx(raw):{database:lib.convert(raw)},db=converted.database||converted;try{lib.dwg_free(raw)}catch(_){}return parseDWGDatabase(db);}"
DWG_NEW = r'''if(ext==='dwg'){
  const sourceBytes=new Uint8Array(await file.arrayBuffer());
  let lib=null;
  try{
   const mod=await loadDWG(),LibreDwg=mod.LibreDwg||mod.default?.LibreDwg;
   if(!LibreDwg||typeof LibreDwg.create!=='function')throw new Error('محرك DWG لم يُحمّل بالشكل المتوقع');
   lib=await LibreDwg.create();
   if(typeof lib.dwg_write_dxf!=='function')throw new Error('محرك DWG الحالي لا يحتوي على محول DXF');
   const converted=lib.dwg_write_dxf(sourceBytes.buffer.slice(sourceBytes.byteOffset,sourceBytes.byteOffset+sourceBytes.byteLength));
   const dxfBytes=sqValidateDwgConversion(converted);
   let model=null,lastErr=null;
   for(const encoding of ['utf-8','windows-1252']){
    try{const candidate=parseDXF(new TextDecoder(encoding,{fatal:false}).decode(dxfBytes));if(candidate&&(candidate.entities?.length||candidate.points?.length||candidate.segments?.length||candidate.polylines?.length)){model=candidate;break;}lastErr=new Error('تم تحويل DWG إلى DXF لكن لم يعثر قارئ اللوحة على كيانات مساحية قابلة للقراءة.');}
    catch(e){lastErr=e;}
   }
   if(!model)throw lastErr||new Error('لم يحتوِ DXF الناتج على عناصر قابلة للقراءة.');
   model.source='DWG';model.convertedFromDWG=true;model.sourceName=file.name;
   model.rawDWGBytes=sourceBytes.slice();model.rawDXFBytes=dxfBytes.slice();
   return model;
  }catch(e){throw new Error('تعذرت قراءة ملف DWG عبر محول DXF الداخلي: '+(e&&e.message?e.message:String(e))+' . لم يتم تعديل الملف الأصلي.');}
 }'''

# Selection state preserves the single-tap workflow and adds the multi-select set.
STATE_OLD = "const state={target:null,reference:null,targetPoints:[null,null],referencePoints:[null,null],active:{target:0,reference:0},tool:{target:'pick',reference:'pick'},snapMode:{target:'auto',reference:'auto'},views:{},selectedEntity:null,undoStack:[],redoStack:[],idPoint:{target:null,reference:null},bound:false};"
STATE_NEW = "const state={target:null,reference:null,targetPoints:[null,null],referencePoints:[null,null],active:{target:0,reference:0},tool:{target:'pick',reference:'pick'},snapMode:{target:'auto',reference:'auto'},views:{},selectedEntity:null,selectedEntities:[],undoStack:[],redoStack:[],idPoint:{target:null,reference:null},bound:false};"

ADD_MULTISELECT = r'''function sqPointInRect(p,r){return !!p&&p.x>=r.minX-1e-9&&p.x<=r.maxX+1e-9&&p.y>=r.minY-1e-9&&p.y<=r.maxY+1e-9;}
function sqSegmentIntersectsRect(a,b,r){
 let t0=0,t1=1,dx=b.x-a.x,dy=b.y-a.y;
 const tests=[[-dx,a.x-r.minX],[dx,r.maxX-a.x],[-dy,a.y-r.minY],[dy,r.maxY-a.y]];
 for(const [p,q] of tests){if(Math.abs(p)<1e-15){if(q<0)return false;continue;}const t=q/p;if(p<0){if(t>t1)return false;if(t>t0)t0=t;}else{if(t<t0)return false;if(t<t1)t1=t;}}
 return t0<=t1;
}
function findEntitiesInWindowBytes(input,box,crossing=false,layerVisibility){
 const rect={minX:Math.min(Number(box.minX),Number(box.maxX)),maxX:Math.max(Number(box.minX),Number(box.maxX)),minY:Math.min(Number(box.minY),Number(box.maxY)),maxY:Math.max(Number(box.minY),Number(box.maxY))};
 if(![rect.minX,rect.maxX,rect.minY,rect.maxY].every(Number.isFinite)||rect.maxX-rect.minX<1e-12||rect.maxY-rect.minY<1e-12)throw new Error('مستطيل التحديد صغير جدًا أو إحداثياته غير صالحة.');
 const parsed=splitPairs(input),bytes=parsed.bytes,records=sectionRecords(parsed.pairs,'ENTITIES'),blocks=blockDefinitions(parsed.pairs),found=[];
 for(let index=0;index<records.length;index++){
  const rec=records[index];if(rec.pairs.some(p=>p.code===67&&Number(p.value)===1))continue;
  const layer=recordString(rec,8)||'0';if(layerVisibility){const pair=Object.entries(layerVisibility).find(([name])=>String(name).toUpperCase()===layer.toUpperCase());if(pair&&pair[1]===false)continue;}
  const geometry=geometryInWorld(rec,blocks),points=[];
  for(const p of geometry.pts||[])points.push(p);
  for(const s of geometry.segments||[]){points.push(s.a,s.b);}
  for(const t of geometry.texts||[])if(t.p)points.push(t.p);
  if(!points.length)continue;
  const inside=points.every(p=>sqPointInRect(p,rect));
  let hit=inside;
  if(!hit&&crossing){hit=points.some(p=>sqPointInRect(p,rect))||(geometry.segments||[]).some(s=>sqSegmentIntersectsRect(s.a,s.b,rect));}
  if(!hit)continue;
  const start=rec.start,end=rec.end;if(!Number.isInteger(start)||!Number.isInteger(end)||start<0||end>bytes.length||end<=start)continue;
  found.push({start,end,type:rec.type,index,layer,distance:0,geometry,raw:bytes.slice(start,end),sourceBytes:input});
 }
 // A DXF INSERT can represent a complete block. De-duplicate exact ranges and return in drawing order.
 const unique=new Map();for(const item of found)unique.set(item.start+':'+item.end,item);
 return Array.from(unique.values());
}
function removeSelectedEntitiesBytes(input,selectedEntities){
 const parsed=splitPairs(input),bytes=parsed.bytes;
 if(!Array.isArray(selectedEntities)||!selectedEntities.length)throw new Error('لم يتم تحديد عناصر داخل المستطيل. اسحب المستطيل حول الخطوط أو النصوص المطلوبة ثم جرّب.');
 const ranges=[],seen=new Set();
 for(const item of selectedEntities){
  if(!item||!Number.isInteger(item.start)||!Number.isInteger(item.end)||item.start<0||item.end>bytes.length||item.end<=item.start)throw new Error('أحد العناصر المحددة لم يعد موجودًا. أعد تحديد العناصر قبل الحذف.');
  const key=item.start+':'+item.end;if(seen.has(key))continue;seen.add(key);
  if(!(item.raw instanceof Uint8Array)||item.raw.length!==item.end-item.start)throw new Error('بيانات أحد العناصر المحددة غير مكتملة. لم يتم حذف أي عنصر.');
  for(let i=0;i<item.raw.length;i++)if(bytes[item.start+i]!==item.raw[i])throw new Error('تغيرت اللوحة بعد التحديد. حدّد العناصر مرة أخرى قبل الحذف.');
  ranges.push({start:item.start,end:item.end,type:item.type,layer:item.layer});
 }
 ranges.sort((a,b)=>a.start-b.start);for(let i=1;i<ranges.length;i++)if(ranges[i].start<ranges[i-1].end)throw new Error('تداخلت حدود بعض العناصر المحددة؛ تم إلغاء الحذف حفاظًا على الملف.');
 const length=bytes.length-ranges.reduce((n,r)=>n+r.end-r.start,0),out=new Uint8Array(length);let src=0,dst=0;
 for(const r of ranges){const n=r.start-src;out.set(bytes.subarray(src,r.start),dst);dst+=n;src=r.end;}out.set(bytes.subarray(src),dst);
 return {bytes:out,deletedCount:ranges.length,deletedTypes:ranges.map(r=>r.type),layers:Array.from(new Set(ranges.map(r=>r.layer||'0'))),recoveredLines:parsed.recoveredLines||0};
}'''

# Replace the existing draw overlay with multi-selection highlighting and a visible rubber-band rectangle.
OVERLAY_PATTERN = re.compile(r"if\(v\.side==='target'&&state\.selectedEntity&&state\.selectedEntity\.sourceBytes===state\.target\?\.bytes&&state\.selectedEntity\.geometry\)\{.*?c\.restore\(\);\}const arr=v\.side==='target'\?state\.targetPoints:state\.referencePoints;for\(let i=0;i<2;i\+\+\)\{", re.S)
OVERLAY_NEW = r'''const sqSelected=(v.side==='target'&&Array.isArray(state.selectedEntities)&&state.selectedEntities.length&&state.selectedEntities.every(x=>x.sourceBytes===state.target?.bytes))?state.selectedEntities:(v.side==='target'&&state.selectedEntity&&state.selectedEntity.sourceBytes===state.target?.bytes?[state.selectedEntity]:[]);for(const selected of sqSelected){const sg=selected.geometry;if(!sg)continue;c.save();c.strokeStyle='#ff4fd8';c.fillStyle='rgba(255,79,216,.22)';c.lineWidth=3.6;c.setLineDash([6,3]);c.lineCap='round';c.lineJoin='round';for(const seg of sg.segments||[]){if(!layerVisible(v,seg.layer))continue;const a=project(v,seg.a,m),b=project(v,seg.b,m);if(![a.x,a.y,b.x,b.y].every(Number.isFinite))continue;c.beginPath();c.moveTo(a.x,a.y);c.lineTo(b.x,b.y);c.stroke();}c.setLineDash([]);for(const p0 of sg.pts||[]){if(!layerVisible(v,p0.layer))continue;const q=project(v,p0,m);if(!Number.isFinite(q.x)||!Number.isFinite(q.y))continue;c.beginPath();c.arc(q.x,q.y,4.5,0,Math.PI*2);c.fill();c.stroke();}for(const tx of sg.texts||[]){if(!tx.p)continue;const q=project(v,tx.p,m);c.font='bold 13px sans-serif';const w=Math.min(240,Math.max(16,c.measureText(String(tx.text||'')).width+8));c.fillStyle='rgba(255,79,216,.18)';c.fillRect(q.x-2,q.y-15,w,18);c.strokeStyle='#ff4fd8';c.strokeRect(q.x-2,q.y-15,w,18);}c.restore();}if(v.side==='target'&&v.selectionBox){const b=v.selectionBox;c.save();c.lineWidth=1.5;c.strokeStyle='#38bdf8';c.fillStyle='rgba(56,189,248,.12)';c.setLineDash([5,3]);c.beginPath();c.rect(Math.min(b.x1,b.x2),Math.min(b.y1,b.y2),Math.abs(b.x2-b.x1),Math.abs(b.y2-b.y1));c.fill();c.stroke();c.restore();}const arr=v.side==='target'?state.targetPoints:state.referencePoints;for(let i=0;i<2;i++){'''

# Pointer handlers: a one-finger drag in select mode is a window; tap still selects one item; two fingers remain pinch zoom.
POINTER_OLD = r''' c.addEventListener('pointerdown',e=>{
  e.preventDefault();v.pointerMap.set(e.pointerId,{x:e.clientX,y:e.clientY});try{c.setPointerCapture(e.pointerId);}catch(_){}
  if(v.pointerMap.size>=2){v.suppressTap=true;const pair=Array.from(v.pointerMap.values()).slice(0,2),center={x:(pair[0].x+pair[1].x)/2,y:(pair[0].y+pair[1].y)/2},r=c.getBoundingClientRect(),local={x:center.x-r.left,y:center.y-r.top};v.pinch={distance:Math.max(1,Math.hypot(pair[0].x-pair[1].x,pair[0].y-pair[1].y)),zoom:v.zoom,world:unproject(v,local)};v.mode='pinch';v.drag=null;v.didDrag=true;
  }else{v.mode='panOrTap';v.drag={id:e.pointerId,x:e.clientX,y:e.clientY,panX:v.panX,panY:v.panY};v.didDrag=false;v.suppressTap=false;}
 });
 c.addEventListener('pointermove',e=>{if(!v.pointerMap.has(e.pointerId))return;v.pointerMap.set(e.pointerId,{x:e.clientX,y:e.clientY});if(v.mode==='pinch'&&v.pointerMap.size>=2&&v.pinch){const pair=Array.from(v.pointerMap.values()).slice(0,2),center={x:(pair[0].x+pair[1].x)/2,y:(pair[0].y+pair[1].y)/2},distance=Math.max(1,Math.hypot(pair[0].x-pair[1].x,pair[0].y-pair[1].y)),r=c.getBoundingClientRect(),local={x:center.x-r.left,y:center.y-r.top};v.zoom=Math.max(.15,Math.min(100000,v.pinch.zoom*distance/v.pinch.distance));const m=metrics(v);v.panX=local.x-m.w/2-(v.pinch.world.x-m.cx)*m.scale;v.panY=local.y-m.h/2+(v.pinch.world.y-m.cy)*m.scale;v.didDrag=true;draw(v);return;}if(v.mode==='panOrTap'&&v.drag&&v.drag.id===e.pointerId){if(Math.hypot(e.clientX-v.drag.x,e.clientY-v.drag.y)>5)v.didDrag=true;if(v.didDrag){v.panX=v.drag.panX+e.clientX-v.drag.x;v.panY=v.drag.panY+e.clientY-v.drag.y;draw(v);}}});
 c.addEventListener('pointerup',e=>{const wasPinch=v.mode==='pinch'||v.pointerMap.size>1,wasTap=!wasPinch&&v.mode==='panOrTap'&&v.drag&&v.drag.id===e.pointerId&&!v.didDrag&&!v.suppressTap;v.pointerMap.delete(e.pointerId);try{c.releasePointerCapture(e.pointerId);}catch(_){}if(wasPinch){v.suppressTap=true;v.pinch=null;if(v.pointerMap.size===1){const p=Array.from(v.pointerMap.entries())[0];v.mode='panOrTap';v.drag={id:p[0],x:p[1].x,y:p[1].y,panX:v.panX,panY:v.panY};v.didDrag=true;}else{v.mode='';v.drag=null;}return;}if(wasTap)pick(v,e.clientX,e.clientY);v.drag=null;v.mode='';v.didDrag=false;v.suppressTap=false;});
 c.addEventListener('pointercancel',e=>{v.pointerMap.delete(e.pointerId);v.mode='';v.drag=null;v.pinch=null;v.suppressTap=true;});'''
POINTER_NEW = r''' c.addEventListener('pointerdown',e=>{
  e.preventDefault();v.pointerMap.set(e.pointerId,{x:e.clientX,y:e.clientY});try{c.setPointerCapture(e.pointerId);}catch(_){}
  if(v.pointerMap.size>=2){clearTimeout(v.selectionLongPressTimer);v.selectionLongPressTimer=null;v.selectionDrag=null;v.selectionBox=null;v.suppressTap=true;const pair=Array.from(v.pointerMap.values()).slice(0,2),center={x:(pair[0].x+pair[1].x)/2,y:(pair[0].y+pair[1].y)/2},r=c.getBoundingClientRect(),local={x:center.x-r.left,y:center.y-r.top};v.pinch={distance:Math.max(1,Math.hypot(pair[0].x-pair[1].x,pair[0].y-pair[1].y)),zoom:v.zoom,world:unproject(v,local)};v.mode='pinch';v.drag=null;v.didDrag=true;
  }else if(v.side==='target'&&state.tool.target==='selectEntity'){
   const r=c.getBoundingClientRect(),start={x:e.clientX-r.left,y:e.clientY-r.top};v.mode='selectBox';v.selectionDrag={id:e.pointerId,start,current:start,originClient:{x:e.clientX,y:e.clientY},moved:false,armed:false,cancelled:false};v.selectionBox=null;v.drag=null;v.didDrag=false;v.suppressTap=false;clearTimeout(v.selectionLongPressTimer);v.selectionLongPressTimer=setTimeout(()=>{const sd=v.selectionDrag;if(sd&&sd.id===e.pointerId&&v.mode==='selectBox'&&v.pointerMap.has(e.pointerId)){sd.armed=true;v.selectionBox={x1:sd.start.x,y1:sd.start.y,x2:sd.current.x,y2:sd.current.y};draw(v);}},350);
  }else{v.mode='panOrTap';v.drag={id:e.pointerId,x:e.clientX,y:e.clientY,panX:v.panX,panY:v.panY};v.didDrag=false;v.suppressTap=false;}
 });
 c.addEventListener('pointermove',e=>{if(!v.pointerMap.has(e.pointerId))return;v.pointerMap.set(e.pointerId,{x:e.clientX,y:e.clientY});if(v.mode==='pinch'&&v.pointerMap.size>=2&&v.pinch){const pair=Array.from(v.pointerMap.values()).slice(0,2),center={x:(pair[0].x+pair[1].x)/2,y:(pair[0].y+pair[1].y)/2},distance=Math.max(1,Math.hypot(pair[0].x-pair[1].x,pair[0].y-pair[1].y)),r=c.getBoundingClientRect(),local={x:center.x-r.left,y:center.y-r.top};v.zoom=Math.max(.15,Math.min(100000,v.pinch.zoom*distance/v.pinch.distance));const m=metrics(v);v.panX=local.x-m.w/2-(v.pinch.world.x-m.cx)*m.scale;v.panY=local.y-m.h/2+(v.pinch.world.y-m.cy)*m.scale;v.didDrag=true;draw(v);return;}
  if(v.mode==='selectBox'&&v.selectionDrag&&v.selectionDrag.id===e.pointerId){const r=c.getBoundingClientRect(),current={x:e.clientX-r.left,y:e.clientY-r.top},sd=v.selectionDrag;sd.current=current;if(!sd.armed){if(Math.hypot(current.x-sd.start.x,current.y-sd.start.y)>8){clearTimeout(v.selectionLongPressTimer);v.selectionLongPressTimer=null;sd.cancelled=true;}return;}if(Math.hypot(current.x-sd.start.x,current.y-sd.start.y)>6){sd.moved=true;v.selectionBox={x1:sd.start.x,y1:sd.start.y,x2:current.x,y2:current.y};draw(v);}return;}
  if(v.mode==='panOrTap'&&v.drag&&v.drag.id===e.pointerId){if(Math.hypot(e.clientX-v.drag.x,e.clientY-v.drag.y)>5)v.didDrag=true;if(v.didDrag){v.panX=v.drag.panX+e.clientX-v.drag.x;v.panY=v.drag.panY+e.clientY-v.drag.y;draw(v);}}});
 c.addEventListener('pointerup',e=>{const wasPinch=v.mode==='pinch'||v.pointerMap.size>1,wasSelectionDrag=!wasPinch&&v.mode==='selectBox'&&v.selectionDrag&&v.selectionDrag.id===e.pointerId,wasTap=!wasPinch&&!wasSelectionDrag&&v.mode==='panOrTap'&&v.drag&&v.drag.id===e.pointerId&&!v.didDrag&&!v.suppressTap;const selection=v.selectionDrag;clearTimeout(v.selectionLongPressTimer);v.selectionLongPressTimer=null;v.pointerMap.delete(e.pointerId);try{c.releasePointerCapture(e.pointerId);}catch(_){}if(wasPinch){v.suppressTap=true;v.pinch=null;v.selectionDrag=null;v.selectionBox=null;if(v.pointerMap.size===1){const p=Array.from(v.pointerMap.entries())[0];v.mode='panOrTap';v.drag={id:p[0],x:p[1].x,y:p[1].y,panX:v.panX,panY:v.panY};v.didDrag=true;}else{v.mode='';v.drag=null;}draw(v);return;}if(wasSelectionDrag){v.selectionDrag=null;v.mode='';v.drag=null;if(selection&&selection.moved){const r=c.getBoundingClientRect(),m=metrics(v),a=unproject(v,selection.start,m),b=unproject(v,selection.current,m),crossing=selection.current.x<selection.start.x;try{const list=findEntitiesInWindowBytes(state.target.bytes,{minX:Math.min(a.x,b.x),maxX:Math.max(a.x,b.x),minY:Math.min(a.y,b.y),maxY:Math.max(a.y,b.y)},crossing,v.layerVisibility);state.selectedEntities=list.map(item=>({...item,sourceBytes:state.target.bytes}));state.selectedEntity=state.selectedEntities.at(-1)||null;v.selectionBox=null;draw(v);status('تم تحديد '+list.length+' عنصرًا داخل المستطيل. '+(crossing?'وضع التقاطع: العناصر الملامسة للمستطيل تُحدد.':'وضع النافذة: العناصر الموجودة بالكامل داخل المستطيل تُحدد.')+' اضغط «حذف المحدد» لتنفيذ الحذف الجماعي.');const label=el('sq110TargetMode');if(label)label.textContent='تم تحديد '+list.length+' عنصرًا بالسحب';}catch(err){v.selectionBox=null;draw(v);status(err.message||String(err),true);}}else if(selection&&!selection.cancelled){v.selectionBox=null;pick(v,e.clientX,e.clientY);}else{v.selectionBox=null;draw(v);}v.didDrag=false;v.suppressTap=false;return;}if(wasTap)pick(v,e.clientX,e.clientY);v.drag=null;v.mode='';v.didDrag=false;v.suppressTap=false;});
 c.addEventListener('pointercancel',e=>{clearTimeout(v.selectionLongPressTimer);v.selectionLongPressTimer=null;v.pointerMap.delete(e.pointerId);v.mode='';v.drag=null;v.pinch=null;v.selectionDrag=null;v.selectionBox=null;v.suppressTap=true;draw(v);});'''

# The current pick branch only sets one entity. Replace it with a single-selection array.
PICK_OLD = "try{const maxWorld=44/Math.max(0.001,metrics(v).scale),found=findNearestEntityBytes(state.target.bytes,world,maxWorld,v.layerVisibility);state.selectedEntity={...found,sourceBytes:state.target.bytes};draw(v);const label=el('sq110TargetMode');if(label)label.textContent='تم تحديد '+found.type+' | Layer: '+found.layer+' | اضغط «حذف المحدد» أو اختر عنصرًا آخر';status('تم تحديد عنصر '+found.type+' على الطبقة '+found.layer+'. اضغط الآن «حذف المحدد». لم يتم تغيير الملف بعد.');return;}catch(e){status(e.message||String(e),true);return;}"
PICK_NEW = "try{const maxWorld=44/Math.max(0.001,metrics(v).scale),found=findNearestEntityBytes(state.target.bytes,world,maxWorld,v.layerVisibility);const chosen={...found,sourceBytes:state.target.bytes};state.selectedEntities=[chosen];state.selectedEntity=chosen;draw(v);const label=el('sq110TargetMode');if(label)label.textContent='تم تحديد '+found.type+' | Layer: '+found.layer+' | اسحب لتحديد مجموعة أو اضغط «حذف المحدد»';status('تم تحديد عنصر '+found.type+' على الطبقة '+found.layer+'. اسحب بإصبع واحد لتحديد عدة عناصر، ثم اضغط «حذف المحدد».');return;}catch(e){status(e.message||String(e),true);return;}"

# Replace deletion action to use the multi-entity safe byte-range remover.
DELETE_OLD = r'''function deleteSelectedEntity(){if(!state.target) {status('افتح اللوحة غير الموجّهة أولًا.',true);return;}const selected=state.selectedEntity;if(!selected||selected.sourceBytes!==state.target.bytes){status('حدد عنصرًا على اللوحة أولًا باستخدام «تحديد عنصر»، ثم اضغط «حذف المحدد».',true);return;}try{const before=targetSnapshot(),removed=removeSelectedEntityBytes(state.target.bytes,selected);state.undoStack.push(before);if(state.undoStack.length>100)state.undoStack.shift();state.redoStack=[];state.target={bytes:removed.bytes,name:state.target.name.replace(/(?:_EDITED)*\.dxf$/i,'_EDITED.dxf')};state.selectedEntity=null;state.idPoint.target=null;state.tool.target='pick';loadView('target',state.target.bytes,state.target.name);fillReadouts();updateDeleteHistoryButtons();updatePickLabels();status('تم حذف العنصر '+removed.deletedType+' من الطبقة '+removed.layer+'. بقية بايتات اللوحة الأصلية محفوظة. استخدم «تراجع» لاسترجاعه أو «إعادة» لتنفيذ الحذف مجددًا.');}catch(e){status((e.message||String(e))+' لم يتم حذف أي عنصر.',true);}}'''
DELETE_NEW = r'''function deleteSelectedEntity(){if(!state.target){status('افتح اللوحة غير الموجّهة أولًا.',true);return;}const selected=Array.isArray(state.selectedEntities)&&state.selectedEntities.length?state.selectedEntities:(state.selectedEntity?[state.selectedEntity]:[]);if(!selected.length||selected.some(x=>x.sourceBytes!==state.target.bytes)){status('حدد عنصرًا بالنقر أو عدة عناصر بالسحب داخل مستطيل باستخدام «تحديد عنصر»، ثم اضغط «حذف المحدد».',true);return;}try{const before=targetSnapshot(),removed=removeSelectedEntitiesBytes(state.target.bytes,selected);state.undoStack.push(before);if(state.undoStack.length>100)state.undoStack.shift();state.redoStack=[];state.target={bytes:removed.bytes,name:state.target.name.replace(/(?:_EDITED)*\.dxf$/i,'_EDITED.dxf')};state.selectedEntity=null;state.selectedEntities=[];state.idPoint.target=null;state.tool.target='pick';loadView('target',state.target.bytes,state.target.name);fillReadouts();updateDeleteHistoryButtons();updatePickLabels();status('تم حذف '+removed.deletedCount+' عنصرًا من نسخة العمل فقط. الطبقات وبيانات وبايتات كل العناصر الأخرى محفوظة. استخدم «تراجع» للاسترجاع أو «إعادة» للتكرار.');}catch(e){status((e.message||String(e))+' لم يتم حذف أي عنصر.',true);}}'''

OLD_UNDO_STATE = "state.selectedEntity=null;state.tool.target='pick';loadView('target',state.target.bytes,state.target.name);"
NEW_UNDO_STATE = "state.selectedEntity=null;state.selectedEntities=[];state.tool.target='pick';loadView('target',state.target.bytes,state.target.name);"
OLD_SETTOOL = "function setTool(side,tool){state.tool[side]=tool;if(tool!=='selectEntity')state.selectedEntity=null;updatePickLabels();if(state.views[side])draw(state.views[side]);status(tool==='id'?'تم تفعيل ID Point على '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+'. اضغط نقطة لقراءة إحداثياتها.':tool==='selectEntity'?'تم تفعيل تحديد العنصر. المس خطًا أو نصًا في اللوحة، وسيظهر تحديده قبل الحذف.':'تم إيقاف الأداة الإضافية.');}"
NEW_SETTOOL = "function setTool(side,tool){state.tool[side]=tool;if(tool!=='selectEntity'){state.selectedEntity=null;state.selectedEntities=[];if(state.views[side]){state.views[side].selectionDrag=null;state.views[side].selectionBox=null;}}updatePickLabels();if(state.views[side])draw(state.views[side]);status(tool==='id'?'تم تفعيل ID Point على '+(side==='target'?'اللوحة غير الموجّهة':'اللوحة المرجعية')+'. اضغط نقطة لقراءة إحداثياتها.':tool==='selectEntity'?'تحديد عنصر: اضغط لاختيار عنصر واحد، أو اضغط ضغطة مطوّلة نحو نصف ثانية ثم اسحب لتحديد عدة عناصر بمستطيل. الاتجاه من اليسار إلى اليمين يحدد ما بداخل المستطيل، ومن اليمين إلى اليسار يحدد العناصر الملامسة له.':'تم إيقاف الأداة الإضافية.');}"

OLD_TARGET_CLEAR = "state.selectedEntity=null;state.undoStack=[];state.redoStack=[];updateDeleteHistoryButtons();}else"
NEW_TARGET_CLEAR = "state.selectedEntity=null;state.selectedEntities=[];state.undoStack=[];state.redoStack=[];updateDeleteHistoryButtons();draw(view);}else"
OLD_MOUNT_RESET = "state.views={};state.selectedEntity=null;state.undoStack=[];state.redoStack=[];state.idPoint={target:null,reference:null};"
NEW_MOUNT_RESET = "state.views={};state.selectedEntity=null;state.selectedEntities=[];state.undoStack=[];state.redoStack=[];state.idPoint={target:null,reference:null};"
OLD_VIEW_OBJECT = "pointerMap:new Map(),mode:'',drag:null,pinch:null,didDrag:false,suppressTap:false,layerVisibility:Object.create(null)"
NEW_VIEW_OBJECT = "pointerMap:new Map(),mode:'',drag:null,pinch:null,selectionDrag:null,selectionBox:null,selectionLongPressTimer:null,didDrag:false,suppressTap:false,layerVisibility:Object.create(null)"
OLD_GUIDE = "الحذف يمسح الكيان المحدد من نسخة العمل فقط، وله تراجع."
NEW_GUIDE = "للحذف الجماعي فعّل «تحديد عنصر» واسحب بإصبع واحد لرسم مستطيل؛ من اليسار لليمين يحدد العناصر الواقعة بالكامل داخله، ومن اليمين لليسار يحدد العناصر الملامسة له. اضغط «حذف المحدد» للحذف الجماعي، ويمكنك التراجع."
OLD_EXPORT_API = "window.__sqOrientation110API={VERSION,solve,transformBytes:universalTransformBytes,deleteNearestEntityBytes,findNearestEntityBytes,removeSelectedEntityBytes,splitPairs,sectionRecords,recordGeometry,geometryInWorld,blockDefinitions,parsePreview};"
NEW_EXPORT_API = "window.__sqOrientation110API={VERSION,solve,transformBytes:universalTransformBytes,deleteNearestEntityBytes,findNearestEntityBytes,findEntitiesInWindowBytes,removeSelectedEntityBytes,removeSelectedEntitiesBytes,splitPairs,sectionRecords,recordGeometry,geometryInWorld,blockDefinitions,parsePreview};"

# Fix INSERT-transformed text in the orientation viewer: apply block scale and angle to text height/orientation.
TEXT_OLD = "const pos=mapped(pairPoint(p,10));if(pos){addPoint(pos);const label=textValue(p);if(label)texts.push({p:pos,text:label,...activeStyle,height:num(p,40,0,2.5),rotation:num(p,50,0,0),widthFactor:num(p,41,0,1),entityType:t});}return;"
TEXT_NEW = "const pos=mapped(pairPoint(p,10));if(pos){addPoint(pos);const label=textValue(p);if(label){const localAngle=num(p,50,0,0)*Math.PI/180,vx=Math.cos(localAngle),vy=Math.sin(localAngle),tx=mat.a*vx+mat.b*vy,ty=mat.c*vx+mat.d*vy,normalX=mat.a*(-vy)+mat.b*vx,normalY=mat.c*(-vy)+mat.d*vx,textScale=Math.hypot(normalX,normalY),textRotation=Math.atan2(ty,tx)*180/Math.PI;texts.push({p:pos,text:label,...activeStyle,height:num(p,40,0,2.5)*Math.max(1e-9,textScale),rotation:textRotation,widthFactor:num(p,41,0,1),entityType:t});}}return;"


def replace_once(s: str, old: str, new: str, label: str) -> str:
    count=s.count(old)
    if count!=1: raise SystemExit(f'ERROR {label}: expected one matching patch point, found {count}')
    return s.replace(old,new,1)

def patch_html(s: str) -> str:
    if 'function sqValidateDwgConversion(converted)' in s: raise SystemExit('V130 DWG reader patch already applied')
    s=replace_once(s,DWG_OLD,DWG_NEW,'shared parser DWG branch')
    marker='async function parseFile(file){'
    helper=r'''function sqValidateDwgConversion(converted){
 if(!converted)throw new Error('محرك LibreDWG أعاد نتيجة فارغة.');
 let out;
 if(converted instanceof Uint8Array)out=converted.slice();
 else if(converted instanceof ArrayBuffer)out=new Uint8Array(converted);
 else if(ArrayBuffer.isView(converted))out=new Uint8Array(converted.buffer,converted.byteOffset,converted.byteLength).slice();
 else if(Array.isArray(converted))out=Uint8Array.from(converted);
 else throw new Error('صيغة ناتج التحويل غير معروفة.');
 if(out.length<64)throw new Error('ملف DXF المحول أقصر من الحجم المتوقع.');
 const head=new TextDecoder('latin1').decode(out.subarray(0,Math.min(out.length,4*1024*1024))),tail=new TextDecoder('latin1').decode(out.subarray(Math.max(0,out.length-128)));
 if(!/SECTION/i.test(head)||!/EOF\s*$/i.test(tail.trim()))throw new Error('فشل التحقق من بنية DXF الناتج؛ لم يتم اعتماد التحويل.');
 return out;
}
'''
    s=replace_once(s,marker,helper+marker,'DXF conversion validator insertion')
    # Fix scaled/rotated text belonging to INSERT blocks.
    s=replace_once(s,TEXT_OLD,TEXT_NEW,'orientation nested block text transform')
    s=replace_once(s,STATE_OLD,STATE_NEW,'multi-selection state')
    # Insert selection-window and batch deletion functions after the single-record remover.
    marker='function deleteNearestEntityBytes(input,world,tolerance){const selected=findNearestEntityBytes(input,world,tolerance);return removeSelectedEntityBytes(input,selected);}'
    s=replace_once(s,marker,ADD_MULTISELECT+'\n'+marker,'window select and batch removal algorithms')
    s=replace_once(s,OVERLAY_PATTERN.pattern,OVERLAY_NEW,'multi-select drawing overlay') if False else s
    count=len(OVERLAY_PATTERN.findall(s))
    if count!=1: raise SystemExit(f'ERROR selected overlay: expected one matching block, found {count}')
    s=OVERLAY_PATTERN.sub(lambda m:OVERLAY_NEW,s,count=1)
    s=replace_once(s,POINTER_OLD.lstrip(),POINTER_NEW.lstrip(),'canvas drag selection gesture')
    s=replace_once(s,PICK_OLD,PICK_NEW,'single selection state')
    s=replace_once(s,DELETE_OLD,DELETE_NEW,'batch delete action')
    s=replace_once(s,OLD_UNDO_STATE,NEW_UNDO_STATE,'clear multi-selection during undo')
    s=replace_once(s,OLD_SETTOOL,NEW_SETTOOL,'selection tool instructions')
    s=replace_once(s,OLD_TARGET_CLEAR,NEW_TARGET_CLEAR,'clear selections on board change')
    s=replace_once(s,OLD_MOUNT_RESET,NEW_MOUNT_RESET,'reset multi-select state')
    s=replace_once(s,OLD_VIEW_OBJECT,NEW_VIEW_OBJECT,'selection rectangle view state')
    # Guide string appears inside the orientation panel HTML.
    if s.count(OLD_GUIDE)<1: raise SystemExit('ERROR orientation multi-select user guide not found')
    s=s.replace(OLD_GUIDE,NEW_GUIDE,1)
    s=replace_once(s,OLD_EXPORT_API,NEW_EXPORT_API,'export multi-select test APIs')
    # API string export should expose the exact byte-selection method to regression tests.
    return s

def patch_apk(source: Path, output: Path):
    if not source.is_file():raise SystemExit(f'APK missing: {source}')
    output.parent.mkdir(parents=True,exist_ok=True);fd,tmpname=tempfile.mkstemp(prefix='sq-v130-',suffix='.apk',dir=output.parent);Path(tmpname).unlink(missing_ok=True);changed=0
    try:
        with zipfile.ZipFile(source,'r') as zi,zipfile.ZipFile(tmpname,'w') as zo:
            for info in zi.infolist():
                if re.match(r'^META-INF/[^/]+\.(?:SF|RSA|DSA|EC|MF)$',info.filename,re.I):continue
                data=zi.read(info.filename)
                if info.filename=='assets/index.html':data=patch_html(data.decode('utf-8')).encode('utf-8');changed+=1
                zo.writestr(info,data)
        if changed!=1:raise SystemExit(f'Expected exactly one assets/index.html, found {changed}')
        Path(tmpname).replace(output)
    except Exception:Path(tmpname).unlink(missing_ok=True);raise
    print(f'PATCHED APK HTML: {source} -> {output}; align and re-sign APK.')

def main():
    p=argparse.ArgumentParser();p.add_argument('--html',type=Path);p.add_argument('--apk',type=Path);p.add_argument('--output',type=Path);a=p.parse_args()
    if a.html and not a.apk and not a.output:
        src=a.html.read_text(encoding='utf-8');out=patch_html(src);a.html.write_text(out,encoding='utf-8',newline='');print(f'PATCHED HTML {a.html}: {len(src)} -> {len(out)} chars')
    elif a.apk and a.output and not a.html:patch_apk(a.apk,a.output)
    else:p.error('use --html PATH or --apk SOURCE.apk --output OUTPUT.apk')
if __name__=='__main__':main()
