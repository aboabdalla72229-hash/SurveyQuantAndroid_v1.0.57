#!/usr/bin/env python3
"""Patch the V164 Android HTML with V166 read-only viewer and exact PDF raster underlay."""
from __future__ import annotations
import argparse, base64, re
from pathlib import Path

META_V164 = '<meta name="surveyquant-v164-compat" content="sq164-cad-output-axis-fix">'
META = '<meta name="surveyquant-v166" content="sq166-readonly-source-and-exact-pdf-raster">'


def embed_engine(html: str, engine: bytes) -> str:
    pattern = r'(<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">)([A-Za-z0-9+/=\r\n]+)(</script>)'
    payload = base64.b64encode(engine).decode('ascii')
    html, count = re.subn(pattern, lambda m: m.group(1) + payload + m.group(3), html, count=1, flags=re.I)
    if count != 1:
        raise ValueError(f'Expected exactly one embedded CAD engine slot, found {count}')
    return html


def patch_dwg_worker(html: str) -> str:
    old_worker = "if(payload.wasmBinaryBuffer)self.SQ_DWG_WASM_BINARY=new Uint8Array(payload.wasmBinaryBuffer);importScripts(payload.wasmScriptUrl,payload.engineScriptUrl);const mod=self.SurveyQuantLibreDwg;"
    new_worker = "if(!payload.wasmBinaryBuffer||payload.wasmBinaryBuffer.byteLength<1000000)throw new Error(\"بيانات WASM المرسلة إلى عامل DWG غير مكتملة.\");self.SQ_DWG_WASM_BINARY=new Uint8Array(payload.wasmBinaryBuffer);importScripts(payload.wasmScriptUrl,payload.engineScriptUrl);const mod=self.SurveyQuantLibreDwg;"
    if html.count(old_worker) != 1:
        raise ValueError('Could not locate unique V164 DWG worker WASM bootstrap')
    html = html.replace(old_worker, new_worker, 1)
    old_transfer = 'payload.wasmBinaryBuffer=wasmBuffer;transfers.push(wasmBuffer);sqDwgWorkerWasmSent=true;'
    new_transfer = 'payload.wasmBinaryBuffer=wasmBuffer;sqDwgWorkerWasmSent=true;'
    if html.count(old_transfer) != 1:
        raise ValueError('Could not locate unique V164 WASM transfer list')
    html = html.replace(old_transfer, new_transfer, 1)
    old_parse = '  const workerModel=await sqParseDwgInWorker(file,90000,options);\n  if(workerModel)return workerModel;'
    new_parse = '''  let workerModel=null,workerReadError=null;
  try{workerModel=await sqParseDwgInWorker(file,90000,options);}catch(e){workerReadError=e;console.warn('SurveyQuant DWG worker failed; falling back to main-thread WASM reader.',e);}
  if(workerModel)return workerModel;'''
    if html.count(old_parse) != 1:
        raise ValueError('Could not locate unique V164 parseFile worker-first route')
    html = html.replace(old_parse, new_parse, 1)
    # Keep the worker error in diagnostics if the non-worker fallback also fails.
    marker = "const detail=conversionError||nativeReadError||new Error('تعذر قراءة DWG');"
    replacement = "const detail=conversionError||nativeReadError||workerReadError||new Error('تعذر قراءة DWG');"
    if html.count(marker) != 1:
        raise ValueError('Could not locate V164 DWG final error diagnostic')
    html = html.replace(marker, replacement, 1)
    html = html.replace('sqDwgWorkerWasmSent=true;', 'sqDwgWorkerWasmSent=true;/*sq166-wasm-clone-fallback*/', 1)
    return html


def patch_html(html: str, engine: bytes) -> str:
    if 'sq166-readonly-source-and-exact-pdf-raster' in html:
        raise ValueError('V166 patch already applied; refusing duplicate injection')
    for marker in ('function safeDownloadFile(', 'sqDownloadNameDialog', 'sq163-cad-engine', 'sq163RawCadOverlayMerge',
                   'sq163-pdfjs-worker', 'sqDownloadNameDialog', 'function safeDownloadFile(',
                   'window.Android.notifyDownload', 'sq162-wasm-binary'):
        if marker not in html:
            raise ValueError(f'Missing required V164 source marker: {marker}')
    html = patch_dwg_worker(html)
    head = re.search(r'<head\b[^>]*>', html, re.I)
    if not head:
        raise ValueError('HTML head tag not found')
    html = html[:head.end()] + META_V164 + META + html[head.end():]
    html = embed_engine(html, engine)
    validate(html, engine)
    return html


def validate(html: str, engine: bytes) -> None:
    for marker in (META, 'sq164-cad-output-axis-fix', 'sqDownloadNameDialog',
                   'const requestedName=await chooseDownloadFilename(',
                   'window.Android.saveFile(finalName,mime,base64)',
                   'window.Android.notifyDownload(finalName,String(result),mime)',
                   'sq163RawCadOverlayMerge', 'sq163-pdfjs-worker', 'sq162-wasm-binary',
                   'sq166-wasm-clone-fallback', 'workerReadError=e'):
        if marker not in html:
            raise ValueError('V166 app validation failed: ' + marker)
    if "window.prompt('اكتب اسم اللوحة / الملف المخرج:" in html:
        raise ValueError('Legacy output prompt remains')
    m = re.search(r'<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">([A-Za-z0-9+/=\r\n]+)</script>', html, re.I)
    if not m or base64.b64decode(m.group(1)) != engine:
        raise ValueError('Embedded V166 engine does not match tested engine file')
    text = engine.decode('utf-8')
    for marker in ('SQ_V166_SOURCE_VIEW_ONLY_AND_EXACT_PDF_RASTER_UNDERLAY',
                   'function ensurePdfWorker(lib,doc)', 'makeRasterUnderlayDxf(imageName,canvas.width,canvas.height,factor)',
                   'canvasPngBytes(canvas)', 'zipStore([{name:dxfName,data:dxfBytes},{name:imageName,data:pngBytes}])',
                   'state.pickStage = -1;', 'V166 read-only mode'):
        if marker not in text:
            raise ValueError('V166 engine required behavior is missing: ' + marker)
    if "el('sq162-do-align').addEventListener" in text:
        raise ValueError('Alignment/export handler remains in read-only viewer')
    if "const select=toolbar.querySelector('.sq162-snap-mode');select.addEventListener" in text:
        raise ValueError('Nullable toolbar control is not guarded')
    if 'ImageTracer.imagedataToSVG' in text:
        raise ValueError('PDF path still invokes ImageTracer vector tracing')


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument('--html', required=True, type=Path)
    p.add_argument('--engine', required=True, type=Path)
    p.add_argument('--check-only', action='store_true')
    a = p.parse_args()
    html = a.html.read_text(encoding='utf-8')
    engine = a.engine.read_bytes()
    if a.check_only:
        validate(html, engine)
        print('PASS V166 patch validation: V164 save bridge retained; DWG worker fallback and read-only viewer; PDF raster underlay embedded.')
        return
    out = patch_html(html, engine)
    a.html.write_text(out, encoding='utf-8')
    print(f'PASS V166 patch applied: {a.html} ({len(out):,} HTML chars; {len(engine):,} engine bytes)')

if __name__ == '__main__':
    main()
