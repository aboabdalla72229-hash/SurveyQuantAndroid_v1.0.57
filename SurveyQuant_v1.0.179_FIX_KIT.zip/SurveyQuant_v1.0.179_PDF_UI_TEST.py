#!/usr/bin/env python3
from pathlib import Path
import argparse,base64,subprocess,tempfile
from playwright.sync_api import sync_playwright
p=argparse.ArgumentParser()
p.add_argument('--engine',type=Path,required=True)
p.add_argument('--pdfjs',type=Path,required=True)
p.add_argument('--worker',type=Path,required=True)
p.add_argument('--pdf',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--browser',default='')
a=p.parse_args()
engine=a.engine.read_text(encoding='utf-8')
pdfjs=a.pdfjs.read_text(encoding='utf-8')
worker=base64.b64encode(a.worker.read_bytes()).decode('ascii')
html=f'''<!doctype html><html><head><meta charset="utf-8"><title>V179 PDF UI regression</title></head><body>
<div class="container"><div id="homeMenu"><div class="home-menu"></div></div></div>
<script>window.__nativeSaved=null;window.__notified=null;window.Android={{saveFile:(filename,mime,base64)=>{{window.__nativeSaved={{filename,mime,base64}};}},notifyDownload:(filename,path,mime)=>{{window.__notified={{filename,path,mime}};}}}};</script>
<script>{pdfjs}</script><script id="sq163-pdfjs-worker" type="application/octet-stream">{worker}</script>
<script>{engine}</script></body></html>'''
with sync_playwright() as q:
    launch={'headless':True,'args':['--no-sandbox']}
    if a.browser: launch['executable_path']=a.browser
    browser=q.chromium.launch(**launch)
    page=browser.new_page(viewport={'width':412,'height':900})
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(html,wait_until='domcontentloaded',timeout=30000)
    assert page.evaluate('!!window.SurveyQuantCAD179 && window.pdfjsLib.version==="3.11.174"')
    page.locator('#sq176-home-pdf-project').click()
    page.locator('#sq162-raster-file').set_input_files(str(a.pdf));page.wait_for_timeout(100)
    assert page.locator('#sq162-pdf-output-name').input_value()=='V179_ARCHITECTURAL_TEST'
    page.locator('#sq162-pdf-output-name').fill('OfficePlan_Walls_Columns')
    page.locator('#sq162-trace').click()
    page.wait_for_function('window.__nativeSaved!==null',timeout=30000)
    saved=page.evaluate('({saved:window.__nativeSaved,notified:window.__notified,status:document.getElementById("sq162-raster-status").textContent})')
    assert saved['saved']['filename']=='OfficePlan_Walls_Columns.dxf',saved
    assert saved['notified'],saved
    import re
    raw=base64.b64decode(saved['saved']['base64'])
    txt=raw.decode('cp1252',errors='replace')
    assert len(re.findall(r'\nPOLYLINE\r?\n',txt))>=5, saved['status']
    assert len(re.findall(r'\nTEXT\r?\n',txt))>=2, saved['status']
    assert 'C-LEVEL OFFICE' in txt
    assert not re.search(r'\nIMAGE(?:\r?\n|$)|\nIMAGEDEF(?:\r?\n|$)',txt)
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_bytes(raw)
    if errors: raise AssertionError('browser page errors: '+repr(errors))
    print('PASS V179 PDF UI: selected PDF -> explicit custom output name -> Android save bridge; 5 black wall/column outline polylines and 2 text entities retained; bytes='+str(len(raw)))
    print(saved['status'])
    browser.close()
