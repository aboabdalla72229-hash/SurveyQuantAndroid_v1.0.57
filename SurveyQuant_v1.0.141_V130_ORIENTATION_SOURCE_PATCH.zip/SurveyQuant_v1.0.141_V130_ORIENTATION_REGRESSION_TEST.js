'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const current = fs.readFileSync(process.argv[2], 'utf8');
const reference = fs.readFileSync(process.argv[3], 'utf8');
const ids = ['sq-orientation-module','sq-orientation-axis-reader-module','sq-orientation-manual-points-module','sq-orientation-reference-board-module','sq-orientation-dxf-faithful-recovery-module','sq-orientation-cad-preserve-module','sq-orientation-v115-tools-module'];
function body(html,id) {
  const re = new RegExp(`(<script\\b(?=[^>]*\\bid=["']${id}["'])[^>]*>)([\\s\\S]*?)(<\\/script\\s*>)`, 'i');
  const m = html.match(re);
  assert(m, `missing script ${id}`);
  assert.equal((html.match(new RegExp(`id=["']${id}["']`,'g'))||[]).length,1,`duplicate script ${id}`);
  return m[2];
}
for (const id of ids) assert.equal(body(current,id),body(reference,id),`not byte-identical to V130: ${id}`);
assert(current.includes('const SQ_APP_VERSION_CODE = 141;'),'version 141 constant missing');
assert(current.includes('id="sq-v117-universal-dwg-bridge"'),'universal DWG bridge missing');
assert(current.includes('function sqDwgWasmRuntimePath()'),'DWG WASM path helper missing');
assert(current.includes('id="surveyquant-v140-fresh-board-session"'),'fresh-session reset from V140 missing');
console.log('PASS V141: 7 orientation modules match V130 byte-for-byte.');
console.log('PASS V141: V140 universal DWG bridge, WASM helper, and fresh-board session cleanup remain.');
