#!/usr/bin/env python3
# Fail-closed V122 patch: projected CAD text scale plus DWG import.
from pathlib import Path
import re
import sys

BRIDGE_ID = 'sq-v122-universal-dwg-bridge'
OLD_FORMULAS = (
    "size=Math.max(5.5,Math.min(15,Math.abs(Number(t.height)||2.5)*m.scale));",
    "size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale);",
    "size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale*Math.max(0.001,Number(v.zoom)||1));",
)
NEW_EXPR = "sqV122NaturalTextPixels(v,t,m,p)"
HELPER = r'''function sqV122NaturalTextPixels(v,t,m,p){
 const raw=Number(t&&t.height),h=Number.isFinite(raw)&&raw!==0?Math.abs(raw):2.5;
 const anchor=t&&t.p;
 if(anchor&&Number.isFinite(Number(anchor.x))&&Number.isFinite(Number(anchor.y))&&typeof project==='function'){
  const shifted=Object.assign({},anchor,{y:Number(anchor.y)+h});
  const q=project(v,shifted,m),dx=Number(q&&q.x)-Number(p&&p.x),dy=Number(q&&q.y)-Number(p&&p.y);
  const px=Math.hypot(dx,dy);
  if(Number.isFinite(px))return px;
 }
 const scale=Math.abs(Number(m&&m.scale)||0),zoom=Math.abs(Number(v&&v.zoom)||1),fallback=h*scale*zoom;
 return Number.isFinite(fallback)?fallback:0;
}'''

if len(sys.argv) != 4:
    raise SystemExit("usage: SurveyQuant_v1.0.122_APPLY_PATCH.py REFERENCE_MODULE.js INDEX_PATH.html DWG_BRIDGE.js")
module_path,index_path,bridge_path=map(Path,sys.argv[1:])
bridge=bridge_path.read_text(encoding='utf-8')
required_bridge=["window.sqOriConvertTargetToDxf","ACCEPT_TYPES","MutationObserver","convertList","new DataTransfer()",r"/\.dwg$/i",r"/\.dxf$/i"]
missing=[x for x in required_bridge if x not in bridge]
if missing: raise SystemExit('ERROR: V122 DWG bridge missing: '+', '.join(missing))
if bridge.count(r"/\.dwg$/i") != 4:
    raise SystemExit(f"ERROR: expected four case-insensitive DWG extension matchers; got {bridge.count(r'/\.dwg$/i')}.")
if r"\\.dwg" in bridge: raise SystemExit('ERROR: double-escaped DWG extension matcher found.')

updated=[]
for path in (module_path,index_path):
    source=path.read_text(encoding='utf-8')
    old_count=sum(source.count(x) for x in OLD_FORMULAS)
    new_count=source.count('size='+NEW_EXPR)
    if new_count==1 and old_count==0:
        pass
    elif new_count==0 and old_count==1:
        for formula in OLD_FORMULAS:
            if formula in source:
                source=source.replace(formula,'size='+NEW_EXPR+';',1)
                break
    else:
        raise SystemExit(f'ERROR: {path.name}: expected one known old text formula or one V122 expression; old={old_count}, new={new_count}.')

    helper_count=source.count('function sqV122NaturalTextPixels(')
    if helper_count==0:
        anchor='function draw(v){'
        if source.count(anchor)!=1:
            raise SystemExit(f'ERROR: {path.name}: expected exactly one draw(v) anchor, found {source.count(anchor)}.')
        source=source.replace(anchor,HELPER+'\n'+anchor,1)
    elif helper_count!=1:
        raise SystemExit(f'ERROR: {path.name}: duplicate natural text-size helper ({helper_count}).')

    if 'function universalTransformBytes(input,t)' not in source:
        raise SystemExit(f'ERROR: {path.name}: byte-preserving CAD transform is missing.')
    if source.count('function sqV122NaturalTextPixels(')!=1 or source.count('size='+NEW_EXPR)!=1:
        raise SystemExit(f'ERROR: {path.name}: V122 natural text formula failed verification.')
    if any(x in source for x in OLD_FORMULAS):
        raise SystemExit(f'ERROR: {path.name}: fixed or legacy text-size formula remains.')
    updated.append((path,source))

html=updated[1][1]
pattern=re.compile(r'(<script id="'+re.escape(BRIDGE_ID)+r'">)[\s\S]*?(</script>)',re.I)
count=len(pattern.findall(html))
if count==1:
    html=pattern.sub(lambda m:m.group(1)+'\n'+bridge.rstrip()+'\n'+m.group(2),html,count=1)
elif count==0:
    if '</body>' not in html.lower(): raise SystemExit('ERROR: HTML body end not found; cannot install V122 DWG bridge.')
    html,n=re.subn(r'</body\s*>',lambda _:'<script id="'+BRIDGE_ID+'">\n'+bridge.rstrip()+'\n</script>\n</body>',html,count=1,flags=re.I)
    if n!=1: raise SystemExit('ERROR: could not inject V122 DWG bridge exactly once.')
else: raise SystemExit(f'ERROR: duplicate V122 bridge scripts found: {count}.')

for token,label in [
    ('function sqV122NaturalTextPixels(', 'natural text scale helper'),
    ('size='+NEW_EXPR, 'projected text scale expression'),
    ('function universalTransformBytes(input,t)', 'CAD transform function'),
    ('id="'+BRIDGE_ID+'"','DWG bridge integration'),
    ('window.sqOriConvertTargetToDxf','DWG converter integration')]:
    if token not in html: raise SystemExit('ERROR: final HTML verification failed: '+label)
if html.count('id="'+BRIDGE_ID+'"')!=1: raise SystemExit('ERROR: duplicate V122 bridge tag in final HTML.')

updated[0][0].write_text(updated[0][1],encoding='utf-8')
index_path.write_text(html,encoding='utf-8')
bridge_path.write_text(bridge,encoding='utf-8')
print('PASS: text pixel height is computed from the actual projected CAD height, not a fixed 5.5–15 px clamp.')
print('PASS: zoom/fit scale affect geometry and text through the same project() transform.')
print('PASS: DWG file pickers and drag/drop use the shared DWG-to-DXF converter.')
print('PASS: existing byte-preserving CAD transform remains intact; this patch does not rewrite source text heights or layers.')
