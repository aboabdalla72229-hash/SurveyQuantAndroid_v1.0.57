'use strict';
const assert=require('node:assert/strict');
let saveCalls=[];
global.safeDownloadFile=async (bytes,name,mime,autoOpen)=>{saveCalls.push({bytes:new Uint8Array(bytes),name,mime,autoOpen});return 'Downloads/SurveyQuant/'+name;};
const CAD=require('./SurveyQuant_v1.0.164_CAD_ENGINE.js');
const close=(a,b,eps=1e-7)=>assert.ok(Math.abs(a-b)<eps,`${a} != ${b}`);

// Two-point similarity transformation: 2x scale and +90 degrees.
const tr=CAD.solve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
close(tr.scale,2);close(tr.rotationDegrees,90);
const A=tr.apply({x:0,y:0}),B=tr.apply({x:10,y:0});
close(A.x,100);close(A.y,200);close(B.x,100);close(B.y,220);

const fixture=[
 '0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','0','ENDSEC',
 '0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','2',
 '0','LAYER','5','10','2','0','70','0','62','7','6','CONTINUOUS',
 '0','LAYER','5','11','2','AXIS_NAMES','70','0','62','3','420','16711680','6','DASHED','0','ENDTAB','0','ENDSEC',
 '0','SECTION','2','ENTITIES',
 '0','LINE','5','20','100','AcDbEntity','8','AXIS_NAMES','62','3','420','16711680','100','AcDbLine','10','0','20','0','11','10','21','0',
 '0','TEXT','5','21','8','AXIS_NAMES','62','3','420','16711680','10','5','20','5','40','2','50','0','1','GRID-A',
 '0','MTEXT','5','22','8','AXIS_NAMES','62','4','10','6','20','6','40','1.5','3','NORTH','1','\\PGRID',
 '0','ENDSEC','0','EOF',''
].join('\r\n');
const input=new TextEncoder().encode(fixture);
const geometry=CAD.readGeometry(input);
assert.ok(geometry.segments.length>=1,'line geometry is loaded');
assert.equal(geometry.texts.length,2,'TEXT and MTEXT axis labels are loaded');
assert.equal(geometry.texts[0].text,'GRID-A');
assert.equal(geometry.texts[0].layer,'AXIS_NAMES');
assert.equal(geometry.texts[0].color,'#ff0000','true color is represented on preview labels');
assert.equal(geometry.texts[1].text,'NORTH GRID','MTEXT chunks are joined in record order and paragraph markers are readable');

const aligned=CAD.transformDxfBytes(input,{x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
const out=new TextDecoder('windows-1252').decode(aligned.bytes);
assert.ok(out.includes('1\r\nGRID-A'),'axis name text stays byte content-identical');
assert.ok(out.includes('3\r\nNORTH\r\n1\r\n\\PGRID'),'MTEXT chunk text stays intact');
assert.ok(out.includes('8\r\nAXIS_NAMES'),'axis layer name remains unchanged');
assert.ok(out.includes('62\r\n3'),'ACI layer/entity color remains unchanged');
assert.ok(out.includes('420\r\n16711680'),'true color remains unchanged');
assert.ok(out.includes('2\r\nAXIS_NAMES\r\n70\r\n0\r\n62\r\n3'),'layer table entry and color remain unchanged');
assert.ok(out.includes('10\r\n90\r\n20\r\n210'),'text anchor is transformed, not recreated');
assert.ok(aligned.editCount>=10,'coordinate, height and rotation values are edited');

// Text stored inside a block definition is displayed after INSERT transform.
const blockFixture=[
 '0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','0','ENDSEC',
 '0','SECTION','2','BLOCKS',
 '0','BLOCK','5','30','2','AXIS_LABEL_BLOCK','70','0','10','0','20','0',
 '0','LINE','8','0','10','0','20','0','11','10','21','0',
 '0','TEXT','8','0','10','2','20','1','40','3','1','GRID-B','0','ENDBLK','8','0',
 '0','ENDSEC','0','SECTION','2','ENTITIES',
 '0','INSERT','8','AXIS_NAMES','2','AXIS_LABEL_BLOCK','10','100','20','200','41','2','42','2','50','90',
 '0','ENDSEC','0','EOF',''
].join('\n');
const blockGeom=CAD.readGeometry(new TextEncoder().encode(blockFixture));
assert.equal(blockGeom.texts.length,1,'text inside block is expanded into preview');
assert.equal(blockGeom.texts[0].text,'GRID-B');
assert.equal(blockGeom.texts[0].layer,'AXIS_NAMES','layer 0 text inherits its INSERT layer in preview');
close(blockGeom.texts[0].position.x,98);close(blockGeom.texts[0].position.y,204);
close(blockGeom.texts[0].rotation,90);close(blockGeom.texts[0].height,6);

// Existing intersection snap logic remains available with text-aware geometry.
const cross={segments:[{a:{x:0,y:5},b:{x:10,y:5}},{a:{x:5,y:0},b:{x:5,y:10}}],points:[],texts:[]};
const snap=CAD.snapPoint(cross,{x:5.1,y:5.1},'intersection',0.5);
assert.equal(snap.type,'intersection');close(snap.point.x,5);close(snap.point.y,5);
let degenerate=false;try{CAD.solve({x:1,y:1},{x:1,y:1},{x:0,y:0},{x:2,y:2});}catch(_){degenerate=true;}assert.ok(degenerate);

// Alignment and raster output must route through the Android-aware save helper.
(async()=>{
 const fileBytes=new TextEncoder().encode('0\nEOF\n');
 const saved=await CAD.downloadBytes(fileBytes,'AlignedBoard.dxf','application/dxf');
 assert.equal(saved,'Downloads/SurveyQuant/AlignedBoard.dxf');
 assert.equal(saveCalls.length,1);assert.equal(saveCalls[0].name,'AlignedBoard.dxf');assert.equal(saveCalls[0].mime,'application/dxf');
 console.log('PASS V164 CAD tests: point-pair transform; original layer/ACI/true-color/text records preserved; TEXT/MTEXT labels visible; block-insert labels transformed; intersection snap; output passed to Android save/notification bridge.');
})().catch(e=>{console.error(e);process.exit(1);});
