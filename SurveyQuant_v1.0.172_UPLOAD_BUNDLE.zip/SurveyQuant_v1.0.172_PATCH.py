#!/usr/bin/env python3
from __future__ import annotations
import argparse, base64, re
from pathlib import Path

META = '<meta name="surveyquant-v172" content="sq172-static-visible-home-project-shortcuts-pdf-image-pair">'
STYLE = r'''<style id="sq172-home-shortcuts-visibility">
#homeMenu .home-menu > #sq172-home-orientation-project,
#homeMenu .home-menu > #sq172-home-pdf-project {display:block!important;visibility:visible!important;opacity:1!important;}
</style>'''
BUTTONS = r'''<button id="sq172-home-orientation-project" class="menu-btn primary" type="button" onclick="window.sq172OpenCadProject('align')">📐 9 مشروع توجيه اللوحات</button>
<button id="sq172-home-pdf-project" class="menu-btn" type="button" onclick="window.sq172OpenCadProject('raster')">📄 10 مشروع تحويل PDF إلى DXF</button>'''
HELPER = r'''<script id="sq172-home-shortcuts-handler">
(function(){
  'use strict';
  window.sq172OpenCadProject=function(tabName){
    var open=function(){
      var launch=document.getElementById('sq162-cad-launch');
      var overlay=document.getElementById('sq162-cad-overlay');
      if(!launch||!overlay)return false;
      overlay.style.display='flex';
      var tab=overlay.querySelector('[data-tab="'+tabName+'"]');
      if(tab)tab.click();
      return true;
    };
    if(open())return;
    var onReady=function(){if(!open())window.alert('تعذر فتح المشروع. أغلق التطبيق وافتحه مرة أخرى.');};
    window.addEventListener('surveyquant-cad-ready',onReady,{once:true});
    window.setTimeout(function(){
      window.removeEventListener('surveyquant-cad-ready',onReady);
      if(!document.getElementById('sq162-cad-overlay'))window.alert('محرك المشروع لم يكتمل تشغيله. راجع ملفات التطبيق ثم أعد فتحه.');
    },15000);
  };
})();
</script>'''
SLOT = re.compile(r'(<script\s+type="application/octet-stream"\s+id="sq163-cad-engine">)([A-Za-z0-9+/=\r\n]+)(</script>)', re.I)
OLD_DROP = '<button class="menu-btn" onclick="openProjectPage(\'dropFilesCard\')" type="button">📥 8 إسقاط الملفات</button>'


def patch_html(html: str, engine: bytes) -> str:
    if 'sq170-orientation-canvas-zoom-per-board-picks-snap-wasm-binary-pdf-worker-ole-reader' not in html:
        raise ValueError('V170 baseline is required')
    if 'sq172-static-visible-home-project-shortcuts-pdf-image-pair' in html:
        raise ValueError('V172 already applied')
    if html.count(OLD_DROP) != 1:
        raise ValueError('Could not uniquely locate the original eight-project home menu')
    html = html.replace(OLD_DROP, OLD_DROP + '\n' + BUTTONS, 1)
    head = re.search(r'<head\b[^>]*>', html, re.I)
    if not head:
        raise ValueError('HTML head missing')
    html = html[:head.end()] + META + STYLE + html[head.end():]
    runtime = '<script id="sq163-runtime-bootstrap">'
    if html.count(runtime) != 1:
        raise ValueError('Runtime bootstrap insertion point is not unique')
    html = html.replace(runtime, HELPER + '\n' + runtime, 1)
    data = base64.b64encode(engine).decode('ascii')
    html, n = SLOT.subn(lambda m: m.group(1) + data + m.group(3), html, count=1)
    if n != 1:
        raise ValueError(f'Expected exactly one CAD engine payload slot, found {n}')
    validate(html, engine)
    return html


def validate(html: str, engine: bytes) -> None:
    required = [
        'sq170-orientation-canvas-zoom-per-board-picks-snap-wasm-binary-pdf-worker-ole-reader',
        'sq172-static-visible-home-project-shortcuts-pdf-image-pair', 'sq163-pdfjs-worker', 'sq162-wasm-binary',
        'id="project1Card"', 'id="dropFilesCard"', 'onclick="openProjectPage(\'project1Card\')"',
        'onclick="openProjectPage(\'dropFilesCard\')"', 'id="sq172-home-orientation-project"',
        'id="sq172-home-pdf-project"', "sq172OpenCadProject('align')", "sq172OpenCadProject('raster')",
        'display:block!important', 'surveyquant-cad-ready'
    ]
    for marker in required:
        if marker not in html:
            raise ValueError('V172 HTML missing required marker: ' + marker)
    menu = re.search(r'<div class="home-menu">([\s\S]*?)</div>', html, re.I)
    if not menu:
        raise ValueError('Home project grid missing')
    ids = re.findall(r'<button\b[^>]*\bid="([^"]+)"', menu.group(1), re.I)
    if ids.count('sq172-home-orientation-project') != 1 or ids.count('sq172-home-pdf-project') != 1:
        raise ValueError('The two new home projects are not static direct children of homeMenu')
    if len(re.findall(r'<button\b', menu.group(1), re.I)) != 10:
        raise ValueError('Expected exactly ten visible home project buttons (8 existing + 2 new)')
    m = SLOT.search(html)
    if not m or base64.b64decode(m.group(2)) != engine:
        raise ValueError('Embedded CAD engine differs from tested V172 engine')
    for marker in (
        'SQ_V170_ORIENTATION_VIEWPORT_PER_BOARD_PICK_SNAP_AXES_EXTENTS_AND_PDF_WORKER',
        'function makeRasterUnderlayDxf', 'function downloadPairedRasterFile', 'IMAGEDEF',
        'sq-home-orientation-project', 'sq-home-pdf-project', 'IMAGE/IMAGEDEF القياسي بدل OLE2FRAME'
    ):
        if marker not in engine.decode('utf-8'):
            raise ValueError('V172 engine missing behaviour: ' + marker)
    if 'تم إخراج ملف DXF واحد فقط' in engine.decode('utf-8'):
        raise ValueError('Old OLE-only PDF export remains')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--html', type=Path, required=True)
    ap.add_argument('--engine', type=Path, required=True)
    ap.add_argument('--check-only', action='store_true')
    a = ap.parse_args()
    html = a.html.read_text(encoding='utf-8')
    engine = a.engine.read_bytes()
    if a.check_only:
        validate(html, engine)
        print('PASS V172: ten static home shortcuts and exact embedded engine')
        return
    out = patch_html(html, engine)
    a.html.write_text(out, encoding='utf-8')
    print(f'PASS V172 patch applied: {a.html} ({len(out):,} HTML chars)')


if __name__ == '__main__':
    main()
