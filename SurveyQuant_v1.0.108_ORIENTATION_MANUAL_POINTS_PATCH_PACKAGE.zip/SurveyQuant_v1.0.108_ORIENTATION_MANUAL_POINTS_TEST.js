'use strict';
const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const manualPath = process.argv[2];
const enginePath = process.argv[3];
assert(manualPath && enginePath, 'usage: test.js manual-module.js orientation-engine.js');
const document = {readyState:'loading',addEventListener(){}};
const window = {addEventListener(){}};
const ctx = {window,document,TextEncoder,Uint8Array,Math,Number,String,Map,Set,Array,Object,RegExp,Error,Infinity,Promise};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(enginePath,'utf8'),ctx,{filename:'orientation-engine.js'});
vm.runInContext(fs.readFileSync(manualPath,'utf8'),ctx,{filename:'manual-points.js'});
const api = window.__sqManualOrientation108;
assert(api && api.VERSION==='1.0.108','manual-points module did not initialize');
const dxf = [
'0','SECTION','2','ENTITIES',
'0','LINE','8','0','10','0','20','0','30','0','11','100','21','0','31','0',
'0','LINE','8','0','10','0','20','0','11','0','21','100',
'0','POINT','8','0','10','20','20','30',
'0','ENDSEC','0','EOF',''
].join('\n');
const bytes = new TextEncoder().encode(dxf);
const drawing = api.parseDrawing(bytes);
assert(drawing.segs.length >= 2,'preview parser did not read linework');
assert(drawing.anchors.some(p=>Math.abs(p.x-100)<1e-8&&Math.abs(p.y)<1e-8),'source CAD endpoint missing');
const src1={x:0,y:0},src2={x:100,y:0},known1={x:500,y:600},known2={x:500,y:800};
const t=api.solve(known1,known2,src1,src2);
const q1=t.point(src1.x,src1.y),q2=t.point(src2.x,src2.y),q3=t.point(0,100);
assert(Math.hypot(q1.x-known1.x,q1.y-known1.y)<1e-8,'point 1 does not align');
assert(Math.hypot(q2.x-known2.x,q2.y-known2.y)<1e-8,'point 2 does not align');
assert(Math.abs(q3.x-300)<1e-8&&Math.abs(q3.y-600)<1e-8,'rotation/translation/scale is incorrect');
const result=window.__sqOrientTest.transformBytes(bytes,t);
assert(result.bytes && result.bytes.length>bytes.length-10,'transform did not return a DXF byte buffer');
const output=Buffer.from(result.bytes).toString('ascii');
assert(output.includes('500') && output.includes('800'),'transformed anchor coordinates not written');
const source=fs.readFileSync(manualPath,'utf8');
assert(source.includes("window.safeDownloadFile(result.bytes"),'Android-safe download helper is not used');
assert(source.includes('sq108Canvas') && source.includes('sq108P1X') && source.includes('sq108P2Y'),'two-point pick UI missing');
console.log('PASS: DXF preview parsing, two-point click/known-coordinate similarity transform, byte-preserving DXF output and Android safeDownloadFile integration.');
