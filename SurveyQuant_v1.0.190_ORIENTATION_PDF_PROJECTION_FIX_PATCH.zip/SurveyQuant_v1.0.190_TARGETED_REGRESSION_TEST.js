'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const cad=require('./SurveyQuant_v1.0.177_CAD_ENGINE.js');
const enc=new TextEncoder();
const dec=new TextDecoder('windows-1252');
// Regression 1: group 340 value 0 is an intentional null pointer, not an unresolved external handle.
const target=cad.polylinesToDxf([{points:[{x:0,y:0},{x:100,y:0}],closed:false,aci:7}],128,128,1).bytes;
let sourceText=dec.decode(cad.polylinesToDxf([{points:[{x:10,y:10},{x:20,y:20}],closed:false,aci:5}],128,128,1).bytes);
sourceText=sourceText.replace(/(0\r?\nLWPOLYLINE\r?\n)/, '$1340\r\n0\r\n');
const source=enc.encode(sourceText);
const merged=cad.mergeRawDxfBoards(target,source);
assert.ok(merged.importedEntities>=1);
assert.match(dec.decode(merged.bytes),/340\r?\n0\r?\n/,'DXF null pointer must remain zero after merge');
// A nonzero unknown hard pointer remains a fail-closed condition.
const bad=enc.encode(sourceText.replace(/340\r?\n0\r?\n/,'340\r\nABCDEF\r\n'));
assert.throws(()=>cad.mergeRawDxfBoards(target,bad),/مقبض خارجي ABCDEF/);
// Regression 2: a convex even-odd clip must clip strokes and fills to the clip boundary.
const OPS={save:1,restore:2,transform:3,setStrokeRGBColor:4,setFillRGBColor:5,setLineWidth:6,constructPath:7,moveTo:8,lineTo:9,curveTo:10,curveTo2:11,curveTo3:12,closePath:13,rectangle:14,stroke:15,closeStroke:16,fill:17,eoFill:18,fillStroke:19,eoFillStroke:20,closeFillStroke:21,closeEOFillStroke:22,endPath:23,clip:24,eoClip:25};
const ops=[OPS.constructPath,OPS.eoClip,OPS.moveTo,OPS.lineTo,OPS.stroke,OPS.constructPath,OPS.closePath,OPS.fill];
const args=[[[OPS.rectangle],[0,0,10,10]],[],[-5,5],[15,5],[],[[OPS.moveTo,OPS.lineTo,OPS.lineTo,OPS.lineTo,OPS.closePath],[-5,-5,15,-5,15,15,-5,15]],[],[]];
// Use a fresh and explicit operator list with a simple filled polygon crossing the clip boundary.
const fnArray=[OPS.constructPath,OPS.eoClip,OPS.moveTo,OPS.lineTo,OPS.stroke,OPS.moveTo,OPS.lineTo,OPS.lineTo,OPS.lineTo,OPS.closePath,OPS.fill];
const argsArray=[[[OPS.rectangle],[0,0,10,10]],[],[-5,5],[15,5],[],[-5,-5],[15,-5],[15,15],[-5,15],[],[]];
const page={getOperatorList:async()=>({fnArray,argsArray})};
const viewport={convertToViewportPoint:(x,y)=>[x,y]};
(async()=>{
 const paths=await cad.pdfOperatorPathsToCad(page,{OPS},viewport);
 const strokes=paths.filter(p=>!p.filled),fills=paths.filter(p=>p.filled);
 assert.equal(strokes.length,1,'crossing stroke should remain as one clipped fragment');
 assert.deepEqual(strokes[0].points.map(p=>[Number((Math.abs(p.x)<1e-8?0:p.x).toFixed(6)),Number(p.y.toFixed(6))]),[[0,5],[10,5]]);
 assert.equal(fills.length,1,'filled polygon should remain present');
 assert.ok(fills[0].points.every(p=>p.x>=-1e-7&&p.x<=10+1e-7&&p.y>=-1e-7&&p.y<=10+1e-7),'filled result must stay within clip polygon');
 assert.equal(fills[0].points.length,4,'clipped outside rectangle should resolve to four clip corners');
 const outsidePage={getOperatorList:async()=>({fnArray:[OPS.constructPath,OPS.eoClip,OPS.moveTo,OPS.lineTo,OPS.stroke],argsArray:[[[OPS.rectangle],[0,0,10,10]],[],[20,20],[30,30],[]]})};
 const outside=await cad.pdfOperatorPathsToCad(outsidePage,{OPS},viewport);assert.equal(outside.length,0,'empty intersection must not leak geometry outside the clip');
 // Non-convex clipping boundaries must remain safely rejected.
 const badPage={getOperatorList:async()=>({fnArray:[OPS.constructPath,OPS.eoClip],argsArray:[[[OPS.moveTo,OPS.lineTo,OPS.lineTo,OPS.lineTo,OPS.lineTo,OPS.closePath],[0,0,10,0,5,4,10,10,0,10]],[]]})};
 await assert.rejects(()=>cad.pdfOperatorPathsToCad(badPage,{OPS},viewport),/غير محدب/);
 // Regression 3: screen coordinates must be normalized when the displayed canvas rectangle is CSS-scaled.
const pointer=cad.canvasPointerToMap({left:10,top:20,width:600,height:400},{width:300,height:200},310,220);
assert.deepEqual(pointer,{x:150,y:100});
const roundTrip={x:150,y:100};assert.ok(Math.hypot(roundTrip.x-pointer.x,roundTrip.y-pointer.y)<1e-9);
// Orientation transform maps the picked source pair onto the picked reference pair exactly.
 const picks=[{x:100,y:200},{x:110,y:200},{x:1000,y:2000},{x:1000,y:2020}];
 const d=cad.alignmentDiagnostics(picks);
 assert.ok(Math.abs(d.rotationDegrees-90)<1e-8);
 assert.ok(Math.abs(d.scale-2)<1e-8);
 assert.ok(d.residualA<1e-8&&d.residualB<1e-8);
 console.log(JSON.stringify({null340Pointer:'PASS',nonzeroExternalHandleStillRejected:'PASS',pdfEoClipStroke:'PASS',pdfEoClipFill:'PASS',emptyClipProducesNoGeometry:'PASS',nonConvexClipFailsClosed:'PASS',orientationPairFit:'PASS',scaledCanvasPointer:'PASS',rotationDegrees:d.rotationDegrees,scale:d.scale,result:'PASS'},null,2));
})().catch(e=>{console.error(e);process.exit(1);});
