#!/usr/bin/env python3
"""Build V121 using the historical V116 CAD builder, adding only V121 fixes.

The immutable V116 build recipe is loaded from Git history. This adapter changes
release labels/version numbers and inserts the V121 text/DWG patch before the
historical verification, signing, and APK packaging steps.
"""
from pathlib import Path
import os
import re
import subprocess
import sys

BASE_SHA = "865d4bf0e15f39145f9f76c664ff83633083d026"
BASE_PATH = ".github/workflows/build-v116-orientation-full-fidelity.yml"


def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise SystemExit(f"ERROR: {label}: expected one anchor, found {count}.")
    return source.replace(old, new, 1)


def transformed_builder() -> str:
    workspace = os.environ.get("GITHUB_WORKSPACE")
    if not workspace:
        raise SystemExit("ERROR: GITHUB_WORKSPACE is missing; run this recipe inside GitHub Actions.")
    raw = subprocess.check_output(
        ["git", "show", f"{BASE_SHA}:{BASE_PATH}"],
        cwd=workspace, text=True, encoding="utf-8"
    )

    source = raw.replace("v1.0.116", "v1.0.121")
    source = source.replace("1.0.116", "1.0.121")
    source = source.replace("v116", "v121").replace("V116", "V121")
    source = source.replace("r'\\g<1>116'", "r'\\g<1>121'")
    source = source.replace("versionCode[[:space:]]+116", "versionCode[[:space:]]+121")
    source = source.replace("1\\.0\\.116", "1\\.0\\.121")
    source = source.replace("Failed to set HTML app version code to 115.", "Failed to set HTML app version code to 121.")
    source = source.replace("SQ_APP_VERSION_CODE = 116;", "SQ_APP_VERSION_CODE = 121;")
    source = source.replace(
        "SurveyQuant_v1.0.121_CAD_FIDELITY_ORIENTATION_FIX.apk",
        "SurveyQuant_v1.0.121_DWG_TEXT_SCALE_IMPORT_FIX.apk"
    )
    source = source.replace(
        "SurveyQuant_v1.0.121_CAD_FIDELITY_SOURCE_PATCH.zip",
        "SurveyQuant_v1.0.121_DWG_TEXT_SCALE_SOURCE_PATCH.zip"
    )
    source = source.replace(
        "SurveyQuant-v1.0.121-CAD-FIDELITY-ORIENTATION-FIX",
        "SurveyQuant-v1.0.121-DWG-TEXT-SCALE-IMPORT-FIX"
    )

    source = replace_once(
        source,
        '      - ".github/workflows/build-v121-orientation-full-fidelity.yml"',
        '      - ".github/workflows/build-v121-dwg-text-scale-import.yml"',
        "V121 workflow path"
    )
    source = replace_once(
        source,
        '      - "SurveyQuant_v1.0.115_ORIENTATION_FINAL_PATCH_PACKAGE.zip"\n',
        '      - "SurveyQuant_v1.0.115_ORIENTATION_FINAL_PATCH_PACKAGE.zip"\n'
        '      - "SurveyQuant_v1.0.121_DWG_TEXT_SCALE_IMPORT_FIX.zip"\n',
        "V121 ZIP push trigger"
    )

    injected_step = '''      - name: Apply V121 proportional CAD text and universal DWG import
        shell: bash
        run: |
          set -euo pipefail
          test -n "${V121_PATCHER:-}" || { echo "ERROR: V121 patcher path is missing."; exit 1; }
          test -n "${V121_TEST:-}" || { echo "ERROR: V121 test path is missing."; exit 1; }
          test -n "${V121_BRIDGE:-}" || { echo "ERROR: V121 DWG bridge path is missing."; exit 1; }
          python3 "$V121_PATCHER" "$REFERENCE_MODULE" "$INDEX_PATH" "$V121_BRIDGE"
          node --check "$V121_BRIDGE"
          node "$V121_TEST" "$REFERENCE_MODULE" "$INDEX_PATH" "$V121_BRIDGE"
          grep -Fq 'const SQ_APP_VERSION_CODE = 121;' "$INDEX_PATH"

'''
    source = replace_once(
        source,
        '          mkdir -p "$RELEASE/source-patch"\n',
        '          mkdir -p "$RELEASE/source-patch"\n'
        '          cp "$V121_PATCHER" "$RELEASE/source-patch/SurveyQuant_v1.0.121_APPLY_PATCH.py"\n'
        '          cp "$V121_BRIDGE" "$RELEASE/source-patch/SurveyQuant_v1.0.121_DWG_IMPORT_BRIDGE.js"\n'
        '          cp "$V121_TEST" "$RELEASE/source-patch/SurveyQuant_v1.0.121_DWG_TEXT_SCALE_TEST.js"\n',
        "include V121 patch sources in the final source bundle"
    )

    source = replace_once(
        source,
        "      - name: Verify original projects and CAD orientation integration\n",
        injected_step + "      - name: Verify original projects and CAD orientation integration\n",
        "insert V121 patch before historical integration checks"
    )

    required = [
        "name: Build SurveyQuant v1.0.121",
        '      - ".github/workflows/build-v121-dwg-text-scale-import.yml"',
        'python3 "$V121_PATCHER" "$REFERENCE_MODULE" "$INDEX_PATH" "$V121_BRIDGE"',
        'const SQ_APP_VERSION_CODE = 121;',
        "gradle --no-daemon clean assembleRelease --stacktrace",
        "actions/upload-artifact@v4",
        "SurveyQuant_v1.0.121_DWG_TEXT_SCALE_IMPORT_FIX.apk",
        "SurveyQuant_v1.0.121_DWG_TEXT_SCALE_SOURCE_PATCH.zip",
        "function universalTransformBytes(input,t)",
    ]
    missing = [token for token in required if token not in source]
    if missing:
        raise SystemExit("ERROR: transformed V121 recipe failed validation: " + ", ".join(missing))
    return source


def resolve_expressions(value: str, shell_script: bool = False) -> str:
    pattern = re.compile(r"\$\{\{\s*(.*?)\s*\}\}")

    def replacement(match: re.Match) -> str:
        expr = match.group(1).strip()
        if expr == "runner.temp":
            return os.environ.get("RUNNER_TEMP", "/tmp")
        if expr == "github.run_id":
            return os.environ.get("GITHUB_RUN_ID", "0")
        if expr == "github.token":
            return "$GH_TOKEN" if shell_script else os.environ.get("GH_TOKEN", "")
        if expr.startswith("secrets."):
            key = expr.split(".", 1)[1]
            return "$" + key if shell_script else os.environ.get(key, "")
        if expr.startswith("env."):
            key = expr.split(".", 1)[1]
            return "$" + key if shell_script else os.environ.get(key, "")
        raise SystemExit(f"ERROR: unhandled Actions expression in historical run step: ${{{{ {expr} }}}}")
    return pattern.sub(replacement, value)


def load_github_env() -> None:
    path = os.environ.get("GITHUB_ENV")
    if not path or not Path(path).exists():
        return
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if "=" in line and not line.startswith("<<"):
            key, value = line.split("=", 1)
            if key and "\n" not in key:
                os.environ[key] = value


def load_github_path() -> None:
    path = os.environ.get("GITHUB_PATH")
    if not path or not Path(path).exists():
        return
    entries = [x for x in Path(path).read_text(encoding="utf-8").splitlines() if x]
    current = os.environ.get("PATH", "").split(os.pathsep)
    for entry in reversed(entries):
        if entry not in current:
            current.insert(0, entry)
    os.environ["PATH"] = os.pathsep.join(current)


def main() -> int:
    try:
        import yaml
    except ImportError:
        raise SystemExit("ERROR: PyYAML is required. Install python3-yaml before running this recipe.")

    source = transformed_builder()
    data = yaml.safe_load(source)
    steps = data.get("jobs", {}).get("build", {}).get("steps", [])
    run_steps = [step for step in steps if isinstance(step, dict) and isinstance(step.get("run"), str)]
    if len(run_steps) < 12:
        raise SystemExit(f"ERROR: historical build recipe appears incomplete ({len(run_steps)} run steps).")

    print(f"V121: validated the historical V116 CAD builder; executing {len(run_steps)} shell steps.", flush=True)
    for idx, step in enumerate(run_steps, 1):
        name = str(step.get("name", f"historical run step {idx}"))
        raw_script = resolve_expressions(step["run"], shell_script=True)
        step_env = os.environ.copy()
        for key, raw_value in (step.get("env") or {}).items():
            if not isinstance(raw_value, str):
                step_env[key] = str(raw_value)
                continue
            value = raw_value.strip()
            match = re.fullmatch(r"\$\{\{\s*secrets\.([A-Za-z_][A-Za-z0-9_]*)\s*\}\}", value)
            if match:
                step_env[key] = step_env.get(match.group(1), "")
            else:
                step_env[key] = resolve_expressions(raw_value, shell_script=False)

        workdir = step.get("working-directory")
        if workdir:
            workdir = os.path.expandvars(resolve_expressions(str(workdir), shell_script=False))
            cwd = Path(workdir)
            if not cwd.is_absolute():
                cwd = Path(workspace) / cwd
        else:
            cwd = Path(workspace)

        print(f"::group::V121 recipe step {idx}/{len(run_steps)}: {name}", flush=True)
        result = subprocess.run(
            ["bash", "--noprofile", "--norc", "-e", "-o", "pipefail", "-c", raw_script],
            cwd=str(cwd), env=step_env, check=False
        )
        print("::endgroup::", flush=True)
        if result.returncode:
            print(f"ERROR: historical step failed ({result.returncode}): {name}", file=sys.stderr, flush=True)
            return result.returncode
        load_github_env()
        load_github_path()

    print("PASS: all V121 historical shell steps completed. Check the uploaded artifact for the signed APK.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
