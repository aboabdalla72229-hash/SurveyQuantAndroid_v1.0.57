from pathlib import Path
import re, hashlib, shutil, zipfile, subprocess, json, os, argparse
ap=argparse.ArgumentParser()
ap.add_argument('--input-html', type=Path, required=True)
ap.add_argument('--output-html', type=Path, required=True)
ap.add_argument('--report', type=Path, required=True)
args=ap.parse_args()
src=args.input_html
out=args.output_html
out.parent.mkdir(parents=True,exist_ok=True)
s=src.read_text(encoding='utf-8')
changes=[]
def rep(old,new,label,count=1):
 global s
 n=s.count(old)
 if n!=count: raise RuntimeError(f'{label}: expected {count} matches, found {n}')
 s=s.replace(old,new,count)
 changes.append({'label':label,'count':n})

# Version and per-session tag
rep('const SQ_APP_VERSION_CODE = 147;','const SQ_APP_VERSION_CODE = 148;','version-code')
rep('surveyquant-v146-fresh-board-session','surveyquant-v148-fresh-board-session','session-guard-id')

# Make orientation UI a little shorter on phone screens, without restricting CAD fit/zoom.
rep('height:56vh;min-height:360px;max-height:640px','height:44vh;min-height:250px;max-height:500px','orientation-canvas-height',2)

# DWG conversion inside the orientation screen must use the same local WASM runtime path as parseFile().
rep('const lib=await LibreDwg.create();','const lib=await LibreDwg.create(sqDwgWasmRuntimePath());','orientation-DWG-runtime-path')
rep('''  const converted=lib.dwg_write_dxf(bytes.buffer);
  if(!converted||!converted.length)throw new Error('فشل تحويل اللوحة DWG إلى DXF. الملف الأصلي لم يتغير.');
  const out=converted instanceof Uint8Array?converted:new Uint8Array(converted);
  return {bytes:out,name:targetFile.name.replace(/\\.dwg$/i,'.dxf')};''', '''  const converted=lib.dwg_write_dxf(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
  const out=sqValidateDwgConversion(converted);
  return {bytes:out,name:targetFile.name.replace(/\\.dwg$/i,'.dxf')};''','orientation-DWG-buffer-validation')

# Correct the min-world-Z scan: DIMENSION mixes WCS and OCS points; IMAGE/WIPEOUT vectors and clip coordinates are not positions.
start=s.index(' function sq145MinWorldZ(records,numeric){')
end=s.index('\n function sq145InsertPair', start)
new_min=''' function sq145MinWorldZ(records,numeric){
  let minZ=Infinity;
  const ocsTypes=new Set(['POINT','CIRCLE','ARC','INSERT','TEXT','ATTRIB','ATTDEF','MTEXT','SOLID','TRACE','LWPOLYLINE','POLYLINE','HATCH','LEADER','DIMENSION','SHAPE','VIEWPORT']);
  const visit=(x,y,z,useOcs,basis)=>{if(!Number.isFinite(x)||!Number.isFinite(y)||!Number.isFinite(z))return;const p=useOcs?sq145ToWorld({x,y,z},basis):{x,y,z};if(Number.isFinite(p.z))minZ=Math.min(minZ,p.z);};
  const visitCodes=(by,codes,useOcs,basis,value)=>{
    for(const xc of codes){const xs=by.get(xc)||[],ys=by.get(xc+10)||[],zs=by.get(xc+20)||[];for(let i=0;i<Math.min(xs.length,ys.length);i++){const x=numeric(xs[i].value),y=numeric(ys[i].value),z=zs[i]?numeric(zs[i].value):0;visit(x,y,z==null?0:z,useOcs,basis);}}
  };
  for(const rec of records||[]){
   const by=new Map();for(const p of rec.pairs||[]){if(!by.has(p.code))by.set(p.code,[]);by.get(p.code).push(p);}
   const value=(code,i=0,fallback=null)=>{const p=(by.get(code)||[])[i];return p?numeric(p.value):fallback;};
   const type=rec.type,flag=Number(value(70,0,0))||0,poly3d=type==='POLYLINE'&&(flag&8)!==0;
   const normal=sq145Norm3({x:value(210,0,0)??0,y:value(220,0,0)??0,z:value(230,0,1)??1}),basis=sq145Basis(normal);
   if(type==='DIMENSION'){
     // DXF DIMENSION group codes are mixed spaces: 10/13/14/15 are WCS, 11/12/16 are OCS.
     visitCodes(by,[10,13,14,15],false,basis,value);visitCodes(by,[11,12,16],true,basis,value);continue;
   }
   if(type==='IMAGE'||type==='WIPEOUT'){
     // Group 10 is the WCS insertion point; 11/12 are WCS image axes and 14/24 clipping data are local.
     visitCodes(by,[10],false,basis,value);continue;
   }
   if(type==='RAY'||type==='XLINE'){
     // Group 10 is the base point, while 11/21/31 is a direction vector, never a position.
     visitCodes(by,[10],false,basis,value);continue;
   }
   const useOcs=ocsTypes.has(type)&&!(type==='POLYLINE'&&poly3d);
   if(type==='LWPOLYLINE'||type==='POLYLINE'&&!poly3d||type==='HATCH'){
    const xs=by.get(10)||[],ys=by.get(20)||[];let elev=0;
    if(type==='LWPOLYLINE')elev=value(38,0,0)??0;else elev=value(30,0,0)??0;
    for(let i=0;i<Math.min(xs.length,ys.length);i++){
     // HATCH group 10/20 in the header is an elevation-origin record, not a boundary vertex.
     if(type==='HATCH'){
       const pathStart=(rec.pairs||[]).findIndex(q=>q.code===91);const pos=(rec.pairs||[]).indexOf(xs[i]);if(pathStart<0||pos<pathStart)continue;
     }
     const z=type==='LWPOLYLINE'?elev:(type==='POLYLINE'?elev:(value(30,i,elev)??elev));
     visit(numeric(xs[i].value),numeric(ys[i].value),z,useOcs,basis);
    }
    continue;
   }
   for(let xc=10;xc<=18;xc++){
    if((type==='MTEXT'||type==='ELLIPSE'||type==='RAY'||type==='XLINE')&&xc===11)continue;
    if(type==='SPLINE'&&(xc===12||xc===13))continue;
    if(type==='MLEADER'||type==='MULTILEADER')continue;
    const xs=by.get(xc)||[],ys=by.get(xc+10)||[],zs=by.get(xc+20)||[];
    for(let i=0;i<Math.min(xs.length,ys.length);i++){
      const x=numeric(xs[i].value),y=numeric(ys[i].value),z=zs[i]?numeric(zs[i].value):0;
      visit(x,y,z==null?0:z,useOcs,basis);
    }
   }
  }
  return Number.isFinite(minZ)?minZ:0;
 }
'''
s=s[:start]+new_min+s[end:]
changes.append({'label':'world-z-position-only-scanner','count':1})

# IMAGE and WIPEOUT use WCS insertion/axis vectors. Do not route them through generic entity-OCS conversion.
rep("const sq145OCSTypes=new Set(['POINT','CIRCLE','ARC','INSERT','TEXT','ATTRIB','ATTDEF','MTEXT','SOLID','TRACE','LWPOLYLINE','POLYLINE','HATCH','LEADER','DIMENSION','SHAPE','VIEWPORT','IMAGE','WIPEOUT']);",
    "const sq145OCSTypes=new Set(['POINT','CIRCLE','ARC','INSERT','TEXT','ATTRIB','ATTDEF','MTEXT','SOLID','TRACE','LWPOLYLINE','POLYLINE','HATCH','LEADER','DIMENSION','SHAPE','VIEWPORT']);",
    'remove-image-wipeout-from-ocs')

# Handle DIMENSION WCS and OCS coordinates according to the DXF reference, and transform the omitted group 15/16.
old='''  let processed=0;
  if(type==='LWPOLYLINE'){'''
new='''  let processed=0;
  if(type==='DIMENSION'){
    // Autodesk DXF reference: (10,13,14,15) are WCS points; (11,12,16) are OCS points.
    // Mixing these spaces or leaving 15/16 untouched creates the long diagonal streaks seen after ALIGN.
    const transformWcsPointCodes=[10,13,14,15],transformOcsPointCodes=[11,12,16];
    for(const xc of transformWcsPointCodes){
      const xs=pairArrays(xc),ys=pairArrays(xc+10),zs=pairArrays(xc+20);
      for(let i=0;i<Math.min(xs.length,ys.length);i++){
        const xp=xs[i],yp=ys[i],x=numeric(xp.value),y=numeric(yp.value);if(x===null||y===null)continue;
        const q=t.point(x,y);change(xp,q.x);change(yp,q.y);processed++;
        if(zs[i]){const z=numeric(zs[i].value);if(z!==null)change(zs[i],zPivot+t.scale*(z-zPivot));}
      }
    }
    for(const xc of transformOcsPointCodes){
      const xs=pairArrays(xc),ys=pairArrays(xc+10),zs=pairArrays(xc+20);
      for(let i=0;i<Math.min(xs.length,ys.length);i++){
        const xp=xs[i],yp=ys[i],x=numeric(xp.value),y=numeric(yp.value);if(x===null||y===null)continue;
        const z=zs[i]?numeric(zs[i].value)??0:0,q=convertPoint(x,y,z);change(xp,q.x);change(yp,q.y);if(zs[i])change(zs[i],q.z);else if(Math.abs(q.z)>1e-10)sq145InsertPair(insertPair,yp,xc+20,q.z);processed++;
      }
    }
  }else if(type==='LWPOLYLINE'){'''
rep(old,new,'dimension-specific-wcs-ocs-branch')

# Generic transform handles both image and wipeout axes as WCS vectors, but must never move image-pixel clipping data.
rep("if(rec.type==='IMAGE'&&xc>12)continue;","if((rec.type==='IMAGE'||rec.type==='WIPEOUT')&&xc>12)continue;",'skip-image-and-wipeout-clipping-data')
rep("if(rec.type==='IMAGE'&&(xc===11||xc===12))mode='vector';","if((rec.type==='IMAGE'||rec.type==='WIPEOUT')&&(xc===11||xc===12))mode='vector';",'transform-image-and-wipeout-axes')
rep("const exact2DTypes=new Set(['LINE','POINT','CIRCLE','ARC','LWPOLYLINE','POLYLINE','TEXT','MTEXT','ATTRIB','ATTDEF','INSERT','SOLID','TRACE','3DFACE','SPLINE','ELLIPSE','RAY','XLINE','LEADER','HATCH','DIMENSION','IMAGE','MLEADER','MULTILEADER']);",
    "const exact2DTypes=new Set(['LINE','POINT','CIRCLE','ARC','LWPOLYLINE','POLYLINE','TEXT','MTEXT','ATTRIB','ATTDEF','INSERT','SOLID','TRACE','3DFACE','SPLINE','ELLIPSE','RAY','XLINE','LEADER','HATCH','DIMENSION','IMAGE','WIPEOUT','MLEADER','MULTILEADER']);",
    'allow-safe-wipeout-transform')
rep("const opaqueTypeNames=new Set(['ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH','SURFACE','HELIX','MULTILEADER','MLINE','TABLE','WIPEOUT','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY','TOLERANCE','SHAPE','VIEWPORT']);",
    "const opaqueTypeNames=new Set(['ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH','SURFACE','HELIX','MULTILEADER','MLINE','TABLE','OLE2FRAME','PDFUNDERLAY','DWFUNDERLAY','DGNUNDERLAY','TOLERANCE','SHAPE','VIEWPORT']);",
    'remove-wipeout-from-opaque-types')

# Keep exact source/destination point mapping and report residuals for visible confirmation.
old=''' const c=Math.cos(angle),s=Math.sin(angle),tx=ref1.x-scale*(c*src1.x-s*src1.y),ty=ref1.y-scale*(s*src1.x+c*src1.y);
 return {scale,angle,angleDeg:angle*180/Math.PI,c,s,tx,ty,point:(x,y)=>({x:scale*(c*x-s*y)+tx,y:scale*(s*x+c*y)+ty}),vector:(x,y)=>({x:scale*(c*x-s*y),y:scale*(s*x+c*y)})};'''
new=''' const c=Math.cos(angle),s=Math.sin(angle),tx=ref1.x-scale*(c*src1.x-s*src1.y),ty=ref1.y-scale*(s*src1.x+c*src1.y);
 const point=(x,y)=>({x:scale*(c*x-s*y)+tx,y:scale*(s*x+c*y)+ty}),vector=(x,y)=>({x:scale*(c*x-s*y),y:scale*(s*x+c*y)});
 const p1=point(src1.x,src1.y),p2=point(src2.x,src2.y),residual1=Math.hypot(p1.x-ref1.x,p1.y-ref1.y),residual2=Math.hypot(p2.x-ref2.x,p2.y-ref2.y);
 const tolerance=Math.max(1e-8,Math.max(Math.abs(ref1.x),Math.abs(ref1.y),Math.abs(ref2.x),Math.abs(ref2.y),dR)*1e-12);
 if(![residual1,residual2].every(Number.isFinite)||residual1>tolerance||residual2>tolerance)throw new Error('فشل التحقق العددي من تطابق النقطتين بعد حساب Alignment؛ لم يتم اعتماد التحويل.');
 return {scale,angle,angleDeg:angle*180/Math.PI,c,s,tx,ty,point,vector,residual1,residual2,tolerance};'''
rep(old,new,'similarity-residual-postcheck')

# Improve pre-export summary: state the point residual and explicitly explain negative coordinates are not clamped.
old='''function fillReadouts(){for(let i=0;i<2;i++){const n=i+1,src=state.targetPoints[i],ref=state.referencePoints[i];for(const [id,p] of [['sq110T'+n,src],['sq110R'+n,ref]]){const x=el(id+'X'),y=el(id+'Y');if(x)x.value=p?p.x.toFixed(6):'';if(y)y.value=p?p.y.toFixed(6):'';}const s=el('sq110StatusPoint'+n);if(s)s.textContent='النقطة '+n+': '+(src&&ref?'مطابقة بين اللوحتين':src?'تم تحديدها في غير الموجّهة':ref?'تم تحديدها في المرجعية':'لم تُحدد بعد');}updatePickLabels();}'''
new='''function fillReadouts(){for(let i=0;i<2;i++){const n=i+1,src=state.targetPoints[i],ref=state.referencePoints[i];for(const [id,p] of [['sq110T'+n,src],['sq110R'+n,ref]]){const x=el(id+'X'),y=el(id+'Y');if(x)x.value=p?p.x.toFixed(6):'';if(y)y.value=p?p.y.toFixed(6):'';}const s=el('sq110StatusPoint'+n);if(s)s.textContent='النقطة '+n+': '+(src&&ref?'مطابقة بين اللوحتين':src?'تم تحديدها في غير الموجّهة':ref?'تم تحديدها في المرجعية':'لم تُحدد بعد');}updatePickLabels();}'''
# identical no-op expected; don't use rep

# Replace stale DWG text in orientation screen if any. Explicit path is now handled internally.
# No other code paths are modified.
out.write_text(s,encoding='utf-8',newline='')
report=args.report
report.parent.mkdir(parents=True,exist_ok=True)
report.write_text('''# SurveyQuant V1.0.148 Patch Report\n\n## Changes\n- Fixed DXF DIMENSION coordinate spaces using the Autodesk DXF reference: WCS groups 10/13/14/15 and OCS groups 11/12/16 are transformed separately. This prevents old, untransformed dimension attachment points from producing long streaks.\n- Corrected the Z-pivot scanner so dimension WCS points are not passed through the OCS basis, and image/wipeout vectors/clipping coordinates cannot pollute the world-Z pivot.\n- Added WCS-axis transformation for IMAGE/WIPEOUT while preserving their pixel/clip payload. WIPEOUT is no longer blanket-rejected by the text-DXF transformer.\n- Fixed orientation-only DWG conversion to initialize LibreDWG with the local WASM runtime URL and validate conversion output with the same DXF validator as the main parser.\n- Reduced the orientation viewport from 56vh/360-640px to 44vh/250-500px.\n- Added residual verification on the two-point similarity transform. Negative coordinates are not forcibly clamped, because that would break exact alignment; point pairs must map within a numeric tolerance.\n\n## Validation scope\nThe new regression test exercises actual DXF byte transformation for DIMENSION WCS/OCS points, IMAGE/WIPEOUT axes and clipping payload, two-point residuals, and the DWG runtime initialization path. Existing V147 regression tests are also run after adjusting the version constant. The original user DWG/DXF remains necessary for final field acceptance.\n''',encoding='utf-8')
print('Wrote',out,'len',len(s),'sha256',hashlib.sha256(s.encode()).hexdigest())
print('Changes',json.dumps(changes,ensure_ascii=False))
