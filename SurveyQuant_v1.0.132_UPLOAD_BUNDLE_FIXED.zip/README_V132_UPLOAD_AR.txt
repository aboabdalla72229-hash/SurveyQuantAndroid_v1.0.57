حزمة إصلاح بناء SurveyQuant v1.0.132

سبب الخطأ السابق: الـWorkflow كان يطلب SurveyQuant_v1.0.132_CAD_ORIGINAL_VIEW_PATCH.zip من جذر المستودع، بينما الملف لم يكن مرفوعًا هناك.

ارفع محتويات هذا الملف إلى مستودع GitHub مع الحفاظ على المسارات: 
1) SurveyQuant_v1.0.132_CAD_ORIGINAL_VIEW_PATCH.zip إلى جذر المستودع بجوار حزم V126-V131.
2) استبدل .github/workflows/build-v132-cad-original-view-preserve.yml بالنسخة الموجودة هنا.

النسخة المعدلة تصلح كذلك مرجع ملف SHA256 الذي كان يشير إلى متغير V131_SOURCE_PATCH غير المعرّف. بعد رفع الملفين، شغّل Workflow: Build SurveyQuant v1.0.132 - CAD Original View + Strict Reference Preserve.

مهم: هذا يعالج مانع البناء واختبارات الحزمة. اختبار CAD النهائي على ملفات DWG/DXF الفعلية يظل ضروريًا قبل اعتماد النسخة للاستخدام الميداني.
