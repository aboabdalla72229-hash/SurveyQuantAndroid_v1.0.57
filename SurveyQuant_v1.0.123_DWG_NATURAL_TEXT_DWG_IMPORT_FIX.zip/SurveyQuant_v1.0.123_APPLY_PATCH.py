#!/usr/bin/env python3
"""V123 repair: make CAD entity labels scale with the older sq108 board viewport."""
from pathlib import Path
import re
import sys

SCRIPT_ID = 'sq-orientation-manual-points-module'
OLD_LOOP = "for(const t of drawing.texts){const p=toScreen(t.p,m);if(p.x<0||p.x>m.w||p.y<0||p.y>m.h)continue;ctx.fillStyle='#e9c46a';ctx.font='11px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);}"
NEW_LOOP = "for(const t of drawing.texts){const p=toScreen(t.p,m);if(p.x<0||p.x>m.w||p.y<0||p.y>m.h)continue;const textPixels=sqV123TextPixelHeight(t.height,m.scale);if(!Number.isFinite(textPixels)||textPixels<=0)continue;ctx.fillStyle='#e9c46a';ctx.font=textPixels+'px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);}"
HELPER = "function sqV123TextPixelHeight(height,scale){const h=Number(height),s=Number(scale);const worldHeight=Number.isFinite(h)&&h!==0?Math.abs(h):2.5;const screenScale=Number.isFinite(s)&&s>0?s:0;return worldHeight*screenScale;}\n"

if len(sys.argv) != 3:
    raise SystemExit('usage: SurveyQuant_v1.0.123_APPLY_PATCH.py MANUAL_MODULE.js INDEX_PATH.html')
manual_path, html_path = map(Path, sys.argv[1:])
manual = manual_path.read_text(encoding='utf-8')
html = html_path.read_text(encoding='utf-8')


def patch_module(source: str, label: str) -> str:
    old_count, new_count = source.count(OLD_LOOP), source.count(NEW_LOOP)
    if (old_count, new_count) == (1, 0):
        source = source.replace(OLD_LOOP, NEW_LOOP, 1)
    elif (old_count, new_count) != (0, 1):
        raise SystemExit(f'ERROR: {label}: expected one fixed-font CAD text loop or one V123 loop; old={old_count}, new={new_count}.')

    helper_count = source.count('function sqV123TextPixelHeight(')
    if helper_count == 0:
        if source.count('function draw(){') != 1:
            raise SystemExit(f'ERROR: {label}: expected one draw() insertion point.')
        source = source.replace('function draw(){', HELPER + 'function draw(){', 1)
    elif helper_count != 1:
        raise SystemExit(f'ERROR: {label}: duplicate V123 text height helpers ({helper_count}).')

    if source.count('function sqV123TextPixelHeight(') != 1 or source.count(NEW_LOOP) != 1:
        raise SystemExit(f'ERROR: {label}: natural CAD text scale did not validate.')
    if OLD_LOOP in source:
        raise SystemExit(f'ERROR: {label}: hard-coded 11px CAD text remains.')
    if 'function metrics(){' not in source or 'const scale=base*zoom;' not in source:
        raise SystemExit(f'ERROR: {label}: board scale/zoom path is missing or changed.')
    if 'function toScreen(p,m)' not in source:
        raise SystemExit(f'ERROR: {label}: geometry screen projection function is missing.')
    return source

manual_updated = patch_module(manual, manual_path.name)
script_pattern = re.compile(r'(<script\b[^>]*\bid=["\']' + re.escape(SCRIPT_ID) + r'["\'][^>]*>)([\s\S]*?)(</script\s*>)', re.I)
matches = list(script_pattern.finditer(html))
if len(matches) != 1:
    raise SystemExit(f'ERROR: integrated HTML: expected exactly one #{SCRIPT_ID} script block, found {len(matches)}.')

def replace_script(match: re.Match) -> str:
    body = patch_module(match.group(2), 'index.html embedded manual-points module')
    return match.group(1) + body + match.group(3)

html_updated, replaced = script_pattern.subn(replace_script, html, count=1)
if replaced != 1:
    raise SystemExit('ERROR: failed to patch exactly one embedded manual-points renderer.')
# Confirm the V122 two-board renderer still uses its own projected CAD text scale.
if 'function sqV122NaturalTextPixels(' not in html_updated or 'size=sqV122NaturalTextPixels(v,t,m,p)' not in html_updated:
    raise SystemExit('ERROR: V122 two-board text renderer was lost while patching the legacy canvas.')
if html_updated.count('function sqV123TextPixelHeight(') != 1:
    raise SystemExit('ERROR: expected one V123 text-height helper in final HTML.')
manual_path.write_text(manual_updated, encoding='utf-8')
html_path.write_text(html_updated, encoding='utf-8')
print('PASS V123: legacy sq108 CAD labels now use source entity height × board fit/zoom scale; hard-coded 11px CAD font removed.')
print('PASS V123: point-pick UI markers remain fixed for touch usability; drawing entity records and DXF bytes are not changed.')
print('PASS V123: V122 two-board preview scaling remains installed.')
