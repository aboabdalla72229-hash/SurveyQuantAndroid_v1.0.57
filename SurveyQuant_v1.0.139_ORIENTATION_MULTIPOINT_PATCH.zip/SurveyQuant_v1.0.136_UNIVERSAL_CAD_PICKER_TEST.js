'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const [htmlPath] = process.argv.slice(2);
assert(htmlPath, 'usage: node SurveyQuant_v1.0.136_UNIVERSAL_CAD_PICKER_TEST.js INDEX_OR_EXTRACTED_APK_HTML');
const html = fs.readFileSync(htmlPath, 'utf8');
const bridgeTag = html.match(/<script\s+id=["']sq-v117-universal-dwg-bridge["']\s*>([\s\S]*?)<\/script\s*>/i);
assert(bridgeTag, 'the shared V117/V126 DWG bridge script is missing');
const bridge = bridgeTag[1];
assert.equal((html.match(/SQ_V136_UNIVERSAL_CAD_INPUT_GATE/g) || []).length, 1,
  'V136 shared CAD picker gate must be embedded exactly once');
assert.match(html, /const\s+SQ_APP_VERSION_CODE\s*=\s*136\s*;/,
  'the embedded app version check must advance to 136');
assert(bridge.includes('strongCadHint'), 'CAD context detector missing');
assert(bridge.includes('MutationObserver'), 'dynamically-created project pickers must be monitored');
assert(bridge.includes('window.__sqV117DwgBridgeAPI'), 'original V117 bridge API is missing');
assert(html.includes('window.__sqOriAxisAutoTest'), 'native app DWG converter lookup must remain available outside the shared picker bridge');
assert(bridge.includes('function universalTransformBytes') === false,
  'universalTransformBytes belongs to the app drawing engine, not the bridge itself');
assert(html.includes('function universalTransformBytes(input,t)'), 'byte-preserving CAD transform was removed');
assert(html.includes('dwg_write_dxf(bytes.buffer)'), 'local DWG-to-DXF writer was removed');
assert(html.includes("function sqDwgWasmRuntimePath()"), 'absolute Android WebView WASM path helper is missing');
assert(html.includes("new URL('./libredwg-writer/wasm/', document.baseURI)"), 'WASM URL must resolve from packaged app page');
assert.equal((html.match(/LibreDwg\.create\(sqDwgWasmRuntimePath\(\)\)/g) || []).length, 2,
  'main board import and orientation must both use the corrected WASM path');
assert.equal((html.match(/LibreDwg\.create\('\.\/libredwg-writer\/wasm'\)/g) || []).length, 0,
  'relative WASM path that triggers Failed to fetch must be removed');
assert(html.includes('safeDownloadFile'), 'existing safe download path was removed');
assert(bridge.includes("var NON_CAD_DATA_IDS = new Set(['fileToDxfInput', 'cleanFilesInput']);"),
  'dedicated point-list utilities must remain excluded');

class TestBlob {
  constructor(parts = [], options = {}) {
    this.parts = parts;
    this.type = options.type || '';
    this.size = parts.reduce((n, part) => n + (part && part.byteLength != null ? part.byteLength : Buffer.byteLength(String(part))), 0);
  }
}
class TestFile extends TestBlob {
  constructor(parts, name, options = {}) { super(parts, options); this.name = name; this.lastModified = options.lastModified || 0; }
}
class TestDataTransfer {
  constructor() { this._files = []; this.items = { add: file => this._files.push(file) }; }
  get files() { return this._files.slice(); }
}
class TestEvent {
  constructor(type, options = {}) { this.type = type; this.bubbles = !!options.bubbles; this.defaultPrevented = false; }
  preventDefault() { this.defaultPrevented = true; }
  stopImmediatePropagation() { this.immediateStopped = true; }
}
function makeInput(id, accept, ariaLabel, parentText) {
  const attrs = { 'aria-label': ariaLabel || '' };
  return {
    nodeType: 1, id, tagName: 'INPUT', type: 'file', accept: accept || '', files: [], value: '',
    labels: ariaLabel ? [{ textContent: ariaLabel }] : [], projectChangeCount: 0,
    getAttribute(name) { return attrs[String(name).toLowerCase()] || null; },
    parentElement: { nodeType: 1, tagName: 'DIV', textContent: parentText || ariaLabel || '', parentElement: null }
  };
}
const cadIds = [
  'concreteDxfInput', 'quantBeforeFile', 'quantAfterFile', 'quantFileInput',
  'profileFileInput', 'dropSurveyFiles', 'dropCadFile', 'sqOriReferenceFile',
  'sqOriTargetFile', 'sq108File', 'sq110TargetFile', 'sq110ReferenceFile'
];
const knownInputs = cadIds.map(id => makeInput(id, '*/*'));
const genericProjection = makeInput('projectFileInputX9', '*/*',
  'اختيار لوحة المصدر لمشروع إسقاط الملفات', 'إسقاط الملفات: اختر اللوحة المصدر');
const genericMerge = makeInput('mergeDrawingUpload', '*/*',
  'Import CAD drawing to merge', 'Merge drawings');
const pointList = makeInput('pointListInput', '*/*,.txt,.csv,.sdr,.pnt',
  'قائمة نقاط TXT CSV SDR PNT', 'استيراد قائمة نقاط');
const imagePdf = makeInput('referencePhotoInput', 'image/*,.pdf',
  'اختيار صورة مرجعية PDF', 'إرفاق صورة مرجعية PDF');
const textOnlyTools = [
  makeInput('fileToDxfInput', '.sdr,.txt,.csv,.pt,.pnt,text/plain,text/csv,*/*'),
  makeInput('cleanFilesInput', '.sdr,.pnt,.txt,.csv,.dat,text/plain,text/csv,*/*')
];
const allInputs = [...knownInputs, genericProjection, genericMerge, pointList, imagePdf, ...textOnlyTools];
const listeners = Object.create(null);
let mutationCallback = null;
const documentMock = {
  nodeType: 9,
  documentElement: {},
  querySelectorAll(selector) { return selector === 'input[type="file"]' ? allInputs : []; },
  addEventListener(type, fn) { (listeners[type] ||= []).push(fn); }
};
const calls = [];
const testBytes = new Uint8Array([0, 10, 13, 255, 7, 8]);
const windowMock = {
  __sqOriAxisAutoTest: {
    async convertTargetToDxf(file) {
      calls.push(file.name);
      return { ok: true, bytes: testBytes.slice(), name: file.name.replace(/\.dwg$/i, '.dxf') };
    }
  }
};
const context = {
  window: windowMock, document: documentMock,
  MutationObserver: class { constructor(fn) { mutationCallback = fn; } observe() {} },
  File: TestFile, Blob: TestBlob, DataTransfer: TestDataTransfer, Event: TestEvent,
  DragEvent: class extends TestEvent {}, alert() {},
  console: { log() {}, warn() {}, error() {} },
  ArrayBuffer, Uint8Array, Set, Map, Array, String, Number, Object, RegExp, Error, Date, Promise, Buffer
};
vm.createContext(context);
vm.runInContext(bridge, context, { filename: 'embedded-sq-universal-dwg-bridge.js' });

for (const id of cadIds) {
  const control = knownInputs.find(x => x.id === id);
  assert(control.accept.toLowerCase().includes('.dwg'), `known board picker failed DWG acceptance: ${id}`);
  assert(control.accept.toLowerCase().includes('.dxf'), `known board picker failed DXF preservation: ${id}`);
}
assert(genericProjection.accept.toLowerCase().includes('.dwg'), 'unknown Arabic projection-board picker must accept DWG');
assert(genericProjection.accept.toLowerCase().includes('.dxf'), 'unknown Arabic projection-board picker must continue accepting DXF');
assert(genericMerge.accept.toLowerCase().includes('.dwg'), 'unknown English CAD merge picker must accept DWG');
assert(!pointList.accept.toLowerCase().includes('.dwg'), 'point-list text upload must not become a CAD picker');
assert(!imagePdf.accept.toLowerCase().includes('.dwg'), 'image/PDF picker must remain outside automatic DWG conversion');
for (const item of textOnlyTools) assert(!item.accept.toLowerCase().includes('.dwg'), `${item.id} must stay a point-list utility`);
assert(mutationCallback, 'MutationObserver must be installed for controls dynamically created in project screens');
const dynamicBoard = makeInput('dynamicUploadR8', '*/*', 'Upload drawing board for orientation', 'Reference board / CAD drawing');
mutationCallback([{ addedNodes: [dynamicBoard] }]);
assert(dynamicBoard.accept.toLowerCase().includes('.dwg'), 'dynamically created board picker must accept DWG');
assert(dynamicBoard.accept.toLowerCase().includes('.dxf'), 'dynamically created board picker must keep DXF');

(async () => {
  const source = new TestFile([testBytes], 'Unknown-Project-Board.DwG', { type: 'application/octet-stream' });
  genericProjection.files = [source];
  genericProjection.value = 'Unknown-Project-Board.DwG';
  genericProjection.dispatchEvent = function (event) {
    event.target = this;
    for (const handler of listeners.change || []) handler(event);
    if (!event.defaultPrevented) this.projectChangeCount++;
    return true;
  };
  const original = new TestEvent('change', { bubbles: true });
  genericProjection.dispatchEvent(original);
  assert(!original.defaultPrevented && !original.immediateStopped,
    'shared picker bridge must not intercept or replace native DWG change events');
  assert.equal(genericProjection.projectChangeCount, 1,
    'the selected DWG must continue through the existing project handler exactly once');
  assert.equal(genericProjection.files.length, 1, 'the existing project handler must retain the selected source file');
  assert.equal(genericProjection.files[0], source, 'the bridge must not substitute a temporary or redrawn file');
  assert.equal(genericProjection.files[0].name, 'Unknown-Project-Board.DwG', 'the original DWG name and extension must remain intact');
  assert.equal(source.name, 'Unknown-Project-Board.DwG', 'original DWG object must remain unchanged');
  assert.equal(calls.length, 0, 'the generic picker bridge must not run orientation-only conversion');
  assert.deepEqual(Array.from(source.parts[0]), Array.from(testBytes), 'source DWG bytes must remain unchanged');
  console.log('PASS V136: all known CAD projects plus generic Arabic projection and English merge inputs accept DWG.');
  console.log('PASS V136: dynamically created board inputs are recognized; native file-change handling is preserved.');
  console.log('PASS V136: point-list TXT/CSV/SDR/PNT and image/PDF controls remain excluded; original DWG is untouched.');
})().catch(error => { console.error(error); process.exitCode = 1; });
