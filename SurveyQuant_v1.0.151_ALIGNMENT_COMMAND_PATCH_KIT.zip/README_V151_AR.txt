SurveyQuant V1.0.151 — أمر ALIGNMENT جديد

الهدف
- إزالة مشروع توجيه اللوحات القديم من واجهة المستخدم واستبدال مدخله بأمر ALIGNMENT مستقل.
- اختيار اللوحة المصدر واللوحة المرجعية، وتحديد نقطتين WCS متناظرتين على كل لوحة، ثم حساب الدوران والمقياس والإزاحة ومعاينة التراكب قبل التصدير.
- فتح DXF مباشرة وقراءة DWG باستخدام قارئ LibreDWG المشترك وتحويل نسخة في الذاكرة إلى DXF؛ الناتج الجديد DXF، والملفان الأصليان لا يتم استبدالهما.
- تفريغ الجلسة والنقاط والمعاينة عند فتح الأمر أو إغلاقه أو استبدال أي ملف، مع تجاهل نتائج القراءة غير المتزامنة القديمة.

الملفات
- SurveyQuant_v1.0.151_APPLY_ALIGNMENT_COMMAND.py: يثبت واجهة الأمر الجديدة ورقم الإصدار 151.
- SurveyQuant_v1.0.151_ALIGNMENT_COMMAND_MODULE.js: متحكم ALIGNMENT الجديد.
- SurveyQuant_v1.0.151_ALIGNMENT_COMMAND_TEST.js: اختبار نقاط التحويل وإزالة مداخل المشروع القديم.
- SurveyQuant_v1.0.151_SESSION_SPLINE_DWG_TEST.js و SurveyQuant_v1.0.151_WCS_PREVIEW_AXIS_TEST.js: اختبارات انحدار موروثة من V150 بعد تحديث رقم النسخة.
- SurveyQuant_v1.0.130_DWG_AXIS_MULTISELECT_TEST.js: اختبار قارئ DWG / الحفاظ على بيانات DXF.
- SurveyQuant_v1.0.151_PACKAGE_APK.py: يحقن HTML المختبر في APK V150 ويرفع بيان الإصدار إلى 1.0.151/151.

البناء
ارفع الحزمة SurveyQuant_v1.0.151_ALIGNMENT_COMMAND_PATCH_KIT.zip إلى جذر المستودع ثم ملف Workflow build-v151-alignment-command-from-scratch.yml إلى .github/workflows/. شغّل Build SurveyQuant v1.0.151 - Fresh ALIGNMENT Command من Actions.

حدود تقنية يجب عدم إخفائها
- DWG يُقرأ عبر محرك LibreDWG ويُحوّل مؤقتًا إلى DXF. الإخراج الحالي DXF وليس DWG أصليًا.
- إذا كان الملف يحتوي على كائنات Civil 3D/Proxy/Solids مغلقة لا تكشف هندستها عبر التحويل، فلا يمكن ضمان تحويل هندستها الداخلية من DXF نصي فقط؛ المحرك يرفض إنشاء ناتج جزئي بدل ادعاء حفظها.
- نجاح الاختبارات الاصطناعية والبناء لا يعادل التحقق الميداني على ملف المساحة الأصلي. افحص الملف الناتج في CAD على نسخة قبل الاعتماد التنفيذي.
