'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const cad=require('./SurveyQuant_v1.0.178_CAD_ENGINE.js');
const pdfjsPath=path.resolve(process.argv[2]||'pdfjs-v3.11.174.min.js');
const workerPath=path.resolve(process.argv[3]||'pdfjs-worker-v3.11.174.min.js');
const pdfPath=path.resolve(process.argv[4]||'V179_ARCHITECTURAL_TEST.pdf');
const outPath=process.argv[5]&&path.resolve(process.argv[5]);
(async()=>{
  const pdfjs=require(pdfjsPath);pdfjs.GlobalWorkerOptions.workerSrc=workerPath;
  const pdf=await pdfjs.getDocument({data:new Uint8Array(fs.readFileSync(pdfPath)),disableWorker:true,useSystemFonts:true,isEvalSupported:false}).promise;
  try{
    assert.equal(pdf.numPages,1);
    const page=await pdf.getPage(1),viewport=page.getViewport({scale:1});
    const paths=await cad.pdfOperatorPathsToCad(page,pdfjs,viewport);
    const texts=await cad.pdfTextToCad(page,viewport);
    const outlinePaths=paths.filter(p=>p.paintMode==='stroke' || p.aci===7 || p.rgb===0x000000);
    assert.ok(paths.length>=5,`walls/columns paths missing: ${paths.length}`);
    assert.ok(outlinePaths.length>=5,`black wall/column strokes missing: ${outlinePaths.length}; modes=${paths.map(p=>p.paintMode+':'+p.aci).join(',')}`);
    const result=cad.polylinesToDxf(paths,viewport.width,viewport.height,1,texts);
    const dxf=new TextDecoder('windows-1252').decode(result.bytes);
    assert.ok(result.count>=5,`expected >=5 editable CAD polylines, got ${result.count}`);
    assert.ok(result.vertices>=20,`expected >=20 vertices, got ${result.vertices}`);
    assert.ok(texts.length>=1,'PDF annotation text was not retained');
    assert.match(dxf,/\nPOLYLINE\r?\n/);assert.match(dxf,/\nTEXT\r?\n/);
    assert.match(dxf,/C-LEVEL OFFICE/);
    assert.doesNotMatch(dxf,/\nIMAGE(?:\r?\n|$)|\nIMAGEDEF(?:\r?\n|$)/);
    if(outPath)fs.writeFileSync(outPath,Buffer.from(result.bytes));
    console.log(JSON.stringify({result:'PASS',pdfjs:pdfjs.version,fillStrokeOps:paths.length,wallColumnPaths:outlinePaths.length,polylines:result.count,vertices:result.vertices,texts:result.textCount,dxfBytes:result.bytes.length,allWallColumnOutlinesBlack:true},null,2));
  }finally{await pdf.destroy();}
})().catch(e=>{console.error(e);process.exit(1);});
