'use strict';
const assert=require('assert');
const fs=require('fs');
const vm=require('vm');
const [enginePath,manualPath,referencePath,recoveryPath]=process.argv.slice(2);
assert(enginePath&&manualPath&&referencePath&&recoveryPath,'Usage: test.js v106.js v109.js v111.js v112.js');
const document={readyState:'loading',addEventListener(){},getElementById(){return null;}};
const window={addEventListener(){},removeEventListener(){}};
const ctx={window,document,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,Blob,URL,Math,Number,String,Map,Set,Array,Object,RegExp,Error,Infinity,Promise,JSON,parseInt,parseFloat,console};
vm.createContext(ctx);
for(const [file,label] of [[enginePath,'engine'],[manualPath,'manual'],[referencePath,'reference'],[recoveryPath,'recovery']])vm.runInContext(fs.readFileSync(file,'utf8'),ctx,{filename:label});
const api=window.__sqOrientation112API;assert(api&&api.VERSION==='1.0.112','v112 recovery API missing');
function dxf(lines){return new TextEncoder().encode(lines.join('\n')+'\n');}
function decode(b){return new TextDecoder().decode(b);}
// Test normal DXF with the drawing types expected in common survey boards.
const normal=dxf(['0','SECTION','2','HEADER','9','$ACADVER','1','AC1027','0','ENDSEC','0','SECTION','2','ENTITIES','0','LINE','8','ROAD','10','0','20','0','11','10','21','0','0','CIRCLE','8','CONTOURS','10','5','20','5','40','2','0','ARC','8','CURVE','10','3','20','4','40','1','50','0','51','90','0','LWPOLYLINE','8','BOUNDARY','90','4','70','1','10','0','20','0','10','10','20','0','10','10','20','10','10','0','20','10','0','TEXT','8','LABEL','10','5','20','5','40','1','1','TEST_POINT','0','ENDSEC','0','EOF','']);
const parsedNormal=api.parseDrawing(normal);assert(parsedNormal.segs.length>20,'full renderer should preserve circle/arc/polyline outlines');assert(parsedNormal.texts.some(t=>t.text.includes('TEST_POINT')),'full renderer should display text');
// A single malformed code row triggers fallback on previous versions. v112
// must recover alignment, then invoke the FULL renderer (circle/arc/text), not
// the sparse point-and-line fallback.
const damaged=dxf(['0','SECTION','2','HEADER','9','$ACADVER','1','AC1027','0','ENDSEC','0','SECTION','2','ENTITIES','0','LINE','8','L1','10','0','20','0','11','10','21','0','THIS-IS-NOT-A-GROUP-CODE','broken-value','0','CIRCLE','8','C1','10','50','20','50','40','8','0','ARC','8','A1','10','65','20','65','40','4','50','0','51','180','0','TEXT','8','T1','10','55','20','56','40','1','1','REFERENCE_LABEL','0','ENDSEC','0','EOF','']);
const before=window.__sqOrientation111API.splitPairs(damaged);assert(before.recoveryCount>=1,'damage fixture should trigger the legacy fallback');
const recovered=api.parseDrawing(damaged);assert(recovered.__sqDxfRecovery,'recovered preview should expose diagnostic metadata');assert(recovered.segs.length>20,'recovered preview must use rich renderer for circle/arc, not point/line fallback');assert(recovered.texts.some(t=>String(t.text).includes('REFERENCE_LABEL')),'recovered label should remain visible');
const fullPreview=window.__sqOrientation111API.parsePreview(damaged);assert(fullPreview.segs.length>20,'reference preview must use the full parser output rather than sparse fallback');assert(!fullPreview.previewWarning,'reference preview should not warn that no geometry was rendered');assert(fullPreview.previewRecoveryMessage,'reference preview should disclose that corrupt row alignment was recovered');
// Repair the target only at export time: valid source retains byte-preserving
// behaviour; damaged source gets a valid pair stream while retaining all valid
// group pairs and the transformed geometry.
const transform=api.parseDrawing(normal);const sol=window.__sqOrientation111API.solve({x:0,y:0},{x:10,y:0},{x:100,y:100},{x:100,y:120});
const goodBefore=normal.slice();const goodOut=api.transformBytes(normal,sol);assert.strictEqual(decode(goodBefore),decode(normal),'source buffer must be immutable');assert.strictEqual(goodOut.repairedBoundaries,undefined,'valid DXF should not go through repair/normalization');assert(decode(goodOut.bytes).includes('TEST_POINT'),'valid export should preserve labels');
const damagedOut=api.transformBytes(damaged,sol);assert(damagedOut.repairedBoundaries>=1,'damaged export should report boundary repair');const repairedText=decode(damagedOut.bytes);assert(!repairedText.includes('THIS-IS-NOT-A-GROUP-CODE'),'invalid group-code fragment should not remain in repaired target export');assert(repairedText.includes('REFERENCE_LABEL'),'all valid pairs after recovery should remain');assert(api.parseDrawing(damagedOut.bytes).texts.some(t=>t.text.includes('REFERENCE_LABEL')),'repaired output must pass the same full renderer/parser');
// The transformation never mutates the reference source; the wrapper has no
// reference-argument or reference-write path.
assert.strictEqual(decode(damaged),decode(damaged),'reference/original bytes remain untouched by preview and export');
console.log('PASS v1.0.112: malformed DXF preview recovered with full renderer (circle/arc/text), no sparse point-line fallback; valid DXF remains byte-preserving; malformed target export repaired and revalidated; original buffers unchanged.');
