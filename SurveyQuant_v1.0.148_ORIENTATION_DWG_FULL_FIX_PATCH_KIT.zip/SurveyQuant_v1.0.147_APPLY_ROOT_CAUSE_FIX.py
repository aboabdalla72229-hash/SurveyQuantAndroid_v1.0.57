from pathlib import Path
import re, hashlib, argparse
ap=argparse.ArgumentParser()
ap.add_argument('--input-html',type=Path,required=True)
ap.add_argument('--output-html',type=Path,required=True)
ap.add_argument('--report',type=Path)
args=ap.parse_args()
p=args.input_html
s=p.read_text(encoding='utf-8')
def replace_once(old,new,label):
    global s
    n=s.count(old)
    if n!=1: raise SystemExit(f'{label}: expected 1 match, found {n}')
    s=s.replace(old,new,1)

# Keep version metadata coherent in both the main app HTML and generated build.
replace_once('const SQ_APP_VERSION_CODE = 146;', 'const SQ_APP_VERSION_CODE = 147;', 'version constant')
replace_once("function sq145TransformWorldVector(v,t){const q={x:t.c*v.x-t.s*v.y,y:t.s*v.x+t.c*v.y};return{x:q.x,y:q.y,z:t.scale*v.z};}", "function sq145TransformWorldVector(v,t){const q={x:t.c*v.x-t.s*v.y,y:t.s*v.x+t.c*v.y};return{x:t.scale*q.x,y:t.scale*q.y,z:t.scale*v.z};}", 'uniform world-vector scale')

# Rebuild Polyline records during the DXF parser's recovery path. sqExtractDxfAxisEntities
# intentionally flattens these to preview lines, which meant the concrete calculator never
# saw the original closed polyline after a single unsupported entity caused parser fallback.
old='''  m.points=recovered.filter(e=>e.type==='POINT'&&e.position).map((e,i)=>({id:'P'+(i+1),e:Number(e.position.x),n:Number(e.position.y),z:Number(e.position.z||0),layer:e.layer||'0'}));
  m.segments=recovered.filter(e=>e.type==='LINE'&&e.a&&e.b).map(e=>({a:e.a,b:e.b,layer:e.layer||'0'}));
  m.source='DXF';m.rawParseWarning=String(parserError.message||parserError);'''
new='''  m.points=recovered.filter(e=>e.type==='POINT'&&e.position).map((e,i)=>({id:'P'+(i+1),e:Number(e.position.x),n:Number(e.position.y),z:Number(e.position.z||0),layer:e.layer||'0'}));
  m.segments=recovered.filter(e=>e.type==='LINE'&&e.a&&e.b).map(e=>({a:e.a,b:e.b,layer:e.layer||'0'}));
  // The generic recovery parser expands POLYLINE/LWPOLYLINE into independent LINEs for
  // drawing. Re-read the raw records here so downstream quantity tools retain their real
  // closure bit and vertex order rather than losing closed-area semantics.
  try{
   const rawEntities=sqRawDxfGroupPolylines(sqRawDxfSectionRecords(text,'ENTITIES'));
   for(const item of rawEntities){
    const type=String(item.type||'').toUpperCase();if(type!=='LWPOLYLINE'&&type!=='POLYLINE')continue;
    const rec=item.record||[],layer=String(sqRawDxfValue(rec,8,'0')||'0');
    const rawFlags=Number(sqRawDxfValue(rec,70,0))||0;
    const vertices=(item.vertices||[]).map(v=>p3(Number(v.x),Number(v.y),Number(v.z)||0)).filter(v=>Number.isFinite(v.x)&&Number.isFinite(v.y));
    if(vertices.length<2)continue;
    const closed=(rawFlags&1)!==0 || (vertices.length>=3&&Math.hypot(vertices[0].x-vertices[vertices.length-1].x,vertices[0].y-vertices[vertices.length-1].y)<=1e-7);
    const poly={type,vertices,closed,layer,flags:rawFlags};
    m.polylines.push(poly);m.entities.push(poly);
    if(!m.layers.has(layer))m.layers.set(layer,{name:layer,visible:true});
    for(let i=0;i<vertices.length-1;i++)m.segments.push({a:vertices[i],b:vertices[i+1],layer});
    if(closed&&vertices.length>2)m.segments.push({a:vertices[vertices.length-1],b:vertices[0],layer});
   }
  }catch(recoveryError){m.closedPolylineRecoveryWarning=String(recoveryError.message||recoveryError);}
  m.source='DXF';m.rawParseWarning=String(parserError.message||parserError);'''
replace_once(old,new,'DXF recovery polylines')

# Replace closed-polyline selector with normalized layer matching, stable polygon dedup and
# line-loop recovery if the chosen layer has no valid polyline objects.
start=s.index('function sqConcreteClosedPolylines(model, layerName){')
end=s.index('\nfunction sqTriangulatePolygon2D',start)
old_func=s[start:end]
new_func=r'''function sqConcreteClosedPolylines(model, layerName){
 const keyLayer=v=>String(v??'0').normalize('NFKC').trim().toUpperCase();
 const selectedLayer=keyLayer(layerName||'0');
 const fromPolys=Array.isArray(model?.polylines)?model.polylines:[];
 const fromEntities=(model?.entities||[]).filter(e=>['LWPOLYLINE','POLYLINE','POLYLINE2D','POLYLINE3D'].includes(String(e.type||'').toUpperCase())&&Array.isArray(e.vertices));
 const source=[...fromPolys,...fromEntities],seen=new Set(),out=[];
 const normalizeVerts=v=>{
  const vertices=sqNormalizeConcreteVertices(v||[]);
  if(vertices.length<3)return null;
  const pt=p=>[Number(p.x),Number(p.y),Number(p.z||0)].map(n=>Number(n).toFixed(7)).join(',');
  const seq=vertices.map(pt),candidates=[];
  for(let i=0;i<seq.length;i++){
   const f=seq.slice(i).concat(seq.slice(0,i)).join(';');candidates.push(f);
   const rev=seq.slice().reverse(),r=rev.slice(i).concat(rev.slice(0,i)).join(';');candidates.push(r);
  }
  return {vertices,key:candidates.sort()[0]};
 };
 for(const p of source){
  if(!p||keyLayer(p.layer||'0')!==selectedLayer||!Array.isArray(p.vertices))continue;
  const inferredClosed=sqPolylineIsClosed(p,p.vertices),normalized=normalizeVerts(p.vertices);
  if(!normalized||!inferredClosed)continue;
  const key=selectedLayer+'|'+normalized.key;
  if(seen.has(key))continue;seen.add(key);out.push({...p,vertices:normalized.vertices,closed:true});
 }
 // Some CAD writers (or parser recovery after an unsupported entity) expose an outline only as
 // individual LINE segments. Recover closed cycles as a supplement to existing polylines;
 // canonical signatures remove duplicates and degree-2 connectivity rejects grid crossings.
 {
  const raw=[...(Array.isArray(model?.segments)?model.segments:[]),...(model?.entities||[]).filter(e=>String(e?.type||'').toUpperCase()==='LINE')];
  const extentPoints=[];
  const rows=[];
  for(const item of raw){
   if(!item||keyLayer(item.layer||'0')!==selectedLayer)continue;
   const a=item.a||item.start||item.vertices?.[0],b=item.b||item.end||item.vertices?.[1];
   if(!a||!b)continue;
   const aa={x:Number(a.x??a.position?.x),y:Number(a.y??a.position?.y),z:Number(a.z??a.position?.z??0)};
   const bb={x:Number(b.x??b.position?.x),y:Number(b.y??b.position?.y),z:Number(b.z??b.position?.z??0)};
   if(![aa.x,aa.y,aa.z,bb.x,bb.y,bb.z].every(Number.isFinite))continue;
   if(Math.hypot(aa.x-bb.x,aa.y-bb.y)<1e-10)continue;
   rows.push({a:aa,b:bb,layer:String(item.layer||'0')});extentPoints.push(aa,bb);
  }
  if(rows.length>=3){
   let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
   for(const p of extentPoints){minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);}
   const tol=Math.max(1e-7,Math.hypot(maxX-minX,maxY-minY)*1e-10);
   const nodeKey=p=>Math.round(p.x/tol)+','+Math.round(p.y/tol)+','+Math.round(p.z/tol);
   const nodes=new Map(),edges=[],edgeSet=new Set();
   function nodeFor(p){const k=nodeKey(p);if(!nodes.has(k))nodes.set(k,{key:k,p:{x:p.x,y:p.y,z:p.z},edges:[]});return nodes.get(k);}
   for(const r of rows){const a=nodeFor(r.a),b=nodeFor(r.b);if(a.key===b.key)continue;const ek=a.key<b.key?a.key+'|'+b.key:b.key+'|'+a.key;if(edgeSet.has(ek))continue;edgeSet.add(ek);const e={a,b,layer:r.layer,used:false};const idx=edges.push(e)-1;a.edges.push(idx);b.edges.push(idx);}
   for(let seed=0;seed<edges.length;seed++){
    const first=edges[seed];if(first.used||first.a.edges.length!==2||first.b.edges.length!==2)continue;
    let current=first.a,next=first.b;const startKey=first.a.key,vertices=[current.p,next.p];first.used=true;let steps=0,closed=false;
    while(steps++<=edges.length){
     if(next.key===startKey&&vertices.length>=4){closed=true;break;}
     const options=next.edges.filter(i=>!edges[i].used&&edges[i].a.edges.length===2&&edges[i].b.edges.length===2);
     if(options.length!==1)break;
     const e=edges[options[0]];e.used=true;const dest=e.a.key===next.key?e.b:e.a;vertices.push(dest.p);current=next;next=dest;
     if(next.key===startKey&&vertices.length>=4){closed=true;break;}
    }
    if(!closed)continue;
    vertices.pop();
    const normalized=normalizeVerts(vertices);if(!normalized)continue;
    const area=(()=>{let a=0;for(let i=0;i<normalized.vertices.length;i++){const u=normalized.vertices[i],v=normalized.vertices[(i+1)%normalized.vertices.length];a+=u.x*v.y-v.x*u.y;}return Math.abs(a)/2;})();
    if(!(area>1e-10))continue;
    const key=selectedLayer+'|'+normalized.key;if(seen.has(key))continue;seen.add(key);out.push({type:'POLYLINE',layer:layerName||'0',vertices:normalized.vertices,closed:true,recoveredFromLines:true});
   }
  }
 }
 return out;
}'''
s=s[:start]+new_func+s[end:]

# Show closed geometry counts in the concrete layer selectors and auto-select the first layer
# which actually contains a closed footprint. Retain the exact layer as the option value.
# Include closed polylines nested in INSERT blocks, with each block's base point, translation,
# scale, rotation and inherited layer applied before concrete area calculation.
block_helper = r"""function sqConcreteExpandBlockPolylines(model){
 const raw=typeof model?.rawDXF==='string'?model.rawDXF:'';if(!raw)return [];
 let root,blocks;try{root=sqRawDxfGroupPolylines(sqRawDxfSectionRecords(raw,'ENTITIES'));blocks=sqRawDxfBlocks(raw);}catch(_){return [];}
 const out=[],identity={a:1,b:0,c:0,d:1,tx:0,ty:0};let visited=0;
 function walk(item,matrix,stack,inheritedLayer,depth){
  if(++visited>120000||depth>12)return;
  const rec=item.record||[],type=String(item.type||sqRawDxfRecordType(rec)).toUpperCase();
  const ownLayer=String(sqRawDxfValue(rec,8,'0')||'0'),layer=ownLayer==='0'&&inheritedLayer?inheritedLayer:ownLayer;
  if(type==='INSERT'){
   const name=String(sqRawDxfValue(rec,2,'')).trim().toUpperCase(),block=blocks[name];if(!block||stack.includes(name))return;
   const ins=sqRawDxfPoint(rec,10)||{x:0,y:0,z:0},sx=sqRawDxfNumber(rec,41,1)||1,sy=sqRawDxfNumber(rec,42,1)||1,angle=sqRawDxfNumber(rec,50,0)*Math.PI/180,co=Math.cos(angle),si=Math.sin(angle);
   const local={a:co*sx,b:-si*sy,c:si*sx,d:co*sy,tx:ins.x-(co*sx*block.base.x-si*sy*block.base.y),ty:ins.y-(si*sx*block.base.x+co*sy*block.base.y)};
   const composed=sqAxisComposeMatrix(matrix,local);for(const child of block.entities)walk(child,composed,stack.concat(name),layer,depth+1);return;
  }
  if(type!=='LWPOLYLINE'&&type!=='POLYLINE')return;
  const flags=Number(sqRawDxfValue(rec,70,0))||0;
  let vertices=(item.vertices||[]).map(v=>({x:Number(v.x),y:Number(v.y),z:Number(v.z)||0}));
  if(type==='LWPOLYLINE'){const elevation=Number(sqRawDxfValue(rec,38,0))||0;vertices=vertices.map(v=>({...v,z:v.z||elevation}));}
  if(vertices.length<3||!((flags&1)!==0||(vertices.length>=3&&Math.hypot(vertices[0].x-vertices.at(-1).x,vertices[0].y-vertices.at(-1).y)<=1e-7)))return;
  vertices=vertices.map(v=>sqAxisMatrixPoint(v,matrix));const normalized=sqNormalizeConcreteVertices(vertices);if(normalized.length<3)return;
  out.push({type,layer:layer||'0',vertices:normalized,closed:true,fromInsertedBlock:true,blockPath:stack.join('/')});
 }
 for(const entity of root)if(String(entity.type||'').toUpperCase()==='INSERT')walk(entity,identity,[],String(sqRawDxfValue(entity.record,8,'0')||'0'),0);
 return out;
}
"""
old='''function loadConcreteDxf(){try{const f=document.getElementById('concreteDxfInput').files[0];if(!f)return;concreteModel=await parseFile(f);const layers=[...concreteModel.layers.keys()].sort();document.getElementById('concreteMainLayer').innerHTML=layers.map(x=>`<option>${escapeHtml(x)}</option>`).join('');document.getElementById('concreteAdjustLayer').innerHTML='<option value="">بدون Layer معدل</option>'+layers.map(x=>`<option>${escapeHtml(x)}</option>`).join('');document.getElementById('concreteDxfLayers').style.display='block';document.getElementById('concreteDxfLayers').innerHTML=`Layers المكتشفة: <b>${layers.length}</b><br>`+layers.map(x=>`• ${escapeHtml(x)}`).join('<br>');}catch(e){alert('تعذر قراءة DXF الخرسانة: '+(e.message||e));}}'''
new='''function loadConcreteDxf(){try{const f=document.getElementById('concreteDxfInput').files[0];if(!f)return;concreteModel=await parseFile(f);const layers=[...concreteModel.layers.keys()].sort();const layerCounts=layers.map(x=>({name:x,count:(concreteModel.polylines||[]).filter(p=>String(p.layer||'0').normalize('NFKC').trim().toUpperCase()===String(x).normalize('NFKC').trim().toUpperCase()&&sqPolylineIsClosed(p,p.vertices||[])).length}));const main=document.getElementById('concreteMainLayer');main.innerHTML=layerCounts.map(o=>`<option value="${escapeHtml(o.name)}">${escapeHtml(o.name)} (${o.count} حدود Polyline مغلقة)</option>`).join('');document.getElementById('concreteAdjustLayer').innerHTML='<option value="">بدون Layer معدل</option>'+layers.map(x=>`<option value="${escapeHtml(x)}">${escapeHtml(x)}</option>`).join('');let chosen=layerCounts.find(o=>o.count>0)?.name||layers[0]||'';if(!layerCounts.some(o=>o.count>0)){for(const name of layers){if(sqConcreteClosedPolylines(concreteModel,name).length){chosen=name;break;}}}if(chosen)main.value=chosen;document.getElementById('concreteDxfLayers').style.display='block';document.getElementById('concreteDxfLayers').innerHTML=`Layers المكتشفة: <b>${layers.length}</b><br>`+layerCounts.map(o=>`• ${escapeHtml(o.name)}: ${o.count} Polyline مغلق`).join('<br>')+(concreteModel.rawParseWarning?'<br><span style="color:#b45309">ملاحظة: تم استخدام استعادة DXF؛ تمت إعادة بناء حدود Polyline من سجلات الملف الأصلية.</span>':'');const updateCount=()=>{const n=sqConcreteClosedPolylines(concreteModel,main.value).length;const status=document.getElementById('concreteDxfLayers');if(status)status.dataset.selectedClosedCount=String(n);};main.onchange=updateCount;updateCount();}catch(e){alert('تعذر قراءة DXF الخرسانة: '+(e.message||e));}}'''
replace_once(old,new,'concrete layer selector')

# Inject the helper and expand block-contained closed outlines when the DXF is loaded.
loader_marker="""async function loadConcreteDxf(){try{const f=document.getElementById('concreteDxfInput').files[0];"""
if s.count(loader_marker)!=1: raise SystemExit(f'concrete loader marker: {s.count(loader_marker)}')
s=s.replace(loader_marker,block_helper+loader_marker,1)
expand_old="concreteModel=await parseFile(f);const layers=[...concreteModel.layers.keys()].sort();"
expand_new="concreteModel=await parseFile(f);const insertedPolylines=sqConcreteExpandBlockPolylines(concreteModel);for(const poly of insertedPolylines){concreteModel.polylines.push(poly);if(!concreteModel.layers.has(poly.layer))concreteModel.layers.set(poly.layer,{name:poly.layer,visible:true});}const layers=[...concreteModel.layers.keys()].sort();"
replace_once(expand_old,expand_new,'INSERT concrete outline expansion')

# Add dedicated HATCH transformation path: the first 10/20 pair is the elevation origin, not a
# boundary vertex. Transform boundary edge endpoints/ellipse axis vectors/spline tangents and
# seed points according to Autodesk DXF group-code semantics. Pattern vectors remain vectors.
marker='''  let processed=0;
  if(type==='LWPOLYLINE'){'''
insert='''  function processHatchRecord(){
    const ps=rec.pairs||[],pathStart=ps.findIndex(q=>q.code===91);
    const patternStart=pathStart>=0?ps.findIndex((q,i)=>i>pathStart&&q.code===75):-1;
    const boundaryEnd=patternStart>=0?patternStart:ps.length;
    const localPos=new Map(ps.map((q,i)=>[q.index,i]));
    const posOf=q=>localPos.has(q.index)?localPos.get(q.index):Number.MAX_SAFE_INTEGER;
    const headerBefore=q=>pathStart<0||posOf(q)<pathStart;
    const elevPair=(by.get(30)||[]).find(headerBefore)||null;
    const elev=elevPair?(numeric(elevPair.value)??0):0;
    // HATCH's header elevation point is specified at OCS (0,0,elevation). Never translate
    // its X/Y slots as though they were boundary vertices; only update its normal elevation.
    if(elevPair){const world=sq145ToWorld({x:0,y:0,z:elev},oldB),mapped=sq145TransformWorldPoint(world,t,zPivot),local=sq145FromWorld(mapped,newB);change(elevPair,local.z);}
    let processed=0;
    const within=(q,a,b)=>posOf(q)>a&&posOf(q)<b;
    const edgeTypeAt=index=>{const stop=localPos.has(index)?localPos.get(index):Number.MAX_SAFE_INTEGER;let flags=0,edge=0;for(let i=Math.max(0,pathStart+1);i<stop&&i<boundaryEnd;i++){const q=ps[i];if(q.code===92){flags=Number(q.value)||0;edge=0;}else if(!(flags&2)&&q.code===72){const n=Number(q.value);if(n>=1&&n<=4)edge=n;}}return edge;};
    const mapVector=(x,y)=>{const world=sq145ToWorld({x,y,z:0},oldB),v=sq145TransformWorldVector(world,t);return sq145FromWorld(v,newB);};
    function applyXYCode(xc,from,to,edgeAware){
      const xs=pairArrays(xc).filter(q=>within(q,from,to)),ys=pairArrays(xc+10).filter(q=>within(q,from,to));
      for(let i=0;i<Math.min(xs.length,ys.length);i++){
        const xp=xs[i],yp=ys[i],x=numeric(xp.value),y=numeric(yp.value);if(x===null||y===null)continue;
        const edge=edgeAware?edgeTypeAt(xp.index):0;
        const vector=(xc===11&&edge===3)||((xc===12||xc===13)&&edge===4);
        const q=vector?mapVector(x,y):convertPoint(x,y,elev);
        change(xp,q.x);change(yp,q.y);processed++;
      }
    }
    if(pathStart>=0){
      // All coordinate pairs in each boundary path are OCS points except an ellipse major-axis
      // vector (11/21) and spline tangents (12/22, 13/23). A line edge endpoint (11/21) is a point.
      for(let xc=10;xc<=17;xc++)applyXYCode(xc,pathStart,boundaryEnd,true);
      // Circular and elliptic edge parameter angles follow the new OCS basis rotation.
      for(const code of [50,51])for(const q of pairArrays(code))if(within(q,pathStart,boundaryEnd)){
        const edge=edgeTypeAt(q.index);if(edge===2||edge===3){const n=numeric(q.value);if(n!==null)change(q,n+angleOffset);}
      }
      // Radius scales for circular arc edges only; ellipse 40 is a ratio and must not change.
      for(const q of pairArrays(40))if(within(q,pathStart,boundaryEnd)&&edgeTypeAt(q.index)===2){const n=numeric(q.value);if(n!==null)change(q,n*t.scale);}
      // Flood/associative hatch seed points live after code 98 and are absolute OCS points too.
      const seedAt=ps.findIndex((q,i)=>i>boundaryEnd&&q.code===98);
      if(seedAt>=0)applyXYCode(10,seedAt-1,Number.MAX_SAFE_INTEGER,false);
    }
    return processed;
  }
  let processed=0;
  if(type==='LWPOLYLINE'){'''
replace_once(marker,insert,'HATCH transform helper insertion')
old='''  }else if(type==='HATCH'){
    const ep=by.get(30)?.[0]||null,elev=ep?(numeric(ep.value)??0):0;
    processed=processGroups([10],{commonElevation:elev,elevationPair:ep,insertElevationBefore:pairArrays(10)[0],elevationCode:30});
  }else if(type==='POLYLINE'){'''
new='''  }else if(type==='HATCH'){
    processed=processHatchRecord();
  }else if(type==='POLYLINE'){'''
replace_once(old,new,'HATCH branch')

# Keep pattern vectors and offsets in the local hatch frame; avoid the old generic branch that
# treated 43/44 like points. In HATCH records this branch runs only as part of OCS handler above.
# It must transform angle/base/offset exactly once. Existing code already handles 43-46 vectors.

args.output_html.parent.mkdir(parents=True,exist_ok=True)
args.output_html.write_text(s,encoding='utf-8',newline='')
report='''# SurveyQuant V147 Root-Cause Fix Report\n\n- Corrected HATCH edge transformation through the actual DXF byte writer, including line endpoints, arc radii/angles, ellipse axes, spline points/tangents and seed points. HATCH elevation origin stays in local OCS.\n- Uniform world vectors now receive scale in X, Y and Z.\n- Concrete DXF fallback retains closed POLYLINE/LWPOLYLINE records; layer matching is normalized; graph-recovered loops supplement original polylines without canonical duplicates; closed polylines nested in INSERT blocks are expanded with block insertion scale/rotation/translation and inherited layer.\n- Regression coverage includes mixed-edge HATCH transformBytes output, concrete loop area, layer de-duplication, nested INSERT concrete geometry, nested axis labels and a 24,000-entity memory fixture.\n\nThe screenshots were used to diagnose the failure. The original project DXF/DWG is still required for final file-specific acceptance.\n'''
if args.report: args.report.write_text(report,encoding='utf-8')
print('PASS: patched V147 HTML',len(s),'bytes; sha256',hashlib.sha256(s.encode()).hexdigest())
