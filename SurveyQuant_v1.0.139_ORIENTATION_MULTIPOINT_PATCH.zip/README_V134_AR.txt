SurveyQuant v1.0.134 R3 WebView DWG runtime repair

Purpose: fix the runtime loading path for bundled LibreDWG in Android WebView. The previous APK converted two actual DWG test fixtures in Node, but the app still invoked import() on an ES module under local file:// Android assets. R3 builds the Emscripten loader as a classic script, builds the high-level LibreDwg API as an IIFE global (SurveyQuantLibreDwg), loads both in order, and passes an explicit local WASM directory to LibreDwg.create().

The patch retains: local DWG/DXF assets, DXF parser bundling, exact four-side convex quadrilateral construction and validation, and the start/exit local-storage cleanup. It does not change the source DWG bytes and keeps raw source bytes with the converted model where existing app code supports it.

The workflow performs real STORM DWG-to-DXF conversion regression tests against the ESM build first, then creates the classic-script runtime for APK packaging. Final APK build and device validation are still required. LibreDWG cannot guarantee every proxy object or every proprietary entity from every AutoCAD version.
