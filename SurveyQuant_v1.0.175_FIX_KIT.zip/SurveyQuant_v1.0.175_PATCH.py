#!/usr/bin/env python3
from pathlib import Path
import argparse,re,sys,base64

PARSER = r'''function readTextPoints(text, format='TXT'){
 const out=[];const src=String(text||'').replace(/\0/g,'');const lines=src.split(/\r?\n/);let header=null;
 const fmt=String(format||'TXT').toUpperCase();
 const clean=s=>String(s??'').trim().replace(/^\ufeff/,'').replace(/^"|"$/g,'');
 const cellsOf=line=>{
  const s=String(line||'').trim();if(!s)return [];
  let delim='';if(s.includes('\t'))delim='\t';else if(s.includes(';'))delim=';';else if(s.includes(','))delim=',';
  if(!delim)return s.split(/\s+/).map(clean).filter(Boolean);
  const out=[];let cur='',quoted=false;
  for(let i=0;i<s.length;i++){const c=s[i];if(c==='"'){if(quoted&&s[i+1]==='"'){cur+='"';i++;}else quoted=!quoted;}else if(c===delim&&!quoted){out.push(clean(cur));cur='';}else cur+=c;}
  out.push(clean(cur));return out;
 };
 const number=v=>{let s=clean(v).replace(/\s/g,'');if(!s)return null;if(s.includes(',')&&!s.includes('.'))s=s.replace(',','.');const n=Number(s);return Number.isFinite(n)?n:null;};
 const normHead=s=>clean(s).toLowerCase().replace(/[\s._-]+/g,'').replace(/[^a-z0-9\u0600-\u06ff]/g,'');
 const aliases={id:['id','point','pointno','pointnumber','ptno','pt','station','stationno','name','number','رقم','رقمالنقطة','النقطة'],x:['x','e','east','easting','utme','coordx','شرق','شرقي'],y:['y','n','north','northing','utmn','coordy','شمال','شمالي'],z:['z','elev','elevation','rl','level','height','منسوب']};
 const add=(id,e,n,z)=>{if(Number.isFinite(e)&&Number.isFinite(n)&&Number.isFinite(z))out.push({id:String(id??'').trim()||('P'+(out.length+1)),e,n,z,layer:'SURVEY_POINTS'});};
 let sdrOrder='ENZ';
 if(fmt==='SDR')for(const ln of lines){if(/^00(?:NM|KI)/i.test(ln)){const flag=String(ln).length>44?String(ln).charAt(44):'';if(flag==='1')sdrOrder='NEZ';else if(flag==='2')sdrOrder='ENZ';else{const p=cellsOf(ln),tail=p[p.length-1];if(tail==='1')sdrOrder='NEZ';else if(tail==='2')sdrOrder='ENZ';}break;}}
 for(const raw of lines){const s=String(raw||'').trim();if(!s)continue;
  if(fmt==='SDR'&&/^08(?:TP|KI)/i.test(s)){
   const p=cellsOf(s);if(p.length>=5){const id=p[1]||('P'+(out.length+1)),a=number(p[2]),b=number(p[3]),z=number(p[4]);if(a!==null&&b!==null&&z!==null){add(id,sdrOrder==='NEZ'?b:a,sdrOrder==='NEZ'?a:b,z);continue;}}
   const id=s.substring(4,20).trim()||('P'+(out.length+1)),a=number(s.substring(20,36)),b=number(s.substring(36,52)),z=number(s.substring(52,68));if([a,b,z].every(v=>v!==null)){add(id,sdrOrder==='NEZ'?b:a,sdrOrder==='NEZ'?a:b,z);continue;}
   const nums=(s.match(/[+-]?(?:\d+(?:\.\d*)?|\.\d+)/g)||[]).map(Number).filter(Number.isFinite);if(nums.length>=3){const q=nums.slice(-3);add(id,sdrOrder==='NEZ'?q[1]:q[0],sdrOrder==='NEZ'?q[0]:q[1],q[2]);}continue;
  }
  const cells=cellsOf(s);if(cells.length<3)continue;const heads=cells.map(normHead);
  const pick=(keys,contains=[])=>heads.findIndex(h=>keys.includes(h)||contains.some(k=>h.includes(k)));
  const hx=pick(aliases.x,['easting','east','coordx','utme']),hy=pick(aliases.y,['northing','north','coordy','utmn']),hz=pick(aliases.z,['elevation','elev','height','level']),hid=pick(aliases.id,['pointno','pointnumber','stationno']);
  if(hx>=0&&hy>=0){header={id:hid,x:hx,y:hy,z:hz};continue;}
  if(header){const e=number(cells[header.x]),n=number(cells[header.y]);let z=header.z>=0?number(cells[header.z]):null;if(z===null){const rest=cells.map((_,i)=>i).filter(i=>i!==header.x&&i!==header.y&&i!==header.id).map(i=>number(cells[i])).filter(v=>v!==null);z=rest.length?rest[rest.length-1]:null;}const id=header.id>=0?cells[header.id]:'';add(id,e,n,z);continue;}
  // No header: the SurveyQuant point-row contract is ID,Easting,Northing,Elevation.
  // A numeric point number is an identifier, never an Easting/Northing value.
  const nums=cells.map(number);
  if(cells.length>=4){const id=cells[0],e=nums[1],n=nums[2],z=nums[3];add(id,e,n,z);}
  else if(cells.length===3){add('',nums[0],nums[1],nums[2]);}
 }
 const seen=new Set();return out.filter(p=>{if(![p.e,p.n,p.z].every(Number.isFinite))return false;const k=p.e.toFixed(6)+'|'+p.n.toFixed(6);if(seen.has(k))return false;seen.add(k);return true;});
}'''

def once(s,old,new,label):
    n=s.count(old)
    if n!=1: raise SystemExit(f'{label}: expected one match, found {n}')
    return s.replace(old,new,1)

def patch_html(path:Path, engine:Path, pdfjs:Path, pdfworker:Path, check=False):
    html=path.read_text(encoding='utf-8')
    marker='<!-- SURVEYQUANT_V175_POINT_IMPORT_AND_SEPARATE_CAD_PROJECTS -->'
    if marker in html:
        if check:
            assert 'sq175-cad-project-host' in html and 'sq175-point-row-contract' in html
            assert 'id=\"sq163-pdfjs-worker\"' in html
            assert 'async function parsePointFiles(files,formatOverride=null)' in html
            assert "parsePointFiles(fs,document.getElementById('fileToDxfType').value)" in html
            print('PASS V175 HTML patch already installed')
            return
        raise SystemExit('V175 patch already installed')
    start=html.find('function readTextPoints(');end=html.find('\nfunction addCadEntity',start)
    if start<0 or end<0:raise SystemExit('Cannot locate readTextPoints block')
    html=html[:start]+PARSER+'\n'+html[end:]
    old_reader="async function parsePointFiles(files){return Promise.all([...files].map(async f=>{const ext=String(f.name||'').toLowerCase().split('.').pop()||'txt';const bytes=new Uint8Array(await f.arrayBuffer());let best=[];for(const enc of ['utf-8','windows-1252','iso-8859-1']){const pts=readTextPoints(new TextDecoder(enc,{fatal:false}).decode(bytes),ext.toUpperCase());if(pts.length>best.length)best=pts;}return{file:f,points:best};}));}"
    new_reader="async function parsePointFiles(files,formatOverride=null){return Promise.all([...files].map(async f=>{const ext=String(f.name||'').toLowerCase().split('.').pop()||'txt';const fmt=String(formatOverride||ext).toUpperCase();const bytes=new Uint8Array(await f.arrayBuffer());let best=[];for(const enc of ['utf-8','windows-1252','iso-8859-1']){const pts=readTextPoints(new TextDecoder(enc,{fatal:false}).decode(bytes),fmt);if(pts.length>best.length)best=pts;}return{file:f,points:best,format:fmt};}));}"
    if html.count(old_reader)!=1:raise SystemExit('Cannot find unique parsePointFiles implementation')
    html=html.replace(old_reader,new_reader,1)
    old_convert="const sets=await parsePointFiles(fs),pts=[],seen=new Set();"
    new_convert="const sets=await parsePointFiles(fs,document.getElementById('fileToDxfType').value),pts=[],seen=new Set();"
    if html.count(old_convert)!=1:raise SystemExit('Cannot find unique file-to-DXF parser call')
    html=html.replace(old_convert,new_convert,1)
    # Replace the old V162 modal engine and its bundled ImageTracer/PDF.js with the independently mounted V175 engine.
    html=re.sub(r'<script\b(?=[^>]*\bid=["\']sq162-(?:pdfjs|imagetracer|cad-engine)["\'])[^>]*>[\s\S]*?</script\s*>','',html,flags=re.I)
    pdf=pdfjs.read_text(encoding='utf-8')
    worker=pdfworker.read_bytes()
    if len(worker)<100000:raise SystemExit('PDF.js worker bundle is missing or unexpectedly small')
    if 'sq163-pdfjs-worker' in html:raise SystemExit('PDF.js worker already exists in V162 HTML; refusing duplicate insertion')
    worker_tag='<script type=\"application/octet-stream\" id=\"sq163-pdfjs-worker\">'+base64.b64encode(worker).decode('ascii')+'</script>\n'
    eng=engine.read_text(encoding='utf-8')
    if 'makeRasterUnderlayDxf' not in eng or 'function transformDxfBytes' not in eng:raise SystemExit('V175 CAD engine missing core functions')
    block='\n<!-- SurveyQuant V175 independent CAD projects and exact PDF raster -->\n'+worker_tag+'<script id="sq175-pdfjs">\n'+pdf.replace('</script>','<\\/script>')+'\n</script>\n<script id="sq175-cad-engine">\n'+eng.replace('</script>','<\\/script>')+'\n</script>\n'
    m=list(re.finditer(r'</body\s*>',html,re.I))
    if m:
        x=m[-1];html=html[:x.start()]+block+html[x.start():]
    else:html+=block
    html+='\n'+marker+'\n'
    html+='\n<!-- sq175-point-row-contract: ID,Easting,Northing,Elevation; numeric ID excluded from coordinates -->\n'
    path.write_text(html,encoding='utf-8')
    print(f'PASS V175 patch: parser corrected; replaced old combined CAD modal with separate project engine ({len(html):,} chars)')


def main():
 p=argparse.ArgumentParser();p.add_argument('--html',type=Path,required=True);p.add_argument('--engine',type=Path,required=True);p.add_argument('--pdfjs',type=Path,required=True);p.add_argument('--pdf-worker',type=Path,required=True);p.add_argument('--check-only',action='store_true');a=p.parse_args();patch_html(a.html,a.engine,a.pdfjs,a.pdf_worker,a.check_only)
if __name__=='__main__':main()
