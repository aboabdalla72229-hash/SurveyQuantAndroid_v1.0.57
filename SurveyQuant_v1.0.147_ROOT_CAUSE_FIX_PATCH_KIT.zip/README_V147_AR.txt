SurveyQuant V1.0.147 - إصلاح السبب الجذري لتشوه التوجيه وحساب الخرسانة

المعالجات:
- تصحيح تحويل حدود HATCH بحسب نوع الحافة. تُحوّل نهايات الخطوط والأقواس والإهليلج وSpline معًا، ويُحافَظ على متجهات النمط المحلية من دون إضافة إزاحة اللوحة العالمية.
- تصحيح تحويل متجهات الإحداثيات بحيث يطبّق الدوران والمقياس على X/Y أيضًا، مع معالجة Z وفق نقطة الارتكاز.
- استعادة سجلات LWPOLYLINE/POLYLINE المغلقة من بيانات DXF الأصلية حتى عند تعثر المحلل الأساسي.
- استنتاج حدود خرسانية مغلقة من خطوط متصلة على Layer المختار، دون اعتماد تقاطعات شبكة الرسم كحدود.
- استخراج الحدود المغلقة داخل INSERT مع مراعاة base point ومكان الإدراج والدوران والمقياس ووراثة Layer.
- عرض عدد الحدود المغلقة المكتشفة لكل Layer واختيار Layer يحتوي على حدود صالحة تلقائيًا.
- الحفاظ على محرك DWG/WASM المحلي واختبارات التوجيه وOCS و3D وMULTILEADER وعمليات التحديد والحذف الموروثة.

الملفات:
- SurveyQuant_v1.0.147_APPLY_ROOT_CAUSE_FIX.py: تطبيق التصحيح على index.html.
- SurveyQuant_v1.0.147_PACKAGE_APK.py: إدخال HTML المختبر إلى APK V146 وتحديث البيان إلى V147. ينتج APK غير موقع، ويوقّعه GitHub Actions لاحقًا.
- ملفات REGRESSION/STABILITY واختبارات التوجيه وDWG وOCS وMLeader.
- README_V147_AR.txt والتقارير تشرح ما تم اختباره.

طريقة البناء على GitHub:
1. ارفع SurveyQuant_v1.0.147_ROOT_CAUSE_FIX_PATCH_KIT.zip إلى جذر المستودع كما هو.
2. ارفع build-v147-hatch-concrete-root-cause-fix.yml إلى المسار .github/workflows/build-v147-hatch-concrete-root-cause-fix.yml.
3. افتح Actions وشغّل: Build SurveyQuant v1.0.147 - HATCH + Concrete Root-Cause Fix.
4. عند نجاح البناء، نزّل Artifact: SurveyQuant-v1.0.147-HATCH-AND-CONCRETE-ROOT-CAUSE-FIX.

التحقق:
نجحت الاختبارات الآلية المدرجة في SurveyQuant_v1.0.147_AUTOMATED_TEST_RESULTS.md. الاختبارات تعتمد على DXF تجريبي ومراجع مرجعية مستقلة. ملف DWG/DXF الأصلي الذي ظهر مشوهًا لم يكن مرفقًا في المحادثة، لذا يلزم فحصه بعد البناء قبل استخدام النتائج في التنفيذ المساحي.
