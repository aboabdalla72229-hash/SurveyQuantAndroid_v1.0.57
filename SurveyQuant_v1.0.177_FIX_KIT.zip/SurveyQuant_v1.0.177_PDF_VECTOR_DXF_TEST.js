'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const cad=require('./SurveyQuant_v1.0.177_CAD_ENGINE.js');
const pdfjsPath=process.argv[2]||path.join(__dirname,'pdfjs-v3.11.174.min.js');
const workerPath=process.argv[3]||path.join(__dirname,'pdfjs-worker-v3.11.174.min.js');
const pdfPath=process.argv[4]||path.join(__dirname,'V176_VECTOR_TEST.pdf');
const resolvedPdfjs=path.resolve(pdfjsPath),resolvedWorker=path.resolve(workerPath);
const nodeWorker=path.join(path.dirname(resolvedPdfjs),'pdf.worker.js');
if(!fs.existsSync(nodeWorker))fs.copyFileSync(resolvedWorker,nodeWorker);
const pdfjs=require(resolvedPdfjs);
pdfjs.GlobalWorkerOptions.workerSrc=resolvedWorker;
(async()=>{
 const pdf=await pdfjs.getDocument({data:new Uint8Array(fs.readFileSync(pdfPath)),disableWorker:true,useSystemFonts:true,isEvalSupported:false}).promise;
 try{
  assert.equal(pdf.numPages,1);
  const page=await pdf.getPage(1),viewport=page.getViewport({scale:1});
  const paths=await cad.pdfOperatorPathsToCad(page,pdfjs,viewport);
  const texts=await cad.pdfTextToCad(page,viewport);
  const result=cad.polylinesToDxf(paths,viewport.width,viewport.height,1,texts);
  const text=new TextDecoder('windows-1252').decode(result.bytes);
  if(process.argv[5])fs.writeFileSync(process.argv[5],Buffer.from(result.bytes));
  assert.ok(paths.length>=3,`expected multiple native vector paths, got ${paths.length}`);
  assert.ok(result.vertices>=20,`expected enough vector vertices, got ${result.vertices}`);
  assert.match(text,/\nPOLYLINE\r?\n/);
  assert.match(text,/\nVERTEX\r?\n/);
  assert.ok(texts.length>=1,'native PDF text should be retained as DXF TEXT');
  assert.match(text,/\nTEXT\r?\n/);
  assert.match(text,/SurveyQuant/);
  assert.doesNotMatch(text,/\nIMAGE(?:\r?\n|$)|\nIMAGEDEF(?:\r?\n|$)/);
  assert.match(text,/SQ_PDF_/);
  assert.match(text,/\$ACADVER\s*\n1\s*\nAC1009/);
  assert.doesNotMatch(text,/\nIMAGE(?:\r?\n|$)|\nIMAGEDEF(?:\r?\n|$)/);
  console.log(JSON.stringify({pdfjs:pdfjs.version,pages:pdf.numPages,mode:'native PDF vector operators',paths:paths.length,vertices:result.vertices,texts:result.textCount,dxfBytes:result.bytes.length,imageEntities:0,result:'PASS'},null,2));
 }finally{await pdf.destroy();}
})().catch(e=>{console.error(e);process.exit(1);});
