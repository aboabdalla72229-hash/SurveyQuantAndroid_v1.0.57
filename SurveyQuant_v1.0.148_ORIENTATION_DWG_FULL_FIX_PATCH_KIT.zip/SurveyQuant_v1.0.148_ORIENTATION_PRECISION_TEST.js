'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const htmlPath = process.argv[2];
const v130Path = process.argv[3];
assert(htmlPath && v130Path, 'Usage: node V148_TEST.js <V144-index.html> <V130-index.html>');
const html = fs.readFileSync(htmlPath, 'utf8');
const v130 = fs.readFileSync(v130Path, 'utf8');
function scriptBody(text, id) {
  const re = new RegExp(`<script\\b(?=[^>]*\\bid=["']${id}["'])[^>]*>([\\s\\S]*?)<\\/script\\s*>`, 'ig');
  const matches = [...text.matchAll(re)];
  assert.equal(matches.length, 1, `exactly one ${id} script must exist`);
  return matches[0][1];
}
const ids = [
  'sq-orientation-module',
  'sq-orientation-axis-reader-module',
  'sq-orientation-manual-points-module',
  'sq-orientation-reference-board-module',
  'sq-orientation-dxf-faithful-recovery-module',
  'sq-orientation-cad-preserve-module',
  'sq-orientation-v115-tools-module'
];
for (const id of ids) {
  if (!['sq-orientation-reference-board-module','sq-orientation-manual-points-module','sq-orientation-axis-reader-module'].includes(id)) {
    assert.equal(scriptBody(html, id), scriptBody(v130, id), `${id} must be byte-for-byte from V130`);
  }
}
assert(html.includes('const SQ_APP_VERSION_CODE = 148;'), 'version code 145 must be present');
assert(html.includes('id="surveyquant-v148-fresh-board-session"'), 'fresh board session guard must remain');
assert(html.includes('id="sq-v117-universal-dwg-bridge"'), 'shared DWG bridge must remain');
assert(html.includes('function sqDwgWasmRuntimePath()'), 'local DWG WASM resolver must remain');
assert(html.includes('height:44vh;min-height:250px;max-height:500px'), 'orientation viewport must be slightly shorter on phones');
for (const id of ['sq110RSelectEntity','sq110RDelete','sq110RUndoDelete','sq110RRedoDelete']) {
  assert(html.includes(`id="${id}"`), `${id} must be added to the reference screen`);
}
for (const fn of ['deleteReferenceEntity','undoReferenceDelete','redoReferenceDelete']) {
  assert(html.includes(`function ${fn}()`), `${fn} must exist`);
}
assert(html.includes('function setSelectedFor(side,entity,entities)'), 'each board must have independent selection state');
const axisReaderBody = scriptBody(html,'sq-orientation-axis-reader-module');
assert(axisReaderBody.includes('function sqOriModelGeometry(model)'), 'enhanced axis reader must exist');
assert(axisReaderBody.includes('sqExtractDxfAxisEntities'), 'enhanced axis reader must include raw-DXF fallback for axes');
assert(axisReaderBody.includes('sqOriConvertTargetToDxf'), 'orientation screen must include DWG conversion path');
const manualBody = scriptBody(html,'sq-orientation-manual-points-module');
assert(manualBody.includes('Groups 12/13 are tangent'), 'manual preview parser must not chain SPLINE tangent vectors as vertices');
assert(manualBody.includes('function drawVertexPath(vertices,closed=false)'), 'manual parser must use bulge-aware polylines');
assert(!html.includes("const extraTypes=new Set(['DIMENSION','ACAD_PROXY_ENTITY','ACAD_PROXY_OBJECT','3DSOLID','BODY','REGION','MESH','SURFACE','HATCH','MLEADER','MLINE"), 'HATCH/MLINE must not be drawn twice');

assert(html.includes('findEntitiesInWindowBytes(board.bytes'), 'marquee selection must use the active board bytes');
assert(html.includes('خطأ النقطتين '), 'two-point result must show numeric fit error');
assert(!html.includes("if(v.side!=='target'){status('اختيار الحذف متاح"), 'reference screen must not be blocked from deletion tools');

// Execute the reference-board module with a minimal browser harness, then test its geometry and transform APIs.
const window = {__sqOrientTest:{}};
const document = {
  readyState: 'loading',
  addEventListener() {},
  getElementById() { return null; },
  querySelector() { return null; },
  querySelectorAll() { return []; },
  createElement() { return {style:{},appendChild(){},remove(){},click(){}}; },
  head:{appendChild(){}}, body:{appendChild(){},classList:{add(){},remove(){}}}
};
const context = {
  window, document, console, Uint8Array, ArrayBuffer, Map, Set, Math, Number, String, Object,
  RegExp, Error, Promise, Blob:global.Blob, URL:global.URL, TextEncoder, TextDecoder,
  performance:{now:()=>0}, setTimeout, clearTimeout
};
window.window = window; window.document = document;
vm.createContext(context);
vm.runInContext(scriptBody(html,'sq-orientation-reference-board-module'), context, {timeout:5000});
const api = window.__sqOrientation110API;
assert(api && typeof api.transformBytes==='function', 'byte-preserving orientation transformer must load');

// Load the patched manual preview parser and verify tangent vectors do not become preview vertices.
const manualWindow = {__sqOrientTest:{}};
const manualContext = {
  window:manualWindow, document, console, Uint8Array, ArrayBuffer, Map, Set, Math, Number, String, Object,
  RegExp, Error, Promise, Blob:global.Blob, URL:global.URL, TextEncoder, TextDecoder,
  performance:{now:()=>0}, setTimeout, clearTimeout
};
manualWindow.window=manualWindow;manualWindow.document=document;
vm.createContext(manualContext);
vm.runInContext(manualBody,manualContext,{timeout:5000});
const manualApi=manualWindow.__sqManualOrientation109;
assert(manualApi&&typeof manualApi.parseDrawing==='function','manual preview parser should load');
const splineDxf=`0\nSECTION\n2\nENTITIES\n0\nSPLINE\n8\nCURVES\n70\n8\n71\n3\n72\n8\n73\n4\n74\n0\n40\n0\n40\n0\n40\n0\n40\n0\n40\n1\n40\n1\n40\n1\n40\n1\n10\n0\n20\n0\n10\n5\n20\n8\n10\n12\n20\n8\n10\n17\n20\n0\n12\n10000\n22\n-10000\n13\n-10000\n23\n10000\n0\nENDSEC\n0\nEOF\n`;
const spline=manualApi.parseDrawing(new TextEncoder().encode(splineDxf));
assert(spline.segs.length>=8,'spline should be sampled from its knot vector as a smooth preview, not straight control polygons');
const splineXs=spline.segs.flatMap(s=>[s.a.x,s.b.x]),splineYs=spline.segs.flatMap(s=>[s.a.y,s.b.y]);
assert(Math.max(...splineXs)<100 && Math.min(...splineXs)>-100 && Math.max(...splineYs)<100 && Math.min(...splineYs)>-100,
  'spline tangent vectors must never create enormous diagonal preview lines');
assert(Math.hypot(spline.segs[0].a.x-0,spline.segs[0].a.y-0)<1e-8,'clamped spline must begin at its first control endpoint');
assert(Math.hypot(spline.segs.at(-1).b.x-17,spline.segs.at(-1).b.y-0)<1e-8,'clamped spline must end at its last control endpoint');

const bulgeDxf=`0\nSECTION\n2\nENTITIES\n0\nLWPOLYLINE\n8\nCURVES\n90\n2\n70\n0\n10\n0\n20\n0\n42\n1\n10\n10\n20\n0\n0\nENDSEC\n0\nEOF\n`;
const bulgeDrawing=manualApi.parseDrawing(new TextEncoder().encode(bulgeDxf));
assert(bulgeDrawing.segs.length>=8,'LWPOLYLINE bulge should be rendered as a sampled arc, not a single chord');
const bulgeY=bulgeDrawing.segs.flatMap(s=>[s.a.y,s.b.y]);
assert(Math.min(...bulgeY)<-4.9,'positive bulge should render its expected semicircular sagitta');


// 1) A DIMENSION without graphics block must not connect its definition points into artificial webs.
const dim = {type:'DIMENSION',pairs:[
  {code:10,value:'1'},{code:20,value:'2'},{code:11,value:'30'},{code:21,value:'40'},
  {code:12,value:'7'},{code:22,value:'8'},{code:13,value:'9'},{code:23,value:'10'}
]};
const dimGeo = api.recordGeometry(dim);
assert.equal(dimGeo.segments.length,0,'dimension definition points must not be joined as preview lines');
assert(dimGeo.pts.length>=3,'dimension points remain available for ID/snap metadata');

// 2) Classic POLYLINE excludes its dummy header origin and closes exactly the vertex outline.
const polyDxf = `0\nSECTION\n2\nENTITIES\n0\nPOLYLINE\n8\nAXES\n70\n1\n10\n0\n20\n0\n0\nVERTEX\n10\n10\n20\n10\n0\nVERTEX\n10\n20\n20\n10\n0\nVERTEX\n10\n20\n20\n20\n0\nSEQEND\n0\nENDSEC\n0\nEOF\n`;
const polyRecords = api.sectionRecords(api.splitPairs(new TextEncoder().encode(polyDxf)).pairs,'ENTITIES');
assert.equal(polyRecords.length,1);
const polyGeo = api.recordGeometry(polyRecords[0]);
assert.equal(polyGeo.pts.length,3,'classic polyline should expose only true vertices');
assert.equal(polyGeo.segments.length,3,'closed polyline should draw its three outline edges, not a dummy-origin line');
assert(!polyGeo.segments.some(s => (s.a.x===0&&s.a.y===0)||(s.b.x===0&&s.b.y===0)), 'dummy origin must not create extra lines');

// 3) An unrecognized HATCH edge path cannot be rendered by joining unrelated coordinate codes.
const hatch = {type:'HATCH',pairs:[{code:92,value:'0'},{code:10,value:'1'},{code:20,value:'2'},{code:11,value:'30'},{code:21,value:'40'}]};
assert.equal(api.recordGeometry(hatch).segments.length,0,'unsupported HATCH path coordinates must not create connecting lines');

// 4) A dimension with an anonymous graphics block draws the block geometry instead of dimension-point spokes.
const dimBlockDxf = `0\nSECTION\n2\nBLOCKS\n0\nBLOCK\n2\n*D1\n70\n0\n10\n0\n20\n0\n0\nLINE\n8\nDIM\n10\n100\n20\n200\n11\n120\n21\n200\n0\nENDBLK\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n0\nDIMENSION\n8\nDIM\n2\n*D1\n10\n1\n20\n2\n11\n30\n21\n40\n13\n50\n23\n60\n0\nENDSEC\n0\nEOF\n`;
const dimPairs = api.splitPairs(new TextEncoder().encode(dimBlockDxf)).pairs;
const blockMap = api.blockDefinitions(dimPairs);
const dimension = api.sectionRecords(dimPairs,'ENTITIES')[0];
const dimBlockGeo = api.geometryInWorld(dimension,blockMap);
assert.equal(dimBlockGeo.segments.length,1,'dimension preview must use its real anonymous graphics block');
assert.equal(dimBlockGeo.segments[0].a.x,100);

// 5) Exact two-point similarity fit: translation + 90-degree rotation + scale 2.
const dxf = `0\nSECTION\n2\nHEADER\n9\n$EXTMIN\n10\n0\n20\n0\n30\n0\n9\n$EXTMAX\n10\n100\n20\n100\n30\n0\n0\nENDSEC\n0\nSECTION\n2\nBLOCKS\n0\nBLOCK\n2\nBLK_AXIS\n70\n0\n10\n0\n20\n0\n30\n0\n0\nTEXT\n8\nAXIS_LABELS\n10\n0\n20\n0\n40\n1\n1\nNORTH-AXIS\n0\nENDBLK\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n0\nLINE\n5\nL1\n8\nROAD\n10\n10\n20\n10\n30\n0\n11\n20\n21\n10\n31\n0\n1001\nSURVEYQUANT_TEST\n1000\nAXIS-EAST\n1001\nCUSTOM_APP\n1000\nKEPT_CUSTOM_DATA\n0\nCIRCLE\n5\nC1\n8\nPOINTS\n10\n10\n20\n15\n30\n0\n40\n5\n0\nTEXT\n5\nT1\n8\nAXIS_LABELS\n10\n10\n20\n10\n30\n0\n40\n2\n50\n0\n1\nAXIS-NORTH\n0\nINSERT\n5\nI1\n8\nAXIS_BLOCKS\n2\nBLK_AXIS\n10\n10\n20\n10\n30\n0\n41\n1\n42\n1\n43\n1\n50\n0\n0\nENDSEC\n0\nEOF\n`;
const src1={x:10,y:10},src2={x:20,y:10},ref1={x:100,y:200},ref2={x:100,y:220};
const transform=api.solve(src1,src2,ref1,ref2);
for (const [s,r] of [[src1,ref1],[src2,ref2]]) {
  const p=transform.point(s.x,s.y);
  assert(Math.hypot(p.x-r.x,p.y-r.y)<1e-8,'source control point must land on its exact reference point');
}
assert.equal(transform.scale,2);
assert(Math.abs(transform.angleDeg-90)<1e-10);
const originalBytes=new TextEncoder().encode(dxf);
const result=api.transformBytes(originalBytes,transform);
assert(result.bytes.length>0);
assert.equal(result.entitiesBefore,result.entitiesAfter,'no ENTITIES records may be lost');
assert(result.changedFields>0,'transform must change coordinate/size/rotation fields');
const outText=new TextDecoder().decode(result.bytes);
for(const s of ['AXIS-EAST','AXIS-NORTH','NORTH-AXIS','KEPT_CUSTOM_DATA','SURVEYQUANT_TEST','CUSTOM_APP','ROAD','POINTS','AXIS_BLOCKS']) {
  assert(outText.includes(s),`layer, axis-label, handle-associated, or XData text must survive: ${s}`);
}
const outPairs=api.splitPairs(result.bytes).pairs;
const ents=api.sectionRecords(outPairs,'ENTITIES');
const line=ents.find(e=>e.type==='LINE');
const val=(rec,code,occ=0)=>Number(rec.pairs.filter(p=>p.code===code)[occ].value);
assert(Math.abs(val(line,10)-100)<1e-8 && Math.abs(val(line,20)-200)<1e-8,'first line endpoint must exactly match point 1');
assert(Math.abs(val(line,11)-100)<1e-8 && Math.abs(val(line,21)-220)<1e-8,'second line endpoint must exactly match point 2');
const circle=ents.find(e=>e.type==='CIRCLE');
assert(Math.abs(val(circle,10)-90)<1e-8 && Math.abs(val(circle,20)-200)<1e-8,'circle center must follow the same full-board transform');
assert(Math.abs(val(circle,40)-10)<1e-8,'circle radius must scale uniformly');
const insert=ents.find(e=>e.type==='INSERT');
assert(Math.abs(val(insert,41)-2)<1e-8 && Math.abs(val(insert,42)-2)<1e-8,'insert scale factors must follow the board similarity transform');
assert(Math.abs(val(insert,50)-90)<1e-8,'insert rotation must follow the board rotation');
const preservedXdata=new TextDecoder().decode(result.bytes);
assert(preservedXdata.includes('1001\nSURVEYQUANT_TEST\n1000\nAXIS-EAST'),'XData attached to supported entities must be preserved');
const proxyDxf=`0\nSECTION\n2\nENTITIES\n0\nACAD_PROXY_ENTITY\n5\nP1\n8\nCIVIL_CUSTOM\n10\n5\n20\n10\n310\nAABBCCDD\n0\nENDSEC\n0\nEOF\n`;
assert.throws(()=>api.transformBytes(new TextEncoder().encode(proxyDxf),transform),/تم إيقاف التصدير/,'opaque proxy entities must be rejected instead of partially moved');
const ocsDxf=`0\nSECTION\n2\nENTITIES\n0\nCIRCLE\n8\nOCS\n10\n10\n20\n10\n40\n2\n210\n0\n220\n1\n230\n0\n0\nENDSEC\n0\nEOF\n`;
const ocsResult=api.transformBytes(new TextEncoder().encode(ocsDxf),transform);
assert(ocsResult.bytes.length>0&&ocsResult.entitiesBefore===ocsResult.entitiesAfter,'ordinary non-default OCS circle must transform instead of blocking export');
const ocsOut=api.sectionRecords(api.splitPairs(ocsResult.bytes).pairs,'ENTITIES').find(e=>e.type==='CIRCLE');
assert(ocsOut&&Math.abs(val(ocsOut,210)-(-1))<1e-8&&Math.abs(val(ocsOut,220))<1e-8,'non-default OCS normal must rotate with alignment');
console.log('PASS V148: V130 orientation engine; safe two-point transform; layer/axis labels and supported-entity XData preserved; opaque proxy sources fail closed while ordinary OCS is transformed; entity count and EOF preserved.');
