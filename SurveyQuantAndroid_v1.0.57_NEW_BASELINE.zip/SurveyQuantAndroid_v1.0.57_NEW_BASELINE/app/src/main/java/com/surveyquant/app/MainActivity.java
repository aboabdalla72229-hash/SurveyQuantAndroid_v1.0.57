package com.surveyquant.app;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.content.pm.PackageManager;
import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.util.UUID;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import org.json.JSONArray;
import org.json.JSONObject;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.pdmodel.PDPage;
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle;
import com.tom_roush.pdfbox.contentstream.PDFGraphicsStreamEngine;
import android.graphics.PointF;
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImage;
import com.tom_roush.pdfbox.cos.COSName;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.text.TextPosition;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import android.graphics.Path;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int FILE_PICKER = 1001;
    private Uri cameraUri;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        try { PDFBoxResourceLoader.init(getApplicationContext()); } catch (Throwable ignored) {}
        try { OpenCVLoader.initLocal(); } catch (Throwable ignored) {}
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AndroidBridge(this), "Android");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = cb;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p != null && p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                if (p != null && p.isCaptureEnabled() && p.getAcceptTypes() != null) {
                    boolean imageCapture = false;
                    for (String t : p.getAcceptTypes()) if (t != null && t.toLowerCase().startsWith("image/")) { imageCapture = true; break; }
                    if (imageCapture) {
                        try {
                            File camDir = new File(getCacheDir(), "camera");
                            if (!camDir.exists()) camDir.mkdirs();
                            File camFile = new File(camDir, "surveyquant_camera_" + System.currentTimeMillis() + ".jpg");
                            cameraUri = FileProvider.getUriForFile(MainActivity.this, "com.surveyquant.app.fileprovider", camFile);
                            Intent cam = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                            cam.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, cameraUri);
                            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            Intent chooser = Intent.createChooser(i, "اختر صورة من المعرض أو الكاميرا");
                            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
                            startActivityForResult(chooser, FILE_PICKER);
                            return true;
                        } catch (Exception ignored) { cameraUri = null; }
                    }
                }
                try { startActivityForResult(i, FILE_PICKER); }
                catch(Exception e){ if(uploadCallback!=null) uploadCallback.onReceiveValue(null); uploadCallback=null; return false; }
                return true;
            }
        });
        setContentView(web);
        if (android.os.Build.VERSION.SDK_INT >= 23 && android.os.Build.VERSION.SDK_INT <= 28 &&
                checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 2001);
        }
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.CAMERA"}, 2003);
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 2002);
        }
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r!=FILE_PICKER || uploadCallback==null) return;
        if(c!=RESULT_OK){ uploadCallback.onReceiveValue(null); uploadCallback=null; cameraUri=null; return; }
        if(d==null && cameraUri!=null){ Uri u=cameraUri; cameraUri=null; uploadCallback.onReceiveValue(new Uri[]{u}); uploadCallback=null; return; }
        if(d==null){ uploadCallback.onReceiveValue(null); uploadCallback=null; return; }
        try {
            if(d.getClipData()!=null){
                int n=d.getClipData().getItemCount();
                Uri[] uris=new Uri[n];
                for(int i=0;i<n;i++){ uris[i]=d.getClipData().getItemAt(i).getUri(); persistReadPermission(uris[i]); }
                uploadCallback.onReceiveValue(uris);
            } else {
                Uri u=d.getData();
                if(u!=null) persistReadPermission(u);
                uploadCallback.onReceiveValue(u!=null?new Uri[]{u}:null);
            }
        } catch(Exception e){ uploadCallback.onReceiveValue(null); }
        uploadCallback=null;
    }

    private void persistReadPermission(Uri u){
        if(u==null) return;
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
    }

    public static class AndroidBridge {
        private static final String CHANNEL_ID = "surveyquant_downloads";
        private final Context context;
        AndroidBridge(Context c){ context=c.getApplicationContext(); }

        @JavascriptInterface
        public String saveFile(String filename, String mime, String base64) {
            try {
                String safeName = filename == null ? "SurveyQuant_Output.bin" : filename.replaceAll("[\\/:*?\"<>|\\p{Cntrl}]", "_");
                String safeMime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                if ("application/dxf".equalsIgnoreCase(safeMime) || "application/acad".equalsIgnoreCase(safeMime)) safeMime = "application/octet-stream";
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, safeMime);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SurveyQuant");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if(uri == null) return "ERROR: cannot create Downloads entry";
                    try(OutputStream out=context.getContentResolver().openOutputStream(uri)){
                        if(out == null) throw new Exception("cannot open output stream");
                        out.write(bytes);
                        out.flush();
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    context.getContentResolver().update(uri, done, null, null);
                    return uri.toString();
                }

                if (android.os.Build.VERSION.SDK_INT >= 23 &&
                        context.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    return "ERROR: storage permission not granted";
                }
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "SurveyQuant");
                if (!dir.exists() && !dir.mkdirs()) return "ERROR: cannot create Downloads/SurveyQuant";
                File outFile = new File(dir, safeName);
                try (FileOutputStream out = new FileOutputStream(outFile)) {
                    out.write(bytes);
                    out.flush();
                }
                return FileProvider.getUriForFile(context, "com.surveyquant.app.fileprovider", outFile).toString();
            } catch(Exception e) {
                return "ERROR: " + e.getMessage();
            }
        }

        private File chunkTemp(String token) { return new File(context.getCacheDir(), "sq_chunk_" + token + ".tmp"); }
        @JavascriptInterface public String startChunkedFile(String filename,String mime){try{String token=UUID.randomUUID().toString().replace("-","");File f=chunkTemp(token);if(f.exists())f.delete();if(!f.createNewFile())return "ERROR: cannot create temp file";return token;}catch(Exception e){return "ERROR: "+e.getMessage();}}
        @JavascriptInterface public String appendChunk(String token,String base64){try{File f=chunkTemp(token);if(!f.exists())return "ERROR: temp file not found";byte[] bytes=Base64.decode(base64,Base64.DEFAULT);try(FileOutputStream out=new FileOutputStream(f,true)){out.write(bytes);out.flush();}return "OK";}catch(Exception e){return "ERROR: "+e.getMessage();}}
        @JavascriptInterface public String finishChunkedFile(String token,String filename,String mime){File f=chunkTemp(token);try{if(!f.exists())return "ERROR: temp file not found";String safeName=filename==null?"SurveyQuant_Output.bin":filename.replaceAll("[\\/:*?\"<>|\\p{Cntrl}]","_");String safeMime=(mime==null||mime.isEmpty())?"application/octet-stream":mime;if("application/dxf".equalsIgnoreCase(safeMime)||"application/acad".equalsIgnoreCase(safeMime))safeMime="application/octet-stream";Uri result;if(android.os.Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,safeName);v.put(MediaStore.Downloads.MIME_TYPE,safeMime);v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/SurveyQuant");v.put(MediaStore.Downloads.IS_PENDING,1);result=context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(result==null)return "ERROR: cannot create Downloads entry";try(OutputStream out=context.getContentResolver().openOutputStream(result);FileInputStream in=new FileInputStream(f)){if(out==null)throw new Exception("cannot open output stream");byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);out.flush();}ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);context.getContentResolver().update(result,done,null,null);}else{if(android.os.Build.VERSION.SDK_INT>=23&&context.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE")!=PackageManager.PERMISSION_GRANTED)return "ERROR: storage permission not granted";File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"SurveyQuant");if(!dir.exists()&&!dir.mkdirs())return "ERROR: cannot create Downloads/SurveyQuant";File outFile=new File(dir,safeName);try(FileOutputStream out=new FileOutputStream(outFile);FileInputStream in=new FileInputStream(f)){byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);out.flush();}result=FileProvider.getUriForFile(context,"com.surveyquant.app.fileprovider",outFile);}f.delete();return result.toString();}catch(Exception e){try{f.delete();}catch(Exception ignored){}return "ERROR: "+e.getMessage();}}
        @JavascriptInterface public void cancelChunkedFile(String token){try{chunkTemp(token).delete();}catch(Exception ignored){}}

        private static String jsonEscape(String s) {
            if (s == null) return "";
            return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", " ").replace("\n", " ");
        }

        private Bitmap loadBitmapFromBase64(String base64) throws Exception {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (b == null) throw new Exception("الصورة غير قابلة للقراءة");
            int max = 2400;
            if (Math.max(b.getWidth(), b.getHeight()) > max) {
                float sc = max / (float)Math.max(b.getWidth(), b.getHeight());
                Bitmap n = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth()*sc)), Math.max(1, Math.round(b.getHeight()*sc)), true);
                if (n != b) b.recycle();
                b = n;
            }
            return b;
        }

        private Bitmap loadPdfPageFromBase64(String base64, int pageNo) throws Exception {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            File f = new File(context.getCacheDir(), "sq_pdf_" + UUID.randomUUID().toString() + ".pdf");
            try (FileOutputStream out = new FileOutputStream(f)) { out.write(bytes); }
            try (ParcelFileDescriptor fd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
                 PdfRenderer renderer = new PdfRenderer(fd)) {
                if (renderer.getPageCount() < pageNo || pageNo < 1) throw new Exception("رقم الصفحة غير موجود");
                PdfRenderer.Page page = renderer.openPage(pageNo - 1);
                float sc = Math.min(3.0f, 2400f / Math.max(page.getWidth(), page.getHeight()));
                int w = Math.max(1, Math.round(page.getWidth()*sc)), h = Math.max(1, Math.round(page.getHeight()*sc));
                Bitmap b = Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(b); c.drawColor(Color.WHITE);
                page.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                page.close();
                return b;
            } finally { try { f.delete(); } catch(Exception ignored){} }
        }

        private JSONArray detectSimpleLines(Bitmap b) {
            JSONArray out = new JSONArray();
            int w=b.getWidth(), h=b.getHeight();
            int maxDim=1100;
            float scale=Math.min(1f, maxDim/(float)Math.max(w,h));
            int sw=Math.max(1,Math.round(w*scale)), sh=Math.max(1,Math.round(h*scale));
            Bitmap small=(sw==w&&sh==h)?b:Bitmap.createScaledBitmap(b,sw,sh,true);
            try {
                // Detect long horizontal/vertical runs plus diagonal runs in 15-degree directions.
                int[][] dirs={{1,0},{0,1},{1,1},{1,-1},{2,1},{2,-1},{1,2},{1,-2},{3,1},{3,-1},{1,3},{1,-3}};
                for(int[] d:dirs){
                    int dx=d[0],dy=d[1];
                    int minRun=Math.max(28,Math.min(sw,sh)/35);
                    for(int y=0;y<sh;y+=2){
                        for(int x=0;x<sw;x+=2){
                            int px=x,py=y,run=0,lastX=x,lastY=y;
                            while(px>=0&&px<sw&&py>=0&&py<sh){
                                int c=small.getPixel(px,py); boolean dark=(Color.red(c)+Color.green(c)+Color.blue(c))<330;
                                if(!dark)break;
                                run++; lastX=px;lastY=py;px+=dx;py+=dy;
                            }
                            if(run>=minRun){
                                try{
                                    JSONObject q=new JSONObject();
                                    q.put("type","line");
                                    q.put("x1",Math.round(x/scale)); q.put("y1",Math.round(y/scale));
                                    q.put("x2",Math.round(lastX/scale)); q.put("y2",Math.round(lastY/scale));
                                    out.put(q);
                                }catch(Exception ignored){}
                            }
                        }
                    }
                }
            } finally { if(small!=b) small.recycle(); }
            // Remove near-duplicate lines, keeping the longest representative.
            JSONArray clean=new JSONArray();
            for(int i=0;i<out.length();i++){
                try{
                    JSONObject a=out.getJSONObject(i); double ax1=a.getDouble("x1"),ay1=a.getDouble("y1"),ax2=a.getDouble("x2"),ay2=a.getDouble("y2");
                    double al=Math.hypot(ax2-ax1,ay2-ay1); if(al<35)continue; boolean dup=false;
                    for(int j=0;j<clean.length();j++){JSONObject q=clean.getJSONObject(j);double qx1=q.getDouble("x1"),qy1=q.getDouble("y1"),qx2=q.getDouble("x2"),qy2=q.getDouble("y2");double ql=Math.hypot(qx2-qx1,qy2-qy1);double d1=Math.hypot(ax1-qx1,ay1-qy1)+Math.hypot(ax2-qx2,ay2-qy2);double d2=Math.hypot(ax1-qx2,ay1-qy2)+Math.hypot(ax2-qx1,ay2-qy1);if(Math.min(d1,d2)<Math.max(20,Math.min(al,ql)*0.08)){dup=true;break;}}
                    if(!dup)clean.put(a);
                }catch(Exception ignored){}
            }
            return clean;
        }
        private String analyzeBitmap(Bitmap b, int pages) throws Exception {
            TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            Text result;
            try { result = Tasks.await(recognizer.process(InputImage.fromBitmap(b,0))); }
            finally { recognizer.close(); }
            JSONArray texts = new JSONArray();
            for(Text.TextBlock block: result.getTextBlocks()) for(Text.Line line:block.getLines()) {
                Rect r=line.getBoundingBox(); if(r==null)continue;
                JSONObject q=new JSONObject(); q.put("text",line.getText()); q.put("x",r.left); q.put("y",r.bottom); q.put("width",r.width()); q.put("height",Math.max(1,r.height())); texts.put(q);
            }
            JSONObject root=new JSONObject();
            root.put("pages",pages); root.put("width",b.getWidth()); root.put("height",b.getHeight()); root.put("texts",texts); root.put("lines",detectSimpleLines(b));
            return root.toString();
        }

        private String analyzePdfVector(byte[] bytes, int pageNo) throws Exception {
            File f=new File(context.getCacheDir(), "sq_pdf_vector_"+UUID.randomUUID()+".pdf");
            try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);}
            try(PDDocument doc=PDDocument.load(f)){
                int idx=Math.max(0,Math.min(doc.getNumberOfPages()-1,pageNo-1));
                PDPage page=doc.getPage(idx); PDRectangle box=page.getMediaBox();
                JSONArray lines=new JSONArray();
                class Catcher extends PDFGraphicsStreamEngine {
                    float cx,cy,sx,sy; boolean have=false;
                    Catcher(PDPage p){super(p);}
                    private void add(float x1,float y1,float x2,float y2){if(Math.hypot(x2-x1,y2-y1)<0.35)return;try{JSONObject q=new JSONObject();q.put("type","line");q.put("x1",x1);q.put("y1",box.getHeight()-y1);q.put("x2",x2);q.put("y2",box.getHeight()-y2);lines.put(q);}catch(Exception ignored){}}
                    public void moveTo(float x,float y){cx=x;cy=y;sx=x;sy=y;have=true;}
                    public void lineTo(float x,float y){if(have)add(cx,cy,x,y);cx=x;cy=y;have=true;}
                    public void curveTo(float x1,float y1,float x2,float y2,float x3,float y3){
                        if(have){float px=cx,py=cy;for(int i=1;i<=16;i++){float t=i/16f,u=1-t;float nx=u*u*u*cx+3*u*u*t*x1+3*u*t*t*x2+t*t*t*x3;float ny=u*u*u*cy+3*u*u*t*y1+3*u*t*t*y2+t*t*t*y3;add(px,py,nx,ny);px=nx;py=ny;}cx=x3;cy=y3;have=true;}
                    }
                    public PointF getCurrentPoint(){return new PointF(cx,cy);}
                    public void closePath(){if(have){add(cx,cy,sx,sy);cx=sx;cy=sy;}}
                    public void endPath(){have=false;}
                    public void strokePath(){}
                    public void fillPath(Path.FillType w){}
                    public void fillAndStrokePath(Path.FillType w){}
                    public void clip(Path.FillType w){}
                    public void shadingFill(COSName n){}
                    public void drawImage(PDImage img){}
                    public void appendRectangle(PointF p0,PointF p1,PointF p2,PointF p3) throws java.io.IOException {moveTo(p0.x,p0.y);lineTo(p1.x,p1.y);lineTo(p2.x,p2.y);lineTo(p3.x,p3.y);closePath();}
                }
                Catcher c=new Catcher(page);c.processPage(page);

                final ArrayList<TextPosition> glyphs=new ArrayList<>();
                PDFTextStripper stripper=new PDFTextStripper(){
                    @Override protected void processTextPosition(TextPosition text){ if(text!=null && text.getUnicode()!=null && !text.getUnicode().isEmpty()) glyphs.add(text); }
                };
                stripper.setStartPage(idx+1); stripper.setEndPage(idx+1); stripper.getText(doc);
                Collections.sort(glyphs,new Comparator<TextPosition>(){public int compare(TextPosition a,TextPosition b){int y=Float.compare(a.getYDirAdj(),b.getYDirAdj());return y!=0?y:Float.compare(a.getXDirAdj(),b.getXDirAdj());}});
                JSONArray texts=new JSONArray(); StringBuilder lineText=new StringBuilder(); float lx=0,ly=Float.NaN,lastRight=0; boolean haveLine=false;
                for(TextPosition tp:glyphs){
                    float x=tp.getXDirAdj(), y=tp.getYDirAdj(), w=Math.max(0.1f,tp.getWidth()), h=Math.max(0.1f,tp.getHeightDir());
                    if(!haveLine || Math.abs(y-ly)>Math.max(2.0f,h*0.65f) || x-lastRight>Math.max(12f,h*1.8f)){
                        if(haveLine && lineText.length()>0){JSONObject q=new JSONObject();q.put("text",lineText.toString().trim());q.put("x",lx);q.put("y",ly);q.put("width",Math.max(0,lastRight-lx));q.put("height",Math.max(1,h));q.put("source","pdf-vector-text");texts.put(q);}
                        lineText.setLength(0);lx=x;ly=y;haveLine=true;
                    }
                    lineText.append(tp.getUnicode());lastRight=Math.max(lastRight,x+w);
                }
                if(haveLine && lineText.length()>0){JSONObject q=new JSONObject();q.put("text",lineText.toString().trim());q.put("x",lx);q.put("y",ly);q.put("width",Math.max(0,lastRight-lx));q.put("height",10);q.put("source","pdf-vector-text");texts.put(q);}
                JSONObject root=new JSONObject();root.put("pages",doc.getNumberOfPages());root.put("width",box.getWidth());root.put("height",box.getHeight());root.put("lines",lines);root.put("texts",texts);root.put("vectorGeometry",true);return root.toString();
            } finally {try{f.delete();}catch(Exception ignored){}}
        }

        private JSONArray detectOpenCVShapes(Bitmap b) {
            JSONArray out=new JSONArray(); Mat src=new Mat(), gray=new Mat(), edges=new Mat();
            try {
                Utils.bitmapToMat(b,src); Imgproc.cvtColor(src,gray,Imgproc.COLOR_RGBA2GRAY); Imgproc.GaussianBlur(gray,gray,new Size(3,3),0); Imgproc.Canny(gray,edges,60,180);
                Mat lines=new Mat(); Imgproc.HoughLinesP(edges,lines,1,Math.PI/180.0,Math.max(25,Math.min(b.getWidth(),b.getHeight())/80),Math.max(25,Math.min(b.getWidth(),b.getHeight())/35),8);
                for(int i=0;i<lines.rows();i++){double[] v=lines.get(i,0);if(v==null||v.length<4)continue;try{JSONObject q=new JSONObject();q.put("type","line");q.put("x1",v[0]);q.put("y1",v[1]);q.put("x2",v[2]);q.put("y2",v[3]);q.put("source","opencv-hough");out.put(q);}catch(Exception ignored){}}
                Mat circles=new Mat(); Imgproc.HoughCircles(gray,circles,Imgproc.HOUGH_GRADIENT,1.2,Math.max(12,Math.min(b.getWidth(),b.getHeight())/80),100,25,3,Math.max(20,Math.min(b.getWidth(),b.getHeight())/8));
                for(int i=0;i<circles.cols();i++){double[] v=circles.get(0,i);if(v==null||v.length<3)continue;try{JSONObject q=new JSONObject();q.put("type","circle");q.put("x",v[0]);q.put("y",v[1]);q.put("r",v[2]);q.put("source","opencv-circle");out.put(q);}catch(Exception ignored){}}
                Mat hierarchy=new Mat(); List<MatOfPoint> contours=new ArrayList<>(); Imgproc.findContours(edges,contours,hierarchy,Imgproc.RETR_LIST,Imgproc.CHAIN_APPROX_SIMPLE);
                for(MatOfPoint c:contours){double peri=Imgproc.arcLength(new MatOfPoint2f(c.toArray()),true);MatOfPoint2f approx=new MatOfPoint2f();Imgproc.approxPolyDP(new MatOfPoint2f(c.toArray()),approx,Math.max(1,peri*0.015),true);Point[] ps=approx.toArray();if(ps.length>=3&&ps.length<=12&&Math.abs(Imgproc.contourArea(approx))>120){for(int i=1;i<ps.length;i++){try{JSONObject q=new JSONObject();q.put("type","line");q.put("x1",ps[i-1].x);q.put("y1",ps[i-1].y);q.put("x2",ps[i].x);q.put("y2",ps[i].y);q.put("source","opencv-contour");out.put(q);}catch(Exception ignored){}}if(ps.length>2){try{JSONObject q=new JSONObject();q.put("type","line");q.put("x1",ps[ps.length-1].x);q.put("y1",ps[ps.length-1].y);q.put("x2",ps[0].x);q.put("y2",ps[0].y);q.put("source","opencv-contour");out.put(q);}catch(Exception ignored){}}}approx.release();c.release();}
                lines.release();circles.release();hierarchy.release();
            } catch(Throwable ignored) { }
            finally {src.release();gray.release();edges.release();}
            return out;
        }

        @JavascriptInterface
        public String analyzeDocument(String base64, String mime, String pageString) {
            try {
                int page=1; try{page=Math.max(1,Integer.parseInt(pageString));}catch(Exception ignored){}
                Bitmap b;
                int pages=1;
                if(mime!=null && mime.toLowerCase().contains("pdf")) {
                    byte[] bytes=Base64.decode(base64,Base64.DEFAULT);
                    String vectorJson=analyzePdfVector(bytes,page);
                    File f=new File(context.getCacheDir(), "sq_pdf_count_" + UUID.randomUUID().toString() + ".pdf");
                    try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);}
                    try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer renderer=new PdfRenderer(fd)) { pages=renderer.getPageCount(); }
                    finally{try{f.delete();}catch(Exception ignored){}}
                    b=loadPdfPageFromBase64(base64,page);
                    String ocr=analyzeBitmap(b,pages); JSONObject vo=new JSONObject(vectorJson), oo=new JSONObject(ocr); JSONArray vl=vo.optJSONArray("lines"), ol=oo.optJSONArray("lines"), vt=vo.optJSONArray("texts"), ot=oo.optJSONArray("texts"); if(vl!=null&&ol!=null){for(int i=0;i<vl.length();i++)ol.put(vl.getJSONObject(i));} if(vt!=null&&ot!=null){for(int i=0;i<vt.length();i++)ot.put(vt.getJSONObject(i));} oo.put("pdfVector",true); return oo.toString();
                } else b=loadBitmapFromBase64(base64);
                try{ JSONObject root=new JSONObject(analyzeBitmap(b,pages)); JSONArray ll=root.optJSONArray("lines"), cc=new JSONArray(); JSONArray cv=detectOpenCVShapes(b); if(ll!=null&&cv!=null){for(int i=0;i<cv.length();i++){JSONObject q=cv.getJSONObject(i);if("circle".equalsIgnoreCase(q.optString("type")))cc.put(q);else ll.put(q);}} root.put("circles",cc); root.put("opencv",true); return root.toString(); }finally{b.recycle();}
            } catch(Exception e) { return "ERROR: " + (e.getMessage()==null?e.toString():e.getMessage()); }
        }

        @JavascriptInterface
        public String getPdfPageCount(String base64) {
            try {
                byte[] bytes=Base64.decode(base64,Base64.DEFAULT);
                File f=new File(context.getCacheDir(), "sq_pdf_count_" + UUID.randomUUID().toString() + ".pdf");
                try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);}
                try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer renderer=new PdfRenderer(fd)){return String.valueOf(renderer.getPageCount());}
                finally{try{f.delete();}catch(Exception ignored){}}
            }catch(Exception e){return "ERROR: "+e.getMessage();}
        }

        @JavascriptInterface
        public boolean openExternalUrl(String url) {
            try {
                if (url == null || url.trim().isEmpty()) return false;
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean notifyDownload(String filename, String uriString, String mime) {
            try {
                String name = (filename == null || filename.trim().isEmpty()) ? "SurveyQuant_Output" : filename;
                String type = (mime == null || mime.isEmpty()) ? "*/*" : mime;
                Intent open = new Intent(Intent.ACTION_VIEW);
                open.setDataAndType(Uri.parse(uriString), type);
                open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                int flags = android.os.Build.VERSION.SDK_INT >= 23 ?
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE :
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT;
                android.app.PendingIntent pending = android.app.PendingIntent.getActivity(context, Math.abs(name.hashCode()), open, flags);

                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm == null) return false;
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "تنزيلات SurveyQuant", NotificationManager.IMPORTANCE_DEFAULT);
                    ch.setDescription("إشعارات الملفات التي تم استخراجها من SurveyQuant");
                    nm.createNotificationChannel(ch);
                }
                NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                        .setSmallIcon(com.surveyquant.app.R.drawable.ic_surveyquant)
                        .setContentTitle("تم التنزيل")
                        .setContentText(name)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText("تم تنزيل الملف: " + name + "\nاضغط لفتحه."))
                        .setContentIntent(pending)
                        .setAutoCancel(true)
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setCategory(NotificationCompat.CATEGORY_PROGRESS);
                nm.notify(Math.abs((name + System.currentTimeMillis()).hashCode()), builder.build());
                return true;
            } catch(Exception e) { return false; }
        }

        @JavascriptInterface
        public boolean openFile(String uriString, String mime) {
            try {
                if(uriString==null || uriString.isEmpty()) return false;
                Intent i=new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(Uri.parse(uriString), mime==null||mime.isEmpty()?"*/*":mime);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
                return true;
            } catch(Exception e){ return false; }
        }
    }

    @Override public void onBackPressed(){
        if(web != null){
            web.evaluateJavascript("(function(){if(document.body.classList.contains('project-mode')){closeProjectPage();return 'PROJECT';}var p=document.getElementById('paymentPage');if(p&&p.style.display==='block'){closePaymentPage();return 'PAYMENT';}return '';})()", value -> {
                String v = value == null ? "" : value.replace("\"", "");
                if("PROJECT".equals(v) || "PAYMENT".equals(v)) return;
                if(web.canGoBack()) web.goBack(); else MainActivity.super.onBackPressed();
            });
        } else super.onBackPressed();
    }
}
