#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const file=process.argv[2];
if(!file)throw new Error('Usage: node SurveyQuant_v1.0.129_DELETE_UNDO_REDO_TEST.js <patched-index.html>');
const html=fs.readFileSync(file,'utf8');
for(const [needle,label] of [
  ['id="sq110SelectEntity"','explicit select button'],
  ['id="sq110Delete" class="sqori-preview" type="button">حذف المحدد','delete selected button'],
  ['id="sq110UndoDelete"','undo button'],
  ['id="sq110RedoDelete"','redo button'],
  ['function findNearestEntityBytes(input,world,tolerance,layerVisibility)','nearest selectable entity routine'],
  ['function removeSelectedEntityBytes(input,selected)','exact entity byte removal'],
  ['function deleteSelectedEntity()','delete-selected action'],
  ['function undoDelete(){if(!state.undoStack.length)return;','undo stack'],
  ['function redoDelete(){if(!state.redoStack.length)return;','redo stack'],
  ['sourceBytes===state.target?.bytes','selection bound to current source bytes'],
  ['state.undoStack.push(before);if(state.undoStack.length>100)state.undoStack.shift();state.redoStack=[]','bounded history and redo invalidation'],
  ['state.tool.target===\'selectEntity\'?\'pick\':\'selectEntity\'','select mode toggle'],
  ['v.zoom=Math.max(.15,Math.min(100000','unchanged high zoom support'],
  ['if(ext===\'dwg\')','native DWG reader remains present']
])assert(html.includes(needle),`missing ${label}`);
const preBoard=html.match(/<script id="sq-orientation-reference-board-module">([\s\S]*?)<\/script>/i);
assert(preBoard,'orientation board module was not found');
assert(!preBoard[1].includes('state.undoBytes=null;state.undoName=null;'),'old single-snapshot undo must be removed from orientation board module');
assert(html.includes('function setTool(side,tool){state.tool[side]=tool;if(tool!==\'selectEntity\')state.selectedEntity=null;'),'selection mode clears highlight when exited');
assert(html.includes('c.strokeStyle=\'#ff4fd8\';'),'selected element highlight overlay');

// Execute the actual orientation-board module and exercise entity pick/removal against a small DXF.
const match=preBoard;
const window={};
const document={readyState:'loading',addEventListener:()=>{},getElementById:()=>null,querySelector:()=>null,querySelectorAll:()=>[]};
const ctx={window,document,console,Uint8Array,ArrayBuffer,Map,Set,Math,Number,String,Object,RegExp,Error,Promise,Blob:global.Blob,URL:global.URL,TextEncoder,TextDecoder,performance:{now:()=>0},setTimeout,clearTimeout};
window.window=window;window.document=document;
vm.createContext(ctx);vm.runInContext(match[1],ctx,{timeout:5000});
const api=window.__sqOrientation110API;
assert(api&&typeof api.findNearestEntityBytes==='function'&&typeof api.removeSelectedEntityBytes==='function','runtime selection/delete API not exported');
const dxf=`0\nSECTION\n2\nENTITIES\n0\nLINE\n8\nROAD\n10\n0\n20\n0\n11\n10\n21\n0\n0\nLINE\n8\nDRAIN\n10\n0\n20\n2\n11\n10\n21\n2\n0\nTEXT\n8\nLABELS\n10\n5\n20\n4\n40\n1\n1\nTEST\n0\nENDSEC\n0\nEOF\n`;
const bytes=new TextEncoder().encode(dxf);
const selected=api.findNearestEntityBytes(bytes,{x:5,y:.2},1);
assert.equal(selected.type,'LINE');assert.equal(selected.layer,'ROAD');
const hiddenLayerSelection=api.findNearestEntityBytes(bytes,{x:5,y:0},3,{ROAD:false,DRAIN:true,LABELS:true});
assert.equal(hiddenLayerSelection.layer,'DRAIN','hidden layers must not take click selection');
const removed=api.removeSelectedEntityBytes(bytes,selected);
const expected=new Uint8Array([...bytes.slice(0,selected.start),...bytes.slice(selected.end)]);
assert.deepEqual(Array.from(removed.bytes),Array.from(expected),'delete must remove only the selected raw entity byte range');
const out=new TextDecoder().decode(removed.bytes);
assert(out.includes('DRAIN')&&out.includes('TEST'),'non-selected entities must remain');
assert(!out.includes('ROAD'),'selected entity must be removed');
const altered=bytes.slice();altered[selected.start+4]^=1;
assert.throws(()=>api.removeSelectedEntityBytes(altered,selected),/تغيرت اللوحة بعد التحديد/,'stale selections must fail safely');
assert.equal(bytes.length,new TextEncoder().encode(dxf).length,'source buffer was mutated');
console.log('PASS V129: visible entity selection by tap; selected layer/type data; exact selected entity removal; other entity bytes preserved; hidden layers skipped; stale selection blocked; undo/redo buttons and stacks wired.');
