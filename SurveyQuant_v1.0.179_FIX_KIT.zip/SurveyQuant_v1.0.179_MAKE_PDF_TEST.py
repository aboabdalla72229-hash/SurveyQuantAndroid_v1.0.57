from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from pathlib import Path
p=Path('V179_ARCHITECTURAL_TEST.pdf')
c=canvas.Canvas(str(p),pagesize=A4)
# Four wall outlines and one structural-column outline, all white filled with black stroke.
c.setLineWidth(1.25); c.setStrokeColorRGB(0,0,0); c.setFillColorRGB(1,1,1)
for x,y,w,h in [(70,700,360,18),(70,500,18,200),(412,500,18,200),(70,500,360,18),(220,590,34,34)]:
    c.rect(x,y,w,h,stroke=1,fill=1)
c.setFillColorRGB(0,0,0); c.setFont('Helvetica',11); c.drawString(210,735,'C-LEVEL OFFICE')
c.drawString(75,465,'ARCHITECTURAL TEST - WALLS AND COLUMNS')
c.showPage(); c.save()
print(f'PASS created {p} ({p.stat().st_size} bytes)')
