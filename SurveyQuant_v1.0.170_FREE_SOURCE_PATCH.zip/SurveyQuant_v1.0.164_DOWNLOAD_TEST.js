'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const html=fs.readFileSync(process.argv[2],'utf8');
function extract(source,marker){
 const start=source.indexOf(marker);assert.ok(start>=0,'missing '+marker);const open=source.indexOf('{',start);let depth=0,quote=null,escaped=false,line=false,block=false;
 for(let i=open;i<source.length;i++){const c=source[i],n=source[i+1]||'';
  if(line){if(c==='\n')line=false;continue;}
  if(block){if(c==='*'&&n==='/'){block=false;i++;}continue;}
  if(quote){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c===quote)quote=null;continue;}
  if(c==='/'&&n==='/'){line=true;i++;continue;}if(c==='/'&&n==='*'){block=true;i++;continue;}
  if(c==='\''||c==='"'||c==='`'){quote=c;continue;}
  if(c==='{')depth++;else if(c==='}'&&--depth===0)return source.slice(start,i+1);
 }
 throw new Error('unclosed '+marker);
}
const chooser=extract(html,'function chooseDownloadFilename(original){');
const safeStart=html.indexOf('async function safeDownloadFile(');const safeEnd=html.indexOf('\nfunction num(',safeStart);assert.ok(safeStart>=0&&safeEnd>safeStart);const safe=html.slice(safeStart,safeEnd);
const calls={saved:[],notified:[]};
const Android={
 saveFile(name,mime,b64){calls.saved.push({name,mime,b64});return 'Downloads/SurveyQuant/'+name;},
 notifyDownload(name,path,mime){calls.notified.push({name,path,mime});}
};
class FakeFileReader{readAsDataURL(blob){blob.arrayBuffer().then(b=>{this.result='data:'+blob.type+';base64,'+Buffer.from(b).toString('base64');this.onload();}).catch(e=>{this.error=e;this.onerror();});}}
const document={getElementById(){return null;}};
const context={
 window:{Android},document,Blob,FileReader:FakeFileReader,URL,setTimeout:fn=>{fn();return 1;},
 chooseDownloadFilename:async()=> 'مخطط_نهائي.dxf',
 showDownloadStatus(){},escapeHtml:s=>String(s),console,Buffer,
};
vm.createContext(context);
vm.runInContext(safe,context);
(async()=>{
 const result=await context.safeDownloadFile(new TextEncoder().encode('0\nEOF\n'),'Suggested.dxf','application/dxf',false);
 assert.equal(result,'Downloads/SurveyQuant/مخطط_نهائي.dxf');
 assert.equal(calls.saved.length,1);assert.equal(calls.saved[0].name,'مخطط_نهائي.dxf');
 assert.equal(calls.saved[0].mime,'application/dxf');assert.ok(calls.saved[0].b64.length>0);
 assert.equal(calls.notified.length,1);assert.equal(calls.notified[0].name,'مخطط_نهائي.dxf');assert.equal(calls.notified[0].path,result);
 console.log('PASS V164 download integration: selected filename is written by Android.saveFile to Downloads/SurveyQuant and Android.notifyDownload fires after success.');
})().catch(e=>{console.error(e);process.exit(1);});
