#!/usr/bin/env python3
"""V126: fix the shared DWG file bridge while preserving the V117 orientation implementation."""
from pathlib import Path
import re
import sys

OLD_API_LIST = "var apis = [window.__sqOrientation115Tools, window.__sqOrientation113API, window.__sqOrientation111API];"
NEW_API_LIST = "var apis = [window.__sqOriAxisAutoTest, window.__sqOrientation115Tools, window.__sqOrientation113API, window.__sqOrientation111API];"
BRIDGE_ID = "sq-v117-universal-dwg-bridge"

if len(sys.argv) != 3:
    raise SystemExit("usage: SurveyQuant_v1.0.126_DWG_IMPORT_PATCH.py V117_BRIDGE.js INDEX_PATH.html")

bridge_path, html_path = map(Path, sys.argv[1:])
bridge_original = bridge_path.read_text(encoding="utf-8")
html_original = html_path.read_text(encoding="utf-8")

# Change only the converter lookup in the V117 universal input bridge.
old_count = bridge_original.count(OLD_API_LIST)
new_count = bridge_original.count(NEW_API_LIST)
if old_count == 1 and new_count == 0:
    bridge = bridge_original.replace(OLD_API_LIST, NEW_API_LIST, 1)
elif old_count == 0 and new_count == 1:
    bridge = bridge_original  # safe to re-run
else:
    raise SystemExit(f"ERROR: expected one V117 converter lookup, old={old_count}, fixed={new_count}; refusing an ambiguous edit.")

# Keep non-CAD point-list importers (TXT/CSV/SDR/PNT) from being accidentally offered DWG.
# CAD-capable file inputs are those that already accept DXF/DWG, or are known CAD board inputs.
old_add = '''  function addAcceptedTypes(input) {
    if (!input || String(input.tagName || '').toLowerCase() !== 'input' ||
        String(input.type || '').toLowerCase() !== 'file') return;
    var current = String(input.accept || '').split(',').map(function (item) {
      return item.trim();
    }).filter(Boolean);
    ACCEPT_TYPES.forEach(function (item) {
      if (!current.some(function (existing) { return existing.toLowerCase() === item.toLowerCase(); })) {
        current.push(item);
      }
    });
    input.accept = current.join(',');
  }'''
new_add = '''  var CAD_INPUT_IDS = new Set([
    'concreteDxfInput', 'quantBeforeFile', 'quantAfterFile', 'quantFileInput',
    'profileFileInput', 'dropSurveyFiles', 'dropCadFile',
    'sqOriReferenceFile', 'sqOriTargetFile', 'sq108File',
    'sq110TargetFile', 'sq110ReferenceFile'
  ]);
  var NON_CAD_DATA_IDS = new Set(['fileToDxfInput', 'cleanFilesInput']);

  function isCadInput(input) {
    if (!input || String(input.tagName || '').toLowerCase() !== 'input' ||
        String(input.type || '').toLowerCase() !== 'file') return false;
    var id = String(input.id || '');
    if (NON_CAD_DATA_IDS.has(id)) return false;
    if (CAD_INPUT_IDS.has(id)) return true;
    var current = String(input.accept || '').split(',').map(function (item) {
      return item.trim().toLowerCase();
    }).filter(Boolean);
    return current.some(function (item) {
      return item === '.dxf' || item === '.dwg' || /(^|\\/)vnd\\.dwg$/.test(item) ||
        item === 'application/dxf' || item === 'application/x-dxf' ||
        item === 'application/acad' || item === 'application/x-acad';
    });
  }

  function addAcceptedTypes(input) {
    if (!isCadInput(input)) return;
    var current = String(input.accept || '').split(',').map(function (item) {
      return item.trim();
    }).filter(Boolean);
    ACCEPT_TYPES.forEach(function (item) {
      if (!current.some(function (existing) { return existing.toLowerCase() === item.toLowerCase(); })) {
        current.push(item);
      }
    });
    input.accept = current.join(',');
  }'''
add_count = bridge.count(old_add)
if add_count == 1:
    bridge = bridge.replace(old_add, new_add, 1)
elif add_count != 0:
    raise SystemExit(f"ERROR: expected at most one addAcceptedTypes body, found {add_count}.")
# If already patched, idempotence requires the exact CAD scope block.
if 'var CAD_INPUT_IDS = new Set([' not in bridge or 'function isCadInput(input)' not in bridge:
    raise SystemExit("ERROR: failed to install CAD-input scope guard.")

old_change_guard = """    if (!input || String(input.tagName || '').toLowerCase() !== 'input' ||
        String(input.type || '').toLowerCase() !== 'file') return;
    var files = Array.prototype.slice.call(input.files || []);"""
new_change_guard = """    if (!isCadInput(input)) return;
    var files = Array.prototype.slice.call(input.files || []);"""
cc = bridge.count(old_change_guard)
if cc == 1:
    bridge = bridge.replace(old_change_guard, new_change_guard, 1)
elif cc == 0 and bridge.count(new_change_guard) == 1:
    pass
else:
    raise SystemExit(f"ERROR: cannot scope the file-change interceptor safely (old={cc}, fixed={bridge.count(new_change_guard)}).")

# Verify the real converter is included in the integrated app and declared before the bridge.
converter_token = 'window.__sqOriAxisAutoTest={detectIntersections:sqOriDetectIntersections,matchIntersections:sqOriMatchIntersections,convertTargetToDxf:sqOriConvertTargetToDxf}'
if converter_token not in html_original:
    # Actual V116 module may minify spaces; accept equivalent explicit export only.
    if not re.search(r'window\.__sqOriAxisAutoTest\s*=\s*\{[^}]*convertTargetToDxf\s*:\s*sqOriConvertTargetToDxf', html_original):
        raise SystemExit("ERROR: app does not expose the known DWG converter; refusing to install a bridge that cannot convert.")

pattern = re.compile(r'(<script id="' + re.escape(BRIDGE_ID) + r'">)([\s\S]*?)(</script>)', re.I)
matches = list(pattern.finditer(html_original))
if len(matches) != 1:
    raise SystemExit(f"ERROR: expected exactly one embedded V117 bridge, found {len(matches)}. Apply the original V117 patch first.")
match = matches[0]
# The converter export must occur before the app-wide bridge code runs.
if html_original.find('window.__sqOriAxisAutoTest') > match.start():
    raise SystemExit("ERROR: DWG converter is declared after the shared bridge; script order is invalid.")
html = html_original[:match.start(2)] + "\n" + bridge.rstrip() + "\n" + html_original[match.end(2):]

# Prove this patch touched no HTML outside the shared bridge script.
check = pattern.search(html)
if not check or len(list(pattern.finditer(html))) != 1:
    raise SystemExit("ERROR: embedded shared bridge is missing or duplicated after patch.")
if html[:check.start(2)] != html_original[:match.start(2)] or html[check.end(2):] != html_original[match.end(2):]:
    raise SystemExit("ERROR: V126 changed content outside the DWG bridge; refusing to alter orientation/project logic.")
if html[check.start(2):check.end(2)].strip() != bridge.strip():
    raise SystemExit("ERROR: embedded bridge differs from the standalone tested bridge.")
if bridge.count(NEW_API_LIST) != 1:
    raise SystemExit("ERROR: actual __sqOriAxisAutoTest DWG converter is not first in the converter lookup.")
if "input.__sqV117DwgBusy" not in bridge or "new DataTransfer()" not in bridge or "MutationObserver" not in bridge:
    raise SystemExit("ERROR: original V117 all-input conversion and dynamic-input support was unexpectedly removed.")

bridge_path.write_text(bridge, encoding="utf-8")
html_path.write_text(html, encoding="utf-8")
print("PASS V126: DWG converter lookup now calls the application's real __sqOriAxisAutoTest.convertTargetToDxf API.")
print("PASS V126: DXF/DWG-enabled board inputs across the app accept DWG; TXT/CSV/SDR/PNT-only importers stay scoped to their own formats.")
print("PASS V126: only the universal DWG bridge block changed; orientation modules and all other HTML are byte-identical to V117 output.")
