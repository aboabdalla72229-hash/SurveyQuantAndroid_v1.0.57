from pathlib import Path
from playwright.sync_api import sync_playwright
import shutil,json
import ezdxf, ezdxf.recover
root=Path(__file__).resolve().parent
html=(root/'index.html').read_text(encoding='utf-8')
with sync_playwright() as p:
 chrome=shutil.which('chromium') or shutil.which('chromium-browser')
 opts={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
 if chrome: opts['executable_path']=chrome
 b=p.chromium.launch(**opts)
 page=b.new_page(viewport={'width':430,'height':900})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded',timeout=60000)
 page.evaluate("window.__saved={};window.Android={saveFile:(n,m,b)=>{window.__saved[n]={mime:m,base64:b};return 'Downloads/'+n;},notifyDownload:()=>{}}")
 page.locator('#sq176-home-orientation-project').click();page.wait_for_timeout(300)
 assert page.locator('#sq162-oriented-canvas').evaluate('c=>c._sqMap===null'), 'oriented preview must start empty'
 page.locator('#sq162-source-file').set_input_files(str(root/'source_v184.dxf'))
 page.wait_for_function("document.querySelector('#sq162-source-info').textContent.includes('بصمة CAD')",timeout=30000)
 page.locator('#sq162-target-file').set_input_files(str(root/'target_v184.dxf'))
 page.wait_for_function("document.querySelector('#sq162-target-info').textContent.includes('بصمة CAD')",timeout=30000)
 page.locator('[data-sq-snap="source"]').select_option('endpoint')
 page.locator('[data-sq-snap="target"]').select_option('endpoint')
 def pick(slot,canvas_id,xy):
  page.locator(f'#sq162-pick-{slot}').click()
  pos=page.locator(f'#{canvas_id}').evaluate("(c,xy)=>{const m=c._sqMap;const p=m.pt({x:xy[0],y:xy[1]});const r=c.getBoundingClientRect();return {x:r.left+p.x,y:r.top+p.y,map:{which:m.which,geom:m.geom}}}",xy)
  page.mouse.click(pos['x'],pos['y']);page.wait_for_timeout(150)
 pick(0,'sq162-source-canvas',[0,0]);pick(1,'sq162-source-canvas',[10,0])
 pick(2,'sq162-target-canvas',[100,100]);pick(3,'sq162-target-canvas',[100,120])
 assert not page.locator('#sq162-do-align').is_disabled(), 'align button did not enable'
 page.locator('#sq162-do-align').click();page.wait_for_timeout(500)
 source=page.locator('#sq162-source-canvas').evaluate("c=>c._sqMap&&({which:c._sqMap.which,bounds:[c._sqMap.geom.minX,c._sqMap.geom.minY,c._sqMap.geom.maxX,c._sqMap.geom.maxY],fp:c._sqMap.boardFingerprint})")
 target=page.locator('#sq162-target-canvas').evaluate("c=>c._sqMap&&({which:c._sqMap.which,bounds:[c._sqMap.geom.minX,c._sqMap.geom.minY,c._sqMap.geom.maxX,c._sqMap.geom.maxY],fp:c._sqMap.boardFingerprint})")
 oriented=page.locator('#sq162-oriented-canvas').evaluate("c=>c._sqMap&&({which:c._sqMap.which,bounds:[c._sqMap.geom.minX,c._sqMap.geom.minY,c._sqMap.geom.maxX,c._sqMap.geom.maxY],fp:c._sqMap.boardFingerprint})")
 status=page.locator('#sq162-align-status').inner_text()
 print(json.dumps({'source':source,'target':target,'oriented':oriented,'status':status,'page_errors':errors[:10]},ensure_ascii=False,indent=2))
 assert source['which']=='source' and source['bounds']==[0,0,10,5],source
 assert target['which']=='target' and target['bounds']==[90,100,100,120],target
 assert oriented and oriented['which']=='oriented' and oriented['bounds'] != source['bounds'],oriented
 assert oriented['fp']==source['fp'] and target['fp']!=source['fp']
 page.locator('#sq162-save-oriented').click();page.wait_for_function('Object.keys(window.__saved).length>0',timeout=30000)
 import base64
 saved=page.evaluate('window.__saved'); filename=list(saved)[0]; out=str(root/'V184_ORIENTED_RESULT.dxf');open(out,'wb').write(base64.b64decode(saved[filename]['base64']))
 doc,rec=ezdxf.recover.readfile(out);audit=doc.audit();msp=doc.modelspace()
 assert doc.dxfversion=='AC1018' and len(msp)>0 and not audit.errors and not audit.fixes,(doc.dxfversion,len(msp),audit.errors,audit.fixes)
 # Loading another reference board must invalidate the previous oriented preview and retain the original source.
 alt=ezdxf.new('R2004');alt.modelspace().add_lwpolyline([(500,600),(510,600),(510,610),(500,610)],close=True);alt.saveas(root/'target_reset_v184.dxf')
 page.locator('#sq162-target-file').set_input_files(str(root/'target_reset_v184.dxf'))
 page.wait_for_function("document.querySelector('#sq162-target-info').textContent.includes('target_reset_v184.dxf')",timeout=30000)
 page.wait_for_timeout(200)
 source_after=page.locator('#sq162-source-canvas').evaluate("c=>c._sqMap&&[c._sqMap.geom.minX,c._sqMap.geom.minY,c._sqMap.geom.maxX,c._sqMap.geom.maxY]")
 target_after=page.locator('#sq162-target-canvas').evaluate("c=>c._sqMap&&[c._sqMap.geom.minX,c._sqMap.geom.minY,c._sqMap.geom.maxX,c._sqMap.geom.maxY]")
 oriented_after=page.locator('#sq162-oriented-canvas').evaluate('c=>c._sqMap')
 assert source_after==[0,0,10,5],source_after;assert target_after==[500,600,510,610],target_after;assert oriented_after is None,oriented_after
 report={'result':'PASS V184 orientation UI separation, saved R2004 DXF and stale-result invalidation','source_canvas_bounds':source['bounds'],'target_canvas_bounds':target['bounds'],'oriented_canvas_bounds':oriented['bounds'],'alignment':'rotation=90 degrees; scale=2; residual=0','saved_file':Path(out).name,'saved_entities':len(msp),'saved_dxf_version':doc.dxfversion,'audit_errors':len(audit.errors),'audit_fixes':len(audit.fixes),'after_reference_reload':{'source':source_after,'target':target_after,'oriented_preview_cleared':oriented_after is None},'page_errors':errors[:10]}
 (root/'V184_ORIENTATION_TEST_LOG.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 print(json.dumps(report,ensure_ascii=False,indent=2))
 b.close()
