'use strict';
const assert=require('assert'),fs=require('fs'),vm=require('vm');
const src=fs.readFileSync(process.argv[2] || '/tmp/sqfix/SurveyQuant_v1.0.107_ORIENTATION_AXIS_READER_PATCH.js','utf8');
const window={addEventListener(){}};const document={readyState:'loading',addEventListener(){}};
vm.runInNewContext(src,{window,document,Uint8Array,TextEncoder,Blob,URL,Math,Number,String,Map,Set,Array,Error},{filename:'v107'});
const api=window.__sqOriAxisAutoTest;assert(api&&api.detectIntersections,'axis reader test API missing');
function model(transform){
 const pt=(x,y)=>transform?transform(x,y):({x,y});
 const entities=[];
 for(const x of [0,10])entities.push({type:'LINE',layer:'GRID',a:pt(x,0),b:pt(x,10)});
 for(const y of [0,10])entities.push({type:'LINE',layer:'GRID',a:pt(0,y),b:pt(10,y)});
 for(const [label,x] of [['A',0],['B',10]]){const p=pt(x,-0.5);entities.push({type:'TEXT',layer:'BUBBLES',position:p,text:label,height:0.5});}
 for(const [label,y] of [['1',0],['2',10]]){const p=pt(-0.5,y);entities.push({type:'TEXT',layer:'BUBBLES',position:p,text:label,height:0.5});}
 return {source:'DXF',entities};
}
const ref=model((x,y)=>({x:-100-2*y,y:300+2*x}));
const srcM=model();
const result=api.matchIntersections(ref,srcM);
console.log('ref',result.ref.intersections.size,'src',result.src.intersections.size,'matches',result.matches.map(x=>x.key),'best',result.best&&result.best.distance,'families',result.ref.families,result.src.families);
assert(result.ref.intersections.size>=4,'did not detect reference grid intersections');
assert(result.src.intersections.size>=4,'did not detect source grid intersections');
assert(result.matches.length>=4,'did not match shared grid labels');
assert(result.best&&result.best.distance>10,'did not choose well-separated control points');
console.log('PASS: axis line families, labeled intersections, and common anchors.');
