#!/usr/bin/env python3
"""Patch the v111/v113 orientation modules without changing unrelated projects."""
from pathlib import Path
import re, sys
if len(sys.argv) != 6:
    raise SystemExit('usage: APPLY_PATCH.py index.html axis-module.js reference-module.js preserve-module.js writer_git_sha')
index_path, axis_path, reference_path, preserve_path = map(Path, sys.argv[1:5])
writer_sha = sys.argv[5].strip()
if not re.fullmatch(r'[0-9a-f]{40}', writer_sha):
    raise SystemExit('ERROR: writer engine commit SHA is invalid')

def sub_once(src, old, new, label):
    count = src.count(old)
    if count != 1:
        raise SystemExit(f'ERROR: expected exactly one anchor for {label}, found {count}')
    return src.replace(old, new, 1)

ref = reference_path.read_text(encoding='utf-8')
# Expose the final live UI state to the additive auto-axis module.
ref = sub_once(ref, 'window.__sqOrientation111API=window.__sqOrientation110API;',
    'window.__sqOrientation111API=Object.assign(window.__sqOrientation110API,{state,loadView,fillReadouts,draw,calculation,exportTarget,status,showScreen,updatePickLabels,nearestSnap,metrics,project,unproject});', 'live orientation API')
# Fix legacy POLYLINE handling: transform VERTEX coordinate records, not the dummy parent point.
old = "  const by=new Map();for(const x of p){if(!by.has(x.code))by.set(x.code,[]);by.get(x.code).push(x);}\n  let entityChanged=false;"
new = "  const by=new Map();for(const x of p){if(!by.has(x.code))by.set(x.code,[]);by.get(x.code).push(x);}\n  const pairOwner=new Map();if(rec.type==='POLYLINE'){let owner='POLYLINE';for(const item of p){if(item.code===0)owner=String(item.value||'').toUpperCase();pairOwner.set(item.index,owner);}}\n  let entityChanged=false;"
ref = sub_once(ref, old, new, 'legacy polyline vertex ownership')
ref = sub_once(ref, "if(rec.type==='POLYLINE'&&xc===10)continue;", "if(rec.type==='POLYLINE'&&pairOwner.get(xs[j].index)!=='VERTEX')continue;", 'legacy polyline vertex transform')
# Raise practical zoom limit from 120 to 5000 in pinch, wheel, and toolbar handlers.
ref = ref.replace('Math.min(120,', 'Math.min(5000,')
# Enlarge the drawings on a phone screen.
ref = ref.replace('height:340px;border:1px solid #42536b', 'height:520px;min-height:520px;border:1px solid #42536b')
# Add zoom multiplier and log slider / OSNAP mode selectors on both boards.
target_anchor = '<button id="sq110TZoomIn" class="sqori-preview" type="button">تكبير +</button>'
target_controls = target_anchor + '<button id="sq110TZoomBoost" class="sqori-preview" type="button">تكبير ×5</button><input id="sq110TZoomRange" type="range" min="-0.8" max="3.7" step="0.01" value="0" aria-label="تكبير دقيق حتى 5000 مرة" style="width:120px"><select id="sq110TSnapMode" aria-label="وضع التقاط النقاط"><option value="auto">OSNAP تلقائي</option><option value="intersection">تقاطع فقط</option><option value="endpoint">رأس / نهاية</option><option value="midpoint">منتصف</option><option value="nearest">أقرب نقطة على الخط</option><option value="perpendicular">عمود على الخط</option><option value="free">نقرة حرة</option></select>'
ref_anchor = '<button id="sq110RZoomIn" class="sqori-preview" type="button">تكبير +</button>'
ref_controls = ref_anchor + '<button id="sq110RZoomBoost" class="sqori-preview" type="button">تكبير ×5</button><input id="sq110RZoomRange" type="range" min="-0.8" max="3.7" step="0.01" value="0" aria-label="تكبير دقيق حتى 5000 مرة" style="width:120px"><select id="sq110RSnapMode" aria-label="وضع التقاط النقاط"><option value="auto">OSNAP تلقائي</option><option value="intersection">تقاطع فقط</option><option value="endpoint">رأس / نهاية</option><option value="midpoint">منتصف</option><option value="nearest">أقرب نقطة على الخط</option><option value="perpendicular">عمود على الخط</option><option value="free">نقرة حرة</option></select>'
ref = sub_once(ref, target_anchor, target_controls, 'target board snap/zoom controls')
ref = sub_once(ref, ref_anchor, ref_controls, 'reference board snap/zoom controls')
ref = sub_once(ref, "tool:{target:'pick',reference:'pick'},views:{},undoBytes:null", "tool:{target:'pick',reference:'pick'},snapMode:{target:'auto',reference:'auto'},views:{},undoBytes:null", 'snap mode state')
# Export can still proceed after coordinate edit / diagnostic.
nearest = r"function nearestSnap\(v,world,screen\)\{.*?\}\nfunction fillReadouts"
replacement = r'''function nearestSnap(v,world,screen){
 const mode=state.snapMode?.[v.side]||'auto',api=window.__sqManualOrientation109,m=metrics(v),segs=v.drawing.segs,projector=p=>project(v,p,m);
 if(mode==='free')return {p:world,kind:'نقرة حرة'};
 let cross=null;if((mode==='auto'||mode==='intersection')&&api&&typeof api.findNearestIntersection==='function')cross=api.findNearestIntersection(segs,screen,projector,48);
 if(cross)return {p:cross.point,kind:'تقاطع OSNAP'};if(mode==='intersection')return null;
 let best=null;const test=(p,kind,limit=44)=>{const q=projector(p),d=Math.hypot(q.x-screen.x,q.y-screen.y);if(d<=limit&&(!best||d<best.d))best={p,d,kind};};
 if(mode==='auto'||mode==='endpoint'){for(const p of v.drawing.anchors)test(p,'رأس/نهاية',42);if(mode==='endpoint')return best&&{p:best.p,kind:best.kind};}
 if(mode==='midpoint'){for(const s of segs)test({x:(s.a.x+s.b.x)/2,y:(s.a.y+s.b.y)/2},'منتصف',46);return best&&{p:best.p,kind:best.kind};}
 if(mode==='auto'||mode==='nearest'||mode==='perpendicular')for(const s of segs){const a=s.a,b=s.b,dx=b.x-a.x,dy=b.y-a.y,d=dx*dx+dy*dy;if(d<1e-20)continue;let u=((world.x-a.x)*dx+(world.y-a.y)*dy)/d;if(mode==='perpendicular'&&(u<0||u>1))continue;u=Math.max(0,Math.min(1,u));test({x:a.x+u*dx,y:a.y+u*dy},mode==='perpendicular'?'عمود على الخط':'أقرب نقطة على الخط',44);}
 return best?{p:best.p,kind:best.kind}:null;
}
function fillReadouts'''
ref, n = re.subn(nearest, replacement, ref, count=1, flags=re.S)
if n != 1: raise SystemExit('ERROR: nearestSnap patch anchor not found')
# Keep XY coordinate readouts editable after selecting a point, as a second precision method.
for ident in ['sq110T1X','sq110T1Y','sq110R1X','sq110R1Y','sq110T2X','sq110T2Y','sq110R2X','sq110R2Y']:
    ref = sub_once(ref, f'<input readonly id="{ident}" style="width:100%">', f'<input type="number" step="any" inputmode="decimal" id="{ident}" style="width:100%">', ident+' editable')
# Set zoom about the canvas centre without shifting the picked point.
anchor = 'function resetView(v){v.zoom=1;v.panX=0;v.panY=0;v.pointerMap.clear();v.mode=\'\';v.drag=null;v.pinch=null;}'
zoom_fn = anchor + "\nfunction setZoom(side,value){const v=state.views[side];if(!v)return;const m=metrics(v),pt={x:m.w/2,y:m.h/2},world=unproject(v,pt,m);v.zoom=Math.max(.1584893,Math.min(5000,Number(value)||1));const n=metrics(v);v.panX=pt.x-n.w/2-(world.x-n.cx)*n.scale;v.panY=pt.y-n.h/2+(world.y-n.cy)*n.scale;const slider=el(side==='target'?'sq110TZoomRange':'sq110RZoomRange');if(slider)slider.value=String(Math.log10(v.zoom));draw(v);}"
ref = sub_once(ref, anchor, zoom_fn, 'centre-based zoom helper')
old_loop = "for(const [side,prefix] of [['target','T'],['reference','R']]){el('sq110'+prefix+'ZoomIn').addEventListener('click',()=>{const v=state.views[side];if(v){v.zoom=Math.min(5000,v.zoom*1.5);draw(v);}});el('sq110'+prefix+'ZoomOut').addEventListener('click',()=>{const v=state.views[side];if(v){v.zoom=Math.max(.15,v.zoom/1.5);draw(v);}});el('sq110'+prefix+'Fit').addEventListener('click',()=>{const v=state.views[side];if(v){resetView(v);draw(v);}});el('sq110'+prefix+'Id').addEventListener('click',()=>setTool(side,state.tool[side]==='id'?'pick':'id'));}"
new_loop = "for(const [side,prefix] of [['target','T'],['reference','R']]){el('sq110'+prefix+'ZoomIn').addEventListener('click',()=>{const v=state.views[side];if(v)setZoom(side,v.zoom*1.5);});el('sq110'+prefix+'ZoomOut').addEventListener('click',()=>{const v=state.views[side];if(v)setZoom(side,v.zoom/1.5);});el('sq110'+prefix+'ZoomBoost').addEventListener('click',()=>{const v=state.views[side];if(v)setZoom(side,v.zoom*5);});el('sq110'+prefix+'ZoomRange').addEventListener('input',e=>setZoom(side,Math.pow(10,Number(e.target.value))));el('sq110'+prefix+'SnapMode').addEventListener('change',e=>{state.snapMode[side]=e.target.value;updatePickLabels();status('وضع الالتقاط للوحة '+(side==='target'?'غير الموجهة':'المرجعية')+': '+e.target.options[e.target.selectedIndex].text+'.');});el('sq110'+prefix+'Fit').addEventListener('click',()=>{const v=state.views[side];if(v){resetView(v);setZoom(side,1);}});el('sq110'+prefix+'Id').addEventListener('click',()=>setTool(side,state.tool[side]==='id'?'pick':'id'));}"
ref = sub_once(ref, old_loop, new_loop, 'zoom/snap listeners')
# Attach coordinate editors after canvases have supplied an initial snap, then preserve higher precision internally.
coord_hook = "el('sq110Delete').addEventListener('click',()=>setTool('target',state.tool.target==='delete'?'pick':'delete'));"
coord_code = "for(const [id,side,i,axis] of [['sq110T1X','target',0,'x'],['sq110T1Y','target',0,'y'],['sq110T2X','target',1,'x'],['sq110T2Y','target',1,'y'],['sq110R1X','reference',0,'x'],['sq110R1Y','reference',0,'y'],['sq110R2X','reference',1,'x'],['sq110R2Y','reference',1,'y']]){el(id).addEventListener('change',()=>{const x=Number(el('sq110'+(side==='target'?'T':'R')+(i+1)+'X').value),y=Number(el('sq110'+(side==='target'?'T':'R')+(i+1)+'Y').value);if(!Number.isFinite(x)||!Number.isFinite(y))return;const pts=side==='target'?state.targetPoints:state.referencePoints;pts[i]={...(pts[i]||{}),x,y,kind:'إحداثيات معدلة يدويًا'};const v=state.views[side];if(v)draw(v);status('تم تحديث إحداثيات النقطة '+(i+1)+' يدويًا بدقة الإدخال.');});} " + coord_hook
ref = sub_once(ref, coord_hook, coord_code, 'manual coordinate editors')
# Replace v113 preservation layer's export vetoes by diagnostics. Parser / transform errors remain visible; audit-only differences never prevent download.
pres = preserve_path.read_text(encoding='utf-8')
start = pres.find('  function safeTransform(input, transform) {')
end = pres.find('\n  ENGINE.transformBytes = safeTransform;', start)
if start < 0 or end < 0: raise SystemExit('ERROR: cannot locate v113 safeTransform')
safe = '''  function safeTransform(input, transform) {
    const original = asBytes(input);
    const normalized = normalizeBlankPairLines(original);
    const working = normalized.valid ? normalized.bytes : original;
    // Preservation checks are diagnostics only: they must never veto an otherwise
    // generated export. The original input remains untouched in memory.
    const result = originalTransform(working, transform);
    if (!result || !result.bytes) throw new Error('لم ينتج محرك التوجيه ملف DXF.');
    let before = null, after = null;
    try { before = structureFingerprint(working); } catch (_) {}
    try { after = structureFingerprint(result.bytes); } catch (_) {}
    result.v115Diagnostics = {
      blankLineRepairPossible: !!normalized.valid,
      blankLinesNormalized: normalized.changed || 0,
      validationAvailable: !!(before && after),
      entityCountBefore: before ? before.entityCount : null,
      entityCountAfter: after ? after.entityCount : null,
      entityCountChanged: !!(before && after && before.entityCount !== after.entityCount),
      typeCountsChanged: !!(before && after && before.types !== after.types),
      layerAssignmentsChanged: !!(before && after && before.layers !== after.layers),
      textContentChanged: !!(before && after && before.text !== after.text),
      recoveredBoundaries: result.repairedBoundaries || 0,
      recoveredMalformedRows: result.repairedMalformedRows || 0
    };
    stats.lastExportValidation = result.v115Diagnostics;
    return result;
  }'''
pres = pres[:start] + safe + pres[end:]
# Do not reject preview solely because the conservative blank-line normalizer was unsure.
start = pres.find('  MANUAL.parseDrawing = function parseDrawingWithStrictPairs(input) {')
end = pres.find('\n\n  // Existing renderer covers standard survey entities', start)
if start < 0 or end < 0: raise SystemExit('ERROR: cannot locate v113 strict preview parser')
parse_override = '''  MANUAL.parseDrawing = function parseDrawingWithRecovery(input) {
    const original = asBytes(input);
    const normalized = normalizeBlankPairLines(original);
    const working = normalized.valid ? normalized.bytes : original;
    const model = originalManualParse(working);
    if (normalized.changed) {
      model.__sqDxfNormalization113 = { blankLinesRemoved: normalized.changed };
      model.previewWarning = 'تمت معالجة ' + normalized.changed + ' سطر فارغ زائد في نسخة القراءة فقط؛ بيانات الملف الأصلي لم تتغير.';
      stats.blankLinesNormalized += normalized.changed;
      stats.lastNormalization = { blankLinesRemoved: normalized.changed, originalBytes: original.length, normalizedBytes: working.length };
    } else if (!normalized.valid) {
      model.previewWarning = (model.previewWarning ? model.previewWarning + ' | ' : '') + 'المعاينة استخدمت قارئ الاستعادة لأن تنسيق بعض أزواج DXF غير قياسي؛ لم يتم تعديل الأصل.';
    }
    try { addUnrenderedEntities(model, working); } catch (e) {
      model.previewWarning = (model.previewWarning ? model.previewWarning + ' | ' : '') + 'بعض العناصر الخاصة لم تدخل المعاينة؛ بياناتها تبقى ضمن الملف المصدر: ' + String(e.message || e);
    }
    return model;
  };'''
pres = pres[:start] + parse_override + pres[end:]
# Swap the read-only CDN WASM for the writer-enabled version built and tested by this workflow.
idx = index_path.read_text(encoding='utf-8')
loader_old = "async function loadDWG(){\n if(!dwgLibPromise){dwgLibPromise=import('https://unpkg.com/@mlightcad/libredwg-web@0.7.14/dist/libredwg-web.js').catch(e=>{dwgLibPromise=null;throw e});}\n return dwgLibPromise;\n}"
loader_new = f"const SQ_WRITER_ENGINE_URL='https://cdn.jsdelivr.net/gh/aboabdalla72229-hash/SurveyQuantAndroid_v1.0.57@{writer_sha}/libredwg-writer/dist/libredwg-web.js';\nasync function loadDWG(){{\n if(!dwgLibPromise){{dwgLibPromise=import(SQ_WRITER_ENGINE_URL).catch(e=>{{dwgLibPromise=null;throw new Error('تعذر تحميل محرك DWG الكاتب المرفق بالتطبيق. تحقق من اتصال الإنترنت ثم أعد المحاولة: '+(e.message||e));}});}}\n return dwgLibPromise;\n}}"
idx = sub_once(idx, loader_old, loader_new, 'writer-enabled DWG loader')
# Keep the orientation workflow itself on the existing final two-board screen.
index_path.write_text(idx, encoding='utf-8')
reference_path.write_text(ref, encoding='utf-8')
preserve_path.write_text(pres, encoding='utf-8')
print('PASS v115 source patch: classic POLYLINE vertices, 5000x zoom, seven snap modes, editable point coordinates, automatic labelled axes, audit-only export diagnostics, tolerant preview, writer-enabled DWG loader.')
