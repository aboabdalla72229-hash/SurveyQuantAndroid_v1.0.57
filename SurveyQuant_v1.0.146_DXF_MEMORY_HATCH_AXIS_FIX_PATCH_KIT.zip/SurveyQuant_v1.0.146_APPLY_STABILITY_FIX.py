#!/usr/bin/env python3
"""V146 stabilization patch: streaming DXF pair scan, single-allocation output, OCS HATCH fix, and pair-based axis labels."""
from __future__ import annotations
import argparse, hashlib, re
from pathlib import Path

OLD_CODE=145
NEW_CODE=146

def script_pattern(sid):
    return re.compile(r'(<script\b(?=[^>]*\bid=["\']'+re.escape(sid)+r'["\'])[^>]*>)([\s\S]*?)(</script\s*>)', re.I)

def get_body(html,sid):
    hits=list(script_pattern(sid).finditer(html))
    if len(hits)!=1: raise ValueError(f'Expected exactly one script id={sid}, found {len(hits)}')
    return hits[0].group(2)

def set_body(html,sid,body):
    hits=list(script_pattern(sid).finditer(html))
    if len(hits)!=1: raise ValueError(f'Expected exactly one script id={sid}, found {len(hits)}')
    m=hits[0]
    return html[:m.start(2)]+body+html[m.end(2):]

def replace_once(s,old,new,label):
    n=s.count(old)
    if n!=1: raise ValueError(f'{label}: expected exactly one anchor, got {n}')
    return s.replace(old,new,1)

STREAM_SPLIT=r'''function splitPairs(input){
 const bytes=input instanceof Uint8Array?input:new Uint8Array(input);
 if(ascii(bytes,0,Math.min(bytes.length,22)).includes('AutoCAD Binary DXF'))throw new Error('ملف DXF ثنائي؛ احفظ نسخة DXF نصية من برنامج CAD لفتحها في المعاينة.');
 const initial=(bytes.length>=3&&bytes[0]===239&&bytes[1]===187&&bytes[2]===191)?3:0;
 // Read one physical line on demand. Do not allocate a second full-file array of line objects.
 function lineAt(start){if(start>=bytes.length)return null;let ce=start;while(ce<bytes.length&&bytes[ce]!==10&&bytes[ce]!==13)ce++;let next=ce;if(next<bytes.length&&bytes[next]===13)next++;if(next<bytes.length&&bytes[next]===10)next++;return {start,ce,next};}
 const lineText=l=>l?ascii(bytes,l.start,l.ce).replace(/^\uFEFF/,'').trim():'';
 function parseCode(text){if(!/^[+-]?\d+$/.test(text))return null;const v=Number(text);return Number.isSafeInteger(v)&&v>=-5&&v<=32767?v:null;}
 const known=new Set(('SECTION ENDSEC EOF LINE POINT CIRCLE ARC ELLIPSE SPLINE LWPOLYLINE POLYLINE VERTEX SEQEND INSERT TEXT MTEXT DIMENSION HATCH SOLID TRACE 3DFACE 3DSOLID REGION BODY MESH ACAD_PROXY_ENTITY ACAD_PROXY_OBJECT ATTRIB ATTDEF MLINE LEADER MLEADER IMAGE WIPEOUT RAY XLINE BLOCK ENDBLK VIEWPORT UNDERLAY HELIX SHAPE TOLERANCE').split(' '));
 const token=s=>{s=String(s||'').trim().toUpperCase();return s.length>0&&s.length<=96&&/[A-Z_$*]/.test(s)&&/^[A-Z0-9_$.*-]+$/.test(s);};
 function nextBoundary(from){let pos=from,skipped=0;while(pos<bytes.length){const cl=lineAt(pos);if(!cl)break;const ct=parseCode(lineText(cl));if(ct===0){const vl=lineAt(cl.next),t=lineText(vl).toUpperCase();if(vl&&token(t)){let p=vl.next,valid=0;for(let k=0;k<12&&p<bytes.length;k++){const cLine=lineAt(p);if(!cLine)break;const c=parseCode(lineText(cLine));if(c===null)break;const vLine=lineAt(cLine.next);if(!vLine)break;valid++;p=vLine.next;}if(valid>=2||['SECTION','ENDSEC','EOF'].includes(t)||(known.has(t)&&valid>=1))return {pos,skipped};}}pos=cl.next;skipped++;}return {pos:-1,skipped};}
 const pairs=[];let cursor=initial,recoveredLines=0,recoveryCount=0;
 while(cursor<bytes.length){const cl=lineAt(cursor);if(!cl||cl.next>=bytes.length)break;const code=parseCode(lineText(cl));if(code===null){const boundary=nextBoundary(cl.next);if(boundary.pos<0)break;recoveredLines+=boundary.skipped+1;recoveryCount++;cursor=boundary.pos;continue;}const vl=lineAt(cl.next);if(!vl)break;pairs.push({code,value:lineText(vl),start:cl.start,valueStart:vl.start,valueEnd:vl.ce,end:vl.next,index:pairs.length});cursor=vl.next;}
 if(pairs.length<6)throw new Error('لم أستطع استعادة أزواج DXF كافية لعرض اللوحة. احفظها بصيغة DXF نصية ثم أعد المحاولة.');
 return {bytes,pairs,recoveredLines,recoveryCount};
}'''

VALIDATOR=r'''function entityTypeSignature(records){let h=2166136261>>>0;for(const rec of records||[]){const s=String(rec.type||'').toUpperCase();for(let i=0;i<s.length;i++)h=Math.imul(h^s.charCodeAt(i),16777619)>>>0;h=Math.imul(h^0,16777619)>>>0;}return h>>>0;}
function validateDxfOutputLight(input,expectedEntities,expectedSignature){
 const bytes=input instanceof Uint8Array?input:new Uint8Array(input);let pos=(bytes.length>=3&&bytes[0]===239&&bytes[1]===187&&bytes[2]===191)?3:0;
 function lineAt(start){if(start>=bytes.length)return null;let ce=start;while(ce<bytes.length&&bytes[ce]!==10&&bytes[ce]!==13)ce++;let next=ce;if(next<bytes.length&&bytes[next]===13)next++;if(next<bytes.length&&bytes[next]===10)next++;return {start,ce,next};}
 const text=l=>l?ascii(bytes,l.start,l.ce).replace(/^\uFEFF/,'').trim():'';
 const codeOf=s=>{if(!/^[+-]?\d+$/.test(s))return null;const n=Number(s);return Number.isSafeInteger(n)&&n>=-5&&n<=32767?n:null;};
 let section='',pendingSection=false,sectionSeen=false,entitiesSeen=false,eofSeen=false,count=0,hash=2166136261>>>0;
 while(pos<bytes.length){const cl=lineAt(pos);if(!cl)break;if(cl.next>=bytes.length){if(text(cl))throw new Error('ناتج DXF يحتوي سطر مجموعة بلا قيمة.');break;}const vl=lineAt(cl.next);if(!vl)throw new Error('ناتج DXF ينتهي بزوج مجموعة غير مكتمل.');const ctext=text(cl),value=text(vl),code=codeOf(ctext);if(code===null)throw new Error('ناتج DXF يحتوي رقم مجموعة غير صالح.');pos=vl.next;
  if(code===0){const u=value.toUpperCase();if(u==='SECTION'){pendingSection=true;sectionSeen=true;continue;}if(u==='ENDSEC'){section='';pendingSection=false;continue;}if(u==='EOF'){eofSeen=true;for(let k=pos;k<bytes.length;k++)if(bytes[k]!==10&&bytes[k]!==13&&bytes[k]!==32&&bytes[k]!==9)throw new Error('يوجد محتوى بعد علامة EOF في ناتج DXF.');break;}if(section==='ENTITIES'&&u!=='VERTEX'&&u!=='SEQEND'){count++;for(let k=0;k<u.length;k++)hash=Math.imul(hash^u.charCodeAt(k),16777619)>>>0;hash=Math.imul(hash^0,16777619)>>>0;}}
  else if(pendingSection&&code===2){section=value.toUpperCase();pendingSection=false;if(section==='ENTITIES')entitiesSeen=true;}
 }
 if(!sectionSeen||!entitiesSeen||!eofSeen)throw new Error('ناتج الإسقاط لم يجتز فحص SECTION/ENTITIES/EOF؛ لم يتم تنزيل DXF غير مكتمل.');
 if(count!==expectedEntities)throw new Error('عدد كيانات ENTITIES تغيّر أثناء الإسقاط ('+expectedEntities+' إلى '+count+'). تم إلغاء التصدير حفاظًا على اللوحة كاملة.');
 if((hash>>>0)!==(expectedSignature>>>0))throw new Error('تغيّر ترتيب أو نوع كيان داخل ENTITIES أثناء الإسقاط. أُلغِي التصدير ولم يتم إنشاء ملف مشوّه.');
 return count;
}'''

AXIS_HELPER=r'''function addAxisLabelsFromPairs(records,blocks,pairs,base){
 const cpRecord=(pairs||[]).findIndex((p,i)=>p.code===9&&String(p.value||'').toUpperCase()==='$DWGCODEPAGE');
 const cp=cpRecord>=0?String(pairs[cpRecord+1]?.value||'UTF-8').toUpperCase():'UTF-8';
 const encoding=/1256/.test(cp)?'windows-1256':/1251/.test(cp)?'windows-1251':/1252/.test(cp)?'windows-1252':/UTF-?8/.test(cp)?'utf-8':'windows-1252';
 let decoder;try{decoder=new TextDecoder(encoding);}catch(_){decoder=new TextDecoder('utf-8');}
 const decodeValue=s=>{const raw=String(s??''),b=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)b[i]=raw.charCodeAt(i)&255;try{return decoder.decode(b);}catch(_){return raw;}};
 const normalize=s=>decodeValue(String(s??'')).replace(/\\P/gi,' ').replace(/\\[A-Za-z][^;]*;/g,' ').replace(/[{}]/g,' ').replace(/\\~/g,' ').replace(/\\/g,' ').replace(/\\[{}]/g,' ').replace(/\s+/g,'').trim().toUpperCase();
 const isAxis=s=>{const v=normalize(s);return v.length>0&&v.length<=12&&(/^[A-Z\u0600-\u06FF]{1,4}[-_.]?\d{0,4}$/.test(v)||/^\d{1,4}[-_.]?[A-Z\u0600-\u06FF]{0,4}$/.test(v));};
 const identity={a:1,b:0,c:0,d:1,tx:0,ty:0};
 const mapPoint=(m,p)=>({x:m.a*p.x+m.b*p.y+m.tx,y:m.c*p.x+m.d*p.y+m.ty});
 const compose=(p,l)=>({a:p.a*l.a+p.b*l.c,b:p.a*l.b+p.b*l.d,c:p.c*l.a+p.d*l.c,d:p.c*l.b+p.d*l.d,tx:p.a*l.tx+p.b*l.ty+p.tx,ty:p.c*l.tx+p.d*l.ty+p.ty});
 let visited=0;const maxVisited=90000;const stack=[];
 const pairNumber=(rec,code,fallback=0)=>{const q=(rec.pairs||[]).find(p=>p.code===code),n=q?Number(q.value):fallback;return Number.isFinite(n)?n:fallback;};
 const pairString=(rec,code)=>String((rec.pairs||[]).find(p=>p.code===code)?.value||'').trim();
 const point=(rec,baseCode)=>{const x=pairNumber(rec,baseCode,NaN),y=pairNumber(rec,baseCode+10,NaN);return Number.isFinite(x)&&Number.isFinite(y)?{x,y}:null;};
 const textLabel=rec=>{const raw=(rec.pairs||[]).filter(p=>p.code===3||p.code===1).map(p=>String(p.value||'')).join('');return decodeValue(raw);};
 function addText(rec,m,inheritedLayer){if((base.texts||[]).length>=18000){base.previewTruncated=true;return;}const type=String(rec.type||'').toUpperCase();if(!['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(type))return;const raw=textLabel(rec);if(!isAxis(raw))return;const xcode=(type==='TEXT'||type==='ATTRIB'||type==='ATTDEF')&&(pairNumber(rec,72,0)!==0||pairNumber(rec,73,0)!==0)&&point(rec,11)?11:10;const p=point(rec,xcode);if(!p)return;const w=mapPoint(m,p),label=decodeValue(raw).replace(/\\P/gi,' ').replace(/[{}]/g,' ').trim();if(!Number.isFinite(w.x)||!Number.isFinite(w.y))return;
  const duplicate=(base.texts||[]).some(t=>String(t.text||'').trim().toUpperCase()===label.toUpperCase()&&t.p&&Math.hypot(t.p.x-w.x,t.p.y-w.y)<1e-4);if(duplicate)return;
  const layer=pairString(rec,8)||'0',effectiveLayer=layer==='0'&&inheritedLayer?inheritedLayer:layer,det=Math.abs(m.a*m.d-m.b*m.c),scale=Math.sqrt(Math.max(1e-12,det));
  const angle=pairNumber(rec,50,0)+Math.atan2(m.c,m.a)*180/Math.PI;
  const tx={p:{x:w.x,y:w.y},text:label,height:Math.abs(pairNumber(rec,40,2.5))*scale,rotation:angle,layer:effectiveLayer,aci:pairNumber(rec,62,256),trueColor:Number.isFinite(pairNumber(rec,420,NaN))?pairNumber(rec,420,NaN):null};base.texts.push(tx);base.anchors.push({x:w.x,y:w.y,layer:effectiveLayer,pointEntity:false});
 }
 function walk(rec,m,inheritedLayer,depth){if(++visited>maxVisited||depth>10){base.previewTruncated=true;return;}const type=String(rec.type||'').toUpperCase();const ownLayer=pairString(rec,8)||'0',layer=ownLayer==='0'&&inheritedLayer?inheritedLayer:ownLayer;
  if(type==='INSERT'){const name=pairString(rec,2).toUpperCase(),block=blocks&&blocks.get(name);if(!block||stack.includes(name))return;const ins=point(rec,10)||{x:0,y:0},sx=pairNumber(rec,41,1)||1,sy=pairNumber(rec,42,1)||1,ang=pairNumber(rec,50,0)*Math.PI/180,co=Math.cos(ang),si=Math.sin(ang),bx=block.base?.x||0,by=block.base?.y||0;const local={a:co*sx,b:-si*sy,c:si*sx,d:co*sy,tx:ins.x-co*sx*bx+si*sy*by,ty:ins.y-si*sx*bx-co*sy*by},next=compose(m,local);stack.push(name);for(const child of block.entities||[]){if(visited>=maxVisited){base.previewTruncated=true;break;}walk(child,next,layer,depth+1);}stack.pop();return;}
  if(['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(type))addText(rec,m,inheritedLayer);
 }
 for(const rec of records||[]){if(visited>=maxVisited){base.previewTruncated=true;break;}if(rec.type==='INSERT'||['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(rec.type))walk(rec,identity,'',0);}
 return visited;
}'''

def patch_html(html):
    if html.count('const SQ_APP_VERSION_CODE = 145;')!=1: raise ValueError('Expected exactly one V145 version constant')
    html=html.replace('const SQ_APP_VERSION_CODE = 145;','const SQ_APP_VERSION_CODE = 146;',1)
    html=html.replace('surveyquant-v145-fresh-board-session','surveyquant-v146-fresh-board-session')
    sid='sq-orientation-reference-board-module'
    body=get_body(html,sid)
    # Streaming splitPairs: eliminate the huge transient array of physical DXF lines.
    start=body.find('function splitPairs(input){'); end=body.find('\nfunction sectionRecords(',start)
    if start<0 or end<0: raise ValueError('Could not locate splitPairs function')
    body=body[:start]+STREAM_SPLIT+body[end:]
    # Replace the previous double-allocation output builder with one exact allocation.
    old=""" const ordered=Array.from(edits.values()).map(item=>({start:item.pair.valueStart,end:item.pair.valueEnd,text:item.value})).concat(insertions.map(item=>({start:item.at,end:item.at,text:item.text}))).sort((a,b)=>a.start-b.start||a.end-b.end),chunks=[];let cursor=0,total=0;
 for(const op of ordered){if(op.start<cursor)throw new Error('تداخلت عمليات تعديل إحداثيات DXF؛ لم يتم إنشاء ملف جزئي.');chunks.push(bytes.slice(cursor,op.start));const replacement=new TextEncoder().encode(op.text);chunks.push(replacement);total+=op.start-cursor+replacement.length;cursor=op.end;}
 chunks.push(bytes.slice(cursor));total+=bytes.length-cursor;const output=new Uint8Array(total);let offset=0;for(const chunk of chunks){output.set(chunk,offset);offset+=chunk.length;}
 const outPairs=splitPairs(output).pairs;
 const entitiesSectionIndex=outPairs.findIndex((p,i)=>p.code===0&&String(p.value).toUpperCase()==='SECTION'&&outPairs[i+1]?.code===2&&String(outPairs[i+1]?.value).toUpperCase()==='ENTITIES');
 const outRecords=sectionRecords(outPairs,'ENTITIES');
 const terminalPair=outPairs[outPairs.length-1];
 if(!outPairs.some(p=>p.code===0&&String(p.value).toUpperCase()==='SECTION')||entitiesSectionIndex<0||!outRecords.length||terminalPair?.code!==0||String(terminalPair?.value).toUpperCase()!=='EOF')throw new Error('ناتج الإسقاط لم يجتز فحص SECTION/ENTITIES/EOF؛ لم يتم تنزيل DXF غير مكتمل.');
 if(outRecords.length!==all.length)throw new Error('عدد كيانات ENTITIES تغيّر أثناء الإسقاط ('+all.length+' إلى '+outRecords.length+'). تم إلغاء التصدير حفاظًا على اللوحة كاملة.');
 return {bytes:output,transformedCount:transformedEntities,changedEntityCount,changedFields:ordered.length,unchangedOpaque,coordinateEntities,entitiesBefore:all.length,entitiesAfter:outRecords.length,layersPreserved:true,dimensionBlocksTransformed:dimensionBlockEntities.length,paperSpaceFallback:paperFallback};"""
    if body.count(old)!=1: raise ValueError(f'Output rebuilding/validation block anchor count {body.count(old)}')
    new=""" const entitiesBefore=all.length,signatureBefore=entityTypeSignature(all),dimensionBlocksCount=dimensionBlockEntities.length;
 const ordered=Array.from(edits.values()).map(item=>({start:item.pair.valueStart,end:item.pair.valueEnd,text:item.value})).concat(insertions.map(item=>({start:item.at,end:item.at,text:item.text}))).sort((a,b)=>a.start-b.start||a.end-b.end);
 let total=bytes.length;for(const op of ordered){if(op.start<0||op.end<op.start||op.end>bytes.length)throw new Error('حدود تعديل DXF غير صالحة؛ لم يتم إنشاء ملف جزئي.');total+=op.text.length-(op.end-op.start);}
 if(total<16)throw new Error('حجم ناتج DXF غير صالح.');
 // All replacements here are ASCII numeric values or ASCII group codes. Copy source ranges directly.
 // This avoids allocating hundreds of thousands of byte slices on the phone.
 const output=new Uint8Array(total);let sourcePos=0,destPos=0;
 for(const op of ordered){if(op.start<sourcePos)throw new Error('تداخلت عمليات تعديل إحداثيات DXF؛ لم يتم إنشاء ملف جزئي.');const span=op.start-sourcePos;output.set(bytes.subarray(sourcePos,op.start),destPos);destPos+=span;for(let i=0;i<op.text.length;i++){const ch=op.text.charCodeAt(i);if(ch>127)throw new Error('ظهر نص غير رقمي في عملية تعديل إحداثيات DXF.');output[destPos++]=ch;}sourcePos=op.end;}
 output.set(bytes.subarray(sourcePos),destPos);destPos+=bytes.length-sourcePos;if(destPos!==output.length)throw new Error('فشل التحقق من طول ناتج DXF قبل الحفظ.');
 // The source already supplied entity types; output validation streams the file without building a second pair/record tree.
 let entitiesAfter;
 if(parsed.recoveryCount){
   const outPairs=splitPairs(output).pairs,outRecords=sectionRecords(outPairs,'ENTITIES');
   const entitiesSectionIndex=outPairs.findIndex((p,i)=>p.code===0&&String(p.value).toUpperCase()==='SECTION'&&outPairs[i+1]?.code===2&&String(outPairs[i+1]?.value).toUpperCase()==='ENTITIES'),terminalPair=outPairs[outPairs.length-1];
   if(!outPairs.some(p=>p.code===0&&String(p.value).toUpperCase()==='SECTION')||entitiesSectionIndex<0||!outRecords.length||terminalPair?.code!==0||String(terminalPair?.value).toUpperCase()!=='EOF')throw new Error('ناتج الإسقاط لم يجتز فحص SECTION/ENTITIES/EOF؛ لم يتم تنزيل DXF غير مكتمل.');
   if(outRecords.length!==entitiesBefore||entityTypeSignature(outRecords)!==signatureBefore)throw new Error('عدد أو نوع كيانات ENTITIES تغيّر أثناء الإسقاط. تم إلغاء التصدير حفاظًا على اللوحة كاملة.');entitiesAfter=outRecords.length;
 }else entitiesAfter=validateDxfOutputLight(output,entitiesBefore,signatureBefore);
 // Release pair/record references before returning the new byte stream to the mobile WebView.
 edits.clear();insertions.length=0;for(const rec of all)rec.pairs.length=0;for(const rec of dimensionBlockEntities)rec.pairs.length=0;all.length=0;pairs.length=0;records.length=0;model.length=0;paper.length=0;dimensionBlockEntities.length=0;
 return {bytes:output,transformedCount:transformedEntities,changedEntityCount,changedFields:ordered.length,unchangedOpaque,coordinateEntities,entitiesBefore,entitiesAfter,layersPreserved:true,dimensionBlocksTransformed:dimensionBlocksCount,paperSpaceFallback:paperFallback};"""
    body=body.replace(old,new,1)
    # Insert low-allocation validator/signature helpers before universalTransformBytes.
    anchor='function universalTransformBytes(input,t){'
    if body.count(anchor)!=1: raise ValueError('universalTransformBytes anchor missing')
    body=body.replace(anchor,VALIDATOR+'\n'+anchor,1)
    # Prevent a HATCH pattern's local origin from receiving global translation.
    old_h="""  if(type==='HATCH'){
    for(const [xc,yc,mode] of [[43,44,'point'],[45,46,'vector']]){
      const xs=pairArrays(xc),ys=pairArrays(yc);for(let i=0;i<Math.min(xs.length,ys.length);i++){
        const x=numeric(xs[i].value),y=numeric(ys[i].value);if(x===null||y===null)continue;
        const q=mode==='point'?t.point(x,y):t.vector(x,y);change(xs[i],q.x);change(ys[i],q.y);
      }
    }
  }"""
    new_h="""  if(type==='HATCH'){
    // Pattern line bases (43/44) and offsets (45/46) are local pattern vectors, not WCS points.
    // Applying tx/ty here moves the hatch grid origin by the full board translation and creates a line-web.
    const pa=angleOffset*Math.PI/180,pc=Math.cos(pa),ps=Math.sin(pa);
    for(const [xc,yc] of [[43,44],[45,46]]){
      const xs=pairArrays(xc),ys=pairArrays(yc);for(let i=0;i<Math.min(xs.length,ys.length);i++){
        const x=numeric(xs[i].value),y=numeric(ys[i].value);if(x===null||y===null)continue;
        const q={x:t.scale*(pc*x-ps*y),y:t.scale*(ps*x+pc*y)};change(xs[i],q.x);change(ys[i],q.y);
      }
    }
  }"""
    if body.count(old_h)!=1: raise ValueError(f'HATCH block anchors {body.count(old_h)}')
    body=body.replace(old_h,new_h,1)
    # Add axis collector before parsePreview, and make it operate on already parsed pairs instead of decoding entire DXF again.
    before='function parsePreview(bytes){'
    if body.count(before)!=1: raise ValueError('parsePreview anchor missing')
    body=body.replace(before,AXIS_HELPER+'\n'+before,1)
    preview_prologue=re.compile(r"const api=window\.__sqManualOrientation109;let base=null,primaryError=null;try\{base=api\.parseDrawing\(bytes\);\}catch\(e\)\{primaryError=e;\}\s*const parsed=splitPairs\(bytes\),allSpaces=sectionRecords\(parsed\.pairs,'ENTITIES'\),blocks=blockDefinitions\(parsed\.pairs\),usedFallback=!base;const parsedLayers=layerDefinitions\(parsed\.pairs\);",re.S)
    replacement="const api=window.__sqManualOrientation109;let base=null,primaryError=null;const MEMORY_SAFE_PREVIEW_BYTES=1500000;try{if(bytes.length<=MEMORY_SAFE_PREVIEW_BYTES&&api&&typeof api.parseDrawing==='function')base=api.parseDrawing(bytes);else primaryError=new Error('تم استخدام مسار المعاينة منخفض الذاكرة لهذا الملف الكبير.');}catch(e){primaryError=e;}\n const parsed=splitPairs(bytes),allSpaces=sectionRecords(parsed.pairs,'ENTITIES'),blocks=blockDefinitions(parsed.pairs),usedFallback=!base;const parsedLayers=layerDefinitions(parsed.pairs);"
    body,npro=preview_prologue.subn(replacement,body,count=1)
    if npro!=1: raise ValueError('Could not install memory-safe large-file preview prologue')
    body=body.replace('base.layers=base.layers||parsedLayers;','base.layers=base.layers||parsedLayers;base.previewLowMemory=bytes.length>MEMORY_SAFE_PREVIEW_BYTES;',1)
    preview_start=body.find(" const extraTypes=new Set(['DIMENSION']);",body.find('function parsePreview(bytes){'))
    preview_end=body.find('\n const pts=[];',preview_start)
    if preview_start<0 or preview_end<0: raise ValueError('Could not locate preview geometry/axis block')
    newloop=""" const extraTypes=new Set(['DIMENSION']);
 const previewBudget={remaining:90000,maxSegments:140000,segments:0,maxPoints:180000,points:0,maxTexts:18000,texts:0,truncated:false};
 const appendGeometry=g=>{for(const p of g.pts)base.anchors.push(p);for(const s of g.segments)base.segs.push(s);for(const t of g.texts)base.texts.push(t);};
 for(const rec of all){if(previewBudget.remaining<=0||previewBudget.segments>=previewBudget.maxSegments||previewBudget.points>=previewBudget.maxPoints){previewBudget.truncated=true;break;}if(usedFallback||extraTypes.has(rec.type)){const g=geometryInWorld(rec,blocks,p=>p,0,previewBudget);appendGeometry(g);if(extraTypes.has(rec.type))base.unsupported=(base.unsupported||0)+1;}}
 if(!all.length)throw new Error(primaryError?.message||'لم يتم العثور على كيانات قابلة للقراءة في قسم ENTITIES داخل DXF.');
 // Axis labels come from parsed TEXT/MTEXT and nested INSERT records; no second full-file decode.
 addAxisLabelsFromPairs(all,blocks,parsed.pairs,base);
 // Cap only the preview representation. Original transformed bytes remain complete.
 if(base.segs.length>previewBudget.maxSegments){base.segs.length=previewBudget.maxSegments;previewBudget.truncated=true;}
 if(base.anchors.length>previewBudget.maxPoints){base.anchors.length=previewBudget.maxPoints;previewBudget.truncated=true;}
 if(base.texts.length>previewBudget.maxTexts){base.texts.length=previewBudget.maxTexts;previewBudget.truncated=true;}
 if(previewBudget.truncated)base.previewTruncated=true;"""
    body=body[:preview_start]+newloop+body[preview_end:]
    # Bounded traversal and non-spread merges prevent deeply nested / huge INSERT blocks from exhausting WebView memory.
    oldgeom="function mergeGeometry(a,b){a.pts.push(...b.pts);a.segments.push(...b.segments);a.texts.push(...b.texts);return a;}\nfunction geometryInWorld(rec,blocks,parent=p=>p,depth=0){const empty={pts:[],segments:[],texts:[]};"
    newgeom="""function mergeGeometry(a,b){for(const p of b.pts)a.pts.push(p);for(const s of b.segments)a.segments.push(s);for(const t of b.texts)a.texts.push(t);return a;}
function geometryInWorld(rec,blocks,parent=p=>p,depth=0,budget=null){const empty={pts:[],segments:[],texts:[]};
 if(!budget)budget={remaining:90000,maxSegments:140000,segments:0,maxPoints:180000,points:0,maxTexts:18000,texts:0,truncated:false};
 if(depth>10||budget.remaining<=0||budget.segments>=budget.maxSegments||budget.points>=budget.maxPoints){budget.truncated=true;return empty;}budget.remaining--;"""
    if body.count(oldgeom)!=1: raise ValueError('geometryInWorld function anchor count')
    body=body.replace(oldgeom,newgeom,1)
    body=body.replace("geometryInWorld(child,blocks,composed,depth+1)","geometryInWorld(child,blocks,composed,depth+1,budget)")
    body=body.replace("geometryInWorld(child,blocks,parent,depth+1)","geometryInWorld(child,blocks,parent,depth+1,budget)")
    geom_tail_start=body.find(" const raw=recordGeometry(rec),mapPoint",body.find("function geometryInWorld("))
    geom_tail_marker="return empty;}"
    geom_tail_end=body.find(geom_tail_marker,geom_tail_start)+len(geom_tail_marker)
    if geom_tail_start<0 or geom_tail_end<len(geom_tail_marker): raise ValueError('geometryInWorld tail not found')
    newgeomtail=""" const raw=recordGeometry(rec),mapPoint=p=>parent({x:p.x,y:p.y}),layer=recordString(rec,8)||'0',aci=pairVal(rec,62),tc=pairVal(rec,420),lw=pairVal(rec,370),lt=recordString(rec,6)||'CONTINUOUS';
 const style={layer,aci,trueColor:tc,lineweight:lw,linetype:lt.toUpperCase(),entityType:rec.type};
 for(let i=0;i<raw.pts.length&&budget.points<budget.maxPoints;i++){empty.pts.push({...mapPoint(raw.pts[i]),...style,pointEntity:rec.type==='POINT'});budget.points++;}if(raw.pts.length>0&&budget.points>=budget.maxPoints)budget.truncated=true;
 for(let i=0;i<raw.segments.length&&budget.segments<budget.maxSegments;i++){const seg=raw.segments[i];empty.segments.push({a:mapPoint(seg.a),b:mapPoint(seg.b),...style});budget.segments++;}if(raw.segments.length>0&&budget.segments>=budget.maxSegments)budget.truncated=true;
 if(['TEXT','MTEXT','ATTRIB','ATTDEF','DIMENSION','MLEADER','LEADER'].includes(rec.type)&&budget.texts<budget.maxTexts){const p=pointAt(rec,10)||pointAt(rec,11),txt=rec.pairs.filter(x=>x.code===1||x.code===3).map(x=>x.value).join('');if(p&&txt){empty.texts.push({p:parent(p),text:txt.replace(/\\P/g,' ').replace(/[{}]/g,' ').trim().slice(0,250),...style,height:pairVal(rec,40)||2.5,rotation:pairVal(rec,50)||0});budget.texts++;}}else if(budget.texts>=budget.maxTexts)budget.truncated=true;return empty;}"""
    body=body[:geom_tail_start]+newgeomtail+body[geom_tail_end:]
    # Avoid re-reading a whole binary/string file for axis names. Add a visible warning only if preview budget is used.
    oldbounds=""" base.entityCount=Math.max(base.entityCount||0,all.length);base.originalEntityRecords=all.length;base.recoveredPairs=parsed.recoveryCount||0;base.previewRecoveryMessage=base.recoveredPairs?'تمت استعادة المعاينة بعد تجاوز '+base.recoveredPairs+' موضعًا تالفًا في تسلسل المجموعة.':null;return base;"""
    newbounds=""" base.entityCount=Math.max(base.entityCount||0,all.length);base.originalEntityRecords=all.length;base.recoveredPairs=parsed.recoveryCount||0;base.previewRecoveryMessage=base.recoveredPairs?'تمت استعادة المعاينة بعد تجاوز '+base.recoveredPairs+' موضعًا تالفًا في تسلسل المجموعة.':null;if(base.previewTruncated){base.previewWarning='المعاينة محدودة لحماية ذاكرة الهاتف؛ ملف DXF الأصلي وتصديره الكامل لم يتم اختصارهما.';base.previewRecoveryMessage=(base.previewRecoveryMessage?base.previewRecoveryMessage+' ':'')+'المعاينة فقط محدودة بسبب حجم اللوحة.';}\n // Drop parser records after constructing independent preview geometry to reduce WebView peak memory.\n for(const rec of all)rec.pairs.length=0;parsed.pairs.length=0;allSpaces.length=0;modelSpaceRecords.length=0;paperSpaceRecords.length=0;blocks.clear();return base;"""
    if body.count(oldbounds)!=1: raise ValueError('preview finalization anchor missing')
    body=body.replace(oldbounds,newbounds,1)
    # Expose streaming validator for the regression harness.
    body=replace_once(body,'splitPairs,sectionRecords,recordGeometry,geometryInWorld,blockDefinitions,parsePreview};','splitPairs,sectionRecords,recordGeometry,geometryInWorld,blockDefinitions,parsePreview,validateDxfOutputLight,entityTypeSignature};','expose validator')
    html=set_body(html,sid,body)
    # Confirm old whole-file decoding path is absent from parsePreview only, and output-builder marker is installed.
    pbody=get_body(html,sid)
    if 'new TextDecoder(encoding).decode(bytes)' in pbody: raise ValueError('whole-file decoder still present in orientation preview')
    if 'const output=new Uint8Array(total)' not in pbody: raise ValueError('single-allocation output builder missing')
    if 'const pa=angleOffset*Math.PI/180' not in pbody: raise ValueError('HATCH local pattern-vector correction missing')
    if 'MEMORY_SAFE_PREVIEW_BYTES=1500000' not in pbody: raise ValueError('memory-safe preview selection missing')
    return html

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input-html',type=Path,required=True);ap.add_argument('--output-html',type=Path,required=True);ap.add_argument('--report',type=Path);a=ap.parse_args()
    source=a.input_html.read_text(encoding='utf-8');out=patch_html(source);a.output_html.parent.mkdir(parents=True,exist_ok=True);a.output_html.write_text(out,encoding='utf-8',newline='')
    report='''# SurveyQuant V146 Stability Fix Report\n\n- Version: 1.0.146 / versionCode 146, based on the successful V145 build.\n- Replaced the complete physical-line DXF scan with a streaming pair reader; pair and entity structures are preserved, but the separate line-object array is eliminated.\n- Rebuilt transformed DXF output with one allocation and direct source-range copies instead of creating a byte slice for every source span.\n- Replaced the common valid-output reparse tree with a streaming SECTION/ENTITIES/EOF + entity-type-signature validator. Malformed/recovered inputs still use the strict legacy validation path.\n- Fixed HATCH pattern base/offset transformation: pattern coordinates now rotate/scale in the local pattern frame, never receive world translation. This prevents pattern origins from shifting by survey offsets.\n- Removed the second whole-file decode used to recover axis names; labels are recovered from already parsed TEXT/MTEXT/ATTRIB/ATTDEF records and nested INSERT blocks, with codepage-aware decoding. Labels like A1, A-01, 2B, and Arabic grid labels are recognized.\n- Large previews skip the heavyweight general renderer and use a bounded common-entity preview; preview bounding/segment budgets protect WebView memory. Export bytes are not truncated. A visible note is shown if only the preview must be limited.\n- Preserved entity count and an FNV signature of entity types through output validation.\n\nAutomated tests cover HATCH local coordinates, no translation of local pattern origins, byte-preserving entity counts/types, nested INSERT axis labels, streaming scan of a large synthetic DXF, 3D/OCS and MLEADER regressions, and JavaScript syntax.\n'''
    if a.report:a.report.write_text(report,encoding='utf-8')
    print('PASS: applied V146 streaming parser, one-allocation DXF output, HATCH local-vector, memory-safe preview, and pair-based axis-label fixes.')
if __name__=='__main__':main()
