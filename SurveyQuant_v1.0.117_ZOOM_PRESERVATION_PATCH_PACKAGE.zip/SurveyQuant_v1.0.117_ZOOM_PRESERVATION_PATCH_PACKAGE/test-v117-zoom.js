'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const [modulePath, indexPath] = process.argv.slice(2);
const moduleText = fs.readFileSync(modulePath, 'utf8');
const index = fs.readFileSync(indexPath, 'utf8');
for (const text of [
  'Math.min(1000000,Number(value)||1)',
  'Math.min(1000000,v.pinch.zoom*distance/v.pinch.distance)',
  'Math.min(1000000,v.zoom*(e.deltaY<0?1.2:1/1.2))',
  'max="6" step="0.01" value="0" aria-label="تكبير اللوحة حتى 1,000,000 مرة"',
  "v.zoom*10);});el('sq110'+prefix+'ZoomRange'",
]) {
  assert(moduleText.includes(text), 'zoom module missing: ' + text);
  assert(index.includes(text), 'integrated app missing: ' + text);
}
const setter = moduleText.match(/function setZoom\(side,value\)\{[^}]*\}/);
assert(setter, 'board zoom setter not found');
assert(!/v\.bytes\s*=|v\.drawing\.[\w$]+\s*=/.test(setter[0]),
  'zoom must not mutate original DXF bytes or CAD entity data');
assert(moduleText.includes('function universalTransformBytes(input,t)'),
  'the original byte-preserving DXF transform path must remain present');
console.log('PASS v117 zoom regression: up to 1,000,000x, synchronized wheel/pinch slider, ×10 boost, original DXF data untouched.');
