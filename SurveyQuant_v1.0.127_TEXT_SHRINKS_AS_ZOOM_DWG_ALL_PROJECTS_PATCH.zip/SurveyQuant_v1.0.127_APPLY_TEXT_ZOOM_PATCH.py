#!/usr/bin/env python3
"""Apply the SurveyQuant v1.0.127 preview-only CAD text scaling fix."""
from __future__ import annotations
import argparse
import re
import os
import tempfile
import zipfile
from pathlib import Path

OLD_ACTIVE = "size=Math.max(0.1,Math.abs(Number(t.height)||2.5)*m.scale*Math.max(0.001,Number(v.zoom)||1))"
NEW_ACTIVE = "fitTextSize=Math.min(4.5,Math.abs(Number(t.height)||2.5)*m.base*0.35),size=Math.max(0.1,fitTextSize/Math.max(1,Number(v.zoom)||1))"
OLD_FALLBACK = "ctx.fillStyle='#e9c46a';ctx.font='11px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);"
NEW_FALLBACK = "ctx.fillStyle='#e9c46a';const fitTextSize=Math.min(4.5,Math.abs(Number(t.height)||2.5)*(m.scale/Math.max(0.001,zoom))*0.35);ctx.font=(Math.max(0.1,fitTextSize/Math.max(1,zoom)))+'px sans-serif';ctx.fillText(t.text,p.x+3,p.y-3);"


def patch_html(source: str) -> str:
    old_active_count = source.count(OLD_ACTIVE)
    old_fallback_count = source.count(OLD_FALLBACK)
    if old_active_count != 1:
        if NEW_ACTIVE in source and old_active_count == 0:
            raise SystemExit("ERROR: active CAD text formula already patched; refusing a second/ambiguous patch.")
        raise SystemExit(f"ERROR: expected exactly one active text-scale formula, found {old_active_count}.")
    if old_fallback_count != 1:
        raise SystemExit(f"ERROR: expected exactly one legacy preview's fixed 11px text formula, found {old_fallback_count}.")

    result = source.replace(OLD_ACTIVE, NEW_ACTIVE, 1)
    result = result.replace(OLD_FALLBACK, NEW_FALLBACK, 1)
    if OLD_ACTIVE in result or OLD_FALLBACK in result:
        raise SystemExit("ERROR: old text formula remains after patch.")
    if NEW_ACTIVE not in result or NEW_FALLBACK not in result:
        raise SystemExit("ERROR: patched text formulas were not found after replacement.")
    # Important invariants: zoom settings, geometry zoom scale, and byte-preserving transform are not altered.
    for required in (
        "function setZoom(side,value){const v=state.views[side];if(!v)return;",
        "scale:base*v.zoom",
        "function universalTransformBytes(input,t)",
        'id="sq-v117-universal-dwg-bridge"',
        "convertTargetToDxf",
    ):
        if required not in result:
            raise SystemExit("ERROR: required existing invariant missing: " + required)
    return result


def patch_html_file(path: Path) -> None:
    original = path.read_text(encoding="utf-8")
    patched = patch_html(original)
    path.write_text(patched, encoding="utf-8", newline="")
    print(f"PATCHED HTML: {path} ({len(original)} -> {len(patched)} characters)")


def patch_apk(source_apk: Path, output_apk: Path) -> None:
    if not source_apk.is_file():
        raise SystemExit(f"ERROR: APK does not exist: {source_apk}")
    output_apk.parent.mkdir(parents=True, exist_ok=True)
    replaced = 0
    with zipfile.ZipFile(source_apk, "r") as zin:
        fd, temp_name = tempfile.mkstemp(prefix="sq-v127-", suffix=".apk", dir=output_apk.parent)
        os.close(fd)
        try:
            with zipfile.ZipFile(temp_name, "w") as zout:
                for info in zin.infolist():
                    name = info.filename
                    # Strip invalidated v1 signature metadata. apksigner will create fresh signatures.
                    if re.match(r"^META-INF/[^/]+\.(?:SF|RSA|DSA|EC|MF)$", name, re.IGNORECASE):
                        continue
                    data = zin.read(name)
                    if name == "assets/index.html":
                        html = data.decode("utf-8")
                        data = patch_html(html).encode("utf-8")
                        replaced += 1
                    zout.writestr(info, data)
            if replaced != 1:
                raise SystemExit(f"ERROR: expected APK asset assets/index.html exactly once, replaced {replaced}.")
            Path(temp_name).replace(output_apk)
        except Exception:
            Path(temp_name).unlink(missing_ok=True)
            raise
    print(f"PATCHED APK ASSET: {source_apk} -> {output_apk}; only assets/index.html replaced; sign/alignment still required.")


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--html", type=Path, help="Patch an extracted index.html in-place")
    p.add_argument("--apk", type=Path, help="Patch assets/index.html within an APK, writing a new unsigned APK")
    p.add_argument("--output", type=Path, help="Required output file when --apk is used")
    args = p.parse_args()
    if args.html and not args.apk and not args.output:
        patch_html_file(args.html)
        return
    if args.apk and args.output and not args.html:
        patch_apk(args.apk, args.output)
        return
    p.error("use exactly one of --html PATH or --apk SOURCE.apk --output OUTPUT.apk")

if __name__ == "__main__":
    main()
