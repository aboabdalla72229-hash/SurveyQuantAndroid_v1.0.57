'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const [manualPath,referencePath]=process.argv.slice(2);assert(manualPath&&referencePath,'usage: test-v126-cad.js manual.js reference.js');
const enc=new TextEncoder(),dec=new TextDecoder();
function harness(){
 const nodes=new Map();
 const document={readyState:'loading',addEventListener(){},querySelector(){return {setAttribute(){}};},getElementById(id){return nodes.get(id)||null;},createElement(tag){return {tagName:tag.toUpperCase(),style:{},children:[],appendChild(n){this.children.push(n);},addEventListener(){},setAttribute(){},innerHTML:'',textContent:''};}};
 const window={devicePixelRatio:1,addEventListener(){},removeEventListener(){},__sqOrientTest:{transformBytes:null},__sqManualOrientation109:null};
 const ctx={window,document,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,DataView,Blob,URL,setTimeout,clearTimeout,Map,Set,Number,String,Math,Error,RegExp,Object,Array,Promise,JSON,console,Intl,Infinity,parseFloat,parseInt};vm.createContext(ctx);return {ctx,window,document,nodes};
}
function dxf(lines){return enc.encode(lines.join('\r\n')+'\r\n');}
const h=harness();
vm.runInContext(fs.readFileSync(manualPath,'utf8'),h.ctx,{filename:'manual-v126'});
vm.runInContext(fs.readFileSync(referencePath,'utf8'),h.ctx,{filename:'reference-v126'});
const manual=h.window.__sqManualOrientation109,api=h.window.__sqOrientation111API;
assert(manual&&api,'reader and orientation API initialize');
// Layer records and inline entity styles must be visible to the real renderer.
const styled=dxf([
'0','SECTION','2','HEADER','9','$EXTMIN','10','0','20','0','30','0','9','$EXTMAX','10','10','20','10','30','0','9','$VIEWCTR','10','5','20','5','9','$VIEWSIZE','40','10','0','ENDSEC',
'0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','2',
'0','LAYER','2','ROAD','70','0','62','1','6','DASHED','370','35',
'0','LAYER','2','TEXTS','70','0','62','3','6','CONTINUOUS','370','13','0','ENDTAB','0','ENDSEC',
'0','SECTION','2','ENTITIES','0','LINE','8','ROAD','10','0','20','0','11','10','21','0',
'0','TEXT','8','TEXTS','10','4','20','2','40','2.5','50','0','1','LAYER_LABEL_ABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789','0','ENDSEC','0','EOF'
]);
const model=manual.parseDrawing(styled);
assert(model.layers&&model.layers.ROAD&&model.layers.ROAD.aci===1,'layer table name/color parsed');
assert(model.segs.some(s=>s.layer==='ROAD'&&s.aci===1&&s.linetype==='DASHED'&&s.lineweight===35),'line carries layer color, linetype and lineweight');
assert(model.texts.some(t=>t.layer==='TEXTS'&&t.text==='LAYER_LABEL_ABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789'&&t.height===2.5),'full text label/style is retained');
const blockDrawing=dxf(['0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','1','0','LAYER','2','ROAD','70','0','62','1','6','CONTINUOUS','0','ENDTAB','0','ENDSEC','0','SECTION','2','BLOCKS','0','BLOCK','8','0','2','B_ROAD','70','0','10','0','20','0','30','0','0','LINE','8','0','10','0','20','0','11','5','21','0','0','ENDBLK','8','0','0','ENDSEC','0','SECTION','2','ENTITIES','0','INSERT','8','ROAD','2','B_ROAD','10','100','20','200','41','1','42','1','50','0','0','ENDSEC','0','EOF']);
const inserted=manual.parseDrawing(blockDrawing);assert(inserted.segs.some(s=>s.layer==='ROAD'&&s.aci===1&&Math.abs(s.a.x-100)<1e-8&&Math.abs(s.b.x-105)<1e-8),'layer-0 entities inside INSERT inherit the INSERT layer and are positioned correctly');
const hatch=dxf(['0','SECTION','2','ENTITIES','0','HATCH','8','HATCH_LAYER','70','1','91','1','92','2','72','0','73','1','93','4','10','0','20','0','10','10','20','0','10','10','20','10','10','0','20','10','75','0','76','1','0','ENDSEC','0','EOF']);
const hatchModel=manual.parseDrawing(hatch);assert(hatchModel.segs.length>=4&&hatchModel.segs.every(s=>s.layer==='HATCH_LAYER'),'closed polyline HATCH boundary should be visible on its original layer');assert.equal(hatchModel.fills.length,1,'solid HATCH produces a polygon fill for the preview');
const dimension=dxf(['0','SECTION','2','BLOCKS','0','BLOCK','8','0','2','*D1','70','0','10','0','20','0','0','LINE','8','0','10','1','20','2','11','9','21','2','0','TEXT','8','0','10','5','20','3','40','1','1','DIMENSION_LABEL','0','ENDBLK','8','0','0','ENDSEC','0','SECTION','2','ENTITIES','0','DIMENSION','8','DIMENSIONS','2','*D1','10','1','20','2','11','5','21','3','42','4.0','0','ENDSEC','0','EOF']);
const dimensionModel=manual.parseDrawing(dimension);assert(dimensionModel.segs.some(s=>s.layer==='DIMENSIONS'),'DIMENSION anonymous-block linework should be included in preview');assert(dimensionModel.texts.some(t=>t.text==='DIMENSION_LABEL'&&t.layer==='DIMENSIONS'),'DIMENSION block annotation text should inherit the dimension layer');
// Exact geometry transform still preserves layers, linetypes and text payload, while moving exposed XY.
const transform=api.solve({x:0,y:0},{x:10,y:0},{x:100,y:200},{x:100,y:220});
const moved=api.transformBytes(styled,transform),out=dec.decode(moved.bytes);
assert.match(out,/\n100\r?\n/,'coordinates actually changed');assert.match(out,/\nROAD\r?\n/,'layer names preserved');assert.match(out,/\nDASHED\r?\n/,'linetype table preserved');assert.match(out,/\nLAYER_LABEL_ABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789\r?\n/,'text contents preserved');
assert.equal(moved.entitiesBefore,moved.entitiesAfter,'entity count preserved');assert.equal(moved.layersPreserved,true,'layer preservation confirmed');
const headerVar=(txt,name)=>{const parts=txt.split(/\r?\n/);const ix=parts.findIndex((v,i)=>v==='9'&&parts[i+1]===name);assert(ix>=0,'header variable '+name+' should exist');const out={};for(let i=ix+2;i<parts.length&&!(parts[i]==='9'||parts[i]==='0');i+=2)out[parts[i]]=Number(parts[i+1]);return out;};const extMin=headerVar(out,'$EXTMIN'),extMax=headerVar(out,'$EXTMAX'),viewCenter=headerVar(out,'$VIEWCTR'),viewSize=headerVar(out,'$VIEWSIZE');assert(Math.abs(extMin['10']-80)<1e-8&&Math.abs(extMin['20']-200)<1e-8,'$EXTMIN must move with the transformed board');assert(Math.abs(extMax['10']-100)<1e-8&&Math.abs(extMax['20']-220)<1e-8,'$EXTMAX must bound the transformed board');assert(Math.abs(viewCenter['10']-90)<1e-8&&Math.abs(viewCenter['20']-210)<1e-8,'$VIEWCTR must move with the transformed board');assert(Math.abs(viewSize['40']-20)<1e-8,'$VIEWSIZE scales with the board');
// Drawing saved only in paper space should transform rather than silently downloading an unchanged DXF.
const paper=dxf(['0','SECTION','2','ENTITIES','0','LINE','8','PAPER_BOARD','67','1','10','0','20','0','11','10','21','0','0','ENDSEC','0','EOF']);
const paperMoved=api.transformBytes(paper,transform),paperText=dec.decode(paperMoved.bytes);
assert.equal(paperMoved.paperSpaceFallback,true,'paper-space-only file reports its fallback explicitly');assert.match(paperText,/\n100\r?\n/,'paper-space-only geometry is transformed');
// Identity transform is an allowed valid no-op and preserves original numeric spelling.
const identity=api.solve({x:0,y:0},{x:10,y:0},{x:0,y:0},{x:10,y:0});
const unchanged=api.transformBytes(styled,identity),same=dec.decode(unchanged.bytes);
assert.equal(unchanged.changedFields,0,'identity keeps byte-preserved numeric strings');assert.match(same,/10\r\n0\r\n20\r\n0\r\n11\r\n10/,'original coordinate text remains intact');
// A required transform must not pass as successful if the file only contains unsupported non-geometric content.
const opaque=dxf(['0','SECTION','2','ENTITIES','0','ACAD_PROXY_ENTITY','8','PROXY','1000','opaque payload','0','ENDSEC','0','EOF']);
assert.throws(()=>api.transformBytes(opaque,transform),/لم أجد كيانات هندسية قابلة للتحويل|لا يتغير أي إحداثي/,'non-geometric/proxy-only content must not be falsely accepted as a projected board');
// Draw rendering is internal to the board canvas and honours layer visibility/colors.
const drawCalls={strokes:0,styles:[],texts:[],fills:0};const canvasCtx={clearRect(){},fillRect(){},fillText(t){drawCalls.texts.push(t);},beginPath(){},moveTo(){},lineTo(){},closePath(){},stroke(){drawCalls.strokes++;drawCalls.styles.push(this.strokeStyle);},setLineDash(){},arc(){},fill(){drawCalls.fills++;},save(){},restore(){},translate(){},rotate(){}};
const view={side:'target',canvas:{clientWidth:400,clientHeight:230,width:400,height:230},ctx:canvasCtx,drawing:model,zoom:1,panX:0,panY:0,layerVisibility:{ROAD:true,TEXTS:true}};
api.draw(view);assert(drawCalls.strokes>0,'canvas renderer draws board geometry');assert(drawCalls.styles.includes('#ff3b30'),'layer ACI color is used');
const hatchView={side:'target',canvas:{clientWidth:400,clientHeight:230,width:400,height:230},ctx:canvasCtx,drawing:hatchModel,zoom:1,panX:0,panY:0,layerVisibility:{HATCH_LAYER:true}};const fillsBefore=drawCalls.fills;api.draw(hatchView);assert(drawCalls.fills>fillsBefore,'solid hatch polygon is filled in the board preview');
const first=drawCalls.strokes;drawCalls.strokes=0;view.layerVisibility.ROAD=false;api.draw(view);assert(drawCalls.strokes<first,'turning off a layer hides its linework without zooming the page');
const source=fs.readFileSync(referencePath,'utf8'),reader=fs.readFileSync(manualPath,'utf8');
for(const token of ['sq110TLayerPanel','sq110RLayerPanel','height:230px;min-height:230px;max-height:230px','user-scalable=no','paperSpaceFallback','dimensionBlockEntities','تكبير داخل اللوحة','c.globalAlpha=.22'])assert(source.includes(token),'missing v126 functionality '+token);
for(const token of ['drawHatchPolylineBoundary',"e.type==='DIMENSION'","if(t==='MLINE')",'fills.push'])assert(reader.includes(token),'missing CAD preview entity support '+token);
console.log('PASS v126: model/paper-space transform, header extents/view centering, block-layer inheritance, dimension annotation, solid HATCH fill/boundaries, MLINE, full text preview, ACI/true colors, linetype/lineweight styling, compact board-only zoom, byte preservation, and empty-projection guard.');
