(function (root, factory) {
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.SurveyQuantCAD162 = api;
  if (root && root.document) api.mount();
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
  'use strict';

  const enc = new TextEncoder();
  const SAFE_SEGMENT_LIMIT = 80000;
  const finite = Number.isFinite;
  const norm = n => Math.abs(n) < 1e-12 ? 0 : n;
  const fmt = n => {
    if (!finite(n)) throw new Error('نتجت قيمة إحداثية غير صالحة؛ أوقفت العملية لحماية الملف الأصلي.');
    n = norm(n);
    return String(Number(n.toPrecision(14)));
  };
  function decodeBytes(bytes) {
    return new TextDecoder('windows-1252').decode(bytes);
  }
  function readLine(bytes, start) {
    if (start >= bytes.length) return null;
    let end = start;
    while (end < bytes.length && bytes[end] !== 10) end++;
    let valueEnd = end;
    if (valueEnd > start && bytes[valueEnd - 1] === 13) valueEnd--;
    return { start, valueEnd, end: end < bytes.length ? end + 1 : end };
  }
  function pairText(bytes, line) {
    return decodeBytes(bytes.subarray(line.start, line.valueEnd)).trim();
  }
  function forEachPair(bytes, callback) {
    let pos = 0;
    while (pos < bytes.length) {
      const codeLine = readLine(bytes, pos);
      if (!codeLine) break;
      const valueLine = readLine(bytes, codeLine.end);
      if (!valueLine) break;
      const codeText = pairText(bytes, codeLine);
      const code = Number.parseInt(codeText, 10);
      callback({
        code,
        value: pairText(bytes, valueLine),
        start: codeLine.start,
        valueStart: valueLine.start,
        valueEnd: valueLine.valueEnd,
        end: valueLine.end,
      });
      pos = valueLine.end;
    }
  }
  function solve(sourceA, sourceB, targetA, targetB) {
    const dx1 = sourceB.x - sourceA.x, dy1 = sourceB.y - sourceA.y;
    const dx2 = targetB.x - targetA.x, dy2 = targetB.y - targetA.y;
    const d1 = Math.hypot(dx1, dy1), d2 = Math.hypot(dx2, dy2);
    if (![sourceA.x, sourceA.y, sourceB.x, sourceB.y, targetA.x, targetA.y, targetB.x, targetB.y].every(finite)) {
      throw new Error('إحداثيات نقاط التوجيه غير صالحة.');
    }
    if (d1 < 1e-9 || d2 < 1e-9) throw new Error('اختر نقطتين مختلفتين في كل لوحة.');
    const scale = d2 / d1;
    const angle = Math.atan2(dy2, dx2) - Math.atan2(dy1, dx1);
    const cos = Math.cos(angle), sin = Math.sin(angle);
    const apply = p => {
      const x = p.x - sourceA.x, y = p.y - sourceA.y;
      return { x: targetA.x + scale * (x * cos - y * sin), y: targetA.y + scale * (x * sin + y * cos) };
    };
    const mappedA = apply(sourceA), mappedB = apply(sourceB);
    return {
      scale,
      rotationRadians: angle,
      rotationDegrees: angle * 180 / Math.PI,
      apply,
      residualA: Math.hypot(mappedA.x - targetA.x, mappedA.y - targetA.y),
      residualB: Math.hypot(mappedB.x - targetB.x, mappedB.y - targetB.y),
    };
  }
  function applyEdits(source, edits) {
    const sorted = edits.slice().sort((a, b) => a.start - b.start || a.end - b.end);
    let total = source.length, cursor = 0;
    for (const edit of sorted) {
      if (!Number.isInteger(edit.start) || !Number.isInteger(edit.end) || edit.start < cursor || edit.end < edit.start || edit.end > source.length) {
        throw new Error('تداخلت تعديلات البايتات؛ أوقفت التحويل بدلًا من إتلاف DXF.');
      }
      total += (edit.insertBytes || new Uint8Array(0)).length - (edit.end - edit.start);
      cursor = edit.end;
    }
    const out = new Uint8Array(total);
    let sourcePos = 0, outPos = 0;
    for (const edit of sorted) {
      const span = edit.start - sourcePos;
      out.set(source.subarray(sourcePos, edit.start), outPos); outPos += span;
      const insert = edit.insertBytes || new Uint8Array(0);
      out.set(insert, outPos); outPos += insert.length; sourcePos = edit.end;
    }
    out.set(source.subarray(sourcePos), outPos); outPos += source.length - sourcePos;
    if (outPos !== out.length) throw new Error('فشل التحقق من حجم DXF الناتج.');
    return out;
  }
  function transformDxfBytes(rawBytes, sourceA, sourceB, targetA, targetB) {
    const bytes = rawBytes instanceof Uint8Array ? rawBytes : new Uint8Array(rawBytes);
    if (!bytes.length) throw new Error('ملف DXF فارغ.');
    const tr = solve(sourceA, sourceB, targetA, targetB);
    const eol = (() => {
      for (let i = 0; i < bytes.length; i++) if (bytes[i] === 10) return i > 0 && bytes[i - 1] === 13 ? '\r\n' : '\n';
      return '\n';
    })();
    const edits = [];
    let pos = 0, section = '', needSectionName = false, blockHeaderPending = false, blockName = '';
    let entity = null, foundEntities = false;
    const theta = tr.rotationRadians;
    const transformPoint = (x, y, vectorOnly) => {
      if (vectorOnly) return { x: tr.scale * (x * Math.cos(theta) - y * Math.sin(theta)), y: tr.scale * (x * Math.sin(theta) + y * Math.cos(theta)) };
      return tr.apply({ x, y });
    };
    const addNumericEdit = (pair, value) => {
      const replacement = enc.encode(fmt(value));
      edits.push({ start: pair.valueStart, end: pair.valueEnd, insertBytes: replacement });
    };
    function flushEntity() {
      if (!entity) return;
      const type = entity.type.toUpperCase(), pairs = entity.pairs;
      const byCode = new Map();
      for (const p of pairs) {
        if (!byCode.has(p.code)) byCode.set(p.code, []);
        byCode.get(p.code).push(p);
      }
      // DXF stores paired XY coordinates as 10..18 and 20..28. Edit only the
      // numeric values, leaving handles, layers, flags, entity type and all
      // unrecognized records byte-for-byte as supplied.
      for (let xCode = 10; xCode <= 18; xCode++) {
        const xs = byCode.get(xCode) || [], ys = byCode.get(xCode + 10) || [];
        if (!xs.length || xs.length !== ys.length) continue;
        for (let i = 0; i < xs.length; i++) {
          const x = Number(xs[i].value), y = Number(ys[i].value);
          if (!finite(x) || !finite(y)) continue;
          const vectorOnly = type === 'ELLIPSE' && xCode === 11;
          const q = transformPoint(x, y, vectorOnly);
          addNumericEdit(xs[i], q.x); addNumericEdit(ys[i], q.y);
        }
      }
      const setMultiplied = code => {
        for (const p of (byCode.get(code) || [])) {
          const n = Number(p.value); if (finite(n)) addNumericEdit(p, n * tr.scale);
        }
      };
      const setRotated = code => {
        for (const p of (byCode.get(code) || [])) {
          const n = Number(p.value); if (finite(n)) addNumericEdit(p, (n + tr.rotationDegrees + 360000) % 360);
        }
      };
      if (type === 'CIRCLE' || type === 'ARC') setMultiplied(40);
      if (['TEXT', 'MTEXT', 'ATTRIB', 'ATTDEF'].includes(type)) setMultiplied(40);
      if (type === 'MTEXT') setMultiplied(41);
      if (type === 'ARC') { setRotated(50); setRotated(51); }
      else if (['TEXT', 'MTEXT', 'ATTRIB', 'ATTDEF', 'INSERT'].includes(type)) setRotated(50);
      else if (type === 'DIMENSION') setRotated(53);
      let extra = '';
      if (type === 'INSERT') {
        const sx = byCode.get(41) || [], sy = byCode.get(42) || [];
        if (sx.length) setMultiplied(41); else extra += `41${eol}${fmt(tr.scale)}${eol}`;
        if (sy.length) setMultiplied(42); else extra += `42${eol}${fmt(tr.scale)}${eol}`;
        if (theta && !(byCode.get(50) || []).length) extra += `50${eol}${fmt(tr.rotationDegrees)}${eol}`;
      }
      if (['TEXT', 'MTEXT', 'ATTRIB', 'ATTDEF'].includes(type) && theta && !(byCode.get(50) || []).length) {
        extra += `50${eol}${fmt(tr.rotationDegrees)}${eol}`;
      }
      if (extra && pairs.length) {
        const last = pairs[pairs.length - 1];
        edits.push({ start: last.end, end: last.end, insertBytes: enc.encode(extra) });
      }
      entity = null;
    }
    while (pos < bytes.length) {
      const codeLine = readLine(bytes, pos);
      if (!codeLine) break;
      const valueLine = readLine(bytes, codeLine.end);
      if (!valueLine) break;
      const code = Number.parseInt(pairText(bytes, codeLine), 10);
      const value = pairText(bytes, valueLine);
      const pair = { code, value, start: codeLine.start, valueStart: valueLine.start, valueEnd: valueLine.valueEnd, end: valueLine.end };
      if (needSectionName && code === 2) { section = value.toUpperCase(); needSectionName = false; if (section === 'ENTITIES') foundEntities = true; pos = valueLine.end; continue; }
      if (section === 'BLOCKS' && blockHeaderPending && code === 2) { blockName = value; blockHeaderPending = false; pos = valueLine.end; continue; }
      if (code === 0) {
        flushEntity();
        const upper = value.toUpperCase();
        if (upper === 'SECTION') { needSectionName = true; pos = valueLine.end; continue; }
        if (upper === 'ENDSEC') { section = ''; blockName = ''; pos = valueLine.end; continue; }
        if (section === 'BLOCKS') {
          if (upper === 'BLOCK') { blockHeaderPending = true; pos = valueLine.end; continue; }
          if (upper === 'ENDBLK') { blockName = ''; pos = valueLine.end; continue; }
          // Anonymous *D blocks store dimension graphics in drawing coordinates.
          if (blockName.toUpperCase().startsWith('*D')) entity = { type: value, pairs: [] };
        } else if (section === 'ENTITIES') entity = { type: value, pairs: [] };
      } else if (entity) entity.pairs.push(pair);
      pos = valueLine.end;
    }
    flushEntity();
    if (!foundEntities) throw new Error('لم يوجد قسم ENTITIES صالح في ملف DXF.');
    if (tr.scale < 1e-12 || !finite(tr.scale)) throw new Error('مقياس التوجيه الناتج غير صالح.');
    const out = applyEdits(bytes, edits);
    return { bytes: out, scale: tr.scale, rotationDegrees: tr.rotationDegrees, editCount: edits.length };
  }
  function readGeometry(rawBytes, maxSegments = SAFE_SEGMENT_LIMIT) {
    const bytes = rawBytes instanceof Uint8Array ? rawBytes : new Uint8Array(rawBytes);
    const segments = [], points = [];
    let section = '', needSectionName = false, entity = null, pendingPolyline = null;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    function addPoint(p) {
      if (!p || !finite(p.x) || !finite(p.y)) return;
      points.push(p); minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x); minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y);
    }
    function addSegment(a, b) {
      if (segments.length >= maxSegments || !a || !b || !finite(a.x) || !finite(a.y) || !finite(b.x) || !finite(b.y)) return;
      segments.push({ a, b }); addPoint(a); addPoint(b);
    }
    function pointsFromPairs(byCode, xCode = 10) {
      const xs = byCode.get(xCode) || [], ys = byCode.get(xCode + 10) || [];
      const out = [];
      for (let i = 0; i < Math.min(xs.length, ys.length); i++) {
        const x = Number(xs[i]), y = Number(ys[i]); if (finite(x) && finite(y)) out.push({ x, y });
      }
      return out;
    }
    function connect(pointsList, closed = false) {
      if (!pointsList.length) return;
      if (pointsList.length === 1) { addPoint(pointsList[0]); return; }
      for (let i = 1; i < pointsList.length && segments.length < maxSegments; i++) addSegment(pointsList[i - 1], pointsList[i]);
      if (closed && segments.length < maxSegments) addSegment(pointsList[pointsList.length - 1], pointsList[0]);
    }
    function finishPolyline() {
      if (pendingPolyline) { connect(pendingPolyline.points, pendingPolyline.closed); pendingPolyline = null; }
    }
    function flushEntity() {
      if (!entity) return;
      const type = entity.type.toUpperCase(), values = entity.values;
      const byCode = new Map();
      for (const [code, arr] of Object.entries(values)) byCode.set(Number(code), arr);
      if (type === 'POLYLINE') {
        finishPolyline();
        pendingPolyline = { points: [], closed: ((Number((values[70] || [])[0]) || 0) & 1) !== 0 };
      } else if (type === 'VERTEX' && pendingPolyline) {
        const p = pointsFromPairs(byCode)[0]; if (p) pendingPolyline.points.push(p);
      } else if (type === 'SEQEND' && pendingPolyline) finishPolyline();
      else {
        if (pendingPolyline) finishPolyline();
        if (type === 'LINE') {
          const a = pointsFromPairs(byCode, 10)[0], b = pointsFromPairs(byCode, 11)[0]; if (a && b) addSegment(a, b);
        } else if (type === 'LWPOLYLINE' || type === 'SPLINE') {
          const ps = pointsFromPairs(byCode, 10); connect(ps, type === 'LWPOLYLINE' && (((Number((values[70] || [])[0]) || 0) & 1) !== 0));
        } else if (type === 'CIRCLE' || type === 'ARC') {
          const c = pointsFromPairs(byCode, 10)[0], r = Number((values[40] || [])[0]);
          if (c && finite(r) && r > 0) {
            let start = type === 'ARC' ? Number((values[50] || [])[0]) * Math.PI / 180 : 0;
            let end = type === 'ARC' ? Number((values[51] || [])[0]) * Math.PI / 180 : Math.PI * 2;
            if (!finite(start)) start = 0; if (!finite(end)) end = Math.PI * 2;
            while (end <= start) end += Math.PI * 2;
            const n = Math.max(12, Math.min(160, Math.ceil((end - start) * 18)));
            let previous = null, first = null;
            for (let i = 0; i <= n; i++) {
              const a = start + (end - start) * i / n, p = { x: c.x + r * Math.cos(a), y: c.y + r * Math.sin(a) };
              if (!first) first = p; if (previous) addSegment(previous, p); previous = p;
            }
          } else if (c) addPoint(c);
        } else if (['SOLID', 'TRACE', '3DFACE'].includes(type)) {
          const ps = []; for (let code = 10; code <= 13; code++) { const p = pointsFromPairs(byCode, code)[0]; if (p) ps.push(p); }
          connect(ps, ps.length > 2);
        } else if (['POINT', 'INSERT', 'TEXT', 'MTEXT', 'ATTRIB', 'ATTDEF', 'DIMENSION'].includes(type)) {
          const p = pointsFromPairs(byCode, 10)[0]; if (p) addPoint(p);
        }
      }
      entity = null;
    }
    let pos = 0;
    while (pos < bytes.length && segments.length < maxSegments) {
      const cLine = readLine(bytes, pos); if (!cLine) break;
      const vLine = readLine(bytes, cLine.end); if (!vLine) break;
      const code = Number.parseInt(pairText(bytes, cLine), 10), value = pairText(bytes, vLine);
      if (needSectionName && code === 2) { section = value.toUpperCase(); needSectionName = false; pos = vLine.end; continue; }
      if (code === 0) {
        flushEntity();
        const u = value.toUpperCase();
        if (u === 'SECTION') { needSectionName = true; pos = vLine.end; continue; }
        if (u === 'ENDSEC') { section = ''; pos = vLine.end; continue; }
        if (section === 'ENTITIES') entity = { type: value, values: Object.create(null) };
      } else if (entity && section === 'ENTITIES' && ((code >= 10 && code <= 18) || (code >= 20 && code <= 28) || [40, 41, 42, 50, 51, 70].includes(code))) {
        if (!entity.values[code]) entity.values[code] = [];
        entity.values[code].push(value);
      }
      pos = vLine.end;
    }
    flushEntity(); finishPolyline();
    if (!segments.length && !points.length) throw new Error('لم أستطع استخراج خطوط قابلة للمعاينة من اللوحة.');
    if (!finite(minX) || !finite(maxX)) { minX = 0; maxX = 1; minY = 0; maxY = 1; }
    if (maxX - minX < 1e-9) { minX -= 0.5; maxX += 0.5; }
    if (maxY - minY < 1e-9) { minY -= 0.5; maxY += 0.5; }
    return { segments, points, minX, minY, maxX, maxY };
  }
  function nearestPoint(geometry, point) {
    let best = null, bestD2 = Infinity;
    for (const s of geometry.segments) {
      const dx = s.b.x - s.a.x, dy = s.b.y - s.a.y, den = dx * dx + dy * dy;
      const t = den ? Math.max(0, Math.min(1, ((point.x - s.a.x) * dx + (point.y - s.a.y) * dy) / den)) : 0;
      const q = { x: s.a.x + t * dx, y: s.a.y + t * dy };
      const d2 = (q.x - point.x) ** 2 + (q.y - point.y) ** 2;
      if (d2 < bestD2) { bestD2 = d2; best = q; }
    }
    if (!best && geometry.points.length) {
      for (const q of geometry.points) { const d2 = (q.x - point.x) ** 2 + (q.y - point.y) ** 2; if (d2 < bestD2) { bestD2 = d2; best = { x: q.x, y: q.y }; } }
    }
    if (!best) throw new Error('لا توجد عناصر مناسبة لالتقاط النقطة.');
    return best;
  }
  function svgPathToPolylines(d, scale = 8) {
    const tokens = String(d || '').match(/[A-Za-z]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?/g) || [];
    let i = 0, cmd = '', x = 0, y = 0, sx = 0, sy = 0, lastC = null, lastQ = null, path = [], paths = [];
    const isCmd = t => /^[A-Za-z]$/.test(t);
    const num = () => Number(tokens[i++]);
    const push = (px, py) => { if (finite(px) && finite(py)) path.push({ x: px, y: py }); };
    const finish = closed => { if (path.length > 1) paths.push({ points: path, closed }); path = []; };
    while (i < tokens.length) {
      if (isCmd(tokens[i])) cmd = tokens[i++];
      if (!cmd) break;
      const rel = cmd === cmd.toLowerCase(), upper = cmd.toUpperCase();
      if (upper === 'Z') { push(sx, sy); finish(true); x = sx; y = sy; cmd = ''; lastC = lastQ = null; continue; }
      if (upper === 'M' || upper === 'L' || upper === 'T') {
        if (i + 1 >= tokens.length) break;
        let nx = num(), ny = num(); if (rel) { nx += x; ny += y; }
        if (upper === 'M') { if (path.length) finish(false); sx = nx; sy = ny; push(nx, ny); cmd = rel ? 'l' : 'L'; }
        else if (upper === 'T') { const qx = lastQ ? 2 * x - lastQ.x : x, qy = lastQ ? 2 * y - lastQ.y : y; const ox = x, oy = y; for (let k = 1; k <= 8; k++) { const t = k / 8, u = 1 - t; push(u*u*ox + 2*u*t*qx + t*t*nx, u*u*oy + 2*u*t*qy + t*t*ny); } lastQ = { x: qx, y: qy }; }
        else push(nx, ny);
        x = nx; y = ny; lastC = null; if (upper !== 'T') lastQ = null;
      } else if (upper === 'H' || upper === 'V') {
        let z = num(); if (rel) z += upper === 'H' ? x : y; if (upper === 'H') x = z; else y = z; push(x, y); lastC = lastQ = null;
      } else if (upper === 'C') {
        if (i + 5 >= tokens.length) break;
        let x1=num(),y1=num(),x2=num(),y2=num(),nx=num(),ny=num(); if (rel) { x1+=x;y1+=y;x2+=x;y2+=y;nx+=x;ny+=y; }
        const ox=x,oy=y; for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*u*ox+3*u*u*t*x1+3*u*t*t*x2+t*t*t*nx,u*u*u*oy+3*u*u*t*y1+3*u*t*t*y2+t*t*t*ny);} x=nx;y=ny;lastC={x:x2,y:y2};lastQ=null;
      } else if (upper === 'S') {
        if (i + 3 >= tokens.length) break;
        const x1=lastC?2*x-lastC.x:x,y1=lastC?2*y-lastC.y:y;let x2=num(),y2=num(),nx=num(),ny=num();if(rel){x2+=x;y2+=y;nx+=x;ny+=y;}const ox=x,oy=y;for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*u*ox+3*u*u*t*x1+3*u*t*t*x2+t*t*t*nx,u*u*u*oy+3*u*u*t*y1+3*u*t*t*y2+t*t*t*ny);}x=nx;y=ny;lastC={x:x2,y:y2};lastQ=null;
      } else if (upper === 'Q') {
        if (i + 3 >= tokens.length) break;
        let x1=num(),y1=num(),nx=num(),ny=num();if(rel){x1+=x;y1+=y;nx+=x;ny+=y;}const ox=x,oy=y;for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*ox+2*u*t*x1+t*t*nx,u*u*oy+2*u*t*y1+t*t*ny);}x=nx;y=ny;lastQ={x:x1,y:y1};lastC=null;
      } else if (upper === 'A') {
        // ImageTracer normally emits cubic curves; fail closed for an unexpected SVG arc.
        throw new Error('خرج مسار منحني غير مدعوم من محرك تتبع الصورة.');
      } else { break; }
    }
    if (path.length) finish(false);
    return paths;
  }
  function polylinesToDxf(paths, width, height, factor) {
    let out = '0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1009\n0\nENDSEC\n0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLTYPE\n70\n1\n0\nLTYPE\n2\nCONTINUOUS\n70\n0\n3\nSolid line\n72\n65\n73\n0\n40\n0.0\n0\nENDTAB\n0\nTABLE\n2\nLAYER\n70\n2\n0\nLAYER\n2\n0\n70\n0\n62\n7\n6\nCONTINUOUS\n0\nLAYER\n2\nIMAGE_TRACE\n70\n0\n62\n7\n6\nCONTINUOUS\n0\nENDTAB\n0\nENDSEC\n0\nSECTION\n2\nBLOCKS\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n';
    let count = 0;
    for (const p of paths) {
      let vertices = p.points || [];
      if (vertices.length < 2) continue;
      if (p.closed && vertices.length > 2 && Math.hypot(vertices[0].x - vertices[vertices.length - 1].x, vertices[0].y - vertices[vertices.length - 1].y) < 1e-6) vertices = vertices.slice(0, -1);
      if (vertices.length < 2) continue;
      out += `0\nPOLYLINE\n8\nIMAGE_TRACE\n66\n1\n70\n${p.closed ? 1 : 0}\n`;
      for (const v of vertices) out += `0\nVERTEX\n8\nIMAGE_TRACE\n10\n${fmt(v.x * factor)}\n20\n${fmt((height - v.y) * factor)}\n30\n0\n`;
      out += '0\nSEQEND\n8\nIMAGE_TRACE\n';
      count++;
    }
    if (!count) throw new Error('لم ينتج التتبع أي مسارات قابلة للحفظ. جرّب صورة أوضح أو زِد الدقة.');
    out += '0\nENDSEC\n0\nEOF\n';
    return { bytes: enc.encode(out), count };
  }
  function downloadBytes(bytes, filename, mime = 'application/dxf') {
    const blob = new Blob([bytes], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = root.document.createElement('a'); a.href = url; a.download = filename; a.style.display = 'none';
    root.document.body.appendChild(a); a.click(); a.remove();
    root.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function mount() {
    if (!root.document || root.document.getElementById('sq162-cad-launch')) return;
    const doc = root.document;
    const style = doc.createElement('style');
    style.id = 'sq162-cad-style';
    style.textContent = `
      #sq162-cad-launch{position:fixed;right:14px;bottom:88px;z-index:2147483000;border:0;border-radius:28px;padding:12px 16px;background:#135ea8;color:#fff;font:700 14px system-ui;box-shadow:0 5px 20px #0004}
      #sq162-cad-overlay{position:fixed;inset:0;z-index:2147483001;background:#0009;display:none;align-items:center;justify-content:center;padding:10px;font-family:system-ui,sans-serif;color:#17202a}
      #sq162-cad-dialog{width:min(100%,980px);max-height:94vh;overflow:auto;background:#fff;border-radius:16px;padding:14px;box-sizing:border-box;direction:rtl;box-shadow:0 12px 55px #0006}
      #sq162-cad-dialog *{box-sizing:border-box} .sq162-head{display:flex;justify-content:space-between;align-items:center;gap:10px;border-bottom:1px solid #ddd;padding-bottom:10px;margin-bottom:10px}
      .sq162-actions{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.sq162-btn{border:0;border-radius:9px;padding:10px 13px;background:#155fa8;color:#fff;font-weight:700;font-size:13px}.sq162-btn:disabled{opacity:.45}.sq162-secondary{background:#e9eef4;color:#22313f}.sq162-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.sq162-panel{border:1px solid #d9e0e7;border-radius:11px;padding:10px;min-width:0}.sq162-panel label{display:block;font-size:13px;font-weight:700;margin-bottom:6px}.sq162-panel input[type=file]{width:100%;font-size:12px}.sq162-canvas{display:block;width:100%;height:220px;background:#fbfcfe;border:1px solid #e0e5eb;border-radius:7px;margin-top:8px;touch-action:manipulation}.sq162-note{font-size:12px;line-height:1.6;color:#465566}.sq162-status{padding:9px;border-radius:8px;background:#eef5fb;white-space:pre-wrap;font-size:13px;line-height:1.6;margin:8px 0}.sq162-tabs{display:flex;gap:7px;margin:6px 0 12px}.sq162-tab{border-radius:8px;padding:8px 11px;background:#e8edf2;color:#243342;border:0;font-weight:700}.sq162-tab.active{background:#155fa8;color:#fff}.sq162-section{display:none}.sq162-section.active{display:block}.sq162-scale{width:110px;max-width:35%;padding:8px;border:1px solid #c7d0da;border-radius:7px;direction:ltr}
      @media(max-width:650px){#sq162-cad-dialog{padding:10px}.sq162-grid{grid-template-columns:1fr}.sq162-canvas{height:190px}.sq162-head h3{font-size:16px}}
    `;
    doc.head.appendChild(style);
    const launch = doc.createElement('button'); launch.id = 'sq162-cad-launch'; launch.type = 'button'; launch.textContent = 'أدوات CAD';
    const overlay = doc.createElement('div'); overlay.id = 'sq162-cad-overlay';
    overlay.innerHTML = `
      <div id="sq162-cad-dialog" role="dialog" aria-modal="true" aria-label="أدوات CAD">
        <div class="sq162-head"><div><h3 style="margin:0">أدوات CAD المساحية</h3><div class="sq162-note">توجيه ثنائي النقاط وتحويل مجاني للصورة أو PDF إلى DXF</div></div><button id="sq162-close" class="sq162-btn sq162-secondary" type="button">إغلاق ومسح الملفات</button></div>
        <div class="sq162-tabs"><button class="sq162-tab active" data-tab="align" type="button">توجيه اللوحات</button><button class="sq162-tab" data-tab="raster" type="button">صورة / PDF إلى DXF</button></div>
        <section id="sq162-tab-align" class="sq162-section active">
          <div class="sq162-note">اختر اللوحة غير الموجهة ثم اللوحة المرجعية. التوجيه يحسب الدوران والمقياس والإزاحة من نقطتين متقابلتين. في ملفات DXF يُعدّل الملف الأصلي مباشرة ولا تُعاد كتابة أنواع العناصر أو الليارات. ملفات DWG تمر أولًا عبر محول LibreDWG المضمّن لإنتاج DXF.</div>
          <div class="sq162-grid" style="margin-top:10px">
            <div class="sq162-panel"><label for="sq162-source-file">اللوحة غير الموجهة (DWG / DXF)</label><input id="sq162-source-file" type="file" accept=".dwg,.dxf,application/dxf,application/octet-stream"><canvas id="sq162-source-canvas" class="sq162-canvas" aria-label="معاينة اللوحة غير الموجهة"></canvas><div id="sq162-source-info" class="sq162-note">لم يتم اختيار ملف بعد.</div></div>
            <div class="sq162-panel"><label for="sq162-target-file">اللوحة الموجهة المرجعية (DWG / DXF)</label><input id="sq162-target-file" type="file" accept=".dwg,.dxf,application/dxf,application/octet-stream"><canvas id="sq162-target-canvas" class="sq162-canvas" aria-label="معاينة اللوحة المرجعية"></canvas><div id="sq162-target-info" class="sq162-note">لم يتم اختيار ملف بعد.</div></div>
          </div>
          <div class="sq162-actions"><button id="sq162-start-pick" class="sq162-btn" type="button" disabled>ابدأ اختيار النقاط</button><button id="sq162-do-align" class="sq162-btn" type="button" disabled>توجيه وحفظ DXF</button><button id="sq162-reset-picks" class="sq162-btn sq162-secondary" type="button">إعادة اختيار النقاط</button></div>
          <div id="sq162-align-status" class="sq162-status" aria-live="polite">الخطوة 1: حمّل اللوحتين لبدء التوجيه.</div>
        </section>
        <section id="sq162-tab-raster" class="sq162-section">
          <div class="sq162-note">استخراج متجهات مجاني داخل التطبيق باستخدام ImageTracer. الناتج يتتبع الخطوط المرئية، ولا يستعيد النصوص أو الإحداثيات أو المقياس الأصلي من صورة ممسوحة ضوئيًا. اضبط عامل المقياس إذا كنت تعرف قيمة مناسبة.</div>
          <div class="sq162-panel" style="margin-top:10px"><label for="sq162-raster-file">اختر صورة أو PDF</label><input id="sq162-raster-file" type="file" accept="image/png,image/jpeg,image/webp,.jpg,.jpeg,.png,.webp,.pdf,application/pdf"><label for="sq162-pdf-page" style="margin-top:9px">رقم صفحة PDF</label><input id="sq162-pdf-page" type="number" min="1" step="1" value="1" class="sq162-scale"><label for="sq162-raster-scale" style="margin-top:9px">عامل المقياس (وحدة رسم لكل بكسل)</label><input id="sq162-raster-scale" type="number" min="0.000001" step="any" value="1" class="sq162-scale"><div class="sq162-actions"><button id="sq162-trace" class="sq162-btn" type="button" disabled>تحويل وحفظ DXF</button></div><div id="sq162-raster-status" class="sq162-status" aria-live="polite">اختر ملفًا للبدء.</div><canvas id="sq162-raster-canvas" class="sq162-canvas" style="display:none" aria-label="معاينة الصورة قبل التحويل"></canvas></div>
        </section>
        <div class="sq162-note" style="margin-top:10px">لا يُستخدم localStorage أو قاعدة بيانات لحفظ اللوحات في هذه الأداة. عند الإغلاق تُفرّغ الذاكرة المؤقتة وعناصر اختيار الملفات.</div>
      </div>`;
    doc.body.appendChild(launch); doc.body.appendChild(overlay);
    const el = id => doc.getElementById(id);
    const state = { source: null, target: null, pickStage: -1, picks: [], tracerFile: null, rasterCanvas: null };
    function status(text, id = 'sq162-align-status') { el(id).textContent = text; }
    function fileTitle(file) { return file && file.name ? file.name : 'drawing'; }
    function clearCanvas(canvas) { const c = canvas.getContext('2d'); c.clearRect(0, 0, canvas.width, canvas.height); }
    function clearDrawing(which) {
      state[which] = null;
      const prefix = which === 'source' ? 'source' : 'target';
      el(`sq162-${prefix}-file`).value = ''; el(`sq162-${prefix}-info`).textContent = 'لم يتم اختيار ملف بعد.';
      clearCanvas(el(`sq162-${prefix}-canvas`));
      state.picks = []; state.pickStage = -1; updatePickUi();
    }
    function cleanup() {
      clearDrawing('source'); clearDrawing('target');
      state.tracerFile = null; state.rasterCanvas = null;
      el('sq162-raster-file').value = ''; el('sq162-raster-pdf-page').value = '1'; el('sq162-raster-scale').value = '1';
      el('sq162-raster-canvas').style.display = 'none'; clearCanvas(el('sq162-raster-canvas'));
      el('sq162-trace').disabled = true; status('تم مسح الملفات والنقاط من الذاكرة المؤقتة.');
      status('اختر ملفًا للبدء.', 'sq162-raster-status');
    }
    function updatePickUi() {
      el('sq162-start-pick').disabled = !(state.source && state.target);
      el('sq162-do-align').disabled = state.picks.length !== 4 || !state.source || !state.target;
      for (const which of ['source', 'target']) {
        const c = el(`sq162-${which}-canvas`); c.style.outline = state.pickStage >= 0 && ((state.pickStage < 2 && which === 'source') || (state.pickStage >= 2 && which === 'target')) ? '2px solid #16834a' : 'none';
      }
      if (state.pickStage >= 0 && state.pickStage < 4) {
        const descriptions = ['اضغط على النقطة الأولى في اللوحة غير الموجهة.', 'اضغط على النقطة الثانية في اللوحة غير الموجهة.', 'اضغط على النقطة المقابلة للأولى في اللوحة المرجعية.', 'اضغط على النقطة المقابلة للثانية في اللوحة المرجعية.'];
        status(`النقطة ${state.pickStage + 1} من 4\n${descriptions[state.pickStage]}\n${state.picks.map((p, i) => `${i + 1}: X=${fmt(p.x)}, Y=${fmt(p.y)}`).join('\n')}`);
      }
    }
    function drawGeometry(canvas, geom, picks, firstPickIndex) {
      if (!geom) return;
      const dpr = Math.min(root.devicePixelRatio || 1, 2), w = Math.max(240, canvas.clientWidth || 280), h = Math.max(160, canvas.clientHeight || 220);
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      const ctx = canvas.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.fillStyle = '#fbfcfe'; ctx.fillRect(0, 0, w, h);
      const pad = 12, sx = (w - 2 * pad) / (geom.maxX - geom.minX), sy = (h - 2 * pad) / (geom.maxY - geom.minY), sc = Math.max(1e-12, Math.min(sx, sy));
      const usedW = (geom.maxX - geom.minX) * sc, usedH = (geom.maxY - geom.minY) * sc, ox = (w - usedW) / 2, oy = (h - usedH) / 2;
      const pt = p => ({ x: ox + (p.x - geom.minX) * sc, y: h - oy - (p.y - geom.minY) * sc });
      ctx.strokeStyle = '#1976b8'; ctx.lineWidth = 1; ctx.beginPath();
      for (const s of geom.segments) { const a = pt(s.a), b = pt(s.b); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); }
      ctx.stroke();
      if (!geom.segments.length) { ctx.strokeStyle = '#1976b8'; ctx.lineWidth = 1; for (const q of geom.points.slice(0, 8000)) { const p = pt(q); ctx.beginPath(); ctx.moveTo(p.x - 3, p.y); ctx.lineTo(p.x + 3, p.y); ctx.moveTo(p.x, p.y - 3); ctx.lineTo(p.x, p.y + 3); ctx.stroke(); } }
      ctx.fillStyle = '#d63333';
      for (let i = 0; i < picks.length; i++) {
        const p = pt(picks[i]); ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#fff'; ctx.font = '10px sans-serif'; ctx.fillText(String(i + firstPickIndex + 1), p.x + 5, p.y - 5); ctx.fillStyle = '#d63333';
      }
      canvas._sqMap = { geom, width: w, height: h, pad, sc, ox, oy, pt };
    }
    function redrawAll() {
      if (state.source) drawGeometry(el('sq162-source-canvas'), state.source.geom, state.picks.slice(0, 2), 0);
      if (state.target) drawGeometry(el('sq162-target-canvas'), state.target.geom, state.picks.slice(2, 4), 2);
    }
    async function loadCadFile(which, file) {
      if (!file) return;
      state.picks = []; state.pickStage = -1; updatePickUi();
      if (!/\.(dwg|dxf)$/i.test(file.name)) throw new Error('اختر ملف DWG أو DXF فقط.');
      if (typeof root.parseFile !== 'function') throw new Error('قارئ الملفات المشترك غير متاح في هذه الشاشة.');
      status('جارٍ قراءة الملف وتحويل DWG إلى DXF عند الحاجة...');
      const model = await root.parseFile(file, { rawOnly: true, conversionOnly: true, retainRawDWG: false });
      const raw = model && model.rawDXFBytes;
      if (!raw || !raw.length) throw new Error('لم يُنتج القارئ بيانات DXF. لا يمكن متابعة التوجيه دون ملف صالح.');
      const bytes = raw instanceof Uint8Array ? raw : new Uint8Array(raw);
      const geom = readGeometry(bytes);
      state[which] = { file, bytes, geom };
      el(`sq162-${which === 'source' ? 'source' : 'target'}-info`).textContent = `${file.name}\n${geom.segments.length.toLocaleString()} مقطع معاينة. يتم الاحتفاظ بالبيانات مؤقتًا في الذاكرة فقط.`;
      redrawAll(); updatePickUi();
      status(`تم تجهيز ${file.name} للمعاينة.`);
    }
    el('sq162-source-file').addEventListener('change', async e => { try { await loadCadFile('source', e.target.files[0]); } catch (err) { clearDrawing('source'); status(String(err.message || err)); } });
    el('sq162-target-file').addEventListener('change', async e => { try { await loadCadFile('target', e.target.files[0]); } catch (err) { clearDrawing('target'); status(String(err.message || err)); } });
    el('sq162-start-pick').addEventListener('click', () => { state.picks = []; state.pickStage = 0; updatePickUi(); redrawAll(); });
    el('sq162-reset-picks').addEventListener('click', () => { state.picks = []; state.pickStage = state.source && state.target ? 0 : -1; updatePickUi(); redrawAll(); });
    function handleCanvasPick(which, event) {
      if (state.pickStage < 0 || state.pickStage >= 4) return;
      const expected = state.pickStage < 2 ? 'source' : 'target';
      if (which !== expected) { status(expected === 'source' ? 'اختر النقطة على اللوحة غير الموجهة أولًا.' : 'اختر النقطة المقابلة على اللوحة المرجعية أولًا.'); return; }
      const canvas = event.currentTarget, map = canvas._sqMap;
      if (!map) return;
      const rect = canvas.getBoundingClientRect(), px = event.clientX - rect.left, py = event.clientY - rect.top;
      const world = { x: state[which].geom.minX + (px - map.ox) / map.sc, y: state[which].geom.minY + (map.height - map.oy - py) / map.sc };
      try { state.picks.push(nearestPoint(state[which].geom, world)); state.pickStage++; updatePickUi(); redrawAll(); }
      catch (err) { status(String(err.message || err)); }
    }
    el('sq162-source-canvas').addEventListener('click', e => handleCanvasPick('source', e));
    el('sq162-target-canvas').addEventListener('click', e => handleCanvasPick('target', e));
    el('sq162-do-align').addEventListener('click', () => {
      try {
        if (!state.source || !state.target || state.picks.length !== 4) throw new Error('حمّل اللوحتين واختر أربع نقاط متقابلة أولًا.');
        const [a, b, c, d] = state.picks;
        const result = transformDxfBytes(state.source.bytes, a, b, c, d);
        const base = fileTitle(state.source.file).replace(/\.[^.]+$/, '');
        downloadBytes(result.bytes, `${base}_ALIGNED.dxf`);
        status(`تم إنشاء DXF الموجّه.\nالدوران: ${fmt(result.rotationDegrees)} درجة\nالمقياس: ${fmt(result.scale)}\nعدد مواضع التعديل: ${result.editCount}\nلم يتم تغيير اسم أي layer أو نوع أي عنصر. لم يتم حفظ الملف داخل ذاكرة التطبيق بعد التنزيل.`);
      } catch (err) { status(String(err.message || err)); }
    });
    launch.addEventListener('click', () => { overlay.style.display = 'flex'; });
    el('sq162-close').addEventListener('click', () => { cleanup(); overlay.style.display = 'none'; });
    overlay.addEventListener('click', e => { if (e.target === overlay) { cleanup(); overlay.style.display = 'none'; } });
    doc.addEventListener('keydown', e => { if (e.key === 'Escape' && overlay.style.display === 'flex') { cleanup(); overlay.style.display = 'none'; } });
    for (const tab of overlay.querySelectorAll('[data-tab]')) tab.addEventListener('click', () => {
      for (const t of overlay.querySelectorAll('[data-tab]')) t.classList.toggle('active', t === tab);
      for (const s of overlay.querySelectorAll('.sq162-section')) s.classList.toggle('active', s.id === `sq162-tab-${tab.dataset.tab}`);
    });
    // Include DWG in any existing CAD picker that already accepts DXF, including pickers
    // created later by project screens, without changing unrelated image/document pickers.
    function broadenCadPickers(scope) {
      for (const input of scope.querySelectorAll ? scope.querySelectorAll('input[type="file"]') : []) {
        const accept = input.getAttribute('accept') || '';
        if (/\.dxf/i.test(accept) && !/\.dwg/i.test(accept)) input.setAttribute('accept', `${accept},.dwg`);
      }
    }
    broadenCadPickers(doc);
    if (root.MutationObserver) new root.MutationObserver(records => { for (const r of records) for (const n of r.addedNodes) if (n.nodeType === 1) broadenCadPickers(n); }).observe(doc.documentElement, { childList: true, subtree: true });

    // Raster/PDF conversion. PDF.js and ImageTracer are embedded by the build workflow;
    // this keeps this feature free and usable offline after installation.
    const rasterFileInput = el('sq162-raster-file'), traceBtn = el('sq162-trace'), rasterCanvas = el('sq162-raster-canvas');
    rasterFileInput.addEventListener('change', () => { state.tracerFile = rasterFileInput.files[0] || null; traceBtn.disabled = !state.tracerFile; status(state.tracerFile ? `تم اختيار ${state.tracerFile.name}.` : 'اختر ملفًا للبدء.', 'sq162-raster-status'); });
    traceBtn.addEventListener('click', async () => {
      const file = state.tracerFile;
      try {
        if (!file) throw new Error('اختر صورة أو PDF أولًا.');
        if (!root.ImageTracer || typeof root.ImageTracer.imagedataToSVG !== 'function') throw new Error('محرك التتبع المجاني غير محمّل في هذه النسخة.');
        traceBtn.disabled = true; status('جارٍ تجهيز الصورة واستخراج الخطوط...', 'sq162-raster-status');
        const maxDim = 1400; let canvas = doc.createElement('canvas'), ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (/\.pdf$/i.test(file.name) || file.type === 'application/pdf') {
          if (!root.pdfjsLib || typeof root.pdfjsLib.getDocument !== 'function') throw new Error('قارئ PDF غير مضمّن في هذه النسخة.');
          const pdf = await root.pdfjsLib.getDocument({ data: new Uint8Array(await file.arrayBuffer()), disableWorker: true, useSystemFonts: true }).promise;
          const pageNumber = Math.max(1, Math.min(pdf.numPages, Number.parseInt(el('sq162-pdf-page').value || '1', 10) || 1));
          const page = await pdf.getPage(pageNumber), base = page.getViewport({ scale: 1 });
          const sc = Math.min(2, maxDim / base.width, maxDim / base.height);
          const viewport = page.getViewport({ scale: sc }); canvas.width = Math.max(1, Math.floor(viewport.width)); canvas.height = Math.max(1, Math.floor(viewport.height));
          await page.render({ canvasContext: ctx, viewport }).promise;
          try { pdf.destroy(); } catch (_) {}
        } else {
          const url = URL.createObjectURL(file);
          try {
            const image = new Image(); image.src = url; await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = () => reject(new Error('تعذر فتح الصورة.')); });
            const sc = Math.min(1, maxDim / image.naturalWidth, maxDim / image.naturalHeight);
            canvas.width = Math.max(1, Math.floor(image.naturalWidth * sc)); canvas.height = Math.max(1, Math.floor(image.naturalHeight * sc));
            ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
          } finally { URL.revokeObjectURL(url); }
        }
        if (canvas.width * canvas.height > maxDim * maxDim) throw new Error('حجم الصفحة أكبر من الحد الآمن للتحويل.');
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height), px = imageData.data;
        // Otsu threshold keeps foreground/background separation image-dependent.
        const hist = new Uint32Array(256); let total = canvas.width * canvas.height, sum = 0;
        for (let i = 0; i < px.length; i += 4) { const g = Math.round(0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2]); hist[g]++; sum += g; }
        let sumB = 0, wB = 0, best = -1, threshold = 190;
        for (let t = 0; t < 256; t++) { wB += hist[t]; if (!wB) continue; const wF = total - wB; if (!wF) break; sumB += t * hist[t]; const mB = sumB / wB, mF = (sum - sumB) / wF; const between = wB * wF * (mB - mF) ** 2; if (between > best) { best = between; threshold = t; } }
        for (let i = 0; i < px.length; i += 4) { const g = Math.round(0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2]), v = g <= Math.min(245, Math.max(80, threshold)) ? 0 : 255; px[i] = px[i + 1] = px[i + 2] = v; px[i + 3] = 255; }
        ctx.putImageData(imageData, 0, 0);
        rasterCanvas.width = canvas.width; rasterCanvas.height = canvas.height; rasterCanvas.style.display = 'block';
        const rctx = rasterCanvas.getContext('2d'); rctx.clearRect(0, 0, rasterCanvas.width, rasterCanvas.height); rctx.drawImage(canvas, 0, 0);
        const svg = root.ImageTracer.imagedataToSVG(imageData, { numberofcolors: 2, colorquantcycles: 1, ltres: 1.1, qtres: 1.1, pathomit: 4, roundcoords: 1, scale: 1, viewbox: true });
        const parsed = new DOMParser().parseFromString(svg, 'image/svg+xml');
        const paths = [];
        for (const pathNode of Array.from(parsed.querySelectorAll('path'))) {
          const holder = pathNode.closest('g'); const fill = (pathNode.getAttribute('fill') || (holder && holder.getAttribute('fill')) || '').toLowerCase();
          const rgb = fill.match(/#([0-9a-f]{3,6})/i);
          let light = /white|#fff/.test(fill);
          if (rgb) { const hex = rgb[1].length === 3 ? rgb[1].split('').map(c => c + c).join('') : rgb[1].slice(0, 6); light = parseInt(hex.slice(0, 2), 16) + parseInt(hex.slice(2, 4), 16) + parseInt(hex.slice(4, 6), 16) > 600; }
          if (!light && pathNode.getAttribute('d')) paths.push(...svgPathToPolylines(pathNode.getAttribute('d'), 8));
        }
        const factor = Number(el('sq162-raster-scale').value);
        if (!finite(factor) || factor <= 0) throw new Error('عامل المقياس يجب أن يكون رقمًا موجبًا.');
        const result = polylinesToDxf(paths, canvas.width, canvas.height, factor);
        const baseName = file.name.replace(/\.[^.]+$/, ''); downloadBytes(result.bytes, `${baseName}_TRACE.dxf`);
        status(`اكتمل التحويل إلى DXF.\nعدد مسارات المتجهات: ${result.count}\nأبعاد الصورة المستخدمة: ${canvas.width} × ${canvas.height} بكسل\nعامل المقياس: ${fmt(factor)} وحدة/بكسل\nهذا تتبّع تقريبي للخطوط المرئية وليس استعادةً لبيانات CAD الأصلية.`, 'sq162-raster-status');
        canvas.width = 1; canvas.height = 1; // release pixel buffer after creating the DXF
      } catch (err) { status(String(err.message || err), 'sq162-raster-status'); }
      finally { traceBtn.disabled = !state.tracerFile; }
    });

    root.addEventListener('pagehide', cleanup, { once: true });
  }
  return { solve, transformDxfBytes, readGeometry, nearestPoint, svgPathToPolylines, polylinesToDxf, mount };
});
