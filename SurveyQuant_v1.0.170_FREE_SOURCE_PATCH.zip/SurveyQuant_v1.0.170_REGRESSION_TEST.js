'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const cad=require('./SurveyQuant_v1.0.170_CAD_ENGINE.js');
function blockAxisFixture(){
 const p=['0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','0','ENDSEC','0','SECTION','2','BLOCKS','0','BLOCK','5','20','100','AcDbEntity','8','0','100','AcDbBlockBegin','2','GRID_AXES','10','0','20','0','30','0','0','XLINE','8','GRID_AXES','10','0','20','0','30','0','11','1','21','0','31','0','0','RAY','8','GRID_AXES','10','0','20','0','30','0','11','0','21','1','31','0','0','TEXT','8','GRID_LABELS','10','0','20','5','30','0','40','1.5','1','A-1','0','ENDBLK','5','21','100','AcDbEntity','8','0','100','AcDbBlockEnd','0','ENDSEC','0','SECTION','2','ENTITIES','0','INSERT','5','50','100','AcDbEntity','8','0','100','AcDbBlockReference','2','GRID_AXES','10','500','20','900','30','0','41','1','42','1','43','1','50','0','0','ENDSEC','0','EOF',''];
 return new TextEncoder().encode(p.join('\r\n'));
}
function testAxesAndSave(){
 const raw=blockAxisFixture(),before=Buffer.from(raw).toString('hex'),g=cad.readGeometry(raw);
 assert.equal(g.segments.length,2);assert.ok(g.segments.every(s=>[s.a.x,s.a.y,s.b.x,s.b.y].every(Number.isFinite)));
 assert.ok(g.texts.some(t=>t.text==='A-1'));assert.equal(Buffer.from(raw).toString('hex'),before);
 assert.ok(g.maxX-g.minX<1000,'infinite XLINE must not expand fit extents');assert.ok(g.maxY-g.minY<1000,'infinite RAY must not expand fit extents');
 const picks=[{x:500,y:900},{x:600,y:900},{x:2000,y:3000},{x:2000,y:3200}],saved=cad.createOrientedDxfBytes(raw,picks),moved=cad.readGeometry(saved.bytes);
 assert.equal(moved.segments.length,2);assert.ok(moved.texts.some(t=>t.text==='A-1'));assert.ok(Math.abs(moved.texts.find(t=>t.text==='A-1').position.x-1990)<1e-8);assert.ok(Math.abs(moved.texts.find(t=>t.text==='A-1').position.y-3000)<1e-8);
 return {segments:g.segments.length,axisLabels:g.texts.length,extents:[g.minX,g.minY,g.maxX,g.maxY],savedSegments:moved.segments.length};
}
function testSnapModes(){
 const geom={segments:[{a:{x:-10,y:0},b:{x:10,y:0}},{a:{x:0,y:-10},b:{x:0,y:10}}],curves:[],points:[]};
 const intersection=cad.snapPoint(geom,{x:.2,y:.2},'intersection',1);
 const endpoint=cad.snapPoint(geom,{x:-10,y:.1},'endpoint',.5);
 const midpoint=cad.snapPoint(geom,{x:0,y:.1},'midpoint',.5);
 const nearest=cad.snapPoint(geom,{x:4.8,y:.1},'nearest',.5);
 assert.equal(intersection.type,'intersection');assert.ok(Math.abs(intersection.point.x)<1e-8&&Math.abs(intersection.point.y)<1e-8);
 assert.equal(endpoint.type,'endpoint');assert.ok(Math.abs(endpoint.point.x+10)<1e-8);
 assert.equal(midpoint.type,'midpoint');assert.ok(Math.abs(midpoint.point.x)<1e-8&&Math.abs(midpoint.point.y)<1e-8);
 assert.equal(nearest.type,'nearest');assert.ok(Math.abs(nearest.point.x-4.8)<1e-8&&Math.abs(nearest.point.y)<1e-8);
 return {intersection:endpoint&&intersection.type,endpoint:endpoint.type,midpoint:midpoint.type,nearest:nearest.type};
}
function testSameNameIdentity(){
 const f={name:'same.dwg',size:3,lastModified:1};assert.notEqual(cad.fileFingerprint(f,new Uint8Array([1,2,3])),cad.fileFingerprint(f,new Uint8Array([1,2,4])));return true;
}
function testPdfDxf(jpegs,out){
 const rects=[{x:0,y:0,width:1600,height:1132},{x:1600,y:0,width:1600,height:1132},{x:0,y:1132,width:1600,height:1132},{x:1600,y:1132,width:1600,height:1132}];
 const tiles=jpegs.map((p,i)=>({bytes:new Uint8Array(fs.readFileSync(p)),...rects[i]}));const dxf=cad.makeEmbeddedRasterDxf(tiles,3200,2264,1);fs.writeFileSync(out,dxf);
 const txt=Buffer.from(dxf).toString('latin1');assert.equal((txt.match(/\nOLE2FRAME\r?\n/g)||[]).length,4);assert.ok(!/\nIMAGE\r?\n|\nIMAGEDEF\r?\n|\.png/i.test(txt));assert.ok(!txt.includes('PK\x03\x04'));
 // Critical regression: the app's own CAD reader must reopen the PDF result as four image tiles.
 const g=cad.readGeometry(dxf);assert.equal(g.oleFrames.length,4);assert.equal(g.segments.length,0);assert.equal(g.texts.length,0);
 assert.deepEqual([g.minX,g.minY,g.maxX,g.maxY],[0,0,3200,2264]);
 for(const frame of g.oleFrames){assert.ok(frame.jpeg.length>1000);assert.deepEqual([...frame.jpeg.slice(0,2)],[0xff,0xd8]);assert.deepEqual([...frame.jpeg.slice(-2)],[0xff,0xd9]);}
 return {dxfBytes:dxf.length,tiles:g.oleFrames.length,jpegBytes:tiles.reduce((n,t)=>n+t.bytes.length,0),extent:[g.minX,g.minY,g.maxX,g.maxY],maxTile:'1600x1132',reopen:'PASS'};
}
const result={axesAndSavedDXF:testAxesAndSave(),snapModes:testSnapModes(),sameBasenameContentIdentity:testSameNameIdentity()};
if(process.argv.length>2){const a=process.argv.slice(2);if(a.length!==5)throw Error('Pass four jpeg fixture paths then output DXF path');result.pdfSingleDxf=testPdfDxf(a.slice(0,4),a[4]);}
console.log(JSON.stringify({ok:true,...result},null,2));
