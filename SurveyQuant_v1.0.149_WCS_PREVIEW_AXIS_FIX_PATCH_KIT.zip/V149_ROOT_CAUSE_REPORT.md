# SurveyQuant V1.0.149: Root-cause review

## What was wrong in the published V148 build

The V148 GitHub Actions job did complete successfully, produced a signed APK, and verified versionCode/versionName. That only proved packaging and the test cases bundled with that workflow. The user's observed behavior was credible: the active preview/picking path still used the legacy parser on drawings that did not trigger a non-canonical-OCS fallback, and axis-label block traversal did not use one consistent WCS placement transform. Therefore a successful two-point solver test did not guarantee the two picked pixels represented the correct world coordinates.

## V149 changes

- The active dual-board orientation module now detects non-canonical OCS normals in model/paper-space entities and nested block records *before* invoking the legacy drawing parser. Such files use the WCS-converted preview geometry from the raw DXF records instead of receiving raw local X/Y coordinates from the legacy parser.
- OCS arbitrary-axis basis conversion is applied to supported OCS points before bounding-box construction, canvas projection, and OSNAP/ID-point selection.
- INSERT preview geometry and nested block-axis labels use one OCS-aware insertion matrix that accounts for insert origin, base point, rotation, scale, and extrusion normal.
- Text anchors and text direction vectors inside nested inserts are converted through the same WCS chain. Axis labels are read from text records after their coordinate conversion.
- The actual dual-board preview canvas was reduced from 44vh/250-500px to 38vh/220-420px.
- The active alignment screen visibly identifies this module as `Alignment كامل للوحة | WCS • V149`, and the loaded-file message indicates when the corrected WCS preview fallback is used.
- The version code/name is bumped to 149/1.0.149. The existing local DWG WASM/LibreDWG bridge and the tested V130 alignment engine remain present.

## Validation performed

- WCS preview helper tests: +Z default OCS, -Z OCS, tilted OCS basis orthogonality, INSERT origin/base point/rotation/scale, nested block geometry, and text-direction projection.
- All 8 inherited regression suites were re-run against the V149 HTML: closed concrete outline recovery, large-file stability/24,000 entities, V130 orientation precision comparison, alignment safety, MULTILEADER, 3D/OCS/axis names, DXF/DWG bridge, and V130 DWG/selection regression.
- All 10 inline JavaScript blocks passed `node --check`; all new Python helpers passed `py_compile`.
- The APK packaging helper successfully injected the tested HTML into the actual signed V148 APK, rewrote the binary manifest to 1.0.149/versionCode 149, and verified the local DWG WASM entry remained in the unsigned package.

## Limits

No user-originated DWG/DXF file was attached in this turn. Therefore there is no claim that this has been field-validated on the exact file that previously distorted. The local APK package check was not a signing operation; GitHub Actions must sign the final APK with the repository keystore secrets. Opaque Proxy/Civil 3D objects whose source geometry is not exposed by the DWG-to-DXF engine cannot be guaranteed by this preview-coordinate patch.
