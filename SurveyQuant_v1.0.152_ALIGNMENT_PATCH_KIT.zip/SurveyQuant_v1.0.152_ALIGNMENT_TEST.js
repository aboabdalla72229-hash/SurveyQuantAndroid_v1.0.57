'use strict';
const assert=require('node:assert/strict');
const core=require('./SurveyQuant_v1.0.152_ALIGNMENT_CORE.js');
const t=core.solveAlignment({x:0,y:0},{x:10,y:0},{x:100,y:100},{x:100,y:120});
assert.ok(Math.abs(t.scale-2)<1e-10);
assert.ok(Math.abs(t.angleDeg-90)<1e-8);
assert.ok(Math.hypot(t.tx-100,t.ty-100)<1e-8);
assert.ok(t.residual<1e-8);
const input=[
'0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','0','ENDSEC',
'0','SECTION','2','TABLES','0','TABLE','2','LAYER','70','1','0','LAYER','2','ROAD','70','0','62','7','6','CONTINUOUS','0','ENDTAB','0','ENDSEC',
'0','SECTION','2','ENTITIES',
'0','LINE','8','ROAD','10','0','20','0','30','0','11','10','21','0','31','0',
'0','CIRCLE','8','ROAD','10','5','20','0','30','0','40','2',
'0','TEXT','8','ROAD','10','1','20','0','30','0','40','2','1','AXIS A','50','0',
'0','LWPOLYLINE','8','ROAD','90','2','70','0','38','0','10','0','20','0','10','10','20','0',
'0','INSERT','8','ROAD','2','BLOCKA','10','3','20','4','30','0','41','1','42','1','43','1','50','30',
'0','ENDSEC','0','EOF',''
].join('\r\n');
const before=Buffer.from(input,'latin1');
const result=core.transformDxfBytes(new Uint8Array(before),t);
assert.ok(result.entitiesTransformed>=5,`transformed ${result.entitiesTransformed}`);
const out=Buffer.from(result.bytes).toString('latin1');
assert.match(out,/10\r\n100\r\n20\r\n100/); // transformed LINE start
assert.match(out,/40\r\n4(?:\.0*)?\r\n/); // circle radius / text height scaled
assert.match(out,/1\r\nAXIS A\r\n/); // original text retained
assert.match(out,/2\r\nBLOCKA\r\n/); // insert block retained
assert.match(out,/41\r\n2(?:\.0*)?\r\n/); // insert scale adjusted
assert.match(out,/2\r\nROAD\r\n/); // layer name retained
assert.match(out,/0\r\nEOF\r\n?$/);
assert.equal(result.types.LINE,1);
assert.equal(result.types.CIRCLE,1);
assert.equal(result.types.TEXT,1);
assert.equal(result.types.LWPOLYLINE,1);
assert.equal(result.types.INSERT,1);
const unsupported=[ '0','SECTION','2','ENTITIES','0','ACAD_PROXY_ENTITY','8','0','310','0102ABCD','0','ENDSEC','0','EOF','' ].join('\n');
assert.throws(()=>core.transformDxfBytes(new TextEncoder().encode(unsupported),t),/غير مكشوفة/ );
assert.throws(()=>core.solveAlignment({x:0,y:0},{x:0,y:0},{x:1,y:1},{x:2,y:2}),/نقطتين متطابقتين/);
console.log('PASS V152 Alignment core: two-point solve, XY orientation, uniform scale, preserved layer/text/block records, closed DXF, and opaque CAD fail-closed protection.');
