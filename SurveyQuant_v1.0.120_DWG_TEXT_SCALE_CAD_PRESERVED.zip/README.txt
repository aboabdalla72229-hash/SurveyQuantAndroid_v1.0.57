SurveyQuant v1.0.120 DWG text-scale / CAD preservation patch kit

Included in the ZIP:
- SurveyQuant_v1.0.120_RUN_RECIPE.py: adapts and executes the historical v1.0.119 Android build shell steps from Git history, with fail-closed V120 changes.
- SurveyQuant_v1.0.120_APPLY_PATCH.py: accepts the intermediate formula emitted by recipe step 10, then scales CAD annotation text with drawing fit scale and board zoom; the patch is safe to rerun; fixes four DWG extension matchers; allows DWG/DXF in dynamically-created file inputs.
- SurveyQuant_v1.0.120_DWG_TEXT_SCALE_TEST.js: static regression checks used by the build workflow.
- README.txt: usage and limits.

Installation in GitHub:
1. Upload the ZIP to the repository root using this exact filename: SurveyQuant_v1.0.120_DWG_TEXT_SCALE_CAD_PRESERVED.zip
2. Save build-v120-dwg-text-scale.yml as .github/workflows/build-v120-dwg-text-scale.yml.
3. Confirm repository Actions permissions allow contents: write, then run the workflow manually.
4. Do not treat the APK as ready until the GitHub Actions run is green and its APK artifact is downloaded.

CAD preservation: this patch does not modify the byte-preserving CAD transform or rebuild the source entities just to render annotations. The existing builder's DWG-to-DXF conversion, STORM real-file tests and CAD-preservation checks remain part of the workflow. A static test is not a substitute for opening real user DWG drawings in the app.
