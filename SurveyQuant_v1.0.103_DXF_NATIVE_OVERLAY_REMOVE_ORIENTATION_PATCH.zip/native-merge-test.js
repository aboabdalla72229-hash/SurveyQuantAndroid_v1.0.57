function inspectPreservedReferenceDXF(content){
 try{
  // Validate the DXF using parsed group-code/value pairs, not brittle substring checks.
  // A BOM, padded group codes, or text inside the ORIGINAL drawing containing words
  // such as "undefined" or "Infinity" must not be treated as DXF corruption.
  const text=String(content||'').replace(/^(?:ï»¿|\uFEFF)/,'');
  const pairs=sqDxfPairsWithOffsets(text);
  for(const name of ['HEADER','TABLES','ENTITIES']){
   if(!sqFindDxfSection(pairs,name))return 'فحص DXF: القسم الأساسي '+name+' غير موجود أو غير مكتمل.';
  }
  if(!sqFindDxfLayerTable(pairs))return 'فحص DXF: جدول الطبقات LAYER غير مكتمل.';
  if(!pairs.some(p=>p.code==='0'&&p.value.toUpperCase()==='EOF'))return 'فحص DXF: علامة نهاية الملف EOF غير موجودة.';
  return '';
 }catch(e){return 'فحص DXF تعذر بسبب بنية غير مقروءة: '+String(e?.message||e);}
}
function validatePreservedReferenceDXF(content){return inspectPreservedReferenceDXF(content)==='';}
function sqDxfPairsWithOffsets(text){
 const lines=[];let pos=0;
 while(pos<text.length){const nl=text.indexOf('\n',pos),lineEnd=nl<0?text.length:nl;let valueEnd=lineEnd;if(valueEnd>pos&&text[valueEnd-1]==='\r')valueEnd--;lines.push({text:text.slice(pos,valueEnd),start:pos,valueEnd,end:nl<0?text.length:nl+1});pos=nl<0?text.length:nl+1;}
 const pairs=[];for(let i=0;i+1<lines.length;i+=2)pairs.push({code:lines[i].text.trim(),value:lines[i+1].text.trim(),start:lines[i].start,end:lines[i+1].end,valueStart:lines[i+1].start,valueEnd:lines[i+1].valueEnd});return pairs;
}
function sqFindDxfSection(pairs,name){
 for(let i=0;i+1<pairs.length;i++){if(pairs[i].code==='0'&&pairs[i].value.toUpperCase()==='SECTION'&&pairs[i+1].code==='2'&&pairs[i+1].value.toUpperCase()===name.toUpperCase()){for(let j=i+2;j<pairs.length;j++)if(pairs[j].code==='0'&&pairs[j].value.toUpperCase()==='ENDSEC')return{start:pairs[i].start,contentStart:pairs[i+1].end,endSec:pairs[j],end:pairs[j].end};}}
 return null;
}
function sqFindDxfLayerTable(pairs){
 for(let i=0;i+1<pairs.length;i++){if(pairs[i].code!=='0'||pairs[i].value.toUpperCase()!=='TABLE'||pairs[i+1].code!=='2'||pairs[i+1].value.toUpperCase()!=='LAYER')continue;let end=-1;for(let j=i+2;j<pairs.length;j++)if(pairs[j].code==='0'&&pairs[j].value.toUpperCase()==='ENDTAB'){end=j;break;}if(end<0)return null;const rows=[];for(let j=i+2;j<end;j++)if(pairs[j].code==='0'&&pairs[j].value.toUpperCase()==='LAYER'){let k=j+1;while(k<end&&pairs[k].code!=='0')k++;const namePair=pairs.slice(j+1,k).find(p=>p.code==='2');if(namePair)rows.push({name:namePair.value,start:pairs[j].start,end:k<end?pairs[k].start:pairs[end].start});}const countPair=pairs.slice(i+2,rows.length?pairs.findIndex((p,idx)=>idx>i+1&&p.code==='0'&&p.value.toUpperCase()==='LAYER'):end).find(p=>p.code==='70')||null;return{tableStart:pairs[i].start,endTab:pairs[end],rows,countPair};}
 return null;
}
function sqConcatBytes(parts){let n=parts.reduce((a,p)=>a+p.length,0),out=new Uint8Array(n),at=0;for(const p of parts){out.set(p,at);at+=p.length;}return out;}
function sqEncodeAscii(text){return new TextEncoder().encode(String(text));}
function sqFindDxfTable(pairs,tableName,rowName){
 for(let i=0;i+1<pairs.length;i++){if(pairs[i].code!=='0'||pairs[i].value.toUpperCase()!=='TABLE'||pairs[i+1].code!=='2'||pairs[i+1].value.toUpperCase()!==tableName.toUpperCase())continue;let end=-1;for(let j=i+2;j<pairs.length;j++)if(pairs[j].code==='0'&&pairs[j].value.toUpperCase()==='ENDTAB'){end=j;break;}if(end<0)return null;const records=[];for(let j=i+2;j<end;j++)if(pairs[j].code==='0'&&pairs[j].value.toUpperCase()===rowName.toUpperCase()){let k=j+1;while(k<end&&pairs[k].code!=='0')k++;const fields=pairs.slice(j+1,k);records.push({start:pairs[j].start,end:k<end?pairs[k].start:pairs[end].start,fields});}const firstRecordIndex=records.length?pairs.findIndex((p,idx)=>idx>i+1&&p.code==='0'&&p.value.toUpperCase()===rowName.toUpperCase()):end;const tableHeaderPairs=pairs.slice(i+2,firstRecordIndex);const countPair=tableHeaderPairs.find(p=>p.code==='70')||null,tableHandlePair=tableHeaderPairs.find(p=>p.code==='5')||null;return{tableStart:pairs[i].start,endTab:pairs[end],records,countPair,tableHandlePair};}
 return null;
}
function sqFindDxfLayerTable(pairs){
 const table=sqFindDxfTable(pairs,'LAYER','LAYER');if(!table)return null;
 return{tableStart:table.tableStart,endTab:table.endTab,rows:table.records.map(r=>({name:r.fields.find(p=>p.code==='2')?.value||'' ,start:r.start,end:r.end})),countPair:table.countPair,tableHandlePair:table.tableHandlePair};
}
function sqDxfVersion(pairs){const header=sqFindDxfSection(pairs,'HEADER');if(!header)return'AC1009';for(let i=0;i<pairs.length-1;i++)if(pairs[i].code==='9'&&pairs[i].value.toUpperCase()==='$ACADVER')return pairs[i+1]?.value||'AC1009';return'AC1009';}
function sqFindModelSpaceHandle(pairs){const table=sqFindDxfTable(pairs,'BLOCK_RECORD','BLOCK_RECORD');if(!table)return null;for(const r of table.records){const name=r.fields.find(p=>p.code==='2')?.value||'';if(name.replace(/[\s_-]/g,'').toUpperCase()==='*MODELSPACE'){const h=r.fields.find(p=>p.code==='5')?.value; if(h&&/^[0-9A-F]+$/i.test(h))return h.toUpperCase();}}return null;}
function sqFindHandseedPair(pairs){for(let i=0;i+1<pairs.length;i++)if(pairs[i].code==='9'&&pairs[i].value.toUpperCase()==='$HANDSEED'&&pairs[i+1].code==='5')return pairs[i+1];return null;}
function sqMaxDxfHandle(pairs){let max=0n;for(const p of pairs)if((p.code==='5'||p.code==='105')&&/^[0-9A-F]+$/i.test(p.value)){try{const n=BigInt('0x'+p.value);if(n>max)max=n;}catch(_){}}return max;}
function sqBuildModernLayerRows(layerFirstEntity,missing,pairs,layerTable){
 if(!missing.length)return{text:'',maxHandle:sqMaxDxfHandle(pairs)};
 const tableHandle=layerTable.tableHandlePair?.value;if(!tableHandle||! /^[0-9A-F]+$/i.test(tableHandle))throw new Error('تعذر الحفاظ على بنية جدول الطبقات الحديث في DXF المرجعي.');
 let maxHandle=sqMaxDxfHandle(pairs),text='';
 for(const name of missing){maxHandle+=1n;const handle=maxHandle.toString(16).toUpperCase(),e=layerFirstEntity.get(name),color=Number.isFinite(Number(e?.color))?Number(e.color):7;text+=`0\nLAYER\n5\n${handle}\n330\n${tableHandle}\n100\nAcDbSymbolTableRecord\n100\nAcDbLayerTableRecord\n2\n${name}\n70\n0\n62\n${color}\n6\nCONTINUOUS\n`;}
 return{text,maxHandle};
}
function sqBuildModernEntityRecords(entities,pairs,startHandle){
 let maxHandle=typeof startHandle==='bigint'?startHandle:sqMaxDxfHandle(pairs);
 const owner=sqFindModelSpaceHandle(pairs);if(!owner&&entities?.length)throw new Error('لوحة DXF المرجعية لا تحتوي على مقبض Model Space صالح؛ أوقفت التصدير لحماية بنية الملف.');
 const z=v=>safeNum(v),nl='\n';let out='';
 const emit=(type,subclass,layer,color,fields)=>{maxHandle+=1n;const handle=maxHandle.toString(16).toUpperCase();out+=`0${nl}${type}${nl}5${nl}${handle}${nl}330${nl}${owner}${nl}100${nl}AcDbEntity${nl}8${nl}${asciiLayerName(layer)}${nl}`;if(Number.isFinite(Number(color)))out+=`62${nl}${Number(color)}${nl}`;out+=`100${nl}${subclass}${nl}${fields}`;};
 const xyz=(a,code)=>`${code}${nl}${z(a.x)}${nl}${code+10}${nl}${z(a.y)}${nl}${code+20}${nl}${z(a.z)}${nl}`;
 for(const e of entities||[]){const L=e.layer||'0',color=e.color;
  if(e.type==='POINT'&&e.position)emit('POINT','AcDbPoint',L,color,xyz(e.position,10));
  else if(e.type==='LINE'&&e.a&&e.b)emit('LINE','AcDbLine',L,color,xyz(e.a,10)+xyz(e.b,11));
  else if((e.type==='TEXT'||e.type==='MTEXT')&&e.position){const q=e.position;emit('TEXT','AcDbText',L,color,xyz(q,10)+`40${nl}${Math.max(.01,z(e.height)||.35)}${nl}1${nl}${asciiText(e.text)}${nl}50${nl}${z(e.rotation)}${nl}72${nl}0${nl}73${nl}0${nl}`);}
  else if(type==='CIRCLE'&&e.center&&Number.isFinite(e.radius)){const q=e.center;emit('CIRCLE','AcDbCircle',L,color,xyz(q,10)+`40${nl}${Math.abs(z(e.radius))}${nl}`);}
  else if(type==='ARC'&&e.center&&Number.isFinite(e.radius)){maxHandle+=1n;const handle=maxHandle.toString(16).toUpperCase(),q=e.center;out+=`0${nl}ARC${nl}5${nl}${handle}${nl}330${nl}${owner}${nl}100${nl}AcDbEntity${nl}8${nl}${asciiLayerName(L)}${nl}`;if(Number.isFinite(Number(color)))out+=`62${nl}${Number(color)}${nl}`;out+=`100${nl}AcDbCircle${nl}${xyz(q,10)}40${nl}${Math.abs(z(e.radius))}${nl}100${nl}AcDbArc${nl}50${nl}${z(e.startAngle)}${nl}51${nl}${z(e.endAngle)}${nl}`;}
  else if(e.type==='3DFACE'&&e.vertices?.length>=3){const v=e.vertices,q=v[3]||v[2];let fields='';for(let i=0;i<4;i++)fields+=xyz(v[i]||q,10+i);emit('3DFACE','AcDbFace',L,color,fields);}
  else if(e.vertices?.length>=2&&['LWPOLYLINE','POLYLINE2D','POLYLINE3D','POLYLINE'].includes(e.type)){for(let i=0;i<e.vertices.length-1;i++)emit('LINE','AcDbLine',L,color,xyz(e.vertices[i],10)+xyz(e.vertices[i+1],11));if(e.closed)emit('LINE','AcDbLine',L,color,xyz(e.vertices[e.vertices.length-1],10)+xyz(e.vertices[0],11));}
 }
 return{text:out,nextHandseed:(maxHandle+1n).toString(16).toUpperCase(),maxHandle};
}
function sqApplyByteEdits(source,edits){let out=source.slice();edits.sort((a,b)=>b.start-a.start);for(const e of edits){const insert=e.insertBytes||new Uint8Array(0);out=sqConcatBytes([out.subarray(0,e.start),insert,out.subarray(e.end)]);}return out;}
// Keep the reference DXF byte-for-byte intact except for adding required layer rows
// and appending new entities. Do not parse/recreate its original drawing entities.
function mergeProjectionDxfPreservingReference(rawBytes, additions){
 if(!(rawBytes instanceof Uint8Array)||!rawBytes.length)throw new Error('لا تتوفر بايتات DXF الأصلية للحفاظ على تفاصيل اللوحة.');
 // Windows-1252 maps each byte to one code unit; replace BOM only in this analysis view.
 const decodedBytes=new TextDecoder('windows-1252').decode(rawBytes),originalText=decodedBytes.startsWith('ï»¿')?'   '+decodedBytes.slice(3):decodedBytes;
 const pairs=sqDxfPairsWithOffsets(originalText),entitySection=sqFindDxfSection(pairs,'ENTITIES'),layerTable=sqFindDxfLayerTable(pairs);
 if(!entitySection)throw new Error('لم يتم العثور على قسم ENTITIES صالح في لوحة DXF المرجعية.');
 if(!layerTable)throw new Error('لوحة DXF المرجعية لا تحتوي على جدول LAYER صالح؛ أوقفت التصدير لتجنب إعادة رسم اللوحة وتغيير خصائصها.');
 const eol=originalText.includes('\r\n')?'\r\n':'\n',version=sqDxfVersion(pairs),versionNo=parseInt(String(version).replace(/^AC/i,''),10)||1009,modern=versionNo>=1012;
 const existing=new Set(layerTable.rows.map(r=>String(r.name).toUpperCase())),layerFirstEntity=new Map();
 for(const e of additions||[]){const n=asciiLayerName(e.layer);if(n&&n!=='0'&&!layerFirstEntity.has(n))layerFirstEntity.set(n,e);}
 const missing=[...layerFirstEntity.keys()].filter(n=>!existing.has(n.toUpperCase()));
 let layerRows='',entityRecords='',handseedValue=null;
 if(modern){
   const layerBuild=sqBuildModernLayerRows(layerFirstEntity,missing,pairs,layerTable);layerRows=layerBuild.text;
   const entityBuild=sqBuildModernEntityRecords(additions,pairs,layerBuild.maxHandle);entityRecords=entityBuild.text;handseedValue=entityBuild.nextHandseed;
 }else{
   for(const name of missing){const e=layerFirstEntity.get(name),c=Number.isFinite(Number(e?.color))?Number(e.color):7;layerRows+=`0${eol}LAYER${eol}2${eol}${name}${eol}70${eol}0${eol}62${eol}${c}${eol}6${eol}CONTINUOUS${eol}`;}
   entityRecords=(additions||[]).map(entityToR12).filter(Boolean).join('');
 }
 entityRecords=entityRecords.replace(/\n/g,eol);
 const edits=[];
 if(layerRows){edits.push({start:layerTable.endTab.start,end:layerTable.endTab.start,insertBytes:sqEncodeAscii(layerRows)});if(layerTable.countPair){const count=layerTable.rows.length+missing.length;edits.push({start:layerTable.countPair.valueStart,end:layerTable.countPair.valueEnd,insertBytes:sqEncodeAscii(String(count))});}}
 if(entityRecords)edits.push({start:entitySection.endSec.start,end:entitySection.endSec.start,insertBytes:sqEncodeAscii(entityRecords)});
 if(handseedValue&&entityRecords){const seed=sqFindHandseedPair(pairs);if(seed)edits.push({start:seed.valueStart,end:seed.valueEnd,insertBytes:sqEncodeAscii(handseedValue)});}
 return sqApplyByteEdits(rawBytes,edits);
}

/* V1.0.103: native DXF-to-DXF overlay. Preserve each drawing's native entity records instead of rebuilding them from parsed geometry. */
function sqNativeRecordsInSection(text,pairs,section){
 const out=[];if(!section)return out;
 const idx=[];for(let i=0;i<pairs.length;i++)if(pairs[i].start>=section.contentStart&&pairs[i].start<section.endSec.start&&pairs[i].code==='0')idx.push(i);
 const sectionEndIndex=pairs.indexOf(section.endSec);for(let k=0;k<idx.length;k++){const i=idx[k],next=idx[k+1],start=pairs[i].start,end=next==null?section.endSec.start:pairs[next].start,recPairs=pairs.slice(i,next==null?sectionEndIndex:next);if(!recPairs.length)continue;out.push({start,end,type:String(pairs[i].value||'').trim().toUpperCase(),pairs:recPairs,raw:text.slice(start,end)});}
 return out;
}
function sqNativeField(rec,code){const p=(rec?.pairs||[]).find(x=>x.code===String(code));return p?p.value:'';}
function sqNativeSafeName(s,max=64){let x=String(s||'').replace(/[^A-Za-z0-9_$-]/g,'_').replace(/^_+|_+$/g,'');if(!x)x='ITEM';return x.slice(0,max);}
function sqNativeUniqueName(stem,used,max=120){let b=String(stem).slice(0,max),n=1,c=b;while(used.has(c.toUpperCase())){const suffix='_'+(++n);c=b.slice(0,max-suffix.length)+suffix;}used.add(c.toUpperCase());return c;}
function sqNativeTableRecords(pairs,tableName){return sqFindDxfTable(pairs,tableName,tableName);}
function sqNativeTableNameSet(table){return new Set((table?.records||[]).map(r=>String(r.fields.find(p=>p.code==='2')?.value||'').toUpperCase()).filter(Boolean));}
function sqNativeEntityHasLayer(rec){return String(rec?.type||'').toUpperCase()!=='ENDSEC'&&(rec?.pairs||[]).some(p=>p.code==='8');}
function sqNativeBlockUnits(text,pairs,section){
 const recs=sqNativeRecordsInSection(text,pairs,section),out=[];
 for(let i=0;i<recs.length;i++){
  if(recs[i].type!=='BLOCK')continue;
  let j=i+1;while(j<recs.length&&recs[j].type!=='ENDBLK')j++;
  if(j>=recs.length)throw new Error('قسم BLOCKS في الملف الأول يحتوي على بلوك غير مكتمل؛ أوقفت الدمج للحفاظ على الرسم.');
  const header=recs[i],name=String(sqNativeField(header,2)||'').trim();
  if(!name){i=j;continue;}
  const isLayout=/^\*(?:MODEL[_ ]?SPACE|PAPER[_ ]?SPACE)/i.test(name);
  out.push({name,isLayout,records:recs.slice(i,j+1)});i=j;
 }
 return out;
}
function sqNativeRewriteRecord(record,context,ctx){
 const edits=[],type=record.type;
 const getMap=(m,v)=>m?.get(String(v??'').toUpperCase());
 const valueEdit=(p,v)=>{if(v!=null&&String(v)!==String(p.value))edits.push({start:p.valueStart-record.start,end:p.valueEnd-record.start,value:String(v)});};
 const pairDelete=p=>edits.push({start:p.start-record.start,end:p.end-record.start,value:''});
 const codeHandle=/^(?:33[0-9]|34[0-9]|35[0-9]|36[0-9]|39[0-9]|480|481|1005)$/;
 for(const p of record.pairs){let v=p.value;
  if(p.code==='5'||p.code==='105'){
   const nv=getMap(ctx.handleMap,v);if(nv)valueEdit(p,nv);continue;
  }
  if(p.code==='8'){const nv=getMap(ctx.layerMap,v);if(nv)valueEdit(p,nv);continue;}
  if(p.code==='6'){const nv=getMap(ctx.resourceMaps.LTYPE,v);if(nv)valueEdit(p,nv);continue;}
  if(p.code==='7'){const nv=getMap(ctx.resourceMaps.STYLE,v);if(nv)valueEdit(p,nv);continue;}
  if(p.code==='1001'){const nv=getMap(ctx.resourceMaps.APPID,v);if(nv)valueEdit(p,nv);continue;}
  if(context==='table'){
   if(p.code==='2'){
    let map=null;if(ctx.tableName==='BLOCK_RECORD')map=ctx.blockMap;else if(ctx.tableName==='LAYER')map=ctx.layerMap;else map=ctx.resourceMaps[ctx.tableName];
    const nv=getMap(map,v);if(nv)valueEdit(p,nv);
   }
   if(p.code==='3'&&ctx.tableName==='DIMSTYLE'){const nv=getMap(ctx.resourceMaps.STYLE,v);if(nv)valueEdit(p,nv);}
  } else if(context==='blockHeader'){
   if(p.code==='2'||p.code==='3'){const nv=getMap(ctx.blockMap,v);if(nv)valueEdit(p,nv);}
  } else if((context==='rootEntity'||context==='blockEntity')&&(type==='INSERT'||type==='MINSERT'||type==='DIMENSION')){
   if(p.code==='2'){const nv=getMap(ctx.blockMap,v);if(nv)valueEdit(p,nv);}
   if(type==='DIMENSION'&&p.code==='3'){const nv=getMap(ctx.resourceMaps.DIMSTYLE,v);if(nv)valueEdit(p,nv);}
  }
  if(p.code==='330'){
   let desired=null;
   if(context==='table')desired=ctx.targetTableHandles[ctx.tableName]||getMap(ctx.handleMap,v)||null;
   else if(context==='rootEntity')desired=getMap(ctx.handleMap,v)||ctx.targetModelSpaceHandle||null;
   else desired=getMap(ctx.handleMap,v)||ctx.currentBlockRecordHandle||null;
   if(desired)valueEdit(p,desired);else pairDelete(p);
   continue;
  }
  if(codeHandle.test(p.code)){
   const nv=getMap(ctx.handleMap,v);if(nv)valueEdit(p,nv);else pairDelete(p);
  }
 }
 edits.sort((a,b)=>b.start-a.start);let out=record.raw;const seen=new Set();for(const e of edits){if(e.start<0||e.end<e.start||seen.has(e.start))continue;seen.add(e.start);out=out.slice(0,e.start)+e.value+out.slice(e.end);}return out;
}
function mergeNativeDxfDrawingsPreservingDetails(targetBytes,sourceBytes){
 if(!(targetBytes instanceof Uint8Array)||!targetBytes.length||!(sourceBytes instanceof Uint8Array)||!sourceBytes.length)throw new Error('ملفات DXF الخام غير متاحة؛ أوقفت الدمج حتى لا أعيد رسم اللوحة.');
 const rawT=sqByteString(targetBytes),rawS=sqByteString(sourceBytes),textT=rawT.startsWith('ï»¿')?'   '+rawT.slice(3):rawT,textS=rawS.startsWith('ï»¿')?'   '+rawS.slice(3):rawS;
 const tp=sqDxfPairsWithOffsets(textT),sp=sqDxfPairsWithOffsets(textS),te=sqFindDxfSection(tp,'ENTITIES'),se=sqFindDxfSection(sp,'ENTITIES'),tb=sqFindDxfSection(tp,'BLOCKS'),sb=sqFindDxfSection(sp,'BLOCKS');
 if(!te||!se)throw new Error('إحدى اللوحتين لا تحتوي على قسم ENTITIES صالح.');
 const targetLayerTable=sqNativeTableRecords(tp,'LAYER'),sourceLayerTable=sqNativeTableRecords(sp,'LAYER');
 if(!targetLayerTable||!sourceLayerTable)throw new Error('إحدى اللوحتين لا تحتوي على جدول Layers صالح. احفظهما بصيغة DXF قياسية ثم أعد المحاولة.');
 const targetModelSpaceHandle=sqFindModelSpaceHandle(tp),targetVersion=parseInt(String(sqDxfVersion(tp)).replace(/^AC/i,''),10)||1009,sourceVersion=parseInt(String(sqDxfVersion(sp)).replace(/^AC/i,''),10)||1009;
 if(targetVersion>=1012&&!targetModelSpaceHandle)throw new Error('لوحة المرجع لا تحتوي على Model Space handle صالح؛ أوقفت الدمج لحماية الملف.');
 if(targetVersion<1012&&sourceVersion>=1012)throw new Error('لوحة المرجع DXF قديمة جدًا للحفاظ الآمن على تفاصيل اللوحة الثانية. افتح المرجع في AutoCAD واحفظه DXF 2000 أو أحدث ثم أعد الإسقاط.');
 const tableNames=['LAYER','LTYPE','STYLE','APPID','DIMSTYLE','MLINESTYLE','BLOCK_RECORD'];
 const sourceTables={},targetTables={},resourceMaps={LTYPE:new Map(),STYLE:new Map(),APPID:new Map(),DIMSTYLE:new Map(),MLINESTYLE:new Map()};
 for(const name of tableNames){sourceTables[name]=sqNativeTableRecords(sp,name);targetTables[name]=sqNativeTableRecords(tp,name);}
 const targetBlockNames=new Set([...(targetTables.BLOCK_RECORD?.records||[]).map(r=>String(r.fields.find(p=>p.code==='2')?.value||'').toUpperCase())]);
 for(const u of sqNativeBlockUnits(rawT,tp,tb))targetBlockNames.add(u.name.toUpperCase());
 const sourceBlocks=sqNativeBlockUnits(rawS,sp,sb),blockMap=new Map();let blockIdx=0;
 for(const b of sourceBlocks){if(b.isLayout)continue;const original=b.name,anon=original.startsWith('*');let mapped=original;
  if(anon||targetBlockNames.has(original.toUpperCase())){const stem=(anon?'*SQ_SRC_':'SQ_SRC_')+sqNativeSafeName(original.replace(/^\*/,'').toUpperCase(),36)+'_'+(++blockIdx);mapped=sqNativeUniqueName(stem,targetBlockNames,60);}
  else targetBlockNames.add(original.toUpperCase());
  blockMap.set(original.toUpperCase(),mapped);
 }
 const targetLayerNames=sqNativeTableNameSet(targetLayerTable),layerMap=new Map([['0','0']]);
 for(const r of sourceLayerTable.records){const name=String(r.fields.find(p=>p.code==='2')?.value||'').trim();if(!name||name==='0')continue;let mapped=name;
  if(targetLayerNames.has(name.toUpperCase()))mapped=sqNativeUniqueName('SQ_SRC_'+sqNativeSafeName(name,180),targetLayerNames,240);
  else targetLayerNames.add(name.toUpperCase());
  layerMap.set(name.toUpperCase(),mapped);
 }
 for(const tableName of ['LTYPE','STYLE','APPID','DIMSTYLE','MLINESTYLE']){
  const st=sourceTables[tableName],tt=targetTables[tableName],used=sqNativeTableNameSet(tt);
  for(const r of st?.records||[]){const name=String(r.fields.find(p=>p.code==='2')?.value||'').trim();if(!name)continue;let mapped=name;
   const existing=used.has(name.toUpperCase());
   const builtIn=(tableName==='LTYPE'&&['CONTINUOUS','BYLAYER','BYBLOCK'].includes(name.toUpperCase()))||(tableName==='APPID'&&name.toUpperCase()==='ACAD');
   if(existing&&!builtIn)mapped=sqNativeUniqueName('SQ_SRC_'+tableName+'_'+sqNativeSafeName(name,160),used,240);
   else if(!existing)used.add(name.toUpperCase());
   resourceMaps[tableName].set(name.toUpperCase(),mapped);
  }
 }
 const targetTableHandles={};for(const name of tableNames)targetTableHandles[name]=targetTables[name]?.tableHandlePair?.value||null;
 // Build raw copy batches for resource table records. No geometry is reconstructed.
 const tableRowsToCopy={};
 for(const tableName of ['LAYER','LTYPE','STYLE','APPID','DIMSTYLE','MLINESTYLE','BLOCK_RECORD']){
  const srcTable=sourceTables[tableName],dstTable=targetTables[tableName];tableRowsToCopy[tableName]=[];if(!srcTable)continue;
  if(!dstTable&&srcTable.records.length){
   const relevant=tableName==='BLOCK_RECORD'?srcTable.records.some(r=>blockMap.has(String(r.fields.find(p=>p.code==='2')?.value||'').toUpperCase())):srcTable.records.some(r=>{const name=String(r.fields.find(p=>p.code==='2')?.value||'').toUpperCase();return tableName==='LAYER'?name!=='0':resourceMaps[tableName]?.get(name)!==name;});
   if(relevant)throw new Error('لوحة المرجع لا تحتوي على جدول '+tableName+' اللازم لحفظ تفاصيل اللوحة الثانية؛ لم يتم تعديل أي رسم.');
  }
  for(const r of srcTable.records){const name=String(r.fields.find(p=>p.code==='2')?.value||'').trim(),key=name.toUpperCase();if(!name)continue;
   if(tableName==='LAYER'&&key==='0')continue;
   if(tableName==='BLOCK_RECORD'&&!blockMap.has(key))continue;
   let mapped=tableName==='BLOCK_RECORD'?blockMap.get(key):tableName==='LAYER'?layerMap.get(key):resourceMaps[tableName]?.get(key);
   if(!mapped)continue;
   const dstNames=sqNativeTableNameSet(dstTable);
   if(mapped.toUpperCase()===key&&dstNames.has(key))continue;
   tableRowsToCopy[tableName].push({start:r.start,end:r.end,type:tableName,pairs:sp.filter(p=>p.start>=r.start&&p.start<r.end),raw:rawS.slice(r.start,r.end),context:'table',tableName});
  }
 }
 // If an MLINESTYLE table is actually required but absent, never degrade to regenerated lines.
 const srcRoot=sqNativeRecordsInSection(rawS,sp,se).filter(r=>r.type!=='ENDSEC'&&!r.pairs.some(p=>p.code==='67'&&p.value==='1'));
 const srcBlockUnits=sourceBlocks.filter(b=>!b.isLayout&&blockMap.has(b.name.toUpperCase()));
 if(srcBlockUnits.length&&!tb)throw new Error('اللوحة المرجعية لا تحتوي على قسم BLOCKS اللازم لحفظ البلوكات الأصلية.');
 const copyRecords=[];
 for(const tn of tableNames)for(const r of tableRowsToCopy[tn])copyRecords.push(r);
 const srcBlockRecHandles=new Map();
 for(const b of srcBlockUnits){const br=(sourceTables.BLOCK_RECORD?.records||[]).find(r=>String(r.fields.find(p=>p.code==='2')?.value||'').toUpperCase()===b.name.toUpperCase());const oldHandle=br?.fields.find(p=>p.code==='5')?.value||'';if(oldHandle)srcBlockRecHandles.set(b.name.toUpperCase(),oldHandle.toUpperCase());}
 const recordBlockNames=new Map();
 for(const b of srcBlockUnits){for(let i=0;i<b.records.length;i++){const rr=b.records[i],ctx=i===0?'blockHeader':rr.type==='ENDBLK'?'blockEnd':'blockEntity';const c={...rr,context:ctx,sourceBlockName:b.name};copyRecords.push(c);recordBlockNames.set(c, b.name.toUpperCase());}}
 for(const r of srcRoot){r.context='rootEntity';copyRecords.push(r);}
 // Assign unique entity/object handles across copied raw rows, preserving internal references.
 let nextHandle=sqMaxDxfHandle(tp);const handleMap=new Map();
 for(const r of copyRecords){for(const p of r.pairs){if(p.code!=='5'&&p.code!=='105')continue;const old=String(p.value||'').toUpperCase();if(!/^[0-9A-F]+$/.test(old)||handleMap.has(old))continue;nextHandle+=1n;handleMap.set(old,nextHandle.toString(16).toUpperCase());}}
 const ctx={layerMap,blockMap,resourceMaps,handleMap,targetTableHandles,targetModelSpaceHandle,currentBlockRecordHandle:null};
 const renderedTableRows={};for(const tn of tableNames)renderedTableRows[tn]=tableRowsToCopy[tn].map(r=>sqNativeRewriteRecord(r,'table',{...ctx,tableName:tn})).join('');
 const sourceBlockRaw=[];
 for(const b of srcBlockUnits){const sourceOld=srcBlockRecHandles.get(b.name.toUpperCase());ctx.currentBlockRecordHandle=sourceOld?handleMap.get(sourceOld)||null:null;for(const r of b.records){const type=r.type,context=type==='BLOCK'?'blockHeader':type==='ENDBLK'?'blockEnd':'blockEntity';sourceBlockRaw.push(sqNativeRewriteRecord(r,context,ctx));}}
 ctx.currentBlockRecordHandle=null;
 const sourceEntityRaw=srcRoot.map(r=>sqNativeRewriteRecord(r,'rootEntity',ctx)).join('');
 const edits=[];
 for(const tn of tableNames){const rows=tableRowsToCopy[tn];if(!rows.length)continue;const table=targetTables[tn];if(!table)continue;edits.push({start:table.endTab.start,end:table.endTab.start,insertBytes:sqByteArray(renderedTableRows[tn])});if(table.countPair)edits.push({start:table.countPair.valueStart,end:table.countPair.valueEnd,insertBytes:sqByteArray(String(table.records.length+rows.length))});}
 if(sourceBlockRaw.length)edits.push({start:tb.endSec.start,end:tb.endSec.start,insertBytes:sqByteArray(sourceBlockRaw.join(''))});
 if(sourceEntityRaw)edits.push({start:te.endSec.start,end:te.endSec.start,insertBytes:sqByteArray(sourceEntityRaw)});
 const seed=sqFindHandseedPair(tp);if(seed&&handleMap.size)edits.push({start:seed.valueStart,end:seed.valueEnd,insertBytes:sqEncodeAscii((nextHandle+1n).toString(16).toUpperCase())});
 const merged=sqApplyByteEdits(targetBytes,edits),checkText=sqByteString(merged),issue=inspectPreservedReferenceDXF(checkText);
 if(issue)throw new Error(issue+' تم إيقاف التصدير لحماية اللوحة الأصلية.');
 const outputPairs=sqDxfPairsWithOffsets(checkText),handles=outputPairs.filter(p=>(p.code==='5'||p.code==='105')&&/^[0-9A-F]+$/i.test(p.value)).map(p=>p.value.toUpperCase());
 if(handles.length!==new Set(handles).size)throw new Error('تم اكتشاف مقابض DXF مكررة بعد الدمج؛ تم إلغاء التصدير لحماية تفاصيل اللوحة.');
 return {bytes:merged,sourceEntityCount:srcRoot.length,sourceBlockCount:srcBlockUnits.length,sourceLayersAdded:tableRowsToCopy.LAYER.length};
}


function sqByteString(bytes){let out='';const chunk=8192;for(let i=0;i<bytes.length;i+=chunk)out+=String.fromCharCode(...bytes.subarray(i,Math.min(bytes.length,i+chunk)));return out;}
function sqByteArray(text){const out=new Uint8Array(text.length);for(let i=0;i<text.length;i++)out[i]=text.charCodeAt(i)&255;return out;}
function makeDxf(kind){
 const modern=true, lines=[];const add=(c,v)=>{lines.push(String(c),String(v));};
 add(0,'SECTION');add(2,'HEADER');add(9,'$ACADVER');add(1,'AC1027');add(9,'$HANDSEED');add(5,kind==='T'?'80':'70');add(0,'ENDSEC');
 add(0,'SECTION');add(2,'TABLES');
 function table(n,h,owner,rows){add(0,'TABLE');add(2,n);add(5,h);add(330,'1');add(100,'AcDbSymbolTable');add(70,rows.length);for(const r of rows){for(const [c,v] of r)add(c,v);}add(0,'ENDTAB');}
 table('LTYPE',kind==='T'?'10':'20','1',[
  [[0,'LTYPE'],[5,kind==='T'?'11':'21'],[330,kind==='T'?'10':'20'],[100,'AcDbSymbolTableRecord'],[100,'AcDbLinetypeTableRecord'],[2,'CONTINUOUS'],[70,0],[3,'Solid line'],[72,65],[73,0],[40,0]],
  ...(kind==='T'?[[[0,'LTYPE'],[5,'12'],[330,'10'],[100,'AcDbSymbolTableRecord'],[100,'AcDbLinetypeTableRecord'],[2,'DASHED'],[70,0],[3,'Target dashed'],[72,65],[73,2],[40,2],[49,1],[49,-1]]]:[[[0,'LTYPE'],[5,'22'],[330,'20'],[100,'AcDbSymbolTableRecord'],[100,'AcDbLinetypeTableRecord'],[2,'DASHED'],[70,0],[3,'Source dash style'],[72,65],[73,2],[40,2],[49,1.5],[49,-.5]]])
 ]);
 table('LAYER',kind==='T'?'30':'40','1',[
  [[0,'LAYER'],[5,kind==='T'?'31':'41'],[330,kind==='T'?'30':'40'],[100,'AcDbSymbolTableRecord'],[100,'AcDbLayerTableRecord'],[2,'0'],[70,0],[62,7],[6,'CONTINUOUS']],
  ...(kind==='T'?[[[0,'LAYER'],[5,'32'],[330,'30'],[100,'AcDbSymbolTableRecord'],[100,'AcDbLayerTableRecord'],[2,'WALLS'],[70,0],[62,1],[6,'CONTINUOUS']]]:[[[0,'LAYER'],[5,'42'],[330,'40'],[100,'AcDbSymbolTableRecord'],[100,'AcDbLayerTableRecord'],[2,'WALLS'],[70,0],[62,3],[6,'DASHED']],[[0,'LAYER'],[5,'43'],[330,'40'],[100,'AcDbSymbolTableRecord'],[100,'AcDbLayerTableRecord'],[2,'UNIQUE_LAYER'],[70,0],[62,2],[6,'CONTINUOUS']]])
 ]);
 table('STYLE',kind==='T'?'50':'60','1',[[[0,'STYLE'],[5,kind==='T'?'51':'61'],[330,kind==='T'?'50':'60'],[100,'AcDbSymbolTableRecord'],[100,'AcDbTextStyleTableRecord'],[2,'STANDARD'],[70,0],[40,0],[41,1],[50,0],[71,0],[42,2.5],[3,'txt.shx'],[4,'']]]);
 table('APPID',kind==='T'?'65':'66','1',[[[0,'APPID'],[5,kind==='T'?'66':'67'],[330,kind==='T'?'65':'66'],[100,'AcDbSymbolTableRecord'],[100,'AcDbRegAppTableRecord'],[2,'ACAD'],[70,0]]]);
 table('DIMSTYLE',kind==='T'?'68':'69','1',[[[0,'DIMSTYLE'],[105,kind==='T'?'6A':'6B'],[330,kind==='T'?'68':'69'],[100,'AcDbSymbolTableRecord'],[100,'AcDbDimStyleTableRecord'],[2,'STANDARD'],[70,0],[3,'STANDARD']]]);
 table('BLOCK_RECORD',kind==='T'?'6C':'6D','1',[
  [[0,'BLOCK_RECORD'],[5,kind==='T'?'6E':'6F'],[330,kind==='T'?'6C':'6D'],[100,'AcDbSymbolTableRecord'],[100,'AcDbBlockTableRecord'],[2,'*Model_Space'],[70,0]],
  [[0,'BLOCK_RECORD'],[5,kind==='T'?'71':'72'],[330,kind==='T'?'6C':'6D'],[100,'AcDbSymbolTableRecord'],[100,'AcDbBlockTableRecord'],[2,'*Paper_Space'],[70,0]],
  ...(kind==='T'?[[[0,'BLOCK_RECORD'],[5,'73'],[330,'6C'],[100,'AcDbSymbolTableRecord'],[100,'AcDbBlockTableRecord'],[2,'B1'],[70,0]]]:[[[0,'BLOCK_RECORD'],[5,'74'],[330,'6D'],[100,'AcDbSymbolTableRecord'],[100,'AcDbBlockTableRecord'],[2,'B1'],[70,0]]])
 ]);
 add(0,'ENDSEC');
 add(0,'SECTION');add(2,'BLOCKS');
 for(const [name,handle,owner,endHandle] of [[ '*Model_Space',kind==='T'?'75':'76',kind==='T'?'6E':'6F',kind==='T'?'79':'7A'],['*Paper_Space',kind==='T'?'77':'78',kind==='T'?'71':'72',kind==='T'?'7A':'7B']]){add(0,'BLOCK');add(5,handle);add(330,owner);add(100,'AcDbEntity');add(8,'0');add(100,'AcDbBlockBegin');add(2,name);add(70,0);add(10,0);add(20,0);add(30,0);add(3,name);add(1,'');add(0,'ENDBLK');add(5,endHandle);add(330,owner);add(100,'AcDbEntity');add(8,'0');add(100,'AcDbBlockEnd');}
 if(kind==='T'){add(0,'BLOCK');add(5,'7B');add(330,'73');add(100,'AcDbEntity');add(8,'0');add(100,'AcDbBlockBegin');add(2,'B1');add(70,0);add(10,0);add(20,0);add(30,0);add(3,'B1');add(1,'');add(0,'LINE');add(5,'7C');add(330,'73');add(100,'AcDbEntity');add(8,'0');add(100,'AcDbLine');add(10,0);add(20,0);add(30,0);add(11,1);add(21,1);add(31,0);add(0,'ENDBLK');add(5,'7D');add(330,'73');add(100,'AcDbEntity');add(8,'0');add(100,'AcDbBlockEnd');}
 if(kind==='S'){
  add(0,'BLOCK');add(5,'7C');add(330,'74');add(100,'AcDbEntity');add(8,'0');add(100,'AcDbBlockBegin');add(2,'B1');add(70,0);add(10,0);add(20,0);add(30,0);add(3,'B1');add(1,'');
  add(0,'LINE');add(5,'7D');add(330,'74');add(100,'AcDbEntity');add(8,'0');add(100,'AcDbLine');add(10,0);add(20,0);add(30,0);add(11,1);add(21,1);add(31,0);
  add(0,'ENDBLK');add(5,'7E');add(330,'74');add(100,'AcDbEntity');add(8,'0');add(100,'AcDbBlockEnd');
 }
 add(0,'ENDSEC');add(0,'SECTION');add(2,'ENTITIES');
 if(kind==='T'){add(0,'LINE');add(5,'7E');add(330,'6E');add(100,'AcDbEntity');add(8,'WALLS');add(62,1);add(100,'AcDbLine');add(10,0);add(20,0);add(30,0);add(11,10);add(21,0);add(31,0);}
 else{
  add(0,'LWPOLYLINE');add(5,'81');add(330,'76');add(100,'AcDbEntity');add(8,'WALLS');add(6,'DASHED');add(62,3);add(370,35);add(100,'AcDbPolyline');add(90,3);add(70,1);add(10,0);add(20,0);add(42,0.414213562);add(10,10);add(20,0);add(43,0.75);add(10,10);add(20,10);add(39,0.25);add(1001,'ACAD');add(1005,'7D');
  add(0,'MTEXT');add(5,'82');add(330,'76');add(100,'AcDbEntity');add(8,'WALLS');add(100,'AcDbMText');add(10,2);add(20,3);add(30,0);add(40,2.5);add(41,12);add(71,1);add(72,5);add(1,'{\\C1;NATIVE TEXT}');add(7,'STANDARD');
  add(0,'INSERT');add(5,'83');add(330,'76');add(100,'AcDbEntity');add(8,'WALLS');add(100,'AcDbBlockReference');add(2,'B1');add(10,5);add(20,5);add(30,0);add(41,1);add(42,1);add(43,1);add(50,30);
  add(0,'LINE');add(5,'84');add(330,'76');add(100,'AcDbEntity');add(8,'UNIQUE_LAYER');add(100,'AcDbLine');add(10,20);add(20,20);add(30,0);add(11,30);add(21,20);add(31,0);
 }
 add(0,'ENDSEC');add(0,'EOF');return lines.join('\r\n')+'\r\n';
}
const target=new TextEncoder().encode(makeDxf('T')),source=new TextEncoder().encode(makeDxf('S'));
const result=mergeNativeDxfDrawingsPreservingDetails(target,source),out=sqByteString(result.bytes);
if(!out.includes('0.414213562'))throw new Error('source LWPOLYLINE bulge was not preserved');
if(!out.includes('0.75'))throw new Error('source polyline width was not preserved');
if(!out.includes('{\\C1;NATIVE TEXT}'))throw new Error('MTEXT formatting was not preserved');
if(!out.includes('SQ_SRC_WALLS'))throw new Error('conflicting source layer was not namespaced');
if(!out.includes('UNIQUE_LAYER'))throw new Error('non-conflicting source layer name was not preserved');
if(out.includes('SQ_SRC_UNIQUE_LAYER'))throw new Error('unconflicted layer was renamed unnecessarily');
if(!out.includes('SQ_SRC_B1_'))throw new Error('source block was not namespaced');
if(!out.includes('SQ_SRC_STYLE_STANDARD'))throw new Error('conflicting source text style was not preserved separately');
if(!out.includes('SQ_SRC_LTYPE_DASHED'))throw new Error('conflicting source linetype was not preserved separately');
if(!out.includes('0\r\nLINE\r\n5\r\n7E'))throw new Error('reference entity handle/original record changed');
const mergedPairs=sqDxfPairsWithOffsets(out),mergedHandles=new Set(mergedPairs.filter(p=>(p.code==='5'||p.code==='105')&&/^[0-9A-F]+$/i.test(p.value)).map(p=>p.value.toUpperCase()));
const xdataRefs=mergedPairs.filter(p=>p.code==='1005').map(p=>p.value.toUpperCase());
if(!xdataRefs.length||xdataRefs.some(h=>h==='7D'||!mergedHandles.has(h)))throw new Error('XDATA handle reference was not remapped to the copied entity');
if(result.sourceBlockCount!==1)throw new Error('source block count wrong: '+result.sourceBlockCount);
const pairs=sqDxfPairsWithOffsets(out),hs=pairs.filter(p=>(p.code==='5'||p.code==='105')&&/^[0-9A-F]+$/i.test(p.value)).map(p=>p.value.toUpperCase());
if(hs.length!==new Set(hs).size)throw new Error('duplicate handles in merged output');
console.log(JSON.stringify({ok:true,sourceEntityCount:result.sourceEntityCount,sourceBlockCount:result.sourceBlockCount,sourceLayersAdded:result.sourceLayersAdded,outputBytes:result.bytes.length}));