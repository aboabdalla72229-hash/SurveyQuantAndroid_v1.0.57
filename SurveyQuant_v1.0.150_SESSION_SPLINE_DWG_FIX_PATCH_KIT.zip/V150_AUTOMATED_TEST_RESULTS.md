# V150 Automated Test Results

## PASS

- V150 WCS preview: +Z, -Z and tilted OCS basis conversion.
- V150 WCS preview: INSERT insertion point, base point, rotation basis and scale.
- Nested geometry returns WCS points rather than raw block-local XY; axis-label text anchors and directions use WCS conversion.
- V150 UI: 34vh preview canvas with 200-360px bounds.
- Real rational B-spline preview; no control-polygon chords. Incomplete spline metadata falls back to fit points or isolated anchors.
- Negative source coordinates can map exactly to positive reference coordinates without clamping signs.
- Fresh session reset clears target/reference boards, selected entities, coordinates, undo/redo and ID Point; load serial invalidates stale reads.
- Selecting a new board clears the previous canvas before reading; failure leaves that slot empty; slow old async loads cannot overwrite a newer selection; target/reference state remains independent.
- `.DWG` routes through shared `parseFile` and validates returned `rawDXFBytes`; errors are surfaced rather than leaving the old canvas visible.
- All 8 inherited regression suites passed: V148 regression, stability, orientation precision, alignment safety, MLEADER, 3D/OCS/axis labels, DXF/DWG regression, and V130 DWG/axis/multiselect tests.
- All 10 inline JavaScript blocks parse with Node 22 `--check`.
- APK package helper injected tested HTML in the V149 APK container, validated app version 1.0.150/versionCode 150 and retained local DWG WASM. The locally generated package is unsigned.

## Not yet field-verified

The user's original drawing was not attached. There is no claim that a specific real DWG file has been opened and aligned on Android, and no signed V150 artifact has been built by GitHub Actions in this run. Actual DWG field verification is still required.
