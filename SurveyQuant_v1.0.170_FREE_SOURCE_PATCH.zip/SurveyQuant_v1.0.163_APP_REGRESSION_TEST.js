'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const htmlPath=process.argv[2];
if(!htmlPath)throw new Error('Usage: node SurveyQuant_v1.0.163_APP_REGRESSION_TEST.js <index.html>');
const html=fs.readFileSync(htmlPath,'utf8');
const required=[
 ['shared DWG/DXF parser remains global','window.parseFile = parseFile;'],
 ['local self-contained DWG binary remains bundled','id="sq162-wasm-binary"'],
 ['DWG runtime exposes bundled WASM bytes','sq162GetBundledDwgWasmBinary'],
 ['DWG worker sends binary once','sqDwgWorkerWasmSent'],
 ['DWG and DXF reference is parsed raw-only','parseFile(cad,{rawOnly:true,conversionOnly:true,retainRawDWG:false})'],
 ['DWG and DXF source is parsed raw-only','parseFile(src,{rawOnly:true,conversionOnly:true,retainRawDWG:false})'],
 ['projection calls raw entity-record merge','engine.mergeRawDxfBoards(targetBytes,sourceBytes)'],
 ['no DXF redraw serializer in CAD overlay branch','mergeRawDxfBoards'],
 ['CAD engine exposes V163 global','SurveyQuantCAD163'],
 ['PDF.js main bundle is embedded','sq163-pdfjs-main'],
 ['real PDF.js worker bundle is embedded','sq163-pdfjs-worker'],
 ['PDF.js workerSrc is initialized locally','GlobalWorkerOptions.workerSrc=url'],
 ['ImageTracer is embedded offline','sq163-imagetracer'],
];
for(const [label,mark] of required)assert.ok(html.includes(mark),`FAIL V163 app regression: ${label}`);
const s=html.indexOf('async function dropFilesMerge(){'),e=html.indexOf('\nfunction downloadDroppedDXF()',s);
assert.ok(s>=0&&e>s,'dropFilesMerge function boundaries found');
const drop=html.slice(s,e);
assert.ok(drop.includes('if(sourceIsCad){'),'CAD-to-CAD path is explicitly selected');
assert.ok(drop.includes('engine.mergeRawDxfBoards(targetBytes,sourceBytes)'),'CAD-to-CAD path bypasses geometry reconstruction');
assert.ok(!drop.includes('buildR12FromEntities'),'CAD-to-CAD path does not redraw/serialize entities');
assert.ok(!html.includes('disableWorker: true'),'PDF.js worker is not disabled after configuring workerSrc');
const enginePath=process.argv[3],loaderPath=process.argv[4];
if(loaderPath){const loader=fs.readFileSync(loaderPath,'utf8');assert.ok(loader.includes('Module["wasmBinary"]=self.SQ_DWG_WASM_BINARY'),'corrected Emscripten loader uses bundled WASM');}
if(enginePath){const engine=fs.readFileSync(enginePath,'utf8');assert.ok(engine.includes('function mergeRawDxfBoards('));assert.ok(engine.includes('updateSnapPreview')&&engine.includes('hover?.point'));assert.ok(engine.includes('Math.min(10000'),'high zoom range is enabled');assert.ok(engine.includes('ناتج ناقص'));assert.ok(engine.includes('zoomView')&&engine.includes('snapPoint'));assert.ok(engine.includes(`data-sq-zoom="in"`));assert.ok(engine.includes(`addEventListener('wheel'`));assert.ok(engine.includes('pointerdown'));assert.ok(engine.includes(`value="intersection"`));assert.ok(engine.includes(`addEventListener('pagehide', cleanup`));assert.ok(engine.includes('transformDxfBytes'));assert.ok(engine.includes('isEvalSupported: false'),'PDF.js keeps the CVE-2024-4367 workaround');assert.ok(!/(?:localStorage|indexedDB|sessionStorage)\s*\./.test(engine),'CAD alignment/conversion state is memory-only');}

console.log('PASS V163 app regression: raw-DXF CAD overlay handler, embedded DWG WASM, PDF worker bootstrap, offline vectorizer, memory-only cleanup, and guarded PDF.js configuration.');
