'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const file = process.argv[2];
if (!file || !fs.existsSync(file)) throw new Error('Usage: node SurveyQuant_v1.0.133_FRESH_SESSION_PERFORMANCE_TEST.js index.html');
const html = fs.readFileSync(file, 'utf8');
const marker = 'SURVEYQUANT_V133_EPHEMERAL_SESSION_PERFORMANCE';
assert(html.includes(marker), 'V133 policy marker missing');
assert(html.includes('const SQ_APP_VERSION_CODE = 133;'), 'in-app version constant must be 133');
assert(html.includes("const SQ_V133_SESSION_SETTINGS=Object.create(null);"), 'project settings must stay in session memory');
assert(!html.includes('localStorage.setItem(SQ_SETTINGS_KEY'), 'project output settings must not persist');
assert(!html.includes('localStorage.setItem(key,el.value)'), 'comparison settings must not persist');
assert(html.includes("window.requestAnimationFrame(()=>{v.__sqV133DrawQueued=0;v.__sqV133DrawImmediate=true;try{draw(v);}"), 'CAD redraw must be coalesced to animation frames');
assert(html.includes("window.addEventListener('pagehide'"), 'page exit cleanup hook missing');
assert(html.includes("document.addEventListener('visibilitychange'"), 'background/return cleanup hook missing');
assert(html.includes('hiddenWasPicker'), 'file picker must be protected from unintended session reset');
assert(html.includes("document.body.classList.contains('payment-mode')"), 'payment screen must not be reset during active payment');
assert(html.includes('window.__sqOrientation111API'), 'orientation state cleanup must be wired');
assert(html.includes('sq_device_id') && html.includes('sq_access_until'), 'activation identity/cache whitelist missing');
assert(html.includes('window.sessionStorage.clear()'), 'old sessionStorage data must be removed at startup');
assert(html.includes('Storage.prototype.setItem = function(key, value)'), 'Web Storage write guard missing');
assert(html.includes('SQ_V133_SESSION_SETTINGS[id]'), 'temporary per-project settings storage missing');
assert(html.includes('function sqV132AssertReferencePreserved(beforeBytes,afterBytes)'), 'source CAD preservation helper was altered or lost');
assert(html.includes('mergeProjectionDxfPreservingReference(referenceBytes,additions)'), 'projection should still merge onto original DXF bytes');

// Execute the early startup storage policy against an isolated Web Storage implementation.
const match = html.match(/<script id="sq-v133-ephemeral-storage-policy">([\s\S]*?)<\/script>/);
assert(match, 'startup storage policy script missing');
class FakeStorage {
  constructor(initial = {}) { this.data = new Map(Object.entries(initial)); }
  get length() { return this.data.size; }
  key(i) { return [...this.data.keys()][i] ?? null; }
  getItem(k) { return this.data.has(String(k)) ? this.data.get(String(k)) : null; }
  setItem(k, v) { this.data.set(String(k), String(v)); }
  removeItem(k) { this.data.delete(String(k)); }
  clear() { this.data.clear(); }
}
const localStorage = new FakeStorage({
  'sq_device_id':'SQ-device-123456',
  'sq_access_until':'2030-01-01T00:00:00.000Z',
  'sq_pending_order':'old-order',
  'sq_pending_device':'old-device',
  'surveyquant.projectOutputSettings.v2':'{"project1Card":{"pointSize":999}}',
  'surveyquant.compare.cmpBeforeColor':'#ff0000',
  'lastDrawing':'secret-drawing-bytes',
  'points':'1,2,3'
});
const sessionStorage = new FakeStorage({'lastSessionDrawing':'private'});
const windowMock = {localStorage, sessionStorage};
const context = {window:windowMock, localStorage, sessionStorage, Storage:FakeStorage, Set, Object, String};
windowMock.Storage = FakeStorage;
vm.createContext(context);
vm.runInContext(match[1], context);
assert.deepEqual([...localStorage.data.keys()].sort(), ['sq_access_until','sq_device_id'], 'startup must purge prior drawing/preferences/payment-handoff values');
assert.equal(sessionStorage.length, 0, 'startup should clear all sessionStorage');
localStorage.setItem('future.drawing.cache', 'blocked');
assert.equal(localStorage.getItem('future.drawing.cache'), null, 'future drawing/cache keys must not persist');
localStorage.setItem('sq_device_id', 'SQ-device-123456');
assert.equal(localStorage.getItem('sq_device_id'), 'SQ-device-123456', 'activation identity must remain functional');
sessionStorage.setItem('anything', 'blocked');
assert.equal(sessionStorage.length, 0, 'new sessionStorage writes must be blocked');

console.log('PASS V133: prior drawing/preferences storage purged; only activation identity/cache survives; drawing/project writes blocked; sessions reset on exit/background return except file picker/payment; CAD redraws are frame-coalesced; source-preserving projection remains intact.');
