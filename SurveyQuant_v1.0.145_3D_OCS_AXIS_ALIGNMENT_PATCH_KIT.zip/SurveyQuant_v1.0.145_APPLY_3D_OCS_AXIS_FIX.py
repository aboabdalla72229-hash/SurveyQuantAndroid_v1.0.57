#!/usr/bin/env python3
"""Upgrade SurveyQuant V144 board alignment for 3D coordinates, standard OCS, and axis-label previews.

The two-point ALIGN computes translation/rotation/uniform scale in XY. The same uniform scale
is applied to WCS Z about the lowest recovered world-Z plane. OCS entities are converted
through WCS and back to the rotated OCS basis to preserve their geometric shape.
"""
from __future__ import annotations
import argparse, hashlib, re
from pathlib import Path

VERSION_OLD = 144
VERSION_NEW = 145

def script_pattern(sid: str):
    return re.compile(r'(<script\b(?=[^>]*\bid=["\']'+re.escape(sid)+r'["\'])[^>]*>)([\s\S]*?)(</script\s*>)', re.I)

def get_body(html: str, sid: str) -> str:
    m=list(script_pattern(sid).finditer(html))
    if len(m)!=1: raise ValueError(f'Expected one script {sid}, found {len(m)}')
    return m[0].group(2)

def set_body(html: str, sid: str, body: str) -> str:
    m=list(script_pattern(sid).finditer(html))
    if len(m)!=1: raise ValueError(f'Expected one script {sid}, found {len(m)}')
    a=m[0]
    return html[:a.start(2)]+body+html[a.end(2):]

def replace_once(s: str, old: str, new: str, label: str) -> str:
    n=s.count(old)
    if n != 1: raise ValueError(f'{label}: expected one anchor; found {n}')
    return s.replace(old,new,1)

OCS_HELPERS = r''' const sq145OCSTypes=new Set(['POINT','CIRCLE','ARC','INSERT','TEXT','ATTRIB','ATTDEF','MTEXT','SOLID','TRACE','LWPOLYLINE','POLYLINE','HATCH','LEADER','DIMENSION','SHAPE','VIEWPORT','IMAGE','WIPEOUT']);
 function sq145Norm3(v){const d=Math.hypot(v.x,v.y,v.z);return d>1e-14?{x:v.x/d,y:v.y/d,z:v.z/d}:{x:0,y:0,z:1};}
 function sq145Cross(a,b){return{x:a.y*b.z-a.z*b.y,y:a.z*b.x-a.x*b.z,z:a.x*b.y-a.y*b.x};}
 function sq145Dot(a,b){return a.x*b.x+a.y*b.y+a.z*b.z;}
 function sq145Add(a,b,k=1){return{x:a.x+k*b.x,y:a.y+k*b.y,z:a.z+k*b.z};}
 function sq145Basis(normal){
  const n=sq145Norm3(normal);let ax;
  if(Math.abs(n.x)<1/64&&Math.abs(n.y)<1/64)ax=sq145Norm3(sq145Cross({x:0,y:1,z:0},n));
  else ax=sq145Norm3(sq145Cross({x:0,y:0,z:1},n));
  const ay=sq145Norm3(sq145Cross(n,ax));return {x:ax,y:ay,z:n};
 }
 function sq145RotateZ(v,t){return{x:t.c*v.x-t.s*v.y,y:t.s*v.x+t.c*v.y,z:v.z};}
 function sq145TransformWorldPoint(p,t,zPivot){const q=t.point(p.x,p.y);return{x:q.x,y:q.y,z:zPivot+t.scale*(p.z-zPivot)};}
 function sq145TransformWorldVector(v,t){const q={x:t.c*v.x-t.s*v.y,y:t.s*v.x+t.c*v.y};return{x:q.x,y:q.y,z:t.scale*v.z};}
 function sq145ToWorld(p,b){return{x:b.x.x*p.x+b.y.x*p.y+b.z.x*p.z,y:b.x.y*p.x+b.y.y*p.y+b.z.y*p.z,z:b.x.z*p.x+b.y.z*p.y+b.z.z*p.z};}
 function sq145FromWorld(p,b){return{x:sq145Dot(p,b.x),y:sq145Dot(p,b.y),z:sq145Dot(p,b.z)};}
 function sq145MinWorldZ(records,numeric){
  let minZ=Infinity;
  const ocsTypes=new Set(['POINT','CIRCLE','ARC','INSERT','TEXT','ATTRIB','ATTDEF','MTEXT','SOLID','TRACE','LWPOLYLINE','POLYLINE','HATCH','LEADER','DIMENSION','SHAPE','VIEWPORT','IMAGE','WIPEOUT']);
  const visit=(rec,x,y,z,useOcs,basis)=>{if(!Number.isFinite(x)||!Number.isFinite(y)||!Number.isFinite(z))return;const p=useOcs?sq145ToWorld({x,y,z},basis):{x,y,z};if(Number.isFinite(p.z))minZ=Math.min(minZ,p.z);};
  for(const rec of records||[]){
   const by=new Map();for(const p of rec.pairs||[]){if(!by.has(p.code))by.set(p.code,[]);by.get(p.code).push(p);}
   const value=(code,i=0,fallback=null)=>{const p=(by.get(code)||[])[i];return p?numeric(p.value):fallback;};
   const type=rec.type,flag=Number(value(70,0,0))||0,poly3d=type==='POLYLINE'&&(flag&8)!==0;
   const useOcs=ocsTypes.has(type)&&!(type==='POLYLINE'&&poly3d);
   const normal=sq145Norm3({x:value(210,0,0)??0,y:value(220,0,0)??0,z:value(230,0,1)??1});
   const basis=sq145Basis(normal);
   if(type==='LWPOLYLINE'||type==='POLYLINE'&&!poly3d||type==='HATCH'){
    const xs=by.get(10)||[],ys=by.get(20)||[];
    let elev=0;if(type==='LWPOLYLINE')elev=value(38,0,0)??0;else if(type==='HATCH')elev=value(30,0,0)??0;else elev=value(30,0,0)??0;
    for(let i=0;i<Math.min(xs.length,ys.length);i++){
     if(type==='POLYLINE'&&i===0){visit(rec,numeric(xs[i].value),numeric(ys[i].value),elev,useOcs,basis);continue;}
     const z=type==='LWPOLYLINE'?elev:(type==='POLYLINE'?elev:(value(30,i,elev)??elev));
     visit(rec,numeric(xs[i].value),numeric(ys[i].value),z,useOcs,basis);
    }
    continue;
   }
   for(let xc=10;xc<=18;xc++){
    if((type==='MTEXT'||type==='ELLIPSE'||type==='RAY'||type==='XLINE')&&xc===11)continue;
    if(type==='IMAGE'&&(xc===11||xc===12))continue;
    if(type==='SPLINE'&&(xc===12||xc===13))continue;
    if(type==='MLEADER'||type==='MULTILEADER')continue;
    const xs=by.get(xc)||[],ys=by.get(xc+10)||[],zs=by.get(xc+20)||[];
    for(let i=0;i<Math.min(xs.length,ys.length);i++){
     const x=numeric(xs[i].value),y=numeric(ys[i].value),z=zs[i]?numeric(zs[i].value):0;
     visit(rec,x,y,z==null?0:z,useOcs,basis);
    }
   }
  }
  return Number.isFinite(minZ)?minZ:0;
 }
 function sq145InsertPair(insertPair,after,code,value){insertPair(after,code,value);}
 function sq145TransformOCSRecord(rec,by,pairOwner,change,numeric,t,zPivot,insertPair,insertBeforePair){
  const type=rec.type;
  if(!sq145OCSTypes.has(type))return null;
  if(type==='POLYLINE'&&((Number((by.get(70)||[])[0]?.value)||0)&8)!==0)return null; // 3D POLYLINE vertices are WCS.
  const pX=by.get(210)?.[0],pY=by.get(220)?.[0],pZ=by.get(230)?.[0];
  const normal=sq145Norm3({x:pX?(numeric(pX.value)??0):0,y:pY?(numeric(pY.value)??0):0,z:pZ?(numeric(pZ.value)??1):1});
  const oldB=sq145Basis(normal),newB=sq145Basis(sq145RotateZ(normal,t));
  const rotatedUx=sq145RotateZ(oldB.x,t),angleOffset=Math.atan2(sq145Dot(rotatedUx,newB.y),sq145Dot(rotatedUx,newB.x))*180/Math.PI;
  const normalAfter=sq145RotateZ(normal,t);
  const pairArrays=code=>by.get(code)||[];
  function editNormal(){for(const [q,val] of [[pX,normalAfter.x],[pY,normalAfter.y],[pZ,normalAfter.z]])if(q)change(q,val);}
  function convertPoint(x,y,z){const w=sq145ToWorld({x,y,z},oldB),tw=sq145TransformWorldPoint(w,t,zPivot);return sq145FromWorld(tw,newB);}
  function processGroups(xCodes,options={}){
    const onlyVertices=!!options.onlyVertices, commonElevation=options.commonElevation;
    let elevationPair=options.elevationPair||null, firstNewZ=null, lastY=null, processed=0;
    for(const xc of xCodes){
      let xs=pairArrays(xc),ys=pairArrays(xc+10),zs=pairArrays(xc+20);
      if(type==='POLYLINE'&&onlyVertices){xs=xs.filter(q=>pairOwner.get(q.index)==='VERTEX');ys=ys.filter(q=>pairOwner.get(q.index)==='VERTEX');zs=zs.filter(q=>pairOwner.get(q.index)==='VERTEX');}
      for(let i=0;i<Math.min(xs.length,ys.length);i++){
        const xp=xs[i],yp=ys[i],zp=options.commonElevation!=null?null:zs[i];
        const x=numeric(xp.value),y=numeric(yp.value);if(x===null||y===null)continue;
        const zv=zp?(numeric(zp.value)??0):(commonElevation!=null?commonElevation:0);
        const q=convertPoint(x,y,zv);change(xp,q.x);change(yp,q.y);if(zp)change(zp,q.z);
        if(firstNewZ===null)firstNewZ=q.z;lastY=yp;processed++;
        if(!zp&&commonElevation==null&&Math.abs(q.z)>1e-10){sq145InsertPair(insertPair,yp,xc+20,q.z);}
      }
    }
    if(options.commonElevation!=null&&processed){
      if(elevationPair)change(elevationPair,firstNewZ??options.commonElevation);
      else if(firstNewZ!=null&&Math.abs(firstNewZ)>1e-10){
        const anchor=options.insertElevationBefore||(pairArrays(10)[0]);
        if(anchor)insertBeforePair(anchor,options.elevationCode||30,firstNewZ);
      }
    }
    return processed;
  }
  let processed=0;
  if(type==='LWPOLYLINE'){
    const ep=by.get(38)?.[0]||null,elev=ep?(numeric(ep.value)??0):0;
    processed=processGroups([10],{commonElevation:elev,elevationPair:ep,insertElevationBefore:pairArrays(10)[0],elevationCode:38});
  }else if(type==='HATCH'){
    const ep=by.get(30)?.[0]||null,elev=ep?(numeric(ep.value)??0):0;
    processed=processGroups([10],{commonElevation:elev,elevationPair:ep,insertElevationBefore:pairArrays(10)[0],elevationCode:30});
  }else if(type==='POLYLINE'){
    const ep=by.get(30)?.[0]||null,elev=ep?(numeric(ep.value)??0):0;
    processed=processGroups([10],{onlyVertices:true,commonElevation:elev,elevationPair:ep,insertElevationBefore:pairArrays(10).find(q=>pairOwner.get(q.index)==='VERTEX'),elevationCode:30});
  }else{
    let codes=[10];
    if(['SOLID','TRACE'].includes(type))codes=[10,11,12,13];
    else if(type==='TEXT'||type==='ATTRIB'||type==='ATTDEF')codes=[10,11];
    else if(type==='DIMENSION')codes=[10,11,12,13,14];
    processed=processGroups(codes);
  }
  editNormal();
  // Extra WCS vectors embedded in OCS entities must rotate in WCS, not translate.
  if(type==='MTEXT'&&(by.has(11)&&by.has(21))){
    const xs=pairArrays(11),ys=pairArrays(21),zs=pairArrays(31);
    for(let i=0;i<Math.min(xs.length,ys.length);i++){
      const x=numeric(xs[i].value),y=numeric(ys[i].value);if(x===null||y===null)continue;
      const q=t.vector(x,y);change(xs[i],q.x);change(ys[i],q.y);if(zs[i]){const z=numeric(zs[i].value);if(z!==null)change(zs[i],z*t.scale);}
    }
  }
  if(type==='HATCH'){
    for(const [xc,yc,mode] of [[43,44,'point'],[45,46,'vector']]){
      const xs=pairArrays(xc),ys=pairArrays(yc);for(let i=0;i<Math.min(xs.length,ys.length);i++){
        const x=numeric(xs[i].value),y=numeric(ys[i].value);if(x===null||y===null)continue;
        const q=mode==='point'?t.point(x,y):t.vector(x,y);change(xs[i],q.x);change(ys[i],q.y);
      }
    }
  }
  return {handled:true,angleDelta:angleOffset,processed};
 }
'''

def patch_html(html: str):
    if html.count('const SQ_APP_VERSION_CODE = 144;') != 1:
        raise ValueError('Expected one V144 version constant')
    html=html.replace('const SQ_APP_VERSION_CODE = 144;','const SQ_APP_VERSION_CODE = 145;',1)
    html=html.replace('surveyquant-v144-fresh-board-session','surveyquant-v145-fresh-board-session')
    body=get_body(html,'sq-orientation-reference-board-module')
    body=replace_once(body," const identity=Math.abs(t.scale-1)<1e-12&&Math.abs(t.angleDeg)<1e-10&&Math.abs(t.tx)<1e-8&&Math.abs(t.ty)<1e-8;",
      " const zPivot=sq145MinWorldZ(records,numeric);\n const insertions=[];\n const insertPair=(after,code,value)=>{if(!after)return;insertions.push({at:after.end,text:String(code)+newline+format(value)+newline});};\n const insertBeforePair=(before,code,value)=>{if(!before)return;insertions.push({at:before.start,text:String(code)+newline+format(value)+newline});};\n const newline=bytes.some((b,i)=>b===10&&i>0&&bytes[i-1]===13)?'\\r\\n':'\\n';\n const identity=Math.abs(t.scale-1)<1e-12&&Math.abs(t.angleDeg)<1e-10&&Math.abs(t.tx)<1e-8&&Math.abs(t.ty)<1e-8;",
      'add 3D pivot and DXF group insertion support')
    body=replace_once(body,' function transformRecord(rec, countForEntity=true){',OCS_HELPERS+'\n function transformRecord(rec, countForEntity=true){','insert 3D/OCS transformation helpers')
    body=replace_once(body, r"""  function xy(xc,yc,mode='point'){
   const xs=by.get(xc)||[],ys=by.get(yc)||[];
   for(let j=0;j<Math.min(xs.length,ys.length);j++){
    if(rec.type==='POLYLINE'&&xc===10&&pairOwner.get(xs[j].index)!=='VERTEX')continue;
    const x=numeric(xs[j].value),y=numeric(ys[j].value);if(x===null||y===null)continue;exposed=true;
    const q=mode==='vector'?t.vector(x,y):t.point(x,y);change(xs[j],q.x);change(ys[j],q.y);
   }
  }
  if(rec.type==='MLEADER'||rec.type==='MULTILEADER'){
   if(transformMLeaderRecord(rec,change,numeric,t,(pair,value)=>{edits.set(pair.index,{pair,value});entityChanged=true;}))exposed=true;
  }else{
   for(let xc=10;xc<=18;xc++){""",
      r"""  function xy(xc,yc,mode='point'){
   const xs=by.get(xc)||[],ys=by.get(yc)||[],zs=by.get(xc+20)||[];
   for(let j=0;j<Math.min(xs.length,ys.length);j++){
    if(rec.type==='POLYLINE'&&xc===10&&pairOwner.get(xs[j].index)!=='VERTEX')continue;
    const x=numeric(xs[j].value),y=numeric(ys[j].value);if(x===null||y===null)continue;exposed=true;
    const q=mode==='vector'?t.vector(x,y):t.point(x,y);change(xs[j],q.x);change(ys[j],q.y);
    if(zs[j]){const z=numeric(zs[j].value);if(z!==null)change(zs[j],mode==='vector'?z*t.scale:zPivot+t.scale*(z-zPivot));}
    else if(mode==='point'){const zNew=zPivot+t.scale*(0-zPivot);if(Math.abs(zNew)>1e-10)insertPair(ys[j],xc+20,zNew);}
   }
  }
  let ocsInfo=null;
  if(rec.type==='MLEADER'||rec.type==='MULTILEADER'){
   if(transformMLeaderRecord(rec,change,numeric,t,(pair,value)=>{edits.set(pair.index,{pair,value});entityChanged=true;}))exposed=true;
  }else{
   ocsInfo=sq145TransformOCSRecord(rec,by,pairOwner,change,numeric,t,zPivot,insertPair,insertBeforePair);
   if(ocsInfo&&ocsInfo.processed)exposed=true;
   if(!ocsInfo){
   for(let xc=10;xc<=18;xc++){""",
      'transform full XYZ WCS and route known OCS entities through WCS')
    body=replace_once(body,"  }\n  if(rec.type==='HATCH'){xy(43,44,'point');xy(45,46,'vector');}\n  // Uniform scale changes geometry-dependent sizes, never layer/color/handle/XData.",
      "    if(rec.type==='HATCH'){xy(43,44,'point');xy(45,46,'vector');}\n   }\n  }\n  // Rotate extrusion normals for WCS entities carrying one; OCS entities updated it in their own local basis.\n  if(!ocsInfo){const nx=by.get(210)?.[0],ny=by.get(220)?.[0];if(nx||ny){const x=nx?(numeric(nx.value)??0):0,y=ny?(numeric(ny.value)??0):0;const q=sq145RotateZ({x,y,z:by.get(230)?.[0]?(numeric(by.get(230)[0].value)??1):1},t);if(nx)change(nx,q.x);if(ny)change(ny,q.y);if(by.get(230)?.[0])change(by.get(230)[0],q.z);}}\n  // Uniform scale changes geometry-dependent sizes, never layer/color/handle/XData.",
      'preserve matching braces and rotate extrusion normals')
    # Angle-bearing fields use the offset in the new OCS basis, not always world angle.
    body=replace_once(body,"  for(const code of rotationCodes)for(const pair of by.get(code)||[]){const n=numeric(pair.value);if(n!==null)change(pair,((n+t.angleDeg)%360+360)%360);}",
      "  const angleDelta=ocsInfo?ocsInfo.angleDelta:t.angleDeg;\n  for(const code of rotationCodes)for(const pair of by.get(code)||[]){const n=numeric(pair.value);if(n!==null)change(pair,((n+angleDelta)%360+360)%360);}",
      'adjust angles to transformed OCS basis')
    # MLeader 3D component transform / matrix: update z values, normals, and pivot translation.
    body=replace_once(body,"    setValue(b.x[i],q.x);setValue(b.y[i],q.y);\n   }\n   if(b.mode==='scale')for(const z of b.z){const value=numeric(z.value);if(value!==null)setValue(z,value*t.scale);}",
      "    setValue(b.x[i],q.x);setValue(b.y[i],q.y);\n    if(b.z[i]){const zv=numeric(b.z[i].value);if(zv!==null)setValue(b.z[i],b.mode==='point'?zPivot+t.scale*(zv-zPivot):zv*t.scale);}\n   }\n   if(b.mode==='scale'&&b.z.length>b.x.length)for(let i=b.x.length;i<b.z.length;i++){const z=b.z[i],value=numeric(z.value);if(value!==null)setValue(z,value*t.scale);}",
      'preserve MLeader Z components')
    body=replace_once(body,"   const M=[[t.scale*cs,t.scale*sn,0,0],[-t.scale*sn,t.scale*cs,0,0],[0,0,t.scale,0],[t.tx,t.ty,0,1]];",
      "   const M=[[t.scale*cs,t.scale*sn,0,0],[-t.scale*sn,t.scale*cs,0,0],[0,0,t.scale,0],[t.tx,t.ty,(1-t.scale)*zPivot,1]];",
      'apply same Z pivot to nested MLeader block matrix')
    # output byte assembler accepts both replacements and inserted coordinate components
    body=replace_once(body," const ordered=Array.from(edits.values()).sort((a,b)=>a.pair.valueStart-b.pair.valueStart),chunks=[];let cursor=0,total=0;\n for(const item of ordered){chunks.push(bytes.slice(cursor,item.pair.valueStart));const replacement=new TextEncoder().encode(item.value);chunks.push(replacement);total+=item.pair.valueStart-cursor+replacement.length;cursor=item.pair.valueEnd;}\n chunks.push(bytes.slice(cursor));total+=bytes.length-cursor;const output=new Uint8Array(total);let offset=0;for(const chunk of chunks){output.set(chunk,offset);offset+=chunk.length;}",
      " const ordered=Array.from(edits.values()).map(item=>({start:item.pair.valueStart,end:item.pair.valueEnd,text:item.value})).concat(insertions.map(item=>({start:item.at,end:item.at,text:item.text}))).sort((a,b)=>a.start-b.start||a.end-b.end),chunks=[];let cursor=0,total=0;\n for(const op of ordered){if(op.start<cursor)throw new Error('تداخلت عمليات تعديل إحداثيات DXF؛ لم يتم إنشاء ملف جزئي.');chunks.push(bytes.slice(cursor,op.start));const replacement=new TextEncoder().encode(op.text);chunks.push(replacement);total+=op.start-cursor+replacement.length;cursor=op.end;}\n chunks.push(bytes.slice(cursor));total+=bytes.length-cursor;const output=new Uint8Array(total);let offset=0;for(const chunk of chunks){output.set(chunk,offset);offset+=chunk.length;}",
      'apply byte-preserving 3D coordinate insertions')
    body=replace_once(body," if(!identity&&geometryChangedFields===0)throw new Error('لم يتغير أي إحداثي رغم أن التوجيه يتطلب حركة/دوران/مقياس. لم يتم تنزيل الملف حتى لا يبدو الإسقاط ناجحًا وهو لم يحرّك اللوحة. راجع النقطتين المختارتين ومحتوى اللوحة.');",
      " if(!identity&&geometryChangedFields+insertions.length===0)throw new Error('لم يتغير أي إحداثي رغم أن التوجيه يتطلب حركة/دوران/مقياس. لم يتم تنزيل الملف حتى لا يبدو الإسقاط ناجحًا وهو لم يحرّك اللوحة. راجع النقطتين المختارتين ومحتوى اللوحة.');",
      'count inserted Z coordinates as changes')
    # Export transform can handle ordinary non-default OCS, so only opaque entities remain a preservation blocker.
    start=" const nonDefaultOcs=records.filter(rec=>{\n   const gx=rec.pairs.find(p=>p.code===210),gy=rec.pairs.find(p=>p.code===220),gz=rec.pairs.find(p=>p.code===230);\n   if(!gx&&!gy&&!gz)return false;\n   const x=gx?Number(gx.value):0,y=gy?Number(gy.value):0,z=gz?Number(gz.value):1;\n   return ![x,y,z].every(Number.isFinite)||Math.abs(x)>1e-9||Math.abs(y)>1e-9||Math.abs(z-1)>1e-9;\n });\n"
    body=replace_once(body,start," // Non-default OCS is now transformed through its WCS basis; it is not an export veto.\n",'remove non-default OCS export veto')
    body=replace_once(body," if(nonDefaultOcs.length){const names=Array.from(new Set(nonDefaultOcs.map(r=>r.type))).slice(0,8).join(', ');throw new Error('تم إيقاف التصدير لأن هناك كيانات في مستوى إحداثيات محلي/ثلاثي الأبعاد غير قياسي ('+names+'). تحويل XY وحدهما قد يشوّهها. استخدم نسخة 2D مسقطة من CAD ثم أعد التوجيه.');}\n",'', 'remove OCS refusal')
    # Refresh outdated UI warning: ordinary 3D/OCS geometry is now supported, only opaque payloads stay guarded.
    body=replace_once(body,"لا يتم التصدير إذا احتوت اللوحة على كائنات Proxy أو Solids أو MLINE/TABLE أو كيانات في OCS غير قياسي لا يمكن تحويل هندستها الداخلية بالكامل. في هذه الحالة لن يُنشأ ملف جزئي أو مشوّه.",
      "تتم معالجة عناصر DXF ثلاثية الأبعاد وOCS القابلة للقراءة أثناء التوجيه مع تحويل هندستها عبر WCS والحفاظ على الطبقات وأسماء المحاور. إذا احتوت اللوحة على كائنات Proxy أو Civil 3D أو Solids أو MLINE/TABLE لا يكشف ملف DXF هندستها الداخلية، سيعرض التطبيق أسماء هذه الكائنات قبل التصدير بدل إخراج لوحة ناقصة أو مشوّهة.",
      'update outdated UI warning after adding ordinary 3D/OCS support')
    # Restore axis names in orientation previews from TEXT inside INSERTed axis bubbles.
    body=replace_once(body,"const pts=[];for(const seg of base.segs)pts.push(seg.a,seg.b);for(const p of base.anchors)pts.push(p);for(const tx of base.texts)if(tx.p)pts.push(tx.p);",
      r""" // Recover concise grid-bubble axis names from raw DXF, including TEXT inside nested INSERT blocks.
 try{
  if(typeof window.sqExtractDxfAxisEntities==='function'){
   const headerAscii=sqByteString(bytes.subarray(0,Math.min(bytes.length,8192)));
   const headerLines=headerAscii.split(String.fromCharCode(10)).map(s=>s.split(String.fromCharCode(13)).join('').trim());
   let cp='UTF-8';for(let hi=0;hi<headerLines.length-3;hi++){if(headerLines[hi]==='9'&&headerLines[hi+1].toUpperCase()==='$DWGCODEPAGE'){cp=headerLines[hi+3]||'UTF-8';break;}}
   cp=String(cp).toUpperCase();const encoding=/1256/.test(cp)?'windows-1256':/1251/.test(cp)?'windows-1251':/1252/.test(cp)?'windows-1252':/UTF-?8/.test(cp)?'utf-8':'windows-1252';let raw;
   try{raw=new TextDecoder(encoding).decode(bytes);}catch(_){raw=sqByteString(bytes);}
   const extracted=window.sqExtractDxfAxisEntities(raw)||[];
   const axisLabel=s=>{const v=String(s??'').replace(/\\P/gi,' ').replace(/[{}]/g,' ').replace(/\s+/g,'').trim().toUpperCase();return v.length<=6&&(/^[A-Z\u0600-\u06FF]{1,3}\d{0,3}$/.test(v)||/^\d{1,3}[A-Z\u0600-\u06FF]{0,2}$/.test(v));};
   for(const item of extracted){if(!['TEXT','MTEXT','ATTRIB','ATTDEF'].includes(String(item.type||'').toUpperCase())||!item.position||!axisLabel(item.text))continue;
    const label=String(item.text).replace(/\\P/gi,' ').replace(/[{}]/g,' ').trim(),x=Number(item.position.x),y=Number(item.position.y);if(!Number.isFinite(x)||!Number.isFinite(y))continue;
    const duplicate=base.texts.some(tx=>String(tx.text||'').trim().toUpperCase()===label.toUpperCase()&&tx.p&&Math.hypot(tx.p.x-x,tx.p.y-y)<1e-4);
    if(!duplicate){const tx={p:{x,y},text:label,height:Math.abs(Number(item.height)||2.5),rotation:Number(item.rotation)||0,layer:item.layer||'0'};base.texts.push(tx);base.anchors.push({x,y,layer:tx.layer});}
   }
  }
 }catch(_){}
 const pts=[];for(const seg of base.segs)pts.push(seg.a,seg.b);for(const p of base.anchors)pts.push(p);for(const tx of base.texts)if(tx.p)pts.push(tx.p);""",
      'restore axis bubble labels in preview')
    return html[:html.index('<script id="sq-orientation-reference-board-module"')] + set_body(html,'sq-orientation-reference-board-module',body)[html.index('<script id="sq-orientation-reference-board-module"'):]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-html',type=Path,required=True)
    ap.add_argument('--output-html',type=Path,required=True)
    ap.add_argument('--report',type=Path)
    args=ap.parse_args()
    s=args.input_html.read_text(encoding='utf-8')
    out=patch_html(s)
    args.output_html.parent.mkdir(parents=True,exist_ok=True)
    args.output_html.write_text(out,encoding='utf-8',newline='')
    if args.report:
        args.report.write_text(f'''# SurveyQuant V145: Full 3D Similarity / OCS / Axis Labels\n\n- Version updated from {VERSION_OLD} to {VERSION_NEW}.\n- Applies one uniform XYZ similarity transform, rotating in the XY plane and scaling elevations about the lowest recovered WCS Z plane so all-zero planes remain zero and an all-positive board cannot become negative merely from an arbitrary median pivot.\n- Standard OCS entities are transformed via OCS basis -> WCS XYZ similarity -> updated OCS basis; extrusion normals are rotated consistently and transformed OCS point coordinates are re-expressed in the new basis.\n- Non-default OCS is no longer rejected by the transform guard.\n- Axis-bubble TEXT/MTEXT/ATTRIB/ATTDEF nested in INSERT blocks is supplemented into the preview without replacing or redrawing the source DXF.\n- DXF group pairs remain byte-preserved except edited values and explicitly inserted missing Z/elevation components.\n\nThis is an automated source patch. Two point pairs specify XY alignment (rotation about WCS Z), not a full 3D orientation or independent vertical datum shift. A single uniform scale is applied to X/Y/Z about the lowest recovered WCS Z plane so the lowest plane stays fixed and zero-Z drawings remain at zero. Ordinary OCS/3D DXF entities are supported. Opaque Proxy/Civil 3D/Solids without exposed entity geometry are not rewritten silently because their private payload cannot be transformed safely by a text DXF editor.\n''',encoding='utf-8')
    print(f'PASS: V{VERSION_NEW} source written; size={len(out)} bytes; sha256={hashlib.sha256(out.encode()).hexdigest()}')
if __name__=='__main__': main()
