'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const pdfjs=require('./pdfjs-v3.11.174.min.js');
pdfjs.GlobalWorkerOptions.workerSrc=path.join(__dirname,'pdf.worker.js');
(async()=>{
 const pdf=await pdfjs.getDocument({data:new Uint8Array(fs.readFileSync('V186_RASTER_FIXTURE.pdf')),disableWorker:true,useSystemFonts:true,isEvalSupported:false}).promise;
 try{
  const page=await pdf.getPage(1),ops=await page.getOperatorList(),O=pdfjs.OPS;
  const rasterOps=[O.paintImageXObject,O.paintImageMaskXObject,O.paintJpegXObject,O.paintInlineImageXObject,O.paintInlineImageXObjectGroup,O.paintImageXObjectRepeat,O.paintImageMaskXObjectGroup,O.paintImageMaskXObjectRepeat,O.paintSolidColorImageMask].filter(Number.isInteger);
  const count=ops.fnArray.filter(op=>rasterOps.includes(op)).length;
  assert.ok(count>0,'fixture should be detected as raster PDF');
  console.log(JSON.stringify({pdfjs:pdfjs.version,pages:pdf.numPages,rasterPaintOperators:count,route:'lossless PNG underlay ZIP',result:'PASS'},null,2));
 }finally{await pdf.destroy();}
})().catch(e=>{console.error(e);process.exit(1);});
