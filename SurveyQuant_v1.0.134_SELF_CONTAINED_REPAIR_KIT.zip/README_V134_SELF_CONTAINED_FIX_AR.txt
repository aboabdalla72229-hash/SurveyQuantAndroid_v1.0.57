إصلاح SurveyQuant v1.0.134 مستقل

ارفع الملف build-v134-self-contained-dwg-dxf-repair.yml إلى المسار .github/workflows/build-v134-self-contained-dwg-dxf-repair.yml في المستودع. لا تحتاج إلى رفع ZIP التصحيح V134 منفصلًا، لأن الـWorkflow يحتويه داخله ويعيد إنشاءه ويتحقق من SHA-256 تلقائيًا. ملفات الأساس V126 وتعديلات V129/V130/V131 تظل مطلوبة كما في المستودع الحالي.

يشمل التصحيح: محرك DWG/DXF محلي ضمن APK، WASM منفصل وصحيح، توليد TSD مع -s WASM_BIGINT=1، هندسة رباعي الأرض والتحقق من أطواله، وتنظيف localStorage وsessionStorage وقواعد IndexedDB التابعة لأصل التطبيق عند بدء التشغيل/مغادرة المستند. لا يُمسح CacheStorage كي لا يتضرر بدء التشغيل.

تم فحص YAML، وجميع كتل Bash، واستعادة ZIP من الـWorkflow، واختبار الانحدار المحلي. لم يتم بعد إثبات إنشاء APK نهائي؛ اعتمد النسخة فقط بعد نجاح GitHub Actions واختبار ملفات DWG/DXF حقيقية على الهاتف.
بصمة ZIP المضمّن: d36a36f44fcdd05f41f85cbc15bfe43d1721b150733c49da79841d58a25aba55
