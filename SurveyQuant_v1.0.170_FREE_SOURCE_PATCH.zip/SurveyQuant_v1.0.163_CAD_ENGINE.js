(function (root, factory) {
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.SurveyQuantCAD163 = api;
  if (root && root.document) api.mount();
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
  'use strict';

  const enc = new TextEncoder();
  const SAFE_SEGMENT_LIMIT = 80000;
  const finite = Number.isFinite;
  const norm = n => Math.abs(n) < 1e-12 ? 0 : n;
  const fmt = n => {
    if (!finite(n)) throw new Error('نتجت قيمة إحداثية غير صالحة؛ أوقفت العملية لحماية الملف الأصلي.');
    n = norm(n);
    return String(Number(n.toPrecision(14)));
  };
  function decodeBytes(bytes) {
    return new TextDecoder('windows-1252').decode(bytes);
  }
  function readLine(bytes, start) {
    if (start >= bytes.length) return null;
    let end = start;
    while (end < bytes.length && bytes[end] !== 10) end++;
    let valueEnd = end;
    if (valueEnd > start && bytes[valueEnd - 1] === 13) valueEnd--;
    return { start, valueEnd, end: end < bytes.length ? end + 1 : end };
  }
  function pairText(bytes, line) {
    return decodeBytes(bytes.subarray(line.start, line.valueEnd)).trim();
  }
  function forEachPair(bytes, callback) {
    let pos = 0;
    while (pos < bytes.length) {
      const codeLine = readLine(bytes, pos);
      if (!codeLine) break;
      const valueLine = readLine(bytes, codeLine.end);
      if (!valueLine) break;
      const codeText = pairText(bytes, codeLine);
      const code = Number.parseInt(codeText, 10);
      callback({
        code,
        value: pairText(bytes, valueLine),
        start: codeLine.start,
        valueStart: valueLine.start,
        valueEnd: valueLine.valueEnd,
        end: valueLine.end,
      });
      pos = valueLine.end;
    }
  }
  function solve(sourceA, sourceB, targetA, targetB) {
    const dx1 = sourceB.x - sourceA.x, dy1 = sourceB.y - sourceA.y;
    const dx2 = targetB.x - targetA.x, dy2 = targetB.y - targetA.y;
    const d1 = Math.hypot(dx1, dy1), d2 = Math.hypot(dx2, dy2);
    if (![sourceA.x, sourceA.y, sourceB.x, sourceB.y, targetA.x, targetA.y, targetB.x, targetB.y].every(finite)) {
      throw new Error('إحداثيات نقاط التوجيه غير صالحة.');
    }
    if (d1 < 1e-9 || d2 < 1e-9) throw new Error('اختر نقطتين مختلفتين في كل لوحة.');
    const scale = d2 / d1;
    const angle = Math.atan2(dy2, dx2) - Math.atan2(dy1, dx1);
    const cos = Math.cos(angle), sin = Math.sin(angle);
    const apply = p => {
      const x = p.x - sourceA.x, y = p.y - sourceA.y;
      return { x: targetA.x + scale * (x * cos - y * sin), y: targetA.y + scale * (x * sin + y * cos) };
    };
    const mappedA = apply(sourceA), mappedB = apply(sourceB);
    return {
      scale,
      rotationRadians: angle,
      rotationDegrees: angle * 180 / Math.PI,
      apply,
      residualA: Math.hypot(mappedA.x - targetA.x, mappedA.y - targetA.y),
      residualB: Math.hypot(mappedB.x - targetB.x, mappedB.y - targetB.y),
    };
  }
  function applyEdits(source, edits) {
    const sorted = edits.slice().sort((a, b) => a.start - b.start || a.end - b.end);
    let total = source.length, cursor = 0;
    for (const edit of sorted) {
      if (!Number.isInteger(edit.start) || !Number.isInteger(edit.end) || edit.start < cursor || edit.end < edit.start || edit.end > source.length) {
        throw new Error('تداخلت تعديلات البايتات؛ أوقفت التحويل بدلًا من إتلاف DXF.');
      }
      total += (edit.insertBytes || new Uint8Array(0)).length - (edit.end - edit.start);
      cursor = edit.end;
    }
    const out = new Uint8Array(total);
    let sourcePos = 0, outPos = 0;
    for (const edit of sorted) {
      const span = edit.start - sourcePos;
      out.set(source.subarray(sourcePos, edit.start), outPos); outPos += span;
      const insert = edit.insertBytes || new Uint8Array(0);
      out.set(insert, outPos); outPos += insert.length; sourcePos = edit.end;
    }
    out.set(source.subarray(sourcePos), outPos); outPos += source.length - sourcePos;
    if (outPos !== out.length) throw new Error('فشل التحقق من حجم DXF الناتج.');
    return out;
  }
  function transformDxfBytes(rawBytes, sourceA, sourceB, targetA, targetB) {
    const bytes = rawBytes instanceof Uint8Array ? rawBytes : new Uint8Array(rawBytes);
    if (!bytes.length) throw new Error('ملف DXF فارغ.');
    const tr = solve(sourceA, sourceB, targetA, targetB);
    const eol = (() => {
      for (let i = 0; i < bytes.length; i++) if (bytes[i] === 10) return i > 0 && bytes[i - 1] === 13 ? '\r\n' : '\n';
      return '\n';
    })();
    const edits = [];
    let pos = 0, section = '', needSectionName = false, blockHeaderPending = false, blockName = '';
    let entity = null, foundEntities = false;
    const theta = tr.rotationRadians;
    const transformPoint = (x, y, vectorOnly) => {
      if (vectorOnly) return { x: tr.scale * (x * Math.cos(theta) - y * Math.sin(theta)), y: tr.scale * (x * Math.sin(theta) + y * Math.cos(theta)) };
      return tr.apply({ x, y });
    };
    const addNumericEdit = (pair, value) => {
      const replacement = enc.encode(fmt(value));
      edits.push({ start: pair.valueStart, end: pair.valueEnd, insertBytes: replacement });
    };
    function flushEntity() {
      if (!entity) return;
      const type = entity.type.toUpperCase(), pairs = entity.pairs;
      const byCode = new Map();
      for (const p of pairs) {
        if (!byCode.has(p.code)) byCode.set(p.code, []);
        byCode.get(p.code).push(p);
      }
      // DXF stores paired XY coordinates as 10..18 and 20..28. Edit only the
      // numeric values, leaving handles, layers, flags, entity type and all
      // unrecognized records byte-for-byte as supplied.
      for (let xCode = 10; xCode <= 18; xCode++) {
        const xs = byCode.get(xCode) || [], ys = byCode.get(xCode + 10) || [];
        if (!xs.length || xs.length !== ys.length) continue;
        for (let i = 0; i < xs.length; i++) {
          const x = Number(xs[i].value), y = Number(ys[i].value);
          if (!finite(x) || !finite(y)) continue;
          const vectorOnly = type === 'ELLIPSE' && xCode === 11;
          const q = transformPoint(x, y, vectorOnly);
          addNumericEdit(xs[i], q.x); addNumericEdit(ys[i], q.y);
        }
      }
      const setMultiplied = code => {
        for (const p of (byCode.get(code) || [])) {
          const n = Number(p.value); if (finite(n)) addNumericEdit(p, n * tr.scale);
        }
      };
      const setRotated = code => {
        for (const p of (byCode.get(code) || [])) {
          const n = Number(p.value); if (finite(n)) addNumericEdit(p, (n + tr.rotationDegrees + 360000) % 360);
        }
      };
      if (type === 'CIRCLE' || type === 'ARC') setMultiplied(40);
      if (['TEXT', 'MTEXT', 'ATTRIB', 'ATTDEF'].includes(type)) setMultiplied(40);
      if (type === 'MTEXT') setMultiplied(41);
      if (type === 'LWPOLYLINE') { setMultiplied(40); setMultiplied(41); }
      if (type === 'LINE') setMultiplied(39);
      if (type === 'HATCH') { for (const code of [49, 53]) { if(code===49)setMultiplied(code);else setRotated(code); } }
      if (type === 'ARC') { setRotated(50); setRotated(51); }
      else if (['TEXT', 'MTEXT', 'ATTRIB', 'ATTDEF', 'INSERT'].includes(type)) setRotated(50);
      else if (type === 'DIMENSION') setRotated(53);
      let extra = '';
      if (type === 'INSERT') {
        const sx = byCode.get(41) || [], sy = byCode.get(42) || [];
        if (sx.length) setMultiplied(41); else extra += `41${eol}${fmt(tr.scale)}${eol}`;
        if (sy.length) setMultiplied(42); else extra += `42${eol}${fmt(tr.scale)}${eol}`;
        if (byCode.get(43)?.length) setMultiplied(43);
        if (theta && !(byCode.get(50) || []).length) extra += `50${eol}${fmt(tr.rotationDegrees)}${eol}`;
      }
      if (['TEXT', 'MTEXT', 'ATTRIB', 'ATTDEF'].includes(type) && theta && !(byCode.get(50) || []).length) {
        extra += `50${eol}${fmt(tr.rotationDegrees)}${eol}`;
      }
      if (extra && pairs.length) {
        const last = pairs[pairs.length - 1];
        edits.push({ start: last.end, end: last.end, insertBytes: enc.encode(extra) });
      }
      entity = null;
    }
    while (pos < bytes.length) {
      const codeLine = readLine(bytes, pos);
      if (!codeLine) break;
      const valueLine = readLine(bytes, codeLine.end);
      if (!valueLine) break;
      const code = Number.parseInt(pairText(bytes, codeLine), 10);
      const value = pairText(bytes, valueLine);
      const pair = { code, value, start: codeLine.start, valueStart: valueLine.start, valueEnd: valueLine.valueEnd, end: valueLine.end };
      if (needSectionName && code === 2) { section = value.toUpperCase(); needSectionName = false; if (section === 'ENTITIES') foundEntities = true; pos = valueLine.end; continue; }
      if (section === 'BLOCKS' && blockHeaderPending && code === 2) { blockName = value; blockHeaderPending = false; pos = valueLine.end; continue; }
      if (code === 0) {
        flushEntity();
        const upper = value.toUpperCase();
        if (upper === 'SECTION') { needSectionName = true; pos = valueLine.end; continue; }
        if (upper === 'ENDSEC') { section = ''; blockName = ''; pos = valueLine.end; continue; }
        if (section === 'BLOCKS') {
          if (upper === 'BLOCK') { blockHeaderPending = true; pos = valueLine.end; continue; }
          if (upper === 'ENDBLK') { blockName = ''; pos = valueLine.end; continue; }
          // Anonymous *D blocks store dimension graphics in drawing coordinates.
          if (blockName.toUpperCase().startsWith('*D')) entity = { type: value, pairs: [] };
        } else if (section === 'ENTITIES') entity = { type: value, pairs: [] };
      } else if (entity) entity.pairs.push(pair);
      pos = valueLine.end;
    }
    flushEntity();
    if (!foundEntities) throw new Error('لم يوجد قسم ENTITIES صالح في ملف DXF.');
    if (tr.scale < 1e-12 || !finite(tr.scale)) throw new Error('مقياس التوجيه الناتج غير صالح.');
    const out = applyEdits(bytes, edits);
    return { bytes: out, scale: tr.scale, rotationDegrees: tr.rotationDegrees, editCount: edits.length };
  }
  function readGeometry(rawBytes, maxSegments = SAFE_SEGMENT_LIMIT) {
    const bytes = rawBytes instanceof Uint8Array ? rawBytes : new Uint8Array(rawBytes);
    const main = { segments: [], points: [], inserts: [] };
    const blocks = new Map();
    let active = main, currentBlock = null, blockHeader = null;
    let section = '', needSectionName = false, entity = null, pendingPolyline = null;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity, totalGeomPoints = 0, totalGeomSegments = 0;
    function addPoint(p) {
      if (!p || !finite(p.x) || !finite(p.y) || totalGeomPoints >= maxSegments) return;
      totalGeomPoints++; active.points.push(p);
      if (active === main) { minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);minY=Math.min(minY,p.y);maxY=Math.max(maxY,p.y); }
    }
    function addSegment(a, b) {
      if (totalGeomSegments >= maxSegments || active.segments.length >= maxSegments || !a || !b || !finite(a.x) || !finite(a.y) || !finite(b.x) || !finite(b.y)) return;
      totalGeomSegments++; active.segments.push({ a, b });
      if (active === main) { minX=Math.min(minX,a.x,b.x);maxX=Math.max(maxX,a.x,b.x);minY=Math.min(minY,a.y,b.y);maxY=Math.max(maxY,a.y,b.y); }
    }
    function pointsFromPairs(byCode, xCode = 10) {
      const xs=byCode.get(xCode)||[],ys=byCode.get(xCode+10)||[],out=[];
      for(let i=0;i<Math.min(xs.length,ys.length);i++){const x=Number(xs[i]),y=Number(ys[i]);if(finite(x)&&finite(y))out.push({x,y});}
      return out;
    }
    function connect(list, closed=false) {
      if(!list.length)return;if(list.length===1){addPoint(list[0]);return;}
      for(let i=1;i<list.length&&main.segments.length<maxSegments;i++)addSegment(list[i-1],list[i]);
      if(closed&&main.segments.length<maxSegments)addSegment(list[list.length-1],list[0]);
    }
    function finishPolyline(){if(pendingPolyline){connect(pendingPolyline.points,pendingPolyline.closed);pendingPolyline=null;}}
    function flushEntity(){
      if(!entity)return;
      const type=entity.type.toUpperCase(),values=entity.values,byCode=new Map();
      for(const [code,arr] of Object.entries(values))byCode.set(Number(code),arr);
      if(type==='POLYLINE'){
        finishPolyline();pendingPolyline={points:[],closed:((Number((values[70]||[])[0])||0)&1)!==0};
      }else if(type==='VERTEX'&&pendingPolyline){const pt=pointsFromPairs(byCode)[0];if(pt)pendingPolyline.points.push(pt);}
      else if(type==='SEQEND'&&pendingPolyline)finishPolyline();
      else{
        if(pendingPolyline)finishPolyline();
        if(type==='LINE'){
          const a=pointsFromPairs(byCode,10)[0],b=pointsFromPairs(byCode,11)[0];if(a&&b)addSegment(a,b);
        }else if(type==='LWPOLYLINE'||type==='SPLINE'){
          const pts=pointsFromPairs(byCode,10);connect(pts,type==='LWPOLYLINE'&&(((Number((values[70]||[])[0])||0)&1)!==0));
        }else if(type==='CIRCLE'||type==='ARC'){
          const c=pointsFromPairs(byCode,10)[0],r=Number((values[40]||[])[0]);
          if(c&&finite(r)&&r>0){let start=type==='ARC'?Number((values[50]||[])[0])*Math.PI/180:0,end=type==='ARC'?Number((values[51]||[])[0])*Math.PI/180:Math.PI*2;if(!finite(start))start=0;if(!finite(end))end=Math.PI*2;while(end<=start)end+=Math.PI*2;const n=Math.max(12,Math.min(160,Math.ceil((end-start)*18)));let prev=null;for(let i=0;i<=n;i++){const a=start+(end-start)*i/n,pt={x:c.x+r*Math.cos(a),y:c.y+r*Math.sin(a)};if(prev)addSegment(prev,pt);prev=pt;}}
          else if(c)addPoint(c);
        }else if(['SOLID','TRACE','3DFACE'].includes(type)){
          const pts=[];for(let code=10;code<=13;code++){const pt=pointsFromPairs(byCode,code)[0];if(pt)pts.push(pt);}connect(pts,pts.length>2);
        }else if(type==='INSERT'){
          const pos=pointsFromPairs(byCode,10)[0];
          if(pos){const name=String((values[2]||[])[0]||'').toUpperCase();active.inserts.push({name,x:pos.x,y:pos.y,sx:Number((values[41]||[])[0]??1),sy:Number((values[42]||[])[0]??1),rotation:Number((values[50]||[])[0]||0),cols:Math.max(1,Math.min(50,Number((values[70]||[])[0]||1)),),rows:Math.max(1,Math.min(50,Number((values[71]||[])[0]||1))),colSpacing:Number((values[44]||[])[0]||0),rowSpacing:Number((values[45]||[])[0]||0)});}
        }else if(['POINT','TEXT','MTEXT','ATTRIB','ATTDEF','DIMENSION'].includes(type)){const pt=pointsFromPairs(byCode,10)[0];if(pt)addPoint(pt);}
      }
      entity=null;
    }
    function finishBlock(){
      if(!currentBlock&&!blockHeader)return;
      const meta=blockHeader||currentBlock||{},name=String(meta.name||currentBlock?.name||'').toUpperCase();
      if(name){const g=currentBlock||{segments:[],points:[],inserts:[]};blocks.set(name,{name,baseX:Number(meta.baseX??currentBlock?.baseX)||0,baseY:Number(meta.baseY??currentBlock?.baseY)||0,geometry:g});}
      blockHeader=null;currentBlock=null;active=main;
    }
    let pos=0;
    while(pos<bytes.length&&main.segments.length<maxSegments){
      const cLine=readLine(bytes,pos);if(!cLine)break;const vLine=readLine(bytes,cLine.end);if(!vLine)break;
      const code=Number.parseInt(pairText(bytes,cLine),10),value=pairText(bytes,vLine);
      if(needSectionName&&code===2){section=value.toUpperCase();needSectionName=false;pos=vLine.end;continue;}
      if(code===0){
        flushEntity();const u=value.toUpperCase();
        if(u==='SECTION'){needSectionName=true;pos=vLine.end;continue;}
        if(u==='ENDSEC'){if(section==='BLOCKS'&&(blockHeader||currentBlock))finishBlock();section='';active=main;pos=vLine.end;continue;}
        if(section==='BLOCKS'){
          if(u==='BLOCK'){if(blockHeader||currentBlock)finishBlock();blockHeader={name:'',baseX:0,baseY:0};currentBlock={segments:[],points:[],inserts:[]};active=currentBlock;entity=null;pos=vLine.end;continue;}
          if(u==='ENDBLK'){finishBlock();entity=null;pos=vLine.end;continue;}
          if(blockHeader&&currentBlock){currentBlock.name=blockHeader.name;currentBlock.baseX=blockHeader.baseX;currentBlock.baseY=blockHeader.baseY;blockHeader=null;}
          if(currentBlock)entity={type:value,values:Object.create(null)};
        }else if(section==='ENTITIES')entity={type:value,values:Object.create(null)};
      }else if(blockHeader&&section==='BLOCKS'){
        if(code===2)blockHeader.name=value;
        else if(code===10)blockHeader.baseX=Number(value);
        else if(code===20)blockHeader.baseY=Number(value);
      }else if(entity&&((code>=10&&code<=18)||(code>=20&&code<=28)||[2,40,41,42,44,45,50,51,70,71].includes(code))){
        if(!entity.values[code])entity.values[code]=[];entity.values[code].push(value);
      }
      pos=vLine.end;
    }
    flushEntity();finishPolyline();if(blockHeader||currentBlock)finishBlock();active=main;
    // Expand INSERT geometry for a faithful preview and reliable snapping. This is
    // visualization only: output alignment still transforms the original DXF bytes.
    const identity={a:1,b:0,c:0,d:1,tx:0,ty:0};let instanceCount=0;
    function applyAffine(p,m){return{x:m.a*p.x+m.c*p.y+m.tx,y:m.b*p.x+m.d*p.y+m.ty};}
    function compose(m,n){return{a:m.a*n.a+m.c*n.b,b:m.b*n.a+m.d*n.b,c:m.a*n.c+m.c*n.d,d:m.b*n.c+m.d*n.d,tx:m.a*n.tx+m.c*n.ty+m.tx,ty:m.b*n.tx+m.d*n.ty+m.ty};}
    function expandInsert(insert,parent,depth){
      if(depth>6||instanceCount>20000||main.segments.length>=maxSegments)return;
      const block=blocks.get(insert.name);if(!block){const p=applyAffine({x:insert.x,y:insert.y},parent);active=main;addPoint(p);return;}
      const sx=finite(insert.sx)&&insert.sx!==0?insert.sx:1,sy=finite(insert.sy)&&insert.sy!==0?insert.sy:1,theta=(finite(insert.rotation)?insert.rotation:0)*Math.PI/180,co=Math.cos(theta),si=Math.sin(theta);
      const a=co*sx,b=si*sx,c=-si*sy,d=co*sy,cols=insert.cols||1,rows=insert.rows||1;
      for(let row=0;row<rows&&instanceCount<=20000;row++)for(let col=0;col<cols&&instanceCount<=20000;col++){
        instanceCount++;
        const ox=insert.x+co*sx*insert.colSpacing*col-si*sy*insert.rowSpacing*row;
        const oy=insert.y+si*sx*insert.colSpacing*col+co*sy*insert.rowSpacing*row;
        const child={a,b,c,d,tx:ox-a*block.baseX-c*block.baseY,ty:oy-b*block.baseX-d*block.baseY};
        const world=compose(parent,child);active=main;
        for(const seg of block.geometry.segments){if(main.segments.length>=maxSegments)break;addSegment(applyAffine(seg.a,world),applyAffine(seg.b,world));}
        for(const pt of block.geometry.points){if(main.points.length>=maxSegments)break;addPoint(applyAffine(pt,world));}
        for(const nested of block.geometry.inserts)expandInsert(nested,world,depth+1);
      }
    }
    for(const ins of main.inserts)expandInsert(ins,identity,0);
    if(!main.segments.length&&!main.points.length)throw new Error('لم أستطع استخراج خطوط أو بلوكات قابلة للمعاينة من اللوحة.');
    if(!finite(minX)||!finite(maxX)){minX=0;maxX=1;minY=0;maxY=1;}
    if(maxX-minX<1e-9){minX-=.5;maxX+=.5;}if(maxY-minY<1e-9){minY-=.5;maxY+=.5;}
    return{segments:main.segments,points:main.points,minX,minY,maxX,maxY};
  }
  function nearestPoint(geometry, point) {
    let best = null, bestD2 = Infinity;
    for (const s of geometry.segments) {
      const dx = s.b.x - s.a.x, dy = s.b.y - s.a.y, den = dx * dx + dy * dy;
      const t = den ? Math.max(0, Math.min(1, ((point.x - s.a.x) * dx + (point.y - s.a.y) * dy) / den)) : 0;
      const q = { x: s.a.x + t * dx, y: s.a.y + t * dy };
      const d2 = (q.x - point.x) ** 2 + (q.y - point.y) ** 2;
      if (d2 < bestD2) { bestD2 = d2; best = q; }
    }
    if (!best && geometry.points.length) {
      for (const q of geometry.points) { const d2 = (q.x - point.x) ** 2 + (q.y - point.y) ** 2; if (d2 < bestD2) { bestD2 = d2; best = { x: q.x, y: q.y }; } }
    }
    if (!best) throw new Error('لا توجد عناصر مناسبة لالتقاط النقطة.');
    return best;
  }
  function snapPoint(geometry, point, mode='intersection', tolerance=1) {
    const tol=Math.max(1e-12,Number(tolerance)||1), tol2=tol*tol, candidates=[];
    let nearest=null,nearestD2=Infinity;const nearSegments=[];
    for(const seg of geometry.segments){
      const dx=seg.b.x-seg.a.x,dy=seg.b.y-seg.a.y,den=dx*dx+dy*dy;
      const t=den?Math.max(0,Math.min(1,((point.x-seg.a.x)*dx+(point.y-seg.a.y)*dy)/den)):0;
      const q={x:seg.a.x+t*dx,y:seg.a.y+t*dy},d2=(q.x-point.x)**2+(q.y-point.y)**2;
      if(d2<nearestD2){nearestD2=d2;nearest={point:q,type:'nearest',distance:d2};}
      if(d2<=tol2*4){nearSegments.push({seg,d2});}
      if(mode==='endpoint'||mode==='intersection'){
        for(const endpoint of [seg.a,seg.b]){const d=(endpoint.x-point.x)**2+(endpoint.y-point.y)**2;if(d<=tol2)candidates.push({point:{x:endpoint.x,y:endpoint.y},type:'endpoint',distance:d});}
      }
      if(mode==='midpoint'||mode==='intersection'){
        const m={x:(seg.a.x+seg.b.x)/2,y:(seg.a.y+seg.b.y)/2},d=(m.x-point.x)**2+(m.y-point.y)**2;if(d<=tol2)candidates.push({point:m,type:'midpoint',distance:d});
      }
    }
    if(mode==='intersection'&&nearSegments.length>1){
      nearSegments.sort((a,b)=>a.d2-b.d2);const list=nearSegments.slice(0,48);
      for(let i=0;i<list.length;i++)for(let j=i+1;j<list.length;j++){
        const a=list[i].seg,b=list[j].seg,rx=a.b.x-a.a.x,ry=a.b.y-a.a.y,sx=b.b.x-b.a.x,sy=b.b.y-b.a.y,den=rx*sy-ry*sx;
        if(Math.abs(den)<1e-14)continue;const qx=b.a.x-a.a.x,qy=b.a.y-a.a.y,t=(qx*sy-qy*sx)/den,u=(qx*ry-qy*rx)/den;
        if(t>=-1e-10&&t<=1+1e-10&&u>=-1e-10&&u<=1+1e-10){const p={x:a.a.x+t*rx,y:a.a.y+t*ry},d=(p.x-point.x)**2+(p.y-point.y)**2;if(d<=tol2)candidates.push({point:p,type:'intersection',distance:d});}
      }
    }
    if(nearest&&nearestD2<=tol2)candidates.push(nearest);
    if(mode==='endpoint'||mode==='intersection'||mode==='nearest'){for(const p of (geometry.points||[])){const d=(p.x-point.x)**2+(p.y-point.y)**2;if(d<=tol2)candidates.push({point:{x:p.x,y:p.y},type:'endpoint',distance:d});if(d<nearestD2){nearestD2=d;nearest={point:{x:p.x,y:p.y},type:'nearest',distance:d};}}}
    const priority={intersection:0,endpoint:1,midpoint:2,nearest:3};
    if(mode==='endpoint')for(const c of candidates)if(c.type==='intersection')c.type='nearest';
    if(mode==='midpoint')for(const c of candidates)if(c.type==='intersection')c.type='nearest';
    const allowed=mode==='nearest'?['nearest']:mode==='endpoint'?['endpoint','nearest']:mode==='midpoint'?['midpoint','nearest']:['intersection','endpoint','midpoint','nearest'];
    const valid=candidates.filter(c=>allowed.includes(c.type));if(!valid.length)return null;
    valid.sort((a,b)=>(priority[a.type]-priority[b.type])||a.distance-b.distance);
    const best=valid[0],labels={intersection:'تقاطع',endpoint:'نهاية عنصر',midpoint:'منتصف عنصر',nearest:'أقرب نقطة'};
    return {point:best.point,type:best.type,typeLabel:labels[best.type],distance:Math.sqrt(best.distance)};
  }

  function svgPathToPolylines(d, scale = 8) {
    const tokens = String(d || '').match(/[A-Za-z]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?/g) || [];
    let i = 0, cmd = '', x = 0, y = 0, sx = 0, sy = 0, lastC = null, lastQ = null, path = [], paths = [];
    const isCmd = t => /^[A-Za-z]$/.test(t);
    const num = () => Number(tokens[i++]);
    const push = (px, py) => { if (finite(px) && finite(py)) path.push({ x: px, y: py }); };
    const finish = closed => { if (path.length > 1) paths.push({ points: path, closed }); path = []; };
    while (i < tokens.length) {
      if (isCmd(tokens[i])) cmd = tokens[i++];
      if (!cmd) break;
      const rel = cmd === cmd.toLowerCase(), upper = cmd.toUpperCase();
      if (upper === 'Z') { push(sx, sy); finish(true); x = sx; y = sy; cmd = ''; lastC = lastQ = null; continue; }
      if (upper === 'M' || upper === 'L' || upper === 'T') {
        if (i + 1 >= tokens.length) break;
        let nx = num(), ny = num(); if (rel) { nx += x; ny += y; }
        if (upper === 'M') { if (path.length) finish(false); sx = nx; sy = ny; push(nx, ny); cmd = rel ? 'l' : 'L'; }
        else if (upper === 'T') { const qx = lastQ ? 2 * x - lastQ.x : x, qy = lastQ ? 2 * y - lastQ.y : y; const ox = x, oy = y; for (let k = 1; k <= 8; k++) { const t = k / 8, u = 1 - t; push(u*u*ox + 2*u*t*qx + t*t*nx, u*u*oy + 2*u*t*qy + t*t*ny); } lastQ = { x: qx, y: qy }; }
        else push(nx, ny);
        x = nx; y = ny; lastC = null; if (upper !== 'T') lastQ = null;
      } else if (upper === 'H' || upper === 'V') {
        let z = num(); if (rel) z += upper === 'H' ? x : y; if (upper === 'H') x = z; else y = z; push(x, y); lastC = lastQ = null;
      } else if (upper === 'C') {
        if (i + 5 >= tokens.length) break;
        let x1=num(),y1=num(),x2=num(),y2=num(),nx=num(),ny=num(); if (rel) { x1+=x;y1+=y;x2+=x;y2+=y;nx+=x;ny+=y; }
        const ox=x,oy=y; for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*u*ox+3*u*u*t*x1+3*u*t*t*x2+t*t*t*nx,u*u*u*oy+3*u*u*t*y1+3*u*t*t*y2+t*t*t*ny);} x=nx;y=ny;lastC={x:x2,y:y2};lastQ=null;
      } else if (upper === 'S') {
        if (i + 3 >= tokens.length) break;
        const x1=lastC?2*x-lastC.x:x,y1=lastC?2*y-lastC.y:y;let x2=num(),y2=num(),nx=num(),ny=num();if(rel){x2+=x;y2+=y;nx+=x;ny+=y;}const ox=x,oy=y;for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*u*ox+3*u*u*t*x1+3*u*t*t*x2+t*t*t*nx,u*u*u*oy+3*u*u*t*y1+3*u*t*t*y2+t*t*t*ny);}x=nx;y=ny;lastC={x:x2,y:y2};lastQ=null;
      } else if (upper === 'Q') {
        if (i + 3 >= tokens.length) break;
        let x1=num(),y1=num(),nx=num(),ny=num();if(rel){x1+=x;y1+=y;nx+=x;ny+=y;}const ox=x,oy=y;for(let k=1;k<=scale;k++){const t=k/scale,u=1-t;push(u*u*ox+2*u*t*x1+t*t*nx,u*u*oy+2*u*t*y1+t*t*ny);}x=nx;y=ny;lastQ={x:x1,y:y1};lastC=null;
      } else if (upper === 'A') {
        // ImageTracer normally emits cubic curves; fail closed for an unexpected SVG arc.
        throw new Error('خرج مسار منحني غير مدعوم من محرك تتبع الصورة.');
      } else { break; }
    }
    if (path.length) finish(false);
    return paths;
  }
  function polylinesToDxf(paths, width, height, factor) {
    let out = '0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1009\n0\nENDSEC\n0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLTYPE\n70\n1\n0\nLTYPE\n2\nCONTINUOUS\n70\n0\n3\nSolid line\n72\n65\n73\n0\n40\n0.0\n0\nENDTAB\n0\nTABLE\n2\nLAYER\n70\n2\n0\nLAYER\n2\n0\n70\n0\n62\n7\n6\nCONTINUOUS\n0\nLAYER\n2\nIMAGE_TRACE\n70\n0\n62\n7\n6\nCONTINUOUS\n0\nENDTAB\n0\nENDSEC\n0\nSECTION\n2\nBLOCKS\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n';
    let count = 0;
    for (const p of paths) {
      let vertices = p.points || [];
      if (vertices.length < 2) continue;
      if (p.closed && vertices.length > 2 && Math.hypot(vertices[0].x - vertices[vertices.length - 1].x, vertices[0].y - vertices[vertices.length - 1].y) < 1e-6) vertices = vertices.slice(0, -1);
      if (vertices.length < 2) continue;
      out += `0\nPOLYLINE\n8\nIMAGE_TRACE\n66\n1\n70\n${p.closed ? 1 : 0}\n`;
      for (const v of vertices) out += `0\nVERTEX\n8\nIMAGE_TRACE\n10\n${fmt(v.x * factor)}\n20\n${fmt((height - v.y) * factor)}\n30\n0\n`;
      out += '0\nSEQEND\n8\nIMAGE_TRACE\n';
      count++;
    }
    if (!count) throw new Error('لم ينتج التتبع أي مسارات قابلة للحفظ. جرّب صورة أوضح أو زِد الدقة.');
    out += '0\nENDSEC\n0\nEOF\n';
    return { bytes: enc.encode(out), count };
  }
  /* Raw-record DXF board merge. Source entity records and supported symbol/block
     records are copied verbatim; only colliding handles, owners and symbol names
     are remapped. Unsupported external/object references fail closed. */
  function* dxfPairs(bytes, start=0, end=bytes.length) {
    let pos=start;
    while(pos<end){
      const c=readLine(bytes,pos); if(!c||c.end>end) break;
      const v=readLine(bytes,c.end); if(!v||v.end>end) break;
      yield {code:Number.parseInt(pairText(bytes,c),10),value:pairText(bytes,v),start:c.start,valueStart:v.start,valueEnd:v.valueEnd,end:v.end};
      pos=v.end;
    }
  }
  function dxfSectionBounds(bytes,name){
    let previous=null,active='',start=null;
    for(const p of dxfPairs(bytes)){
      if(previous&&previous.code===0&&previous.value.toUpperCase()==='SECTION'&&p.code===2){active=p.value.toUpperCase();start=p.end;}
      if(active===name.toUpperCase()&&p.code===0&&p.value.toUpperCase()==='ENDSEC')return {start,end:p.start,endPair:p};
      previous=p;
    }
    return null;
  }
  function dxfTableMap(bytes){
    const out=new Map();let previous=null,active=null,row=null,header=[];
    const finishRow=end=>{if(row){row.end=end;active.rows.push(row);row=null;}};
    const finishTable=()=>{if(active){if(active.endTab)finishRow(active.endTab.start);active.header=header;active.handle=header.find(p=>p.code===5)?.value||null;active.countPair=header.find(p=>p.code===70)||null;out.set(active.name,active);}active=null;header=[];};
    for(const p of dxfPairs(bytes)){
      if(previous&&previous.code===0&&previous.value.toUpperCase()==='TABLE'&&p.code===2){finishTable();active={name:p.value.toUpperCase(),start:previous.start,rows:[],endTab:null};header=[];row=null;}
      else if(active){
        if(p.code===0){if(p.value.toUpperCase()==='ENDTAB'){finishRow(p.start);active.endTab=p;finishTable();}else{finishRow(p.start);row={type:p.value.toUpperCase(),start:p.start,name:'',end:null};}}
        else if(row){if(p.code===2&&!row.name)row.name=p.value;}
        else header.push(p);
      }
      previous=p;
    }
    return out;
  }
  function dxfRowFields(bytes,row){return [...dxfPairs(bytes,row.start,row.end)];}
  function dxfRecordSignature(bytes,row){return dxfRowFields(bytes,row).filter(p=>![5,105,330].includes(p.code)).map(p=>`${p.code}:${p.value}`).join('\n');}
  function dxfBlockDefinitions(bytes){
    const sec=dxfSectionBounds(bytes,'BLOCKS');if(!sec)return [];
    const defs=[];let current=null;
    for(const p of dxfPairs(bytes,sec.start,sec.end)){
      if(p.code===0){
        const type=p.value.toUpperCase();
        if(type==='BLOCK'){if(current)throw new Error('تعريف BLOCK متداخل أو غير مغلق في اللوحة المصدر.');current={start:p.start,end:null,name:''};}
        else if(type==='ENDBLK'&&current){current.end=p.end;defs.push(current);current=null;}
      }else if(current&&p.code===2&&!current.name)current.name=p.value;
    }
    if(current)throw new Error('تعريف بلوك غير مكتمل في اللوحة المصدر.');
    return defs;
  }
  function dxfMaxHandle(bytes){let max=0n;for(const p of dxfPairs(bytes))if((p.code===5||p.code===105)&&/^[0-9A-F]+$/i.test(p.value)){const n=BigInt('0x'+p.value);if(n>max)max=n;}return max;}
  function dxfFindModelHandle(table,which){
    if(!table)return null;
    for(const r of table.rows){const n=String(r.name||'').replace(/[\s_-]/g,'').toUpperCase();if(n===which){const h=dxfRowFields(table._bytes,r).find(p=>p.code===5)?.value;return h||null;}}
    return null;
  }
  function dxfUniqueName(prefix,name,used,max=31){
    const base=String(name||'ITEM'),suffixBase=prefix+base;let candidate=suffixBase.slice(0,max),i=1;
    while(used.has(candidate.toUpperCase())){const suffix='_'+i++;candidate=suffixBase.slice(0,Math.max(1,max-suffix.length))+suffix;}
    used.add(candidate.toUpperCase());return candidate;
  }
  function dxfCollectHandles(bytes,ranges){
    const set=new Set();for(const [a,b] of ranges)for(const p of dxfPairs(bytes,a,b))if((p.code===5||p.code===105)&&/^[0-9A-F]+$/i.test(p.value))set.add(p.value.toUpperCase());return set;
  }
  function dxfRewriteRange(bytes,start,end,context,handleMap,edits){
    let entityType='';
    for(const p of dxfPairs(bytes,start,end)){
      if(p.code===0)entityType=p.value.toUpperCase();
      let replacement=null;
      if((p.code===5||p.code===105)&&handleMap.has(p.value.toUpperCase()))replacement=handleMap.get(p.value.toUpperCase());
      else if((p.code>=330&&p.code<=369)||p.code===1005){
        const h=p.value.toUpperCase();
        if(context.ownerMap?.has(h))replacement=context.ownerMap.get(h);
        else if(handleMap.has(h))replacement=handleMap.get(h);
        else if(/^[0-9A-F]+$/i.test(p.value))throw new Error(`يوجد مرجع DXF إلى مقبض خارجي ${p.value} (المجموعة ${p.code}) لم يمكن استيراده بأمان. لم يتم إنشاء ناتج ناقص.`);
      }
      if(replacement===null){
        const maps=context.names||{};
        if(p.code===8&&maps.LAYER?.has(p.value))replacement=maps.LAYER.get(p.value);
        else if(p.code===6&&maps.LTYPE?.has(p.value))replacement=maps.LTYPE.get(p.value);
        else if(p.code===7&&maps.STYLE?.has(p.value))replacement=maps.STYLE.get(p.value);
        else if(p.code===3&&entityType==='DIMENSION'&&maps.DIMSTYLE?.has(p.value))replacement=maps.DIMSTYLE.get(p.value);
        else if(p.code===1001&&maps.APPID?.has(p.value))replacement=maps.APPID.get(p.value);
        else if((entityType==='INSERT'||entityType==='DIMENSION')&&p.code===2&&maps.BLOCK?.has(p.value))replacement=maps.BLOCK.get(p.value);
        else if((entityType==='BLOCK'||entityType==='ENDBLK')&&(p.code===2||p.code===3)&&maps.BLOCK?.has(p.value))replacement=maps.BLOCK.get(p.value);
        else if(context.tableName&&p.code===2&&maps[context.tableName]?.has(p.value))replacement=maps[context.tableName].get(p.value);
        else if(context.tableName==='LAYER'&&p.code===6&&maps.LTYPE?.has(p.value))replacement=maps.LTYPE.get(p.value);
        else if(context.tableName==='DIMSTYLE'&&p.code===3&&maps.STYLE?.has(p.value))replacement=maps.STYLE.get(p.value);
      }
      if(replacement!==null&&String(replacement)!==p.value)edits.push({start:p.valueStart,end:p.valueEnd,insertBytes:enc.encode(String(replacement))});
    }
  }
  function dxfConcat(parts){let n=0;for(const p of parts)n+=p.length;const out=new Uint8Array(n);let at=0;for(const p of parts){out.set(p,at);at+=p.length;}return out;}
  function dxfParseHandseed(bytes){let previous=null;for(const p of dxfPairs(bytes)){if(previous&&previous.code===9&&previous.value.toUpperCase()==='$HANDSEED'&&p.code===5)return p;previous=p;}return null;}
  function mergeRawDxfBoards(targetInput,sourceInput){
    const target=targetInput instanceof Uint8Array?targetInput:new Uint8Array(targetInput),source=sourceInput instanceof Uint8Array?sourceInput:new Uint8Array(sourceInput);
    if(!target.length||!source.length)throw new Error('أحد ملفي DXF فارغ.');
    const ts=dxfSectionBounds(target,'ENTITIES'),ss=dxfSectionBounds(source,'ENTITIES'),tb=dxfSectionBounds(target,'BLOCKS'),sb=dxfSectionBounds(source,'BLOCKS');
    if(!ts||!ss)throw new Error('يجب أن يحتوي الملفان على قسم ENTITIES صالح.');
    if(!tb)throw new Error('اللوحة المرجعية لا تحتوي على قسم BLOCKS. أوقفت الدمج لحماية بنية الملف.');
    const tt=dxfTableMap(target),st=dxfTableMap(source);tt.forEach(v=>v._bytes=target);st.forEach(v=>v._bytes=source);
    if(!tt.has('LAYER')||!st.has('LAYER'))throw new Error('جدول LAYER مفقود في أحد الملفين.');
    const hasTargetBlockRecord=tt.has('BLOCK_RECORD'),hasSourceBlockRecord=st.has('BLOCK_RECORD');
    if(hasTargetBlockRecord!==hasSourceBlockRecord)throw new Error('إصدارا DXF يستخدمان بنيتين مختلفتين لجدول BLOCK_RECORD؛ أوقفت الدمج حتى لا تتغير بنية الملف.');
    const hasBlockRecord=hasTargetBlockRecord;
    const targetModel=hasBlockRecord?dxfFindModelHandle(tt.get('BLOCK_RECORD'),' *MODELSPACE'.trim()):null;
    const sourceModel=hasBlockRecord?dxfFindModelHandle(st.get('BLOCK_RECORD'),' *MODELSPACE'.trim()):null;
    if(hasBlockRecord&&(!targetModel||!sourceModel))throw new Error('تعذر تحديد Model Space في أحد الملفين.');
    const reserved=n=>String(n||'').replace(/[\s_-]/g,'').toUpperCase();
    const sysNames=new Set(['*MODELSPACE','*PAPERSPACE','*PAPERSPACE0']);
    const targetDefs=dxfBlockDefinitions(target),srcDefs=dxfBlockDefinitions(source);
    const targetBlockNames=new Set((hasBlockRecord?tt.get('BLOCK_RECORD').rows.map(r=>String(r.name||'')):targetDefs.map(d=>d.name)).map(n=>n.toUpperCase()));
    const defsByName=new Map(srcDefs.map(d=>[d.name.toUpperCase(),d]));
    const srcBlockRows=hasBlockRecord?st.get('BLOCK_RECORD').rows:[],blockMap=new Map();
    if(hasBlockRecord){
      for(const row of srcBlockRows){
        const name=row.name||'';if(!name)continue;
        if(sysNames.has(reserved(name)))continue;
        const def=defsByName.get(name.toUpperCase());if(!def)throw new Error(`تعريف البلوك ${name} مسجل في BLOCK_RECORD لكنه بلا بيانات BLOCK. أوقفت الدمج لمنع فقد العناصر.`);
        const mapped=targetBlockNames.has(name.toUpperCase())?dxfUniqueName('SQ163_',name,targetBlockNames,255):name;
        targetBlockNames.add(mapped.toUpperCase());blockMap.set(name,mapped);
      }
    }else{
      // Legacy R12/R13 DXF has no BLOCK_RECORD table. Preserve its block records
      // directly and remap names for INSERT/BLOCK references without inventing tables.
      for(const def of srcDefs){const name=def.name||'';if(!name||sysNames.has(reserved(name)))continue;const mapped=targetBlockNames.has(name.toUpperCase())?dxfUniqueName('SQ163_',name,targetBlockNames,31):name;targetBlockNames.add(mapped.toUpperCase());blockMap.set(name,mapped);}
    }
    for(const def of srcDefs)if(!sysNames.has(reserved(def.name))&&!blockMap.has(def.name))throw new Error(`تعريف البلوك ${def.name} غير مرتبط بسجل يمكن استيراده بأمان.`);
    const nameMaps={LAYER:new Map(),LTYPE:new Map(),STYLE:new Map(),DIMSTYLE:new Map(),APPID:new Map(),BLOCK:new Map(blockMap),BLOCK_RECORD:new Map(blockMap)};
    const tablesToMerge=['LAYER','LTYPE','STYLE','DIMSTYLE','APPID'];
    const plannedRows=new Map();
    for(const tableName of tablesToMerge){
      const srcTable=st.get(tableName),dstTable=tt.get(tableName);if(!srcTable){plannedRows.set(tableName,[]);continue;}
      if(!dstTable)throw new Error(`جدول ${tableName} غير موجود في اللوحة المرجعية بينما تحتاجه اللوحة المصدر.`);
      const existing=new Map(dstTable.rows.map(r=>[String(r.name||'').toUpperCase(),r])),used=new Set(existing.keys()),rows=[];
      for(const sr of srcTable.rows){
        const name=sr.name||'';if(!name)continue;
        if(tableName==='LAYER'&&name==='0'){const zero=existing.get('0');if(zero&&dxfRecordSignature(target,zero)!==dxfRecordSignature(source,sr))throw new Error('تعريف الطبقة 0 مختلف بين اللوحتين؛ أوقفت الدمج لحماية خصائصها.');nameMaps.LAYER.set(name,'0');continue;}
        const dr=existing.get(name.toUpperCase());
        if(!dr){nameMaps[tableName].set(name,name);rows.push(sr);used.add(name.toUpperCase());continue;}
        if(dxfRecordSignature(target,dr)===dxfRecordSignature(source,sr)){nameMaps[tableName].set(name,name);continue;}
        const mapped=dxfUniqueName('SQ163_',name,used,tableName==='LAYER'?31:255);nameMaps[tableName].set(name,mapped);rows.push(sr);
      }
      plannedRows.set(tableName,rows);
    }
    const reservedMap=new Map();
    if(hasBlockRecord)for(const name of ['*Model_Space','*Paper_Space','*Paper_Space0']){
      const sr=srcBlockRows.find(r=>reserved(r.name)===reserved(name)),tr=tt.get('BLOCK_RECORD').rows.find(r=>reserved(r.name)===reserved(name));
      if(sr&&tr){const sh=dxfRowFields(source,sr).find(p=>p.code===5)?.value,th=dxfRowFields(target,tr).find(p=>p.code===5)?.value;if(sh&&th)reservedMap.set(sh.toUpperCase(),th);}
    }
    const sourceRanges=[[ss.start,ss.end]];if(sb)for(const d of srcDefs)if(blockMap.has(d.name))sourceRanges.push([d.start,d.end]);
    for(const n of tablesToMerge)for(const r of plannedRows.get(n)||[])sourceRanges.push([r.start,r.end]);
    const blockRecordRows=hasBlockRecord?srcBlockRows.filter(r=>blockMap.has(r.name)):[];for(const r of blockRecordRows)sourceRanges.push([r.start,r.end]);
    const defined=dxfCollectHandles(source,sourceRanges),targetMax=dxfMaxHandle(target);let next=targetMax+1n;const handleMap=new Map();
    for(const h of defined){if(handleMap.has(h))throw new Error(`مقبض مكرر في المصدر: ${h}`);handleMap.set(h,(next++).toString(16).toUpperCase());}
    const ownerMap=new Map(reservedMap);
    for(const n of (hasBlockRecord?[...tablesToMerge,'BLOCK_RECORD']:tablesToMerge)){const a=st.get(n),b=tt.get(n);if(a?.handle&&b?.handle)ownerMap.set(a.handle.toUpperCase(),b.handle);}
    for(const row of blockRecordRows){const old=dxfRowFields(source,row).find(p=>p.code===5)?.value,newHandle=old&&handleMap.get(old.toUpperCase());if(old&&newHandle)ownerMap.set(old.toUpperCase(),newHandle);}
    const edits=[];
    dxfRewriteRange(source,ss.start,ss.end,{names:nameMaps,ownerMap},handleMap,edits);
    if(sb)for(const d of srcDefs)if(blockMap.has(d.name))dxfRewriteRange(source,d.start,d.end,{names:nameMaps,ownerMap},handleMap,edits);
    for(const n of tablesToMerge){const dst=tt.get(n);for(const r of plannedRows.get(n)||[])dxfRewriteRange(source,r.start,r.end,{names:nameMaps,ownerMap,tableName:n},handleMap,edits);}
    for(const r of blockRecordRows)dxfRewriteRange(source,r.start,r.end,{names:nameMaps,ownerMap,tableName:'BLOCK_RECORD'},handleMap,edits);
    const rewritten=edits.length?applyEdits(source,edits):source;
    const copied={};
    const rewrittenTables=dxfTableMap(rewritten);rewrittenTables.forEach(v=>v._bytes=rewritten);
    for(const n of tablesToMerge){copied[n]=[];const now=rewrittenTables.get(n);for(const r of plannedRows.get(n)||[]){const wanted=String(nameMaps[n].get(r.name)||r.name).toUpperCase();const matching=now?.rows.find(z=>z.name.toUpperCase()===wanted);if(!matching)throw new Error(`فشل تحديد سجل ${n} بعد إعادة ربط المراجع.`);copied[n].push(rewritten.subarray(matching.start,matching.end));}}
    const mappedBlockNames=new Set([...blockMap.values()].map(n=>n.toUpperCase()));
    copied.BLOCK_RECORD=[];if(hasBlockRecord)for(const r of rewrittenTables.get('BLOCK_RECORD').rows)if(mappedBlockNames.has(String(r.name||'').toUpperCase()))copied.BLOCK_RECORD.push(rewritten.subarray(r.start,r.end));
    const rewrittenDefs=dxfBlockDefinitions(rewritten);copied.BLOCKS=[];
    for(const d of rewrittenDefs)if(mappedBlockNames.has(d.name.toUpperCase()))copied.BLOCKS.push(rewritten.subarray(d.start,d.end));
    const newEnt=dxfSectionBounds(rewritten,'ENTITIES'),entityBytes=rewritten.subarray(newEnt.start,newEnt.end);
    const targetEdits=[];
    for(const n of (hasBlockRecord?[...tablesToMerge,'BLOCK_RECORD']:tablesToMerge)){const rows=copied[n]||[];if(!rows.length)continue;const t=tt.get(n);if(!t?.endTab)throw new Error(`لا يمكن إضافة سجلات جدول ${n}.`);targetEdits.push({start:t.endTab.start,end:t.endTab.start,insertBytes:dxfConcat(rows)});if(t.countPair)targetEdits.push({start:t.countPair.valueStart,end:t.countPair.valueEnd,insertBytes:enc.encode(String(t.rows.length+rows.length))});}
    if(copied.BLOCKS.length)targetEdits.push({start:tb.end,end:tb.end,insertBytes:dxfConcat(copied.BLOCKS)});
    if(entityBytes.length)targetEdits.push({start:ts.end,end:ts.end,insertBytes:entityBytes});
    const handseed=dxfParseHandseed(target);if(handseed)targetEdits.push({start:handseed.valueStart,end:handseed.valueEnd,insertBytes:enc.encode(next.toString(16).toUpperCase())});
    const merged=applyEdits(target,targetEdits),verifyTables=dxfTableMap(merged),verifyBlocks=dxfBlockDefinitions(merged),verifyEntities=dxfSectionBounds(merged,'ENTITIES');
    if(!verifyTables.get('LAYER')?.endTab||(hasBlockRecord&&!verifyTables.get('BLOCK_RECORD')?.endTab)||!verifyEntities)throw new Error('فشل التحقق البنيوي من DXF الناتج.');
    if(mappedBlockNames.size&&verifyBlocks.filter(d=>mappedBlockNames.has(d.name.toUpperCase())).length!==mappedBlockNames.size)throw new Error('لم يتم استيراد كل تعريفات البلوكات المصدرية.');
    let importedEntities=0;for(const p of dxfPairs(rewritten,newEnt.start,newEnt.end))if(p.code===0&&p.value.toUpperCase()!=='ENDSEC')importedEntities++;
  return {bytes:merged,sourceEntitiesBytes:entityBytes.length,importedEntities,importedBlocks:copied.BLOCKS.length,importedLayers:(copied.LAYER||[]).length,importedTableRecords:Object.fromEntries((hasBlockRecord?[...tablesToMerge,'BLOCK_RECORD']:tablesToMerge).map(n=>[n,(copied[n]||[]).length]))};
  }

  function downloadBytes(bytes, filename, mime = 'application/dxf') {
    const blob = new Blob([bytes], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = root.document.createElement('a'); a.href = url; a.download = filename; a.style.display = 'none';
    root.document.body.appendChild(a); a.click(); a.remove();
    root.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function mount() {
    if (!root.document || root.document.getElementById('sq162-cad-launch')) return;
    const doc = root.document;
    const style = doc.createElement('style');
    style.id = 'sq162-cad-style';
    style.textContent = `
      #sq162-cad-launch{position:fixed;right:14px;bottom:88px;z-index:2147483000;border:0;border-radius:28px;padding:12px 16px;background:#135ea8;color:#fff;font:700 14px system-ui;box-shadow:0 5px 20px #0004}
      #sq162-cad-overlay{position:fixed;inset:0;z-index:2147483001;background:#0009;display:none;align-items:center;justify-content:center;padding:10px;font-family:system-ui,sans-serif;color:#17202a}
      #sq162-cad-dialog{width:min(100%,980px);max-height:94vh;overflow:auto;background:#fff;border-radius:16px;padding:14px;box-sizing:border-box;direction:rtl;box-shadow:0 12px 55px #0006}
      #sq162-cad-dialog *{box-sizing:border-box} .sq162-head{display:flex;justify-content:space-between;align-items:center;gap:10px;border-bottom:1px solid #ddd;padding-bottom:10px;margin-bottom:10px}
      .sq162-actions{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.sq162-btn{border:0;border-radius:9px;padding:10px 13px;background:#155fa8;color:#fff;font-weight:700;font-size:13px}.sq162-btn:disabled{opacity:.45}.sq162-secondary{background:#e9eef4;color:#22313f}.sq162-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.sq162-panel{border:1px solid #d9e0e7;border-radius:11px;padding:10px;min-width:0}.sq162-panel label{display:block;font-size:13px;font-weight:700;margin-bottom:6px}.sq162-panel input[type=file]{width:100%;font-size:12px}.sq162-canvas{display:block;width:100%;height:420px;background:#fbfcfe;border:1px solid #e0e5eb;border-radius:7px;margin-top:8px;touch-action:none;cursor:crosshair;user-select:none}.sq162-view-tools{display:flex;align-items:center;gap:5px;flex-wrap:wrap;margin-top:8px}.sq162-view-tools .sq162-btn{padding:9px 13px;min-width:46px;min-height:42px}.sq162-zoom-value{font:600 11px system-ui;color:#34495e;min-width:42px;text-align:center}.sq162-snap-mode{max-width:170px;min-width:120px;padding:6px;border:1px solid #ccd5de;border-radius:8px;background:#fff;color:#1c2b38;font-size:11px}.sq162-note{font-size:12px;line-height:1.6;color:#465566}.sq162-status{padding:9px;border-radius:8px;background:#eef5fb;white-space:pre-wrap;font-size:13px;line-height:1.6;margin:8px 0}.sq162-tabs{display:flex;gap:7px;margin:6px 0 12px}.sq162-tab{border-radius:8px;padding:8px 11px;background:#e8edf2;color:#243342;border:0;font-weight:700}.sq162-tab.active{background:#155fa8;color:#fff}.sq162-section{display:none}.sq162-section.active{display:block}.sq162-scale{width:110px;max-width:35%;padding:8px;border:1px solid #c7d0da;border-radius:7px;direction:ltr}
      @media(max-width:650px){#sq162-cad-dialog{padding:10px}.sq162-grid{grid-template-columns:1fr}.sq162-canvas{height:380px}.sq162-head h3{font-size:16px}}
    `;
    doc.head.appendChild(style);
    const launch = doc.createElement('button'); launch.id = 'sq162-cad-launch'; launch.type = 'button'; launch.textContent = 'أدوات CAD';
    const overlay = doc.createElement('div'); overlay.id = 'sq162-cad-overlay';
    overlay.innerHTML = `
      <div id="sq162-cad-dialog" role="dialog" aria-modal="true" aria-label="أدوات CAD">
        <div class="sq162-head"><div><h3 style="margin:0">أدوات CAD المساحية</h3><div class="sq162-note">توجيه ثنائي النقاط وتحويل مجاني للصورة أو PDF إلى DXF</div></div><button id="sq162-close" class="sq162-btn sq162-secondary" type="button">إغلاق ومسح الملفات</button></div>
        <div class="sq162-tabs"><button class="sq162-tab active" data-tab="align" type="button">توجيه اللوحات</button><button class="sq162-tab" data-tab="raster" type="button">صورة / PDF إلى DXF</button></div>
        <section id="sq162-tab-align" class="sq162-section active">
          <div class="sq162-note">اختر اللوحة غير الموجهة ثم اللوحة المرجعية. التوجيه يحسب الدوران والمقياس والإزاحة من نقطتين متقابلتين. كبّر بإصبعيك أو بعجلة الفأرة، واسحب لتحريك اللوحة، واختر التقاط التقاطع أو النهاية أو المنتصف. في DXF تُعدّل سجلات الإحداثيات داخل الملف نفسه مع إبقاء أنواع العناصر والليارات والنصوص ومقابضها كما هي. ملفات DWG تتحول أولًا إلى DXF عبر LibreDWG.</div>
          <div class="sq162-grid" style="margin-top:10px">
            <div class="sq162-panel"><label for="sq162-source-file">اللوحة غير الموجهة (DWG / DXF)</label><input id="sq162-source-file" type="file" accept=".dwg,.dxf,application/dxf,application/octet-stream"><div class="sq162-view-tools" data-sq-view="source"><button class="sq162-btn sq162-secondary" data-sq-zoom="in" type="button" aria-label="تكبير">＋ تكبير</button><button class="sq162-btn sq162-secondary" data-sq-zoom="out" type="button" aria-label="تصغير">− تصغير</button><button class="sq162-btn sq162-secondary" data-sq-zoom="fit" type="button">احتواء الرسم</button><span class="sq162-zoom-value">100%</span><select class="sq162-snap-mode" aria-label="نمط الالتقاط"><option value="intersection">تقاطع المحاور</option><option value="endpoint">نهاية عنصر</option><option value="midpoint">منتصف عنصر</option><option value="nearest">أقرب نقطة</option></select></div><canvas id="sq162-source-canvas" class="sq162-canvas" aria-label="معاينة اللوحة غير الموجهة"></canvas><div id="sq162-source-info" class="sq162-note">لم يتم اختيار ملف بعد.</div></div>
            <div class="sq162-panel"><label for="sq162-target-file">اللوحة الموجهة المرجعية (DWG / DXF)</label><input id="sq162-target-file" type="file" accept=".dwg,.dxf,application/dxf,application/octet-stream"><div class="sq162-view-tools" data-sq-view="target"><button class="sq162-btn sq162-secondary" data-sq-zoom="in" type="button" aria-label="تكبير">＋ تكبير</button><button class="sq162-btn sq162-secondary" data-sq-zoom="out" type="button" aria-label="تصغير">− تصغير</button><button class="sq162-btn sq162-secondary" data-sq-zoom="fit" type="button">احتواء الرسم</button><span class="sq162-zoom-value">100%</span><select class="sq162-snap-mode" aria-label="نمط الالتقاط"><option value="intersection">تقاطع المحاور</option><option value="endpoint">نهاية عنصر</option><option value="midpoint">منتصف عنصر</option><option value="nearest">أقرب نقطة</option></select></div><canvas id="sq162-target-canvas" class="sq162-canvas" aria-label="معاينة اللوحة المرجعية"></canvas><div id="sq162-target-info" class="sq162-note">لم يتم اختيار ملف بعد.</div></div>
          </div>
          <div class="sq162-actions"><button id="sq162-start-pick" class="sq162-btn" type="button" disabled>ابدأ اختيار النقاط</button><button id="sq162-do-align" class="sq162-btn" type="button" disabled>توجيه وحفظ DXF</button><button id="sq162-reset-picks" class="sq162-btn sq162-secondary" type="button">إعادة اختيار النقاط</button></div>
          <div id="sq162-align-status" class="sq162-status" aria-live="polite">الخطوة 1: حمّل اللوحتين لبدء التوجيه.</div>
        </section>
        <section id="sq162-tab-raster" class="sq162-section">
          <div class="sq162-note">استخراج متجهات مجاني داخل التطبيق باستخدام ImageTracer. الناتج يتتبع الخطوط المرئية، ولا يستعيد النصوص أو الإحداثيات أو المقياس الأصلي من صورة ممسوحة ضوئيًا. اضبط عامل المقياس إذا كنت تعرف قيمة مناسبة.</div>
          <div class="sq162-panel" style="margin-top:10px"><label for="sq162-raster-file">اختر صورة أو PDF</label><input id="sq162-raster-file" type="file" accept="image/png,image/jpeg,image/webp,.jpg,.jpeg,.png,.webp,.pdf,application/pdf"><label for="sq162-pdf-page" style="margin-top:9px">رقم صفحة PDF</label><input id="sq162-pdf-page" type="number" min="1" step="1" value="1" class="sq162-scale"><label for="sq162-raster-scale" style="margin-top:9px">عامل المقياس (وحدة رسم لكل بكسل)</label><input id="sq162-raster-scale" type="number" min="0.000001" step="any" value="1" class="sq162-scale"><div class="sq162-actions"><button id="sq162-trace" class="sq162-btn" type="button" disabled>تحويل وحفظ DXF</button></div><div id="sq162-raster-status" class="sq162-status" aria-live="polite">اختر ملفًا للبدء.</div><canvas id="sq162-raster-canvas" class="sq162-canvas" style="display:none" aria-label="معاينة الصورة قبل التحويل"></canvas></div>
        </section>
        <div class="sq162-note" style="margin-top:10px">لا يُستخدم localStorage أو قاعدة بيانات لحفظ اللوحات في هذه الأداة. عند الإغلاق تُفرّغ الذاكرة المؤقتة وعناصر اختيار الملفات.</div>
      </div>`;
    doc.body.appendChild(launch); doc.body.appendChild(overlay);
    const el = id => doc.getElementById(id);
    const state = { source: null, target: null, pickStage: -1, picks: [], tracerFile: null, rasterCanvas: null, views: {source:{zoom:1,panX:0,panY:0,centerX:null,centerY:null},target:{zoom:1,panX:0,panY:0,centerX:null,centerY:null}}, snapModes:{source:'intersection',target:'intersection'}, hover:{source:null,target:null} };
    function status(text, id = 'sq162-align-status') { el(id).textContent = text; }
    function fileTitle(file) { return file && file.name ? file.name : 'drawing'; }
    function clearCanvas(canvas) { const c = canvas.getContext('2d'); c.clearRect(0, 0, canvas.width, canvas.height); }
    function clearDrawing(which) {
      state[which] = null; state.hover[which]=null; state.views[which]={zoom:1,panX:0,panY:0,centerX:null,centerY:null};
      const prefix = which === 'source' ? 'source' : 'target';
      el(`sq162-${prefix}-file`).value = ''; el(`sq162-${prefix}-info`).textContent = 'لم يتم اختيار ملف بعد.';
      clearCanvas(el(`sq162-${prefix}-canvas`));
      state.picks = []; state.pickStage = -1; updatePickUi();
    }
    function cleanup() {
      clearDrawing('source'); clearDrawing('target');
      state.tracerFile = null; state.rasterCanvas = null;
      el('sq162-raster-file').value = ''; el('sq162-pdf-page').value = '1'; el('sq162-raster-scale').value = '1';
      el('sq162-raster-canvas').style.display = 'none'; clearCanvas(el('sq162-raster-canvas'));
      el('sq162-trace').disabled = true; status('تم مسح الملفات والنقاط من الذاكرة المؤقتة.');
      status('اختر ملفًا للبدء.', 'sq162-raster-status');
    }
    function updatePickUi() {
      el('sq162-start-pick').disabled = !(state.source && state.target);
      el('sq162-do-align').disabled = state.picks.length !== 4 || !state.source || !state.target;
      for (const which of ['source', 'target']) {
        const c = el(`sq162-${which}-canvas`); c.style.outline = state.pickStage >= 0 && ((state.pickStage < 2 && which === 'source') || (state.pickStage >= 2 && which === 'target')) ? '2px solid #16834a' : 'none';
      }
      if (state.pickStage >= 0 && state.pickStage < 4) {
        const descriptions = ['اضغط على النقطة الأولى في اللوحة غير الموجهة.', 'اضغط على النقطة الثانية في اللوحة غير الموجهة.', 'اضغط على النقطة المقابلة للأولى في اللوحة المرجعية.', 'اضغط على النقطة المقابلة للثانية في اللوحة المرجعية.'];
        status(`النقطة ${state.pickStage + 1} من 4\n${descriptions[state.pickStage]}\n${state.picks.map((p, i) => `${i + 1}: X=${fmt(p.x)}, Y=${fmt(p.y)}`).join('\n')}`);
      }
    }
    function drawGeometry(which, canvas, geom, picks, firstPickIndex) {
      if (!geom) return;
      const dpr = Math.min(root.devicePixelRatio || 1, 2), w = Math.max(240, canvas.clientWidth || 280), h = Math.max(160, canvas.clientHeight || 300);
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      const ctx = canvas.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.fillStyle = '#fbfcfe'; ctx.fillRect(0, 0, w, h);
      const pad = 16, sx = (w - 2 * pad) / (geom.maxX - geom.minX), sy = (h - 2 * pad) / (geom.maxY - geom.minY), baseScale = Math.max(1e-12, Math.min(sx, sy));
      const view = state.views[which];
      if (!Number.isFinite(view.centerX) || !Number.isFinite(view.centerY)) { view.centerX=(geom.minX+geom.maxX)/2; view.centerY=(geom.minY+geom.maxY)/2; }
      view.zoom = Math.max(0.2, Math.min(10000, Number(view.zoom)||1));
      const sc = baseScale * view.zoom;
      const pt = p => ({ x: w/2 + (p.x-view.centerX)*sc + view.panX, y: h/2 - (p.y-view.centerY)*sc + view.panY });
      const toWorld = p => ({x:view.centerX+(p.x-w/2-view.panX)/sc,y:view.centerY-(p.y-h/2-view.panY)/sc});
      ctx.strokeStyle = '#1976b8'; ctx.lineWidth = Math.max(.6,Math.min(2,1/Math.sqrt(view.zoom))); ctx.beginPath();
      for (const seg of geom.segments) { const a = pt(seg.a), b = pt(seg.b); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); }
      ctx.stroke();
      if (!geom.segments.length) { ctx.strokeStyle = '#1976b8'; ctx.lineWidth = 1; for (const q of geom.points.slice(0, 8000)) { const p = pt(q); ctx.beginPath(); ctx.moveTo(p.x - 3, p.y); ctx.lineTo(p.x + 3, p.y); ctx.moveTo(p.x, p.y - 3); ctx.lineTo(p.x, p.y + 3); ctx.stroke(); } }
      ctx.fillStyle = '#d63333';
      for (let i = 0; i < picks.length; i++) { const p = pt(picks[i]); ctx.beginPath(); ctx.arc(p.x,p.y,5,0,Math.PI*2); ctx.fill(); ctx.fillStyle='#fff';ctx.font='bold 11px sans-serif';ctx.fillText(String(i+firstPickIndex+1),p.x+7,p.y-7);ctx.fillStyle='#d63333'; }
      const hover=state.hover[which];
      if(hover?.point){const q=pt(hover.point);ctx.save();ctx.strokeStyle='#079455';ctx.fillStyle='#079455';ctx.lineWidth=2;ctx.beginPath();ctx.arc(q.x,q.y,8,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(q.x-13,q.y);ctx.lineTo(q.x+13,q.y);ctx.moveTo(q.x,q.y-13);ctx.lineTo(q.x,q.y+13);ctx.stroke();ctx.font='bold 11px system-ui';ctx.fillText(hover.typeLabel||'Snap',q.x+12,q.y-10);ctx.restore();}
      canvas._sqMap = { geom, width:w, height:h, pad, sc, baseScale, pt, toWorld, view };
      const toolbar=overlay.querySelector(`[data-sq-view="${which}"]`); if(toolbar){const z=toolbar.querySelector('.sq162-zoom-value');if(z)z.textContent=`${Math.round(view.zoom*100)}%`;const sel=toolbar.querySelector('.sq162-snap-mode');if(sel&&sel.value!==state.snapModes[which])sel.value=state.snapModes[which];}
    }
    let sqRedrawPending=false;
    function requestRedraw(){if(sqRedrawPending)return;sqRedrawPending=true;const raf=root.requestAnimationFrame||((fn)=>root.setTimeout(fn,16));raf(()=>{sqRedrawPending=false;redrawAll();});}
    function redrawAll() {
      if (state.source) drawGeometry('source',el('sq162-source-canvas'), state.source.geom, state.picks.slice(0, 2), 0);
      if (state.target) drawGeometry('target',el('sq162-target-canvas'), state.target.geom, state.picks.slice(2, 4), 2);
    }
    function fitView(which){const g=state[which]?.geom;if(!g)return;state.views[which]={zoom:1,panX:0,panY:0,centerX:(g.minX+g.maxX)/2,centerY:(g.minY+g.maxY)/2};redrawAll();}
    function zoomView(which,factor,anchor){const c=el(`sq162-${which}-canvas`),map=c&&c._sqMap;if(!map)return;const view=state.views[which],a=anchor||{x:map.width/2,y:map.height/2},world=map.toWorld(a);view.zoom=Math.max(.2,Math.min(10000,view.zoom*factor));const sc=map.baseScale*view.zoom;view.panX=a.x-map.width/2-(world.x-view.centerX)*sc;view.panY=a.y-map.height/2+(world.y-view.centerY)*sc;redrawAll();}
    for(const toolbar of overlay.querySelectorAll('[data-sq-view]')){
      const which=toolbar.dataset.sqView;
      toolbar.addEventListener('click',e=>{const b=e.target.closest('[data-sq-zoom]');if(!b)return;const action=b.dataset.sqZoom;if(action==='fit')fitView(which);else zoomView(which,action==='in'?2:1/2);});
      const select=toolbar.querySelector('.sq162-snap-mode');select.addEventListener('change',()=>{state.snapModes[which]=select.value;status(`نمط الالتقاط: ${select.options[select.selectedIndex].text}`);});
    }
    async function loadCadFile(which, file) {
      if (!file) return;
      state.picks = []; state.pickStage = -1; updatePickUi();
      if (!/\.(dwg|dxf)$/i.test(file.name)) throw new Error('اختر ملف DWG أو DXF فقط.');
      if (typeof root.parseFile !== 'function') throw new Error('قارئ الملفات المشترك غير متاح في هذه الشاشة.');
      status('جارٍ قراءة الملف وتحويل DWG إلى DXF عند الحاجة...');
      const model = await root.parseFile(file, { rawOnly: true, conversionOnly: true, retainRawDWG: false });
      const raw = model && model.rawDXFBytes;
      if (!raw || !raw.length) throw new Error('لم يُنتج القارئ بيانات DXF. لا يمكن متابعة التوجيه دون ملف صالح.');
      const bytes = raw instanceof Uint8Array ? raw : new Uint8Array(raw);
      const geom = readGeometry(bytes);
      state[which] = { file, bytes, geom };
      state.views[which]={zoom:1,panX:0,panY:0,centerX:(geom.minX+geom.maxX)/2,centerY:(geom.minY+geom.maxY)/2};
      el(`sq162-${which}-info`).textContent = `${file.name}\n${geom.segments.length.toLocaleString()} مقطع معاينة. البيانات مؤقتة في الذاكرة فقط.`;
      redrawAll(); updatePickUi();
      status(`تم تجهيز ${file.name} للمعاينة.`);
    }
    el('sq162-source-file').addEventListener('change', async e => { try { await loadCadFile('source', e.target.files[0]); } catch (err) { clearDrawing('source'); status(String(err.message || err)); } });
    el('sq162-target-file').addEventListener('change', async e => { try { await loadCadFile('target', e.target.files[0]); } catch (err) { clearDrawing('target'); status(String(err.message || err)); } });
    el('sq162-start-pick').addEventListener('click', () => { state.picks = []; state.hover={source:null,target:null}; state.pickStage = 0; updatePickUi(); redrawAll(); });
    el('sq162-reset-picks').addEventListener('click', () => { state.picks = []; state.hover={source:null,target:null}; state.pickStage = state.source && state.target ? 0 : -1; updatePickUi(); redrawAll(); });
    function updateSnapPreview(which,clientX,clientY){
      if(state.pickStage<0||state.pickStage>=4)return;
      const expected=state.pickStage<2?'source':'target';if(which!==expected)return;
      const canvas=el(`sq162-${which}-canvas`),map=canvas._sqMap;if(!map||!state[which])return;
      const rect=canvas.getBoundingClientRect(),pixel={x:clientX-rect.left,y:clientY-rect.top},world=map.toWorld(pixel);
      state.hover[which]=snapPoint(state[which].geom,world,state.snapModes[which]||'intersection',14/map.sc);
      requestRedraw();
    }
    function handleCanvasPick(which,clientX,clientY) {
      if (state.pickStage < 0 || state.pickStage >= 4) return;
      const expected = state.pickStage < 2 ? 'source' : 'target';
      if (which !== expected) { status(expected === 'source' ? 'اختر النقطة على اللوحة غير الموجهة أولًا.' : 'اختر النقطة المقابلة على اللوحة المرجعية أولًا.'); return; }
      const canvas=el(`sq162-${which}-canvas`),map=canvas._sqMap;if(!map)return;
      const rect=canvas.getBoundingClientRect(),pixel={x:clientX-rect.left,y:clientY-rect.top},world=map.toWorld(pixel);
      try {
        const snap=snapPoint(state[which].geom,world,state.snapModes[which]||'intersection',14/map.sc);
        if(!snap)throw new Error('لم يتم العثور على عنصر داخل مدى الالتقاط. كبّر اللوحة أو اختر نمط التقاط آخر.');
        state.picks.push({...snap.point,snapType:snap.type});state.hover[which]=null;state.pickStage++;updatePickUi();redrawAll();
        status(`تم التقاط ${snap.typeLabel} عند X=${fmt(snap.point.x)}، Y=${fmt(snap.point.y)}.`);
      } catch (err) { status(String(err.message || err)); }
    }
    function bindViewport(which){
      const canvas=el(`sq162-${which}-canvas`),pointers=new Map();let gesture=null;
      const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),mid=(a,b)=>({x:(a.x+b.x)/2,y:(a.y+b.y)/2});
      canvas.addEventListener('wheel',e=>{e.preventDefault();const r=canvas.getBoundingClientRect();zoomView(which,e.deltaY<0?1.22:1/1.22,{x:e.clientX-r.left,y:e.clientY-r.top});},{passive:false});
      canvas.addEventListener('pointerdown',e=>{
        canvas.setPointerCapture?.(e.pointerId);const r=canvas.getBoundingClientRect(),p={x:e.clientX-r.left,y:e.clientY-r.top};pointers.set(e.pointerId,p);updateSnapPreview(which,e.clientX,e.clientY);
        if(pointers.size===1){const v=state.views[which];gesture={type:'drag',start:p,last:p,panX:v.panX,panY:v.panY,moved:false};}
        else if(pointers.size===2){const q=[...pointers.values()],map=canvas._sqMap,center=mid(q[0],q[1]);gesture={type:'pinch',distance:Math.max(1,dist(q[0],q[1])),zoom:state.views[which].zoom,world:map?map.toWorld(center):null,center,viewCenter:{x:map?.view.centerX||0,y:map?.view.centerY||0}};}
      });
      canvas.addEventListener('pointermove',e=>{
        if(!pointers.has(e.pointerId))return;const r=canvas.getBoundingClientRect(),p={x:e.clientX-r.left,y:e.clientY-r.top};pointers.set(e.pointerId,p);
        if(pointers.size>=2&&gesture?.type==='pinch'){
          const q=[...pointers.values()],d=Math.max(1,dist(q[0],q[1])),center=mid(q[0],q[1]),view=state.views[which],map=canvas._sqMap;
          view.zoom=Math.max(.2,Math.min(10000,gesture.zoom*d/gesture.distance));if(map&&gesture.world){const sc=map.baseScale*view.zoom;view.panX=center.x-map.width/2-(gesture.world.x-view.centerX)*sc;view.panY=center.y-map.height/2+(gesture.world.y-view.centerY)*sc;}
          requestRedraw();
        }else if(pointers.size===1&&gesture?.type==='drag'){
          const dx=p.x-gesture.start.x,dy=p.y-gesture.start.y,travel=Math.hypot(dx,dy);
          if(travel>8){gesture.moved=true;const v=state.views[which];v.panX=gesture.panX+dx;v.panY=gesture.panY+dy;requestRedraw();}
          else if(!gesture.lastSnapPreviewAt||Date.now()-gesture.lastSnapPreviewAt>120){gesture.lastSnapPreviewAt=Date.now();updateSnapPreview(which,e.clientX,e.clientY);}
        }
      });
      const release=e=>{const was=gesture;pointers.delete(e.pointerId);if(pointers.size===0){if(was?.type==='drag'&&!was.moved)handleCanvasPick(which,e.clientX,e.clientY);gesture=null;}else if(pointers.size===1){const q=[...pointers.values()][0],v=state.views[which];gesture={type:'drag',start:q,last:q,panX:v.panX,panY:v.panY,moved:true};}};
      canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);if(!pointers.size)gesture=null;else if(pointers.size===1){const q=[...pointers.values()][0],v=state.views[which];gesture={type:'drag',start:q,last:q,panX:v.panX,panY:v.panY,moved:true};}});
    }
    bindViewport('source');bindViewport('target');
    el('sq162-do-align').addEventListener('click', () => {
      try {
        if (!state.source || !state.target || state.picks.length !== 4) throw new Error('حمّل اللوحتين واختر أربع نقاط متقابلة أولًا.');
        const [a, b, c, d] = state.picks;
        const result = transformDxfBytes(state.source.bytes, a, b, c, d);
        const base = fileTitle(state.source.file).replace(/\.[^.]+$/, '');
        downloadBytes(result.bytes, `${base}_ALIGNED.dxf`);
        status(`تم إنشاء DXF الموجّه.\nالدوران: ${fmt(result.rotationDegrees)} درجة\nالمقياس: ${fmt(result.scale)}\nعدد مواضع التعديل: ${result.editCount}\nلم يتم تغيير اسم أي layer أو نوع أي عنصر. لم يتم حفظ الملف داخل ذاكرة التطبيق بعد التنزيل.`);
      } catch (err) { status(String(err.message || err)); }
    });
    launch.addEventListener('click', () => { overlay.style.display = 'flex'; });
    el('sq162-close').addEventListener('click', () => { cleanup(); overlay.style.display = 'none'; });
    overlay.addEventListener('click', e => { if (e.target === overlay) { cleanup(); overlay.style.display = 'none'; } });
    doc.addEventListener('keydown', e => { if (e.key === 'Escape' && overlay.style.display === 'flex') { cleanup(); overlay.style.display = 'none'; } });
    for (const tab of overlay.querySelectorAll('[data-tab]')) tab.addEventListener('click', () => {
      for (const t of overlay.querySelectorAll('[data-tab]')) t.classList.toggle('active', t === tab);
      for (const s of overlay.querySelectorAll('.sq162-section')) s.classList.toggle('active', s.id === `sq162-tab-${tab.dataset.tab}`);
    });
    // Include DWG in any existing CAD picker that already accepts DXF, including pickers
    // created later by project screens, without changing unrelated image/document pickers.
    function broadenCadPickers(scope) {
      for (const input of scope.querySelectorAll ? scope.querySelectorAll('input[type="file"]') : []) {
        const accept = input.getAttribute('accept') || '';
        if (/\.dxf/i.test(accept) && !/\.dwg/i.test(accept)) input.setAttribute('accept', `${accept},.dwg`);
      }
    }
    broadenCadPickers(doc);
    if (root.MutationObserver) new root.MutationObserver(records => { for (const r of records) for (const n of r.addedNodes) if (n.nodeType === 1) broadenCadPickers(n); }).observe(doc.documentElement, { childList: true, subtree: true });

    // Raster/PDF conversion. PDF.js and ImageTracer are embedded by the build workflow;
    // this keeps this feature free and usable offline after installation.
    const rasterFileInput = el('sq162-raster-file'), traceBtn = el('sq162-trace'), rasterCanvas = el('sq162-raster-canvas');
    rasterFileInput.addEventListener('change', () => { state.tracerFile = rasterFileInput.files[0] || null; traceBtn.disabled = !state.tracerFile; status(state.tracerFile ? `تم اختيار ${state.tracerFile.name}.` : 'اختر ملفًا للبدء.', 'sq162-raster-status'); });
    traceBtn.addEventListener('click', async () => {
      const file = state.tracerFile;
      try {
        if (!file) throw new Error('اختر صورة أو PDF أولًا.');
        if (!root.ImageTracer || typeof root.ImageTracer.imagedataToSVG !== 'function') throw new Error('محرك التتبع المجاني غير محمّل في هذه النسخة.');
        traceBtn.disabled = true; status('جارٍ تجهيز الصورة واستخراج الخطوط...', 'sq162-raster-status');
        const maxDim = 1400; let canvas = doc.createElement('canvas'), ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (/\.pdf$/i.test(file.name) || file.type === 'application/pdf') {
          if (!root.pdfjsLib || typeof root.pdfjsLib.getDocument !== 'function') throw new Error('قارئ PDF غير مضمّن في هذه النسخة.');
          const pdf = await root.pdfjsLib.getDocument({ data: new Uint8Array(await file.arrayBuffer()), useSystemFonts: true, isEvalSupported: false }).promise;
          const pageNumber = Math.max(1, Math.min(pdf.numPages, Number.parseInt(el('sq162-pdf-page').value || '1', 10) || 1));
          const page = await pdf.getPage(pageNumber), base = page.getViewport({ scale: 1 });
          const sc = Math.min(2, maxDim / base.width, maxDim / base.height);
          const viewport = page.getViewport({ scale: sc }); canvas.width = Math.max(1, Math.floor(viewport.width)); canvas.height = Math.max(1, Math.floor(viewport.height));
          await page.render({ canvasContext: ctx, viewport }).promise;
          try { pdf.destroy(); } catch (_) {}
        } else {
          const url = URL.createObjectURL(file);
          try {
            const image = new Image(); image.src = url; await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = () => reject(new Error('تعذر فتح الصورة.')); });
            const sc = Math.min(1, maxDim / image.naturalWidth, maxDim / image.naturalHeight);
            canvas.width = Math.max(1, Math.floor(image.naturalWidth * sc)); canvas.height = Math.max(1, Math.floor(image.naturalHeight * sc));
            ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
          } finally { URL.revokeObjectURL(url); }
        }
        if (canvas.width * canvas.height > maxDim * maxDim) throw new Error('حجم الصفحة أكبر من الحد الآمن للتحويل.');
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height), px = imageData.data;
        // Otsu threshold keeps foreground/background separation image-dependent.
        const hist = new Uint32Array(256); let total = canvas.width * canvas.height, sum = 0;
        for (let i = 0; i < px.length; i += 4) { const g = Math.round(0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2]); hist[g]++; sum += g; }
        let sumB = 0, wB = 0, best = -1, threshold = 190;
        for (let t = 0; t < 256; t++) { wB += hist[t]; if (!wB) continue; const wF = total - wB; if (!wF) break; sumB += t * hist[t]; const mB = sumB / wB, mF = (sum - sumB) / wF; const between = wB * wF * (mB - mF) ** 2; if (between > best) { best = between; threshold = t; } }
        for (let i = 0; i < px.length; i += 4) { const g = Math.round(0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2]), v = g <= Math.min(245, Math.max(80, threshold)) ? 0 : 255; px[i] = px[i + 1] = px[i + 2] = v; px[i + 3] = 255; }
        ctx.putImageData(imageData, 0, 0);
        rasterCanvas.width = canvas.width; rasterCanvas.height = canvas.height; rasterCanvas.style.display = 'block';
        const rctx = rasterCanvas.getContext('2d'); rctx.clearRect(0, 0, rasterCanvas.width, rasterCanvas.height); rctx.drawImage(canvas, 0, 0);
        const svg = root.ImageTracer.imagedataToSVG(imageData, { numberofcolors: 2, colorquantcycles: 1, ltres: 1.1, qtres: 1.1, pathomit: 4, roundcoords: 1, scale: 1, viewbox: true });
        const parsed = new DOMParser().parseFromString(svg, 'image/svg+xml');
        const paths = [];
        for (const pathNode of Array.from(parsed.querySelectorAll('path'))) {
          const holder = pathNode.closest('g'); const fill = (pathNode.getAttribute('fill') || (holder && holder.getAttribute('fill')) || '').toLowerCase();
          const rgb = fill.match(/#([0-9a-f]{3,6})/i);
          let light = /white|#fff/.test(fill);
          if (rgb) { const hex = rgb[1].length === 3 ? rgb[1].split('').map(c => c + c).join('') : rgb[1].slice(0, 6); light = parseInt(hex.slice(0, 2), 16) + parseInt(hex.slice(2, 4), 16) + parseInt(hex.slice(4, 6), 16) > 600; }
          if (!light && pathNode.getAttribute('d')) paths.push(...svgPathToPolylines(pathNode.getAttribute('d'), 8));
        }
        const factor = Number(el('sq162-raster-scale').value);
        if (!finite(factor) || factor <= 0) throw new Error('عامل المقياس يجب أن يكون رقمًا موجبًا.');
        const result = polylinesToDxf(paths, canvas.width, canvas.height, factor);
        const baseName = file.name.replace(/\.[^.]+$/, ''); downloadBytes(result.bytes, `${baseName}_TRACE.dxf`);
        status(`اكتمل التحويل إلى DXF.\nعدد مسارات المتجهات: ${result.count}\nأبعاد الصورة المستخدمة: ${canvas.width} × ${canvas.height} بكسل\nعامل المقياس: ${fmt(factor)} وحدة/بكسل\nهذا تتبّع تقريبي للخطوط المرئية وليس استعادةً لبيانات CAD الأصلية.`, 'sq162-raster-status');
        canvas.width = 1; canvas.height = 1; // release pixel buffer after creating the DXF
      } catch (err) { status(String(err.message || err), 'sq162-raster-status'); }
      finally { traceBtn.disabled = !state.tracerFile; }
    });

    root.addEventListener('pagehide', cleanup, { once: true });
  }
  return { solve, transformDxfBytes, readGeometry, nearestPoint, snapPoint, mergeRawDxfBoards, svgPathToPolylines, polylinesToDxf, mount };
});
