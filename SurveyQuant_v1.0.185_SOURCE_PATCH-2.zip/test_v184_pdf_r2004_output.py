from pathlib import Path
import base64, json, shutil
from playwright.sync_api import sync_playwright
import ezdxf, ezdxf.recover
root=Path(__file__).resolve().parent
html=(root/'index.html').read_text(encoding='utf-8')
fixtures=[('mixed',root/'V180_MIXED_ARCHITECTURAL_TEST.pdf','V184_Mixed'),('raster',root/'V180_RASTER_ONLY_TEST.pdf','V184_Raster'),('vector',root/'V180_VECTOR_ONLY_TEST.pdf','V184_Vector')]
ANDROID=r"""window.__nativeSavedFiles={};window.__nativeNotifiedFiles=[];window.Android={saveFile:(filename,mime,base64)=>{window.__nativeSavedFiles[filename]={filename,mime,base64};return 'Downloads/SurveyQuant/'+filename;},notifyDownload:(filename,path,mime)=>window.__nativeNotifiedFiles.push({filename,path,mime})};"""
with sync_playwright() as p:
 chrome=shutil.which('chromium') or shutil.which('chromium-browser')
 opts={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
 if chrome: opts['executable_path']=chrome
 b=p.chromium.launch(**opts)
 page=b.new_page(viewport={'width':430,'height':900})
 page_errors=[];page.on('pageerror',lambda e:page_errors.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded',timeout=60000)
 page.evaluate(ANDROID);page.wait_for_timeout(250)
 page.locator('#sq176-home-pdf-project').click();page.wait_for_timeout(100)
 result=[]
 for mode,pdf,name in fixtures:
  inp=page.locator('#sq162-raster-file');inp.set_input_files(str(pdf))
  page.wait_for_function("document.querySelector('#sq162-raster-file').files.length===1 && !document.querySelector('#sq162-trace').disabled",timeout=30000)
  page.locator('#sq162-pdf-output-name').fill(name);page.evaluate('window.__nativeSavedFiles={};window.__nativeNotifiedFiles=[];')
  page.locator('#sq162-trace').click();page.wait_for_function("Object.keys(window.__nativeSavedFiles).length>0",timeout=60000)
  saved=page.evaluate('window.__nativeSavedFiles');assert list(saved.keys())==[name+'.dxf'],(mode,list(saved))
  item=saved[name+'.dxf'];assert item['mime']=='application/dxf'
  raw=base64.b64decode(item['base64']);out=root/f'V184_{mode.upper()}_R2004.dxf';out.write_bytes(raw);rawtxt=raw.decode('cp1252',errors='replace')
  assert rawtxt.startswith('  0\nSECTION\n  2\nHEADER\n')
  for section in ('CLASSES','TABLES','BLOCKS','ENTITIES','OBJECTS'): assert f'  2\n{section}\n' in rawtxt,section
  assert rawtxt.endswith('  0\nEOF\n')
  assert '\nIMAGE\n' not in rawtxt and '\nIMAGEDEF\n' not in rawtxt and '\nOLE2FRAME\n' not in rawtxt
  doc,rec=ezdxf.recover.readfile(out);audit=doc.audit();m=doc.modelspace()
  assert doc.dxfversion=='AC1018',doc.dxfversion
  assert not audit.errors and not audit.fixes,(mode,audit.errors,audit.fixes)
  assert len(m.query('LWPOLYLINE'))+len(m.query('POLYLINE'))>0,(mode,len(m))
  notes=page.evaluate('window.__nativeNotifiedFiles');assert len(notes)==1 and notes[0]['filename']==name+'.dxf',notes
  status=page.locator('#sq162-raster-status').inner_text();assert 'تم حفظ ملف DXF واحد' in status,status
  result.append({'mode':mode,'file':name+'.dxf','bytes':len(raw),'entities':len(m),'layers':len(doc.layers),'lwpolylines':len(m.query('LWPOLYLINE')),'polylines':len(m.query('POLYLINE')),'texts':len(m.query('TEXT')),'dxf_version':doc.dxfversion,'audit_errors':len(audit.errors),'audit_fixes':len(audit.fixes),'sections':['CLASSES','TABLES','BLOCKS','ENTITIES','OBJECTS']})
 report={'result':'PASS V184 PDF to standards-complete AC1018 DXF','fixtures':result,'browser_page_errors':page_errors[:10]}
 (root/'V184_PDF_TEST_LOG.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 print(json.dumps(report,ensure_ascii=False,indent=2));b.close()
