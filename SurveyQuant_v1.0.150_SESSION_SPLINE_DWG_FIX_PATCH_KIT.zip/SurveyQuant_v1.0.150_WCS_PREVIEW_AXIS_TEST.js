'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const htmlPath = process.argv[2];
assert(htmlPath, 'usage: node SurveyQuant_v1.0.149_WCS_PREVIEW_AXIS_TEST.js patched-index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
assert(html.includes('const SQ_APP_VERSION_CODE = 150;'), 'HTML must be V150');
assert(html.includes('height:34vh;min-height:200px;max-height:360px'), 'dual-board preview must be smaller');
assert(html.includes('function sqPreviewPointToWcs'), 'WCS preview converter missing');
assert(html.includes('function sqPreviewInsertMatrix'), 'OCS-aware INSERT matrix missing');
assert(html.includes('await window.parseFile(file)'), 'the active alignment file picker must use the shared canonical DWG reader');
assert(html.includes('window.parseFile = parseFile;'), 'shared canonical reader export missing');
assert(html.includes('function resetOrientationState()'), 'session reset implementation missing');
assert(html.includes('function prepareSideForReplacement(side)'), 'replace-board reset-before-read implementation missing');
assert(html.includes('state.loadSerial[side]=token;'), 'stale async-load generation guard missing');
assert(html.includes("if(t==='SPLINE'){"), 'active spline branch missing');
assert(html.includes('await LibreDwg.create(sqDwgWasmRuntimePath())'), 'local DWG WASM runtime path must remain available');
assert(html.includes('id="surveyquant-v150-fresh-board-session"'), 'fresh-board lifecycle script must carry the V150 tag');
assert(html.includes('const needsWcsPreview=[...all,...nestedRecords].some(sqPreviewHasNonCanonicalOcs)'), 'non-canonical OCS must force WCS fallback before parser');
assert(html.includes('const local=sqPreviewInsertMatrix(rec,block.base),next=compose(m,local)'), 'nested axis labels must use the OCS-aware INSERT matrix');
assert(html.includes('sqPreviewPointToWcs(rec,{x,y},baseCode)'), 'axis label anchors must be projected to WCS');
assert(html.includes('view.drawing.previewWcsFallback?\'WCS/OCS\''), 'WCS/fallback diagnosis must be visible in file info');

const helperStart = html.indexOf('const SQ_PREVIEW_OCS_TYPES');
const helperEnd = html.indexOf('function recordGeometry(rec)', helperStart);
assert(helperStart >= 0 && helperEnd > helperStart, 'cannot isolate WCS helper source');
const helpers = html.slice(helperStart, helperEnd);
const geomStart = html.indexOf('function geometryInWorld(', helperEnd);
const geomEnd = html.indexOf('function distPointSeg(', geomStart);
assert(geomStart >= 0 && geomEnd > geomStart, 'cannot isolate geometryInWorld');
const geometry = html.slice(geomStart, geomEnd);
const harness = `
function pairVal(rec, code, occ=0) { const arr=(rec.pairs||[]).filter(p=>p.code===code); if(!arr[occ]) return null; const n=Number(arr[occ].value); return Number.isFinite(n)?n:null; }
function pointAt(rec, code, occ=0) { const x=pairVal(rec,code,occ), y=pairVal(rec,code+10,occ); return x===null||y===null?null:{x,y}; }
function recordString(rec,code,occ=0) { const p=(rec.pairs||[]).filter(q=>q.code===code)[occ]; return p?String(p.value||'').trim():''; }
function num(v) { const n=Number(v); return Number.isFinite(n)?n:null; }
function mergeGeometry(a,b) { a.pts.push(...b.pts); a.segments.push(...b.segments); a.texts.push(...b.texts); return a; }
function recordGeometry(rec) { const g=rec.testGeometry||{pts:[],segments:[],texts:[]}; return {pts:g.pts||[],segments:g.segments||[],texts:g.texts||[]}; }
${helpers}
${geometry}
this.api={sqPreviewNormal,sqPreviewBasis,sqPreviewPointToWcs,sqPreviewTextDirection,sqPreviewHasNonCanonicalOcs,sqPreviewInsertMatrix,sqPreviewApplyMatrix,geometryInWorld};
`;
const context = vm.createContext({Math, Number, String, Set, Map, Object, Array, RegExp, Infinity, console});
vm.runInContext(harness, context, {filename:'wcs-preview-test-harness.js'});
const api = context.api;
const rec=(type,pairs=[])=>({type,pairs});
const normalZ=rec('CIRCLE',[]);
let q=api.sqPreviewPointToWcs(normalZ,{x:1200.5,y:800.25},10);
assert(Math.abs(q.x-1200.5)<1e-10 && Math.abs(q.y-800.25)<1e-10, '+Z OCS must retain XY');
const flipped=rec('CIRCLE',[{code:210,value:'0'},{code:220,value:'0'},{code:230,value:'-1'},{code:30,value:'0'}]);
assert.equal(api.sqPreviewHasNonCanonicalOcs(flipped),true,'negative-Z extrusion must switch to WCS preview');
q=api.sqPreviewPointToWcs(flipped,{x:100,y:200},10);
assert(Math.abs(q.x+100)<1e-10 && Math.abs(q.y-200)<1e-10, '-Z OCS point should map by AutoCAD arbitrary-axis basis, not raw XY');
const tilted=rec('TEXT',[{code:210,value:'0.3'},{code:220,value:'0.4'},{code:230,value:'0.866025403784'}]);
assert.equal(api.sqPreviewHasNonCanonicalOcs(tilted),true,'tilted OCS must switch to WCS preview');
const b=api.sqPreviewBasis(tilted);const dot=(u,v)=>u.x*v.x+u.y*v.y+u.z*v.z;
assert(Math.abs(dot(b.x,b.y))<1e-10 && Math.abs(dot(b.x,b.z))<1e-10 && Math.abs(dot(b.y,b.z))<1e-10, 'OCS basis must be orthogonal');
assert(Math.abs(Math.hypot(b.x.x,b.x.y,b.x.z)-1)<1e-10 && Math.abs(Math.hypot(b.y.x,b.y.y,b.y.z)-1)<1e-10, 'OCS basis axes must be normalized');
const insert=rec('INSERT',[{code:2,value:'B'},{code:10,value:'100'},{code:20,value:'200'},{code:30,value:'0'},{code:41,value:'2'},{code:42,value:'3'},{code:50,value:'0'},{code:210,value:'0'},{code:220,value:'0'},{code:230,value:'-1'}]);
const m=api.sqPreviewInsertMatrix(insert,{x:10,y:10});
const base=api.sqPreviewApplyMatrix(m,{x:10,y:10});
assert(Math.abs(base.x+100)<1e-10 && Math.abs(base.y-200)<1e-10, 'INSERT block base must land exactly on the OCS-converted insertion point');
assert(Math.abs(m.a+2)<1e-10 && Math.abs(m.d-3)<1e-10, 'INSERT scale/OCS basis matrix incorrect');
const block={base:{x:10,y:10},entities:[rec('CIRCLE',[],)]};
block.entities[0].testGeometry={pts:[{x:10,y:10},{x:11,y:10}],segments:[{a:{x:10,y:10},b:{x:11,y:10}}],texts:[]};
const geom=api.geometryInWorld(insert,new Map([['B',block]]),p=>p);
assert(geom.pts.length===2 && geom.segments.length===1, 'INSERT geometry was not expanded');
assert(Math.abs(geom.pts[0].x+100)<1e-10 && Math.abs(geom.pts[0].y-200)<1e-10, 'block base vertex does not map to WCS insertion origin');
assert(Math.abs(geom.pts[1].x+102)<1e-10 && Math.abs(geom.pts[1].y-200)<1e-10, 'scaled child vertex does not use OCS orientation and scale');
const textRec=rec('TEXT',[{code:210,value:'0'},{code:220,value:'0'},{code:230,value:'-1'}]);
const td=api.sqPreviewTextDirection(textRec,0);
assert(Math.abs(td.x+1)<1e-10 && Math.abs(td.y)<1e-10, 'text direction must follow OCS basis');
console.log('PASS V150 WCS preview: +Z, -Z and tilted OCS basis conversion');
console.log('PASS V150 WCS preview: INSERT insertion point, base point, rotation basis, and scale');
console.log('PASS V150 WCS preview: nested geometry returns real WCS points, not raw local XY');
console.log('PASS V150 WCS preview: axis-label text anchors/directions are wired to WCS conversion');
console.log('PASS V150 UI: preview canvas reduced to 34vh with 200-360px bounds');
