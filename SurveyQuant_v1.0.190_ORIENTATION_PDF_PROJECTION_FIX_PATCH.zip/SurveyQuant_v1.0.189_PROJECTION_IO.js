(function(root){
  'use strict';
  const DXF_TO_DWG_URL='https://anyconv.com/ar/tahwil-dxf-iilaa-dwg/';
  const DWG_TO_DXF_URL='https://anyconv.com/ar/tahwil-dwg-iilaa-dxf/';
  function asBytes(value){
    if(value instanceof Uint8Array)return value;
    if(value instanceof ArrayBuffer)return new Uint8Array(value);
    if(ArrayBuffer.isView(value))return new Uint8Array(value.buffer,value.byteOffset,value.byteLength);
    return new Uint8Array(value||[]);
  }
  function validateTextDxf(bytes,label){
    if(!bytes.length)throw new Error(`لم ينتج ملف ${label} أي بايتات DXF.`);
    const text=new TextDecoder('windows-1252').decode(bytes);
    const lines=text.split(/\r?\n/).map(line=>line.trim());
    let hasEntities=false;
    for(let i=0;i<lines.length-3;i++){
      if(lines[i]==='0'&&lines[i+1].toUpperCase()==='SECTION'&&lines[i+2]==='2'&&lines[i+3].toUpperCase()==='ENTITIES'){hasEntities=true;break;}
    }
    let end=lines.length-1;while(end>=0&&!lines[end])end--;
    const hasEof=end>=1&&lines[end].toUpperCase()==='EOF'&&lines[end-1]==='0';
    if(!hasEntities||!hasEof)throw new Error(`ملف ${label} ليس DXF نصياً مكتملاً بقسم ENTITIES وEOF. لم يتم إجراء دمج أو إخراج ناقص.`);
    return bytes;
  }
  async function readCadBytes(file,parseFileFn,statusFn){
    if(!file||typeof file.arrayBuffer!=='function')throw new Error('ملف CAD غير صالح أو لم يتم اختياره.');
    const name=String(file.name||'drawing'),lower=name.toLowerCase();
    if(!/\.(?:dxf|dwg)$/.test(lower))throw new Error(`الصيغة غير مدعومة في إسقاط CAD: ${name}. اختر DXF أو DWG.`);
    if(typeof parseFileFn!=='function')throw new Error('قارئ ملفات DWG/DXF غير متاح داخل التطبيق.');
    if(typeof statusFn==='function')statusFn(`⏳ جاري قراءة ${name}...`);
    const sourceBytes=asBytes(await file.arrayBuffer());
    if(!sourceBytes.length)throw new Error(`وصل الملف ${name} فارغاً من مدير الملفات.`);
    if(lower.endsWith('.dxf')){
      const bytes=validateTextDxf(sourceBytes,name);
      const model=await parseFileFn(file,{rawOnly:true,sourceBytes});
      return {model,bytes,sourceFormat:'DXF',sourceName:name,originalBytes:sourceBytes};
    }
    const model=await parseFileFn(file,{rawOnly:true,conversionOnly:true,retainRawDWG:false,projectionSource:true,sourceBytes});
    const converted=asBytes(model&&model.rawDXFBytes);
    if(!converted.length)throw new Error(`تعذر تحويل ${name} إلى DXF داخلياً. لم يتم تعديل المصدر ولم يتم إنشاء ناتج جزئي. يمكن استخدام محول DWG إلى DXF الخارجي من الروابط الموجودة في المشروع.`);
    const bytes=validateTextDxf(converted,`DXF المحول من ${name}`);
    return {model,bytes,sourceFormat:'DWG',sourceName:name,originalBytes:sourceBytes};
  }
  function resolveExportFormat(value){
    const v=String(value||'dxf').trim().toLowerCase();
    if(v!=='dxf'&&v!=='dwg')throw new Error('صيغة الإخراج يجب أن تكون DXF أو DWG.');
    return v;
  }
  async function exportMergedCad(bytes,format,saveFn,baseName='SurveyQuant_Dropped_Files'){
    const data=asBytes(bytes),kind=resolveExportFormat(format);
    if(!data.length)throw new Error('لا توجد لوحة مدمجة للتصدير. نفّذ الإسقاط أولاً.');
    if(typeof saveFn!=='function')throw new Error('خدمة حفظ الملفات غير متاحة داخل التطبيق.');
    const filename=`${String(baseName||'SurveyQuant_Dropped_Files').replace(/[^A-Za-z0-9_.-]/g,'_')}.dxf`;
    const saved=await saveFn(data,filename,'application/dxf',false,true);
    if(saved===null||saved===false||(typeof saved==='string'&&/^ERROR(?:[: ]|$)/i.test(saved)))throw new Error('فشل Android في طلب حفظ ملف DXF الوسيط. لم يتم فتح المحول الخارجي.');
    if(kind==='dxf')return {requestedFormat:'dxf',savedFormat:'dxf',filename,saved,direct:true,converterUrl:null};
    return {requestedFormat:'dwg',savedFormat:'dxf',filename,saved,direct:false,converterUrl:DXF_TO_DWG_URL,reverseConverterUrl:DWG_TO_DXF_URL,
      message:'تم حفظ DXF الوسيط. افتح محول DXF إلى DWG، واختر الملف المحفوظ من Downloads/SurveyQuant، ثم نزّل DWG الناتج.'};
  }
  root.SurveyQuantProjectionIO={readCadBytes,validateTextDxf,resolveExportFormat,exportMergedCad,DXF_TO_DWG_URL,DWG_TO_DXF_URL};
  if(typeof module==='object'&&module.exports)module.exports=root.SurveyQuantProjectionIO;
})(typeof window!=='undefined'?window:globalThis);
