SurveyQuant v1.0.152 | أمر Alignment جديد من الصفر

المحتويات:
- ALIGNMENT_CORE: حساب نقطتين وتحويل هندسي موحد (دوران + مقياس + إزاحة) وتحويل DXF مع حفظ بايتات وسجلات الملف غير المعدلة قدر الإمكان.
- ALIGNMENT_COMMAND: شاشة مستقلة لاختيار DXF/DWG، التقاط 4 نقاط، معاينة على المرجع، والتنزيل.
- REBUILD_ALIGNMENT_FROM_SCRATCH.py: يحذف وحدات التوجيه القديمة السبع ويفصل مراجعها من صفحة التطبيق، ثم يحقن الوحدة الجديدة.
- PACKAGE_APK.py: يحقن HTML النهائي داخل APK ويضبط رقم الإصدار 1.0.152 / 152؛ يلزم توقيع APK بعد ذلك.
- ALIGNMENT_TEST.js: اختبار الحساب والتحويل وحفظ الطبقات والنصوص ورفض الكائنات المغلقة.
- build-v152-alignment-from-scratch.yml: سير عمل GitHub Actions لتجهيز APK موقّع.

طريقة الإعداد من الهاتف:
1) ارفع الملف SurveyQuant_v1.0.152_ALIGNMENT_PATCH_KIT.zip إلى جذر مستودع SurveyQuantAndroid_v1.0.57.
2) أضف build-v152-alignment-from-scratch.yml في المسار .github/workflows/build-v152-alignment-from-scratch.yml.
3) رفع ملف الـ workflow بعد رفع ZIP سيشغل البناء تلقائيًا. يجب أن يظل Artifact إصدار V150 رقم التشغيل 40189448694 متاحًا.
4) بعد النجاح، نزّل Artifact باسم SurveyQuant-v1.0.152-ALIGNMENT-FROM-SCRATCH من Actions.

حدود فنية مهمة:
- يقبل الأمر DXF وDWG للقراءة، لكن الناتج DXF لأن الحزمة لا تحتوي على كاتب DWG أصلي.
- كائنات Proxy وCivil 3D المغلقة التي لا تكشف هندستها للتحويل الدقيق يتم رفض إخراجها بدل تحريك جزء من اللوحة بصمت.
- اختبارات الكود لا تغني عن اختبار ملفات DWG/DXF الحقيقية في التطبيق.
